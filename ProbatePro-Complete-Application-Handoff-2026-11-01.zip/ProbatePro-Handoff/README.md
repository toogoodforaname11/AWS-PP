# ProbatePro — complete source handoff for Claude

Start here. This is a portable **source-and-schema package**, not a production database backup, running deployment, or export of Manus secrets.

**Application source checkpoint:** `a304b3c991ffb25d6dfc2d7833fb9f9b8829ee43` — the integrated, isolated-verification staging version. The application code, court-document generators, UI, popup implementation, schema, migrations, dependencies and lockfiles are copied unchanged from that checkpoint. The only source-tree overlay is `application/PROJECT_PREFERENCES.md`, containing later documentation-only decisions. Its checkpoint version is preserved under `handoff/source-baseline/` and the difference is explicitly identified in the source manifest.

**Updated original handoff — review incorporated:** this original package now includes the complete review, corrected setup guides, verification evidence and updated Claude receiving prompt. Read [`handoff/ARCHIVE_AUDIT.md`](handoff/ARCHIVE_AUDIT.md) and [`README errata and precedence`](handoff/README_ERRATA_AND_PRECEDENCE.md) first. The review adds setup/provenance material outside the unchanged application, not a rewritten app or a production deployment.

## Read in this order

1. [`CLAUDE_START_HERE.md`](CLAUDE_START_HERE.md): the exact receiving-agent instructions and authorization boundary.
2. [`handoff/CURRENT_STATUS.md`](handoff/CURRENT_STATUS.md): what is verified, what is historical, and what remains unverified.
3. [`handoff/FROZEN_BEHAVIOR_AND_ACCEPTANCE.md`](handoff/FROZEN_BEHAVIOR_AND_ACCEPTANCE.md): document freeze, restored single-form inline popups, bulk/package restrictions, and regression checklist.
4. [`handoff/LOCAL_SETUP_AND_VERIFICATION.md`](handoff/LOCAL_SETUP_AND_VERIFICATION.md): installation, serial gates, development/build commands and startup prerequisites.
5. [`database/README.md`](database/README.md): exact existing database schema/migration setup; **no rows or database dump** are included.
6. [`handoff/OAUTH_AND_PLATFORM_DEPENDENCIES.md`](handoff/OAUTH_AND_PLATFORM_DEPENDENCIES.md): existing Manus OAuth flow, secure configuration and platform dependencies.
7. [`handoff/AWS_HOSTING_PLAN.md`](handoff/AWS_HOSTING_PLAN.md): future AWS-hosting sequence, not a completed or authorized deployment.
8. [`Production build contract`](handoff/PRODUCTION_BUILD_CONTRACT.md), [`configuration checklist`](handoff/CONFIGURATION_CHECKLIST.md), and [`external asset inventory`](handoff/EXTERNAL_ASSET_MANIFEST.md): preserve both dependency graphs, runtime layout, all feature inputs and visual dependencies.
9. [`Schema catalog`](database/SCHEMA_CATALOG.json) and [`fresh migration preflight`](database/FRESH_MIGRATION_PREFLIGHT.json): exact source metadata, original snapshot gaps, duplicate ADD hazards and existing-data migration risks. Run `python3 handoff/review_database_definition.py` before any DB attempt; this does not connect a DB.

Also read `application/RULES.md`, scoped instructions, `application/plan.md`, the latest `PROJECT_PREFERENCES.md`, `application/TODO.md`, `application/docs/integration/`, and the original source plans and final review under `application/docs/superpowers/plans/` and `application/outputs/`. Historical documents retain their original status and must not be interpreted as current deployment facts.

## Package structure

```text
application/        Complete tracked application at the verified checkpoint
  client/           React interface, static assets and popup implementation
  server/           Express/tRPC, authentication, generation, delivery and storage
  shared/           Contracts, form requirements, domain/legal rules
  drizzle/          Schema, relations, migrations 0000–0173, snapshots and journal
  chatbot/          Included companion source, tests, manifests and lockfile
  test-fixtures/    Accepted fictional integration/render fixtures and provenance
  references/       Official form/legislation captures and integration references
  docs/, outputs/   Existing plans, repair ledgers, task audit trail and reports
  tools/integration/Existing isolated installer, serial gates and render verifier
handoff/            New receiving/setup/OAuth/AWS/preservation instructions
  aws-context/      Selected no-secret production policy evidence and context
  source-baseline/  Checkpoint copy of the later-overlaid preference document
database/           Database setup instructions and migration index
SOURCE_MANIFEST.json Exact hashes for every original application file
PACKAGE_MANIFEST.json SHA-256 hashes for the delivered package payload
```

## Verify before installing

Extract into a **new empty directory**, not over an existing application or dirty working tree. Do not use an extractor that discards hidden files or converts CRLF/LF endings. Then run from this package root:

```sh
python3 handoff/verify_package.py
```

On native Windows, `py -3 handoff/verify_package.py` is the equivalent verification command. Use WSL2/Ubuntu for the existing isolated Node gate runner; its Windows-native process-isolation path is deliberately refused.

The receiver verifier reads only package files. It checks hashes, required directories, duplicate/case-colliding paths and unexpected symlinks. It never starts the app, connects a DB, reads secrets or changes files. This is archive integrity verification, not test execution or production acceptance.

After reading the rules, follow `LOCAL_SETUP_AND_VERIFICATION.md` to install the **existing pinned** toolchain/dependencies and run the six isolated gates. Do not run a bare `pnpm dev` expecting a complete environment: this source fails closed when required auth/encryption settings are absent, and the production startup additionally proves storage and schema before listening.

## The database included here

The complete current database **definition** is included: `drizzle/schema.ts`, `relations.ts`, all 174 SQL migrations, migration metadata/journal, schema checker, migration runner, and relevant tests. No existing database has been inspected or exported for this package. There are no estate/user rows, account data, uploads, stored legal documents, master credentials, RDS instance, or SQL data dump.

Create a **new disposable local database with fictional data only** when following the development instructions. Migrating a live database or creating RDS is a later separately approved task. Do not substitute a generic generated schema or run `db:push`; use the existing migration runner and explicit schema checks.

## Keep the current behavior exactly

**Do not edit document wording, citations, formatting, layout, templates, DOCX/PDF/HTML rendering, legal rules, or form-selection logic. Do not redesign or replace the popup.** Single-form missing-information popups accept the existing typed inline fields and apply explicit entries before generation through the existing save/override boundaries. Bulk and grant-package gap popups intentionally do not accept inline edits. Missing facts remain warn-only where already supported; Generate anyway must remain available without bypassing authorization, input-integrity or other safety checks.

The source contains previously accepted repairs and regressions; preserve them byte-for-byte until an explicitly approved non-document deployment adaptation is needed. Use the supplied source/hash manifests and frozen baseline verifier rather than re-generating golden files. The notes Unicode **filename** repair is included, but visible Unicode PDF-content garbling remains an acknowledged unmodified-renderer limitation.

## OAuth and hosting are not magically portable credentials

The existing app uses legacy Manus OAuth plus its own signed sessions, existing email/password auth and estate-scoped portal sessions. The OAuth code is included, but usable project configuration and permission to redirect to a new AWS-hosted callback are not in this ZIP and have not been proven. Preserve the real existing flow; do not fabricate a login, remove nonce/CSRF checks, rename cookies or assume generic OIDC behavior.

A full AWS deployment would need secrets supplied privately, approved callback/origin configuration, verified MySQL TLS, a container/runtime and ingress design, and any platform-service/asset dependencies resolved. The package includes direct instructions and a plan for that work; it does **not** claim an unchanged production server can already be started safely on AWS.

Outside Manus, `DATABASE_URL` is not reserved by Webdev and can remain the application’s input. Within the current Manus project it is reserved by the enabled managed database, so a later external DB path there would need a distinct protected name. In either case the current URL-only DB adapter/migration path needs a separately approved verified-TLS integration before RDS production use.

## Exclusions and custody

Excluded intentionally: `.git` and its remotes/credentials/history database, all real `.env`/secret values, owner-vault files, private HMAC run key, production and local runtime databases, uploads, browser profiles, cookies/tokens, logs, `.work`, `node_modules`, caches and compiled `dist` outputs. The vetted `chatbot/.env.example` is an empty-key documentation template, not a populated runtime file. All reviewed fictional golden DOCX/preview fixtures remain included because the frozen-render checks require them.

The application’s existing MIT declaration is retained; official forms/reference captures and included assets retain their own provenance. Keep this archive private as source/audit material. Packaging does not commit, push, publish, change AWS policies, move live data, close historical unaccepted tasks, or complete the pending GitHub owner-confirmation flow.
