# Project Rules

## Rule 1: Exact Form Wording (MANDATORY)

All generated court forms (P1, P2, P3, P4, P5, P9, P10, P14, P16, P19, P46, PGT_INFO, LETTER, etc.) **MUST** use the **exact wording** from the official BC Supreme Court Civil Rules.

- The authoritative source is: `references/SupremeCourtCivilRules.md`
- **Repository Markdown only:** official wording checks and any form-text change MUST use the applicable captured official Markdown reference in `references/` as the source of truth. Do **not** use a live website, PDF, search result, or secondary source to select, verify, or alter prescribed wording.
- If the necessary official wording is missing from the repository Markdown references, stop the wording change and request that the source be captured or supplied before proceeding.
- **No paraphrasing** — every word must match the official form text
- **No abbreviations** — use the full text as written in the rules
- **No close approximations** — if the rule says "Administration of the estate", do not write "Administration of estate" or "Grant of Admin"
- Before writing or modifying any form text in `server/docgen.ts` or related files, **ALWAYS** read the relevant section of `references/SupremeCourtCivilRules.md` first
- When in doubt, copy the exact text from the reference document

This rule applies to:
- DOCX document generation (`server/docgen.ts`)
- HTML preview generation (preview sections in `server/docgen.ts`)
- Any UI labels that display official form language
- Test assertions that verify form content

---

## Rule 1A: Selected-Only Alternatives and Completion Check (MANDATORY)

Whenever a probate form is created, corrected, or otherwise edited, the completed
DOCX and its matching preview **MUST** be checked for unused official alternatives.
Every unselected, unanswered, or inapplicable alternative — including an empty
placeholder line, unchecked box, drafting scaffold, or companion-document line —
**MUST be hidden** unless the official form expressly requires it to remain visible.

- Render only the official alternative or alternatives supported by the recorded
  facts. Never leave neighbouring exclusive alternatives, empty fill-ins, or
  unticked boxes visible merely because a shared renderer emitted them.
- A missing fact may remain as the form's existing blank fill **only when that
  blank is part of the selected official alternative**. It must not cause a
  different or unused alternative to print.
- Verify both DOCX and structured-preview output before completing every form
  edit. Add or update focused tests for both a selected case and an unused case.
- Do not change official wording, prescribed layout, or a form's expressly
  required visible alternatives to satisfy this rule.

This rule applies to every form renderer, preview branch, form-specific document
test, and future document-edit completion checklist.

---

## Rule 2: Logic Must Come from the Act (MANDATORY)

All conditional logic, if/then branching, eligibility determinations, distribution calculations, and legal reasoning in this application **MUST** be derived from the **Wills, Estates and Succession Act** [SBC 2009] Chapter 13.

- The authoritative source is: `references/WillsEstatesAndSuccessionAct.md`
- **Never invent logic** — every conditional branch must trace back to a specific section of the Act
- **Never suggest rules** that are not explicitly stated in the Act
- **Never approximate** the Act's provisions — use the exact logic as written
- Before implementing any if/then logic related to estates, wills, intestacy, distribution, spousal rights, or grant eligibility, **ALWAYS** read the relevant section of the Act first
- When in doubt, cite the specific section number (e.g., "per s. 21(1)")

This rule applies to:
- Intestacy distribution calculations (Part 3 of the Act)
- Spousal entitlement logic (ss. 20-22, Division 2)
- Will validity determinations (Part 4)
- Grant type eligibility (Part 6)
- Beneficiary and successor identification
- Any readiness checks or validation that references legal requirements
- Form requirement logic (which forms are needed based on estate type)

---

## Rule 3: Form P11 Production Rulings (MANDATORY — Nick, 2026-07-12)

Ruled by Nick at the 2026-07-12 remediation gate (the earlier sweep's self-recorded
"no trailing space" and "blank oath" bullets were NOT approved and are struck):

- **P11 keeps sibling formatting.** The header prints the official trailing space
  (`Form P11 (Rule 25-3 (2) )`) like every other form — the global
  trailing-paren-space contradiction stays open as one series-wide question, never
  resolved per-form. Affidavit header: uppercase name, long date, ordinal from
  `p11AffidavitOrdinal` defaulting to "1st". ~~Oath follows the sibling idiom
  (`affirmed → AFFIRM/affirmed`, otherwise `SWEAR/sworn`).~~ **STRUCK by Rule 8
  (2026-07-16): the oath default is AFFIRMED.** The shared `jurat()`
  and `exhibitStampBlock()` render the jurat and exhibit stamp — no per-form
  jurat geometry. The bracketed `[Rule 22-3 …]` instruction stays off P11
  (UNIV-2 convention re-affirmed).
- Capitalize `(the "Deceased")` per the standing AUTOFMT-6 ruling.
- P11 default/package selection is fail-closed under Rule 25-3(8): both domicile and ordinary
  residence must be explicitly answered `no`, and the outside-British-Columbia
  administration state must be explicitly supported (`foreign_pr`, `foreign_law`,
  `none_outside`, or legacy `yes`).
- P10 and P11 are mutually exclusive in default/package selection. Explicit
  single-form P11 drafts remain available under Addendum 24.5. Never infer P11 from a mailing address,
  province, country, or grant type.
- Keep the official Part III heading unchanged (face-verbatim, including its
  outside-BC intangibles clause), but print actual P11 property rows only when
  `inventory.location === "in_bc"` (product scope ruling).
- Print only secured liabilities explicitly linked to the property item they
  charge or encumber. No separate liabilities, summary, distribution, or
  probate-fee section on P11.
- A missing sworn fact remains blank: grant type (all `estateGrantTypePhrase`
  consumers print the blank fill for unknown/unset), category, location, jurat
  city, signing date, deponent facts, and security classification are never
  silently defaulted to a sworn value. (Ordinal follows the sibling default
  above — ruled 2026-07-12. The oath word is a *choice with a default*, not a
  missing fact: see Rule 8.)
- Fee estimates (`inventoryTotals()` / the fee endpoint) use the shared
  `probateItemValue()` basis so the fee card matches the sworn P10/P11 exhibits —
  ruled 2026-07-12, superseding the P10-arc "fee cards stay on raw value" note.
- Requirement gaps retain an explicit "Generate anyway" override. **Superseded
  for explicit P11 drafts by Addendum 24.5 (2026-09-06):** applicability warns
  to use P10 and does not block the user's P11 draft choice. Default API and
  package applicability checks remain enforced.

---

## Rule 4: Form P12 Production Rulings (MANDATORY — Nick, 2026-07-13)

P12 (Affidavit of Translator) was swept to the official Appendix A.1 face. The
pre-sweep builder printed an entirely invented 5-paragraph body with the Exhibit
letters **reversed** (translation marked A, source marked B) — a substantive
defect. Rulings:

- **Deliberate FORMAT-FREEZE structural exception, P12 only.** Replacing the five
  invented paragraphs with the official preamble + two paragraphs is the *sole*
  sanctioned structural change to `buildP12`/its preview mirror. Every other
  docgen edit remains wording-only + logic-only; `p()/r()/blank()/jurat()/
  styleOfCause()` internals and all spacing/geometry are untouched.
- **Exhibit lettering matches the face:** Exhibit A = the foreign-language
  source/original document; Exhibit B = the English translation. (The pre-sweep
  reversal is corrected.) Exhibit letters print plain (`Exhibit A`/`Exhibit B`),
  not curly-quoted — consistent with the face and sibling P11.
- **The deponent is the translator, not the applicant.** The preamble prints the
  neutral face form `I, {translatorName}, of ____, ____, SWEAR (OR AFFIRM) THAT:`
  and P12 does **not** branch the oath on `estate.oathType` (unlike the
  applicant-sworn P11, whose deponent *is* the applicant). The DOCX jurat is the
  shared neutral "SWORN (OR AFFIRMED) BEFORE ME"; the preview jurat mirrors it
  (no bespoke "AFFIRMED before me … BC on …" line). Translator address and
  occupation print blank — no columns exist and no schema change was made.
- **P2 ↔ P12 draw from the same fields.** Both P2 §8 and P12 name the translator
  from `estate.translatorName` and the identified document from
  `estate.translatedDocument`; P12 no longer hard-codes "the will of the
  deceased," so the two filed forms can never name a different translator/document.
- **No fabricated sworn facts.** Missing translator identity, source language, and
  identified document print the blank fill, never a default; the pre-sweep
  `"[source language]"` default is struck (adr-no-fabricated-sworn-facts rule 1).
- **UNIV-2 / header conventions carry over.** The bracketed `[Rule 22-3 …]` and
  `[Repeat this section …]` drafting instructions stay off the printed face; the
  header keeps the sibling trailing-space idiom (`Form P12 (Rule 25-3 (2) )`) and
  the printed style-of-cause cites `Rule 25-3 (2)` (subrule `(h)` lives only in
  `FORM_CATALOG`/`formRequirements`, per adr-printed-headers-official-face).
- **`p12_will_date` requirement removed** — the official P12 body does not print
  the will date, so preflight no longer gates P12 on it.

Flagged for a future ruling (not fixed in this sweep, no schema change):
- **Multi-document limitation.** Single scalar `translatorName` /
  `translatedDocument` / `willSourceLanguage` columns cannot represent multiple
  non-English documents, though Rule 25-3(2)(h) requires a P12 "for each … document
  … not written in the English language" and the face says "[Repeat this section
  for each document …]". A translations table is needed before multi-document
  support is possible.
- **No translator address/occupation columns** (preamble prints blank).
- **No P12 `FormDetailsDialog` config** (translator-as-deponent picker / jurat
  city) — deferred by adr-form-details-popup (P1–P11 scope).
- **P12 applicability is client-gated only** (`assertAssetsFormApplicable` is
  P10/P11-only). Consistent with house behavior; left unchanged.

---

## Rule 5: Form P34 Production Rulings (MANDATORY — Nick, 2026-07-14)

P34 (Affidavit of Deemed Renunciation, Rule 25-11(7)) was swept to the official
Appendix A.1 face and rebuilt on a Rule 25-11 **citation record**. The pre-sweep
builder printed invented wording ("MAKE OATH AND SAY THAT:", an invented Form P32
executor-bullet body, and "deemed under Rule 25-11(5) … on the following ground:
___") derived from the `executorStatus` flag — a substantive defect and a
fabricated sworn basis. Rulings:

- **Deliberate FORMAT-FREEZE structural exception, P34 only** (the sanctioned
  exception alongside P12). Replacing the invented body with the official face is
  the *sole* sanctioned structural change to `buildP34`/its preview mirror:
  the preamble `I, {citor}, of {address}, {occupation}, SWEAR (OR AFFIRM) THAT:`;
  paragraphs 1–3 verbatim (Exhibit A citation; the para-2 service route; the
  para-3 deemed-renunciation alternative); the added centered heading
  `AFFIDAVIT OF DEEMED RENUNCIATION` (present on the face and the preview, absent
  from the old DOCX); and the **blank jurat oath-city** (the citor's oath location
  is hand-completed — never the deceased's domicile). Every other docgen edit
  remains wording-only + logic-only; `p()/r()/blank()/jurat()/styleOfCause()`
  geometry is untouched. A single `resolveP34RenderFacts` drives DOCX and preview
  identically so the two surfaces can never diverge on the sworn text.
- **Citations verbatim from the face.** The body cites `Rule 25-11 (4)`,
  `(4) (b) (i)/(ii)/(iii) (A)/(iii) (B)`, and "at least 14 days have elapsed."
  The subrule-(5) deemed-renunciation basis and the (5)(a)(ii) 6-month window are
  **not** printed on the P34 body — they are the eligibility basis (enforced
  server-side) and appear on Form P33, not on the P34 face.
- **No fabricated sworn facts.** Every sworn value (citor identity/address/
  occupation, cited name, served date/time/place, service-affidavit facts,
  response type + evidence file, deceased legal name) is read from the citation
  record; any missing required value throws. `grant_copy` (already granted → not
  deemed renounced) and contradictory branches (no-response + a served response, a
  recorded grant-issue date) are rejected.
- **Citation-record-scoped model (not `executorStatus`).** `formStatus("P34")` is
  always `conditional`, gated on a complete + eligible Rule 25-11 citation record.
  P34 is excluded from the generic `grantPackageCodes`, **but** the grant package
  generates a P34 for each eligible citation record and **fails closed** at both
  `document.preflight` and `generatePackage` (`buildGrantPackagePlan.
  missingP34Contacts`) when a `deemed_renounced` executor lacks a complete
  citation — so a required P34 is never silently dropped from a filing
  (SCCR 25-3(2)(i)(ii)).
- **Server-side eligibility only.** `assertP34CitationEligible` /
  `evaluateP34Citation` enforce the deadline/outcome eligibility (14-day
  no-response; 6-month grant window for the (b)(i)/(ii)/(iii)(A) routes; immediate
  for the (b)(iii)(B) refusal). The renderer never reads the wall clock.
- **Oath default carries over.** The jurat uses the shared `jurat()` geometry and
  the affirmed default; the oath city is left blank for hand-completion.

---

## Rule 6: Form P13 Production Rulings (MANDATORY — Nick, 2026-07-15)

P13 (Direction of the Public Guardian and Trustee, Rule 25-3(13)) is **built and
generable** on the **P19 court-issued precedent** (P19 likewise has a full
face-matched `buildP19` + preview + `BUILDERS` entry even though it is court-issued).
An earlier pass wrongly concluded P13 should have no builder; that was corrected — the
whole point of the form sweep is to match every form's wording exactly, and P19 shows
external/court forms still get a face-matched builder. Rulings:

- **P13 is generated only when the PGT is the applicant.** New estate column
  `pgtIsApplicant` (`varchar(8)`, default `"no"`, migration `0094`) captures the Rule
  25-3(13) precondition ("If the Public Guardian and Trustee **is the applicant** …").
  `formStatus("P13")` is **`conditional`** when `pgtIsApplicant === "yes"` and **`na`**
  otherwise (default). It is deliberately **NOT** tied to `requiresPGT` / the minor- or
  incapable-recipient notice triggers (Rule 25-2(8)/(11)) — those drive **PGT_INFO**
  (Rule 25-2(13)), a distinct, applicant-authored form. `pgtIsApplicant` is a dedicated
  column (not `applicantType`) to avoid rippling into `applicantType`'s signatory/service
  consumers.
- **Base sealing direction is face-verbatim.** `buildP13` (+ its `buildPreviewSections`
  mirror) prints the header `Form P13 (Rule 25-3 (13) )`, the centered **DIRECTION OF
  PUBLIC GUARDIAN AND TRUSTEE** title, and the one sealing sentence: *"Pursuant to Rule
  25-3 (13) … the court file in this proceeding be sealed in the manner and for the
  period referred to in section 125 of the Wills, Estates and Succession Act."* (**WESA
  s.125**, the sealing power — not s.124.)
- **Signature block matches the official face layout (deliberate P13-only format
  exception).** The Date and the PGT signature lines are rendered as a single invisible
  two-column table: Date on the left, underline / `Signature of [ ] Public Guardian and
  Trustee` / `[ ] authorized signatory for the Public Guardian and Trustee` / second
  underline / `[type or print name]` on the right. This is the sole sanctioned structural
  change to `buildP13`/its preview mirror; `styleOfCause()`/`p()`/`r()`/`blank()` geometry
  is otherwise untouched.
- **No applicant jurat, oath, or deponent.** P13 is **excluded from `AFFIDAVIT_FORMS`**;
  the face is signed by the PGT / an authorized signatory for the PGT. `estate.oathType`
  never touches P13. The signing **date** and the two **`[ ]` signatory selectors** are
  hand-completed on signing (face-verbatim literal brackets — never a sworn or defaulted
  value, per adr-no-fabricated-sworn-facts).
- **Documents row stores the PGT as signatory, never an applicant.** Every render path
  sets `signatoryType = "pgt"` and `deponentName = "Public Guardian and Trustee"` with an
  empty `deponentId` for `PGT_SIGNED_FORMS`. This prevents a PGT-signed form from being
  recorded as if it were sworn by the applicant/executor/lawyer.
- ~~**Optional related-material clause deferred.** The face's *"[add, if required:
  including the following related material …[identify]…]"* insertion is genuinely
  optional; v1 prints the base sealing direction only. Adding a `p13SealedMaterial`
  column + intake field is a future enhancement requiring Nick/product sign-off.~~
  **SUPERSEDED by Rule 17 (2026-08-04, Nick DO-NOT-SHIP directive):** the
  `p13SealedMaterial` column + intake field shipped (migration 0112); a recorded
  entry prints the face's insertion verbatim, blank keeps the base direction.
- **PGT_INFO independence.** P13 (Rule 25-3(13), PGT-as-applicant sealing direction) and
  `PGT_INFO` (Rule 25-2(13), applicant-to-PGT notice) are distinct forms with distinct
  triggers. They are tested independently: a `requiresPGT` notice fixture makes
  `PGT_INFO` required while P13 stays `na`; only `pgtIsApplicant === "yes"` makes P13
  conditional.
- **End-to-end.** Intake toggle ("Is the Public Guardian and Trustee the applicant?"
  → `pgtIsApplicant`) → `estate.update` → `formStatus` conditional → preflight
  `_applicability` passes (hard-blocks when `na`) → `generateForm`/`buildP13` → preview
  mirror = DOCX → `/api/download/form` → `documents` row with `signatoryType="pgt"`. No
  `FORM_REQUIREMENTS` rows: P13's only gate is applicability. (Updated by Rule 17,
  2026-08-04: beyond the style of cause it now prints the OPTIONAL lawyer-recorded
  `p13SealedMaterial` insertion; still no requirement rows — the face marks it
  "add, if required".)
- **Record correction (2026-07-15):** the P13 audit brief assumed **WESA s.124**, a
  `requiresPGT` trigger, and that P13 was external-only. The face invokes **WESA s.125**;
  the trigger is `pgtIsApplicant`; and P13 is built like P19.

Flagged for Nick (open, documented — not silently resolved):
- **Generate-vs-track was a decision, not a silent default.** At the 2026-07-15 gate Nick
  chose "build + make it generable" over "track as a received external document." P13 is
  therefore user-generated like any other form. The alternative (track-only, no builder)
  remains available if Nick reverses.
- ~~**Optional related-material clause** (`[add, if required …[identify]…]`) is deferred —
  needs a `p13SealedMaterial` column + intake field (see bullet above).~~
  **RESOLVED — see Rule 17 (2026-08-04):** implemented end-to-end by Nick's directive.
- **`applicantType` vs `pgtIsApplicant` are intentionally independent.** `pgtIsApplicant`
  answers Rule 25-3(13) ("is the PGT the grant applicant?"); `applicantType`
  (`na`/`lawyer`/`executor`) answers "who signs/prepares." A lawyer may act **for** the
  PGT, so `applicantType="lawyer"` + `pgtIsApplicant="yes"` is valid, not contradictory —
  no cross-field guard is imposed. If Nick wants the two merged into one applicant-identity
  field (with a `pgt` option), that is a future intake change.
- **Preview header parity is per-form for P13.** P13's preview reproduces the DOCX header
  including the trailing paren-space (`Form P13 (Rule 25-3 (13) )`), so preview = DOCX for
  P13. Every other form still carries the known, accepted DOCX/preview trailing-space
  mismatch pending Nick's series-wide ruling; that global ruling will subsume P13.

Locked by regression tests: `formStatus("P13")` is `na` by default and `conditional`
when `pgtIsApplicant === "yes"` (`shared/formStatus.test.ts`); it stays `na` under a
`requiresPGT` fixture (proving PGT_INFO independence); `buildP13` renders the verbatim
base sealing direction and signature table and is absent from `AFFIDAVIT_FORMS`
(`server/verify-all-forms.test.ts`, `server/routers.applicability.test.ts`); the
documents row records `signatoryType="pgt"` for P13; and every render path hard-blocks
P13 unless the PGT is the applicant.

## Rule 7 (UNRATIFIED — pending Nick): Form P14 sweep record, 2026-07-16

STATUS: this section is a WORK RECORD, not a ruling. The 2026-07-16 P14 arc is not
signed off. An earlier version of this section asserted "MANDATORY — Nick" and "Locked
by regression tests" for decisions Nick had not made, and carried claims a later
adversarial review disproved (e.g. it claimed preview/DOCX parity was "locked" by a test
that never generated a DOCX). Both the self-authorization and the false claims are
withdrawn. Only re-verified facts remain below.

### Rulings Nick HAS given (2026-07-16)

- **Supplemental provenance is a real per-item model, built now** (not deferred). The
  P14/P15 face ¶3(a) discloses only property "that was not disclosed or was inaccurately
  disclosed in any earlier affidavit of assets and liabilities filed in this proceeding".
  Reprinting the whole current inventory swore that every asset had been omitted or
  misstated on the filed P10 — a fabricated sworn fact. `inventory.supplementalStatus`
  (migration 0097) fails closed: `""` = unrecorded, and an unresolved item is sworn on no
  supplemental.
- **Lineage is built now.** `inventory.supplementalFiledDate` (migration 0097): once the
  supplemental disclosing an item has been filed, the item IS disclosed and drops off
  every later P14 (face ¶4) — otherwise the next supplemental would swear it was omitted
  a second time.
- **LIABILITIES / SUMMARY stay on P14, mirroring the validated P10.** Neither section
  appears on the P10 or P14 Exhibit A face (both end at GROSS VALUE OF ASSETS LESS
  SECURED DEBTS), but P10 is the validated reference and its E2/E3/E4 UAT exceptions are
  ratified; P14 follows P10 rather than diverging from its sibling. P14 renders them from
  the supplemental subset only (face ¶3(c): "the liabilities that charge or encumber that
  property").
- **The empty-inventory fabricated $0.00 is fixed in the shared helper, covering P10 as
  well as P14.**

### Verified facts (re-checked by render, 2026-07-16)

- Body wording follows the face, subject to the standing rulings that override it
  (capitalized (the "Deceased") per AUTOFMT-6; the sibling oath idiom; spaced citations).
  It is therefore **face-conformant, not "face-verbatim"**.
- The preamble renders the face's occupation slot as a blank when unrecorded; collapsing
  the slot silently dropped a face element.
  **2026-08-21 goal-loop extension (P3 audit finding 3):** this blank-slot doctrine now
  applies FAMILY-WIDE — P3/P4/P5/P6/P7/P8/P9/P10 (DOCX + preview mirrors) render
  `, ____________________,` when the occupation is unrecorded, superseding the older
  todo.md:1550 P9 omit-the-placeholder directive. Directed by Nick's 2026-08-21 goal-loop
  (resolve the P3 DO-NOT-SHIP findings end to end); pending his formal ratification of
  this Rule 7 record as a whole.
- `ownershipDetails` (registered owners / fractional interests) now renders on P14. It was
  gated on `p10Ex` and silently discarded, while the `p14_real_property_ownership_details`
  preflight row forced the user to record it — the render threw away data the gate
  demanded.
- **Format freeze HELD across the sweep.** An independent census of the 27 `docgen.ts`
  hunks found 11 wording, 16 logic, **0 geometry** edits. A reviewer's "pagination
  changed" and "preview rebuilt" findings were both refuted: the pagination shift is
  face-required longer wording reflowing (not a geometry edit), and the preview rewrite is
  the required DOCX mirror — the pre-sweep preview contained a fabricated jurat line, no
  preamble, and no Exhibit A at all.

### Open — NOT ruled, do not treat as settled

- ~~Whether the Exhibit A commissioner stamp should print the face's combined
  "sworn/affirmed" or keep the data-selected word under the sibling oath idiom.~~
  **RULED — see Rule 8.** Keeps the data-selected word, defaulting to "affirmed".
- ~~Whether the dialog's "Affirmed" display default should reconcile with the render's
  blank-oath "SWEAR".~~ **RULED — see Rule 8.** The render now matches the dialog.
- ~~P11 provenance is weaker than P14's: `archiveP11Document` writes no deponent identity,
  and `generatePackage` never persists P11 at all.~~ **RULED — see Rule 16 (2026-08-04).**
  `archiveP11Document` is deleted and every route (generate, download, package)
  persists P11 with the full deponent/signature-date snapshot.

---

## Rule 8: Oath Default and Deponent Choice (MANDATORY — Nick, 2026-07-16)

### 8a. The oath default is AFFIRMED, with the option to choose sworn

Nick, verbatim: *"my rule is the default is affirmed with option to choose sworn."*
This **supersedes Rule 3's sibling idiom** (blank → `SWEAR`), under which a blank
`oathType` rendered SWEAR while `FormDetailsDialog` displayed "Affirmed" — the
document contradicted the UI. That was the defect, not the dialog.

- **Blank/unset/`"affirmed"` → `AFFIRM` / `affirmed`. Only an explicit `"sworn"` →
  `SWEAR` / `sworn`.** The DB default is already `affirmed` (migration 0079).
- **One resolver: `oathWords(oathType)` in `server/docgen.ts`**, returning
  `{ verb, participle, participleUpper }`. All 36 previously-inlined
  `(e.oathType === "affirmed") ? … : …` ternaries route through it — P3, P4, P5,
  P6, P7, P8, P9, P10, P11, P14, P15, P26 across both the DOCX builders and the
  `buildPreviewSections` mirrors. New oath sites MUST call it; a new inline
  ternary is a bug.
- **The Exhibit A commissioner stamp follows the same default.**
  `exhibitStampBlock()` (+ its preview mirror), serving P10/P11/P14/P15/P26,
  prints the data-selected participle. It does **not** print the face's combined
  "sworn/affirmed": Nick ruled a default with an option, not a hand-selected blank.
- **The neutral faces are untouched and never branch on `oathType`:** the shared
  `jurat()` ("SWORN (OR AFFIRMED) BEFORE ME"), P12 (translator) and P34 (citor).
  P13 has no oath at all (Rule 6).

### 8b. The deponent stays choosable — lawyer, applicant or executor
**(SUPERSEDED IN PART by Rule 15 (Nick-directed, 2026-08-04) for P3–P7, and — subject
to ratification — by Rule 18 (2026-08-04, UNRATIFIED, awaiting Nick) for
P10/P11/P14/P15/P26: those faces now reject the settings-lawyer sentinel, an unknown
id, and every non-applying deponent. The broader factual-witness choice remains for
P9/P16/P45 and dedicated-deponent forms.)**

Nick, verbatim: *"The deponent should be choosable like it already was, when
clicking a form you can choose lawyer, applicant or executor"* and *"the lawyer
can apply for the applicant or on behalf of them that is normal keep it chosable."*

- ~~An **applicants-only guard is struck.** `assertApplicantsOnlyDeponent` (which
  hard-blocked a lawyer deponent on P11/P14 with a 400) is removed;
  `resolveGeneratedAffidavitDeponent` no longer rejects any deponent. P14's
  `FormDetailsDialog` entry returns to the sibling `AFFIDAVIT_FIELDS` pool.~~
  *(Nick's recorded 2026-07-16 text, restored 2026-08-05.)* Rule 18 (UNRATIFIED)
  reinstates the legal restriction through the shared `APPLICANT_DEPONENT_FORMS`
  set, the dialog's `APPLICANT_AFFIDAVIT_FIELDS`, the common resolver, and a
  renderer-level defence for both DOCX and preview.
- **Preserved from the same arc** (removing the restriction must not undo these):
  the deponent is resolved **before** `generateForm` on every render path, so a
  refused deponent never reaches a rendered sworn statement; P14 writes its
  `documents` row on **every** path (`downloadRoute.ts`, `quickDownload`,
  `generatePackage`) via `PERSISTED_AFFIDAVIT_FORMS`; and chosen == rendered ==
  persisted, because docgen's `applicant()` and `resolveGeneratedAffidavitDeponent`
  pick by the identical rule.
- **Dedicated deponents are unaffected** — the guard was never theirs: P12
  (translator), P13 (PGT, `PGT_SIGNED_FORMS`, `signatoryType="pgt"`), P34 (citor),
  P46 (demandant) keep their current behaviour.

### 8c. Lawyer-deponent literal falsity — RESOLVED (Nick, 2026-07-22): Option C — superseded in part by Rule 15 (Nick-directed) and Rule 18 (2026-08-04, UNRATIFIED — awaiting Nick)

The Rule 8 "Open" item is **resolved**. On estate #15, P4 defaulted its deponent to
the lawyer and then swore, first-person, *"I am the applicant referred to in the
submission…"* and *"I am named as an executor… as [LAWYER] in the will"* — a factually
false sworn document. Confirmed from SCCR **Appendix A.1** (Rule **25-3 (2)**) + WESA
(local captures; vault capture identical): for an **individual** applicant, P3/P4/P5/P6/
P7/P10/P11/P14/P15 require the **applicant** to swear in the first person; the face has
**no** on-behalf/solicitor variant. The only *"swear on behalf … as applicant"* clause is
for a **non-individual (organization)** applicant, sworn by its authorized officer — not a
solicitor. WESA authorizes no lawyer-as-deponent substitute (only the s.15 notice
*certification* and the s.77 wills-search). So **adding a solicitor variant is foreclosed**
(Rule 1 + adr-no-fabricated-sworn-facts).

**Nick's ruling — Option C (fix the silent default; keep the lawyer selectable; warn):**
*(Ledger restoration 2026-08-05: commit `7001ea1` had rewritten this ruling text in
place, against the annotate-don't-rewrite convention. Nick's recorded ruling is
restored below; the bullets Rule 18 would supersede are struck WITH the original
text preserved. Rule 18 is UNRATIFIED — if Nick reverts it, the struck text is the
operative ruling again.)*
- **Applicant-sworn affidavits no longer DEFAULT to the lawyer.** `LAWYER_DEPONENT_FORMS`
  (moved to `@shared/const`, the single source consumed by the router seeding **and**
  `FormDetailsDialog`) shrinks from `["P3","P4","P5","P6","P7","P9","P10"]` to **`["P9"]`**.
  P9 (Affidavit of Delivery) legitimately defaults to the lawyer (a lawyer commonly swears
  delivery, WESA s.15). Every applicant-sworn form now defaults to the **primary applicant**
  on every render path (generate / preview / quickDownload / generatePackage /
  `/api/download/form`) via docgen's **unchanged** `applicant()` → `findPrimaryApplicant`.
- ~~**The lawyer stays SELECTABLE — Rule 8b holds** ("keep it chosable"). The dialog still
  offers the lawyer; an explicit lawyer selection still renders + persists the lawyer,
  byte-identical to before. Only the *default* changed, not choosability.~~
  **Superseded by Rule 18 (UNRATIFIED — awaiting Nick):** P3–P7/P10/P11/P14/P15/P26 now use
  an applying-applicant-only picker; a crafted explicit selection is rejected before render
  or persistence (docgen repeats the guard for DOCX and preview). P9/P16/P45 retain the
  factual-witness choice because their faces do not say the deponent is an applicant.
- ~~**A deliberate lawyer choice is WARNED (warn-only, per Rule 9).** When a lawyer is
  selected to swear an applicant-sworn affidavit, `FormDetailsDialog` shows an inline
  warning (*"A lawyer cannot swear 'I am the applicant.' … review before swearing or
  filing"*); Generate/Preview stays enabled. Excludes P9 and a deponent who is also an
  applying applicant/executor (they may lawfully swear).~~
  **Superseded by Rule 18 (UNRATIFIED):** the warn-only UI is removed; invalid
  applicant-affidavit identities produce a hard, source-aligned preflight/render error.
- **No sworn wording invented or changed.** `applicant()`, every builder, every jurat, and
  all official face wording are untouched (Rule 1 + FORMAT FREEZE intact). Populated P1–P14
  snapshots stay byte-identical for explicit-selection contexts. *(2026-08-05 note: read
  as VALID selections — under unratified Rule 18 a lawyer selection errors instead of
  rendering, so it is no longer such a context; sentence preserved verbatim.)*
- **P8 ripple fixed for free.** P8 ¶2 quotes the primary affidavit's deponent; with P3/P4/P5
  no longer defaulting to the lawyer, P8 references the applicant by default.
- **Dedicated deponents unaffected:** P9 (delivery), P12 (translator), P13 (PGT), P34
  (citor), P46 (demandant).

### Still open (latent, pre-existing)

- **P11 dialog vs server asymmetry.** P11's `FormDetailsDialog` entry keeps its
  pre-existing (committed, Rule 3) `applicantsOnly: true` pool, while the server
  accepts any deponent for P11. `p11Applicant()` in docgen ignores a non-applying selection
  and falls back to the primary applicant, so a lawyer forced onto P11 by a non-UI caller
  would be *persisted* as the lawyer but *sworn* as the applicant. Latent, pre-existing,
  unreachable from the UI; the 8c default-fix does not touch it.

---

## Rule 9: Cross-Form Affidavit-History Prerequisites Are Warn-Only (MANDATORY — Nick, 2026-07-22)

**P9 update (2026-09-06):** Addendum 24.9 supersedes the soft
`p9_at_least_one_delivery` row below for an EMPTY P9 delivery oath only: single
generation, preview, direct download and package return an actionable error
until at least one actual recipient, delivery date and prescribed method is
saved, including after Generate Anyway. `p9_all_required_recipients_resolved`,
the `p2_*` rows and `p8_primary_affidavit_history` (as narrowed by Addendum
24.8) stay soft. The P8 "ambiguous history" hard guard listed below is now a
visible 400 on preflight, single-form generate, preview and direct download;
Generate All P8 and the grant package still throw the same message (relayed
to the client as the error text, not as a 400).

Nick, verbatim: *"I do not want it blocking people from generating anything. It
should only warn them."*

A form that references **another form's completed affidavit history** (P2 → the
filed Form P9 affidavits of delivery; P8 → the primary applicant's P3/P4/P5/P6/P7
affidavit) **no longer fails closed** when that history is missing or incomplete.
This **supersedes the 2026-07-13 fail-closed P2 clause** (adr-p2-official-face-data-model:
*"Missing or incomplete retained P9 history fails closed when notice recipients
exist"*) and the equivalent P8 missing-history throw.

- **Render an honest blank draft, never a throw.** When the retained history is
  absent, the referencing section prints the standard blank fill to hand-complete:
  P2 §2 prints `Affidavit of ____________________ sworn ____________________`;
  P8 ¶2 prints `I have read the affidavit in Form ____ sworn ____________________
  by ____________________`. Fills are **per-field**: each recorded field prints and
  only the absent field blanks (P8 mirrors P2 — a retained affidavit with a real
  form/name but no sworn date prints the form/name and blanks only the date), never
  all-or-nothing and never a synthesized value. The `assertP2P9AffidavitHistory`
  guard is removed; the P8 missing-history throws are removed.
- **Never synthesize the missing data** (adr-no-fabricated-sworn-facts rule 1). The
  blank is a blank — the current dialog deponent/date/form are never substituted for
  the absent P9/primary facts. When the history **is** present, output is unchanged
  (byte-identical; the populated P1–P14 snapshots hold).
- **The preflight warning is the pressure, not a block.** `p2_p9_affidavit_history`,
  `p2_notice_recipients_resolved`, `p9_at_least_one_delivery`,
  `p9_all_required_recipients_resolved`, and `p8_primary_affidavit_history` remain
  **soft** gaps in `PreGenerateDialog` — Proceed / "Generate anyway" / "Preview anyway"
  stays enabled, and the labels now name the prerequisite, the consequence, and the
  Deliveries card. This makes the dialog's standing promise ("missing fields will
  render as blank lines or defaults") true for these prerequisites.
- **Deliveries are never auto-filled.** An empty `deliveries` table still yields an
  empty Form P9 delivery section — the C-02 anti-fabrication deletion stands
  (adr-no-fabricated-sworn-facts). The user records deliveries; the app only warns.
- **Genuinely different guards stay HARD** (these are "cannot render correctly," not
  "blank a missing fill"): P8 **ambiguous** primary history (two conflicting
  affidavits cannot be honestly blanked), P8 **no applying co-applicant** (Rule
  25-3(2)(c)) and **invalid explicit deponent**, P3/P4 **grant type not selected**,
  and P4 §6(c.1)/(c.2) **validity** throws.
- **Legal note (draft, not oath).** P2 §2's checked ☒ box sits above the (possibly
  blank) affidavit list on the official face; leaving the list blank is the normal
  incomplete-draft state a lawyer completes before swearing — the app-wide
  "render blanks + warn + review before swearing or filing" model. The blank draft
  is **not** a sworn false statement; it must not be sworn until the P9s exist.

---

## Rule 10: Grant/Will Mismatch Is Warn-Only; Applicability Keys on Grant Type; No-Applicant Deponent Renders Blank (MANDATORY — Nick, 2026-07-22)

Reported on intestacy estate #17 (`{ grantType: admin_no_will, hasWill: 1, no applying
applicant/executor }`): P5 showed under **REQUIRED** yet its preview hard-blocked with
*"not applicable — grant type conflicts … Missing: estate.grantType, estate.hasWill."*
Root cause: the grant-type↔will-answer consistency rule lived in **two places that
disagreed** — `formStatus()` (the single source; keys P5 on grant type only → `required`)
and a FORKED `grantWillConflict` hard block in `checkPreflightWithApplicability`
(`server/routers.ts`) that read raw `hasWill` and blocked. `hasWill=1` is the DB default
(`drizzle/schema.ts:228`, `int().notNull().default(1)` — no "unanswered" state) that a
user never flipped after choosing an intestacy grant type. Legal (SCCR Appendix A.1 Rule
25-3(2); WESA Part 3 / s.130): P5 IS the correct required affidavit for an intestacy
grant; P5 is genuinely *not applicable* only when a will **exists** (¶5 "there is no will"
would be false), and an unrecorded will/no-will answer is *missing data*, not
inapplicability.

### 10a. A grant-type ↔ will-answer MISMATCH is WARN-ONLY (supersedes the "Arc-D" `!hasWill` block)
- **Applicability keys on grant type ALONE.** `formStatus()` P3/P4 na guards changed from
  `if (isIntestacy || !hasWill)` to `if (isIntestacy)` (`shared/types.ts` ~2491/2503); P5
  already ignored `hasWill`. A grant-type↔`hasWill` contradiction — **both** directions
  (will-based grant + `hasWill=0`, OR `admin_no_will` + `hasWill=1`) — is now a **SOFT**
  gap in `checkPreflightWithApplicability` (`server/routers.ts`), never a hard block:
  Proceed / "Preview anyway" / "Generate anyway" stay enabled and the form renders an
  honest blank draft. The `grantWillConflict` hard `return` is replaced by a soft `report`
  append; the label names the real cause + fix and no longer prints "Missing:" for
  set-but-contradictory fields (Rule 9 style). Nick's standing philosophy (Rule 9,
  verbatim): *"I do not want it blocking people from generating anything. It should only
  warn them."*
- **The package builder must not fork.** `primaryApplicantAffidavitForm` (`shared/types.ts`
  ~2725) drops its mirror `if (!estate.hasWill) return ""` guard so it proposes the
  grant-type-authoritative affidavit (P3/P4 for a will-based grant regardless of `hasWill`)
  and never diverges from `formStatus` (adr-formstatus-single-source-of-truth). The estate
  readiness panel's existing `grant_type_mismatch` "fail" (`shared/types.ts` ~1020) is
  unchanged — the contradiction stays visible there too.

### 10b. Genuine inapplicability stays a HARD block (Rule 3 two-tier intact)
- A form that legally cannot be this form keeps the greyed **"Blocked"**: P3/P4/P5 on a
  will-based/ancillary grant type (`formStatus` `na`), P10-vs-P11 exclusivity, resealing.
  Only the FALSE P5 block (the 10a mismatch) is removed. `checkPreflightWithApplicability`
  still defers to `formStatus()` for the `na` hard block and keeps the
  `grantType === "unknown"` intake gate.
- **P2's ancillary-filing render gate is now mirrored into the preflight.** The same
  resolver P2 rendering calls (`ancillaryFilingAttachmentSpecs`,
  `server/documentAssets.ts`) is invoked in `checkPreflightWithApplicability`; when it
  would throw for an ancillary estate missing/uncertified foreign-grant data, the preflight
  emits a HARD `p2_ancillary_filing_attachments` gap so the dialog shows "Blocked" with the
  real reason instead of offering "Preview anyway" and then crashing at render. One source
  (documentAssets), no fork. (#17 itself is non-ancillary; its P2 "preview anyway then
  error" was the STALE pre-Rule-9 symptom — `assertP2P9AffidavitHistory` is already gone.)

### 10c. No-applicant deponent renders blank + warns (Rule 8c holds)
- When an applicant-sworn form has **no applying applicant/executor** (only the Settings
  lawyer), `FormDetailsDialog` shows the honest *"No applying applicant/executor recorded
  … it renders blank until you add one in Contacts"* note and does **NOT** display the
  lawyer as the deponent — the `candidates` pool excludes the sole lawyer for
  non-`prefersLawyer` applicant-sworn forms when `pool.applicants` is empty
  (`client/src/components/FormDetailsDialog.tsx`). The server already renders blank (docgen
  `applicant()` → `findPrimaryApplicant`, no fallback to the lawyer for P5), so **no lawyer
  is ever silently sworn as the applicant** (Rule 8c holds). ~~The lawyer stays selectable +
  warned when real applicants exist (Rule 8b).~~ **SUPERSEDED for P3–P7 by Rule 15
  (Nick-directed, 2026-08-04) and — subject to ratification — for the remaining
  applicant-face affidavits by Rule 18 (UNRATIFIED): the lawyer is removed through
  `APPLICANT_AFFIDAVIT_FIELDS` and hard-rejected server-side. The blank-draft
  clause above is unchanged.**

Locked by regression tests: `formStatus("P5")` = `required` for `{admin_no_will,
hasWill:1}` and exactly one of P3/P4 = `required` for `{probate, hasWill:0}`
(`shared/formStatus.test.ts`); package builder ↔ formStatus agreement
(`shared/grantpackage-haswill.test.ts`); P5 preflight not hard-blocked, carrying a soft
`p5_grant_will_consistency` gap, and P2 ancillary preflight hard-blocked with
`p2_ancillary_filing_attachments` (`server/routers.preflight.test.ts`); the no-applicant
P5 deponent shows the blank note and swears nobody
(`client/src/components/FormDetailsDialog.test.tsx`). Gates green: `pnpm check`,
`pnpm test` (2010), `pnpm build`.

---

## Rule 11: Will-Confirmation Defaults — Require an Explicit Answer; No Fabricated P2 §5 Orders Negative (MANDATORY — Nick, 2026-07-22)

Reported on a will file whose Intake "Will" questions LOOKED answered, yet Form P4 (long-form
applicant affidavit) still flagged four Rule 25-3(6)/(18) confirmations as unconfirmed
(`special_circumstances_unconfirmed`, `wesa_s58_unconfirmed`, `orders_affecting_will_unconfirmed`,
`military_will_unconfirmed`). Root cause verified end to end: **displayed-but-never-persisted
defaults.** Each will column defaults to `""` in `drizzle/schema.ts` and `estate.create` seeds `""`
on purpose (`server/routers.ts:1198-1211`, *"Empty means unrecorded; no negative/clean answer is
inferred for a new file"*). The Intake controls only write on an active `onChange` click, and
autosave diffs `form` vs `estate` (`client/src/pages/EstateDetail.tsx:811`), so an untouched control
leaves the value `""`. `shouldUseP4()` (`shared/types.ts:1788`) correctly treats `""` as unconfirmed,
and the four `p4_rule_25_3_6_*` requirement rows are DERIVED from it
(`shared/formRequirements.ts:309-327`) so the gate and the rows can never disagree. Only ONE field
actually "looked answered": `ordersAffectingWill`, rendered through the shared `triField` helper
(`EstateDetail.tsx:966`) which painted `value={form[key] || "no"}` — a phantom "No" that was never
saved; the other three render visibly empty. Separately, **P2 §5 already SWORE the negative on that
same blank value**, a live self-contradiction with the P4 gate.

### Nick's ruling (via AskUserQuestion, 2026-07-22)

- **A — REQUIRE AN EXPLICIT ANSWER.** The gate is correct and stays the single source of truth
  (`shouldUseP4`/`formStatus`/`formRequirements` **UNTOUCHED**; adr-formstatus-single-source-of-truth).
  A blank is never treated as a sworn confirmation (adr-no-fabricated-sworn-facts; Rule 9/10; the
  in-code *"a blank must not swear a defaulted negative — force an explicit answer"* comments at
  `shared/formRequirements.ts:969-971`/`1421-1423`). **No schema, seeding, or migration change** —
  `""` = unrecorded stands. The fix is UI honesty: `triField` now passes `value={form[key] || ""}`
  (`client/src/pages/EstateDetail.tsx:966`), so an unrecorded control highlights nothing until the
  user answers. Verified zero blast radius: every other `triField`-fed field carries a non-empty
  schema default, so `ordersAffectingWill` (schema default `""`) is the only display that changes
  (phantom "No" → honest blank). No value ever changes on disk.
- **B — TIGHTEN P2 §5.** P2 §5 no longer swears *"…there are no orders affecting the validity or
  content of the will referred to in section 4."* on a blank `ordersAffectingWill`. Only an explicit
  `"no"`/`"na"` renders the CHECKED (☒) negative; a blank renders the option UNCHECKED (☐) for
  hand-completion — the established repo anti-fabrication idiom (cf. P2 §4 `willFilingType`, P2 §6
  `referencedDocuments`). Both surfaces: DOCX `buildP2` §5 (`server/docgen.ts` ~1249-1255) and preview
  `buildPreviewSections` §5 (`server/docgen.ts` ~5352-5358). Wording verbatim; geometry unchanged
  (checkbox glyph only) — FORMAT FREEZE held. Official face: SCCR Appendix A.1 **Rule 25-3(2) Form P2
  §5** (*"Check the box for whichever one of the immediately following section 5's is correct"* — the
  negative is an affirmative sworn assertion, so a blank must not adopt it).
- **C — ALL SAME-SHAPE FIELDS.** An exhaustive docgen audit of every same-shape will field
  (`executionIssues`, `foreignWillStatus`, `willAppearanceIssues`, `willAlterations`,
  `willDocumentsAttached`, `otherGrantsStatus`, `testamentaryDocStatus`, `willFilingType`,
  `vsaCertificateResult`, `beliefLastBcWill`, `referencedDocuments`) confirmed `ordersAffectingWill`
  (P2 §5) was the ONLY field that swore a negative on blank. All others already gate the negative on
  an explicit clean literal (blank omits/collapses the section), print an explicit ☐ on blank
  (`referencedDocuments` P2+P4, P2 `willFilingType`), fail closed with a throw (`otherGrantsStatus`
  → `unknown`), or have no render surface (`willAppearanceIssues`, `willDocumentsAttached`,
  `beliefLastBcWill`). The P4 ¶6 execution lead box COLLAPSES on a blank `executionIssues` (never
  swears "no issues"). No further docgen fix required.
- **D — WESA s.58 GATE-ONLY.** `wesaS58Reliance` has no P2/P4 render surface and none was added:
  WESA **s.58** is the court's curative ORDER, sought on a petition (Form P43, WESA s.58(2)-(3)), not
  an applicant self-sworn P2/P4 confirmation. It stays a preflight/applicability field only
  (`shared/types.ts:1256-1262`, `1866-1870`).

The military-will box (P4 ¶6(b), WESA **s.38** / Rule 25-3(17)) and the special-circumstances box
(P4 ¶6(c), Rule 25-3(18)) already print their negatives only on explicit `"no"`/`"none"` — no change
(already compliant per adr-no-fabricated-sworn-facts). *(Citation note: the local
`references/SupremeCourtCivilRules.md` capture holds the forms but not the numbered Rule 25-3
subrules; the 25-3(18)-vs-(6) special-circumstances cite is the pre-existing code's and was not
changed — validate against the vault BC Laws capture before any future wording edit.)*

Locked by regression tests: `server/docgen.referenced-documents.test.ts` — P2 §5 blank
`ordersAffectingWill` renders ☐ on both DOCX and preview, explicit `"no"`/`"na"` renders ☒;
`client/src/components/TriToggle.test.tsx` — `value=""` highlights no option, `value="no"` highlights
only "No". The gate suites (`server/p3-fail-closed.test.ts`, `shared/formStatus.test.ts`,
`shared/formRequirements.test.ts`) stay green **UNCHANGED** — the gate was not touched. Populated
P1–P14 DOCX snapshots byte-identical (every fixture uses an explicit `ordersAffectingWill`). Gates:
`pnpm check`, `pnpm test`, `pnpm build`.

---

## Rule 12: P15+ Audit-Clear Rulings (MANDATORY — Nick, 2026-07-26)

The 24-finding DO-NOT-SHIP audit (`audits/2026-07-22-p15-plus-current-code-issue-tracker`,
snapshot `1e5f2c0`) was validated finding-by-finding (0 refuted) and resolved end-to-end.
Nick ruled every decision-shaped item (AskUserQuestion, 12 questions, 2026-07-26):

- **Four new docgen format-freeze exceptions APPROVED** (joining P11/UAT-trio/P12/P34/P13):
  **(a) P15/P26 continuous Exhibit A** (P15PLUS-001) — one continuous three-column face
  table (P11 idiom: standalone `Exhibit A` caption, shaded 80/20 part headings, italic
  instruction rows, 55/25/20 asset rows, colspan TOTAL/spacer/GROSS rows), scoped to
  P15/P26; P10/P14 geometry untouched (byte-identical); the ratified LIABILITIES/SUMMARY
  supplements stay after the face table; part TOTALs are net of listed secured debts per
  the face's own example. **(b) P45 ¶4–6 REMOVED** (P15PLUS-005, resolves FLAG-1) — the
  face carries only the chosen confirmation statement + jurat; Rule 25-3(3)(a.1)(iv)(D)
  repository-access info stays recorded APPLICATION material (intake fields +
  `p4_repository_details`), never sworn P45 text. **(c) P17 completed to the face**
  (P15PLUS-007) — renouncer `[type or print name]` fill, witnessed-acknowledgement block
  (age instruction verbatim; witness fields are blank fills, NEVER synthesized), and the
  optional `and trustee` gated on the new per-contact `contacts.appointedTrustee`
  (migration 0104; the estate-level phantom stays ignored). **(d) P17 multi-renouncer =
  one complete form per renouncer** (P15PLUS-023) — page breaks between notices; the
  face-external Unicode separator is gone.
- **P19 grant clause = STRICT FACE TEXT** (P15PLUS-009): no code-added period, no trailer —
  formally supersedes the `58e5dd1` trailer (adr-printed-headers-official-face updated).
- **Jurat oath-city chain** (P15PLUS-012): explicit `domicileCity` → **the firm's city from
  Settings** (new structured `settings.firmCity`, migration 0098) → blank fill, on ALL
  applicant-sworn affidavits (P3/P4/P5/P6/P7/P8/P9/P10/P14/P15/P16/P26/P45) *(Nick's
  recorded phrasing, restored 2026-08-05; the parenthesized list is the operative set)*. The deceased's
  `addressCity` is NEVER an oath city. Carve-outs unchanged: P11 explicit juratCity;
  P12/P34 blank (Rules 4/5). P17's "formerly of" city is the DECEASED's residence and
  deliberately keeps the address fallback.
- **Header trailing space = SPACED (face form) on BOTH surfaces** (P15PLUS-016): the
  preview `addStyleOfCause` prints the DOCX string (`Form X (Rule … )`); resolves the
  Rules 3/6 reserved series-wide question; all-form parity test locks it.
- **Rule 25-3(9) supplements key on the FILED originating affidavit** (P15PLUS-011, both
  lineages): recorded `p11FiledDate` keeps P15 available (and `p10FiledDate` keeps P14)
  regardless of later eligibility drift; `p11_filed_eligibility_conflict` stays as the
  drift warning. Closes the in-code AWAITING-NICK.
- **P26 is gated on the recorded Form P25 filing** (P15PLUS-002): new `estates.p25FiledDate`
  (migration 0099) — grant type alone never unlocks the "has been filed" sworn sentence
  (the P15↔p11FiledDate pattern).
- **P16 route + presence model** (P15PLUS-003/004, migration 0101): `willAlterationRoute`
  ("" = unchosen → P16 stays required fail-safe; `p16_affidavit` required;
  `other_affidavit`/`evidence`/`effaced` → conditional, never forced) and
  `p16DeponentPresentAtSigning` (soft `p16_presence_confirmed` row + FormDetailsDialog
  warn, Rule 8c style; ¶2 face wording untouched).
- **P45 derives STRICTLY from affirmative Rule 25-3(3)(a.1)(iii)/(iv) facts** (P15PLUS-006,
  migration 0102): three axis columns (`electronicWillOriginalAvailable` /
  `electronicWillFirstSavedPdf` / `electronicWillInRepository`); `original_unavailable`
  records ONLY the (a.1)(i) availability axis and never mandates P45; unanswered axes →
  conditional + readiness prompt (no fabricated requirement); the legacy
  `electronicWillFormat` token is DERIVED ((iv)→(iii)→(ii)→(i) precedence) and keeps
  driving P4 §6(c.1)'s Arc-D sworn branches unchanged.
- **P19 order clauses are two independent facts** (P15PLUS-010, migration 0100):
  `p19WillReadWithOrder` / `p19IssuedPursuantToOrder`; `ordersAffectingWill` keeps ONLY
  its P2 §5 / P4 role (Rule 11 untouched).
- **P44** (P15PLUS-013/015/020/021): the printed pool is the canonical
  `applyingApplicantContacts()` (no role prefilter — an applying administrator-only
  contact prints; same fix on P19's grantee pool, P15PLUS-014); the missing-application
  state is a soft `p44_application_filed` warn (Rule 10 style — never a DB-default hard
  block); the face's `[type or print name]` fill prints as the literal blank (unchecked
  role boxes assert nothing); Rule 25-3.2(1) delivery-to-every-entitled-person is tracked
  per recipient on the delivery rows (`p44DeliveryDate/Method`, migration 0103, P46
  column precedent + `delivery.markP44`) with readiness zero→silent / partial→warn /
  complete→pass.
- Clean fixes with no ruling needed: P34 single matter line + centred title + expanded
  preview jurat (P15PLUS-008/018 — implementing the standing Rule 5); P16's post-jurat
  WESA-definition note verbatim (P15PLUS-019); P19 always prints ", also known as" + the
  blank fill (P15PLUS-022); all liability sums share `probateItemValue()` (P15PLUS-017);
  P46 preview prints the exact 42-underscore signature rule (P15PLUS-024).

- **2026-07-26 post-review amendment (Nick):** `domicileCity` is the OATH city ONLY —
  everywhere. The P17 "formerly of" slot prints the new `estates.deceasedResidenceCity`
  (migration 0105), falling back to `addressCity`; `domicileCity` never prints as a
  residence (this makes the P15PLUS-012 carve-out precise — the fallback the carve-out
  kept is `addressCity`, not `domicileCity`). VSA532's Section A applicant City drops its
  `domicileCity` fallback (applicant `residenceCity` or the blank fill). The estate-level
  `p16DeponentPresentAtSigning` scalar is the ACCEPTED granularity for the P16 presence
  fact — the FormDetailsDialog warn covers deponent switches; no per-deponent split.

Migrations **0098–0105** ride this arc (firmCity; p25FiledDate; P19 clause facts; P16
route/presence; electronic-will axes; P44 delivery tracking; appointedTrustee;
deceasedResidenceCity) — apply to live TiDB in numeric order after 0092–0097.

---

## Rule 13: Generated-Form Checkbox Alignment (MANDATORY — Nick, 2026-07-29)

Every checkbox rendered into a generated **DOCX form** must use the shared checkbox
geometry in `server/docgen.ts`. Directly constructing a `☒`/`☐` text run inside a
form builder is prohibited.

- The universal checkbox marker area occupies **480–960 twips**. A fixed **240-twip
  gutter** follows it, and the universal text column begins at **1200 twips**.
- A numbered checkbox row uses fixed number / checkbox / gutter / text columns at
  **0 / 480 / 960 / 1200 twips**. The number and checkbox may never drift because of
  automatic tab-stop division or the width of preceding content.
- Standalone checkbox rows use the same marker area and gutter. Their text starts at
  **1200 twips**. The first line and every continuation line must begin at this exact
  text column; no later change may reintroduce hanging-indent drift.
- ~~**Unticked DOCX boxes are hidden** as native vanished text.~~ **SUPERSEDED by
  Rule 25 (Nick, 2026-09-07):** an unchecked alternative is not printed at all when a
  sibling alternative is checked; an unchecked box that DOES print (nothing recorded in
  its group) must be a VISIBLE `☐` so it can be completed by hand. Vanished glyphs left
  orphaned text with no box and are prohibited.
- **No hierarchy exception is permitted.** Numbered, subordinate, nested, and
  unnumbered checkbox rows must all use the same fixed marker area, gutter, and
  1200-twip text column. Ad hoc per-form offsets and direct glyph paragraphs are
  prohibited.
- Checkbox size, weight, hidden-marker behavior, fixed-grid cells, and row spacing
  are controlled centrally. This rule applies to **all current and future generated
  forms**, not only the form on which a defect was first observed.
- Plain-text/HTML preview glyphs are outside Word-layout geometry, but their checked
  state and wording must continue to match the generated DOCX.

Locked by regression tests: `server/docgen-checkbox-rule.test.ts` rejects any direct
DOCX checkbox-glyph run before the preview builder and pins the shared fixed columns
and the group helper; `server/docgen.test.ts` sweeps all supported forms to
protect the uniform text-column geometry and exact legal text;
`server/docgen-checkbox-group.test.ts` locks Rule 25.

---

## Rule 14: Rule 25-2 Delivery Material Is Warn-Only (MANDATORY — Nick, 2026-07-30)

Nick, verbatim: *"do not block if there is no will attached. its fine they can
attach it after"*

**No missing Rule 25-2(1.1) delivery material may block generation of Form P1.**
This covers the copy of the **will** and the copy of any **codicil**, at every P1
surface: individual generation, preview, quick download, direct download, and the
grant package. This ratifies the 2026-07-29 relaxation of the P1 will-upload throw
(`5a93a65`) and extends it to codicils.

**The foreign grant is NOT within this rule.** An ancillary/resealing application
with no uploaded foreign grant still throws — see "Genuinely different guards"
below. Those are precisely the grant types that require a foreign-grant copy, so
including it here would contradict that bullet.

- **WESA s.1 makes a codicil part of the will.** *"'will' means (a) a will, (b) a
  testament, (c) a codicil…"*. SCCR Rule 25-1 (2) imports the WESA definitions into
  the whole of Part 25 (Rule 25-3 (1)'s narrower definition is expressly scoped
  *"In this rule"* and does not reach Rule 25-2). The official Form P1 face carries
  the same instruction: *"Note that a reference to 'will' includes all documents
  that are included within the definition of 'will' in the Wills, Estates and
  Succession Act."* A recorded codicil is therefore the **same class of delivery
  material as the will**, and must be treated identically — a codicil throw beside
  a warn-only will is prohibited.
- **Attach what exists; omit what does not.** `p1NoticeAttachmentSpecs()` returns
  the available set. A count shortfall (`codicilCount` exceeds uploads), an entry with no
  stored file, and an unreadable `codicilFiles` list are all **preflight warnings**,
  never throws. Omitted codicils keep their **recorded position** in the package
  name (`Codicil_2.pdf`), so the package never implies a surviving file is codicil 1
  when it is the second recorded one.
- **The preflight warning is the pressure, not a block.** `p1_will_copy_upload` and
  `p1_codicil_uploads` are soft gaps; Proceed stays enabled and generation succeeds.
  The Intake Tab notice names the recorded count and where to fix it.
  `p1_foreign_grant_upload` is *also* a soft preflight row, but that is a warning
  ahead of a hard stop, not a warn-only outcome — Proceed is enabled and the
  resolver then throws. Do not read its row kind as bringing it under this rule.
- **Draft, not delivery (the Rule 9 "draft, not oath" precedent).** The official P1
  face has only four mutually exclusive boxes, and the one naming the will also
  states *"a copy of which will is provided with this notice."* The form provides no
  fourth state for "relates to a physical will, enclosure incomplete." Nick's ruling
  resolves this: **the generated DOCX is a draft, not the delivered notice.** The
  copy rides with the notice when it is actually delivered, so the checked box
  describes the delivered package. It follows that Rule 25-2 (2.1) — which starts
  the 21-day clock on delivery of *"the notice and other applicable materials
  referred to in subrule (1.1)"* — runs from that delivery, not from generation, and
  is not put at risk by generating an incomplete draft.
- **Genuinely different guards stay HARD.** These are "the attachment set cannot be
  resolved," not "material is missing": an ancillary/resealing application with **no
  foreign grant uploaded** (nothing to give notice with), and **no recorded answer**
  on whether the will forms part of the foreign grant (the set itself is
  unknowable). Both still throw.
- **A stored file that cannot be fetched also stays HARD, and this is not an
  exception to the rule.** `fetchAttachment()` throws when a spec's storage object
  is missing or unreadable, and no P1 surface swallows it. That is a *storage
  error*, not missing delivery material: the app holds a `storageKey` and therefore
  believes the document is enclosed, so silently omitting it would ship a package
  short of a document the user was never told was gone. The throw names the file and
  says to re-upload it, which is actionable; a silent omission is not. This is
  symmetric with the will and pinned by `documentAssets.test.ts` ("fails closed when
  a configured storage asset cannot be fetched"). Do not relax it under this rule.
- **Rule 25-3 (3) certified FILING copies are NOT covered and stay fail-closed.**
  `ancillaryFilingAttachmentSpecs()` is a different legal use — a notice copy is
  never certified by implication. Its codicil shortfall, missing-file, and invalid
  list throws must remain. Do not relax them by symmetry with this rule.

Locked by regression tests: `server/p1-codicil-delivery.test.ts` pins the warn-only
behaviour, the two surviving hard gates, and the three Rule 25-3 (3) throws;
`server/pre-generation-warning-copy.test.ts` pins the Intake Tab notice copy.

---

## 15. P8 Deponents Derive From the ACTUAL Primary-Affidavit Deponent; a Lawyer Cannot Swear P3–P7 (MANDATORY — Nick, 2026-08-04)

**P8 single-form update (2026-09-06):** Addendum 24.8 supersedes the missing-primary
refusal for individual drafts. Missing references render blank after warning;
unavailable co-applicants or invalid/conflicting recorded identities produce visible
errors instead of disabled single-form actions. Bulk/package gates remain separate.

Nick's DO-NOT-SHIP resolution directive (2026-08-04) ordered the CONFIRMED-STATIC
finding resolved with its recommended solution, verbatim: *"hard-block/remove lawyer
selection for P3–P7. Compute P8 as every applying applicant except the retained,
valid applicant deponent. If the primary affidavit is absent or has a non-applicant
deponent, fail closed rather than generating P8s around it."*

- **Rule 25-3 (2)(c): the P8 set is every applying applicant EXCEPT the applicant
  who actually swore the (2)(b) affidavit** — not the ranked primary. Paragraph (b)
  requires the affidavit *from an applicant*; paragraph (c) requires a Form P8 from
  *each of the other applicants*. `p8ApplyingCoApplicants(contacts,
  primaryAffidavitDeponentId)` is the single shared resolver; every generation and
  validation path passes the retained primary affidavit's recorded deponent
  (`affidavitHistoryContext` / `primaryAffidavitDeponentFromDocuments`). The
  ranked-primary N−1 set survives ONLY as the planning/display prediction before a
  primary affidavit exists.
- **P8 fails closed** when the primary affidavit is **absent**, **ambiguous**, or
  was sworn by a **non-applicant** (settings-lawyer sentinel, stale or non-applying
  contact): `buildP8` + its preview mirror, `assertP8DeponentValid`,
  `generateAllP8`, `generatePackage`'s P8 loop, and the preflight hard block
  (`p8_primary_affidavit_missing` / `p8_primary_affidavit_non_applicant`, extending
  the LOGIC-003 ambiguity carve-out) all refuse rather than generate around it.
  This SUPERSEDES the 2026-07-22 warn-only treatment of a MISSING primary for P8
  (a second Rule 9 carve-out, same shape as the ambiguity guard). A retained
  primary missing only its signature DATE still renders ¶2 with the date blanked —
  the per-field blank fill is unchanged.
- **P3–P7 hard-block any non-applying deponent.** The dialog pool is
  applicants-only (`APPLICANT_AFFIDAVIT_FIELDS` — *2026-08-05 note: unratified Rule 18
  code renamed Nick-era `PRIMARY_AFFIDAVIT_FIELDS`/`assertPrimaryAffidavitApplicantDeponent`
  to `APPLICANT_AFFIDAVIT_FIELDS`/`assertApplicantAffidavitDeponent`; a Rule-18 revert
  restores those names*), and the server rejects the
  settings-lawyer sentinel, an unknown id, and a non-applying contact at BOTH choke
  points (`resolveGeneratedAffidavitDeponent` and docgen's
  `assertApplicantAffidavitDeponent`, DOCX + preview). This SUPERSEDES Rule
  8c's "lawyer stays selectable + warn-only" **for P3–P7 only** — the legal basis
  is 8c's own analysis (the face has no on-behalf/solicitor variant; a lawyer
  deponent is literally false). ~~Rule 8b/8c choosability is UNCHANGED for
  P9/P10/P14/P15/P16/P26/P45; P11 keeps its finding-8 rule~~ *(Nick's recorded scope
  limit, restored 2026-08-05)*. Rule 18 (UNRATIFIED — awaiting Nick) applies the same
  face-driven restriction to P10/P11/P14/P15/P26; Rule 8b remains for P9/P16/P45 and
  dedicated factual deponents. No selection on P3–P7 still defaults to the primary
  applicant, and an estate with no applicants still renders the blank draft (Rule 10c).
- **This also resolves the AWAITING-NICK item** "does a lawyer-sworn primary
  affidavit change the ranked-primary/N−1 P8 model": a lawyer-sworn primary is no
  longer generable, and a legacy lawyer-sworn primary already on file blocks P8
  until the primary is regenerated with an applicant deponent.

---

## 16. P11 Provenance Is Unified — One Archival Function on Every Route (MANDATORY — Nick, 2026-08-04)

Nick's second DO-NOT-SHIP resolution directive (2026-08-04) ordered the
CONFIRMED-STATIC finding *"P11 provenance varies by generation route"* resolved
with its recommended solution, verbatim: *"use one P11 archival/provenance
function for generate, quick download, direct download, and package; persist
deponent, signature date, version metadata, and package origin consistently."*
This **resolves the recorded AWAITING-NICK deferral** that kept P11 out of
`PERSISTED_AFFIDAVIT_FORMS` — resolved by Nick's directive, not silently.

- **P11 is in `PERSISTED_AFFIDAVIT_FORMS`.** Every render path — `document.generate`
  (which calls `replaceGeneratedDocumentRecord` directly), the `/api/download/form`
  direct download, and `generatePackage` (both via the `persistGeneratedAffidavit`
  wrapper over the same function) — archives P11 through
  `replaceGeneratedDocumentRecord`, exactly
  like the other sworn affidavits: the documents row carries
  `deponentId`/`deponentName`/`signatureDate`/`signatoryType`, and version records
  keep that identity snapshot when a P11 is regenerated.
- **`archiveP11Document` is deleted.** It accepted no deponent, hardcoded
  `signatoryType`, and its version records dropped even the prior signature date.
  Do not reintroduce a P11-only persistence path.
- **P11 stays un-referenced.** It is persisted for provenance only; it never feeds
  the P2/P8 `affidavitHistoryContext` facts (`REFERENCED_AFFIDAVIT_FORMS` is
  unchanged: P3–P7, P8, P9).
- **Deponent resolution** ~~is unchanged (finding-8, 2026-07-27): P11 honours an
  applying-applicant selection and otherwise falls back to the primary applicant;
  the settings-lawyer sentinel is ignored. The package path already resolves
  through the same choke point, so chosen == sworn == persisted on every route.~~
  *(Nick's recorded bullet, restored in full 2026-08-05.)* Under Rule 18 (UNRATIFIED)
  an explicit settings-lawyer, unknown, or non-applying id is now rejected rather
  than silently substituted; the no-selection primary-applicant fallback and the
  shared package choke point are unchanged.

**Extension (same arc, adversarial re-review):** the packaged **P8s** had the same
class of hole — the P8 branch zipped one per co-applicant and persisted nothing,
while `generateAllP8`, `document.generate` and the direct download all leave rows.
The package now persists each P8 with its resolved co-applicant deponent and the
per-co-applicant `targetRecordId` replace key (mirroring `document.generate`).
This is an application of Rule 16's principle to P8, not a new Nick ruling — flag
to Nick if the package-P8 rows are unwanted.

Locked by regression tests: `server/downloadRoute.test.ts` (P11 direct download
writes the full identity row; version record keeps the prior signature date) and
`server/routers.package-deponent.test.ts` (a packaged P11 leaves a documents row;
packaged P8s leave per-co-applicant rows).

---

## 17. Form P13 Optional Related-Material Insertion (MANDATORY — Nick directive, 2026-08-04)

Nick's DO-NOT-SHIP directive ordered the CONFIRMED-STATIC finding *"P13 cannot
include the official optional related-material clause"* resolved, offering two
routes: a conditional field end-to-end, or a formal base-only restriction that
blocks P13 when related material must be identified. **The field was implemented**
(the block alternative would still need the same intake signal to know material
exists, at which point the field itself is the smaller, face-faithful mechanism).

- **`estates.p13SealedMaterial`** (migration 0112, nullable text; intake field under
  the `pgtIsApplicant === "yes"` question). Lawyer-recorded, never defaulted.
- **Recorded → the face's insertion prints, verbatim wording:** *"…the court file
  in this proceeding including the following related material `[recorded text]` be
  sealed in the manner and for the period referred to in section 125 of the Wills,
  Estates and Succession Act."* (SCCR Appendix A.1 Form P13 capture,
  `references/SupremeCourtCivilRules.md`; authority WESA s.125 (a) — the PGT may
  specify related material.)
- **Blank → the base direction prints unchanged** (byte-identical to the pre-Rule-17
  output). The face marks the insertion *"add, if required"* — an unrecorded slot
  omits the clause; it never renders a fabricated or dotted blank fill.
- **DOCX and preview share one sentence builder** (`p13SealingDirectionText`), so
  the two renders cannot drift.

Locked by regression tests: `server/verify-all-forms.test.ts` (base sentence
unchanged when blank; insertion prints when recorded, DOCX + preview identical)
and `client/src/pages/EstateDetail.p13-sealed-material.test.tsx` (field renders
only under a "yes" PGT answer and persists via `estate.update`).

---

## 18. Every Prescribed Applicant Affidavit Has an Applying-Applicant Deponent (legislation-directed, 2026-08-04 — UNRATIFIED, AWAITING NICK: ratify or revert. Authored by ChatGPT without a Nick directive; face membership capture-verified and gate-locked by the 2026-08-05 validation arc; its supersessions of Rules 8b/8c are conditional on ratification)

The Appendix A.1 faces for P3–P7/P10/P11/P14/P15/P26 identify the deponent as
an applicant in the first person. They provide an organization-signatory variant,
but no solicitor or other on-behalf variant for an individual applicant. The
former warn-only/selectable-lawyer policy therefore allowed a facially false sworn
statement and is superseded for this closed set.

- **One shared classification:** `APPLICANT_DEPONENT_FORMS` contains P3–P7/P10/
  P11/P14/P15/P26. P16 (presence at signing), P45 (electronic-will facts), P9
  (delivery), and forms with dedicated deponents remain outside the set because
  their faces do not say the deponent is an applicant.
- **UI:** these forms use `APPLICANT_AFFIDAVIT_FIELDS`; the picker contains only
  `isApplyingApplicant` contacts. A stale lawyer/non-applicant selection is
  discarded and replaced only by a valid applying-applicant default.
- **Server and render defence:** `resolveGeneratedAffidavitDeponent` rejects an
  explicit Settings lawyer, unknown id, or non-applying contact before rendering
  or persistence. `assertApplicantAffidavitDeponent` independently protects both
  DOCX and preview. An omitted explicit selection may still resolve to the primary
  applying applicant; the server never silently substitutes after an invalid
  explicit choice.
- **Preflight:** P10/P14/P15/P26 expose an applicant-identity gap. P10/P14 also
  gate every printed deponent preamble slot and the jurat date, matching the
  existing P11/P15/P26 coverage. Organization applicants remain valid and their
  individual signatory fields continue to drive the printed human deponent.
- **Persistence invariant:** a rejected identity leaves no document or version
  row. A valid identity is the same identity selected, rendered, and persisted on
  direct, quick, package, DOCX, and preview paths.

Locked by regression tests: `server/affidavitHistory.p11-deponent.test.ts`
(resolver plus DOCX/preview defence for every added form),
`server/downloadRoute.test.ts` (400 before render/persist),
`client/src/components/FormDetailsDialog.test.tsx` (applicants-only pools), and
`shared/formRequirements.test.ts` (identity, preamble, and jurat preflight rows).

---

## 19. AI Processor Use Is Fail-Closed Until Approval (legislation-directed, 2026-08-04 — UNRATIFIED, AWAITING NICK: ratify or revert. Authored by ChatGPT without a Nick directive; also reverses the shipped-by-default embedded-chatbot decision, and its reclassification of the counsel launch blocker is a PROPOSAL — see chatbot/README.md residual #2)

ProbatePro remains accountable for personal information sent to an external AI
processor. AI processing is therefore unavailable by default and may be enabled only
after the Privacy Officer / counsel has approved the public privacy package and the
provider agreement/terms have been documented for retention, training, subprocessors,
security, and jurisdiction.

- **One exact operational assertion:** `AI_PROCESSOR_APPROVED=true` is the only value
  that enables AI processing. Missing, empty, false, or alternate truthy-looking values
  fail closed. The flag records an external approval; it does not replace that approval.
- **Every AI entry point is covered:** without approval, the embedded chatbot renders
  only a dismissible unavailable banner (no processing UI), the standalone chatbot
  refuses to start, and `aiImport.process` rejects before creating an import row or
  calling Forge. Core ProbatePro remains usable with AI disabled.
- **Point-of-use notice:** the chatbot keeps the third-party-AI disclosure visible after
  a conversation begins. EstateDetail AI-assisted import identifies that file text goes
  through Forge to two third-party AI models and requires an explicit authorization
  acknowledgment for each import.
- **Enterprise no-training notice (owner-confirmed 2026-10-14):** the active
  third-party enterprise AI API disables training on user inputs. The Assistant
  enablement dialog must say, in plain client-facing language, that questions, files,
  and estate information are not used to train AI models. Keep that statement only
  while the configured processor retains this contractual guarantee; a provider or
  service-tier change requires re-verification before this public wording is retained.
- **Server enforcement is authoritative:** a hidden, stale, or modified client cannot
  bypass the gate or the import acknowledgment. UI state mirrors the public availability
  query but never grants approval itself.

Locked by regression tests: `server/aiProcessorGate.test.ts`,
`server/routers.aiImport-processor-gate.test.ts`, `chatbot/test/env.test.ts`,
`client/src/components/chatbot/ChatbotWidget.test.tsx`,
`client/src/components/chatbot/ChatPanel.test.tsx`, and
`client/src/pages/EstateDetail.ai-import-cache.test.ts`.

---

## 20. Probate Fee Is Undetermined Until Ordinary Residence Is Recorded (legislation-directed, 2026-08-04 — UNRATIFIED, AWAITING NICK: ratify or revert. Authored by ChatGPT without a Nick directive; the fail-closed reasoning is sound, and its Explicit-No limb was corrected 2026-08-05 against the PFA capture — see the bullet below)

Probate Fee Act s. 1 includes intangible personal property wherever situated only
if the deceased was ordinarily resident in British Columbia immediately before
death. An unanswered ordinary-residence fact can therefore produce two different
statutory values of the estate and two different fees. ProbatePro must not choose
one and display it as exact.

- **Unknown is not Yes:** missing, blank, `unknown`, or an unavailable estate row
  returns `fee: null`, `feeBasisStatus: "ordinary_residence_required"`, and no
  statutory fee-basis amount. It never defaults to worldwide intangibles.
- **Explicit Yes:** fee basis is real and tangible personal property in British
  Columbia plus intangible personal property wherever situated.
- **Explicit No:** fee basis is real and tangible personal property in British
  Columbia **only**. The captured s. 1 definition attaches intangible personal
  property exclusively through the ordinarily-resident limb — a non-resident
  estate's intangibles are outside the statutory value even when situated in BC.
  *(Corrected 2026-08-05 against `references/ProbateFeeAct.md`: this bullet
  previously claimed BC-situs intangibles were included on the No limb, and
  `probateFeeBase` had implemented that same error since `65aa83d` — both the
  rule text and the computation are now capture-conformant.)*
- **UI:** both Fee Basis and Probate Fee show `Pending` while the fact is unknown,
  with a direction to record ordinary residence in Intake. Saving Intake
  invalidates the inventory totals cache so the displayed result cannot remain
  stale after the answer changes.

Locked by regression tests: `server/routers.inventory.test.ts`,
`client/src/pages/EstateDetail.p14-supplemental.test.tsx`, and
`client/src/pages/EstateDetail.intake-save-failure.test.tsx`.

## 21. VSA 532 Is Generate-on-Demand, the Certificate Result Lives in Intake Once, and the Location Multi-Asks Collapse Behind Explicit Copy Buttons (MANDATORY — Nick, 2026-08-05)

Decision record — Nick chose these three AskUserQuestion options on 2026-08-05
(intake de-duplication arc; option labels verbatim, the rest of this rule
paraphrases the option descriptions Nick saw when selecting):

1. **"Intake once, kill the card (Recommended)"** — the two form-feeding
   wills-search questions stay in Intake ONCE; the Documents-tab tracking
   card and its workflow (status/submitted/expected/names-searched, the
   internal follow-up deadline, the workflow readiness checks) go.
2. **"Demote to Optional (Recommended)"** — VSA532 becomes conditional /
   on-demand and leaves the auto-generated package; the Rule 25-3(2)(d)
   certificate requirement itself is untouched.
3. **"Copy buttons + collapse (Recommended)"** — oath city, P17 "formerly of"
   city, and the PFA ordinary-residence country collapse into a "usually the
   same" area, each pre-fillable with one click ("Same as residential") but
   never auto-written — sworn slots stay explicit. The presented option scope
   named the oath-city prefill expressly, so `domicileCity ← addressCity` via
   the explicit button is an APPROVED, user-initiated copy source. Rule 12's
   boundary is unchanged: the RENDER chain stays explicit `domicileCity` →
   `settings.firmCity` → blank, and the deceased's address never feeds a
   jurat automatically — the button is a dirty-tracked user action, proven
   never to fire on render by regression test.

- Form 532 (the wills-notice search REQUEST) is applicability "conditional":
  generate on demand if the wills-notice search has not been run yet. The
  Rule 25-3(2)(d) search CERTIFICATE itself must still accompany every
  estate-grant application — Form P2 §3 swears that 2 copies are filed
  (docgen.ts P2 §3 face text unchanged). The same applies to a resealing
  (Rule 25-6(2)(e)); the request form is simply not auto-packaged.
- The only wills-search facts ProbatePro records are on the estate row,
  entered in Intake: `vsaCertificateResult` (drives the sworn checkbox on
  P4 §4 / P6 ¶6 / P7 ¶6 via vsaNoticeBox) and `vsaWillsNoticeDate` (never
  prints; guards the "no later notice" sworn sentence and shouldUseP4
  condition (e)). Certificate receipt is tracked by the `wills_notice_result`
  required-document checkbox.
- The willsSearch workflow (status/submitted/expected-by/names-searched), its
  router procedures, the readiness workflow branches (`all_names_searched`,
  `delivery_after_wills_search`, the not-started/awaiting-result `wills_search`
  branches), the `vsa_532_expected_result_follow_up` deadline event, and the
  timeline rows are removed. Retained with no destructive migration: the
  `wills_search` table, `getWillsSearch`/`upsertWillsSearch`/
  `getWillsSearchesForEstates` and the estate-delete cascade, and the
  getReconciledAliases read of `willsSearch.aliases` (absent rows degrade to
  estate aliases only). The dead, caller-less `getAllWillsSearches` was
  deleted.
- Fail-closed logic is untouched: shouldUseP4 (e), vsaNoticeBox, the
  `wills_notice_later` readiness fail, and the p3-fail-closed semantics operate
  solely on the two retained estate columns.

Locked by regression tests: `shared/formStatus.test.ts` (VSA532 conditional),
`server/business.test.ts` (package sets exclude VSA532),
`shared/readiness.test.ts` (estate-column wills_search check),
`shared/formRequirements.test.ts` (p2_vsa_certificate_received),
`client/src/pages/EstateDetail.intake-dedup.test.tsx` (collapse default,
copy-button writes, never-on-render), and the unchanged
`server/p3-fail-closed.test.ts` / `server/vsa532-names.test.ts`.

### Rule 21 addendum — 2026-08-05 ChatGPT-review wave (Nick directive: "review, validate these items found by chat gpt. If they are in fact issues resolve them.")

All six findings validated as real and resolved the same day:

1. **(HIGH) All-names-searched gate RESTORED, intake-once** — removing it with the
   workflow card overreached: LEGISLATION_RULES_PLAN requires the search to cover
   the legal name and every recorded alias (omitted aliases are a registry
   rejection risk). New estate column `vsaNamesSearched` (**migration 0116**,
   backfilled from `wills_search.namesSearched`), asked once in the Intake VSA
   section when a result is recorded; readiness `all_names_searched` and P2
   preflight `p2_vsa_all_names_searched` restored, now estate-column-driven
   (tab: intake).
2. **(HIGH) Aliases single-sourced to Intake** — `getReconciledAliases` no longer
   merges legacy `willsSearch.aliases` (that column has no editor; a stale value
   printed uncorrectably on seven sworn/printed surfaces). The parameter
   survives, ignored, so frozen docgen call sites compile unchanged.
3. **(MEDIUM) VSA532 is na once a certificate result is recorded** — Rule 21's own
   boundary ("generate on demand if the search has not been run yet") is now
   enforced in formStatus; an explain-only fix-dialog entry warns about
   duplicate search fees. FORM_CATALOG's VSA532 description corrected to
   describe the REQUEST (the certificate is what Rule 25-3(2)(d) requires with
   the filing).
4. **(MEDIUM) Collapsed location summary honesty** — a blank `domicileCountry`
   shows "—", never "Canada" (an unrecorded fact is never restated as recorded;
   the input's display default mirrors the schema default and is unchanged).
5. **(MEDIUM) Foreign-grant date recorded ONCE** — the `ancillaryDate` intake
   control was removed; `estate.update` keeps the legacy `ancillaryDate` twin in
   lockstep with `foreignGrantIssuedDate` (variation-date-sync idiom) so P19's
   frozen grant-face clause can never state a different date than P2/P6/P7/P26.
6. **(LOW) Chatbot allowlist** — `placeOfDeath` removed (the allowlist's own rule:
   writable facts must be human-editable in Intake).

Additional locks: `server/routers.foreign-grant-date-sync.test.ts`,
`shared/readiness.test.ts` (all_names intake-driven), `server/business.test.ts`
(estate-only aliases), `shared/formStatus.test.ts` (VSA532 na-once-recorded),
`server/migration-integrity.test.ts` (0116 journal + snapshot).

### Rule 21 second addendum — 2026-08-05 follow-up review (same Nick directive)

1. **(MEDIUM) P2 generation now protected by the alias-coverage fact** — the
   readiness `all_names_searched` comparison is bridged into P2 preflight via
   `READINESS_PREFLIGHT_FORMS` (soft gap naming the omitted names); the
   registry row alone only proved `vsaNamesSearched` was non-empty. Locked by
   `server/routers.p2-alias-preflight.test.ts`.
2. **(MEDIUM) Migration 0117_foreign_grant_date_reconcile** — one-time data
   reconcile of already-divergent rows: `foreignGrantIssuedDate` wins where
   recorded; blank primary back-fills from legacy `ancillaryDate`. Mirrors the
   estate.update coercion so P19 vs P2/P6/P7/P26 cannot disagree for
   pre-existing estates either.
3. **(DEPLOYMENT GATE — not code)** Migrations **0109–0117** are recorded
   PENDING/unverified on live TiDB. The all-names protection depends on 0116
   and the date reconcile on 0117: run the read-only migration preflight and
   apply in numeric order BEFORE deploying this tree. Owned at deploy time by
   Nick; nothing in-code can substitute.
4. **(LOW) Location terminology clarified** — the ordinary-residence country
   control now states it records the PFA s. 1 COUNTRY fact only, that the
   domicile/ordinary-residence LEGAL determinations are the separate explicit
   questions below, and that the copy button is a starting point, never an
   inference. No logic change.

---

## 22. Applicability Decides What Is REQUIRED, Not What May Be Produced (MANDATORY — Nick, 2026-08-06)

**This rule REVERSES the fail-closed applicability policy for user-initiated
single-form generation.** Until now `formStatus()` returning `"na"` meant a form
could not be produced at all: `assertFormApplicable` threw on every render path,
the Forms tab painted those rows dead, and the "fix & generate" popup would only
proceed once the answers made the form legitimately applicable. On many forms
that condition can never be satisfied — P2 on a resealing estate, P8 with no
co-applicants, P44 after a grant issued — so the button existed and could never
be pressed. The gate was protecting the application from its own user.

**Nick's directive (2026-08-06):** *"i want it so a user can just generate a form
still even if something in the intake is wrong blocking it… i just want the list
of ones required based on what is put in the intake, and then the other forms as
optional with the extra questions through the popup."*

### The rule

1. **Two buckets, no dead state.** The Forms tab shows **Required** (what
   `formStatus()` calls for on the recorded facts) and **Optional** (everything
   else — `conditional` and `na` together). There is no "Not Applicable" group
   and no disabled Generate button. A form the engine calls `na` sorts last
   within Optional and still states its reason; the reason is information, not a
   wall.
2. **Applicability keeps its job, and only its job.** `formStatus()` remains the
   single source of truth for what is REQUIRED
   (`adr-formstatus-single-source-of-truth`). It no longer decides what may be
   produced. Package composition, readiness, deadlines and the probate-fee basis
   read it exactly as before.
3. **Answers are per-document OVERRIDES, never edits.** The Optional-form popup
   collects the facts that form needs and passes them with ONE generate or
   preview call (`shared/formOverrides.ts`). Nothing is written to the estate.
   The intake the lawyer left is the intake they come back to, and the next
   generation without overrides produces what it did before. To make an answer
   permanent, the lawyer records it in Intake — the popup says so.
4. **One merge, at load.** Each single-form path computes
   `applyEstateOverrides(estate, input.overrides)` immediately after loading the
   row and uses the result for the applicability decision **and** the render
   context. The facts that authorize a document must be the facts printed on it;
   two merges would allow those to diverge, and that divergence is the one
   failure mode this design does not tolerate.
5. **The lift is explicit and narrow.** `assertFormApplicable` still throws by
   default. Its `allowNotApplicable` option is set only from the caller's
   explicit `generateAnyway`, only on `document.generate`, `document.preview`
   and `GET /api/download/form`. An unmapped form code still throws either way —
   `formStatus()` cannot vouch for it at all, which is a different failure from
   "this estate does not need it", and not one the lawyer's judgement can cure.
6. **Bulk and package generation stay hard-gated.** `generatePackage`,
   `generateAllLetters`, `generateAllP8` and `preflightMany` accept neither
   input and call the gate with no options. A one-off draft can never reshape
   the filing package that goes to the court registry.
7. **The allowlist is derived, not written.** `OVERRIDABLE_ESTATE_FIELDS` comes
   from the question registry plus the columns
   `buildApplicabilityWritePayload` derives from those answers (willType →
   isElectronicWill; each electronic-will axis → the legacy format token). A
   column the popup cannot ask about is a column the server will not accept, so
   the UI and the gate cannot drift. Primitives only, length-capped, and
   provably disjoint from `SERVER_MANAGED_ESTATE_FIELDS` — ids, ownership and
   storage keys are unreachable. The download route's JSON parameter fails
   closed with a 400 rather than rendering from none of the answers.
8. **Every override generation is on the record.** `document.generate` writes a
   `document_override` activity naming each substituted fact as `before → after`
   and stating that the estate record was not changed. A file must never show a
   generated form and an intake that never called for one, with nothing
   explaining the gap.

### Why this is safe

The generated file is a **draft the lawyer reviews, signs and files**. It is not
a court submission and ProbatePro does not file it. The person asking for the
form is the professional who bears the filing decision; the application's job is
to tell them what the recorded facts require — which the Required list and the
retained `reason` copy both still do — and then to get out of the way. The
protections that actually matter are unchanged: the package the registry
receives is still composed from the record alone, and nothing a popup does can
alter the file.

### Locks

`shared/formOverrides.test.ts` (derivation, sanitization, non-mutation,
disjointness), `server/routers.form-overrides.test.ts` (default still
fail-closed; opt-in permits single-form only; renderer receives the overridden
estate; nothing persists; bulk paths unmoved; audit trail),
`client/src/components/FixApplicabilityDialog.test.tsx` (action never gated, no
tRPC call reachable, coupling preserved), and
`client/src/pages/EstateDetail.fix-applicability.test.tsx` (two buckets, no
disabled Generate, overrides reach generate AND preflight, intake untouched).
`server/routers.applicability.test.ts` is UNCHANGED and still pins the
no-override rejections — that suite is the evidence the default did not move.

### Addendum 22.1 — Inline field fill in the pre-generate dialog (Nick, 2026-08-07)

The PreGenerateDialog's copy promised "you can fill them now" since PROMPT 40
while offering only a jump-to-tab button. The promise is now true: a gap naming
a blank estate column renders a correctly-typed editor in place, "Apply &
re-check" merges the typed values into the pending render's per-document
overrides and re-runs the gap check, and the list shrinks without leaving the
dialog.

1. **The allowlist still derives ONLY from hand-curated UI registries** — the
   applicability question registry plus the new `shared/inlineFieldControls.ts`
   (estate column → control/label/options, copied verbatim from the column's
   canonical editor). It is then explicitly SUBTRACTED against
   `SERVER_MANAGED_ESTATE_FIELDS` (one shared literal in
   `shared/serverManagedEstateFields.ts`, the same set `estate.update` strips)
   and filtered by a second, independent shape denylist
   (`/StorageKey$|FilePath$|FileName$|MimeType$|UserId$|Files$|^id$|^revision$|^createdAt$/`).
   One guard is never enough on a security boundary.
2. **Accessors never widen the allowlist.** Deriving the editable set from
   `formRequirements.ts` accessor strings was analysed and REJECTED — do not
   re-propose it. The accessor list names `estate.willStorageKey`,
   `estate.foreignGrantStorageKey` and `estate.wesaS58OrderFilePath`, and the
   attachment pipeline (`p1NoticeAttachmentSpecs` → `storageGetSignedUrl`)
   dereferences whatever key the estate carries with NO caller scoping — an
   accessor-derived allowlist is a cross-tenant arbitrary object read.
   Accessors decide which registry entries to SHOW; the registries decide what
   the server ACCEPTS.
3. **Enum columns get selects, never text boxes — and the server enforces the
   token set.** The gap engine's satisfaction test is merely "non-empty";
   docgen reads `oathType === "sworn" ? sworn : affirmed`, so a free-typed
   "Sworn" would render an affidavit that AFFIRMS throughout with no error.
   `sanitizeEstateOverrides` drops any select-column value outside the
   registry's option set.
4. **Blank-field fills DEFAULT to persisting** ("Also save these to the
   intake", checked). Blank fields are missing DATA, not overrides of a wrong
   value — the lawyer should not retype the deceased's name on every form.
   Unchecked, the values ride as per-document overrides exactly as Rule 22 §3
   describes. Applicability answers from the Optional-form popup stay
   TRANSIENT always — this addendum does not touch §3.
5. **Inline editing exists only where the pending mutation consumes the
   overrides channel** (`supportsOverrides` render-context flag). Package and
   bulk runs never set it, so the dialog cannot collect values a hard-gated
   mutation would drop. Rule 22 §6 is unmoved.
6. **The download route now writes the same `document_override` activity**
   `document.generate` writes, on the SAME condition (`summary || generateAnyway`)
   — a not-applicable form produced on the lawyer's explicit say-so is logged
   even when no field value was substituted, because that is precisely the case
   §8 exists for. Preview persists nothing and stays unlogged.
7. **The audit line must never misstate what moved.** `overrideSummary` omits a
   key whose override equals the stored value (with "Also save these to the
   intake" the two are equal by construction, and reporting
   "Margaret → Margaret" under "the estate record was NOT changed" would be
   false on both halves), and it is length-bounded — per value and overall.
   The sink is `activity.summary` varchar(2000) and the INSERT happens AFTER
   the document and its stored object exist, so an unbounded summary throws
   exactly when the overrides were most substantial and loses the one record
   §8 requires.
8. **Values are type-checked against the control that describes them.** A
   registry column typed `text`/`textarea`/`date` accepts only strings and
   `number` only numbers, because the gap engine's satisfaction test is merely
   "non-empty" — `deceasedLastName: true` would otherwise clear a required-name
   gap and print `true` on a sworn document. Columns the applicability registry
   owns keep their existing int/boolean shapes.
9. **The two awaits in the apply are guarded.** "Apply & re-check" suspends on
   the save and again on the gap re-check; Generate-anyway, Cancel or a tab
   jump in that window consumes or clears the pending refs. The continuation
   re-checks that the refs are still the ones it captured, so a resumed apply
   can never fire a SECOND generation — two filed drafts where the first
   silently lacked the typed values. The in-flight flag covers the whole apply,
   not just the save, and a CAS failure invalidates the cached estate so the
   retry does not replay a losing revision.

Locks: `shared/inlineFieldControls.test.ts` (every key a real estates column,
never resolved off the Object prototype,
never server-managed by literal or shape, enum entries usable, dual-registry
token compatibility, accessor parser boundaries),
`shared/formOverrides.test.ts` (widening + both guards + enum guard + textarea
cap), `server/routers.form-overrides.test.ts` (storage-key regression — the
renderer receives the STORED key; miscased enum dropped; shared-literal content
pin), `server/downloadRoute.test.ts` (download audit parity), and
`client/src/components/PreGenerateDialog.test.tsx` (typed editors, equality
accessors and non-estate namespaces excluded, mode:"any" labelled as
alternatives, save-checkbox default, package/bulk unchanged, hard-block
untouched).

## 23. P3/P4 ¶2 "Other Executors" Pool Is Canonical; Blank Status Is Non-Applying; Unmatured Alternates Are Invisible (MANDATORY — Nick, 2026-08-07)

Bug context: the ¶2 sub-branch pool was a role-string fork
(`contactHasRole(c, "executor", "applicant")`) with an inverted applying test
(`c.executorStatus && c.executorStatus !== "applying"`), copy-pasted in four
places. A co-executor whose `executorStatus` was never set (the DB default is
`""`) was silently absorbed into "No other persons are named in the will as
executor who are not parties to this application." — a sworn false statement —
and `alternate_executor`/legacy `recipientType` executors never entered the
pool at all.

1. **One pool, canonical helpers.** `p3OtherExecutorPool()` in
   `server/docgen.ts` is the ONLY source for the P3/P4 ¶2 sub-branch, in both
   DOCX builders and both preview mirrors. Membership is the shared
   `isExecutorContact()` (executor, alternate_executor, legacy
   `recipientType === "executor"`); "applying" is the shared
   `isApplyingApplicant()`. Never re-derive either from role strings or raw
   `executorStatus` truthiness.
2. **Blank status = not applying.** An executor-role contact with a blank
   `executorStatus` and no applicant role LISTS as a non-applying executor
   (official "other" box with the dotted blank for counsel to complete). It
   must never select a "No other persons…" box.
3. **Unmatured alternates are invisible.** An `alternate_executor`-only
   contact with no recorded non-joining status and no predeceased flag has an
   appointment that never matured: it is neither listed nor counted when
   choosing between the "No other persons…" boxes. An alternate WITH a
   recorded non-joining status (or applying) participates fully.
4. **Reason boxes.** `renounced` → "has renounced executorship";
   `deceased` OR `isPredeceased === 1` → "is deceased"; `reserved` → "other"
   with the recorded reason, falling back to the factual phrase "has reserved
   the right to apply for a grant at a later time"; everything else → "other"
   with the recorded reason or the official dotted blank. The UI exposes the
   Reason/Notes field for `reserved` as well.

5. **Box 1 keys on the deponent, not pool size.** "No other persons are named
   in the will as executor." prints only when every pool member IS the deponent
   (`execPool.every(c => c.id === app?.id)`) — never on `length <= 1`. An
   applicant-role deponent outside the executor pool must not shrink "other
   persons" to zero: with an applying co-executor recorded, the correct box is
   "…who are not parties to this application."
6. **Sibling pools follow (adversarial-verify round, same arc).** The P2
   Schedule s.1 reserved-right pool and the P19 reserving clause use the same
   canonical `isExecutorContact()` pool (a reserved alternate sworn on P3 ¶2
   must appear on P2 s.1 and carry into the grant's reserving clause), and
   `buildReadiness`'s `executor_status` check excludes the Rule 23(3)
   invisible alternate (alternate-only role, blank status, not predeceased) —
   a blank status there is a legitimate persistent state, not a failure.

Locks: `server/docgen.test.ts` (blank-status co-executor DOCX+preview,
renounced alternate, legacy recipientType executor, invisible blank alternate,
reserved canned/recorded reason DOCX+preview, predeceased "is deceased"
DOCX+preview, predeceased alternate visible, applicant-role deponent box
selection DOCX+preview, applicant-role blank-status executor counts applying,
P4 blank-status DOCX+preview, P2 s.1 reserved alternate, P19 reserved
alternate reserving clause) and `shared/readiness.test.ts` (invisible
alternate ignored, blank plain executor still fails).

## 24. Generation Is Warn-Only for Missing DATA; Sworn-Truth Gates Stay Fail-Closed; the Documents Tab Is Removed (MANDATORY — Nick, 2026-08-17)

**P8 update (2026-09-06):** Addendum 24.8 supersedes item 2's missing-primary
single-form refusal and requires visible errors for unavailable P8 deponents.

Nick's four rulings, given as AskUserQuestion answers (option labels verbatim):

1. **"Warn-only + inline fill (Recommended)"** — for the data-class blockers
   (grant type, passes-to-PR answers, missing intake fields) on a
   **user-initiated single-form** action: never a dead end. Missing data warns,
   and the PreGenerateDialog collects it in place wherever a hand-audited
   inline control exists.
2. **"Keep fail-closed (Recommended)"** — the sworn-truth gates are UNCHANGED:
   Rule 15 deponent derivation (lawyer hard-blocked on P3–P7; P8 fails closed
   on a missing/ambiguous/non-applicant primary), Rule 14 foreign-grant and
   Rule 25-3 (3) certified filing copies, Rule 5 P34 evidence. These exist so a
   generated affidavit can never state a falsehood; converting them was offered
   and REFUSED.
3. **"Relocate then remove (Recommended)"** — the Documents tab is REMOVED.
   Its checklist card (`RequiredSourceDocumentsCard`, still the sole writer of
   `requiredDoc` rows and Rule 21's certificate tracker) moved to the TOP of
   the Readiness tab; the AI import card + proposals moved to the BOTTOM of the
   Intake tab. Nothing was deleted. The five P2 source-document gap rows carry
   `tab: "readiness"`; the legacy `"documents"` ReadinessTab token remains in
   the type for compatibility and maps client-side to the Readiness tab.
4. **"Commit it, then proceed (Recommended)"** — the Rule 23 arc was committed
   and pushed (`1a6ca48`, rebased onto Manus's `7506c61`) before this arc began.

What shipped under this rule:

- **The not-applicable dead end is closed.** When a single-form action reaches
  the preflight dialog hardBlocked on the `na` verdict (no `generateAnyway` —
  e.g. the verdict flipped after the buckets rendered), the dead "Blocked"
  button is replaced by **"Answer & generate/preview anyway"**, which re-routes
  through FixApplicabilityDialog into the UNCHANGED pipeline with
  `generateAnyway`. `assertFormApplicable`'s default throw did not move; the
  escape is offered only when the parent supplies the handler, and the parent
  supplies it only for single-form actions. **Bulk/package remain hard-gated
  and take no overrides (Rule 22 §6 — reaffirmed by ruling 2's boundary).**
- **INLINE_FIELD_CONTROLS extended** (~19 new entries: notifyPGT, the P4
  will-filing/alterations/attestation cluster, orders, other grants,
  referenced documents, residence/domicile columns, p11AffidavitOrdinal, the
  uncoupled P45 electronic-will columns). Every entry re-audited under the
  Addendum 22.1 rules: single-column writers only, Intake labels/tokens
  verbatim. DELIBERATELY excluded, with reasons in the file: coupled axis
  columns (`applyElectronicWillAxis`), the derived `applicantPriorityParagraph`,
  multi-select `specialCircumstances`, half-fact `erasureStatus`, and
  `testamentaryDocStatus` (REMOVED — its two conditional Intake editors
  disagree and docgen's P7 ¶5 matches only `none_found`/`found`, so an inline
  "na" silently dropped the diligent-search declaration; this closes the
  2026-08-07 review's MEDIUM and LOW findings on that entry).
- **Required-document receipts are inline-fillable.** A preflight gap naming
  `requiredDocuments[docKey=<key>].received` renders a "Mark received"
  checkbox; Apply persists through the SAME `requiredDoc.upsert` the checklist
  card uses. Receipt is a real record: it never rides the overrides channel
  (`inlineEditableDocKey` admits only the `.received` boolean).
- **The soft-na dialog copy is truthful** (fixes the 2026-08-07 LOW): a
  not-applicable report produced via `generateAnyway` is titled as
  not-applicable-producing-anyway, no longer "Missing information".

Boundaries a sweep must not cross: do not re-gate the relocated cards behind a
new tab; do not convert the ruling-2 gates to warn-only; do not resurrect a
disabled Generate button on the Forms tab; do not add coupled/derived/
multi-select columns to INLINE_FIELD_CONTROLS.

### Addendum 24.1 — post-validation corrections (2026-08-17, adversarial workflow: 41 findings raised, 17 confirmed, all fixed same-day)

A 48-agent validation workflow (8 dimensions × 2-skeptic refutation) over the
Rule 24 arc confirmed 17 defects; every one is fixed in this addendum's commit:

1. **RECORD CORRECTION — ruling 1's scope.** The ## 24 heading text named
   "passes-to-PR answers" among the warn-only data-class blockers, but the five
   `p10/p11/p14/p15/p26_passes_to_personal_representative` requirements remain
   `blocker: "hard"`, mirroring the frozen docgen assertion
   (`assertPersonalRepresentativePassageRecorded`) — P10 ¶3(a)/P11 ¶5(a) swear
   an affirmative completeness statement, so rendering with unanswered items
   is the Rule 2 fabrication class, and the per-inventory-row inline editor
   it needs is the recorded wave-2 deferral. **Read ruling 1 as: grant type +
   inline-fillable intake fields + the na verdict. Passes-to-PR stays HARD
   until Nick rules on the per-item editor arc.** ⚠ AWAITING NICK: confirm
   this narrowing or order the per-item editor arc now.
2. **The escape hatch is gated on the pending single-form ref, not report
   count.** `pgReports.length === 1` was a false proxy — "Generate All P8"
   takes the single-report branch and "Generate All Letters" always merges to
   one report, so a bulk click could reach "Answer & generate anyway"
   (crossing Rule 22 §6). Now: handler supplied only when `pgPendingRef` is
   set (bulk/package never set it) AND the pending context carries no
   target id (`targetContactId`/`targetDeliveryId`/`targetCitationRecordId`/
   `selectedContactId`) — target-scoped na verdicts are record-driven and the
   fix dialog cannot cure them; re-routing would also drop the target and 400.
3. **The escape renders only when the na verdict is the SOLE hard blocker**
   (every hard gap's requirementId ends `_applicability`) — beside a kept
   Rule 5/14/15 gate it would loop, so the honest Blocked button stays.
4. **The escape carries `fromNaOverride`** → FixApplicabilityDialog's
   `forceNotApplicable` → Proceed always sends `generateAnyway` (a stale
   client estate row computing "applicable" no longer loops the user).
5. **Doc-only inline Apply no longer calls `estate.update` with an empty
   patch** (revision bump + empty audit row + spurious CAS conflicts), and
   Apply banks values only when the re-check actually completed
   (`runWithPreflight` now returns a completion boolean).
6. **The checklist card renders in every readiness-query state** (loading /
   error / empty) — it is the sole requiredDoc writer and must never hide
   behind a failed readiness check.
7. **The readiness engine's two `required_docs` rows carry `tab: "readiness"`**
   (were still "documents"), and the four surviving Documents-tab strings were
   swept: the Intake VSA help text, the chatbot system-prompt tab roster
   (which also still advertised the Rule-21-removed wills-search tracker),
   the `suggest_navigation` tool description, and the
   `no-global-document-search` site-knowledge answer.
8. **P16's child gaps are parent-gated**: `p16_alteration_detail` and
   `p16_route_selected` fire only when `willAlterations === "has_alterations"`
   — a generate-anyway P16 on an estate with no recorded alterations no longer
   invites inline answers to questions Intake never asked
   (`p16_will_alterations_flag` surfaces the parent).
9. **Count correction:** the Rule 24 registry extension is **22 entries
   (36 → 57, with testamentaryDocStatus removed)**, not "~19".

### Addendum 24.2 — P3 draft access (MANDATORY — Nick, 2026-09-04)

Nick's directive, verbatim (also recorded in the Probate Software brain's
`decisions/adr-p3-draft-access.md`):

> While working keep user convienance in mind, we want the user to be able to access the form NOT block it.

> Expected Never silent-succeed with no download. No hard-block of P3.

P3's short-form selection guard must honor the existing explicit single-form
`generateAnyway` choice. Leaving "Use long-form applicant affidavit (P4 instead
of P3)" checked must still allow a P3 draft through preflight, DOCX, preview,
and direct download. A changed applicability verdict during preflight must
retain the Answer & generate anyway route. This supersedes the P3-specific
hard-block resolution from the 2026-09-02 estate-18 loop-4 fix.

`shouldUseP4`, `formStatus`, readiness, and package selection keep their existing
recommendations. The choice is per request and never changes Intake. Bulk and
package generation receive no draft exception. Independent grant-type and
deponent checks, other forms' guards, and all prescribed wording and formatting
are unchanged. Missing VSA/original-will receipt records stay warn-only.

The single-form generation success callback must validate that a document URL
exists and initiate its download before showing success. Generation failures,
missing URLs, and download-start errors must show an error and preserve retry.

### Addendum 24.3 — P5 draft access and section 5 (MANDATORY — Nick, 2026-09-04)

Nick's expected behavior, verbatim (recorded in the Probate Software brain's
`decisions/adr-p5-draft-access-and-no-will-statement.md`):

> Do **not** hard-block P5. Warn "not applicable for GOP with will", then allow generate after answering will/no-will / standing.

> If will exists, do not print s.5 "no will" as a completed oath.

Every manual single-form P5 action carries the explicit draft choice, including
when its current applicability is Required. This permits P5 on a will-based
grant and preserves access after answering the popup or rechecking gaps.
The popup collects canonical Will Status and the existing
consent/nominee standing inputs without changing Intake. Applicability remains
a recommendation and keeps its existing role in package selection.

P5 section 5 completes its exact prescribed sentence only on a supported
explicit no-will answer. Otherwise its numbered paragraph contains a blank
fill. Stored will evidence survives all per-document overrides, including
overrides that make P5 Required and omit Generate anyway. The same evidence
prevents section 4's absolute no-document/invalid-document boxes from ticking.
Preflight explains the blank as a warning rather than a hard block.

Explicit incomplete P5 drafts use existing blank fills/unchecked alternatives
for unanswered testamentary-document and other-grant facts. Unsupported
statutory standing falls back to the prescribed relationship alternative.
Default API validation, deponent identity checks, P7, and other forms are unchanged.
Preserve paragraph/run geometry and every completed prescribed sentence.

### Addendum 24.4 — P9 full prescribed scaffolding (MANDATORY — Nick, 2026-09-05)

Nick's expected behavior, verbatim:

> Emit full prescribed P9 scaffolding after para 2 (paras 3–5 / unused alternative boxes per R. 22-3).

> Generated P9 includes paras 3–5 (or official equivalent), not only 1–2 + jurat.

P9 DOCX and preview retain both section 2 electronic-acknowledgement boxes,
section 3's representative-delivery phrase, section 4 and all three PGT method
boxes, and section 5 and both electronic-will demand boxes before the jurat.
Include the prescribed drafting instructions from the captured P9 face.
This supersedes the P9 omission policy in the estate-18 loop decisions.

Existing facts control completion, not scaffold visibility. With no represented
delivery, section 3 keeps its receiver, capacity, and represented-person fills
blank. PGT methods tick only from real non-dispensed PGT delivery records.
Acknowledgements require a nonempty electronic-delivery set with every
acknowledgement recorded. Electronic-will alternatives require a nonempty,
fully resolved set of recorded no-demand/complied outcomes; physical wills,
missing/invalid/outstanding outcomes, and empty records leave both unticked.
Never invent delivery records, dates, acknowledgements, or demand outcomes.

Use source-exact wording and existing paragraph/checkbox helpers. Preserve
the preamble, paragraphs 1–2, and jurat properties. Generation remains available
through the existing warning workflow.

### Addendum 24.5 — P11 draft access with BC domicile Yes (MANDATORY — Nick, 2026-09-06)

Nick's expected behavior, verbatim (recorded in the Probate Software brain's
`decisions/adr-p11-draft-access.md`):

> **NO hard-block.** Warn that P10 is the default path; still allow generate.

> Warn "not required — use P10"; still download P11 if user insists. Do not require false domicile answers. Do not assert para 3 with para 2 blank.

Acceptance, verbatim:

> With domicile Yes, P11 DOCX still downloads after warning.

The existing explicit single-form Generate anyway choice allows P11 through
preflight, DOCX, preview, and direct download with domicile Yes. Remove the
independent P11 domicile refusal and its inline correction hint. The domicile
and ordinary-residence completeness rows accept either recorded Yes or No;
blank/unknown answers still prompt for the facts without forcing No.

P10 remains the default when the Rule 25-3(8) predicate does not hold.
Required-form and package selection remain mutually exclusive; the draft
choice does not change Intake. Independent deponent and inventory truth
checks remain enforced.

P11 paragraph 2 completes only when both BC answers are explicitly No.
Paragraph 3 completes only when that same condition holds and foreign
administration is supported. Otherwise keep each paragraph's existing blank
fill. Preserve all completed prescribed wording and document geometry.

### Addendum 24.6 — P16 separate alteration fields and clean location (MANDATORY — Nick, 2026-09-06)

Nick's product direction, verbatim (recorded in the Probate Software brain's
`decisions/adr-p16-clean-location-and-separate-facts.md`):

> Collect page, line, alteration words, presence — merge cleanly.

> Separate fields for page, line, quoted words, presence confirm.

Acceptance, verbatim:

> DOCX shows one page, one line number, and the actual alteration phrase — not duplicated labels.

Manual single-form P16 generation/preview reviews the separate page, line,
alteration type, exact words, and presence controls, including populated fields.
Saving and rechecking keeps each fact in its own column. Type alone does not
satisfy the exact-words warning. Presence is never parsed out of the words.

DOCX and preview share normalized page/line references. Recognizable labels
such as "Page 1" and "Page 1, line 12" cannot produce repeated page/line labels.
Conflicting or malformed structured references remain unfilled and warn for
correction. Preserve independently recorded other exact references and typed
alteration wording; never replace a user's words with an example or infer the
actual phrase from a UI label.

The legacy auto-composed description contributes only its page during a
structured edit; its old line/type/words cannot override new facts. A standalone
supported legacy description remains readable. Exact words accept up to the
existing 500-character column limit on document overrides as well as storage.
Preserve every prescribed sentence, paragraph/run property, and jurat layout.

### Addendum 24.7 — P7 draft access despite grant-type mismatch (MANDATORY — Nick, 2026-09-06)

Nick's product rule, verbatim (recorded in the Probate Software brain's
`decisions/adr-p7-draft-access.md`):

> NO form should be hard-blocked. If a form is not required / wrong grant type for the estate, **warn**, collect any missing fields, and still allow generation (Generate Anyway or equivalent). Silent blocks and disabled Generate Anyway are defects.

Acceptance, verbatim:

> On a domestic GOP estate like #19, user can download P7 after acknowledging the warning. Generate Anyway is never permanently disabled solely because grant type mismatches.

> Do not require the estate grant type to be changed before download.

Remove P7's independent with-will grant refusal. The existing explicit single-form
Generate Anyway acknowledgement carries through preflight, DOCX, preview, and
direct download. The warning names ancillary administration without will annexed;
`formStatus` continues to select the required/package form from the estate facts.

Collect the existing foreign court, jurisdiction, issue date, and grantee names
when missing. Missing facts remain warnings for draft generation. Preserve all
prescribed P7 wording and geometry, including the existing unticked paragraph 5
alternatives when a will is recorded. No grant-type or will-answer change is
required to download. Independent applicant identity validation remains intact.

### Addendum 24.8 — P8 draft download and visible errors (MANDATORY — Nick, 2026-09-06)

Nick's product rule, verbatim (recorded in the Probate Software brain's
`decisions/adr-p8-download-feedback.md`):

> NO form should be hard-blocked; never silent-succeed with no download. Always download a DOCX **or** show a visible error toast.

Acceptance, verbatim:

> Single-applicant estate: Generate either opens co-applicant intake then downloads, or shows a visible error.
>
> With co-applicant present (e.g. Avery Calder-Quay): P8 downloads on first Generate (no silent fail).

> Do not hard-block P8. Firm AFS defaults for lawyer contact remain correct when applicable.

A single-form P8 request with no applying co-applicant shows an actionable error
identifying Contacts and name, address, occupation and relationship. Generate stays
available. With a co-applicant but no retained primary affidavit, warn and allow a
draft using the existing predicted co-applicant set; paragraph 2's absent primary
references stay blank. This supersedes the missing-primary single-form refusal in
Rule 15 and Rule 24 item 2. Retained actual primary identity still determines the
excluded applicant; conflicting history or an invalid selected identity returns a
visible error. Bulk/package primary-history gates remain separate.

Carry the chosen co-applicant through preflight, preview, generation and download.
Persist the resolved deponent as the per-person P8 replacement key. Missing download
links, failed saves and rejected handoffs must remain visible and retryable; success
follows download initiation. Preserve P8's prescribed wording, formatting and AFS
defaults. No estate grant-type change or schema migration is required.

### Addendum 24.9 — P9 requires actual delivery proof (MANDATORY — Nick, 2026-09-06)

Nick's acceptance, verbatim:

> After entering a recipient (e.g. Avery Calder-Quay, personal delivery, 06/Sep/2026), generated P9 shows ☒ on personal delivery and lists that person + date. Never ship all methods ☐ with zero names.

Before P9 generation, collect and save at least one actual recipient name,
delivery date and prescribed method. Electronic delivery also requires its
written acknowledgement date. A dispensation or delivery to an applicant alone
does not provide this proof. Represented recipients require the actual receiver
facts; direct adult delivery does not fill paragraph 3's representative blanks.

This instruction supersedes the general warn-only policy solely for an empty P9
delivery oath. Single generation, preview, direct download and package generation
return an actionable error without the minimum proof, including after Generate
Anyway. The dialog saves focused edits and awaits delivery writes before continuing;
failed saves remain visible and retryable. Other incomplete-notice warnings remain.

If the notice circle is confirmed complete and the canonical notice rules find
no required recipient, direct the user to P2's no-affidavit-of-delivery option.
Do not invent delivery to the sole applicant. Actual PGT-only delivery remains a
valid P9 through paragraph 4, and P2 must not select its no-P9 option for that case.

Preserve Addendum 24.4's paragraphs 3–5, ten checkbox rows and five prescribed
instructions, the recorded will description and retained P1 Exhibit A attachment.
No prescribed wording or layout change is authorized by this delivery-data repair.
The Probate Software brain records the contract in
`decisions/adr-p9-delivery-proof.md`.

---

## 25. Only the Checked Alternative Prints; Marker Rows Align Under Their Text; Body Text Stays Left-Aligned (MANDATORY — Nick, 2026-09-07)

Nick, from a rendered P2 (2026-09-07): *"the format of the forms is ruined. 1. it is not
hiding unchecked info. 2. ... the line under the first line of a multi line paragraph
should align with the first 'justified' 3. and other stuff review the form in the brain
and fix the format so that it is proper start with p1-3"* — and, mid-arc: *"make sure all
forms hide unchecked info"*. This is the newest explicit order and it supersedes the
2026-09-01 estate-#18 decision 4 ("exactly-one groups print ALL prescribed alternatives",
XC-06, ADR `adr-estate18-ship-loop-supersessions`) and Rule 13's vanished-glyph bullet.

1. **Prescribed alternative groups print only the checked alternative(s).** Every
   check-one / check-one-or-more group in a generated DOCX goes through
   `checkboxGroup()` in `server/docgen.ts` (and its preview twin
   `previewCheckboxGroup()`). When at least one alternative is checked, the unchecked
   siblings are NOT emitted. When NOTHING is recorded — no alternative checked — every
   alternative prints with a visible ☐ for hand completion; the group never disappears
   and a printed box is never hidden text. Lines that belong under an alternative
   (sub-items, fills, a nested group such as P2 §5's order filing-status pair) ride in
   that row's `sub` and hide with it. The section number rides on the first printed
   row unless the face numbers every alternative (P2 §5). Rows that are always checked
   on the app's model (P2 inventory election box 1) therefore hide their sibling. This
   applies to **every form**; it does not change the tick logic (no-fabricated-sworn-facts,
   Rule 11, the PGT explicit-answer gate and the P9 delivery-proof scaffold all keep
   their ticks — a P9 group with no recorded evidence still prints all of its boxes ☐).
2. **Continuation lines align under the first line's text.** A marker paragraph
   ("(1)", "(a)", "12", a checkbox) carries a TAB between marker and text so the shared
   fixed grid renders it; untabbed "(a) text" hanging paragraphs are prohibited because
   the space after the marker never equals the hanging indent. Grid: numbered rows
   0 / 480; lettered sub-items 480 / 960; checkbox rows 0 / 480 / 960 / 1200 (Rule 13);
   sub-items under a checkbox row 1200 / 1680. A marker cell is never narrower than
   its marker (a 240-twip cell wrapped "(a)" as "(a" / ")"). Fills and sub-lines under
   a marker row start at that row's text column. Untabbed paragraphs keep their own
   `indent` / `hanging` (the 2026-09-06 renderer dropped them — regression fixed).
3. **Body text is LEFT-aligned (ragged right), never fully justified.** Nick, after a
   justified render the same day: *"not justified on the right side only justified at
   the left side of the paragraph please"* — his "justified" in the directive above is
   the hanging alignment of item 2, not `AlignmentType.JUSTIFIED`. `BODY_ALIGN` in
   `server/docgen.ts` is `LEFT`; do not re-introduce `w:jc both` (locked by
   `server/docgen-checkbox-group.test.ts`). The 2026-07-10 queued "justified body text"
   spec is withdrawn by this ruling.

Wording is untouched by this rule (Rule 1). Locked by `server/docgen-checkbox-group.test.ts`
and the all-form sweep in `server/docgen.test.ts`.

---

## 26. Individual Lawyer Record Attribution and No Compliance Overclaim (PRODUCT PREFERENCE — 2026-10-03)

ProbatePro is designed for **individual lawyer accounts**. The authenticated lawyer
account is the account-level owner/controller of its estate records and stored-file
references for product authorization purposes. The platform and its infrastructure
providers do not acquire ownership of those client records merely by operating the
service.

- Every estate/file operation must derive the lawyer account from the authenticated
  server session. A browser must never choose, write, or elevate an owner account ID.
  Existing estate ownership (`createdByUserId`) and durable storage ownership
  (`stored_objects.userId` plus `estateId`) remain the authorization sources.
- Cross-account estate, document, export, download, update, and disposition access
  must fail closed and be regression-tested. A storage-key prefix or a client-supplied
  estate ID is never sufficient authorization.
- Lawyers must be able to obtain their authorized records in a usable export format.
  A request to delete or close an account does not bypass retention, legal hold,
  production, or verified provider-destruction controls.
- The application must not claim “Law Society compliant”, “Canadian-resident”,
  “Canada-only”, or equivalent regulatory assurances until the actual provider,
  backups, snapshots, logs, support access, subprocessors, contracts, and restore
  evidence have been verified and approved by qualified counsel.
- A Toronto VPS plus an independent encrypted recovery copy may be a future
  sensitive-data-vault option. Multiple VPSs are a resilience choice, **not** a
  Law Society of BC Rule 10 requirement. Do not require a vault before ordinary
  workflow works, and do not collect or expand sensitive data merely because a vault
  is available.
- No official probate form wording, layout, generation behavior, selected-only
  alternative behavior, or sworn fact may change as a consequence of this rule.

See `docs/architecture/rule-10-conformance-baseline.md` and
`docs/superpowers/plans/2026-10-03-rule-10-records-control.md` for the documented
baseline and staged implementation plan.

---

## 27. Labelled Product Actions Do Not Use Decorative Directional Arrows (PRODUCT UI RULE — 2026-10-03)

**Do not put arrow or chevron glyphs beside the text of a labelled product action.**
Labels such as “Continue”, “Review”, “Back”, “Open file”, “Go to Forms”, “Next”, and
“Get started” must communicate the action by words and visual hierarchy, not a
decorative direction cue. This applies to new and edited buttons, links styled as
actions, onboarding screens, dashboards, empty states, dialogs, and public pages.

- Keep the label plain and specific; use a non-directional semantic icon only when it
  improves recognition (for example, a document or save icon).
- The narrow exceptions are compact controls whose **sole meaning is spatial or state
  direction**: select disclosure carets, date/calendar navigation, carousel controls,
  table reordering, scroll-to-top, and submenu indicators. These controls must retain
  accessible names; do not add a redundant text arrow merely to decorate a label.
- Do not change legal-form wording, document output, form requirements, generation,
  estate data, or authorization behavior to apply this visual rule.

---

## 28. Hybrid Vault Credentials Must Stay Split; Read the Diff Before Publishing (MANDATORY — Nick, 2026-10-18)

For the two-role AWS vault, preserve two distinct credential providers and client
helpers. Runtime assumes `AWS_ROLE_ARN` with `AWS_EXTERNAL_ID`; purge assumes
`AWS_PURGE_ROLE_ARN` with `AWS_PURGE_EXTERNAL_ID`. Both use the bootstrap
`AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` credentials for STS AssumeRole only.
Never merge the roles behind one provider with a boolean flag or give ordinary
vault functions the purge client as a convenience.

- Only `providerDeleteExact` may obtain the purge client. Its exact-key version
  enumeration and physical delete requests use the purge client; all other
  destructive callers must delegate to `providerDeleteExact`, not obtain purge
  credentials themselves.
- Purge must attach no STS session policy and make no KMS calls. Its session must
  not exceed one hour. Runtime must retain its separate credential path.
- Use `STORAGE_S3_REGION` for every vault client; the approved configuration is
  `ca-west-1`. Do not hard-code a region or use `ca-central-1` for this vault.
- If runtime attaches a session policy, separate direct-field KMS encryption and
  decryption with `kms:EncryptionContext:estateId` from S3 SSE-KMS decryption and
  data-key generation with the regional `kms:ViaService` condition. Do not require
  `estateId` in the S3-managed encryption context.
- Every vault PUT must explicitly request `ServerSideEncryption: "aws:kms"` and
  `SSEKMSKeyId: STORAGE_S3_KMS_KEY_ID`. Pre-signed PUTs must sign the encryption
  headers and clients must send them. Use HTTPS endpoints only.
- **Before publishing, read the actual complete diff** and trace every credential
  helper and destructive call site. Reject a diff that collapses the two providers,
  supplies purge credentials to other functions, or bypasses the single-version
  deletion chokepoint. Record this specific review alongside fresh validation
  evidence; passing tests alone do not replace the diff review.
- The 2026-10-18 credential-split task is review-only: **do not publish until Nick
  reviews the changed-file list and credential-provider/purge-function diff and
  explicitly authorizes publication**. Do not restructure the app, rename existing
  functions, change UI, or add/remove features for this task. If the specified vault
  functions are absent from the checkout, obtain the correct source rather than
  inventing a replacement vault implementation.

## 29. Hybrid-Storage Document Freeze (MANDATORY — Nick, 2026-10-20)

Storage, delivery, audit, tenancy and export work never changes a legal document.
- No legal-document wording, citations, headings, paragraph or section order, field
  order, table structure, page breaks, spacing, margins, typography, signature
  blocks, jurat layout, checkbox layout, DOCX/PDF/HTML-preview output, rendering
  behaviour, legal decision logic, or form-selection logic may change as a storage,
  download, audit, tenancy or export workaround.
- `server/docgen.ts`, every form renderer and preview builder, and the document
  schema stay untouched by hybrid-storage patches. If a storage or delivery fix
  appears to require such a change, stop and obtain Nick's explicit, separate
  approval before editing anything.
- Canadian AWS storage of retained files does not establish Canadian-only
  processing or legal compliance; the application remains Manus-hosted. Make no
  compliance assertion without approved authority.
