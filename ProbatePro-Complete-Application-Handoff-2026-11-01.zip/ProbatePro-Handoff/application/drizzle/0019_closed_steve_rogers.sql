ALTER TABLE `estates` ADD `isMilitaryWill` varchar(8) DEFAULT 'no' NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `specialCircumstances` text DEFAULT ('none') NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `willLanguage` text DEFAULT ('english') NOT NULL;
