ALTER TABLE `contacts` ADD `deliveryMethod` varchar(16) DEFAULT 'mail' NOT NULL;--> statement-breakpoint
ALTER TABLE `contacts` ADD `deliveryDate` varchar(10) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `codicilCount` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `codicilDates` text DEFAULT ('') NOT NULL;