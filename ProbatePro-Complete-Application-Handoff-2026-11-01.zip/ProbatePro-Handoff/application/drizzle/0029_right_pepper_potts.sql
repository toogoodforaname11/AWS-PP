ALTER TABLE `estates` ADD `electronicWillLocked` varchar(8) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `electronicWillVerificationMethod` text DEFAULT ('') NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `electronicWillLockMethod` text DEFAULT ('') NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `electronicWillFormatDescription` text DEFAULT ('') NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `electronicWillRepositoryName` text DEFAULT ('') NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `electronicWillRepositoryAddress` text DEFAULT ('') NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `vsaCertificateResult` text DEFAULT ('no_notice') NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `vsaWillsNoticeDate` varchar(10) DEFAULT '' NOT NULL;
