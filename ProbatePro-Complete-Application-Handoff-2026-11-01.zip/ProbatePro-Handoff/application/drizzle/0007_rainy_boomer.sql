ALTER TABLE `estates` ADD `willStorageKey` text DEFAULT ('') NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `willFileName` text DEFAULT ('') NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `willMimeType` text DEFAULT ('') NOT NULL;
