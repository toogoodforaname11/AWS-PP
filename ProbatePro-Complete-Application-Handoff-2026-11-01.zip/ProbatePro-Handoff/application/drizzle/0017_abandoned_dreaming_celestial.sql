ALTER TABLE `contacts` ADD `isMinor` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `contacts` ADD `isMentallyIncapable` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `contacts` ADD `executorStatus` varchar(32) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `contacts` ADD `recipientType` varchar(64) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `contacts` ADD `renunciationReason` varchar(255) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `electronicWillFormat` text DEFAULT ('') NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `willFilingType` text DEFAULT ('physical_original') NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `treatyFirstNationName` text DEFAULT ('') NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `hasTestamentaryTrust` varchar(8) DEFAULT 'no' NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `trusteeNamed` varchar(8) DEFAULT 'no' NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `numberOfApplicants` int DEFAULT 1 NOT NULL;
