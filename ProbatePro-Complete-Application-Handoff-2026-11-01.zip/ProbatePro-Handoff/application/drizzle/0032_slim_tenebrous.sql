ALTER TABLE `estates` ADD `estateName` text DEFAULT ('') NOT NULL;
