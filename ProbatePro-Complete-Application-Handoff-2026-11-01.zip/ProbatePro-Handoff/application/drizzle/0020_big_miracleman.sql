ALTER TABLE `estates` ADD `limitedGrant` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `grantLimitation` text DEFAULT ('') NOT NULL;