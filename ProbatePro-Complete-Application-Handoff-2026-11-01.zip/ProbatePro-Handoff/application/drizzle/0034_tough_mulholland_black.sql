ALTER TABLE `estates` ADD `translatorName` text DEFAULT ('') NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `translatedDocument` text DEFAULT ('') NOT NULL;
