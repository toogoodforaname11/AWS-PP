CREATE TABLE `audit_log` (
	`id` varchar(36) NOT NULL,
	`event` varchar(64) NOT NULL,
	`ip` varchar(64) NOT NULL DEFAULT '',
	`userAgent` varchar(512) NOT NULL DEFAULT '',
	`detail` text,
	`estateId` varchar(36),
	`createdAt` bigint NOT NULL,
	CONSTRAINT `audit_log_id` PRIMARY KEY(`id`)
);
