CREATE TABLE `estate_notes` (
	`id` varchar(36) NOT NULL,
	`estateId` varchar(36) NOT NULL,
	`userId` int NOT NULL,
	`content` text NOT NULL,
	`pinned` int NOT NULL DEFAULT 0,
	`createdAt` bigint NOT NULL,
	`updatedAt` bigint NOT NULL,
	CONSTRAINT `estate_notes_id` PRIMARY KEY(`id`)
);
