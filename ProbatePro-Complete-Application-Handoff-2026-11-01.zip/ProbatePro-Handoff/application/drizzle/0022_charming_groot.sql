CREATE TABLE `contact_templates` (
	`id` varchar(36) NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`contacts` text NOT NULL DEFAULT ('[]'),
	`createdAt` bigint NOT NULL,
	CONSTRAINT `contact_templates_id` PRIMARY KEY(`id`)
);
