ALTER TABLE `contacts` ADD `applicantKind` varchar(32) DEFAULT 'individual' NOT NULL;--> statement-breakpoint
ALTER TABLE `contacts` ADD `serviceFax` varchar(64) DEFAULT '' NOT NULL;