ALTER TABLE `settings` ADD `firmPhone` varchar(50) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `settings` ADD `firmFax` varchar(50) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `settings` ADD `firmEmail` varchar(320) DEFAULT '' NOT NULL;