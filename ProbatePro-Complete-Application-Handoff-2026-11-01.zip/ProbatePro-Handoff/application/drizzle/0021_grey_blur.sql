ALTER TABLE `contacts` ADD `guardianName` varchar(255) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `settings` ADD `letterheadDocxKey` varchar(512) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `settings` ADD `letterheadDocxUrl` varchar(512) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `settings` ADD `letterheadDocxName` varchar(255) DEFAULT '' NOT NULL;