CREATE TABLE `activity` (
	`id` varchar(36) NOT NULL,
	`estateId` varchar(36) NOT NULL,
	`type` varchar(32) NOT NULL,
	`summary` text NOT NULL,
	`actor` varchar(128) NOT NULL DEFAULT '',
	`createdAt` bigint NOT NULL,
	CONSTRAINT `activity_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ai_imports` (
	`id` varchar(36) NOT NULL,
	`estateId` varchar(36) NOT NULL,
	`status` varchar(32) NOT NULL DEFAULT 'uploaded',
	`fileNames` text NOT NULL DEFAULT (''),
	`proposal` text NOT NULL DEFAULT (''),
	`appliedFields` text NOT NULL DEFAULT (''),
	`error` text NOT NULL DEFAULT (''),
	`createdAt` bigint NOT NULL,
	CONSTRAINT `ai_imports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `contacts` (
	`id` varchar(36) NOT NULL,
	`estateId` varchar(36) NOT NULL,
	`role` varchar(32) NOT NULL DEFAULT 'beneficiary',
	`name` varchar(255) NOT NULL DEFAULT '',
	`address` text NOT NULL DEFAULT (''),
	`addressForService` text NOT NULL DEFAULT (''),
	`email` varchar(320) NOT NULL DEFAULT '',
	`phone` varchar(32) NOT NULL DEFAULT '',
	`cityCountry` varchar(255) NOT NULL DEFAULT '',
	`relationship` varchar(128) NOT NULL DEFAULT '',
	CONSTRAINT `contacts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `documents` (
	`id` varchar(36) NOT NULL,
	`estateId` varchar(36) NOT NULL,
	`formCode` varchar(16) NOT NULL,
	`documentName` varchar(255) NOT NULL,
	`format` varchar(8) NOT NULL DEFAULT 'docx',
	`signatoryType` varchar(16) NOT NULL DEFAULT 'executor',
	`signatureDate` varchar(10) NOT NULL DEFAULT '',
	`exhibitStamp` int NOT NULL DEFAULT 0,
	`storageKey` varchar(512) NOT NULL DEFAULT '',
	`storageUrl` varchar(512) NOT NULL DEFAULT '',
	`generatedBy` varchar(128) NOT NULL DEFAULT '',
	`createdAt` bigint NOT NULL,
	CONSTRAINT `documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `estate_access` (
	`id` varchar(36) NOT NULL,
	`estateId` varchar(36) NOT NULL,
	`email` varchar(320) NOT NULL,
	`contactName` varchar(255) NOT NULL DEFAULT '',
	`accessToken` varchar(128) NOT NULL,
	`active` int NOT NULL DEFAULT 1,
	`lastLoginAt` bigint NOT NULL DEFAULT 0,
	`createdAt` bigint NOT NULL,
	CONSTRAINT `estate_access_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `estates` (
	`id` varchar(36) NOT NULL,
	`fileNumber` int NOT NULL,
	`fileType` text NOT NULL DEFAULT ('probate_only'),
	`status` text NOT NULL DEFAULT ('incomplete'),
	`assignee` text NOT NULL DEFAULT (''),
	`registry` text NOT NULL DEFAULT (''),
	`deceasedFirstName` text NOT NULL DEFAULT (''),
	`deceasedMiddleNames` text NOT NULL DEFAULT (''),
	`deceasedLastName` text NOT NULL DEFAULT (''),
	`deceasedAliases` text NOT NULL DEFAULT (''),
	`deceasedAddress` text NOT NULL DEFAULT (''),
	`dateOfBirth` varchar(10) NOT NULL DEFAULT '',
	`dateOfDeath` varchar(10) NOT NULL DEFAULT '',
	`maritalStatus` text NOT NULL DEFAULT (''),
	`domicileCity` text NOT NULL DEFAULT (''),
	`domicileCountry` text NOT NULL DEFAULT ('Canada'),
	`hasWill` int NOT NULL DEFAULT 1,
	`willDate` varchar(10) NOT NULL DEFAULT '',
	`isElectronicWill` int NOT NULL DEFAULT 0,
	`grantType` text NOT NULL DEFAULT ('grant_of_probate'),
	`p1DeliveredDate` varchar(10) NOT NULL DEFAULT '',
	`p2FiledDate` varchar(10) NOT NULL DEFAULT '',
	`grantIssuedDate` varchar(10) NOT NULL DEFAULT '',
	`createdAt` bigint NOT NULL,
	`createdByUserId` int,
	CONSTRAINT `estates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `inventory` (
	`id` varchar(36) NOT NULL,
	`estateId` varchar(36) NOT NULL,
	`category` varchar(32) NOT NULL DEFAULT 'financial',
	`description` text NOT NULL DEFAULT (''),
	`location` varchar(16) NOT NULL DEFAULT 'in_bc',
	`value` bigint NOT NULL DEFAULT 0,
	CONSTRAINT `inventory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `required_documents` (
	`id` varchar(36) NOT NULL,
	`estateId` varchar(36) NOT NULL,
	`docKey` varchar(64) NOT NULL,
	`received` int NOT NULL DEFAULT 0,
	`receivedDate` varchar(10) NOT NULL DEFAULT '',
	`notes` text NOT NULL DEFAULT (''),
	CONSTRAINT `required_documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`id` varchar(16) NOT NULL,
	`letterheadStorageKey` varchar(512) NOT NULL DEFAULT '',
	`letterheadStorageUrl` varchar(512) NOT NULL DEFAULT '',
	`letterheadMime` varchar(32) NOT NULL DEFAULT '',
	`letterheadName` varchar(255) NOT NULL DEFAULT '',
	`letterheadWidth` int NOT NULL DEFAULT 0,
	`letterheadHeight` int NOT NULL DEFAULT 0,
	`firmName` varchar(255) NOT NULL DEFAULT '',
	`firmAddress` text NOT NULL DEFAULT (''),
	`updatedAt` bigint NOT NULL DEFAULT 0,
	CONSTRAINT `settings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wills_search` (
	`id` varchar(36) NOT NULL,
	`estateId` varchar(36) NOT NULL,
	`status` varchar(32) NOT NULL DEFAULT 'not_started',
	`method` varchar(16) NOT NULL DEFAULT 'mail',
	`submittedDate` varchar(10) NOT NULL DEFAULT '',
	`expectedByDate` varchar(10) NOT NULL DEFAULT '',
	`resultReceivedDate` varchar(10) NOT NULL DEFAULT '',
	`outcome` varchar(32) NOT NULL DEFAULT '',
	`willDateSigned` varchar(10) NOT NULL DEFAULT '',
	`willLocation` text NOT NULL DEFAULT (''),
	`noticeReceivedDate` varchar(10) NOT NULL DEFAULT '',
	`aliases` text NOT NULL DEFAULT (''),
	`referenceNumber` varchar(64) NOT NULL DEFAULT '',
	`courierRequested` int NOT NULL DEFAULT 0,
	`notes` text NOT NULL DEFAULT (''),
	CONSTRAINT `wills_search_id` PRIMARY KEY(`id`)
);
