ALTER TABLE `settings` ADD `letterClosing` varchar(100) DEFAULT 'Yours truly,' NOT NULL;--> statement-breakpoint
ALTER TABLE `settings` ADD `letterShowPerLine` boolean DEFAULT true NOT NULL;