ALTER TABLE `estate_notes` ADD `tag` varchar(64);--> statement-breakpoint
ALTER TABLE `estate_notes` ADD `attachmentKey` varchar(512);--> statement-breakpoint
ALTER TABLE `estate_notes` ADD `attachmentUrl` varchar(512);--> statement-breakpoint
ALTER TABLE `estate_notes` ADD `attachmentName` varchar(255);--> statement-breakpoint
ALTER TABLE `estate_notes` ADD `attachmentType` varchar(64);