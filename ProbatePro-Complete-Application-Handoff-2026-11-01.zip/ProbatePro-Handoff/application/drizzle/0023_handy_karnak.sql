ALTER TABLE `contact_templates` MODIFY COLUMN `contacts` text NOT NULL;--> statement-breakpoint
ALTER TABLE `settings` ADD `suppressFirmText` boolean DEFAULT false NOT NULL;