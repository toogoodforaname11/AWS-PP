ALTER TABLE `estates` ADD `executionIssueDescription` text NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `alterationsDescription` text NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `militaryWillDescription` text NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `foreignWillDescription` text NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `willCopyDescription` text NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `laterTestamentaryDescription` text NOT NULL;
