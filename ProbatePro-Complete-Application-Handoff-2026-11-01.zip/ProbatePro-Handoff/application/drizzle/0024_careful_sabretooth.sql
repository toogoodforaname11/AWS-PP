CREATE TABLE `document_versions` (
	`id` varchar(36) NOT NULL,
	`estateId` varchar(36) NOT NULL,
	`formCode` varchar(16) NOT NULL,
	`documentName` varchar(255) NOT NULL,
	`format` varchar(8) NOT NULL DEFAULT 'docx',
	`storageKey` varchar(512) NOT NULL DEFAULT '',
	`storageUrl` varchar(512) NOT NULL DEFAULT '',
	`generatedBy` varchar(128) NOT NULL DEFAULT '',
	`createdAt` bigint NOT NULL,
	CONSTRAINT `document_versions_id` PRIMARY KEY(`id`)
);
