ALTER TABLE `activity` MODIFY COLUMN `summary` varchar(2000) NOT NULL;--> statement-breakpoint
ALTER TABLE `ai_imports` MODIFY COLUMN `fileNames` varchar(2000) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `ai_imports` MODIFY COLUMN `proposal` varchar(10000) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `ai_imports` MODIFY COLUMN `appliedFields` text NOT NULL;--> statement-breakpoint
ALTER TABLE `ai_imports` MODIFY COLUMN `error` varchar(2000) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `audit_log` MODIFY COLUMN `detail` varchar(2000);--> statement-breakpoint
ALTER TABLE `contact_templates` MODIFY COLUMN `contacts` varchar(10000) NOT NULL;--> statement-breakpoint
ALTER TABLE `contacts` MODIFY COLUMN `address` varchar(500) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `contacts` MODIFY COLUMN `addressForService` varchar(500) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `estate_notes` MODIFY COLUMN `content` varchar(10000) NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` MODIFY COLUMN `deceasedAliases` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `estates` MODIFY COLUMN `deceasedAddress` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `estates` MODIFY COLUMN `altResidenceAddress` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `estates` MODIFY COLUMN `otherGrantsDescription` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `estates` MODIFY COLUMN `electronicWillVerificationMethod` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `estates` MODIFY COLUMN `electronicWillLockMethod` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `estates` MODIFY COLUMN `electronicWillRepositoryAddress` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `estates` MODIFY COLUMN `grantLimitation` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `estates` MODIFY COLUMN `codicilDates` text NOT NULL DEFAULT ('');--> statement-breakpoint
ALTER TABLE `estates` MODIFY COLUMN `codicilFiles` text;--> statement-breakpoint
ALTER TABLE `estates` MODIFY COLUMN `notes` text NOT NULL;--> statement-breakpoint
ALTER TABLE `inventory` MODIFY COLUMN `description` varchar(1000) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `required_documents` MODIFY COLUMN `notes` varchar(5000) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `settings` MODIFY COLUMN `firmAddress` varchar(500) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `settings` MODIFY COLUMN `letterBodyTemplate` varchar(10000) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `name` varchar(255);--> statement-breakpoint
ALTER TABLE `wills_search` MODIFY COLUMN `willLocation` varchar(500) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `wills_search` MODIFY COLUMN `aliases` varchar(1000) NOT NULL DEFAULT '';--> statement-breakpoint
ALTER TABLE `wills_search` MODIFY COLUMN `notes` varchar(5000) NOT NULL DEFAULT '';
