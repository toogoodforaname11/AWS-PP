ALTER TABLE `settings` MODIFY COLUMN `id` varchar(36) NOT NULL;--> statement-breakpoint
ALTER TABLE `settings` ADD `userId` int DEFAULT 0 NOT NULL;