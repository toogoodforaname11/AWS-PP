ALTER TABLE `estates` ADD `referencedDocumentNames` text DEFAULT ('') NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `orderDescription` text DEFAULT ('') NOT NULL;--> statement-breakpoint
ALTER TABLE `estates` ADD `certifiedCopies` int DEFAULT 3 NOT NULL;
