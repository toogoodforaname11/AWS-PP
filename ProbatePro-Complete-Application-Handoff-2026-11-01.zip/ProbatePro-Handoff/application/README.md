# ProbatePro — BC Probate Law-Practice Software

ProbatePro is a paralegal/lawyer workbench for managing British Columbia probate estate files end-to-end: intake of the deceased and parties, tracking assets and liabilities, computing intestacy distribution and probate fees, tracking statutory deadlines, and generating the official BC Supreme Court Rule 25 probate forms (P1–P46 + VSA 532) as court-ready DOCX with live HTML previews.

> **Scope:** BC only (WESA + Supreme Court Civil Rules Part 25). Not legal advice — documents are prepared for professional review.

## Tech Stack

- **Frontend:** React 19, Vite 7, Tailwind CSS 4, shadcn/ui, TanStack Query, tRPC v11
- **Backend:** Express 4, tRPC v11, Drizzle ORM, MySQL (TiDB Cloud serverless)
- **Document generation:** `docx` library (DOCX) + HTML preview mirror
- **Auth:** Manus OAuth (staff), tokenized portal sessions (executor/client)
- **Storage:** AWS S3 (documents, letterhead, wills, codicils, consent letters)

## Quick Start

```bash
# Install dependencies
pnpm install

# Run dev server (Express + Vite HMR)
pnpm dev

# Type check
pnpm check

# Run tests
pnpm test

# Build for production
pnpm build
```

### Local development — file storage

A bare `pnpm dev` with no `STORAGE_S3_*`/`LEGAL_RECORD_STORAGE_APPROVED` env
configured auto-defaults to an isolated local MinIO profile
(`http://127.0.0.1:9000`, bucket `probatepro-dev`, `minioadmin`/`minioadmin`).
One-time setup:

```bash
docker run -d -p 9000:9000 --name probatepro-minio minio/minio server /data
# then create the "probatepro-dev" bucket via the MinIO console at :9000
```

Production requires the approved AWS Canada profile and never falls back to
this dev default. AI features stay off unless `AI_PROCESSOR_APPROVED=true`
(see `chatbot/README.md`, Security residuals #2).

## Project Structure

```
client/src/      React SPA (pages, components, hooks)
server/          Express entry, tRPC routers, docgen builders, DB helpers
shared/          Domain rules, form requirements, date utilities, types
drizzle/         Schema and migration SQL
references/      Integration specs and reference notes
```

## Documentation

Detailed architecture, decisions, and legislative references live in the ProbatePro second brain (Obsidian vault):

- `C:\Users\nick\OneDrive\Desktop\Probate Software`
- Start with `DASHBOARD.md`, `CLAUDE.md`, `SOUL.md`, and `AGENTS.md`.

## Testing

The suite is the project's health metric. Every legislative rule change gets tests.

```bash
pnpm test        # vitest run
pnpm check       # tsc --noEmit
```

## License

MIT
