import { afterEach, describe, expect, it, vi } from "vitest";
import { getLoginUrlAsync, redirectToLogin } from "./const";

describe("CSRF-protected login bootstrap", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
    document.getElementById("probatepro-auth-start-error")?.remove();
  });

  it("deduplicates concurrent login starts and shows one actionable fail-closed alert", async () => {
    const fetchMock = vi.fn().mockRejectedValue(new Error("rate limited"));
    vi.stubGlobal("fetch", fetchMock);
    const errorSpy = vi.spyOn(console, "error").mockImplementation(() => undefined);

    redirectToLogin();
    redirectToLogin();
    await new Promise(resolve => setTimeout(resolve, 0));

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const alert = document.getElementById("probatepro-auth-start-error");
    expect(alert?.getAttribute("role")).toBe("alert");
    expect(alert?.textContent).toMatch(/We couldn’t start sign-in/i);
    expect(alert?.textContent).toMatch(/Try again/i);
    errorSpy.mockRestore();
  });

  it("requests a fresh, non-cacheable server-issued login URL", async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      json: vi.fn().mockResolvedValue({ loginUrl: "https://portal.example.com/app-auth?state=fresh" }),
    });
    vi.stubGlobal("fetch", fetchMock);

    await expect(getLoginUrlAsync("/settings")).resolves.toContain("https://portal.example.com/");
    expect(fetchMock).toHaveBeenCalledWith(
      expect.stringContaining("returnPath=%2Fsettings"),
      expect.objectContaining({ credentials: "include", cache: "no-store" }),
    );
  });

  it("rejects malformed OAuth bootstrap responses instead of navigating to an unsafe value", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({
      ok: true,
      json: vi.fn().mockResolvedValue({ loginUrl: "javascript:alert(1)" }),
    }));

    await expect(getLoginUrlAsync()).rejects.toThrow("invalid redirect");
  });
});
