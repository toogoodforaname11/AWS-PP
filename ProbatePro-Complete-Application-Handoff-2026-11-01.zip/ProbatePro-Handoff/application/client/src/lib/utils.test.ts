import { afterEach, describe, expect, it, vi } from "vitest";
import { downloadFromUrl, previewStoredFile } from "./utils";

describe("stored-file browser navigation", () => {
  afterEach(() => {
    vi.restoreAllMocks();
    document.body.innerHTML = "";
  });

  it("previews through a same-origin proxy navigation without fetching S3", () => {
    const open = vi.spyOn(window, "open").mockReturnValue({} as Window);
    const fetchSpy = vi.spyOn(globalThis, "fetch");

    previewStoredFile("notes/7/estate-1/file one.pdf");

    expect(open).toHaveBeenCalledWith(
      "/manus-storage/notes/7/estate-1/file%20one.pdf",
      "_blank",
      "noopener,noreferrer",
    );
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it("downloads storage objects through an attachment-first same-tab navigation", () => {
    let clicked: HTMLAnchorElement | null = null;
    vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(function () {
      clicked = this;
    });

    downloadFromUrl("/manus-storage/documents/p10.docx", "P10 — Estate.docx");

    expect(clicked?.getAttribute("href")).toBe(
      "/manus-storage/documents/p10.docx?download=P10%20%E2%80%94%20Estate.docx",
    );
    expect(clicked?.getAttribute("download")).toBe("P10 — Estate.docx");
    expect(clicked?.target).toBe("");
    expect(document.body.querySelector("iframe")).toBeNull();
    expect(document.body.querySelector("a")).toBeNull();
  });
});
