/**
 * Task 12: the preview's bounded body reader and its modal-side helpers. Real Response/ReadableStream bodies, fake
 * timers where a timer matters, byte comparison through Array.from (jsdom's Uint8Array and Node's Response are
 * different realms). Fictional data only.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { existsSync, readdirSync, readFileSync } from "node:fs";
import path from "node:path";
import { hashKey } from "@tanstack/react-query";
import { browserResponse, chunkedStream, stalledStream } from "./browserResponse.testkit";
import { clearFallbackSession, clientSessionGeneration } from "./fallbackSession";
import { createTrpcTransportFetch } from "./trpcTransport";
import {
  PREVIEW_BODY_CEILING_BYTES,
  PREVIEW_BODY_IDLE_TIMEOUT_MS,
  PREVIEW_BODY_TOTAL_TIMEOUT_MS,
  PREVIEW_REFUSAL_BODY_LIMIT_BYTES,
  PREVIEW_UNAVAILABLE_SENTENCE,
  PreviewPayloadError,
  PreviewTransportError,
  createPreviewTransportFetch,
  previewErrorMessage,
  previewQueryKeyHash,
  previewRetry,
  validatePreviewPayload,
} from "./previewTransport";

const encoder = new TextEncoder();
const JSON_TYPE = "application/json";
const bytesOf = (text: string) => encoder.encode(text);
const NEUTRAL = "The preview could not be loaded. Please try again.";

/** A tRPC/SuperJSON success envelope for fictional sections, as the server sends it. */
const envelope = (sections: unknown[]) => JSON.stringify({ result: { data: { json: { formCode: "P1", formName: "Fictional", sections } } } });

/** A stream that counts pulls, hands out `chunks` one per pull, records cancellation, and runs `onPull` first. */
function countingStream(chunks: Uint8Array[], hooks: { onPull?: (pull: number, controller: ReadableStreamDefaultController<Uint8Array>) => void | "stop" } = {}) {
  const state = { pulls: 0, cancelled: 0, cancelReason: undefined as unknown };
  const stream = new ReadableStream<Uint8Array>({
    pull(controller) {
      state.pulls += 1;
      if (hooks.onPull?.(state.pulls, controller) === "stop") return;
      const next = chunks[state.pulls - 1];
      if (next) controller.enqueue(next);
      else controller.close();
    },
    cancel(reason) { state.cancelled += 1; state.cancelReason = reason; },
  }, { highWaterMark: 0 });
  return { stream, state };
}

const jsonResponse = (body: string | Uint8Array | ReadableStream<Uint8Array> | null, init: ResponseInit = {}) =>
  browserResponse(body, { status: 200, headers: { "content-type": JSON_TYPE }, ...init });

const wrap = (response: Response | (() => Response | Promise<Response>)) => {
  const inner = vi.fn(async (_input: RequestInfo | URL, _init?: RequestInit) => (typeof response === "function" ? await response() : response));
  return { inner, fetch: createPreviewTransportFetch(inner) };
};

const rejection = async (promise: Promise<unknown>) => {
  try { await promise; } catch (error) { return error; }
  throw new Error("expected a rejection");
};

const isPreviewError = (error: unknown, reason: string) =>
  error instanceof PreviewTransportError && error.reason === reason && error.message === NEUTRAL;

afterEach(() => {
  vi.useRealTimers();
  sessionStorage.clear();
});

describe("createPreviewTransportFetch — ceiling (U1)", () => {
  const limit = PREVIEW_BODY_CEILING_BYTES;
  // The last character is a 4-byte astral sequence, split across the chunk boundary.
  const bodyOf = (bytes: number) => "a".repeat(bytes - 4) + "😀";

  it("accepts a body of exactly the ceiling and reassembles a multi-byte sequence split across chunks", async () => {
    const text = bodyOf(limit);
    const all = bytesOf(text);
    expect(all.byteLength).toBe(limit);
    const { stream, state } = countingStream([all.subarray(0, limit - 2), all.subarray(limit - 2)]);
    const { fetch } = wrap(jsonResponse(stream));
    const out = await fetch("/api/trpc/document.preview", { method: "GET" });
    expect(out.status).toBe(200);
    expect(await out.text()).toBe(text);
    expect(state.pulls).toBe(3);
    expect(state.cancelled).toBe(0);
  });

  it("accepts a body one byte under the ceiling", async () => {
    const text = bodyOf(limit - 1);
    const { stream } = countingStream([bytesOf(text)]);
    const { fetch } = wrap(jsonResponse(stream));
    const out = await fetch("/api/trpc/document.preview", { method: "GET" });
    expect(await out.text()).toBe(text);
  });

  it("refuses a body one byte over the ceiling at the first chunk that crosses it and reads no further", async () => {
    const all = bytesOf(bodyOf(limit + 1));
    expect(all.byteLength).toBe(limit + 1);
    const { stream, state } = countingStream([all.subarray(0, limit - 2), all.subarray(limit - 2), bytesOf("never")]);
    const { fetch } = wrap(jsonResponse(stream));
    const error = await rejection(fetch("/api/trpc/document.preview", { method: "GET" }));
    expect(isPreviewError(error, "too-large")).toBe(true);
    expect(state.pulls).toBe(2);
    expect(state.cancelled).toBe(1);
  });
});

describe("createPreviewTransportFetch — headers are ignored (U2)", () => {
  const body = "0123456789";
  for (const [label, headers] of [
    ["absent", {}],
    ["non-numeric", { "content-length": "ten" }],
    ["overstated", { "content-length": "999" }],
    ["understated", { "content-length": "2" }],
    ["over the limit", { "content-length": String(PREVIEW_BODY_CEILING_BYTES * 2) }],
    ["gzip with a lying length", { "content-length": "2", "content-encoding": "gzip" }],
  ] as const) {
    it(`Content-Length ${label}: the decoded byte count alone decides`, async () => {
      const { fetch } = wrap(browserResponse(chunkedStream([bytesOf(body)]), { status: 200, headers: { "content-type": JSON_TYPE, ...headers } }));
      const out = await fetch("/api/trpc/document.preview", { method: "GET" });
      expect(await out.text()).toBe(body);
    });
  }

  it("refuses a 2xx that is not JSON before reading a single chunk", async () => {
    const { stream, state } = countingStream([bytesOf("<html>login</html>")]);
    const { fetch } = wrap(browserResponse(stream, { status: 200, headers: { "content-type": "text/html" } }));
    const error = await rejection(fetch("/api/trpc/document.preview", { method: "GET" }));
    expect(isPreviewError(error, "not-json")).toBe(true);
    expect(state.pulls).toBe(0);
    expect(state.cancelled).toBe(1);
  });
});

describe("createPreviewTransportFetch — refusal bodies (U3)", () => {
  for (const status of [400, 500]) {
    it(`passes a ${status} JSON body of exactly ${PREVIEW_REFUSAL_BODY_LIMIT_BYTES} bytes through unchanged`, async () => {
      const text = "{" + "\"x\":\"" + "y".repeat(PREVIEW_REFUSAL_BODY_LIMIT_BYTES - 8) + "\"}";
      expect(bytesOf(text).byteLength).toBe(PREVIEW_REFUSAL_BODY_LIMIT_BYTES);
      const { fetch } = wrap(jsonResponse(chunkedStream([bytesOf(text)]), { status }));
      const out = await fetch("/api/trpc/document.preview", { method: "GET" });
      expect(out.status).toBe(status);
      expect(await out.text()).toBe(text);
    });

    it(`refuses a ${status} JSON body one byte over the refusal bound`, async () => {
      const text = "{" + "\"x\":\"" + "y".repeat(PREVIEW_REFUSAL_BODY_LIMIT_BYTES - 7) + "\"}";
      expect(bytesOf(text).byteLength).toBe(PREVIEW_REFUSAL_BODY_LIMIT_BYTES + 1);
      const { stream, state } = countingStream([bytesOf(text)]);
      const { fetch } = wrap(jsonResponse(stream, { status }));
      const error = await rejection(fetch("/api/trpc/document.preview", { method: "GET" }));
      expect(isPreviewError(error, "too-large")).toBe(true);
      expect(state.cancelled).toBe(1);
    });
  }

  it("U3a: a realistic BAD_REQUEST envelope with a zod issue list stays under the bound and reaches tRPC verbatim", async () => {
    const zodError = { issues: Array.from({ length: 12 }, (_, i) => ({ code: "invalid_type", path: ["overrides", `field${i}`], message: "Expected string, received number" })) };
    const text = JSON.stringify({ error: { json: { message: "Choose the executor who signs this affidavit.", code: -32600, data: { code: "BAD_REQUEST", httpStatus: 400, zodError } } } });
    expect(bytesOf(text).byteLength).toBeLessThan(PREVIEW_REFUSAL_BODY_LIMIT_BYTES);
    const { fetch } = wrap(jsonResponse(chunkedStream([bytesOf(text)]), { status: 400 }));
    const out = await fetch("/api/trpc/document.preview", { method: "GET" });
    expect(out.status).toBe(400);
    expect(await out.text()).toBe(text);
  });
});

describe("createPreviewTransportFetch — no-body responses (U4)", () => {
  it("returns a 204 unchanged", async () => {
    const response = new Response(null, { status: 204 });
    const { fetch } = wrap(response);
    expect(await fetch("/api/trpc/document.preview", { method: "GET" })).toBe(response);
  });

  it("returns a null-body 200 unchanged", async () => {
    const response = new Response(null, { status: 200, headers: { "content-type": JSON_TYPE } });
    const { fetch } = wrap(response);
    expect(await fetch("/api/trpc/document.preview", { method: "GET" })).toBe(response);
  });
});

describe("createPreviewTransportFetch — abort (U5, U10, U11)", () => {
  it("U10: an abort that lands after the inner fetch resolved and before the first read cancels the body and rethrows the reason", async () => {
    const controller = new AbortController();
    const reason = new DOMException("Closed", "AbortError");
    const { stream, state } = countingStream([bytesOf("{}")]);
    const response = jsonResponse(stream);
    const { fetch } = wrap(() => Promise.resolve(response).then((r) => { controller.abort(reason); return r; }));
    const error = await rejection(fetch("/api/trpc/document.preview", { method: "GET", signal: controller.signal }));
    expect(error).toBe(reason);
    expect(state.pulls).toBe(0);
    expect(state.cancelled).toBe(1);
  });

  it("U5: an abort during the first read cancels the reader once, leaves no timer and rethrows the signal's reason", async () => {
    vi.useFakeTimers();
    const controller = new AbortController();
    const reason = new DOMException("Closed", "AbortError");
    let cancelled = 0;
    const stream = stalledStream(null, () => { cancelled += 1; });
    const { fetch } = wrap(jsonResponse(stream));
    const pending = fetch("/api/trpc/document.preview", { method: "GET", signal: controller.signal });
    const settled = rejection(pending);
    await vi.advanceTimersByTimeAsync(0);
    controller.abort(reason);
    expect(await settled).toBe(reason);
    expect(cancelled).toBe(1);
    expect(stream.locked).toBe(true);
    expect(vi.getTimerCount()).toBe(0);
  });

  it("U5: an abort between two chunks rethrows the reason and never yields a Response", async () => {
    const controller = new AbortController();
    const reason = new DOMException("Closed", "AbortError");
    const { stream, state } = countingStream([bytesOf("{\"a\":"), bytesOf("1}")], {
      onPull: (pull) => { if (pull === 2) controller.abort(reason); },
    });
    const { fetch } = wrap(jsonResponse(stream));
    const error = await rejection(fetch("/api/trpc/document.preview", { method: "GET", signal: controller.signal }));
    expect(error).toBe(reason);
    expect(state.cancelled).toBe(1);
  });

  it("U11: a stop decided while a read is pending outranks that read's `done`", async () => {
    const controller = new AbortController();
    const reason = new DOMException("Closed", "AbortError");
    const { stream } = countingStream([bytesOf("{\"sections\":[]}")], {
      onPull: (pull, streamController) => {
        if (pull === 2) { controller.abort(reason); streamController.close(); return "stop"; }
      },
    });
    const { fetch } = wrap(jsonResponse(stream));
    const error = await rejection(fetch("/api/trpc/document.preview", { method: "GET", signal: controller.signal }));
    expect(error).toBe(reason);
  });

  it("U11: a body timeout decided while a read is pending outranks that read's `done`", async () => {
    vi.useFakeTimers();
    const { stream } = countingStream([bytesOf("{\"sections\":[]}")], {
      onPull: (pull, streamController) => {
        if (pull === 2) { vi.advanceTimersByTime(PREVIEW_BODY_IDLE_TIMEOUT_MS); streamController.close(); return "stop"; }
      },
    });
    const { fetch } = wrap(jsonResponse(stream));
    const error = await rejection(fetch("/api/trpc/document.preview", { method: "GET" }));
    expect(isPreviewError(error, "body-timeout")).toBe(true);
  });
});

describe("createPreviewTransportFetch — body timers (U6)", () => {
  beforeEach(() => { vi.useFakeTimers(); });

  it("cuts a stream that stalls between chunks at the idle timeout, cancelling the reader and clearing every timer", async () => {
    let cancelled = 0;
    const stream = stalledStream(bytesOf("{\"sections\":"), () => { cancelled += 1; });
    const { fetch } = wrap(jsonResponse(stream));
    const settled = rejection(fetch("/api/trpc/document.preview", { method: "GET" }));
    await vi.advanceTimersByTimeAsync(PREVIEW_BODY_IDLE_TIMEOUT_MS - 1);
    expect(cancelled).toBe(0);
    await vi.advanceTimersByTimeAsync(1);
    expect(isPreviewError(await settled, "body-timeout")).toBe(true);
    expect(cancelled).toBe(1);
    expect(vi.getTimerCount()).toBe(0);
  });

  it("U6a: a body that never yields its first chunk is cut by the idle timer (armed before the first read)", async () => {
    let cancelled = 0;
    const stream = stalledStream(null, () => { cancelled += 1; });
    const { fetch } = wrap(jsonResponse(stream));
    const settled = rejection(fetch("/api/trpc/document.preview", { method: "GET" }));
    await vi.advanceTimersByTimeAsync(PREVIEW_BODY_IDLE_TIMEOUT_MS);
    expect(isPreviewError(await settled, "body-timeout")).toBe(true);
    expect(cancelled).toBe(1);
    expect(vi.getTimerCount()).toBe(0);
  });

  it("cuts a trickle that never idles at the total timeout", async () => {
    const tick = 10_000;
    let cancelled = 0;
    let pulls = 0;
    const stream = new ReadableStream<Uint8Array>({
      pull(controller) {
        pulls += 1;
        return new Promise<void>((resolve) => { setTimeout(() => { try { controller.enqueue(bytesOf("x")); } catch { /* cancelled meanwhile */ } resolve(); }, tick); });
      },
      cancel() { cancelled += 1; },
    }, { highWaterMark: 0 });
    const { fetch } = wrap(jsonResponse(stream));
    const settled = rejection(fetch("/api/trpc/document.preview", { method: "GET" }));
    await vi.advanceTimersByTimeAsync(PREVIEW_BODY_TOTAL_TIMEOUT_MS - 1);
    expect(cancelled).toBe(0);
    await vi.advanceTimersByTimeAsync(1);
    expect(isPreviewError(await settled, "body-timeout")).toBe(true);
    expect(cancelled).toBe(1);
    expect(pulls).toBeGreaterThan(1);
    expect(vi.getTimerCount()).toBe(0);
  });
});

describe("createPreviewTransportFetch — stream errors and success (U7, U8, U12)", () => {
  it("U7: a stream error mid-body is `incomplete` and no Response is produced", async () => {
    const { stream } = countingStream([bytesOf("{\"sec")], {
      onPull: (pull, controller) => { if (pull === 2) { controller.error(new Error("connection reset")); return "stop"; } },
    });
    const { fetch } = wrap(jsonResponse(stream));
    const error = await rejection(fetch("/api/trpc/document.preview", { method: "GET" }));
    expect(isPreviewError(error, "incomplete")).toBe(true);
  });

  it("U8: the rebuilt Response carries only the status and content-type and a byte-identical body, Unicode intact", async () => {
    const sections = [
      { type: "paragraph", text: "Wiedźmin 😀 — café x" },
      { type: "heading", text: "é combining, NBSP here", center: true },
    ];
    const text = envelope(sections);
    const bytes = bytesOf(text);
    const { fetch } = wrap(browserResponse(chunkedStream([bytes.subarray(0, 7), bytes.subarray(7)]), { status: 200, headers: { "content-type": "application/json; charset=utf-8", "content-length": String(bytes.byteLength), "x-rotated-session": "never-copied" } }));
    const signal = new AbortController().signal;
    const added = vi.spyOn(signal, "addEventListener");
    const removed = vi.spyOn(signal, "removeEventListener");
    const out = await fetch("/api/trpc/document.preview", { method: "GET", signal });
    expect(out.status).toBe(200);
    expect(out.statusText).toBe("");
    // The body-phase abort listener is attached once and removed on the success exit.
    expect(added).toHaveBeenCalledTimes(1);
    expect(removed).toHaveBeenCalledTimes(1);
    expect(removed.mock.calls[0][1]).toBe(added.mock.calls[0][1]);
    expect(Array.from(out.headers.keys())).toEqual(["content-type"]);
    expect(out.headers.get("content-type")).toBe("application/json; charset=utf-8");
    const outBytes = new Uint8Array(await out.clone().arrayBuffer());
    expect(Array.from(outBytes)).toEqual(Array.from(bytes));
    const json = await out.json();
    expect(json.result.data.json.sections).toEqual(sections);
  });

  it("U12: the transport's synthetic 503 envelope passes through intact and parses as the same envelope", async () => {
    const fetchImpl = vi.fn(async () => new Response("<html>gateway</html>", { status: 503, headers: { "content-type": "text/html" } }));
    const transport = createTrpcTransportFetch({ fetchImpl, retryDelayMs: () => 0 });
    const fetch = createPreviewTransportFetch(transport);
    const out = await fetch("/api/trpc/document.preview", { method: "GET" });
    expect(out.status).toBe(503);
    expect(Array.from(out.headers.keys())).toEqual(["content-type"]);
    // The transport's sentence for an HTML 5xx that survives its retries (trpcTransport.ts, the non-JSON branch).
    await expect(out.json()).resolves.toMatchObject({ error: { json: { message: "Server returned an error (503). Please try again.", data: { code: "INTERNAL_SERVER_ERROR", httpStatus: 503 } } } });
  });
});

describe("createPreviewTransportFetch — session guard (U13)", () => {
  it("a session end between the headers and the first read cancels the body and fails as session-ended", async () => {
    const { stream, state } = countingStream([bytesOf("{}")]);
    const response = jsonResponse(stream);
    const { fetch } = wrap(() => Promise.resolve(response).then((r) => { clearFallbackSession(); return r; }));
    const error = await rejection(fetch("/api/trpc/document.preview", { method: "GET" }));
    expect(isPreviewError(error, "session-ended")).toBe(true);
    expect(state.pulls).toBe(0);
    expect(state.cancelled).toBe(1);
    expect(Object.keys(error as object)).toEqual(["reason"]);
    expect((error as { cause?: unknown }).cause).toBeUndefined();
  });

  it("a session end between two chunks cancels the reader and drops the bytes", async () => {
    const { stream, state } = countingStream([bytesOf("{\"a\":"), bytesOf("1}")], {
      onPull: (pull) => { if (pull === 2) clearFallbackSession(); },
    });
    const { fetch } = wrap(jsonResponse(stream));
    const error = await rejection(fetch("/api/trpc/document.preview", { method: "GET" }));
    expect(isPreviewError(error, "session-ended")).toBe(true);
    expect(state.cancelled).toBe(1);
  });

  it("a rotated token stored mid-body is accepted and the Response is rebuilt byte-identical", async () => {
    sessionStorage.setItem("manus-cookie", "app_session_id=fictional-a");
    const text = envelope([{ type: "paragraph", text: "rotation keeps the preview" }]);
    const bytes = bytesOf(text);
    const { stream } = countingStream([bytes.subarray(0, 9), bytes.subarray(9)], {
      onPull: (pull) => { if (pull === 2) sessionStorage.setItem("manus-cookie", "app_session_id=fictional-b"); },
    });
    const { fetch } = wrap(jsonResponse(stream));
    const out = await fetch("/api/trpc/document.preview", { method: "GET" });
    expect(Array.from(new Uint8Array(await out.arrayBuffer()))).toEqual(Array.from(bytes));
  });

  it("U16: a request that is both aborted and past a session end rejects with the abort reason, never as session-ended", async () => {
    const controller = new AbortController();
    const reason = new DOMException("Closed", "AbortError");
    const { stream, state } = countingStream([bytesOf("{}")]);
    const response = jsonResponse(stream);
    const { fetch } = wrap(() => Promise.resolve(response).then((r) => { controller.abort(reason); clearFallbackSession(); return r; }));
    const error = await rejection(fetch("/api/trpc/document.preview", { method: "GET", signal: controller.signal }));
    expect(error).toBe(reason);
    expect(state.pulls).toBe(0);
    expect(state.cancelled).toBe(1);
  });
});

describe("modal helpers (U9)", () => {
  it("previewErrorMessage shows an envelope error's own message and the neutral sentence otherwise", () => {
    expect(previewErrorMessage({ message: "Choose the executor who signs this affidavit.", data: { code: "BAD_REQUEST", httpStatus: 400 } })).toBe("Choose the executor who signs this affidavit.");
    expect(previewErrorMessage({ message: "Unexpected token < in JSON at position 0" })).toBe(NEUTRAL);
    expect(previewErrorMessage({ message: "Unable to transform response from server", data: undefined })).toBe(NEUTRAL);
    expect(previewErrorMessage(new PreviewTransportError("too-large"))).toBe(NEUTRAL);
    expect(previewErrorMessage(null)).toBe(NEUTRAL);
    expect(PREVIEW_UNAVAILABLE_SENTENCE).toBe(NEUTRAL);
  });

  it("previewRetry retries envelope errors up to three times and never a data-less error", () => {
    const envelopeError = { data: { code: "INTERNAL_SERVER_ERROR", httpStatus: 503 } };
    expect(previewRetry(0, envelopeError)).toBe(true);
    expect(previewRetry(2, envelopeError)).toBe(true);
    expect(previewRetry(3, envelopeError)).toBe(false);
    expect(previewRetry(0, new PreviewTransportError("body-timeout"))).toBe(false);
    expect(previewRetry(0, { data: undefined })).toBe(false);
    expect(previewRetry(0, new DOMException("Closed", "AbortError"))).toBe(false);
  });
});

describe("validatePreviewPayload (U14)", () => {
  const deepFreeze = <T,>(value: T): T => {
    if (value && typeof value === "object") { Object.freeze(value); for (const v of Object.values(value as object)) deepFreeze(v); }
    return value;
  };
  const valid = () => deepFreeze({
    formCode: "P11",
    formName: "Fictional",
    extra: "unknown fields are allowed",
    sections: [
      { type: "paragraph", text: "", bold: false, italic: true, center: false, indent: true, align: "right" },
      { type: "heading", text: "IN THE SUPREME COURT", center: true },
      { type: "checkbox", text: "Checked", checked: true, hideUnchecked: false, hideMarker: false },
      { type: "signature", text: "", suppressRule: true },
      { type: "separator" },
      { type: "pagebreak" },
      { type: "letterhead_image", imageUrl: "/manus-storage/fictional/letterhead.png" },
      { type: "letterhead_docx", text: "fictional.docx" },
      { type: "letter_recipient_block", text: "a\nb\n\n", recipientLines: ["Bob", "1 Street"], deliveryMethod: "Regular Mail" },
      { type: "table", rows: [] },
      { type: "table", rows: [{ cells: ["", "x"], header: true, italic: false, colSpans: [2, 1], cellAligns: ["left", "center"] }, { cells: [] }] },
    ],
  });

  it("returns the same reference for a well-formed payload, including empty drafts and unknown fields, without mutating it", () => {
    const payload = valid();
    const snapshot = JSON.stringify(payload);
    expect(validatePreviewPayload(payload)).toBe(payload);
    expect(validatePreviewPayload({ sections: [] })).toEqual({ sections: [] });
    expect(JSON.stringify(payload)).toBe(snapshot);
  });

  const malformed: Array<[string, unknown]> = [
    ["null payload", null],
    ["string payload", "sections"],
    ["sections not an array", { sections: "x" }],
    ["sections null", { sections: null }],
    ["null element", { sections: [null] }],
    ["string element", { sections: ["paragraph"] }],
    ["unknown type", { sections: [{ type: "bogus", text: "x" }] }],
    ["text not a string", { sections: [{ type: "paragraph", text: {} }] }],
    ["imageUrl not a string", { sections: [{ type: "letterhead_image", imageUrl: 42 }] }],
    ["deliveryMethod not a string", { sections: [{ type: "letter_recipient_block", deliveryMethod: ["x"] }] }],
    ["recipientLines not an array", { sections: [{ type: "letter_recipient_block", recipientLines: "x" }] }],
    ["recipient line not a string", { sections: [{ type: "letter_recipient_block", recipientLines: [1] }] }],
    ["rows not an array", { sections: [{ type: "table", rows: {} }] }],
    ["row without cells array", { sections: [{ type: "table", rows: [{ cells: "x" }] }] }],
    ["cell not a string", { sections: [{ type: "table", rows: [{ cells: [{}] }] }] }],
    ["colSpans not an array", { sections: [{ type: "table", rows: [{ cells: ["a"], colSpans: "2" }] }] }],
    ["colSpan not finite", { sections: [{ type: "table", rows: [{ cells: ["a"], colSpans: [Number.NaN] }] }] }],
    ["cellAligns entry outside the literals", { sections: [{ type: "table", rows: [{ cells: ["a"], cellAligns: ["middle"] }] }] }],
    ["bold as 1", { sections: [{ type: "paragraph", text: "x", bold: 1 }] }],
    ["italic as 'true'", { sections: [{ type: "paragraph", text: "x", italic: "true" }] }],
    ["center as null", { sections: [{ type: "paragraph", text: "x", center: null }] }],
    ["checked as 'yes'", { sections: [{ type: "checkbox", text: "x", checked: "yes" }] }],
    ["hideUnchecked as 0", { sections: [{ type: "checkbox", text: "x", hideUnchecked: 0 }] }],
    ["hideMarker as object", { sections: [{ type: "checkbox", text: "x", hideMarker: {} }] }],
    ["indent as 1", { sections: [{ type: "paragraph", text: "x", indent: 1 }] }],
    ["suppressRule as 'true'", { sections: [{ type: "signature", text: "x", suppressRule: "true" }] }],
    ["row header as 1", { sections: [{ type: "table", rows: [{ cells: ["a"], header: 1 }] }] }],
    ["row italic as 'yes'", { sections: [{ type: "table", rows: [{ cells: ["a"], italic: "yes" }] }] }],
    ["align outside the literals", { sections: [{ type: "paragraph", text: "x", align: "justify" }] }],
  ];
  for (const [label, payload] of malformed) {
    it(`rejects whole: ${label}`, () => {
      let thrown: unknown;
      try { validatePreviewPayload(payload as never); } catch (error) { thrown = error; }
      expect(thrown).toBeInstanceOf(PreviewPayloadError);
      expect((thrown as Error).message).toBe(NEUTRAL);
      expect("data" in (thrown as object)).toBe(false);
    });
  }
});

describe("validatePreviewPayload over the captured fixtures (U14b, guard)", () => {
  const baselineDir = path.resolve(__dirname, "../../../test-fixtures/integration/2026-10-30-v1/render-baseline");
  const taskFixtures = path.resolve(__dirname, "../../../test-fixtures/integration/2026-10-30-v1/letterhead-previews");

  it("accepts every real captured preview payload by reference: the 26 render-baseline fixtures and the two letterhead fixtures", () => {
    // The render gate depends on the same directory; a missing fixture is a loud failure here, never a skip.
    expect(existsSync(baselineDir), baselineDir).toBe(true);
    const files = [
      ...readdirSync(baselineDir).filter((name) => name.endsWith(".preview.json")).sort().map((name) => path.join(baselineDir, name)),
      ...["LETTER-image.preview.json", "LETTER-docx.preview.json"].map((name) => path.join(taskFixtures, name)),
    ];
    expect(files).toHaveLength(28);
    for (const file of files) {
      const sections = JSON.parse(readFileSync(file, "utf8"));
      expect(Array.isArray(sections), file).toBe(true);
      const payload = { formCode: path.basename(file).split(".")[0], formName: "Fictional", sections };
      expect(validatePreviewPayload(payload), file).toBe(payload);
    }
  });
});

describe("previewQueryKeyHash (U15)", () => {
  const key = [["document", "preview"], { input: { estateId: "e1", formCode: "P1" }, type: "query" }] as const;

  it("hashes the key together with the tab's current session generation", () => {
    expect(previewQueryKeyHash(key)).toBe(hashKey([key, clientSessionGeneration()]));
  });

  it("changes when the session ends and not when a token rotates", () => {
    sessionStorage.setItem("manus-cookie", "app_session_id=fictional-a");
    const before = previewQueryKeyHash(key);
    sessionStorage.setItem("manus-cookie", "app_session_id=fictional-b");
    expect(previewQueryKeyHash(key)).toBe(before);
    clearFallbackSession();
    expect(previewQueryKeyHash(key)).not.toBe(before);
  });
});
