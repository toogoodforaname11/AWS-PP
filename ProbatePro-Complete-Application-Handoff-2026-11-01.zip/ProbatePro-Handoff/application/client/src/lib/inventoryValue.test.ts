import { describe, expect, it } from "vitest";
import {
  hydrateInventoryItemForEdit,
  inventoryEffectiveValueInput,
  inventoryValueRecordedFromForm,
  realPropertyFmvInput,
  updateRealPropertyFmvInput,
  updateInventoryValueInput,
} from "./inventoryValue";

describe("inventory value form conversion", () => {
  it("hydrates historical zero defaults as blanks and does not fabricate an explicit zero", () => {
    expect(hydrateInventoryItemForEdit({
      category: "real_property",
      value: 0,
      assessedMarketValue: 0,
      dateOfDeathValue: 0,
      valueRecorded: 0,
    })).toMatchObject({ value: "", assessedMarketValue: "", dateOfDeathValue: "", valueRecorded: 0 });
  });

  it("hydrates explicit zero and legacy nonzero rows without losing their meaning", () => {
    // B18: hydration always shows two decimals so trailing cent zeros survive
    expect(hydrateInventoryItemForEdit({ category: "tangible", value: 0, valueRecorded: 1 }))
      .toMatchObject({ value: "0.00", valueRecorded: 1 });
    expect(hydrateInventoryItemForEdit({ category: "real_property", value: 123_00, assessedMarketValue: 0, valueRecorded: 0 }))
      .toMatchObject({ value: "123.00", assessedMarketValue: "", valueRecorded: 1 });
  });

  it("counts raw zero as entered, but not a blank, for generic and category-specific fields", () => {
    expect(inventoryValueRecordedFromForm({ category: "tangible", value: "0" })).toBe(1);
    expect(inventoryValueRecordedFromForm({ category: "real_property", value: "", assessedMarketValue: "0" })).toBe(1);
    expect(inventoryValueRecordedFromForm({ category: "financial", value: "", dateOfDeathValue: "0" })).toBe(1);
    expect(inventoryValueRecordedFromForm({ category: "financial", value: "", dateOfDeathValue: "" })).toBe(0);
  });

  it("gives an entered preferred source precedence and otherwise falls back to generic input", () => {
    expect(inventoryEffectiveValueInput({ category: "real_property", value: "123", assessedMarketValue: "0" })).toBe("0");
    expect(inventoryEffectiveValueInput({ category: "financial", value: "456", dateOfDeathValue: "0" })).toBe("0");
    expect(inventoryEffectiveValueInput({ category: "real_property", value: "123", assessedMarketValue: "" })).toBe("123");
    expect(updateInventoryValueInput({ category: "financial", value: "", dateOfDeathValue: "" }, "dateOfDeathValue", "0"))
      .toMatchObject({ dateOfDeathValue: "0", valueRecorded: 1 });
  });

  it("keeps a pending real-property FMV blank while synchronizing a later entered FMV", () => {
    const pending = updateRealPropertyFmvInput({ category: "real_property", value: "", assessedMarketValue: "" }, "");
    expect(pending).toMatchObject({ value: "", assessedMarketValue: "", valueRecorded: 0 });
    expect(realPropertyFmvInput({ category: "real_property", value: "325000.00", assessedMarketValue: "", valueRecorded: 1 })).toBe("325000.00");

    const recorded = updateRealPropertyFmvInput(pending, "325000");
    expect(recorded).toMatchObject({ value: "325,000", assessedMarketValue: "325,000", valueRecorded: 1 });

    const actualZero = updateRealPropertyFmvInput(pending, "0");
    expect(actualZero).toMatchObject({ value: "0", assessedMarketValue: "0", valueRecorded: 1 });
  });
});
