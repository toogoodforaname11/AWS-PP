/**
 * Native delivery for a cookie session (Nick, 2026-10-20; Task 9 keeps it unchanged): with no Preview
 * Bearer fallback token, a generated document leaves the app by one same-tab standard form POST per
 * activation: the PostDelivery's action and fields plus a fresh attemptId, nothing in a query string,
 * no new browsing context. The triggering control stays disabled for the two-second submission
 * window, so a double-click submits once. Phone and desktop widths behave identically.
 */
import React from "react";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { PostDelivery } from "@shared/postDelivery";
import { deliverAttachment } from "./attachmentDelivery";

const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const delivery: PostDelivery = {
  method: "POST",
  action: "/api/download/form",
  fields: { estateId: "estate-1", formCode: "P3", documentId: "doc_P3-1", signatoryType: "executor", signatureDate: "2026-10-20" },
};
const originalInnerWidth = window.innerWidth;

type Submission = {
  method: string;
  action: string | null;
  enctype: string;
  target: string | null;
  display: string;
  connected: boolean;
  framesOpen: number;
  inputs: Array<{ type: string; name: string; value: string }>;
};
let submissions: Submission[];
let submit: ReturnType<typeof vi.spyOn>;
let openWindow: ReturnType<typeof vi.spyOn>;

beforeEach(() => {
  submissions = [];
  submit = vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) {
    submissions.push({
      method: this.method,
      action: this.getAttribute("action"),
      enctype: this.enctype,
      target: this.getAttribute("target"),
      display: this.style.display,
      connected: this.isConnected,
      framesOpen: document.querySelectorAll("iframe").length,
      inputs: Array.from(this.querySelectorAll("input"), (input) => ({ type: input.type, name: input.name, value: input.value })),
    });
  });
  openWindow = vi.spyOn(window, "open").mockReturnValue(null);
});

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  vi.useRealTimers();
  Object.defineProperty(window, "innerWidth", { configurable: true, writable: true, value: originalInnerWidth });
});

function DownloadButton({ value = delivery }: { value?: PostDelivery }) {
  return <button type="button" onClick={(event) => { void deliverAttachment(value, event.currentTarget); }}>Download P3</button>;
}

const postedFields = (submission: Submission) => Object.fromEntries(submission.inputs.map((input) => [input.name, input.value]));

describe.each([1280, 375])("native cookie-session delivery at %ipx", (width) => {
  beforeEach(() => {
    Object.defineProperty(window, "innerWidth", { configurable: true, writable: true, value: width });
    window.dispatchEvent(new Event("resize"));
  });

  it("submits one hidden same-tab POST form per click with every field and a fresh attemptId, then removes it", () => {
    vi.useFakeTimers();
    render(<DownloadButton />);
    const button = screen.getByRole("button", { name: "Download P3" });

    fireEvent.click(button);
    expect(submit).toHaveBeenCalledTimes(1);
    const [first] = submissions;
    expect(first).toMatchObject({
      method: "post",
      action: "/api/download/form",
      enctype: "application/x-www-form-urlencoded",
      target: null,
      display: "none",
      connected: true,
      framesOpen: 0,
    });
    expect(first.inputs.every((input) => input.type === "hidden")).toBe(true);
    expect(first.inputs).toHaveLength(Object.keys(delivery.fields).length + 1);
    expect(postedFields(first)).toEqual({ ...delivery.fields, attemptId: expect.stringMatching(UUID_V4) });
    expect(document.querySelectorAll("form")).toHaveLength(0);
    expect(document.querySelectorAll("iframe")).toHaveLength(0);
    expect(openWindow).not.toHaveBeenCalled();

    vi.advanceTimersByTime(2000);
    fireEvent.click(button);
    expect(submit).toHaveBeenCalledTimes(2);
    expect(postedFields(submissions[1])).toEqual({ ...delivery.fields, attemptId: expect.stringMatching(UUID_V4) });
    expect(postedFields(submissions[1]).attemptId).not.toBe(postedFields(first).attemptId);
    expect(document.querySelectorAll("form")).toHaveLength(0);
  });

  it("keeps the control disabled for the two-second window, so a double-click submits exactly once", async () => {
    vi.useFakeTimers();
    render(<DownloadButton />);
    const button = screen.getByRole("button", { name: "Download P3" }) as HTMLButtonElement;

    fireEvent.click(button);
    fireEvent.click(button);
    expect(submit).toHaveBeenCalledTimes(1);
    expect(button.disabled).toBe(true);
    await expect(deliverAttachment(delivery, button)).resolves.toEqual({ kind: "suppressed" });
    expect(submit).toHaveBeenCalledTimes(1);

    vi.advanceTimersByTime(1999);
    expect(button.disabled).toBe(true);
    vi.advanceTimersByTime(1);
    expect(button.disabled).toBe(false);

    fireEvent.click(button);
    expect(submit).toHaveBeenCalledTimes(2);
    expect(button.disabled).toBe(true);
  });

  it("hands focus back to the control when disabling it dropped focus to the page", () => {
    vi.useFakeTimers();
    render(<DownloadButton />);
    const button = screen.getByRole("button", { name: "Download P3" });
    button.focus();

    fireEvent.click(button);
    // Browsers run focus fixup when a focused control becomes disabled: focus
    // falls to the page. jsdom keeps it on the disabled button, so emulate it.
    const activeElement = vi.spyOn(document, "activeElement", "get").mockReturnValue(document.body);
    const focus = vi.spyOn(button, "focus");
    vi.advanceTimersByTime(1999);
    expect(focus).not.toHaveBeenCalled();
    vi.advanceTimersByTime(1);
    expect(focus).toHaveBeenCalledTimes(1);
    expect(focus).toHaveBeenCalledWith({ preventScroll: true });
    activeElement.mockRestore();
    expect(document.activeElement).toBe(button);
    expect((button as HTMLButtonElement).disabled).toBe(false);
  });

  it("leaves focus alone when the control was not focused at the click", () => {
    vi.useFakeTimers();
    render(<DownloadButton />);
    const button = screen.getByRole("button", { name: "Download P3" });

    fireEvent.click(button);
    vi.spyOn(document, "activeElement", "get").mockReturnValue(document.body);
    const focus = vi.spyOn(button, "focus");
    vi.advanceTimersByTime(2000);
    expect(focus).not.toHaveBeenCalled();
  });

  it("never pulls focus back from a control the user moved to during the window", () => {
    vi.useFakeTimers();
    render(<><DownloadButton /><button type="button">Dismiss</button></>);
    const button = screen.getByRole("button", { name: "Download P3" });
    const other = screen.getByRole("button", { name: "Dismiss" });
    button.focus();

    fireEvent.click(button);
    other.focus();
    vi.advanceTimersByTime(2000);
    expect(document.activeElement).toBe(other);
  });

  it("an unmount inside the window leaves nothing behind and focuses nothing", () => {
    vi.useFakeTimers();
    const consoleError = vi.spyOn(console, "error");
    const { unmount } = render(<DownloadButton />);
    const button = screen.getByRole("button", { name: "Download P3" });
    button.focus();

    fireEvent.click(button);
    unmount();
    const focus = vi.spyOn(HTMLElement.prototype, "focus");
    vi.advanceTimersByTime(2000);

    expect(focus).not.toHaveBeenCalled();
    expect(consoleError).not.toHaveBeenCalled();
    expect(document.querySelectorAll("form")).toHaveLength(0);
    expect(submit).toHaveBeenCalledTimes(1);
  });

  it.each([
    ["a GET descriptor", { ...delivery, method: "GET" }],
    ["a query-string action", { ...delivery, action: "/api/download/form?documentId=doc_P3-1" }],
    ["a stored-object link", { ...delivery, action: "/manus-storage/estates/estate-1/P3.docx" }],
    ["a non-string field", { ...delivery, fields: { ...delivery.fields, documentId: 7 } }],
    ["no descriptor", undefined],
  ])("refuses %s: no form, no submission, the control stays enabled", async (_label, invalid) => {
    render(<DownloadButton />);
    const button = screen.getByRole("button", { name: "Download P3" }) as HTMLButtonElement;
    const createElement = vi.spyOn(document, "createElement");

    await expect(deliverAttachment(invalid as unknown as PostDelivery, button)).resolves.toEqual({ kind: "invalid" });
    expect(createElement).not.toHaveBeenCalledWith("form");
    expect(submit).not.toHaveBeenCalled();
    expect(button.disabled).toBe(false);
    expect(document.querySelectorAll("form")).toHaveLength(0);
  });

  it("posts without a control and draws a v4 attemptId from getRandomValues where randomUUID is unavailable", async () => {
    const webCrypto = globalThis.crypto;
    vi.stubGlobal("crypto", { getRandomValues: webCrypto.getRandomValues.bind(webCrypto) });
    const notes: PostDelivery = { method: "POST", action: "/api/notes/export-pdf", fields: { estateId: "estate-1" } };

    await expect(deliverAttachment(notes)).resolves.toEqual({ kind: "submitted" });
    await expect(deliverAttachment(notes)).resolves.toEqual({ kind: "submitted" });
    expect(submit).toHaveBeenCalledTimes(2);
    const [first, second] = submissions.map(postedFields);
    expect(submissions[0]).toMatchObject({ method: "post", action: "/api/notes/export-pdf", target: null });
    expect(first).toEqual({ estateId: "estate-1", attemptId: expect.stringMatching(UUID_V4) });
    expect(second.attemptId).toMatch(UUID_V4);
    expect(second.attemptId).not.toBe(first.attemptId);
  });
});
