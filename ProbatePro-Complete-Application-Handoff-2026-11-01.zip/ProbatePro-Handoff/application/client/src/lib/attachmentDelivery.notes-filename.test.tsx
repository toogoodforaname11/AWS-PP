import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { PostDelivery } from "../../../shared/postDelivery";
import { notesFilenameDisposition } from "../../../server/_core/notesFilename";
import { browserResponse } from "./browserResponse.testkit";

vi.mock("sonner", () => ({ toast: { success: vi.fn(), error: vi.fn(), info: vi.fn(), loading: vi.fn(), dismiss: vi.fn() } }));
import { toast } from "sonner";
import { deliverAttachment, fetchDeliveryAttachment } from "./attachmentDelivery";

const notes: PostDelivery = { method: "POST", action: "/api/notes/export-pdf", fields: { estateId: "fictional-unicode-notes" } };
const bytes = new TextEncoder().encode("%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n");
const fallback = "Notes - Estate - 2026-10-31.pdf";
const fetchSpy = vi.fn();
const clicks: string[] = [];
const blobs: Blob[] = [];

function respond(header: string, body: Uint8Array = bytes, status = 200) {
  fetchSpy.mockResolvedValue(browserResponse(body, { status, headers: {
    "content-type": "application/pdf", "content-length": String(body.length), "content-disposition": header,
  } }));
}

beforeEach(() => {
  vi.useFakeTimers();
  fetchSpy.mockReset(); clicks.length = 0; blobs.length = 0;
  vi.stubGlobal("fetch", fetchSpy);
  sessionStorage.setItem("manus-cookie", "app_session_id=fictional.notes.header.token");
  vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(function (this: HTMLAnchorElement) { clicks.push(this.download); });
  Object.defineProperty(URL, "createObjectURL", { configurable: true, writable: true, value: vi.fn((blob: Blob) => { blobs.push(blob); return "blob:http://localhost/fictional-notes"; }) });
  Object.defineProperty(URL, "revokeObjectURL", { configurable: true, writable: true, value: vi.fn() });
  vi.mocked(toast.error).mockReset();
});

afterEach(() => {
  vi.clearAllTimers(); vi.useRealTimers(); vi.restoreAllMocks(); vi.unstubAllGlobals(); sessionStorage.clear();
  delete (URL as any).createObjectURL; delete (URL as any).revokeObjectURL;
});

describe("approved notes filename: actual server-header/client-transport compatibility", () => {
  it.each([
    "Notes - Łukasz O’Neill QA - 2026-10-31.pdf",
    "Notes - Zoë Example - 2026-10-31.pdf",
    "Notes - 陳 Example - 2026-10-31.pdf",
    'Notes - Example "Quoted" - 2026-10-31.pdf',
    "Notes - Example \\ Branch - 2026-10-31.pdf",
    "Notes - Example 20% (QA) - 2026-10-31.pdf",
    "Notes - Helen Example - 2026-10-31.pdf",
  ])("hands off the exact approved filename and unchanged PDF bytes: %s", async filename => {
    respond(notesFilenameDisposition(filename, fallback));
    const control = document.createElement("button");
    const native = vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(() => undefined);
    await expect(deliverAttachment(notes, control)).resolves.toEqual({ kind: "handed-off", filename, bytes: bytes.length });
    expect(clicks).toEqual([filename]);
    expect(blobs).toHaveLength(1);
    expect(Array.from(new Uint8Array(await blobs[0].arrayBuffer()))).toEqual(Array.from(bytes));
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    expect(fetchSpy.mock.calls[0][0]).toBe("/api/notes/export-pdf");
    expect(fetchSpy.mock.calls[0][1].headers).toEqual({ "Content-Type": "application/x-www-form-urlencoded", Authorization: "Bearer fictional.notes.header.token" });
    expect(native).not.toHaveBeenCalled();
    expect(control.disabled).toBe(false);
    expect(toast.error).not.toHaveBeenCalled();
  });

  it("the existing JSON fetch path accepts the same header without changing its envelope", async () => {
    const filename = "Notes - Łukasz Example - 2026-10-31.pdf";
    respond(notesFilenameDisposition(filename, fallback));
    await expect(fetchDeliveryAttachment(notes)).resolves.toMatchObject({ kind: "handed-off", filename });
    expect(fetchSpy.mock.calls[0][1].headers["Content-Type"]).toBe("application/json");
    expect(JSON.parse(fetchSpy.mock.calls[0][1].body)).toMatchObject(notes.fields);
    expect(clicks).toEqual([filename]);
  });

  it("cookie-only delivery remains one unchanged native form, with no client filename parsing or fetch", async () => {
    sessionStorage.clear();
    const native = vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) {
      expect(new URL(this.action).pathname).toBe(notes.action);
      expect(this.method).toBe("post");
      expect(new FormData(this).get("estateId")).toBe(notes.fields.estateId);
    });
    await expect(deliverAttachment(notes)).resolves.toEqual({ kind: "submitted" });
    expect(native).toHaveBeenCalledTimes(1);
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it.each([
    "attachment; filename=\"Notes.pdf\"; filename*=UTF-8''Notes%ZZ.pdf",
    "attachment; filename=\"Notes.pdf\"; filename*=UTF-8''Notes%E0%A4.pdf",
    "attachment; filename=\"Notes.pdf\"; filename*=ISO-8859-1''Notes%E9.pdf",
    "attachment; filename=\"Notes.pdf\"; filename*=UTF-8''Notes%0D%0AInjected.pdf",
    "attachment; filename=\"Notes.pdf\"; filename*=UTF-8''Notes%7F.pdf",
    "attachment; filename=\"Notes.pdf\"; filename*=UTF-8''Notes%C2%85.pdf",
    "attachment; filename=\"Notes.pdf\"; filename*=UTF-8''Notes.docx",
    "attachment; filename=\"Notes.pdf\"; filename*=UTF-8''",
    "attachment; filename=\"Notes.pdf\"; filename*=UTF-8''Notes.pdf; filename*=UTF-8''Other.pdf",
    "inline; filename=\"Notes.pdf\"; filename*=UTF-8''Notes.pdf",
    "attachment; filename*=UTF-8''Notes.pdf",
  ])("refuses an invalid extended header without a browser handoff: %s", async header => {
    respond(header);
    const control = document.createElement("button");
    const native = vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(() => undefined);
    await expect(deliverAttachment(notes, control)).resolves.toMatchObject({ kind: "failed", reason: "invalid-response" });
    expect(clicks).toEqual([]); expect(blobs).toEqual([]);
    expect(fetchSpy).toHaveBeenCalledTimes(1); expect(native).not.toHaveBeenCalled();
    expect(control.disabled).toBe(false);
    expect(fetchSpy.mock.calls[0][1].signal.aborted).toBe(true);
  });

  it("a valid extended name does not bypass PDF completeness checks and an explicit retry can succeed", async () => {
    const filename = "Notes - Łukasz Example - 2026-10-31.pdf";
    const header = notesFilenameDisposition(filename, fallback);
    respond(header, bytes.subarray(0, bytes.length - 7));
    await expect(deliverAttachment(notes)).resolves.toMatchObject({ kind: "failed", reason: "invalid-response" });
    expect(clicks).toEqual([]);
    respond(header);
    await expect(deliverAttachment(notes)).resolves.toMatchObject({ kind: "handed-off", filename });
    expect(fetchSpy).toHaveBeenCalledTimes(2);
    expect(clicks).toEqual([filename]);
  });

  it("does not broaden DOCX or ZIP header acceptance", async () => {
    const header = notesFilenameDisposition("Report - Łukasz.docx", "Report.docx");
    fetchSpy.mockResolvedValue(browserResponse(bytes, { status: 200, headers: { "content-type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "content-disposition": header } }));
    await expect(deliverAttachment({ method: "POST", action: "/api/download/form", fields: { estateId: "fictional-unicode-notes" } })).resolves.toMatchObject({ kind: "failed", reason: "invalid-response" });
    expect(clicks).toEqual([]); expect(blobs).toEqual([]);
  });
});
