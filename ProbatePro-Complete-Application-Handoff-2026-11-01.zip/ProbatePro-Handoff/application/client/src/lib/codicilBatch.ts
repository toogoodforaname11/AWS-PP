/**
 * Delete codicil entries from the end so every remaining server index stays
 * valid as the estate's revision advances after each mutation.
 */
export function codicilClearIndices(count: number): number[] {
  return Array.from({ length: Math.max(0, count) }, (_, position) => count - position - 1);
}
