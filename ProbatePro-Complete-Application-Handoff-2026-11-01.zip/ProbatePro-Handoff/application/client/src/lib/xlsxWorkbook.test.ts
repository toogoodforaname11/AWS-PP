import JSZip from "jszip";
import { describe, expect, it } from "vitest";
import { createXlsxWorkbook, readFirstXlsxWorksheetRows, XLSX_MIME_TYPE } from "./xlsxWorkbook";

describe("native XLSX workbook helpers", () => {
  it("creates and reads a workbook without comma-delimited parsing", async () => {
    const workbook = await createXlsxWorkbook({
      sheetName: "Inventory",
      headers: ["category", "description", "value"],
      rows: [{ category: "financial", description: "RBC, chequing account", value: 1025.5 }],
    });

    expect(workbook.type).toBe(XLSX_MIME_TYPE);
    await expect(readFirstXlsxWorksheetRows(workbook)).resolves.toEqual([
      { category: "financial", description: "RBC, chequing account", value: "1025.5" },
    ]);
  });

  it("reads standard shared-string worksheet cells", async () => {
    const zip = new JSZip();
    zip.file(
      "xl/sharedStrings.xml",
      '<?xml version="1.0"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><si><t>category</t></si><si><t>description</t></si><si><t>financial</t></si><si><t>RBC, chequing account</t></si></sst>',
    );
    zip.file(
      "xl/worksheets/sheet1.xml",
      '<?xml version="1.0"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="s"><v>1</v></c></row><row r="2"><c r="A2" t="s"><v>2</v></c><c r="B2" t="s"><v>3</v></c></row></sheetData></worksheet>',
    );
    const buffer = await zip.generateAsync({ type: "arraybuffer" });
    const workbook = new Blob([buffer], { type: XLSX_MIME_TYPE });

    await expect(readFirstXlsxWorksheetRows(workbook)).resolves.toEqual([
      { category: "financial", description: "RBC, chequing account" },
    ]);
  });
});
