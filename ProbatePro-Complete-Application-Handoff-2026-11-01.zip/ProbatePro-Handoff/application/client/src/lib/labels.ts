// Single source of truth for user-facing display labels and the one
// display-date format. Screens must not hand-roll status/role/grant-type
// strings or ad-hoc date formats (mirrors the oathWords() convention).
import { fmtDateDDMMMYYYY } from "../../../shared/date-utils";
import { normalizeGrantType } from "../../../shared/types";

export const STATUS_LABELS: Record<string, string> = {
  intake: "Intake",
  incomplete: "Incomplete",
  ready_to_file: "Ready to File",
  filed: "Filed",
  granted: "Granted",
  complete: "Complete",
  archived: "Archived",
};

export function statusLabel(status: string | null | undefined): string {
  if (!status) return "";
  return STATUS_LABELS[status] ?? status;
}

// Curated grant-type display names, keyed by the raw stored value so the
// ancillary distinction is preserved (source: Intake selector wording).
export const GRANT_TYPE_LABELS: Record<string, string> = {
  grant_of_probate: "Grant of Probate",
  probate: "Grant of Probate",
  grant_of_admin_with_will: "Administration with Will Annexed",
  admin_with_will: "Administration with Will Annexed",
  grant_of_admin: "Grant of Administration",
  admin_no_will: "Grant of Administration",
  ancillary_probate: "Ancillary Grant of Probate",
  ancillary_admin_with_will: "Ancillary Grant of Admin with Will",
  ancillary_admin_no_will: "Ancillary Grant of Admin without Will",
  resealing: "Resealing",
};

export function grantTypeLabel(raw: string | null | undefined): string {
  if (!raw || raw === "unknown") return "Grant type not selected";
  return GRANT_TYPE_LABELS[raw] ?? GRANT_TYPE_LABELS[normalizeGrantType(raw)] ?? "Grant type not selected";
}

// Contact.role stores comma-joined lowercase tokens (see contactRoles()).
const ROLE_LABELS: Record<string, string> = {
  pgt: "Public Guardian and Trustee",
  client_reported_person: "Client-reported person",
};

function titleCaseContactValue(value: string): string {
  return value
    .trim()
    .replace(/[_-]+/g, " ")
    .replace(/\b\w/g, character => character.toUpperCase());
}

/**
 * A client-reported person is intentionally not assigned a legal role from the
 * portal. When the client supplied a relationship, show that reported context
 * without changing the neutral stored role or guessing a legal classification.
 */
export function roleLabel(
  role: string | null | undefined,
  relationship?: string | null
): string {
  return (role || "")
    .split(",")
    .map(r => r.trim().toLowerCase())
    .filter(Boolean)
    .map(r => {
      if (r === "client_reported_person" && relationship?.trim())
        return `${titleCaseContactValue(relationship)} (client-reported)`;
      return (
        ROLE_LABELS[r] ??
        r.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase())
      );
    })
    .join(", ");
}

// Keyboard-shortcut hints: the handlers accept Ctrl and ⌘ alike, but the
// visible hint must match the viewer's platform (B16).
export const IS_MAC =
  typeof navigator !== "undefined" && /Mac|iP(hone|ad|od)/.test(navigator.platform || navigator.userAgent);

export function shortcutLabel(key: string): string {
  return IS_MAC ? `⌘${key}` : `Ctrl+${key}`;
}

export function deliveryMethodLabel(m: string | null | undefined): string {
  switch (m) {
    case "ordinary_mail":
    case "mail":
      return "Ordinary Mail";
    case "registered_mail":
      return "Registered Mail";
    case "personal":
      return "Personal Delivery";
    case "electronic":
      return "Electronic";
    default:
      return m || "";
  }
}

/**
 * The one display format for calendar dates: "15 Jan 2026" (unambiguous,
 * never locale-dependent M/D/YYYY). Accepts "YYYY-MM-DD" strings verbatim
 * and timestamps/Dates, which render in the viewer's local timezone.
 */
export function fmtDisplayDate(input: string | number | Date | null | undefined): string {
  if (input == null || input === "") return "";
  if (typeof input === "string" && /^\d{4}-\d{2}-\d{2}/.test(input)) {
    return fmtDateDDMMMYYYY(input.slice(0, 10));
  }
  const d = new Date(input);
  if (Number.isNaN(d.getTime())) return typeof input === "string" ? input : "";
  const ymd = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  return fmtDateDDMMMYYYY(ymd);
}
