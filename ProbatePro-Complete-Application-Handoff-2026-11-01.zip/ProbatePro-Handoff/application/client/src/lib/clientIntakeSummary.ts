import type {
  ClientIntakeItem,
  ClientIntakePayload,
  ClientIntakePerson,
} from "@shared/clientIntake";

export type ClientIntakeSummaryRow = { label: string; value: string };
export type ClientIntakeSummarySection = {
  title: string;
  rows: ClientIntakeSummaryRow[];
};

const DOCUMENT_LABELS: Record<string, string> = {
  original_will: "Original will",
  death_certificate: "Death certificate",
  tax_return: "Most recent tax return",
  identification: "Identification",
};

const PERSON_LABELS: Record<
  keyof Omit<ClientIntakePerson, "category">,
  string
> = {
  name: "Name",
  relationship: "Relationship to deceased",
  age: "Reported age",
  occupation: "Occupation",
  address: "Address",
  addressStreet: "Residential street address",
  addressUnit: "Residential unit / suite",
  addressCity: "Residential city",
  addressProvince: "Residential province / state",
  addressPostalCode: "Residential postal code",
  addressCountry: "Residential country",
  email: "Email",
  phone: "Phone",
  executorStatus: "Reported executor status",
};

const EXECUTOR_STATUS_LABELS: Record<
  ClientIntakePerson["executorStatus"],
  string
> = {
  "": "",
  applying: "Applying (active)",
  reserved: "Right reserved — not joining this application",
  renounced: "Renounced",
  deceased: "Deceased",
  unable: "Unable to act",
};

const ITEM_LABELS: Record<keyof ClientIntakeItem, string> = {
  category: "Category",
  description: "Description",
  location: "Location",
  value: "Reported value",
  bankAddress: "Institution address",
  accountNumber: "Account number",
  accountHolder: "Account holder",
  pid: "PID",
  legalDescription: "Legal description",
  registeredOwner: "Registered owner",
  ownershipDetails: "Ownership details",
};

function nonEmpty(
  rows: Array<ClientIntakeSummaryRow | false | null | undefined>
) {
  return rows.filter((row): row is ClientIntakeSummaryRow =>
    Boolean(row && typeof row === "object" && row.value.trim())
  );
}

function addSection(
  sections: ClientIntakeSummarySection[],
  title: string,
  rows: ClientIntakeSummaryRow[]
) {
  if (rows.length) sections.push({ title, rows });
}

function readableEnum(value: string) {
  return value
    .replace(/_/g, " ")
    .replace(/\b\w/g, letter => letter.toUpperCase());
}

function personRows(person: ClientIntakePerson) {
  return nonEmpty(
    (
      Object.keys(PERSON_LABELS) as Array<
        keyof Omit<ClientIntakePerson, "category">
      >
    ).map(key => ({
      label: PERSON_LABELS[key],
      value:
        key === "executorStatus"
          ? EXECUTOR_STATUS_LABELS[person.executorStatus]
          : person[key],
    }))
  );
}

function itemRows(item: ClientIntakeItem) {
  return nonEmpty(
    (Object.keys(ITEM_LABELS) as Array<keyof ClientIntakeItem>).map(key => {
      const value =
        key === "category"
          ? readableEnum(item.category)
          : key === "location"
            ? item.location === "unknown"
              ? ""
              : readableEnum(item.location)
            : item[key];
      return { label: ITEM_LABELS[key], value: String(value || "") };
    })
  );
}

/**
 * Produces a client-readable summary of an immutable client submission. It never
 * reads current estate values, reviewer notes, portal access data, or application state.
 */
export function buildClientIntakeSummarySections(
  payload: ClientIntakePayload
): ClientIntakeSummarySection[] {
  const sections: ClientIntakeSummarySection[] = [];

  addSection(
    sections,
    "Deceased",
    nonEmpty([
      { label: "First name", value: payload.deceasedFirstName },
      { label: "Middle name(s)", value: payload.deceasedMiddleNames },
      { label: "Last name", value: payload.deceasedLastName },
      { label: "Other names used", value: payload.deceasedAliases },
      { label: "Other name first name", value: payload.deceasedAkaFirstName },
      {
        label: "Other name middle name(s)",
        value: payload.deceasedAkaMiddleName,
      },
      { label: "Other name last name", value: payload.deceasedAkaLastName },
      { label: "Date of birth", value: payload.dateOfBirth },
      { label: "Place of birth", value: payload.deceasedPlaceOfBirth },
      { label: "Date of death", value: payload.dateOfDeath },
      { label: "Place of death", value: payload.placeOfDeath },
    ])
  );

  addSection(
    sections,
    "Last residence",
    nonEmpty([
      { label: "Reported full address", value: payload.deceasedAddress },
      { label: "Unit / suite", value: payload.addressUnit },
      { label: "Street address", value: payload.addressStreet },
      { label: "City", value: payload.addressCity },
      { label: "Province / state", value: payload.addressProvince },
      { label: "Postal code", value: payload.addressPostalCode },
      { label: "Country", value: payload.addressCountry },
      { label: "Last city of residence", value: payload.deceasedResidenceCity },
      { label: "Domicile city", value: payload.domicileCity },
      {
        label: "First Nation answer",
        value: payload.treatyFirstNation
          ? readableEnum(payload.treatyFirstNation)
          : "",
      },
      {
        label: "Treaty First Nation name",
        value: payload.treatyFirstNationName,
      },
    ])
  );

  addSection(
    sections,
    "Will information",
    nonEmpty([
      {
        label: "Will status",
        value:
          payload.willStatus === "unknown"
            ? ""
            : readableEnum(payload.willStatus),
      },
      { label: "Will date", value: payload.willDate },
      { label: "Will location", value: payload.willLocation },
    ])
  );

  addSection(
    sections,
    "Client details",
    nonEmpty([
      { label: "Name", value: payload.clientName },
      { label: "Email", value: payload.clientEmail },
      { label: "Phone", value: payload.clientPhone },
      {
        label: "Relationship to deceased",
        value: payload.relationshipToDeceased,
      },
      { label: "Occupation", value: payload.clientOccupation },
      { label: "Date of birth", value: payload.clientDateOfBirth },
      { label: "Unit / suite", value: payload.clientAddressUnit },
      { label: "Street address", value: payload.clientAddressStreet },
      { label: "City", value: payload.clientAddressCity },
      { label: "Province / state", value: payload.clientAddressProvince },
      { label: "Postal code", value: payload.clientAddressPostalCode },
      { label: "Country", value: payload.clientAddressCountry },
    ])
  );

  payload.executors.forEach((person, index) =>
    addSection(sections, `Executor ${index + 1}`, personRows(person))
  );

  payload.familyMembers.forEach((person, index) =>
    addSection(
      sections,
      `${readableEnum(person.category)} ${index + 1}`,
      personRows(person)
    )
  );

  payload.estateItems.forEach((item, index) =>
    addSection(sections, `Estate asset or debt ${index + 1}`, itemRows(item))
  );

  addSection(
    sections,
    "Documents reported",
    payload.documentsAvailable.map(document => ({
      label: "Available document",
      value: DOCUMENT_LABELS[document] || readableEnum(document),
    }))
  );

  addSection(
    sections,
    "Case-specific responses",
    payload.customQuestions
      .filter(question => question.answer.trim())
      .map(question => ({ label: question.prompt, value: question.answer }))
  );

  addSection(
    sections,
    "Additional information",
    nonEmpty([{ label: "Client notes", value: payload.clientNotes }])
  );

  return sections;
}
