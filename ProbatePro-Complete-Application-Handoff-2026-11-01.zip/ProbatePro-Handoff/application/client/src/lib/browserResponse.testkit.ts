/**
 * Test support for Task 9 (not application code; imported only by tests).
 *
 * A real Response with a real ReadableStream body, shaped the way a browser hands a same-origin
 * fetch result to page code. Node's `new Response()` reports `type: "default"`, a browser reports
 * `"basic"`; a `redirect: "manual"` fetch that met a redirect reports `"opaqueredirect"` with status 0
 * and no body. Bodies are bytes or strings, never a jsdom Blob (Node's Response would stringify it).
 */
export type BrowserResponseType = "basic" | "opaqueredirect" | "cors" | "opaque";

export function browserResponse(
  body: string | Uint8Array | ReadableStream<Uint8Array> | null,
  init: ResponseInit = {},
  type: BrowserResponseType = "basic",
): Response {
  if (type === "opaqueredirect") {
    const response = new Response(null, { status: 200 });
    Object.defineProperty(response, "type", { value: "opaqueredirect" });
    Object.defineProperty(response, "status", { value: 0 });
    return response;
  }
  const response = new Response(body as BodyInit | null, init);
  Object.defineProperty(response, "type", { value: type });
  return response;
}

/** A byte stream that hands out the given chunks one read at a time and records cancellation. */
export function chunkedStream(chunks: Uint8Array[], onCancel?: (reason: unknown) => void): ReadableStream<Uint8Array> {
  let index = 0;
  return new ReadableStream<Uint8Array>({
    pull(controller) {
      if (index < chunks.length) controller.enqueue(chunks[index++]);
      else controller.close();
    },
    cancel(reason) {
      onCancel?.(reason);
    },
  });
}

/** A byte stream whose first read never settles until cancelled; records cancellation. */
export function stalledStream(first: Uint8Array | null, onCancel?: (reason: unknown) => void): ReadableStream<Uint8Array> {
  let sent = false;
  return new ReadableStream<Uint8Array>({
    pull(controller) {
      if (!sent && first) {
        sent = true;
        controller.enqueue(first);
        return;
      }
      return new Promise<void>(() => undefined);
    },
    cancel(reason) {
      onCancel?.(reason);
    },
  });
}
