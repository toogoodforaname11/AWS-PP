import { COOKIE_NAME } from "@shared/const";

/**
 * The Preview Bearer fallback (Task 9): when the browser blocks the session cookie (Safari ITP, private
 * browsing, WebView), the runtime mirrors the session into sessionStorage so requests can forward it as
 * a Bearer token. tRPC and the attachment deliveries read it through this one parser so they cannot drift.
 * The token is never cached, copied or written here.
 */
const STORE_KEY = "manus-cookie";

// Bumped whenever this tab ends its session, so an in-flight download can tell its session is gone.
let generation = 0;

/** The `app_session_id` value of the first matching `;`-separated entry, or null. */
export function readFallbackSessionToken(): string | null {
  try {
    const raw = sessionStorage.getItem(STORE_KEY);
    if (!raw) return null;
    const prefix = `${COOKIE_NAME}=`;
    const pair = raw.split(";").find((entry) => entry.trim().startsWith(prefix));
    return pair?.trim().slice(prefix.length) || null;
  } catch {
    // sessionStorage unavailable
    return null;
  }
}

/** The request header the fallback contributes, or none. */
export function fallbackAuthorizationHeader(): Record<string, string> {
  const token = readFallbackSessionToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export function clientSessionGeneration(): number {
  return generation;
}

/** Ends this tab's fallback session: marks the change, then removes the stored token. */
export function clearFallbackSession(): void {
  generation += 1;
  try {
    sessionStorage.removeItem(STORE_KEY);
  } catch {
    // sessionStorage unavailable
  }
}
