import { describe, expect, it, vi } from "vitest";
import { clientIntakePayloadSchema } from "@shared/clientIntake";

const jsPdfMock = vi.hoisted(() => {
  const instances: any[] = [];
  class JsPdfMock {
    setProperties = vi.fn();
    setFont = vi.fn();
    setFontSize = vi.fn();
    setTextColor = vi.fn();
    setDrawColor = vi.fn();
    setLineWidth = vi.fn();
    line = vi.fn();
    text = vi.fn();
    splitTextToSize = vi.fn((value: string) => String(value).split("\n"));
    addPage = vi.fn();
    save = vi.fn();
    constructor() {
      instances.push(this);
    }
  }
  return { JsPdfMock, instances };
});

vi.mock("jspdf", () => ({ jsPDF: jsPdfMock.JsPdfMock }));

import {
  buildClientIntakePdfSections,
  exportCompletedClientIntakePdf,
} from "./clientIntakePdf";

describe("client intake PDF export", () => {
  const payload = clientIntakePayloadSchema.parse({
    deceasedFirstName: "Avery",
    deceasedLastName: "Stone",
    dateOfDeath: "2026-02-14",
    deceasedAddress: "12 Cedar Avenue, Victoria, BC",
    willStatus: "will",
    willDate: "2024-01-10",
    willLocation: "Home safe",
    clientName: "Jordan Morgan",
    clientEmail: "jordan@example.com",
    clientPhone: "604-555-0100",
    relationshipToDeceased: "Executor",
    clientNotes: "Please call before sending mail.",
    executors: [
      {
        name: "Morgan Executor",
        relationship: "Friend",
        address: "100 Oak Street",
        email: "morgan@example.com",
        phone: "604-555-0101",
        occupation: "Accountant",
        age: "",
        category: "executor",
      },
    ],
    familyMembers: [],
    estateItems: [
      {
        category: "financial",
        description: "Savings account",
        location: "in_bc",
        value: "12000",
        bankAddress: "",
        accountNumber: "",
        accountHolder: "Avery Stone",
        pid: "",
        legalDescription: "",
        registeredOwner: "",
        ownershipDetails: "",
      },
    ],
    documentsAvailable: ["death_certificate", "original_will"],
    customQuestions: [
      {
        id: "cq_propertyfact1",
        prompt: "Who has keys to the property?",
        helpText: "",
        required: true,
        answer: "Jordan Morgan",
      },
      {
        id: "cq_unanswered2",
        prompt: "Unused prompt",
        helpText: "",
        required: false,
        answer: "",
      },
    ],
  });

  it("builds readable non-empty sections from the submitted payload only", () => {
    const sections = buildClientIntakePdfSections(payload);

    expect(sections.map(section => section.title)).toEqual(
      expect.arrayContaining([
        "Deceased",
        "Last residence",
        "Will information",
        "Client details",
        "Executor 1",
        "Estate asset or debt 1",
        "Documents reported",
        "Case-specific responses",
        "Additional information",
      ])
    );
    expect(sections.flatMap(section => section.rows)).toEqual(
      expect.arrayContaining([
        { label: "First name", value: "Avery" },
        { label: "Date of death", value: "2026-02-14" },
        { label: "Who has keys to the property?", value: "Jordan Morgan" },
      ])
    );
    expect(sections.flatMap(section => section.rows).map(row => row.label)).not.toContain(
      "Unused prompt"
    );
  });

  it("keeps separately reported alias parts visible in the completed intake record", () => {
    const sections = buildClientIntakePdfSections(
      clientIntakePayloadSchema.parse({
        ...payload,
        deceasedAkaFirstName: "Taylor",
        deceasedAkaMiddleName: "Jordan",
        deceasedAkaLastName: "Morgan",
      })
    );

    expect(sections.flatMap(section => section.rows)).toEqual(
      expect.arrayContaining([
        { label: "Other name first name", value: "Taylor" },
        { label: "Other name middle name(s)", value: "Jordan" },
        { label: "Other name last name", value: "Morgan" },
      ])
    );
  });

  it("saves a safe PDF filename based on the submitted display name", () => {
    const filename = exportCompletedClientIntakePdf({
      payload,
      submittedByName: "Jordan Morgan / executor",
      submittedAt: Date.UTC(2026, 1, 14),
    });

    expect(filename).toBe("client-intake-jordan-morgan-executor-2026-02-14.pdf");
    expect(filename).not.toContain("jordan@example.com");
    expect(jsPdfMock.instances).toHaveLength(1);
    expect(jsPdfMock.instances[0].save).toHaveBeenCalledWith(filename);
    expect(jsPdfMock.instances[0].text).toHaveBeenCalledWith(
      "Client intake submission",
      18,
      20
    );
  });
});
