import { describe, expect, it, vi } from "vitest";
import { createTrpcTransportFetch } from "./trpcTransport";
import { browserResponse, chunkedStream } from "./browserResponse.testkit";

describe("tRPC transport timeout handling", () => {
  it("turns a hung request into a controlled unavailable response", async () => {
    const fetchImpl = vi.fn((_input: RequestInfo | URL, init?: RequestInit) => new Promise<Response>((_resolve, reject) => {
      init?.signal?.addEventListener("abort", () => reject(new DOMException("Timed out", "AbortError")), { once: true });
    }));
    const fetchWithTimeout = createTrpcTransportFetch({ fetchImpl, timeoutMs: 1, maxRetries: 0 });

    const response = await fetchWithTimeout("/api/trpc", { method: "GET" });

    expect(fetchImpl).toHaveBeenCalledTimes(1);
    expect(response.status).toBe(503);
    await expect(response.json()).resolves.toMatchObject({
      error: {
        json: {
          message: "The server took too long to respond. Please try again.",
          data: { code: "INTERNAL_SERVER_ERROR", httpStatus: 503 },
        },
      },
    });
  });

  it("keeps the existing bounded retry for an infrastructure HTML 5xx response", async () => {
    const fetchImpl = vi.fn()
      .mockResolvedValueOnce(new Response("temporary gateway page", { status: 503, headers: { "content-type": "text/html" } }))
      .mockResolvedValueOnce(new Response("{}", { status: 200, headers: { "content-type": "application/json" } }));
    const fetchWithTimeout = createTrpcTransportFetch({ fetchImpl, retryDelayMs: () => 0 });

    const response = await fetchWithTimeout("/api/trpc", { method: "GET" });

    expect(fetchImpl).toHaveBeenCalledTimes(2);
    expect(response.status).toBe(200);
  });

  it("does not convert an explicit caller cancellation into a server failure", async () => {
    const controller = new AbortController();
    controller.abort();
    const cancellation = new DOMException("Cancelled", "AbortError");
    const fetchImpl = vi.fn(() => Promise.reject(cancellation));
    const fetchWithTimeout = createTrpcTransportFetch({ fetchImpl, timeoutMs: 1 });

    await expect(fetchWithTimeout("/api/trpc", { signal: controller.signal })).rejects.toBe(cancellation);
  });
});

/**
 * Task 12 (P5, P5b): the backoff wait honours the caller's signal, and a discarded non-JSON error body is cancelled.
 * Fictional data only.
 */
describe("tRPC transport caller abort during backoff and discarded bodies (Task 12)", () => {
  const html503 = () => new Response("temporary gateway page", { status: 503, headers: { "content-type": "text/html" } });
  /** Records whether the promise settled, without awaiting it. */
  const settle = (promise: Promise<unknown>) => {
    const state = { settled: false, rejection: undefined as unknown };
    promise.then(() => { state.settled = true; }, (error) => { state.settled = true; state.rejection = error; });
    return state;
  };

  it("T1: an abort during the backoff after a 503 HTML response rejects at once with the signal's reason and makes no further attempt", async () => {
    vi.useFakeTimers();
    try {
      const controller = new AbortController();
      const reason = new DOMException("Closed", "AbortError");
      const fetchImpl = vi.fn(async () => html503());
      const transport = createTrpcTransportFetch({ fetchImpl });
      const state = settle(transport("/api/trpc/document.preview", { method: "GET", signal: controller.signal }));
      await vi.advanceTimersByTimeAsync(0);
      expect(fetchImpl).toHaveBeenCalledTimes(1);
      expect(state.settled).toBe(false);
      controller.abort(reason);
      await vi.advanceTimersByTimeAsync(0);
      expect(state.settled).toBe(true);
      expect(state.rejection).toBe(reason);
      expect(fetchImpl).toHaveBeenCalledTimes(1);
      expect(vi.getTimerCount()).toBe(0);
    } finally {
      vi.useRealTimers();
    }
  });

  it("T2: an abort during the backoff after a thrown network error rejects at once with the signal's reason", async () => {
    vi.useFakeTimers();
    try {
      const controller = new AbortController();
      const reason = new DOMException("Closed", "AbortError");
      const fetchImpl = vi.fn(async () => { throw new TypeError("Failed to fetch"); });
      const transport = createTrpcTransportFetch({ fetchImpl });
      const state = settle(transport("/api/trpc/document.preview", { method: "GET", signal: controller.signal }));
      await vi.advanceTimersByTimeAsync(0);
      expect(fetchImpl).toHaveBeenCalledTimes(1);
      expect(state.settled).toBe(false);
      controller.abort(reason);
      await vi.advanceTimersByTimeAsync(0);
      expect(state.settled).toBe(true);
      expect(state.rejection).toBe(reason);
      expect(fetchImpl).toHaveBeenCalledTimes(1);
      expect(vi.getTimerCount()).toBe(0);
    } finally {
      vi.useRealTimers();
    }
  });

  it("T3: a signal already aborted when the backoff starts rejects immediately with no second attempt", async () => {
    vi.useFakeTimers();
    try {
      const controller = new AbortController();
      const reason = new DOMException("Closed", "AbortError");
      const fetchImpl = vi.fn(() => new Promise<Response>((resolve) => { controller.abort(reason); resolve(html503()); }));
      const transport = createTrpcTransportFetch({ fetchImpl });
      const state = settle(transport("/api/trpc/document.preview", { method: "GET", signal: controller.signal }));
      await vi.advanceTimersByTimeAsync(0);
      expect(state.settled).toBe(true);
      expect(state.rejection).toBe(reason);
      expect(fetchImpl).toHaveBeenCalledTimes(1);
      expect(vi.getTimerCount()).toBe(0);
    } finally {
      vi.useRealTimers();
    }
  });

  it("T4: every discarded non-JSON error body is cancelled before the retry wait and before the synthetic envelope; a JSON body is never touched", async () => {
    const events: string[] = [];
    const discarded = () => browserResponse(chunkedStream([new TextEncoder().encode("<html>gateway</html>")], () => { events.push("cancel"); }), { status: 503, headers: { "content-type": "text/html" } });
    const fetchImpl = vi.fn(async () => { events.push("fetch"); return discarded(); });
    const transport = createTrpcTransportFetch({ fetchImpl, retryDelayMs: () => { events.push("wait"); return 0; } });
    const response = await transport("/api/trpc/document.preview", { method: "GET" });
    expect(response.status).toBe(503);
    expect(events).toEqual(["fetch", "cancel", "wait", "fetch", "cancel", "wait", "fetch", "cancel"]);

    let jsonCancelled = 0;
    const jsonFetch = vi.fn(async () => browserResponse(chunkedStream([new TextEncoder().encode("{\"ok\":true}")], () => { jsonCancelled += 1; }), { status: 200, headers: { "content-type": "application/json" } }));
    const okTransport = createTrpcTransportFetch({ fetchImpl: jsonFetch });
    const ok = await okTransport("/api/trpc/document.preview", { method: "GET" });
    expect(await ok.json()).toEqual({ ok: true });
    expect(jsonCancelled).toBe(0);
  });
});
