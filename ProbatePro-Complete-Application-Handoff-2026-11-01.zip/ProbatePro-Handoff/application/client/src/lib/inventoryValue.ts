import { isInventoryValueRecorded } from "@shared/types";
import { formatCurrency } from "./formatters";

type InventoryValueForm = {
  category?: string | null;
  value?: unknown;
  dateOfDeathValue?: unknown;
  assessedMarketValue?: unknown;
  accruedInterest?: unknown;
  valueRecorded?: number | null;
  [key: string]: unknown;
};

export type InventoryValueField = "value" | "dateOfDeathValue" | "assessedMarketValue";

function hasEntry(value: unknown): boolean {
  return value !== null && value !== undefined && String(value).trim() !== "";
}

/** Derive the persisted flag from the value inputs visible for this category. */
export function inventoryValueRecordedFromForm(item: InventoryValueForm): 0 | 1 {
  if (item.category === "financial" && hasEntry(item.dateOfDeathValue)) return 1;
  if (item.category === "real_property" && hasEntry(item.assessedMarketValue)) return 1;
  if (hasEntry(item.value)) return 1;
  return 0;
}

/** Category-specific sworn source, falling back to generic input only while the preferred field is blank. */
export function inventoryEffectiveValueInput(item: InventoryValueForm): unknown {
  if (item.category === "financial" && hasEntry(item.dateOfDeathValue)) return item.dateOfDeathValue;
  if (item.category === "real_property" && hasEntry(item.assessedMarketValue)) return item.assessedMarketValue;
  return item.value;
}

/**
 * The single editable FMV shown for real property. Older rows may have the
 * amount in the generic value column; keep that visible until the next save
 * synchronizes the real-property source field. An explicit $0 still wins over
 * a legacy generic amount, while the default zero sentinel remains blank.
 */
export function realPropertyFmvInput(item: InventoryValueForm): string {
  const preferred = item.assessedMarketValue;
  const preferredIsExplicit = hasEntry(preferred)
    && (item.valueRecorded === 1 || Number(preferred) !== 0);
  const selected = preferredIsExplicit ? preferred : item.value;
  return selected === null || selected === undefined ? "" : String(selected);
}

/**
 * Keep the real-property display and sworn source aligned without converting a
 * blank/pending FMV into an explicit $0. The persisted valueRecorded flag is
 * what distinguishes the database's zero sentinel from a real entered zero.
 */
export function updateRealPropertyFmvInput(
  item: InventoryValueForm,
  rawValue: string,
): InventoryValueForm {
  const formatted = formatCurrency(rawValue);
  const next = { ...item, value: formatted, assessedMarketValue: formatted };
  return { ...next, valueRecorded: inventoryValueRecordedFromForm(next) };
}

/** Update a value input while retaining whether an explicit zero was entered. */
export function updateInventoryValueInput(
  item: InventoryValueForm,
  field: InventoryValueField,
  rawValue: string,
): InventoryValueForm {
  const next = { ...item, [field]: formatCurrency(rawValue) };
  return { ...next, valueRecorded: inventoryValueRecordedFromForm(next) };
}

function centsToInput(value: unknown, showZero: boolean): string {
  const cents = Number(value || 0);
  if (!Number.isFinite(cents) || (cents === 0 && !showZero)) return "";
  return formatCurrency((cents / 100).toFixed(2));
}

/**
 * Convert a database row to edit-form strings without turning a legacy default
 * zero into an explicit value when an unrelated field is edited and saved.
 */
export function hydrateInventoryItemForEdit<T extends InventoryValueForm>(item: T): T & { valueRecorded: 0 | 1 } {
  const recorded = isInventoryValueRecorded({
    category: String(item.category || "unknown"),
    value: Number(item.value || 0),
    dateOfDeathValue: Number(item.dateOfDeathValue || 0),
    assessedMarketValue: Number(item.assessedMarketValue || 0),
    valueRecorded: item.valueRecorded,
  });
  const explicit = item.valueRecorded === 1;

  return {
    ...item,
    value: centsToInput(item.value, explicit),
    accruedInterest: centsToInput(item.accruedInterest, false),
    dateOfDeathValue: centsToInput(item.dateOfDeathValue, explicit),
    assessedMarketValue: centsToInput(item.assessedMarketValue, explicit),
    valueRecorded: recorded ? 1 : 0,
  };
}
