import { describe, expect, it } from "vitest";
import { moveCodicilOrder } from "./codicilOrder";

describe("moveCodicilOrder", () => {
  it("preserves every source index while moving a codicil to an earlier position", () => {
    expect(moveCodicilOrder(4, 3, 1)).toEqual([0, 3, 1, 2]);
  });

  it("preserves every source index while moving a codicil to a later position", () => {
    expect(moveCodicilOrder(4, 0, 2)).toEqual([1, 2, 0, 3]);
  });

  it("rejects no-op and out-of-range moves before a server mutation is attempted", () => {
    expect(moveCodicilOrder(3, 1, 1)).toBeNull();
    expect(moveCodicilOrder(3, -1, 0)).toBeNull();
    expect(moveCodicilOrder(3, 0, 3)).toBeNull();
  });
});
