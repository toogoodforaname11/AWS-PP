import JSZip from "jszip";

export const XLSX_MIME_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

const XML_DECLARATION = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
const MAX_WORKSHEET_XML_CHARACTERS = 5_000_000;

export interface XlsxWorkbookInput {
  sheetName: string;
  headers: readonly string[];
  rows: readonly Record<string, string | number | null | undefined>[];
}

function xmlEscape(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function spreadsheetColumnName(index: number) {
  let column = "";
  let remaining = index;
  while (remaining > 0) {
    const remainder = (remaining - 1) % 26;
    column = String.fromCharCode(65 + remainder) + column;
    remaining = Math.floor((remaining - 1) / 26);
  }
  return column;
}

function spreadsheetColumnIndex(reference: string) {
  const column = reference.match(/[A-Z]+/i)?.[0]?.toUpperCase() ?? "";
  return column.split("").reduce((index, character) => index * 26 + character.charCodeAt(0) - 64, 0);
}

function inlineStringCell(reference: string, value: string) {
  const preserveSpace = /^\s|\s$/.test(value) ? ' xml:space="preserve"' : "";
  return `<c r="${reference}" t="inlineStr"><is><t${preserveSpace}>${xmlEscape(value)}</t></is></c>`;
}

function cellXml(reference: string, value: string | number | null | undefined) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return `<c r="${reference}"><v>${value}</v></c>`;
  }
  return inlineStringCell(reference, String(value ?? ""));
}

function worksheetXml(headers: readonly string[], rows: readonly Record<string, string | number | null | undefined>[]) {
  const renderedRows = [
    `<row r="1">${headers.map((header, index) => inlineStringCell(`${spreadsheetColumnName(index + 1)}1`, header)).join("")}</row>`,
    ...rows.map((row, rowIndex) => {
      const spreadsheetRow = rowIndex + 2;
      return `<row r="${spreadsheetRow}">${headers.map((header, columnIndex) => cellXml(`${spreadsheetColumnName(columnIndex + 1)}${spreadsheetRow}`, row[header])).join("")}</row>`;
    }),
  ];
  const lastColumn = spreadsheetColumnName(Math.max(headers.length, 1));
  const lastRow = rows.length + 1;
  return `${XML_DECLARATION}<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><dimension ref="A1:${lastColumn}${lastRow}"/><autoFilter ref="A1:${lastColumn}${lastRow}"/><sheetData>${renderedRows.join("")}</sheetData></worksheet>`;
}

/** Creates a portable .xlsx workbook without a runtime workbook-parser dependency. */
export async function createXlsxWorkbook({ sheetName, headers, rows }: XlsxWorkbookInput) {
  const zip = new JSZip();
  const escapedSheetName = xmlEscape(sheetName);
  const worksheet = worksheetXml(headers, rows);

  zip.file(
    "[Content_Types].xml",
    `${XML_DECLARATION}<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`,
  );
  zip.file(
    "_rels/.rels",
    `${XML_DECLARATION}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`,
  );
  zip.file(
    "xl/workbook.xml",
    `${XML_DECLARATION}<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="${escapedSheetName}" sheetId="1" r:id="rId1"/></sheets></workbook>`,
  );
  zip.file(
    "xl/_rels/workbook.xml.rels",
    `${XML_DECLARATION}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>`,
  );
  zip.file("xl/worksheets/sheet1.xml", worksheet);

  const data = await zip.generateAsync({ type: "arraybuffer", compression: "DEFLATE", compressionOptions: { level: 6 } });
  return new Blob([data], { type: XLSX_MIME_TYPE });
}

function sharedStrings(document: Document) {
  return Array.from(document.getElementsByTagName("si"), (item) => Array.from(item.getElementsByTagName("t"), (text) => text.textContent ?? "").join(""));
}

function firstWorksheetPath(zip: JSZip) {
  return Object.keys(zip.files)
    .filter((path) => /^xl\/worksheets\/sheet\d+\.xml$/i.test(path))
    .sort((left, right) => Number(left.match(/\d+/)?.[0] ?? 0) - Number(right.match(/\d+/)?.[0] ?? 0))[0];
}

function parseWorksheetRows(worksheetDocument: Document, strings: string[]) {
  return Array.from(worksheetDocument.getElementsByTagName("row"), (row) => {
    const values: string[] = [];
    Array.from(row.getElementsByTagName("c")).forEach((cell) => {
      const reference = cell.getAttribute("r") ?? "";
      const index = spreadsheetColumnIndex(reference);
      if (!index) return;
      const type = cell.getAttribute("t");
      const value = type === "inlineStr"
        ? Array.from(cell.getElementsByTagName("t"), (text) => text.textContent ?? "").join("")
        : cell.getElementsByTagName("v")[0]?.textContent ?? "";
      values[index - 1] = type === "s" ? strings[Number(value)] ?? "" : value;
    });
    return values;
  });
}

/** Reads the first worksheet into records keyed by its first header row. */
export async function readFirstXlsxWorksheetRows(file: Blob) {
  const zip = await JSZip.loadAsync(await file.arrayBuffer());
  const worksheetPath = firstWorksheetPath(zip);
  const worksheetFile = worksheetPath ? zip.file(worksheetPath) : null;
  if (!worksheetFile) throw new Error("WORKSHEET_MISSING");

  const worksheetXmlText = await worksheetFile.async("string");
  if (worksheetXmlText.length > MAX_WORKSHEET_XML_CHARACTERS) throw new Error("WORKSHEET_TOO_LARGE");
  const parser = new DOMParser();
  const sharedStringsFile = zip.file("xl/sharedStrings.xml");
  const strings = sharedStringsFile ? sharedStrings(parser.parseFromString(await sharedStringsFile.async("string"), "application/xml")) : [];
  const rows = parseWorksheetRows(parser.parseFromString(worksheetXmlText, "application/xml"), strings);
  const headers = rows[0]?.map((value) => value.trim()) ?? [];
  if (headers.every((header) => !header)) throw new Error("HEADERS_MISSING");

  return rows.slice(1).map((values) => {
    const record: Record<string, string> = {};
    headers.forEach((header, index) => {
      if (header) record[header] = values[index] ?? "";
    });
    return record;
  });
}
