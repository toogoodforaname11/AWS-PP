/**
 * Task 12: the app's tRPC links through the real client. The preview query travels alone on a bounded, cancellable
 * link; everything else keeps the batch link; the two share one transport. A fetch stub at the network boundary
 * honours abort signals and answers with real envelopes. Fictional data only.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { TRPCClientError, createTRPCClient } from "@trpc/client";
import superjson from "superjson";
import type { AppRouter } from "../../../server/routers";
import { browserResponse, chunkedStream } from "./browserResponse.testkit";
import { createAppTrpcLinks } from "./trpcLinks";

/** The approved preview ceiling (P2): 4 MiB of decoded envelope bytes, written as a literal so this suite fails on behaviour. */
const PREVIEW_BODY_CEILING_BYTES = 4 * 1024 * 1024;
const NEUTRAL = "The preview could not be loaded. Please try again.";
const encoder = new TextEncoder();
const PREVIEW_INPUT = { estateId: "e1", formCode: "P1", signatoryType: "executor", signatureDate: "2026-07-12" };
const SECTIONS = [{ type: "paragraph", text: "Fictional preview body" }];
const PREVIEW_PAYLOAD = { formCode: "P1", formName: "Fictional", sections: SECTIONS };

type Recorded = { url: string; init: RequestInit; procedures: string[]; batch: boolean; inputs: unknown[] };
type Route = (request: Recorded) => Response | Promise<Response>;

const envelope = (payload: unknown) => JSON.stringify({ result: { data: superjson.serialize(payload) } });
const json = (body: string, status = 200) => browserResponse(body, { status, headers: { "content-type": "application/json" } });
const decodeInputs = (url: URL, batch: boolean): unknown[] => {
  const raw = url.searchParams.get("input");
  if (raw === null) return [];
  const parsed = JSON.parse(raw);
  return batch ? Object.keys(parsed).sort().map((k) => superjson.deserialize(parsed[k])) : [superjson.deserialize(parsed)];
};

/** Answers each procedure of a request by name; batch requests get one envelope per op. */
const byProcedure = (answers: Record<string, unknown>): Route => (request) => {
  const bodies = request.procedures.map((name) => {
    if (!(name in answers)) throw new Error(`no answer for ${name}`);
    return { result: { data: superjson.serialize(answers[name]) } };
  });
  return json(JSON.stringify(request.batch ? bodies : bodies[0]));
};

function harness() {
  const requests: Recorded[] = [];
  let route: Route = byProcedure({ "document.preview": PREVIEW_PAYLOAD, "settings.get": { lawyerName: "Fictional Lawyer" }, "contact.list": [], "document.generate": { id: "doc_1" } });
  const fetchImpl = vi.fn((input: RequestInfo | URL, init?: RequestInit) => new Promise<Response>((resolve, reject) => {
    const url = new URL(String(input), "http://localhost");
    const batch = url.searchParams.get("batch") === "1";
    const procedures = url.pathname.replace("/api/trpc/", "").split(",");
    const request: Recorded = { url: String(input), init: init ?? {}, procedures, batch, inputs: decodeInputs(url, batch) };
    requests.push(request);
    const signal = init?.signal;
    const aborted = () => reject(signal?.reason ?? new DOMException("The operation was aborted.", "AbortError"));
    if (signal?.aborted) return aborted();
    signal?.addEventListener("abort", aborted, { once: true });
    Promise.resolve().then(() => route(request)).then(resolve, reject);
  }));
  const client = createTRPCClient<AppRouter>({ links: createAppTrpcLinks({ fetchImpl, retryDelayMs: () => 1000 }) });
  return { client, requests, fetchImpl, setRoute: (next: Route) => { route = next; } };
}

const authorizationOf = (request: Recorded) => new Headers(request.init.headers as HeadersInit).get("authorization");
const flush = () => new Promise((resolve) => setTimeout(resolve, 0));

beforeEach(() => { sessionStorage.clear(); });
afterEach(() => { vi.useRealTimers(); sessionStorage.clear(); });

describe("createAppTrpcLinks — routing (L1, L1a, L2)", () => {
  it("L1: the preview query is one un-batched GET carrying the SuperJSON input and the Bearer header, never a token in the URL", async () => {
    sessionStorage.setItem("manus-cookie", "app_session_id=fictional-token-1");
    const { client, requests } = harness();
    const result = await client.document.preview.query(PREVIEW_INPUT as never);
    expect(result).toEqual(PREVIEW_PAYLOAD);
    expect(requests).toHaveLength(1);
    const [request] = requests;
    expect(request.init.method).toBe("GET");
    expect(request.batch).toBe(false);
    expect(request.procedures).toEqual(["document.preview"]);
    expect(request.inputs).toEqual([PREVIEW_INPUT]);
    expect(authorizationOf(request)).toBe("Bearer fictional-token-1");
    expect(request.url).not.toContain("fictional-token-1");
    expect(request.init.credentials).toBe("include");
  });

  it("L1: cookie mode sends no Authorization header on the preview link", async () => {
    const { client, requests } = harness();
    await client.document.preview.query(PREVIEW_INPUT as never);
    expect(authorizationOf(requests[0])).toBeNull();
  });

  it("L1a: a token rotated between two preview requests is carried by the second (per-request headers)", async () => {
    sessionStorage.setItem("manus-cookie", "app_session_id=fictional-token-1");
    const { client, requests } = harness();
    await client.document.preview.query(PREVIEW_INPUT as never);
    sessionStorage.setItem("manus-cookie", "app_session_id=fictional-token-2");
    await client.document.preview.query(PREVIEW_INPUT as never);
    expect(requests.map(authorizationOf)).toEqual(["Bearer fictional-token-1", "Bearer fictional-token-2"]);
  });

  it("L2: other queries in one tick are batched and a mutation posts; neither passes through the bounded reader", async () => {
    const { client, requests, setRoute } = harness();
    // A body far over the preview ceiling: only an unbounded path can resolve it.
    const padding = "p".repeat(PREVIEW_BODY_CEILING_BYTES + 1024);
    setRoute((request) => {
      const bodies = request.procedures.map((name) => ({ result: { data: superjson.serialize(name === "document.generate" ? { id: "doc_1", padding } : { padding }) } }));
      return json(JSON.stringify(bodies));
    });
    const [settings, contacts] = await Promise.all([client.settings.get.query(), client.contact.list.query({ estateId: "e1" } as never)]);
    expect((settings as unknown as { padding: string }).padding).toHaveLength(padding.length);
    expect((contacts as unknown as { padding: string }).padding).toHaveLength(padding.length);
    expect(requests).toHaveLength(1);
    expect(requests[0].batch).toBe(true);
    expect(requests[0].procedures.sort()).toEqual(["contact.list", "settings.get"]);
    const generated = await client.document.generate.mutate({ estateId: "e1", formCode: "P1" } as never);
    expect((generated as { id: string }).id).toBe("doc_1");
    expect(requests[1].init.method).toBe("POST");
  });
});

describe("createAppTrpcLinks — isolation (L3, L5)", () => {
  it("L3: aborting the preview's own signal aborts only its request; a query issued in the same tick resolves", async () => {
    const { client, requests, setRoute } = harness();
    let releasePreview: (() => void) | undefined;
    setRoute((request) => request.procedures[0] === "document.preview"
      ? new Promise<Response>((resolve) => { releasePreview = () => resolve(json(envelope(PREVIEW_PAYLOAD))); })
      : json(JSON.stringify([{ result: { data: superjson.serialize({ lawyerName: "Fictional Lawyer" }) } }])));
    const controller = new AbortController();
    const preview = client.document.preview.query(PREVIEW_INPUT as never, { signal: controller.signal });
    const settings = client.settings.get.query();
    await flush();
    expect(requests).toHaveLength(2);
    const reason = new DOMException("Closed", "AbortError");
    controller.abort(reason);
    const error = await preview.catch((e: unknown) => e);
    expect(error).toBeInstanceOf(TRPCClientError);
    // Mid-flight, the shared transport aborts its own controller, so the cause is that controller's AbortError, never a
    // server failure; the caller's reason object itself is preserved on the backoff path (L6, T1-T3).
    expect(((error as TRPCClientError<AppRouter>).cause as { name?: string })?.name).toBe("AbortError");
    expect((error as TRPCClientError<AppRouter>).data).toBeUndefined();
    expect(requests.find((r) => r.procedures[0] === "document.preview")?.init.signal?.aborted).toBe(true);
    expect(requests.find((r) => r.batch)?.init.signal?.aborted ?? false).toBe(false);
    await expect(settings).resolves.toEqual({ lawyerName: "Fictional Lawyer" });
    releasePreview?.();
  });

  it("L5: a bounded-reader refusal on the preview leaves a concurrent batch untouched", async () => {
    const { client, setRoute } = harness();
    const oversize = "{\"result\":{\"data\":{\"json\":{\"sections\":[\"" + "x".repeat(PREVIEW_BODY_CEILING_BYTES) + "\"]}}}}";
    setRoute((request) => request.procedures[0] === "document.preview"
      ? json(oversize)
      : json(JSON.stringify([{ result: { data: superjson.serialize({ lawyerName: "Fictional Lawyer" }) } }])));
    const preview = client.document.preview.query(PREVIEW_INPUT as never);
    const settings = client.settings.get.query();
    const error = await preview.catch((e: unknown) => e);
    expect(error).toBeInstanceOf(TRPCClientError);
    expect((error as TRPCClientError<AppRouter>).message).toBe(NEUTRAL);
    expect((error as TRPCClientError<AppRouter>).data).toBeUndefined();
    expect((error as TRPCClientError<AppRouter>).meta).toBeUndefined();
    await expect(settings).resolves.toEqual({ lawyerName: "Fictional Lawyer" });
  });
});

describe("createAppTrpcLinks — rotation and backoff (L4, L6)", () => {
  it("L4: X-Rotated-Session is stored from a preview response and from a batch response", async () => {
    const { client, setRoute } = harness();
    setRoute((request) => {
      const rotated = request.batch ? "app_session_id=rotated-batch" : "app_session_id=rotated-preview";
      const bodies = request.procedures.map((name) => ({ result: { data: superjson.serialize(name === "document.preview" ? PREVIEW_PAYLOAD : { lawyerName: "Fictional Lawyer" }) } }));
      return browserResponse(JSON.stringify(request.batch ? bodies : bodies[0]), { status: 200, headers: { "content-type": "application/json", "X-Rotated-Session": rotated } });
    });
    await client.document.preview.query(PREVIEW_INPUT as never);
    expect(sessionStorage.getItem("manus-cookie")).toBe("app_session_id=rotated-preview");
    await client.settings.get.query();
    expect(sessionStorage.getItem("manus-cookie")).toBe("app_session_id=rotated-batch");
  });

  it("L6: a caller abort during the transport's backoff makes no further attempt and surfaces the abort reason", async () => {
    vi.useFakeTimers();
    const { client, fetchImpl, setRoute } = harness();
    setRoute(() => browserResponse("<html>gateway</html>", { status: 503, headers: { "content-type": "text/html" } }));
    const controller = new AbortController();
    const reason = new DOMException("Closed", "AbortError");
    const preview = client.document.preview.query(PREVIEW_INPUT as never, { signal: controller.signal });
    const outcome = { settled: false, error: undefined as unknown };
    preview.then(() => { outcome.settled = true; }, (e: unknown) => { outcome.settled = true; outcome.error = e; });
    await vi.advanceTimersByTimeAsync(0);
    expect(fetchImpl).toHaveBeenCalledTimes(1);
    expect(outcome.settled).toBe(false);
    controller.abort(reason);
    await vi.advanceTimersByTimeAsync(0);
    expect(outcome.settled).toBe(true);
    expect(outcome.error).toBeInstanceOf(TRPCClientError);
    expect((outcome.error as TRPCClientError<AppRouter>).cause).toBe(reason);
    await vi.advanceTimersByTimeAsync(5000);
    expect(fetchImpl).toHaveBeenCalledTimes(1);
  });
});

describe("createAppTrpcLinks — payload validation link (L7)", () => {
  it("rejects a malformed preview envelope before the promise resolves, with the neutral sentence and no data", async () => {
    const { client, setRoute } = harness();
    setRoute(() => json(envelope({ formCode: "P1", formName: "Fictional", sections: [null] })));
    const error = await client.document.preview.query(PREVIEW_INPUT as never).catch((e: unknown) => e);
    expect(error).toBeInstanceOf(TRPCClientError);
    expect((error as TRPCClientError<AppRouter>).message).toBe(NEUTRAL);
    expect((error as TRPCClientError<AppRouter>).data).toBeUndefined();
    expect((error as TRPCClientError<AppRouter>).meta).toBeUndefined();
  });

  it("forwards a well-formed preview envelope and never inspects other procedures", async () => {
    const { client, setRoute } = harness();
    setRoute(byProcedure({ "document.preview": PREVIEW_PAYLOAD, "settings.get": { sections: "not a preview; untouched" } }));
    await expect(client.document.preview.query(PREVIEW_INPUT as never)).resolves.toEqual(PREVIEW_PAYLOAD);
    await expect(client.settings.get.query()).resolves.toEqual({ sections: "not a preview; untouched" });
  });

  it("streams through the bounded reader: a chunked well-formed envelope resolves byte for byte", async () => {
    const { client, setRoute } = harness();
    const body = encoder.encode(envelope(PREVIEW_PAYLOAD));
    setRoute(() => browserResponse(chunkedStream([body.subarray(0, 5), body.subarray(5, 40), body.subarray(40)]), { status: 200, headers: { "content-type": "application/json" } }));
    await expect(client.document.preview.query(PREVIEW_INPUT as never)).resolves.toEqual(PREVIEW_PAYLOAD);
  });
});
