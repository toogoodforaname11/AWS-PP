/**
 * Task 12: the preview's bounded, cancellable body reader and the modal-side rules that go with it.
 *
 * The reader wraps the Response the shared transport returns for the preview query only. It bounds the body in
 * bytes and time before tRPC parses it, drops every byte on any refusal (never a partial preview), and rethrows a
 * caller abort as the caller's own reason. It never parses JSON, never inspects a section and never logs: the legal
 * content passes through untouched or not at all.
 */
import { hashKey } from "@tanstack/react-query";
import { clientSessionGeneration } from "./fallbackSession";

export const PREVIEW_UNAVAILABLE_SENTENCE = "The preview could not be loaded. Please try again.";
/** Decoded bytes of the whole tRPC/SuperJSON envelope of a 2xx preview (P2, provisional; the probe checks headroom). */
export const PREVIEW_BODY_CEILING_BYTES = 4 * 1024 * 1024;
/** Decoded bytes of a refusal (status >= 400) envelope. */
export const PREVIEW_REFUSAL_BODY_LIMIT_BYTES = 16 * 1024;
/** Longest gap between body chunks, armed before the first read. */
export const PREVIEW_BODY_IDLE_TIMEOUT_MS = 15_000;
/** Longest body phase, headers to last byte. */
export const PREVIEW_BODY_TOTAL_TIMEOUT_MS = 60_000;

export type PreviewTransportReason = "not-json" | "too-large" | "body-timeout" | "incomplete" | "session-ended";

/** A refusal decided on this side of the wire: only its reason and the approved neutral sentence, nothing else (P11). */
export class PreviewTransportError extends Error {
  readonly reason: PreviewTransportReason;
  constructor(reason: PreviewTransportReason) {
    super(PREVIEW_UNAVAILABLE_SENTENCE);
    Object.defineProperty(this, "name", { value: "PreviewTransportError", enumerable: false });
    this.reason = reason;
  }
}

/** A well-formed envelope whose payload is not a preview the modal can render; rejected whole before any cache write. */
export class PreviewPayloadError extends Error {
  constructor() {
    super(PREVIEW_UNAVAILABLE_SENTENCE);
    Object.defineProperty(this, "name", { value: "PreviewPayloadError", enumerable: false });
  }
}

type FetchLike = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

const abortReasonOf = (signal: AbortSignal): unknown => signal.reason ?? new DOMException("The operation was aborted.", "AbortError");
const cancelQuietly = (body: ReadableStream<Uint8Array> | null | undefined): void => { void body?.cancel().catch(() => undefined); };

export function createPreviewTransportFetch(inner: FetchLike): FetchLike {
  return async (input, init) => {
    const generationAtStart = clientSessionGeneration();
    const response = await inner(input, init);
    const signal = init?.signal ?? null;
    if (signal?.aborted) { cancelQuietly(response.body); throw abortReasonOf(signal); }
    if (clientSessionGeneration() !== generationAtStart) { cancelQuietly(response.body); throw new PreviewTransportError("session-ended"); }
    if (response.status === 204 || response.status === 205 || response.status === 304 || !response.body) return response;
    const contentType = response.headers.get("content-type") ?? "";
    if (response.status < 400 && !contentType.includes("application/json")) { cancelQuietly(response.body); throw new PreviewTransportError("not-json"); }
    const limit = response.status >= 400 ? PREVIEW_REFUSAL_BODY_LIMIT_BYTES : PREVIEW_BODY_CEILING_BYTES;

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    const halted = { set: false, error: undefined as unknown };
    const halt = (error: unknown): void => {
      if (halted.set) return;
      halted.set = true;
      halted.error = error;
      void reader.cancel().catch(() => undefined);
    };
    const onAbort = (): void => halt(abortReasonOf(signal!));
    const timeout = (): void => halt(new PreviewTransportError("body-timeout"));
    let idleTimer: ReturnType<typeof setTimeout> | undefined;
    const touch = (): void => { clearTimeout(idleTimer); idleTimer = setTimeout(timeout, PREVIEW_BODY_IDLE_TIMEOUT_MS); };
    const totalTimer = setTimeout(timeout, PREVIEW_BODY_TOTAL_TIMEOUT_MS);
    signal?.addEventListener("abort", onAbort, { once: true });
    let received = 0;
    let text = "";
    try {
      touch();
      for (;;) {
        let chunk: ReadableStreamReadResult<Uint8Array>;
        try {
          chunk = await reader.read();
        } catch (error) {
          if (halted.set) throw halted.error;
          throw new PreviewTransportError("incomplete");
        }
        // A stop decided while this read was pending outranks whatever the read returned.
        if (halted.set) throw halted.error;
        if (chunk.done) break;
        received += chunk.value.byteLength;
        if (received > limit) { halt(new PreviewTransportError("too-large")); throw halted.error; }
        if (clientSessionGeneration() !== generationAtStart) { halt(new PreviewTransportError("session-ended")); throw halted.error; }
        touch();
        text += decoder.decode(chunk.value, { stream: true });
      }
      text += decoder.decode();
      if (clientSessionGeneration() !== generationAtStart) { halt(new PreviewTransportError("session-ended")); throw halted.error; }
      return new Response(text, { status: response.status, headers: { "content-type": contentType || "application/json" } });
    } finally {
      clearTimeout(idleTimer);
      clearTimeout(totalTimer);
      signal?.removeEventListener("abort", onAbort);
    }
  };
}

/** The Alert's copy rule (P3): an envelope error keeps its already-public sentence; every client-side cause is neutral. */
export function previewErrorMessage(error: { message: string; data?: unknown } | null | undefined): string {
  return error?.data ? error.message : PREVIEW_UNAVAILABLE_SENTENCE;
}

/** The preview's retry rule (P4): envelope errors keep React Query's three retries; client-side causes are terminal. */
export function previewRetry(failureCount: number, error: unknown): boolean {
  return Boolean((error as { data?: unknown } | null | undefined)?.data) && failureCount < 3;
}

const SECTION_TYPES = new Set(["heading", "paragraph", "checkbox", "signature", "table", "separator", "letterhead_image", "letterhead_docx", "letter_recipient_block", "pagebreak"]);
const ALIGNS = new Set(["left", "right", "center"]);
const BOOLEAN_FLAGS = ["bold", "italic", "center", "checked", "hideUnchecked", "hideMarker", "indent", "suppressRule"] as const;
const isRecord = (value: unknown): value is Record<string, unknown> => typeof value === "object" && value !== null && !Array.isArray(value);
const optionalString = (value: unknown): boolean => value === undefined || typeof value === "string";
const optionalBoolean = (value: unknown): boolean => value === undefined || typeof value === "boolean";
const optionalAlign = (value: unknown): boolean => value === undefined || (typeof value === "string" && ALIGNS.has(value));
const stringArray = (value: unknown): boolean => Array.isArray(value) && value.every((entry) => typeof entry === "string");

function wellFormedRow(row: unknown): boolean {
  if (!isRecord(row)) return false;
  if (!stringArray(row.cells)) return false;
  if (!optionalBoolean(row.header) || !optionalBoolean(row.italic)) return false;
  if (row.colSpans !== undefined && !(Array.isArray(row.colSpans) && row.colSpans.every((span) => typeof span === "number" && Number.isFinite(span)))) return false;
  if (row.cellAligns !== undefined && !(Array.isArray(row.cellAligns) && row.cellAligns.every((align) => typeof align === "string" && ALIGNS.has(align)))) return false;
  return true;
}

function wellFormedSection(section: unknown): boolean {
  if (!isRecord(section)) return false;
  if (typeof section.type !== "string" || !SECTION_TYPES.has(section.type)) return false;
  if (!optionalString(section.text) || !optionalString(section.imageUrl) || !optionalString(section.deliveryMethod)) return false;
  if (!BOOLEAN_FLAGS.every((flag) => optionalBoolean(section[flag]))) return false;
  if (!optionalAlign(section.align)) return false;
  if (section.recipientLines !== undefined && !stringArray(section.recipientLines)) return false;
  if (section.rows !== undefined && !(Array.isArray(section.rows) && section.rows.every(wellFormedRow))) return false;
  return true;
}

/**
 * Accepts exactly what the server's PreviewSection shape and the frozen markup's reads require, returns the same
 * reference, and never alters, filters, coerces or normalises anything. Unknown extra fields are allowed; empty
 * drafts (no sections, empty strings, empty rows, absent optional fields) are legitimate.
 */
export function validatePreviewPayload<T>(payload: T): T {
  const record: unknown = payload;
  if (!isRecord(record) || !Array.isArray(record.sections) || !record.sections.every(wellFormedSection)) throw new PreviewPayloadError();
  return payload;
}

/**
 * Partitions the preview cache by the tab's session generation (P8): a session end makes every earlier entry unreachable.
 * Default-hashed helpers (utils.document.preview.getData/setData/invalidate, queryClient.getQueryData(queryKey)) hash
 * without the generation and cannot see these entries; the modal's useQuery is the only caller today.
 */
export function previewQueryKeyHash(queryKey: readonly unknown[]): string {
  return hashKey([queryKey, clientSessionGeneration()]);
}
