import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { toast } from "sonner";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Opens a stored file (will, codicil, sealed order, citation evidence…) in a
 * new tab via the ownership-checked `/manus-storage/` proxy — the same route
 * the will/codicil viewers use, so every "View" affordance behaves identically.
 */
function encodedStoragePath(storageKey: string): string {
  return storageKey.split("/").map(encodeURIComponent).join("/");
}

export function previewStoredFile(storageKey: string) {
  // The proxy authenticates this same-origin navigation and then redirects to a
  // five-minute S3 URL. Do not fetch the redirect: a private S3 bucket has no
  // browser CORS requirement, and direct navigation does not need one.
  const opened = window.open(
    `/manus-storage/${encodedStoragePath(storageKey)}`,
    "_blank",
    "noopener,noreferrer",
  );
  if (!opened) toast.error("Pop-up blocked. Allow pop-ups to preview stored files.");
}

export function downloadFromUrl(url: string, filename?: string) {
  const isStorageProxy = url.startsWith("/manus-storage/");
  const href = isStorageProxy && filename
    ? `${url}${url.includes("?") ? "&" : "?"}download=${encodeURIComponent(filename)}`
    : url;
  const anchor = document.createElement("a");
  anchor.href = href;
  // The initial URL is same-origin. Mark it as an attachment navigation so
  // browsers preserve the user-visible download handoff across the proxy's
  // signed redirect. Hidden iframe targets can suppress such attachment
  // navigations in Chromium after an asynchronous generate request, leaving a
  // successful form response with no download.
  if (filename) anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
}

/** A per-click id the delivery routes log; RFC 4122 v4 either way. */
export function newAttemptId(): string {
  if (typeof crypto.randomUUID === "function") return crypto.randomUUID();
  // randomUUID needs a secure context; getRandomValues does not.
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
