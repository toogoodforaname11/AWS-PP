/**
 * Task 9: the one reader of the Preview Bearer fallback (sessionStorage "manus-cookie"). tRPC
 * (main.tsx) and the attachment deliveries share it, so its parse must stay exactly the original
 * main.tsx logic: the first ";"-separated entry whose trim starts with "app_session_id=".
 */
import { afterEach, describe, expect, it, vi } from "vitest";
import { clearFallbackSession, clientSessionGeneration, fallbackAuthorizationHeader, readFallbackSessionToken } from "./fallbackSession";

/** The pre-Task 9 main.tsx headers() body, kept here verbatim as the parity oracle. */
function originalMainHeaders(): Record<string, string> {
  try {
    const raw = sessionStorage.getItem("manus-cookie");
    if (raw) {
      const prefix = "app_session_id=";
      const pair = raw.split(";").find((s) => s.trim().startsWith(prefix));
      const token = pair?.trim().slice(prefix.length);
      if (token) return { Authorization: `Bearer ${token}` };
    }
  } catch {
    // sessionStorage unavailable
  }
  return {};
}

afterEach(() => {
  vi.restoreAllMocks();
  sessionStorage.clear();
});

describe("Task 9: the shared Preview Bearer fallback reader", () => {
  it.each([
    ["the exact pair", "app_session_id=fictional.a.b", "fictional.a.b"],
    ["the first of several matching pairs", "app_session_id=first; app_session_id=second", "first"],
    ["a pair after other cookies, with whitespace", "theme=dark;   app_session_id=spaced.token  ; other=1", "spaced.token"],
    ["a value containing '='", "app_session_id=abc==", "abc=="],
    ["an empty value", "app_session_id=", null],
    ["only lookalike names", "xapp_session_id=nope; app_session_id_old=nope; app_session=nope", null],
    ["lookalikes before the real pair", "xapp_session_id=nope; app_session_id=real", "real"],
    ["no stored value", null, null],
  ])("reads %s", (_label, stored, expected) => {
    if (stored !== null) sessionStorage.setItem("manus-cookie", stored);
    expect(readFallbackSessionToken()).toBe(expected);
    expect(fallbackAuthorizationHeader()).toEqual(originalMainHeaders());
    expect(fallbackAuthorizationHeader()).toEqual(expected ? { Authorization: `Bearer ${expected}` } : {});
  });

  it("returns no token, and no header, when storage throws", () => {
    vi.spyOn(Storage.prototype, "getItem").mockImplementation(() => { throw new DOMException("blocked", "SecurityError"); });
    expect(readFallbackSessionToken()).toBeNull();
    expect(fallbackAuthorizationHeader()).toEqual({});
  });

  it("reads afresh on every call, so a later retry sees the current token", () => {
    sessionStorage.setItem("manus-cookie", "app_session_id=first");
    expect(readFallbackSessionToken()).toBe("first");
    sessionStorage.setItem("manus-cookie", "app_session_id=rotated");
    expect(readFallbackSessionToken()).toBe("rotated");
  });

  it("clearing the session removes the stored value and marks a new session generation", () => {
    sessionStorage.setItem("manus-cookie", "app_session_id=fictional");
    const before = clientSessionGeneration();
    clearFallbackSession();
    expect(sessionStorage.getItem("manus-cookie")).toBeNull();
    expect(readFallbackSessionToken()).toBeNull();
    expect(clientSessionGeneration()).toBe(before + 1);
  });

  it("still marks the session ended when storage refuses the removal", () => {
    vi.spyOn(Storage.prototype, "removeItem").mockImplementation(() => { throw new DOMException("blocked", "SecurityError"); });
    const before = clientSessionGeneration();
    expect(() => clearFallbackSession()).not.toThrow();
    expect(clientSessionGeneration()).toBe(before + 1);
  });
});
