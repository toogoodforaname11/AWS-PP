import { describe, expect, it } from "vitest";
import { JSDOM } from "jsdom";
import { renderPrintDocument } from "./printDocument";

describe("print preview DOM construction", () => {
  it("renders stored markup-shaped data as text without event attributes or executable nodes", () => {
    const dom = new JSDOM("<!doctype html><html><head></head><body></body></html>", { url: "https://probate-pro.com" });
    const payload = '<img src=x onerror="globalThis.pwned=true"><script>globalThis.pwned=true</script>';
    renderPrintDocument(dom.window.document, payload, [
      { type: "heading", text: payload },
      { type: "table", rows: [{ cells: [payload, "safe"], colSpans: [999, 1], cellAligns: ["evil", "right"] }] },
      { type: "letterhead_image", imageUrl: "javascript:alert(1)" },
    ], "https://probate-pro.com");

    expect(dom.window.document.title).toBe(payload);
    expect(dom.window.document.querySelector("script")).toBeNull();
    expect(dom.window.document.querySelector("img")).toBeNull();
    expect(dom.window.document.querySelector("[onerror]")).toBeNull();
    expect(dom.window.document.body.textContent).toContain(payload);
    expect(dom.window.document.querySelector("td")?.colSpan).toBe(20);
  });

  // FORMAT FREEZE. The print preview mirrors a filed court document, so its
  // rendered output must not drift. These assertions failed when the DOM
  // rewrite replaced the original `[&nbsp;&nbsp;]` with ordinary spaces (which
  // collapse in HTML) and capped table rows at 50 cells (which silently dropped
  // content from a legal document).
  const NBSP = String.fromCharCode(160);

  it("keeps the unchecked checkbox mark at two non-breaking spaces", () => {
    const dom = new JSDOM("<!doctype html><html><head></head><body></body></html>", { url: "https://probate-pro.com" });
    renderPrintDocument(dom.window.document, "P10", [
      { type: "checkbox", checked: false, text: "unchecked" },
      { type: "checkbox", checked: true, text: "checked" },
    ], "https://probate-pro.com");

    const marks = Array.from(dom.window.document.querySelectorAll(".checkbox-mark")).map((n) => n.textContent);
    expect(marks[0]).toBe(`[${NBSP}${NBSP}]`);
    expect(marks[0]).not.toBe("[  ]");
    expect(marks[1]).toBe("[X]");
  });

  it("omits the checkbox marker column when a preview section requests relevant text only", () => {
    const dom = new JSDOM("<!doctype html><html><head></head><body></body></html>", { url: "https://probate-pro.com" });
    renderPrintDocument(dom.window.document, "P10", [
      { type: "checkbox", checked: true, text: "relevant wording", hideMarker: true },
    ], "https://probate-pro.com");

    const checkbox = dom.window.document.querySelector(".checkbox");
    expect(checkbox?.classList.contains("checkbox-text-only")).toBe(true);
    expect(checkbox?.querySelector(".checkbox-mark")).toBeNull();
    expect(checkbox?.textContent).toBe("relevant wording");
  });

  it("renders every cell in a wide row without silently truncating", () => {
    const dom = new JSDOM("<!doctype html><html><head></head><body></body></html>", { url: "https://probate-pro.com" });
    const cells = Array.from({ length: 60 }, (_, i) => `c${i}`);
    renderPrintDocument(dom.window.document, "P11", [{ type: "table", rows: [{ cells }] }], "https://probate-pro.com");

    const tds = dom.window.document.querySelectorAll("td");
    expect(tds.length).toBe(60);
    expect(tds[59]?.textContent).toBe("c59");
  });

  it("keeps beneficiary-letter recipient details compact beside the bold delivery method", () => {
    const dom = new JSDOM("<!doctype html><html><head></head><body></body></html>", { url: "https://probate-pro.com" });
    renderPrintDocument(dom.window.document, "Letter", [{
      type: "letter_recipient_block",
      recipientLines: ["12/Jul/2026", "Bob Beneficiary", "5 Elm St"],
      deliveryMethod: "Regular Mail",
    }], "https://probate-pro.com");

    const block = dom.window.document.querySelector(".letter-recipient-block");
    expect(block?.querySelectorAll(".letter-recipient-lines p")).toHaveLength(3);
    expect(block?.querySelector(".letter-delivery-method p")?.textContent).toBe("Delivery Method");
    expect(block?.querySelector(".letter-delivery-method .bold")?.textContent).toBe("Regular Mail");
  });
});
