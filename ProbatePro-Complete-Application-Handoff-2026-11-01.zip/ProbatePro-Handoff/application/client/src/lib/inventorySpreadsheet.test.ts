import { describe, expect, it } from "vitest";
import {
  INVENTORY_SPREADSHEET_EXAMPLE_ROWS,
  INVENTORY_SPREADSHEET_HEADERS,
  inventorySpreadsheetRowsToItems,
  validateSpreadsheetInventoryItem,
} from "./inventorySpreadsheet";

describe("inventorySpreadsheetRowsToItems", () => {
  it("maps Excel-style headers, formatted currency, and preferred sworn values", () => {
    const [item] = inventorySpreadsheetRowsToItems([
      {
        Category: "Financial",
        Description: "RBC chequing",
        Location: "British Columbia",
        Value: "$1,000.00",
        "Date of Death Value": "$1,025.50",
        "Passes to Personal Representative": "Yes",
        "Account Type": "chequing",
        "Bank Address": "1715 Commercial Dr",
        "Account Holder": "Jordan Ellis",
        "Account Number": "05920-5002878",
        "Accrued Interest": "$25.50",
      },
    ]);

    expect(item).toMatchObject({
      category: "financial",
      description: "RBC chequing",
      location: "in_bc",
      value: 100_000,
      valueRecorded: 1,
      dateOfDeathValue: 102_550,
      passesToPersonalRepresentative: "yes",
      subcategory: "chequing",
      bankAddress: "1715 Commercial Dr",
      accountHolder: "Jordan Ellis",
      accountNumber: "05920-5002878",
      accruedInterest: 2_550,
    });
  });

  it("recognizes the provided template headers and ignores blank rows", () => {
    const templateRows = INVENTORY_SPREADSHEET_EXAMPLE_ROWS.map((row) => ({ ...row }));
    const items = inventorySpreadsheetRowsToItems([...templateRows, {}]);

    expect(INVENTORY_SPREADSHEET_HEADERS).toContain("category");
    expect(items).toHaveLength(2);
    expect(items[0]).toMatchObject({ category: "financial", value: 1_500_000, dateOfDeathValue: 1_505_000 });
    expect(items[1]).toMatchObject({ category: "real_property", assessedMarketValue: 85_000_000 });
  });

  it("keeps an unknown location unknown rather than making a B.C. assertion", () => {
    const [item] = inventorySpreadsheetRowsToItems([{ category: "tangible", description: "Artwork", location: "", value: 500 }]);
    expect(item).toMatchObject({ location: "unknown", value: 50_000 });
  });

  it("flags malformed preview basics but permits an honestly pending value", () => {
    const [malformed] = inventorySpreadsheetRowsToItems([
      { category: "unrecognized", description: "", location: "somewhere", value: 500 },
    ]);
    expect(validateSpreadsheetInventoryItem(malformed).map((issue) => issue.field)).toEqual([
      "category",
      "description",
      "location",
    ]);

    const [pendingValue] = inventorySpreadsheetRowsToItems([
      { category: "financial", description: "Savings", location: "in_bc", value: "" },
    ]);
    expect(validateSpreadsheetInventoryItem(pendingValue)).toEqual([]);
  });
});
