const PRINT_CSS = `
body { font-family: Georgia, serif; font-size: 12pt; line-height: 1.6; max-width: 7.5in; margin: 0.75in auto; color: #1a1a1a; }
h1, h2, h3 { font-family: sans-serif; }
.heading { font-weight: bold; font-size: 14pt; margin: 12pt 0 6pt; }
.heading-center, .center { text-align: center; }
.separator { border: none; border-top: 1px solid #ccc; margin: 12pt 0; }
.checkbox { display: flex; gap: 0; padding-left: 40px; margin: 4pt 0; text-indent: -24px; }
.checkbox-text-only { display: block; padding-left: 0; text-indent: 0; }
.checkbox-mark { font-family: monospace; flex-shrink: 0; width: 24px; }
.checkbox-text { flex: 1; }
.signature { margin-top: 24pt; padding-top: 12pt; border-top: 1px solid #999; font-size: 10pt; color: #666; }
.signature-no-rule { padding-top: 0; border-top: none; }
.indent { padding-left: 24pt; }
.bold { font-weight: bold; }
.italic { font-style: italic; color: #666; font-size: 10pt; }
.letterhead { text-align: center; margin-bottom: 12pt; }
.letterhead img { max-width: 100%; height: auto; max-height: 120pt; }
.letterhead-docx { padding: 8pt; border: 1px dashed #aaa; color: #666; font-size: 9pt; }
.letter-recipient-block { display: grid; grid-template-columns: minmax(0, 1fr) auto; column-gap: 32pt; align-items: start; margin: 0 0 12pt; }
.letter-recipient-lines, .letter-delivery-method { line-height: 1.25; }
.letter-recipient-lines p, .letter-delivery-method p { margin: 0; }
.letter-delivery-method { text-align: right; white-space: nowrap; }
.pagebreak { break-before: page; page-break-before: always; }
table { width: 100%; border-collapse: collapse; margin: 8pt 0; font-size: 10pt; }
td { padding: 4pt 8pt; border-bottom: 1px solid #eee; white-space: pre-line; }
tr.header { background: #f5f5f5; font-weight: bold; }
td.right { text-align: right; }
td.center { text-align: center; }
@media print { body { margin: 0; } }
`;

function element(doc: Document, tag: string, classNames: string[] = [], text?: unknown): HTMLElement {
  const node = doc.createElement(tag);
  if (classNames.length) node.classList.add(...classNames.filter(Boolean));
  if (text !== undefined && text !== null) node.textContent = String(text);
  return node;
}

function safeImageUrl(value: unknown, appOrigin: string): string | null {
  if (typeof value !== "string" || value.length > 4096) return null;
  if (/^data:image\/(png|jpeg|gif|webp);base64,[a-z0-9+/=]+$/i.test(value)) return value;
  if (value.startsWith("blob:")) return value;
  try {
    const parsed = new URL(value, appOrigin);
    if (parsed.protocol === "https:") return parsed.href;
    if (parsed.protocol === "http:" && parsed.origin === appOrigin && /^(localhost|127\.0\.0\.1)$/i.test(parsed.hostname)) return parsed.href;
  } catch {
    return null;
  }
  return null;
}

/** Build the print preview exclusively with DOM APIs; stored values are text, never markup. */
export function renderPrintDocument(doc: Document, title: string, sections: readonly any[], appOrigin: string): void {
  const head = doc.createElement("head");
  const charset = doc.createElement("meta");
  charset.setAttribute("charset", "utf-8");
  head.append(charset);
  const titleNode = doc.createElement("title");
  titleNode.textContent = title;
  head.append(titleNode);
  const style = doc.createElement("style");
  style.textContent = PRINT_CSS;
  head.append(style);

  const body = doc.createElement("body");
  for (const section of sections) {
    if (!section || typeof section !== "object") continue;
    if (section.type === "letterhead_image") {
      const src = safeImageUrl(section.imageUrl, appOrigin);
      if (!src) continue;
      const wrapper = element(doc, "div", ["letterhead"]);
      const img = doc.createElement("img");
      img.src = src;
      img.alt = "Letterhead";
      wrapper.append(img);
      body.append(wrapper);
    } else if (section.type === "letterhead_docx") {
      body.append(element(doc, "div", ["letterhead", "letterhead-docx"], `DOCX letterhead template: ${section.text || "configured template"}. Header/footer appear in the generated DOCX.`));
    } else if (section.type === "letter_recipient_block") {
      const wrapper = element(doc, "div", ["letter-recipient-block"]);
      const lines = Array.isArray(section.recipientLines) && section.recipientLines.length > 0
        ? section.recipientLines
        : String(section.text || "").split("\n").slice(0, -2);
      const recipient = element(doc, "div", ["letter-recipient-lines"]);
      lines.forEach((line: unknown) => recipient.append(element(doc, "p", [], line)));
      const delivery = element(doc, "div", ["letter-delivery-method"]);
      delivery.append(element(doc, "p", [], "Delivery Method"));
      delivery.append(element(doc, "p", ["bold"], section.deliveryMethod || "Regular Mail"));
      wrapper.append(recipient, delivery);
      body.append(wrapper);
    } else if (section.type === "heading") {
      body.append(element(doc, "p", ["heading", section.center ? "heading-center" : ""], section.text || ""));
    } else if (section.type === "separator") {
      body.append(element(doc, "hr", ["separator"]));
    } else if (section.type === "pagebreak") {
      body.append(element(doc, "div", ["pagebreak"]));
    } else if (section.type === "checkbox") {
      const wrapper = element(doc, "div", ["checkbox", section.hideMarker ? "checkbox-text-only" : ""]);
      // Format freeze: the unchecked mark is two NON-BREAKING spaces. Ordinary
      // spaces collapse in HTML, which narrows the glyph and changes the frozen
      // print output.  characters below are literal U+00A0. printDocument.test.ts
      // asserts them, so a formatter cannot silently collapse them back.
      if (!section.hideMarker) wrapper.append(element(doc, "span", ["checkbox-mark"], section.checked ? "[X]" : "[  ]"));
      wrapper.append(element(doc, "span", ["checkbox-text"], section.text || ""));
      body.append(wrapper);
    } else if (section.type === "signature") {
      const wrapper = element(doc, "div", ["signature", section.suppressRule ? "signature-no-rule" : ""]);
      if (!section.suppressRule) wrapper.append(element(doc, "p", [], "________________________________"));
      wrapper.append(element(doc, "p", [], section.text || ""));
      body.append(wrapper);
    } else if (section.type === "table" && Array.isArray(section.rows)) {
      const table = doc.createElement("table");
      for (const row of section.rows) {
        if (!row || !Array.isArray(row.cells)) continue;
        const tr = element(doc, "tr", [row.header ? "header" : "", row.italic ? "italic" : ""]);
        // No cell cap: `sections` is built server-side by docgen, not user input,
        // and silently dropping cells from a court document is worse than any
        // rendering cost a long row could cause.
        row.cells.forEach((cell: unknown, index: number) => {
          const align = ["left", "right", "center"].includes(row.cellAligns?.[index]) ? row.cellAligns[index] : (index > 0 ? "right" : "left");
          const td = element(doc, "td", [align], cell ?? "") as HTMLTableCellElement;
          const span = Number(row.colSpans?.[index]);
          td.colSpan = Number.isInteger(span) ? Math.min(Math.max(span, 1), 20) : 1;
          tr.append(td);
        });
        table.append(tr);
      }
      body.append(table);
    } else {
      body.append(element(doc, "p", [section.bold ? "bold" : "", section.italic ? "italic" : "", section.center ? "center" : "", section.indent ? "indent" : ""], section.text || ""));
    }
  }

  const html = doc.documentElement || doc.appendChild(doc.createElement("html"));
  html.replaceChildren(head, body);
}
