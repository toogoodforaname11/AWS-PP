import { TRPCClientError, httpBatchLink, httpLink, splitLink, type TRPCLink } from "@trpc/client";
import { observable } from "@trpc/server/observable";
import superjson from "superjson";
import type { AppRouter } from "../../../server/routers";
import { createTrpcTransportFetch } from "./trpcTransport";
import { fallbackAuthorizationHeader } from "./fallbackSession";
import { createPreviewTransportFetch, validatePreviewPayload } from "./previewTransport";

type FetchLike = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

export type AppTrpcLinkOptions = {
  /** Tests only: the fetch the shared transport calls (the browser's by default). */
  fetchImpl?: FetchLike;
  /** Tests only: replaces the rotated-session handler. */
  onResponse?: (response: Response) => void | Promise<void>;
  /** Tests only: the shared transport's retry delay. */
  retryDelayMs?: (attempt: number) => number;
};

// H-2 Fix: if the server rotated a bearer-backed session, retain the
// refreshed fallback token for later requests where cookies are blocked.
function storeRotatedSession(response: Response): void {
  try {
    const rotated = response.headers.get("X-Rotated-Session");
    if (rotated) sessionStorage.setItem("manus-cookie", rotated);
  } catch {
    // sessionStorage is unavailable in some private/WebView contexts.
  }
}

/**
 * Task 12: validates the preview's transformed payload before the client resolves the query promise, so a malformed
 * payload rejects (neutral sentence, no data) and is never a cache success. Sits only on the preview branch.
 */
const previewValidationLink: TRPCLink<AppRouter> = () => ({ op, next }) => observable((observer) => next(op).subscribe({
  next(envelope) {
    const result = envelope.result as { type?: string; data?: unknown };
    if (result.type === undefined || result.type === "data") {
      try {
        validatePreviewPayload(result.data);
      } catch (error) {
        observer.error(TRPCClientError.from(error as Error));
        return;
      }
    }
    observer.next(envelope);
  },
  error(error) { observer.error(error); },
  complete() { observer.complete(); },
}));

/**
 * The app's tRPC links: one shared transport (header timeout, bounded retries, session rotation); the preview query
 * alone travels un-batched through the validation link and the bounded reader, so its cancellation or refusal can
 * never touch another operation; everything else keeps the batch link exactly as before.
 */
export function createAppTrpcLinks({ fetchImpl, onResponse = storeRotatedSession, retryDelayMs }: AppTrpcLinkOptions = {}): TRPCLink<AppRouter>[] {
  const transportFetch = createTrpcTransportFetch({ fetchImpl, onResponse, retryDelayMs });
  const linkOptions = {
    url: "/api/trpc",
    transformer: superjson,
    headers() {
      // Preview auto-login fallback: when the browser blocks iframe cookies
      // (Safari ITP / private browsing / WebView), the runtime mirrors the
      // session into sessionStorage so we can forward it as a Bearer token.
      // The regular OAuth cookie flow keeps working and takes priority server-side.
      return fallbackAuthorizationHeader();
    },
  };
  return [
    splitLink<AppRouter>({
      condition: (op) => op.type === "query" && op.path === "document.preview",
      true: [previewValidationLink, httpLink<AppRouter>({ ...linkOptions, fetch: createPreviewTransportFetch(transportFetch) })],
      false: httpBatchLink<AppRouter>({ ...linkOptions, fetch: transportFetch }),
    }),
  ];
}
