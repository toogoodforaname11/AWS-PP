/**
 * Shared motion variants and utilities for Framer Motion animations.
 * Used across the app for consistent, professional micro-interactions.
 */

// Staggered list entrance
export const staggerContainer = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
      delayChildren: 0.1,
    },
  },
};

export const staggerItem = {
  hidden: { opacity: 0, y: 8 },
  show: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.3,
      ease: [0.23, 1, 0.32, 1] as [number, number, number, number],
    },
  },
};

// Fade in from below (for page sections)
export const fadeInUp = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.4,
      ease: [0.23, 1, 0.32, 1],
    },
  },
};

// Scale in (for cards, modals)
export const scaleIn = {
  hidden: { opacity: 0, scale: 0.96 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.25,
      ease: [0.23, 1, 0.32, 1],
    },
  },
};

// Card hover spotlight effect
export const cardHover = {
  rest: { scale: 1 },
  hover: {
    scale: 1.005,
    transition: {
      duration: 0.2,
      ease: [0.23, 1, 0.32, 1],
    },
  },
  tap: {
    scale: 0.995,
    transition: {
      duration: 0.1,
    },
  },
};

// Button press effect
export const buttonPress = {
  whileTap: { scale: 0.97 },
  transition: { duration: 0.16, ease: [0.23, 1, 0.32, 1] },
};

// Slide in from left (for sidebar items)
export const slideInLeft = {
  hidden: { opacity: 0, x: -12 },
  visible: {
    opacity: 1,
    x: 0,
    transition: {
      duration: 0.3,
      ease: [0.23, 1, 0.32, 1],
    },
  },
};
