/**
 * Auto-formatting utilities for input fields.
 * Each formatter takes a raw string and returns the formatted version.
 */

/**
 * Format a Canadian phone number as 604-555-1234.
 * Strips non-digits, then inserts dashes after 3rd and 6th digit.
 * Caps at 10 digits.
 */
export function formatPhone(raw: string): string {
  const digits = raw.replace(/\D/g, "").slice(0, 10);
  if (digits.length <= 3) return digits;
  if (digits.length <= 6) return `${digits.slice(0, 3)}-${digits.slice(3)}`;
  return `${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`;
}

/**
 * Format a Canadian SIN as 123 456 789.
 * Strips non-digits, inserts spaces after 3rd and 6th digit.
 * Caps at 9 digits.
 */
export function formatSIN(raw: string): string {
  const digits = raw.replace(/\D/g, "").slice(0, 9);
  if (digits.length <= 3) return digits;
  if (digits.length <= 6) return `${digits.slice(0, 3)} ${digits.slice(3)}`;
  return `${digits.slice(0, 3)} ${digits.slice(3, 6)} ${digits.slice(6)}`;
}

/**
 * Format a Canadian postal code as A1A 1A1.
 * Strips non-alphanumeric, uppercases, inserts space after 3rd char.
 * Caps at 6 alphanumeric characters (7 with space).
 */
export function formatPostalCode(raw: string): string {
  const clean = raw.replace(/[^A-Za-z0-9]/g, "").toUpperCase().slice(0, 6);
  if (clean.length <= 3) return clean;
  return `${clean.slice(0, 3)} ${clean.slice(3)}`;
}

/**
 * Format a currency value with comma separators.
 * Allows digits, one decimal point, and up to 2 decimal places.
 * Inserts commas in the integer part as the user types.
 * Example: "1250000.5" → "1,250,000.5"
 */
export function formatCurrency(raw: string): string {
  // Allow only digits and one decimal point
  let cleaned = raw.replace(/[^0-9.]/g, "");
  // Handle multiple decimal points — keep only the first
  const parts = cleaned.split(".");
  if (parts.length > 2) {
    cleaned = parts[0] + "." + parts.slice(1).join("");
  }
  const [intPart, decPart] = cleaned.split(".");
  // Add commas to integer part
  const withCommas = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  if (decPart !== undefined) {
    // Cap decimal to 2 places
    return `${withCommas}.${decPart.slice(0, 2)}`;
  }
  return withCommas;
}

/**
 * Parse a formatted currency string back to a plain number string.
 * Removes commas, keeps digits and decimal point.
 */
export function parseCurrencyToNumber(formatted: string): string {
  return formatted.replace(/,/g, "");
}

/**
 * Parse a formatted currency string to integer cents.
 * Never NaN: a lone ".", empty string, or garbage parses to 0 cents.
 */
export function parseCurrencyToCents(formatted: string): number {
  const n = parseFloat(parseCurrencyToNumber(formatted));
  return Number.isFinite(n) ? Math.round(n * 100) : 0;
}

/**
 * Auto-uppercase a court file number.
 */
export function formatCourtFileNumber(raw: string): string {
  return raw.toUpperCase();
}
