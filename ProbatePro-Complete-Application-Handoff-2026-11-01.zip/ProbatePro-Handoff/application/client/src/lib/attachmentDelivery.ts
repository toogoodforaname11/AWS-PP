import { useId, useLayoutEffect, useMemo, useSyncExternalStore } from "react";
import { toast } from "sonner";
import { isPostDelivery, type PostDelivery, type PostDeliveryAction } from "@shared/postDelivery";
import { clientSessionGeneration, readFallbackSessionToken } from "./fallbackSession";
import { newAttemptId } from "./utils";

/**
 * Generated-document delivery (Nick, 2026-10-20; Task 9, 2026-10-23; Task 13 feedback, 2026-10-23).
 *
 * A session with no stored fallback token keeps the deliberate same-tab native form POST, unchanged (a cookie
 * tab can hold one: the chatbot's session rotation stores it). A session holding the
 * supported Preview Bearer fallback (cookies blocked) cannot use a form — a form cannot carry
 * Authorization — so it sends ONE same-origin fetch with the token in the Authorization header only,
 * keeps the native urlencoded envelope (the preview keeps its JSON one), bounds and validates the
 * response, and hands the attachment to the browser. Nothing is retried; nothing falls back to a form.
 * "handed-off" means the browser was given the file — never that it was saved or received.
 */
export type DeliveryOutcome =
  | { kind: "invalid" }
  | { kind: "suppressed" }
  | { kind: "submitted" }
  | { kind: "handed-off"; filename: string; bytes: number }
  | { kind: "refused"; status: number; message: string }
  | { kind: "failed"; reason: FailedReason; message: string }
  | { kind: "cancelled" };

type FailedReason = "network" | "timeout" | "redirect" | "invalid-response" | "too-large" | "incomplete" | "session-changed";
type StopReason = "timeout" | "cancelled" | "too-large" | "session-changed";
type AttachmentKind = "docx" | "zip" | "pdf";
type Session = { token: string | null; generation: number };

const MiB = 1024 * 1024;
/** Fetch-path ceilings per output class (Nick, 2026-10-23). Native cookie downloads have none. */
export const ATTACHMENT_CEILING_BYTES: Readonly<Record<AttachmentKind, number>> = { zip: 512 * MiB, docx: 64 * MiB, pdf: 64 * MiB };
export const REFUSAL_BODY_LIMIT_BYTES = 65_536;
export const HEADERS_TIMEOUT_MS = 900_000;
export const BODY_IDLE_TIMEOUT_MS = 60_000;
export const BODY_TOTAL_TIMEOUT_MS = 1_800_000;
/** A bounded cleanup policy, not a guarantee: a download prompt that outlasts it needs a retry. */
export const BLOB_URL_REVOKE_MS = 120_000;
const NATIVE_WINDOW_MS = 2000;

const KIND_BY_MEDIA_TYPE: Readonly<Record<string, AttachmentKind>> = {
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
  "application/zip": "zip",
  "application/pdf": "pdf",
};
const KINDS_BY_ACTION: Readonly<Record<PostDeliveryAction, readonly AttachmentKind[]>> = {
  "/api/download/form": ["docx", "zip"],
  "/api/download/export": ["zip"],
  "/api/notes/export-pdf": ["pdf"],
};
const EXTENSION: Readonly<Record<AttachmentKind, string>> = { docx: ".docx", zip: ".zip", pdf: ".pdf" };

// Existing sentences only: the delivery routes' own fallback and the tRPC transport's two.
const GENERIC = "The download could not be completed. Please try again.";
const TIMEOUT = "The server took too long to respond. Please try again.";
const NETWORK = "Server is temporarily unavailable. Please try again in a moment.";

function failed(reason: FailedReason): DeliveryOutcome {
  return { kind: "failed", reason, message: reason === "timeout" ? TIMEOUT : reason === "network" ? NETWORK : GENERIC };
}

function stopped(reason: StopReason): DeliveryOutcome {
  return reason === "cancelled" ? { kind: "cancelled" } : failed(reason);
}

/** The validated same-origin delivery path, checked before any credential is read or request built. */
function deliveryAction(delivery: unknown): PostDeliveryAction | null {
  if (!isPostDelivery(delivery)) return null;
  try {
    // Resolved exactly as fetch() resolves it (against the document base URL), so a <base> cannot redirect it.
    const url = new URL(delivery.action, document.baseURI);
    if (url.origin !== window.location.origin || url.pathname !== delivery.action || url.search || url.hash) return null;
  } catch {
    return null;
  }
  return delivery.action;
}

function sameSession(session: Session): boolean {
  return clientSessionGeneration() === session.generation && readFallbackSessionToken() === session.token;
}

const busyControls = new WeakSet<HTMLElement>();

/** Disables an enabled control for the delivery; the release re-enables only what it disabled. */
function holdControl(control: HTMLElement): () => void {
  const hadFocus = document.activeElement === control;
  const disabledHere = !control.hasAttribute("disabled");
  // Disable first: a control that cannot be held is never recorded as busy (Task 13).
  if (disabledHere) control.setAttribute("disabled", "");
  busyControls.add(control);
  return () => {
    busyControls.delete(control);
    if (disabledHere) control.removeAttribute("disabled");
    // Disabling a focused button can drop focus to the page; hand it back.
    const focusDropped = !document.activeElement || document.activeElement === document.body;
    if (hadFocus && focusDropped && control.isConnected) control.focus({ preventScroll: true });
  };
}

/** The cookie session's unchanged native submission: a hidden same-tab urlencoded form. */
function submitNativeForm(delivery: PostDelivery, control?: HTMLElement | null): void {
  const form = document.createElement("form");
  form.method = "post";
  form.action = delivery.action;
  form.enctype = "application/x-www-form-urlencoded";
  form.style.display = "none";
  for (const [name, value] of Object.entries({ ...delivery.fields, attemptId: newAttemptId() })) {
    form.append(Object.assign(document.createElement("input"), { type: "hidden", name, value }));
  }
  const release = control ? holdControl(control) : null;
  document.body.append(form);
  try {
    form.submit();
  } finally {
    form.remove();
    if (release) setTimeout(release, NATIVE_WINDOW_MS);
  }
}

// ─── Task 13: one in-flight fetch per prepared delivery ────────────────────────────────────────────

/**
 * The prepared deliveries with a fetch in flight, keyed by the descriptor object a preparation returned: an
 * auto-download and its recovery button share that object, and a new generation returns a new one, so it never
 * inherits an older attempt. Native submissions are never observed, so they never enter it.
 */
const pendingDeliveries = new WeakSet<PostDelivery>();
const pendingListeners = new Set<() => void>();

/** A toast, listener or observer failure never undoes cleanup or reaches a caller (and is never logged: Task 9). */
function quietly<T>(run: () => T): T | undefined {
  try {
    return run();
  } catch {
    return undefined;
  }
}

function setPending(delivery: PostDelivery, pending: boolean): void {
  if (pending) pendingDeliveries.add(delivery);
  else pendingDeliveries.delete(delivery);
  // A snapshot, so a listener that unsubscribes while being told is safe.
  Array.from(pendingListeners).forEach((listener) => {
    quietly(listener);
  });
}

/** The store behind useDeliveryPending (exported so its failure safety can be tested). */
export function subscribeDeliveryPending(listener: () => void): () => void {
  pendingListeners.add(listener);
  return () => {
    pendingListeners.delete(listener);
  };
}

/** True while a fetch for this prepared delivery is in flight, from its auto-download or its control. */
export function useDeliveryPending(delivery: PostDelivery | null | undefined): boolean {
  return useSyncExternalStore(subscribeDeliveryPending, () => !!delivery && pendingDeliveries.has(delivery));
}

/**
 * The refusal when an outcome means the prepared link itself can never succeed unchanged — a stale or tampered
 * binding (409), invalid parameters (400), an oversize request (413) or an invalid descriptor — else null: any
 * other outcome leaves a fresh attempt of the same link worth trying.
 */
export function unusableLinkMessage(outcome: DeliveryOutcome): string | null {
  if (outcome.kind === "invalid") return GENERIC;
  return outcome.kind === "refused" && (outcome.status === 400 || outcome.status === 409 || outcome.status === 413) ? outcome.message : null;
}

// ─── Task 13: feedback ownership ───────────────────────────────────────────────────────────────────

type ToastId = string | number;
type ToastKind = "info" | "loading" | "success" | "error";

/**
 * One attempt's feedback. It is current while its owner is mounted on the same scope, its slot has not been
 * retired or taken by a newer attempt, and the tab's session has not ended since it began (a token rotation keeps
 * it: Task 13 r3). Once it is not, every toast it showed is removed and later ones are dropped. A loading toast is
 * replaced in place by the result.
 */
export type DeliveryFeedback = {
  current(): boolean;
  info(text: string): void;
  loading(text: string): void;
  success(text: string): void;
  error(text: string): void;
  retire(): void;
};
/**
 * The mounted surface that starts attempts: one live attempt per slot. `trackSession: false` is for feedback shown
 * at once, such as an invalid descriptor's: there is no session to follow.
 */
export type DeliveryFeedbackOwner = { begin(slot: string, options?: { trackSession?: boolean }): DeliveryFeedback; retire(slot: string): void };
export type FeedbackTarget = { owner: DeliveryFeedbackOwner; slot: string };

function currentSession(): Session {
  return { token: readFallbackSessionToken(), generation: clientSessionGeneration() };
}

/** No session to follow for feedback shown at once, or for ownerless attempts (the Task 9 behavior). */
function createFeedback(ownerCurrent: () => boolean, trackSession: boolean): DeliveryFeedback {
  // Task 13 r3 (Nick, 2026-10-24): feedback follows the tab's session generation, which only ending the session
  // bumps. A same-user token rotation keeps it; the transport's own token check (Task 9) still fails that read,
  // so the attempt reports the failure instead of going silent. Feedback never reads the token.
  const generation = trackSession ? clientSessionGeneration() : null;
  const shown = new Set<ToastId>();
  let loadingId: ToastId | undefined;
  let retired = false;
  const retire = () => {
    if (retired) return;
    retired = true;
    shown.forEach((id) => {
      quietly(() => toast.dismiss(id));
    });
    shown.clear();
  };
  const current = () => !retired && ownerCurrent() && (generation === null || clientSessionGeneration() === generation);
  const show = (kind: ToastKind, text: string) => {
    if (!current()) {
      retire();
      return;
    }
    const replace = kind === "success" || kind === "error" ? loadingId : undefined;
    if (kind !== "loading") loadingId = undefined;
    let id: ToastId | undefined;
    try {
      id = replace === undefined ? toast[kind](text) : toast[kind](text, { id: replace });
    } catch {
      // A result that cannot be shown must not leave its loading toast up: loading toasts never time out.
      if (replace !== undefined) quietly(() => toast.dismiss(replace));
      return;
    }
    if (id === undefined) return;
    shown.add(id);
    if (kind === "loading") loadingId = id;
  };
  return {
    current,
    retire,
    info: (text) => show("info", text),
    loading: (text) => show("loading", text),
    success: (text) => show("success", text),
    error: (text) => show("error", text),
  };
}

type Owner = DeliveryFeedbackOwner & { active: boolean; retireAll(): void };

function createOwner(): Owner {
  const slots = new Map<string, DeliveryFeedback>();
  const owner: Owner = {
    active: true,
    begin(slot, options) {
      slots.get(slot)?.retire();
      const feedback: DeliveryFeedback = createFeedback(() => owner.active && slots.get(slot) === feedback, options?.trackSession !== false);
      slots.set(slot, feedback);
      return feedback;
    },
    retire(slot) {
      slots.get(slot)?.retire();
      slots.delete(slot);
    },
    retireAll() {
      slots.forEach((feedback) => feedback.retire());
      slots.clear();
    },
  };
  return owner;
}

/**
 * The mounted surface whose attempts may still show feedback. Unmounting, a new `scopeKey` (another estate) or
 * `active` turning false retires every live attempt at once — a layout effect, so it wins over any outcome
 * dispatched afterwards. Feedback cleanup only: no request is cancelled.
 */
export function useDeliveryFeedbackOwner(scopeKey: string, active = true): DeliveryFeedbackOwner {
  // A new scope is a new owner.
  const owner = useMemo(() => createOwner(), [scopeKey]);
  useLayoutEffect(() => {
    owner.active = active;
    return () => {
      owner.active = false;
      owner.retireAll();
    };
  }, [owner, active]);
  return owner;
}

/**
 * Task 13 r3 (Nick, 2026-10-24): the estate page's owner when one is passed, so an attempt's feedback survives a tab
 * switch. It is namespaced per surface instance, so a remounted tab and its unmounted predecessor never replace each
 * other's attempts. With no page owner, this surface's own owner (r2: e.g. a tab rendered alone).
 */
export function useEstateFeedbackOwner(pageOwner: DeliveryFeedbackOwner | undefined, fallbackScopeKey: string): DeliveryFeedbackOwner {
  const own = useDeliveryFeedbackOwner(fallbackScopeKey, pageOwner === undefined);
  const instance = useId();
  return useMemo<DeliveryFeedbackOwner>(() => (pageOwner
    ? { begin: (slot, options) => pageOwner.begin(`${instance}:${slot}`, options), retire: (slot) => pageOwner.retire(`${instance}:${slot}`) }
    : own), [pageOwner, own, instance]);
}

// ─── Task 13: one runner for every activation ─────────────────────────────────────────────────────

/**
 * One activation of a delivery control or auto-download. Validation, suppression, the token read and a native
 * submission all happen synchronously inside the call; a synchronous submit failure propagates exactly as
 * before, with nothing registered. Every other failure resolves an outcome, so the returned Promise never
 * rejects. A fetch attempt holds its prepared delivery (and control) until it settles, then cleans up exactly
 * once; only a still-current attempt shows its result or calls onOutcome.
 */
function deliver(
  delivery: PostDelivery,
  control: HTMLElement | null | undefined,
  subject: string | null,
  target: FeedbackTarget | undefined,
  onOutcome: ((outcome: DeliveryOutcome) => void) | undefined,
): Promise<DeliveryOutcome> {
  const begin = (trackSession = true) => (target ? target.owner.begin(target.slot, { trackSession }) : createFeedback(() => true, false));
  const observe = (feedback: DeliveryFeedback, outcome: DeliveryOutcome) => {
    if (onOutcome && feedback.current()) quietly(() => onOutcome(outcome));
  };
  const action = deliveryAction(delivery);
  if (!action) {
    // Shown at once, before any credential read (Task 9): there is no session to follow.
    const feedback = begin(false);
    feedback.error(GENERIC);
    observe(feedback, { kind: "invalid" });
    return Promise.resolve({ kind: "invalid" });
  }
  if (pendingDeliveries.has(delivery) || (control && busyControls.has(control))) return Promise.resolve({ kind: "suppressed" });
  const session = currentSession();
  if (session.token === null) {
    submitNativeForm(delivery, control);
    const feedback = begin();
    if (subject) feedback.info(`${subject} — download requested. Check your browser's downloads.`);
    observe(feedback, { kind: "submitted" });
    return Promise.resolve({ kind: "submitted" });
  }
  const feedback = begin();
  let done = false;
  let release: (() => void) | null = null;
  const finish = (outcome: DeliveryOutcome): DeliveryOutcome => {
    if (done) return outcome;
    done = true;
    // Task 13 r3.1 (security review): a refusal finished after the token changed never shows the server's text,
    // which can name a person; the toast and the reported outcome carry the generic sentence instead.
    if (outcome.kind === "refused" && !sameSession(session)) outcome = { ...outcome, message: GENERIC };
    if (release) quietly(release);
    setPending(delivery, false);
    if (!feedback.current()) {
      feedback.retire();
      return outcome;
    }
    if (outcome.kind === "refused" || outcome.kind === "failed") feedback.error(outcome.message);
    else if (outcome.kind === "handed-off" && subject) feedback.success(`${subject} — download started.`);
    else if (outcome.kind === "cancelled") feedback.retire();
    observe(feedback, outcome);
    return outcome;
  };
  try {
    setPending(delivery, true);
    if (control) release = holdControl(control);
    if (subject) feedback.loading(`${subject} — preparing the download…`);
    return fetchAttachment(delivery, action, session, "urlencoded").then(finish, () => finish(failed("invalid-response")));
  } catch {
    return Promise.resolve(finish(failed("invalid-response")));
  }
}

/** A delivery control's activation; `feedback`/`onOutcome` scope its error and recovery to its owner (Task 13). */
export function deliverAttachment(
  delivery: PostDelivery,
  control?: HTMLElement | null,
  feedback?: FeedbackTarget,
  onOutcome?: (outcome: DeliveryOutcome) => void,
): Promise<DeliveryOutcome> {
  return deliver(delivery, control, null, feedback, onOutcome);
}

/**
 * An auto-download after generation, announced once per attempt (Task 13): "requested" for a native submission;
 * for a fetch, a loading toast that becomes "started" or the refusal. Still void and detached, so the mutation's
 * own timing is untouched and a synchronous native submit failure still reaches its onError.
 */
export function deliverAndAnnounce(
  delivery: PostDelivery,
  subject: string,
  options: { feedback?: FeedbackTarget; onOutcome?: (outcome: DeliveryOutcome) => void } = {},
): void {
  void deliver(delivery, null, subject, options.feedback, options.onOutcome);
}

/** The preview modal's download: always one fetch, its existing JSON envelope, no toast, no control. */
export function fetchDeliveryAttachment(delivery: PostDelivery, signal?: AbortSignal): Promise<DeliveryOutcome> {
  const action = deliveryAction(delivery);
  if (!action) return Promise.resolve({ kind: "invalid" });
  const session: Session = { token: readFallbackSessionToken(), generation: clientSessionGeneration() };
  return fetchAttachment(delivery, action, session, "json", signal);
}

type Read = { ok: true; chunks: Uint8Array[]; bytes: number } | { ok: false; reason: StopReason | "incomplete" };

async function fetchAttachment(
  delivery: PostDelivery,
  action: PostDeliveryAction,
  session: Session,
  encoding: "urlencoded" | "json",
  callerSignal?: AbortSignal,
): Promise<DeliveryOutcome> {
  if (callerSignal?.aborted) return { kind: "cancelled" };
  const controller = new AbortController();
  // Mutated from timers and the abort listener, so it lives on an object, not in narrowed locals.
  const run = {
    stop: null as StopReason | null,
    reader: null as ReadableStreamDefaultReader<Uint8Array> | null,
    response: null as Response | null,
    handedOff: false,
    timers: [] as Array<ReturnType<typeof setTimeout>>,
    idle: undefined as ReturnType<typeof setTimeout> | undefined,
  };
  const halt = (reason: StopReason) => {
    if (run.stop === null) run.stop = reason;
    controller.abort();
    // A stream that ignores the abort still ends: cancelling resolves a pending read as done.
    run.reader?.cancel().catch(() => undefined);
  };
  const onCallerAbort = () => halt("cancelled");
  callerSignal?.addEventListener("abort", onCallerAbort, { once: true });
  const headersTimer = setTimeout(() => halt("timeout"), HEADERS_TIMEOUT_MS);
  run.timers.push(headersTimer);

  const readBody = async (response: Response, limit: number): Promise<Read> => {
    if (!response.body) return { ok: true, chunks: [], bytes: 0 };
    const reader = response.body.getReader();
    run.reader = reader;
    const chunks: Uint8Array[] = [];
    let bytes = 0;
    run.timers.push(setTimeout(() => halt("timeout"), BODY_TOTAL_TIMEOUT_MS));
    const touch = () => {
      clearTimeout(run.idle);
      run.idle = setTimeout(() => halt("timeout"), BODY_IDLE_TIMEOUT_MS);
    };
    touch();
    try {
      for (;;) {
        const { done, value } = await reader.read();
        // A stop decided while this read was pending outranks the read's own result.
        if (run.stop) return { ok: false, reason: run.stop };
        // A session that changed mid-body ends the read: none of it is shown or handed off.
        if (!sameSession(session)) {
          halt("session-changed");
          return { ok: false, reason: "session-changed" };
        }
        if (done) return { ok: true, chunks, bytes };
        bytes += value.byteLength;
        if (bytes > limit) {
          halt("too-large");
          return { ok: false, reason: "too-large" };
        }
        chunks.push(value);
        touch();
      }
    } catch {
      return { ok: false, reason: run.stop ?? "incomplete" };
    }
  };

  try {
    const fields = { ...delivery.fields, attemptId: newAttemptId() };
    const headers: Record<string, string> = encoding === "json"
      ? { "Content-Type": "application/json" }
      : { "Content-Type": "application/x-www-form-urlencoded" };
    if (session.token !== null) headers.Authorization = `Bearer ${session.token}`;
    const body = encoding === "json" ? JSON.stringify(fields) : new URLSearchParams(Object.entries(fields)).toString();
    let response: Response;
    try {
      response = await fetch(action, { method: "POST", credentials: "include", redirect: "manual", headers, body, signal: controller.signal });
    } catch {
      return run.stop ? stopped(run.stop) : failed("network");
    }
    run.response = response;
    clearTimeout(headersTimer);
    if (run.stop) return stopped(run.stop);
    if (response.type === "opaqueredirect" || response.redirected) return failed("redirect");
    if (response.type !== "basic") return failed("invalid-response");
    if (!sameSession(session)) {
      halt("session-changed");
      return stopped("session-changed");
    }

    if (response.status >= 400) {
      const read = await readBody(response, REFUSAL_BODY_LIMIT_BYTES);
      if (!read.ok && (read.reason === "cancelled" || read.reason === "session-changed")) return stopped(read.reason);
      return { kind: "refused", status: response.status, message: read.ok ? refusalSentence(response, read.chunks) : GENERIC };
    }
    if (response.status !== 200) return failed("invalid-response");

    const type = mediaType(response);
    const kind = KIND_BY_MEDIA_TYPE[type];
    if (!kind || !KINDS_BY_ACTION[action].includes(kind)) return failed("invalid-response");
    const filename = attachmentFilename(response.headers.get("content-disposition"), kind);
    if (!filename) return failed("invalid-response");
    const declared = response.headers.get("content-length");
    let expected: number | null = null;
    if (declared !== null) {
      if (!/^\d+$/.test(declared.trim())) return failed("invalid-response");
      expected = Number(declared.trim());
      if (expected > ATTACHMENT_CEILING_BYTES[kind]) return failed("too-large");
    }
    const contentEncoding = (response.headers.get("content-encoding") ?? "").trim().toLowerCase();
    const read = await readBody(response, ATTACHMENT_CEILING_BYTES[kind]);
    if (!read.ok) return read.reason === "incomplete" ? failed("incomplete") : stopped(read.reason);
    // A declared length counts the bytes on the wire; only an unencoded body must match it.
    if (expected !== null && (contentEncoding === "" || contentEncoding === "identity") && read.bytes !== expected) return failed("incomplete");
    if (read.bytes === 0 || !hasContainerMarkers(kind, read.chunks, read.bytes)) return failed("invalid-response");
    if (!sameSession(session)) return failed("session-changed");
    handOff(read.chunks, type, filename);
    run.handedOff = true;
    return { kind: "handed-off", filename, bytes: read.bytes };
  } catch {
    // Anything unexpected after the response arrived is a local failure, not a server outage.
    return run.stop ? stopped(run.stop) : failed(run.response ? "invalid-response" : "network");
  } finally {
    for (const timer of run.timers) clearTimeout(timer);
    clearTimeout(run.idle);
    callerSignal?.removeEventListener("abort", onCallerAbort);
    if (!run.handedOff) {
      // Every exit that is not a handoff ends the request, so the server sees the close.
      controller.abort();
      if (run.reader) run.reader.cancel().catch(() => undefined);
      else run.response?.body?.cancel().catch(() => undefined);
    }
  }
}

function mediaType(response: Response): string {
  return (response.headers.get("content-type") ?? "").split(";")[0].trim().toLowerCase();
}

function joined(chunks: Uint8Array[]): Uint8Array {
  const out = new Uint8Array(chunks.reduce((total, chunk) => total + chunk.byteLength, 0));
  let offset = 0;
  for (const chunk of chunks) {
    out.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return out;
}

/** The route's public JSON sentence (Task 14), or the generic one. Shown as text only. */
function refusalSentence(response: Response, chunks: Uint8Array[]): string {
  if (mediaType(response) !== "application/json") return GENERIC;
  try {
    const value: unknown = JSON.parse(new TextDecoder().decode(joined(chunks)));
    if (value && typeof value === "object" && !Array.isArray(value) && Object.prototype.hasOwnProperty.call(value, "error")) {
      const error = (value as { error: unknown }).error;
      if (typeof error === "string" && error.trim()) return error;
    }
  } catch {
    // Not JSON: never shown.
  }
  return GENERIC;
}

// sendAttachment's exact form (deliveryRouter.ts); the name runs to the final quote.
const DISPOSITION = /^attachment; filename="(.+)"$/;
// The approved notes-only ASCII fallback plus UTF-8 filename; other delivery header contracts are unchanged.
const NOTES_UTF8_DISPOSITION = /^attachment; filename="(?:[\x20-\x21\x23-\x5b\x5d-\x7e]|\\["\\])+"; filename\*=UTF-8''((?:[!#$&+\-.^_`|~A-Za-z0-9]|%[0-9A-Fa-f]{2})+)$/;
// eslint-disable-next-line no-control-regex -- a control character makes a file name unusable
const CONTROL_CHARACTER = /[\u0000-\u001f\u007f]/;
// eslint-disable-next-line no-control-regex -- notesFilenameDisposition also removes C1 controls
const NOTES_C1_CONTROL_CHARACTER = /[\u0080-\u009f]/;

function attachmentFilename(header: string | null, kind: AttachmentKind): string | null {
  let name = header ? DISPOSITION.exec(header)?.[1] : undefined;
  const extended = kind === "pdf" && header ? NOTES_UTF8_DISPOSITION.exec(header) : null;
  if (extended) {
    try { name = decodeURIComponent(extended[1]); } catch { return null; }
    if (NOTES_C1_CONTROL_CHARACTER.test(name)) return null;
  }
  if (!name || CONTROL_CHARACTER.test(name) || !name.toLowerCase().endsWith(EXTENSION[kind])) return null;
  return name;
}

const ZIP_LOCAL_HEADER = [0x50, 0x4b, 0x03, 0x04];
const ZIP_END_RECORD = [0x50, 0x4b, 0x05, 0x06];
const PDF_HEADER = [0x25, 0x50, 0x44, 0x46, 0x2d]; // %PDF-
const PDF_END = [0x25, 0x25, 0x45, 0x4f, 0x46]; // %%EOF
const ZIP_END_RECORD_BYTES = 22;
const ZIP_TAIL_WINDOW = ZIP_END_RECORD_BYTES + 0xffff;
const PDF_TAIL_WINDOW = 1024;

function head(chunks: Uint8Array[], length: number): Uint8Array {
  const out = new Uint8Array(length);
  let filled = 0;
  for (const chunk of chunks) {
    const take = Math.min(length - filled, chunk.byteLength);
    out.set(chunk.subarray(0, take), filled);
    filled += take;
    if (filled === length) break;
  }
  return out.subarray(0, filled);
}

function tail(chunks: Uint8Array[], total: number, length: number): Uint8Array {
  const size = Math.min(length, total);
  const out = new Uint8Array(size);
  let skip = total - size;
  let filled = 0;
  for (const chunk of chunks) {
    if (skip >= chunk.byteLength) {
      skip -= chunk.byteLength;
      continue;
    }
    const part = chunk.subarray(skip);
    skip = 0;
    out.set(part, filled);
    filled += part.byteLength;
  }
  return out;
}

function matchesAt(bytes: Uint8Array, marker: number[], at: number): boolean {
  return at >= 0 && at + marker.length <= bytes.length && marker.every((value, index) => bytes[at + index] === value);
}

/**
 * Format markers, not container validation: a ZIP/DOCX starts with a local header (or is a complete empty
 * archive) and ends with its end-of-central-directory record; a PDF starts with %PDF- and ends with %%EOF.
 * This refuses a mislabelled HTML/JSON page and a truncated body; it does not inflate, CRC-check or parse,
 * so interior corruption behind intact markers would pass.
 */
function hasContainerMarkers(kind: AttachmentKind, chunks: Uint8Array[], total: number): boolean {
  if (kind === "pdf") {
    const end = tail(chunks, total, PDF_TAIL_WINDOW);
    return matchesAt(head(chunks, PDF_HEADER.length), PDF_HEADER, 0)
      && Array.from({ length: end.length }, (_, index) => index).some((at) => matchesAt(end, PDF_END, at));
  }
  const start = head(chunks, ZIP_LOCAL_HEADER.length);
  // A complete empty archive is a single end record.
  const opens = matchesAt(start, ZIP_LOCAL_HEADER, 0) || (kind === "zip" && matchesAt(start, ZIP_END_RECORD, 0));
  return opens && endsWithEndRecord(chunks, total);
}

/**
 * The end record must close the archive: its declared comment runs to the last byte, and the central directory
 * it points at ends where the record begins. A bare signature search is not enough: JSZip stores members
 * uncompressed, so a DOCX inside a P1, letters or package ZIP carries an end record of its own.
 * shortcut: no ZIP64 end records (JSZip never writes them; the largest ceiling is 512 MiB).
 */
function endsWithEndRecord(chunks: Uint8Array[], total: number): boolean {
  const window = tail(chunks, total, ZIP_TAIL_WINDOW);
  const windowStart = total - window.length;
  const view = new DataView(window.buffer, window.byteOffset, window.byteLength);
  for (let at = window.length - ZIP_END_RECORD_BYTES; at >= 0; at--) {
    if (!matchesAt(window, ZIP_END_RECORD, at)) continue;
    const closesArchive = at + ZIP_END_RECORD_BYTES + view.getUint16(at + 20, true) === window.length;
    const directoryEndsHere = view.getUint32(at + 16, true) + view.getUint32(at + 12, true) === windowStart + at;
    if (closesArchive && directoryEndsHere) return true;
  }
  return false;
}

function handOff(chunks: Uint8Array[], type: string, filename: string): void {
  const url = URL.createObjectURL(new Blob(chunks as BlobPart[], { type }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.style.display = "none";
  document.body.append(anchor);
  try {
    anchor.click();
  } finally {
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), BLOB_URL_REVOKE_MS);
  }
}
