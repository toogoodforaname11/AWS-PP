import { describe, expect, it } from "vitest";
import { asAssistantChimeTone, clampAssistantChimeVolume } from "./assistantChime";

describe("Assistant completion chime preferences", () => {
  it("accepts only the supported ProbatePro chime profiles", () => {
    expect(asAssistantChimeTone("harbor")).toBe("harbor");
    expect(asAssistantChimeTone("ledger")).toBe("ledger");
    expect(asAssistantChimeTone("beacon")).toBe("beacon");
    expect(asAssistantChimeTone("unknown")).toBe("harbor");
  });

  it("keeps persisted chime volume within its safe 0–100 range", () => {
    expect(clampAssistantChimeVolume(65.4)).toBe(65);
    expect(clampAssistantChimeVolume(-8)).toBe(0);
    expect(clampAssistantChimeVolume(160)).toBe(100);
    expect(clampAssistantChimeVolume("not-a-number")).toBe(35);
  });
});
