/**
 * Task 9: the authenticated attachment transport for a session holding the Preview Bearer fallback.
 * One deliberate same-origin fetch per activation; the token only in Authorization; the native
 * urlencoded envelope (the preview keeps JSON); status-first refusals; bounded, validated bytes;
 * an identity-checked handoff; never a retry and never a fallback to a header-less form.
 * Fictional tokens and documents only.
 */
import React from "react";
import JSZip from "jszip";
import { act, cleanup, fireEvent, render, renderHook, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import type { PostDelivery } from "@shared/postDelivery";
import { browserResponse, chunkedStream, stalledStream } from "./browserResponse.testkit";

vi.mock("sonner", () => ({ toast: { success: vi.fn(), error: vi.fn(), info: vi.fn(), loading: vi.fn(), dismiss: vi.fn() } }));
import { toast } from "sonner";
import {
  ATTACHMENT_CEILING_BYTES, BLOB_URL_REVOKE_MS, BODY_IDLE_TIMEOUT_MS, BODY_TOTAL_TIMEOUT_MS, HEADERS_TIMEOUT_MS,
  REFUSAL_BODY_LIMIT_BYTES, deliverAndAnnounce, deliverAttachment, fetchDeliveryAttachment, subscribeDeliveryPending,
  unusableLinkMessage, useDeliveryFeedbackOwner, useDeliveryPending, useEstateFeedbackOwner, type DeliveryFeedbackOwner,
  type DeliveryOutcome,
} from "./attachmentDelivery";
import { clearFallbackSession } from "./fallbackSession";

const TOKEN = "fictional.unit.token-a";
const TOKEN_B = "fictional.unit.token-b";
const DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const GENERIC = "The download could not be completed. Please try again.";
const form: PostDelivery = {
  method: "POST",
  action: "/api/download/form",
  fields: { estateId: "estate-1", formCode: "P3", documentId: "doc_P3-1", signatoryType: "executor", signatureDate: "2026-10-20" },
};
const exportDelivery: PostDelivery = { method: "POST", action: "/api/download/export", fields: { type: "estate", estateId: "estate-1" } };
const notes: PostDelivery = { method: "POST", action: "/api/notes/export-pdf", fields: { estateId: "estate-1" } };
const encoder = new TextEncoder();

let docx: Uint8Array;
let zip: Uint8Array;
let emptyZip: Uint8Array;
const pdf = encoder.encode("%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n");
const fetchSpy = vi.fn<(input: RequestInfo | URL, init?: RequestInit) => Promise<Response>>();
const clicks: Array<{ href: string; download: string }> = [];
const blobs: Blob[] = [];
let revoke: ReturnType<typeof vi.fn>;

beforeAll(async () => {
  docx = await new JSZip().file("word/document.xml", "<w:document/>").generateAsync({ type: "uint8array" });
  zip = await new JSZip().file("a.docx", docx).generateAsync({ type: "uint8array" });
  emptyZip = await new JSZip().generateAsync({ type: "uint8array" });
});

beforeEach(() => {
  fetchSpy.mockReset();
  vi.stubGlobal("fetch", fetchSpy);
  clicks.length = 0;
  blobs.length = 0;
  vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(function (this: HTMLAnchorElement) {
    clicks.push({ href: this.href, download: this.download });
  });
  revoke = vi.fn();
  Object.defineProperty(URL, "createObjectURL", { configurable: true, writable: true, value: vi.fn((blob: Blob) => { blobs.push(blob); return `blob:http://localhost/unit-${blobs.length}`; }) });
  Object.defineProperty(URL, "revokeObjectURL", { configurable: true, writable: true, value: revoke });
  vi.mocked(toast.error).mockReset();
  vi.mocked(toast.success).mockReset();
  vi.mocked(toast.info).mockReset();
  vi.mocked(toast.loading).mockReset();
  vi.mocked(toast.dismiss).mockReset();
});

afterEach(() => {
  cleanup();
  vi.useRealTimers();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  sessionStorage.clear();
  delete (URL as any).createObjectURL;
  delete (URL as any).revokeObjectURL;
});

const useToken = (token = TOKEN) => sessionStorage.setItem("manus-cookie", `app_session_id=${token}`);
const headersOf = (index = 0) => (fetchSpy.mock.calls[index]?.[1]?.headers ?? {}) as Record<string, string>;
const initOf = (index = 0) => fetchSpy.mock.calls[index]?.[1] as RequestInit;
const signalOf = (index = 0) => initOf(index).signal as AbortSignal;

/** A stub that honours the abort signal as a browser fetch does, then answers with `make`. */
function respond(make: (init: RequestInit) => Response | Promise<Response>) {
  fetchSpy.mockImplementation((_input, init) => new Promise<Response>((resolve, reject) => {
    const signal = init?.signal;
    const aborted = () => reject(new DOMException("The operation was aborted.", "AbortError"));
    if (signal?.aborted) return aborted();
    signal?.addEventListener("abort", aborted, { once: true });
    Promise.resolve().then(() => make(init!)).then(resolve, reject);
  }));
}

function attachment(bytes: Uint8Array | ReadableStream<Uint8Array> | null, type: string, filename: string, extra: Record<string, string> = {}): Response {
  const headers: Record<string, string> = { "content-type": type, "content-disposition": `attachment; filename="${filename}"`, ...extra };
  if (bytes instanceof Uint8Array && !("content-length" in extra)) headers["content-length"] = String(bytes.length);
  return browserResponse(bytes, { status: 200, headers });
}

const docxResponse = (extra: Record<string, string> = {}) => attachment(docx, DOCX, "P3_Example_1.docx", extra);
const refusal = (status: number, body: string, type = "application/json; charset=utf-8") => browserResponse(body, { status, headers: { "content-type": type } });

describe("Task 9: credentials and the request contract", () => {
  it("a token sends exactly one same-origin fetch with the native envelope and the token only in Authorization", async () => {
    useToken();
    const submit = vi.spyOn(HTMLFormElement.prototype, "submit");
    respond(() => docxResponse());

    const outcome = await deliverAttachment(form);

    expect(outcome).toEqual({ kind: "handed-off", filename: "P3_Example_1.docx", bytes: docx.length });
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    const [url, init] = fetchSpy.mock.calls[0] as [string, RequestInit];
    expect(url).toBe("/api/download/form");
    expect(init).toMatchObject({ method: "POST", credentials: "include", redirect: "manual" });
    expect(init).not.toHaveProperty("mode");
    expect(init).not.toHaveProperty("keepalive");
    expect(init.headers).toEqual({ "Content-Type": "application/x-www-form-urlencoded", Authorization: `Bearer ${TOKEN}` });
    expect(typeof init.body).toBe("string");
    expect(Object.fromEntries(new URLSearchParams(String(init.body)))).toEqual({ ...form.fields, attemptId: expect.stringMatching(UUID_V4) });
    expect(String(init.body)).toBe(new URLSearchParams(Object.entries({ ...form.fields, attemptId: new URLSearchParams(String(init.body)).get("attemptId")! })).toString());
    expect(String(init.body)).not.toContain(TOKEN);
    expect(url).not.toContain(TOKEN);
    expect(submit).not.toHaveBeenCalled();
  });

  it.each([
    ["no stored session", null],
    ["only lookalike cookie names", "xapp_session_id=nope; app_session_id_old=nope"],
    ["an empty token", "app_session_id="],
  ])("%s keeps the unchanged native form and sends no fetch", async (_label, stored) => {
    if (stored !== null) sessionStorage.setItem("manus-cookie", stored);
    const submit = vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(() => undefined);
    await expect(deliverAttachment(form)).resolves.toEqual({ kind: "submitted" });
    expect(submit).toHaveBeenCalledTimes(1);
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it("unavailable storage keeps the native form and never throws", async () => {
    vi.spyOn(Storage.prototype, "getItem").mockImplementation(() => { throw new DOMException("blocked", "SecurityError"); });
    const submit = vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(() => undefined);
    await expect(deliverAttachment(form)).resolves.toEqual({ kind: "submitted" });
    expect(submit).toHaveBeenCalledTimes(1);
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it("a token with header-illegal characters fails as a network failure and never falls back to a form", async () => {
    sessionStorage.setItem("manus-cookie", "app_session_id=bad\ntoken");
    const submit = vi.spyOn(HTMLFormElement.prototype, "submit");
    respond((init) => { new Headers(init.headers); return docxResponse(); });
    const outcome = await deliverAttachment(form);
    expect(outcome).toMatchObject({ kind: "failed", reason: "network" });
    expect(submit).not.toHaveBeenCalled();
    expect(clicks).toEqual([]);
  });

  it("the preview keeps its pinned JSON envelope and adds the token header", async () => {
    useToken();
    respond(() => docxResponse());
    await expect(fetchDeliveryAttachment(form)).resolves.toMatchObject({ kind: "handed-off" });
    const init = initOf();
    expect(init.headers).toEqual({ "Content-Type": "application/json", Authorization: `Bearer ${TOKEN}` });
    expect(JSON.parse(String(init.body))).toEqual({ ...form.fields, attemptId: expect.stringMatching(UUID_V4) });
    expect(String(init.body)).not.toContain(TOKEN);
  });

  it("a cookie-only preview fetch sends no Authorization header", async () => {
    respond(() => docxResponse());
    await expect(fetchDeliveryAttachment(form)).resolves.toMatchObject({ kind: "handed-off" });
    expect(headersOf()).toEqual({ "Content-Type": "application/json" });
  });

  it("an explicit retry is a fresh activation that reads the current token and draws a new attemptId", async () => {
    useToken();
    respond(() => refusal(401, JSON.stringify({ error: "Authentication required" })));
    await expect(deliverAttachment(form)).resolves.toEqual({ kind: "refused", status: 401, message: "Authentication required" });
    useToken(TOKEN_B);
    respond(() => docxResponse());
    await expect(deliverAttachment(form)).resolves.toMatchObject({ kind: "handed-off" });
    expect(fetchSpy).toHaveBeenCalledTimes(2);
    expect(headersOf(1).Authorization).toBe(`Bearer ${TOKEN_B}`);
    const attempt = (index: number) => new URLSearchParams(String(initOf(index).body)).get("attemptId");
    expect(attempt(1)).not.toBe(attempt(0));
  });

  it("never writes the token store, even when a response carries a rotation header", async () => {
    useToken();
    respond(() => docxResponse({ "x-rotated-session": `app_session_id=${TOKEN_B}` }));
    await deliverAttachment(form);
    expect(sessionStorage.getItem("manus-cookie")).toBe(`app_session_id=${TOKEN}`);
  });
});

describe("Task 9 D6: the Bearer body is the native urlencoded envelope", () => {
  const nativeBody = (fields: Record<string, string>, attemptId: string) => new URLSearchParams(Object.entries({ ...fields, attemptId })).toString();

  /** Task 6's all-17-field shape (formDeliveryBinding.body-size.routes.test.ts): a 148-byte binding, four ≤2,000-byte paddings. */
  function thresholdFields(): Record<string, string> {
    const fields = (padding: number): Record<string, string> => {
      let remaining = padding;
      const overrides = Object.fromEntries(Array.from({ length: 4 }, (_, index) => {
        const chunk = Math.min(2000, remaining);
        remaining -= chunk;
        return [`bodySizePadding${index}`, "x".repeat(chunk)];
      }));
      return {
        estateId: "estate-body-size-fictional", formCode: "P1", signatoryType: "lawyer", signatureDate: "2026-09-01",
        targetBeneficiaryId: "avery", deponentId: "jordan", selectedContactId: "jordan", deliveryId: "delivery-fictional",
        citationRecordId: "citation-fictional", affidavitOrdinal: "1st",
        consentNomination: JSON.stringify({ nomineeContactId: "jordan", relationshipToNominee: "brother", beneficiarySharePercentage: 50 }),
        consentAppointAdministrator: JSON.stringify({ administratorContactId: "jordan" }),
        overrides: JSON.stringify(overrides), generateAnyway: "true", documentId: "d".repeat(32),
        binding: `fdb1.${"1".repeat(13)}.${"a".repeat(64)}.${"b".repeat(64)}`,
      };
    };
    // Each padding x is exactly one urlencoded byte.
    const padding = 8349 - nativeBody(fields(0), "0".repeat(36)).length;
    expect(padding).toBeLessThanOrEqual(8000);
    return fields(padding);
  }

  it("a Task 6-shaped all-17-field descriptor at the form threshold is sent as exactly its 8,349 native bytes", async () => {
    useToken();
    const fields = thresholdFields();
    expect(fields.binding).toHaveLength(148);
    respond(() => docxResponse());
    await deliverAttachment({ method: "POST", action: "/api/download/form", fields });
    const body = String(initOf().body);
    const attemptId = new URLSearchParams(body).get("attemptId")!;
    expect(attemptId).toMatch(UUID_V4);
    expect(Object.keys(Object.fromEntries(new URLSearchParams(body)))).toHaveLength(17);
    expect(body).toBe(nativeBody(fields, attemptId));
    expect(encoder.encode(body).length).toBe(8349);
  });

  it("a valid descriptor inside the 8,349-byte form cap whose JSON would cross the 8,353-byte JSON cap is still sent urlencoded", async () => {
    // Nick's contract counterexample (2026-10-23 plan review): one 8,300-character field.
    useToken();
    const fields = { x: "x".repeat(8300) };
    respond(() => docxResponse());
    await deliverAttachment({ method: "POST", action: "/api/download/form", fields });
    const body = String(initOf().body);
    const attemptId = new URLSearchParams(body).get("attemptId")!;
    expect(initOf().headers).toMatchObject({ "Content-Type": "application/x-www-form-urlencoded" });
    expect(body).toBe(nativeBody(fields, attemptId));
    expect(encoder.encode(body).length).toBe(8349);
    expect(encoder.encode(JSON.stringify({ ...fields, attemptId })).length).toBe(8359);
  });

  it("a preview refusal (413) is shown and never re-posted in another encoding", async () => {
    useToken();
    respond(() => refusal(413, JSON.stringify({ error: "The request is too large." })));
    await expect(fetchDeliveryAttachment(form)).resolves.toEqual({ kind: "refused", status: 413, message: "The request is too large." });
    expect(fetchSpy).toHaveBeenCalledTimes(1);
  });
});

describe("Task 9: descriptor validation happens before any credential read or request", () => {
  it.each([
    ["a GET descriptor", { ...form, method: "GET" }],
    ["a query-string action", { ...form, action: "/api/download/form?x=1" }],
    ["a hash action", { ...form, action: "/api/download/form#x" }],
    ["an alternate path", { ...form, action: "/api/download/form/" }],
    ["a foreign absolute action", { ...form, action: "https://example.invalid/api/download/form" }],
    ["a protocol-relative action", { ...form, action: "//example.invalid/api/download/form" }],
    ["a non-string field", { ...form, fields: { ...form.fields, documentId: 7 } }],
    ["no descriptor", undefined],
  ])("refuses %s", async (_label, invalid) => {
    useToken();
    const read = vi.spyOn(Storage.prototype, "getItem");
    const button = document.createElement("button");
    await expect(deliverAttachment(invalid as unknown as PostDelivery, button)).resolves.toEqual({ kind: "invalid" });
    await expect(fetchDeliveryAttachment(invalid as unknown as PostDelivery)).resolves.toEqual({ kind: "invalid" });
    expect(fetchSpy).not.toHaveBeenCalled();
    expect(read).not.toHaveBeenCalled();
    expect(button.hasAttribute("disabled")).toBe(false);
  });

  it("refuses a path that a cross-origin <base> would send elsewhere, before any credential read", async () => {
    useToken();
    const base = Object.assign(document.createElement("base"), { href: "https://attacker.example/" });
    document.head.append(base);
    try {
      expect(new URL(form.action, document.baseURI).origin).toBe("https://attacker.example");
      const read = vi.spyOn(Storage.prototype, "getItem");
      await expect(deliverAttachment(form)).resolves.toEqual({ kind: "invalid" });
      await expect(fetchDeliveryAttachment(form)).resolves.toEqual({ kind: "invalid" });
      expect(fetchSpy).not.toHaveBeenCalled();
      expect(read).not.toHaveBeenCalled();
    } finally {
      base.remove();
    }
  });
});

describe("Task 9: session identity at handoff", () => {
  it("A to B replacement before the headers arrive: nothing is handed off and the request is aborted", async () => {
    useToken();
    respond(() => { useToken(TOKEN_B); return docxResponse(); });
    const outcome = await deliverAttachment(form);
    expect(outcome).toEqual({ kind: "failed", reason: "session-changed", message: GENERIC });
    expect(clicks).toEqual([]);
    expect(blobs).toEqual([]);
    expect(signalOf().aborted).toBe(true);
    expect(toast.error).toHaveBeenCalledWith(GENERIC);
  });

  it("A to B replacement while the body is read: the read stops at once and nothing is handed off", async () => {
    useToken();
    let pulls = 0;
    let cancelled = false;
    // highWaterMark 0: the swap happens only when the transport reads, after the headers check passed.
    respond(() => attachment(new ReadableStream<Uint8Array>({
      pull(controller) {
        pulls += 1;
        if (pulls === 1) { useToken(TOKEN_B); controller.enqueue(docx.subarray(0, 10)); return; }
        controller.enqueue(docx.subarray(10));
        controller.close();
      },
      cancel() { cancelled = true; },
    }, { highWaterMark: 0 }), DOCX, "P3_Example_1.docx", { "content-length": String(docx.length) }));
    await expect(deliverAttachment(form)).resolves.toEqual({ kind: "failed", reason: "session-changed", message: GENERIC });
    expect(pulls).toBe(1);
    expect(cancelled).toBe(true);
    expect(signalOf().aborted).toBe(true);
    expect(clicks).toEqual([]);
    expect(blobs).toEqual([]);
  });

  it("A to B replacement while a refusal is read: session A's sentence is never shown", async () => {
    useToken();
    const sentence = "Cannot generate the grant package: add a complete Rule 25-11 citation record for Fictional Person A.";
    respond(() => browserResponse(new ReadableStream<Uint8Array>({
      pull(controller) {
        useToken(TOKEN_B);
        controller.enqueue(encoder.encode(JSON.stringify({ error: sentence })));
        controller.close();
      },
    }, { highWaterMark: 0 }), { status: 400, headers: { "content-type": "application/json" } }));
    await expect(deliverAttachment(form)).resolves.toEqual({ kind: "failed", reason: "session-changed", message: GENERIC });
    expect(toast.error).toHaveBeenCalledTimes(1);
    expect(toast.error).toHaveBeenCalledWith(GENERIC);
  });

  it("a sign-out (cleared session) during the flight: nothing is handed off", async () => {
    useToken();
    respond(() => { clearFallbackSession(); return docxResponse(); });
    await expect(deliverAttachment(form)).resolves.toMatchObject({ kind: "failed", reason: "session-changed" });
    expect(clicks).toEqual([]);
  });

  it("a cookie-only preview logout during the flight: nothing is handed off", async () => {
    respond(() => { clearFallbackSession(); return docxResponse(); });
    await expect(fetchDeliveryAttachment(form)).resolves.toMatchObject({ kind: "failed", reason: "session-changed" });
    expect(clicks).toEqual([]);
  });

  it("same-user rotation is cancelled conservatively; the explicit retry reads the rotated token and succeeds", async () => {
    useToken();
    respond(() => { useToken(`${TOKEN}-rotated`); return docxResponse(); });
    await expect(deliverAttachment(form)).resolves.toMatchObject({ kind: "failed", reason: "session-changed" });
    respond(() => docxResponse());
    await expect(deliverAttachment(form)).resolves.toMatchObject({ kind: "handed-off" });
    expect(headersOf(1).Authorization).toBe(`Bearer ${TOKEN}-rotated`);
    expect(new URLSearchParams(String(initOf(1).body)).get("attemptId")).not.toBe(new URLSearchParams(String(initOf(0).body)).get("attemptId"));
  });
});

describe("Task 9: accepted attachments", () => {
  it.each([
    ["a DOCX form", form, () => docx, DOCX, "P3_Example_1.docx"],
    ["a form ZIP", form, () => zip, "application/zip", "P1_with_Required_Documents_Example_1.zip"],
    ["an export ZIP", exportDelivery, () => zip, "application/zip", "ProbatePro_Estate_Export_Example_1.zip"],
    ["a complete empty export ZIP", exportDelivery, () => emptyZip, "application/zip", "Letters_Example_1.zip"],
    ["a notes PDF", notes, () => pdf, "application/pdf", "Notes - Helen Example - 2026-10-23.pdf"],
  ] as const)("hands off %s with identical bytes, type and the server's filename", async (_label, delivery, bytes, type, filename) => {
    useToken();
    vi.useFakeTimers();
    respond(() => attachment(bytes(), type, filename));
    const outcome = await deliverAttachment(delivery);
    expect(outcome).toEqual({ kind: "handed-off", filename, bytes: bytes().length });
    expect(clicks).toEqual([{ href: "blob:http://localhost/unit-1", download: filename }]);
    expect(blobs[0].type).toBe(type);
    // Plain arrays: jsdom's TextEncoder returns a Uint8Array from another realm.
    expect(Array.from(new Uint8Array(await blobs[0].arrayBuffer()))).toEqual(Array.from(bytes()));
    expect(document.querySelectorAll("a")).toHaveLength(0);
    expect(vi.getTimerCount()).toBe(1);
    await vi.advanceTimersByTimeAsync(BLOB_URL_REVOKE_MS - 1);
    expect(revoke).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(1);
    expect(revoke).toHaveBeenCalledTimes(1);
    expect(revoke).toHaveBeenCalledWith("blob:http://localhost/unit-1");
    expect(toast.error).not.toHaveBeenCalled();
    expect(toast.success).not.toHaveBeenCalled();
  });

  it("a failure while handing the file to the browser is reported once, releases the control and leaves no timer", async () => {
    useToken();
    vi.useFakeTimers();
    Object.defineProperty(URL, "createObjectURL", { configurable: true, writable: true, value: vi.fn(() => { throw new Error("blob URLs unavailable"); }) });
    respond(() => docxResponse());
    const button = document.createElement("button");
    await expect(deliverAttachment(form, button)).resolves.toEqual({ kind: "failed", reason: "invalid-response", message: GENERIC });
    expect(toast.error).toHaveBeenCalledTimes(1);
    expect(clicks).toEqual([]);
    expect(button.hasAttribute("disabled")).toBe(false);
    expect(vi.getTimerCount()).toBe(0);
  });

  it("passes a raw notes name with quotes and Latin-1 letters through unchanged", async () => {
    useToken();
    const name = 'Notes - Zoë "Jo" O\'Brien - 2026-10-23.pdf';
    respond(() => attachment(pdf, "application/pdf", name));
    await expect(deliverAttachment(notes)).resolves.toEqual({ kind: "handed-off", filename: name, bytes: pdf.length });
    expect(clicks[0].download).toBe(name);
  });

  it("accepts a body without Content-Length, and a gzip-encoded body whose decoded size differs from it", async () => {
    useToken();
    respond(() => attachment(chunkedStream([docx.subarray(0, 10), docx.subarray(10)]), DOCX, "P3_Example_1.docx"));
    await expect(deliverAttachment(form)).resolves.toMatchObject({ kind: "handed-off", bytes: docx.length });
    respond(() => attachment(docx, DOCX, "P3_Example_1.docx", { "content-length": "17", "content-encoding": "gzip" }));
    await expect(deliverAttachment(form)).resolves.toMatchObject({ kind: "handed-off", bytes: docx.length });
  });

  it("deliverAndAnnounce (Task 13): a fetch shows a loading toast, then the handoff or one refusal under that same id", async () => {
    useToken();
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    let answer!: (response: Response) => void;
    respond(() => new Promise<Response>((resolve) => { answer = resolve; }));
    deliverAndAnnounce({ ...form }, "Form generated");
    expect(toast.loading).toHaveBeenCalledWith("Form generated — preparing the download…");
    expect(toast.success).not.toHaveBeenCalled();
    await vi.waitFor(() => expect(answer).toBeTypeOf("function"));
    answer(docxResponse());
    await vi.waitFor(() => expect(toast.success).toHaveBeenCalledWith("Form generated — download started.", { id: "t-1" }));

    vi.mocked(toast.loading).mockReturnValueOnce("t-2");
    respond(() => refusal(409, JSON.stringify({ error: "This download link is out of date. Generate the document again." })));
    deliverAndAnnounce({ ...form }, "Form generated");
    await vi.waitFor(() => expect(toast.error).toHaveBeenCalledWith("This download link is out of date. Generate the document again.", { id: "t-2" }));
    expect(toast.error).toHaveBeenCalledTimes(1);
    expect(toast.success).toHaveBeenCalledTimes(1);
    expect(toast.info).not.toHaveBeenCalled();
  });

  it("deliverAndAnnounce (Task 13): a native submission says only that the download was requested", () => {
    const submit = vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(() => undefined);
    deliverAndAnnounce({ ...form }, "Form generated");
    expect(submit).toHaveBeenCalledTimes(1);
    expect(toast.info).toHaveBeenCalledWith("Form generated — download requested. Check your browser's downloads.");
    expect(toast.success).not.toHaveBeenCalled();
    expect(toast.loading).not.toHaveBeenCalled();
  });
});

describe("Task 9: refused or invalid attachments are never handed off", () => {
  const truncatedBeforeEnd = (bytes: Uint8Array) => bytes.subarray(0, bytes.length - 22);
  // JSZip stores members uncompressed, so a member DOCX keeps its own end record inside the archive.
  const cutAfterStoredMember = () => {
    const at = Buffer.from(zip).indexOf(Buffer.from(docx));
    expect(at).toBeGreaterThan(0);
    return zip.subarray(0, at + docx.length);
  };
  it.each([
    ["HTML 200 (a login page)", () => browserResponse("<html>Sign in</html>", { status: 200, headers: { "content-type": "text/html", "content-disposition": 'attachment; filename="P3.docx"' } })],
    ["JSON 200", () => browserResponse(JSON.stringify({ ok: true }), { status: 200, headers: { "content-type": "application/json", "content-disposition": 'attachment; filename="P3.docx"' } })],
    ["a missing disposition", () => browserResponse(docx, { status: 200, headers: { "content-type": DOCX } })],
    ["an inline disposition", () => browserResponse(docx, { status: 200, headers: { "content-type": DOCX, "content-disposition": 'inline; filename="P3.docx"' } })],
    ["an empty name", () => attachment(docx, DOCX, "")],
    ["a control character in the name", () => attachment(docx, DOCX, "P3\u0001.docx")],
    ["an extension that does not match the type", () => attachment(docx, DOCX, "P3_Example_1.zip")],
    ["a DOCX type over HTML bytes", () => attachment(encoder.encode("<html>Sign in</html>"), DOCX, "P3.docx")],
    ["zero bytes", () => attachment(new Uint8Array(0), DOCX, "P3.docx")],
    ["a DOCX truncated before its end record", () => attachment(chunkedStream([truncatedBeforeEnd(docx)]), DOCX, "P3.docx")],
    ["a ZIP truncated before its end record", () => attachment(chunkedStream([truncatedBeforeEnd(zip)]), "application/zip", "P1_with_Required_Documents_X_1.zip")],
    ["a ZIP cut exactly at the end of a stored member DOCX", () => attachment(chunkedStream([cutAfterStoredMember()]), "application/zip", "P1_with_Required_Documents_X_1.zip")],
    ["a PDF cut before %%EOF", () => attachment(chunkedStream([pdf.subarray(0, pdf.length - 7)]), "application/pdf", "Notes.pdf")],
    ["the four bytes PK\\x05\\x06 alone", () => attachment(new Uint8Array([0x50, 0x4b, 0x05, 0x06]), "application/zip", "P1_X_1.zip")],
    ["a 204", () => browserResponse(null, { status: 204 })],
    ["a 206", () => browserResponse(docx, { status: 206, headers: { "content-type": DOCX, "content-disposition": 'attachment; filename="P3.docx"' } })],
    ["a 304", () => browserResponse(null, { status: 304 })],
    ["a cors-typed response", () => browserResponse(docx, { status: 200, headers: { "content-type": DOCX, "content-disposition": 'attachment; filename="P3.docx"' } }, "cors")],
    ["an opaque response", () => browserResponse(docx, { status: 200, headers: { "content-type": DOCX, "content-disposition": 'attachment; filename="P3.docx"' } }, "opaque")],
  ])("%s gives invalid-response with the request aborted", async (_label, make) => {
    useToken();
    respond(() => make());
    const outcome = await deliverAttachment(form);
    expect(outcome).toEqual({ kind: "failed", reason: "invalid-response", message: GENERIC });
    expect(clicks).toEqual([]);
    expect(blobs).toEqual([]);
    expect(signalOf().aborted).toBe(true);
    expect(toast.error).toHaveBeenCalledTimes(1);
    expect(toast.success).not.toHaveBeenCalled();
  });

  it("an export never accepts a DOCX and notes never accept a ZIP", async () => {
    useToken();
    respond(() => docxResponse());
    await expect(deliverAttachment(exportDelivery)).resolves.toMatchObject({ kind: "failed", reason: "invalid-response" });
    respond(() => attachment(zip, "application/zip", "Notes.zip"));
    await expect(deliverAttachment(notes)).resolves.toMatchObject({ kind: "failed", reason: "invalid-response" });
  });

  it("a redirect is refused without following it: one fetch, nothing handed off", async () => {
    useToken();
    respond(() => browserResponse(null, {}, "opaqueredirect"));
    await expect(deliverAttachment(form)).resolves.toEqual({ kind: "failed", reason: "redirect", message: GENERIC });
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    expect(clicks).toEqual([]);
  });

  it("a short body against its declared length is incomplete", async () => {
    useToken();
    respond(() => attachment(chunkedStream([docx.subarray(0, 50)]), DOCX, "P3.docx", { "content-length": String(docx.length) }));
    await expect(deliverAttachment(form)).resolves.toEqual({ kind: "failed", reason: "incomplete", message: GENERIC });
    expect(clicks).toEqual([]);
  });

  it("a malformed declared length is an invalid response", async () => {
    useToken();
    respond(() => attachment(docx, DOCX, "P3.docx", { "content-length": "12abc" }));
    await expect(deliverAttachment(form)).resolves.toMatchObject({ kind: "failed", reason: "invalid-response" });
  });

  it("a stream error mid-body is incomplete and nothing is handed off", async () => {
    useToken();
    respond(() => attachment(new ReadableStream<Uint8Array>({ pull(controller) { controller.error(new TypeError("network reset")); } }), DOCX, "P3.docx"));
    await expect(deliverAttachment(form)).resolves.toMatchObject({ kind: "failed", reason: "incomplete" });
    expect(clicks).toEqual([]);
  });
});

describe("Task 9 D3: ceilings", () => {
  it("states the approved ceilings by value", () => {
    expect(ATTACHMENT_CEILING_BYTES).toEqual({ zip: 536_870_912, docx: 67_108_864, pdf: 67_108_864 });
    expect(REFUSAL_BODY_LIMIT_BYTES).toBe(65_536);
    expect(HEADERS_TIMEOUT_MS).toBe(900_000);
    expect(BODY_IDLE_TIMEOUT_MS).toBe(60_000);
    expect(BODY_TOTAL_TIMEOUT_MS).toBe(1_800_000);
    expect(BLOB_URL_REVOKE_MS).toBe(120_000);
  });

  it.each([
    ["docx", form, DOCX, "P3.docx", ATTACHMENT_CEILING_BYTES.docx],
    ["zip", exportDelivery, "application/zip", "Export_1.zip", ATTACHMENT_CEILING_BYTES.zip],
    ["pdf", notes, "application/pdf", "Notes.pdf", ATTACHMENT_CEILING_BYTES.pdf],
  ] as const)("a declared %s length one byte over the ceiling is refused before a byte is read; exactly the ceiling is read", async (_kind, delivery, type, name, ceiling) => {
    useToken();
    let pulls = 0;
    // highWaterMark 0: a pull happens only when the transport reads.
    const counted = () => new ReadableStream<Uint8Array>({ pull(controller) { pulls += 1; controller.close(); } }, { highWaterMark: 0 });
    respond(() => attachment(counted(), type, name, { "content-length": String(ceiling + 1) }));
    await expect(deliverAttachment(delivery)).resolves.toEqual({ kind: "failed", reason: "too-large", message: GENERIC });
    expect(pulls).toBe(0);
    expect(signalOf().aborted).toBe(true);
    respond(() => attachment(counted(), type, name, { "content-length": String(ceiling) }));
    // Admitted by the length gate; the (empty) stream then fails the exact-length check.
    await expect(deliverAttachment(delivery)).resolves.toMatchObject({ kind: "failed", reason: "incomplete" });
    expect(pulls).toBe(1);
  });

  it("counts actual bytes when no length is declared: one byte over the 64 MiB DOCX ceiling cancels the reader", async () => {
    useToken();
    let cancelled = false;
    // More is still pending after the chunk, so there is a live reader to cancel.
    respond(() => attachment(stalledStream(new Uint8Array(ATTACHMENT_CEILING_BYTES.docx + 1), () => { cancelled = true; }), DOCX, "P3.docx"));
    await expect(deliverAttachment(form)).resolves.toEqual({ kind: "failed", reason: "too-large", message: GENERIC });
    expect(cancelled).toBe(true);
    expect(clicks).toEqual([]);
  });

  it("a refusal body of exactly 65,536 bytes is read; one byte more gives the generic sentence and cancels the reader", async () => {
    useToken();
    const sentence = (length: number) => { const prefix = '{"error":"'; const suffix = '"}'; return prefix + "a".repeat(length - prefix.length - suffix.length) + suffix; };
    respond(() => refusal(400, sentence(REFUSAL_BODY_LIMIT_BYTES)));
    const exact = await deliverAttachment(form);
    expect(exact).toMatchObject({ kind: "refused", status: 400 });
    expect((exact as { message: string }).message).toHaveLength(REFUSAL_BODY_LIMIT_BYTES - 12);
    let cancelled = false;
    respond(() => browserResponse(stalledStream(encoder.encode(sentence(REFUSAL_BODY_LIMIT_BYTES + 1)), () => { cancelled = true; }), { status: 400, headers: { "content-type": "application/json" } }));
    await expect(deliverAttachment(form)).resolves.toEqual({ kind: "refused", status: 400, message: GENERIC });
    expect(cancelled).toBe(true);
  });
});

describe("Task 9: refusals keep their real public outcome", () => {
  it.each([
    [400, "Invalid download parameters."],
    [401, "Authentication required"],
    [403, "Access denied"],
    [404, "Estate not found"],
    [409, "This download link is out of date. Generate the document again."],
    [413, "The request is too large."],
    [429, "Request limit reached for this action. Please wait a moment and try again."],
    [429, "Too many requests. Please slow down."],
    [500, "Failed to generate document. Please try again."],
    [503, "The document was generated but could not be audited. Please try again."],
  ])("%i shows its JSON sentence, saves nothing and announces nothing", async (status, sentence) => {
    useToken();
    respond(() => refusal(status, JSON.stringify({ error: sentence })));
    await expect(deliverAttachment(form)).resolves.toEqual({ kind: "refused", status, message: sentence });
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    expect(clicks).toEqual([]);
    expect(toast.error).toHaveBeenCalledWith(sentence);
    expect(toast.success).not.toHaveBeenCalled();
  });

  it("shows a long closed-parameter sentence whole", async () => {
    useToken();
    const sentence = `Cannot generate the grant package: add a complete Rule 25-11 citation record for ${Array.from({ length: 200 }, (_, i) => `Fictional Contact ${i}`).join(", ")}.`;
    expect(sentence.length).toBeGreaterThan(4000);
    respond(() => refusal(400, JSON.stringify({ error: sentence })));
    await expect(deliverAttachment(form)).resolves.toEqual({ kind: "refused", status: 400, message: sentence });
  });

  it.each([
    ["an HTML 502 page", () => refusal(502, "<html><body>Bad gateway: upstream detail</body></html>", "text/html")],
    ["an HTML 503 page", () => refusal(503, "<html>Service unavailable</html>", "text/html")],
    ["a text refusal", () => refusal(500, "stack trace: at line 1", "text/plain")],
    ["an empty error", () => refusal(400, JSON.stringify({ error: "  " }))],
    ["a non-string error", () => refusal(400, JSON.stringify({ error: { message: "nested" } }))],
    ["a JSON array", () => refusal(400, JSON.stringify(["Access denied"]))],
    ["malformed JSON", () => refusal(400, "{not json")],
  ])("%s gives the generic sentence and never echoes the body", async (_label, make) => {
    useToken();
    respond(() => make());
    const outcome = await deliverAttachment(form);
    expect(outcome).toMatchObject({ kind: "refused", message: GENERIC });
    expect(toast.error).toHaveBeenCalledWith(GENERIC);
  });

  it("the notes route's 500 JSON labelled application/pdf is a refusal, never a document", async () => {
    useToken();
    respond(() => refusal(500, JSON.stringify({ error: "Failed to generate PDF" }), "application/pdf; charset=utf-8"));
    await expect(deliverAttachment(notes)).resolves.toEqual({ kind: "refused", status: 500, message: GENERIC });
    expect(clicks).toEqual([]);
    expect(blobs).toEqual([]);
  });

  it("a network failure is one fetch, the network sentence, and no automatic re-POST", async () => {
    useToken();
    fetchSpy.mockRejectedValue(new TypeError("Failed to fetch"));
    await expect(deliverAttachment(form)).resolves.toEqual({ kind: "failed", reason: "network", message: "Server is temporarily unavailable. Please try again in a moment." });
    expect(fetchSpy).toHaveBeenCalledTimes(1);
  });
});

describe("Task 9: deadlines and cancellation", () => {
  it("no response headers within the deadline is a timeout; the request is aborted", async () => {
    useToken();
    vi.useFakeTimers();
    respond(() => new Promise<Response>(() => undefined));
    const pending = deliverAttachment(form);
    await vi.advanceTimersByTimeAsync(HEADERS_TIMEOUT_MS - 1);
    expect(signalOf().aborted).toBe(false);
    await vi.advanceTimersByTimeAsync(1);
    await expect(pending).resolves.toEqual({ kind: "failed", reason: "timeout", message: "The server took too long to respond. Please try again." });
    expect(signalOf().aborted).toBe(true);
    expect(vi.getTimerCount()).toBe(0);
  });

  it("a body that stalls longer than the idle deadline is a timeout and its reader is cancelled", async () => {
    useToken();
    vi.useFakeTimers();
    let cancelled = false;
    respond(() => attachment(stalledStream(docx.subarray(0, 10), () => { cancelled = true; }), DOCX, "P3.docx"));
    const pending = deliverAttachment(form);
    await vi.advanceTimersByTimeAsync(BODY_IDLE_TIMEOUT_MS);
    await expect(pending).resolves.toMatchObject({ kind: "failed", reason: "timeout" });
    expect(cancelled).toBe(true);
    expect(clicks).toEqual([]);
    expect(vi.getTimerCount()).toBe(0);
  });

  it("a trickle under the idle deadline is still cut by the total body deadline", async () => {
    useToken();
    vi.useFakeTimers();
    let cancelled = false;
    let interval: ReturnType<typeof setInterval> | undefined;
    const trickle = new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(docx.subarray(0, 4));
        interval = setInterval(() => controller.enqueue(new Uint8Array([0])), BODY_IDLE_TIMEOUT_MS - 1000);
      },
      cancel() { cancelled = true; clearInterval(interval); },
    });
    respond(() => attachment(trickle, DOCX, "P3.docx"));
    const pending = deliverAttachment(form);
    await vi.advanceTimersByTimeAsync(BODY_TOTAL_TIMEOUT_MS);
    await expect(pending).resolves.toMatchObject({ kind: "failed", reason: "timeout" });
    expect(cancelled).toBe(true);
    expect(clicks).toEqual([]);
  });

  it("a deadline while a read is pending and no length was declared wins over the read: a complete-looking body is not handed off", async () => {
    useToken();
    vi.useFakeTimers();
    // A whole valid DOCX arrives, then the stream stalls. The cancel resolves the pending read as done;
    // that done must not count as the end of the file.
    respond(() => attachment(stalledStream(docx), DOCX, "P3.docx"));
    const pending = deliverAttachment(form);
    await vi.advanceTimersByTimeAsync(BODY_IDLE_TIMEOUT_MS);
    await expect(pending).resolves.toMatchObject({ kind: "failed", reason: "timeout" });
    expect(blobs).toEqual([]);
    expect(clicks).toEqual([]);
  });

  it("a caller abort before the headers or while reading is a cancellation, with the reader cancelled", async () => {
    useToken();
    const before = new AbortController();
    respond(() => new Promise<Response>(() => undefined));
    const pending = fetchDeliveryAttachment(form, before.signal);
    await Promise.resolve();
    before.abort();
    await expect(pending).resolves.toEqual({ kind: "cancelled" });

    let cancelled = false;
    const during = new AbortController();
    respond(() => attachment(stalledStream(docx.subarray(0, 10), () => { cancelled = true; }), DOCX, "P3.docx"));
    const reading = fetchDeliveryAttachment(form, during.signal);
    await vi.waitFor(() => expect(fetchSpy).toHaveBeenCalledTimes(2));
    await new Promise((resolve) => setTimeout(resolve, 0));
    during.abort();
    await expect(reading).resolves.toEqual({ kind: "cancelled" });
    expect(cancelled).toBe(true);
    expect(clicks).toEqual([]);

    const already = new AbortController();
    already.abort();
    await expect(fetchDeliveryAttachment(form, already.signal)).resolves.toEqual({ kind: "cancelled" });
    expect(fetchSpy).toHaveBeenCalledTimes(2);
  });

  it("after a refusal no timer is left behind", async () => {
    useToken();
    vi.useFakeTimers();
    respond(() => refusal(409, JSON.stringify({ error: "This download link is out of date. Generate the document again." })));
    await deliverAttachment(form);
    expect(vi.getTimerCount()).toBe(0);
  });
});

describe("Task 9: the control's lifetime on the fetch path", () => {
  function Button({ onActivate }: { onActivate: (control: HTMLElement) => void }) {
    return <button type="button" onClick={(event) => onActivate(event.currentTarget)}>Download P3</button>;
  }

  it("holds the control for the actual request lifetime, suppresses a double click, then releases it", async () => {
    useToken();
    let answer!: (response: Response) => void;
    respond(() => new Promise<Response>((resolve) => { answer = resolve; }));
    const outcomes: Promise<DeliveryOutcome>[] = [];
    render(<Button onActivate={(control) => outcomes.push(deliverAttachment(form, control))} />);
    const button = screen.getByRole("button", { name: "Download P3" }) as HTMLButtonElement;
    fireEvent.click(button);
    expect(button.disabled).toBe(true);
    outcomes.push(deliverAttachment(form, button));
    await expect(outcomes[1]).resolves.toEqual({ kind: "suppressed" });
    await vi.waitFor(() => expect(answer).toBeTypeOf("function"));
    answer(docxResponse());
    await expect(outcomes[0]).resolves.toMatchObject({ kind: "handed-off" });
    expect(button.disabled).toBe(false);
    expect(fetchSpy).toHaveBeenCalledTimes(1);
  });

  it("independent controls on different prepared deliveries both proceed (Task 13: one shared delivery is one fetch)", async () => {
    useToken();
    respond(() => docxResponse());
    const first = document.createElement("button");
    const second = document.createElement("button");
    const outcomes = await Promise.all([deliverAttachment({ ...form }, first), deliverAttachment({ ...form }, second)]);
    expect(outcomes.map((outcome) => outcome.kind)).toEqual(["handed-off", "handed-off"]);
    expect(fetchSpy).toHaveBeenCalledTimes(2);
  });

  it("never re-enables a control that was already disabled", async () => {
    useToken();
    respond(() => refusal(500, JSON.stringify({ error: "Failed to generate document. Please try again." })));
    const button = document.createElement("button");
    button.setAttribute("disabled", "");
    await deliverAttachment(form, button);
    expect(button.hasAttribute("disabled")).toBe(true);
  });

  it("returns focus only when it dropped to the page, never taking it back from a moved focus or an unmounted control", async () => {
    useToken();
    respond(() => docxResponse());
    const { unmount } = render(<><Button onActivate={() => undefined} /><button type="button">Other</button></>);
    const button = screen.getByRole("button", { name: "Download P3" });
    const other = screen.getByRole("button", { name: "Other" });
    const focus = vi.spyOn(button, "focus");

    // Browsers drop focus from a control that becomes disabled; jsdom keeps it, so emulate the drop
    // after the hold (which reads the focus synchronously) and before the release.
    button.focus();
    focus.mockClear();
    const dropped = deliverAttachment(form, button);
    const toPage = vi.spyOn(document, "activeElement", "get").mockReturnValue(document.body);
    await dropped;
    expect(focus).toHaveBeenCalledTimes(1);
    expect(focus).toHaveBeenCalledWith({ preventScroll: true });
    toPage.mockRestore();

    button.focus();
    focus.mockClear();
    const moved = deliverAttachment(form, button);
    other.focus();
    await moved;
    expect(focus).not.toHaveBeenCalled();
    expect(document.activeElement).toBe(other);

    button.focus();
    focus.mockClear();
    let answer!: (response: Response) => void;
    respond(() => new Promise<Response>((resolve) => { answer = resolve; }));
    const pending = deliverAttachment(form, button);
    unmount();
    await vi.waitFor(() => expect(answer).toBeTypeOf("function"));
    const anyFocus = vi.spyOn(HTMLElement.prototype, "focus");
    answer(docxResponse());
    await expect(pending).resolves.toMatchObject({ kind: "handed-off" });
    expect(focus).not.toHaveBeenCalled();
    expect(anyFocus).not.toHaveBeenCalled();
  });
});

describe("Task 9: the token never leaves the Authorization header", () => {
  it("is absent from every URL, body, anchor, toast and console argument", async () => {
    useToken();
    const logged: string[] = [];
    for (const method of ["log", "info", "warn", "error", "debug"] as const) {
      vi.spyOn(console, method).mockImplementation((...args: unknown[]) => { logged.push(args.map(String).join(" ")); });
    }
    respond(() => docxResponse());
    await deliverAttachment(form);
    respond(() => refusal(401, JSON.stringify({ error: "Authentication required" })));
    await deliverAttachment(form);
    fetchSpy.mockRejectedValueOnce(new TypeError("Failed to fetch"));
    await deliverAttachment(form);
    const visible = JSON.stringify({
      urls: fetchSpy.mock.calls.map((call) => String(call[0])),
      bodies: fetchSpy.mock.calls.map((call) => String(call[1]?.body)),
      clicks,
      toasts: [...vi.mocked(toast.error).mock.calls, ...vi.mocked(toast.success).mock.calls],
      logged,
    });
    expect(visible).not.toContain(TOKEN);
    expect(fetchSpy.mock.calls.every((call) => (call[1]?.headers as Record<string, string>).Authorization === `Bearer ${TOKEN}`)).toBe(true);
  });
});

// ─── Task 13 ─────────────────────────────────────────────────────────────────────────────────────────

const attemptAt = (index: number) => new URLSearchParams(String(initOf(index).body)).get("attemptId");
const settle = () => new Promise<void>((resolve) => { setTimeout(resolve, 0); });

/** A fetch whose response is held until the test releases it. */
function paused(): { release(response: Response): Promise<void> } {
  let answer: ((response: Response) => void) | undefined;
  respond(() => new Promise<Response>((resolve) => { answer = resolve; }));
  return {
    async release(response: Response) {
      await vi.waitFor(() => expect(answer).toBeTypeOf("function"));
      answer!(response);
    },
  };
}

describe("Task 13: one in-flight fetch per prepared delivery", () => {
  it("the auto-download and its own button share one fetch; the button is suppressed until the attempt settles", async () => {
    useToken();
    const delivery: PostDelivery = { ...form };
    const flight = paused();
    deliverAndAnnounce(delivery, "Form generated");
    const button = document.createElement("button");
    const second = deliverAttachment(delivery, button);
    await settle();
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    await expect(second).resolves.toEqual({ kind: "suppressed" });
    expect(button.hasAttribute("disabled")).toBe(false);
    await flight.release(docxResponse());
    await vi.waitFor(() => expect(toast.success).toHaveBeenCalledWith("Form generated — download started."));
    respond(() => docxResponse());
    await expect(deliverAttachment(delivery, button)).resolves.toMatchObject({ kind: "handed-off" });
    expect(fetchSpy).toHaveBeenCalledTimes(2);
    expect(attemptAt(1)).not.toBe(attemptAt(0));
    expect(blobs).toHaveLength(2);
  });

  it("two controls on one prepared delivery start one fetch", async () => {
    useToken();
    const delivery: PostDelivery = { ...form };
    const flight = paused();
    const first = deliverAttachment(delivery, document.createElement("button"));
    const second = deliverAttachment(delivery, document.createElement("button"));
    await settle();
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    await expect(second).resolves.toEqual({ kind: "suppressed" });
    await flight.release(docxResponse());
    await expect(first).resolves.toMatchObject({ kind: "handed-off" });
    expect(blobs).toHaveLength(1);
  });

  it.each([
    ["a refusal", () => refusal(503, JSON.stringify({ error: "Estate exports are busy. Please try again in a moment." }))],
    ["a network failure", null],
  ] as const)("after %s the delivery is released, so an explicit retry is a fresh attempt with the current token", async (_label, make) => {
    useToken();
    const delivery: PostDelivery = { ...form };
    if (make) respond(make);
    else fetchSpy.mockRejectedValueOnce(new TypeError("Failed to fetch"));
    const first = await deliverAttachment(delivery);
    expect(first.kind).toBe(make ? "refused" : "failed");
    useToken(TOKEN_B);
    respond(() => docxResponse());
    await expect(deliverAttachment(delivery)).resolves.toMatchObject({ kind: "handed-off" });
    expect(headersOf(1).Authorization).toBe(`Bearer ${TOKEN_B}`);
    expect(attemptAt(1)).not.toBe(attemptAt(0));
  });

  it("a native submission never holds the delivery: an immediate retry posts again with a fresh attemptId", async () => {
    const posted: string[] = [];
    vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) {
      posted.push(String(new FormData(this).get("attemptId")));
    });
    const delivery: PostDelivery = { ...form };
    deliverAndAnnounce(delivery, "Form generated");
    await expect(deliverAttachment(delivery, document.createElement("button"))).resolves.toEqual({ kind: "submitted" });
    expect(posted).toHaveLength(2);
    expect(posted[1]).not.toBe(posted[0]);
  });

  it("a synchronous native submit failure propagates and registers nothing", async () => {
    vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementationOnce(() => { throw new Error("submission blocked"); });
    const delivery: PostDelivery = { ...form };
    expect(() => deliverAndAnnounce(delivery, "Form generated")).toThrow("submission blocked");
    expect(toast.info).not.toHaveBeenCalled();
    useToken();
    respond(() => docxResponse());
    await expect(deliverAttachment(delivery)).resolves.toMatchObject({ kind: "handed-off" });
  });

  it("useDeliveryPending is true only while that delivery's fetch is in flight", async () => {
    useToken();
    const watched: PostDelivery = { ...form };
    const other: PostDelivery = { ...form };
    function Probe() {
      return <><span data-testid="watched">{String(useDeliveryPending(watched))}</span><span data-testid="other">{String(useDeliveryPending(other))}</span></>;
    }
    render(<Probe />);
    expect(screen.getByTestId("watched").textContent).toBe("false");
    const flight = paused();
    act(() => deliverAndAnnounce(watched, "Form generated"));
    await waitFor(() => expect(screen.getByTestId("watched").textContent).toBe("true"));
    expect(screen.getByTestId("other").textContent).toBe("false");
    await flight.release(docxResponse());
    await waitFor(() => expect(screen.getByTestId("watched").textContent).toBe("false"));
  });
});

describe("Task 13: recovery classification", () => {
  it("an invalid descriptor is never silent", async () => {
    await expect(deliverAttachment({ ...form, action: "https://example.invalid/api/download/form" } as unknown as PostDelivery)).resolves.toEqual({ kind: "invalid" });
    expect(toast.error).toHaveBeenCalledTimes(1);
    expect(toast.error).toHaveBeenCalledWith(GENERIC);
  });

  const stale = "This download link is out of date. Generate the document again.";
  it.each([
    [{ kind: "refused", status: 409, message: stale }, stale],
    [{ kind: "refused", status: 400, message: "Invalid download parameters." }, "Invalid download parameters."],
    [{ kind: "refused", status: 413, message: "The request is too large." }, "The request is too large."],
    [{ kind: "invalid" }, GENERIC],
    [{ kind: "refused", status: 401, message: "Authentication required" }, null],
    [{ kind: "refused", status: 403, message: "Access denied" }, null],
    [{ kind: "refused", status: 404, message: "Estate not found" }, null],
    [{ kind: "refused", status: 429, message: "Request limit reached for this action. Please wait a moment and try again." }, null],
    [{ kind: "refused", status: 500, message: "Failed to generate document. Please try again." }, null],
    [{ kind: "refused", status: 503, message: "The document was generated but could not be audited. Please try again." }, null],
    [{ kind: "failed", reason: "network", message: "Server is temporarily unavailable. Please try again in a moment." }, null],
    [{ kind: "failed", reason: "too-large", message: GENERIC }, null],
    [{ kind: "submitted" }, null],
    [{ kind: "handed-off", filename: "P3.docx", bytes: 1 }, null],
    [{ kind: "suppressed" }, null],
    [{ kind: "cancelled" }, null],
  ] as Array<[DeliveryOutcome, string | null]>)("unusableLinkMessage(%o) is %s", (outcome, expected) => {
    expect(unusableLinkMessage(outcome)).toBe(expected);
  });
});

describe("Task 13: an attempt's feedback belongs to its mounted owner, slot and session", () => {
  type OwnerHook = ReturnType<typeof mountOwner>;
  function mountOwner() {
    return renderHook(({ scope, active }: { scope: string; active: boolean }) => useDeliveryFeedbackOwner(scope, active), {
      initialProps: { scope: "forms:estate-1", active: true },
    });
  }

  it.each([
    ["the owner unmounts", (hook: OwnerHook) => hook.unmount()],
    ["the owner moves to another estate", (hook: OwnerHook) => hook.rerender({ scope: "forms:estate-2", active: true })],
    ["the owner becomes inactive", (hook: OwnerHook) => hook.rerender({ scope: "forms:estate-1", active: false })],
    ["its slot is retired", (hook: OwnerHook) => act(() => hook.result.current.retire("form-recovery"))],
  ])("when %s, its live toast is removed at once and its later result and callback are dropped", async (_label, retire) => {
    useToken();
    const hook = mountOwner();
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    const flight = paused();
    const onOutcome = vi.fn();
    const delivery: PostDelivery = { ...form };
    deliverAndAnnounce(delivery, "Form generated", { feedback: { owner: hook.result.current, slot: "form-recovery" }, onOutcome });
    expect(toast.loading).toHaveBeenCalledWith("Form generated — preparing the download…");
    retire(hook);
    expect(toast.dismiss).toHaveBeenCalledWith("t-1");
    await flight.release(docxResponse());
    // Feedback cleanup is not request cancellation: the browser still receives the file.
    await vi.waitFor(() => expect(clicks).toHaveLength(1));
    await settle();
    expect(toast.success).not.toHaveBeenCalled();
    expect(toast.error).not.toHaveBeenCalled();
    expect(onOutcome).not.toHaveBeenCalled();
    // The lock still ends at settlement.
    respond(() => docxResponse());
    await expect(deliverAttachment(delivery)).resolves.toMatchObject({ kind: "handed-off" });
  });

  it("a newer attempt in the same slot replaces the older one: only the newer result is announced", async () => {
    useToken();
    const { result } = mountOwner();
    vi.mocked(toast.loading).mockReturnValueOnce("t-old").mockReturnValueOnce("t-new");
    const answers: Array<(response: Response) => void> = [];
    respond(() => new Promise<Response>((resolve) => { answers.push(resolve); }));
    const older = vi.fn();
    const newer = vi.fn();
    deliverAndAnnounce({ ...form }, "Form generated", { feedback: { owner: result.current, slot: "form-recovery" }, onOutcome: older });
    deliverAndAnnounce({ ...form }, "Form generated", { feedback: { owner: result.current, slot: "form-recovery" }, onOutcome: newer });
    expect(toast.dismiss).toHaveBeenCalledWith("t-old");
    await vi.waitFor(() => expect(answers).toHaveLength(2));
    answers[0](docxResponse());
    answers[1](docxResponse());
    await vi.waitFor(() => expect(newer).toHaveBeenCalledTimes(1));
    await settle();
    expect(older).not.toHaveBeenCalled();
    expect(toast.success).toHaveBeenCalledTimes(1);
    expect(toast.success).toHaveBeenCalledWith("Form generated — download started.", { id: "t-new" });
  });

  it("attempts in different slots of one owner keep their own feedback", async () => {
    useToken();
    const { result } = mountOwner();
    respond(() => docxResponse());
    const formOutcome = vi.fn();
    const packageOutcome = vi.fn();
    deliverAndAnnounce({ ...form }, "Form generated", { feedback: { owner: result.current, slot: "form-recovery" }, onOutcome: formOutcome });
    deliverAndAnnounce({ ...exportDelivery }, "Grant package generated", { feedback: { owner: result.current, slot: "package" }, onOutcome: packageOutcome });
    await vi.waitFor(() => expect(formOutcome).toHaveBeenCalledTimes(1));
    await vi.waitFor(() => expect(packageOutcome).toHaveBeenCalledTimes(1));
    expect(toast.success).toHaveBeenCalledWith("Form generated — download started.");
  });

  it("a token rotation during the flight keeps the attempt's feedback: its error replaces the loading toast, onOutcome hears session-changed, and no file is handed off", async () => {
    useToken();
    const { result } = mountOwner();
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    // Task 13 r3 (D12): a same-tab token rotation does not end the session; the transport still fails the read.
    respond(() => { useToken(TOKEN_B); return docxResponse(); });
    const onOutcome = vi.fn();
    deliverAndAnnounce({ ...form }, "Form generated", { feedback: { owner: result.current, slot: "form-recovery" }, onOutcome });
    await vi.waitFor(() => expect(toast.error).toHaveBeenCalledWith(GENERIC, { id: "t-1" }));
    await settle();
    expect(toast.error).toHaveBeenCalledTimes(1);
    expect(onOutcome).toHaveBeenCalledTimes(1);
    expect(onOutcome).toHaveBeenCalledWith({ kind: "failed", reason: "session-changed", message: GENERIC });
    expect(toast.dismiss).not.toHaveBeenCalled();
    expect(toast.success).not.toHaveBeenCalled();
    expect(clicks).toEqual([]);
    expect(blobs).toEqual([]);
  });

  it("ending the session during the flight drops the old session's feedback", async () => {
    useToken();
    const { result } = mountOwner();
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    respond(() => { clearFallbackSession(); return docxResponse(); });
    const onOutcome = vi.fn();
    deliverAndAnnounce({ ...form }, "Form generated", { feedback: { owner: result.current, slot: "form-recovery" }, onOutcome });
    await vi.waitFor(() => expect(toast.dismiss).toHaveBeenCalledWith("t-1"));
    await settle();
    expect(toast.error).not.toHaveBeenCalled();
    expect(toast.success).not.toHaveBeenCalled();
    expect(onOutcome).not.toHaveBeenCalled();
    expect(clicks).toEqual([]);
  });

  it.each([
    ["the owner unmounts", (hook: OwnerHook) => hook.unmount()],
    ["the session ends", () => clearFallbackSession()],
    ["its slot is retired", (hook: OwnerHook) => hook.result.current.retire("form-recovery")],
  ])("when %s between the handoff and the dispatch, nothing is announced for that attempt", async (_label, change) => {
    useToken();
    const hook = mountOwner();
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    const onOutcome = vi.fn();
    vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(function (this: HTMLAnchorElement) {
      clicks.push({ href: this.href, download: this.download });
      change(hook);
    });
    respond(() => docxResponse());
    deliverAndAnnounce({ ...form }, "Form generated", { feedback: { owner: hook.result.current, slot: "form-recovery" }, onOutcome });
    await vi.waitFor(() => expect(clicks).toHaveLength(1));
    await settle();
    expect(toast.success).not.toHaveBeenCalled();
    expect(onOutcome).not.toHaveBeenCalled();
    expect(toast.dismiss).toHaveBeenCalledWith("t-1");
  });

  it("a token rotation between the handoff and the dispatch still announces the download that started", async () => {
    useToken();
    const { result } = mountOwner();
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    const onOutcome = vi.fn();
    vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(function (this: HTMLAnchorElement) {
      clicks.push({ href: this.href, download: this.download });
      useToken(TOKEN_B);
    });
    respond(() => docxResponse());
    deliverAndAnnounce({ ...form }, "Form generated", { feedback: { owner: result.current, slot: "form-recovery" }, onOutcome });
    await vi.waitFor(() => expect(clicks).toHaveLength(1));
    await settle();
    expect(toast.success).toHaveBeenCalledWith("Form generated — download started.", { id: "t-1" });
    expect(toast.dismiss).not.toHaveBeenCalled();
    expect(onOutcome).toHaveBeenCalledWith({ kind: "handed-off", filename: "P3_Example_1.docx", bytes: docx.length });
  });

  it("a refusal dispatched after a token rotation uses the generic sentence, never the server's, for the toast and onOutcome", async () => {
    useToken();
    const { result } = mountOwner();
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    const sentence = "Cannot generate the grant package: add a complete Rule 25-11 citation record for Fictional Person A.";
    // Task 13 r3.1: the token rotates after the transport's last session check of the refusal body and before the
    // outcome is dispatched — inside the abort that ends every request not handed off (Task 9), a deterministic point.
    respond((init) => {
      init.signal!.addEventListener("abort", () => useToken(TOKEN_B), { once: true });
      return refusal(409, JSON.stringify({ error: sentence }));
    });
    const onOutcome = vi.fn();
    deliverAndAnnounce({ ...form }, "Form generated", { feedback: { owner: result.current, slot: "form-recovery" }, onOutcome });
    await vi.waitFor(() => expect(onOutcome).toHaveBeenCalledTimes(1));
    expect(onOutcome).toHaveBeenCalledWith({ kind: "refused", status: 409, message: GENERIC });
    expect(toast.error).toHaveBeenCalledTimes(1);
    expect(toast.error).toHaveBeenCalledWith(GENERIC, { id: "t-1" });
  });

  it("a button attempt's error belongs to its owner too", async () => {
    useToken();
    const hook = mountOwner();
    const flight = paused();
    const onOutcome = vi.fn();
    const pending = deliverAttachment({ ...form }, document.createElement("button"), { owner: hook.result.current, slot: "form-recovery" }, onOutcome);
    hook.unmount();
    await flight.release(refusal(409, JSON.stringify({ error: "This download link is out of date. Generate the document again." })));
    await expect(pending).resolves.toMatchObject({ kind: "refused", status: 409 });
    expect(toast.error).not.toHaveBeenCalled();
    expect(onOutcome).not.toHaveBeenCalled();
  });

  it("a native submission that throws begins nothing: the slot keeps its earlier attempt's feedback", () => {
    const submit = vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(() => undefined);
    const { result } = mountOwner();
    const target = { owner: result.current, slot: "form-recovery" };
    vi.mocked(toast.info).mockReturnValueOnce("t-1");
    deliverAndAnnounce({ ...form }, "Form generated", { feedback: target });
    submit.mockImplementationOnce(() => { throw new Error("submission blocked"); });
    expect(() => deliverAndAnnounce({ ...form }, "Form generated", { feedback: target })).toThrow("submission blocked");
    expect(toast.info).toHaveBeenCalledTimes(1);
    expect(toast.dismiss).not.toHaveBeenCalled();
  });
});

describe("Task 13 r3 (D11): a surface on the estate page's owner keeps its attempts across a tab switch", () => {
  type PageHook = ReturnType<typeof mountPage>;
  /** The estate page's owner (AnimatedTabs): one per estate, outliving the tabs it shows. */
  function mountPage() {
    return renderHook(({ scope }: { scope: string }) => useDeliveryFeedbackOwner(scope), { initialProps: { scope: "estate:estate-1" } });
  }
  /** One mounted instance of a tab surface (FormsTab, DeliveriesCard, NotesTab) given that page owner. */
  function mountSurface(page: DeliveryFeedbackOwner) {
    return renderHook(() => useEstateFeedbackOwner(page, "forms:estate-1"));
  }

  it("an attempt keeps its feedback after the surface that began it unmounts: the handoff replaces its loading toast", async () => {
    useToken();
    const page = mountPage();
    const surface = mountSurface(page.result.current);
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    const flight = paused();
    const onOutcome = vi.fn();
    deliverAndAnnounce({ ...form }, "Form generated", { feedback: { owner: surface.result.current, slot: "form-recovery" }, onOutcome });
    // A tab switch unmounts the surface; the page and its owner stay.
    surface.unmount();
    await flight.release(docxResponse());
    await vi.waitFor(() => expect(clicks).toHaveLength(1));
    await settle();
    expect(toast.loading).toHaveBeenCalledWith("Form generated — preparing the download…");
    expect(toast.dismiss).not.toHaveBeenCalled();
    expect(toast.success).toHaveBeenCalledWith("Form generated — download started.", { id: "t-1" });
    expect(onOutcome).toHaveBeenCalledWith({ kind: "handed-off", filename: "P3_Example_1.docx", bytes: docx.length });
  });

  it("two instances on one page owner never replace each other's attempts in a slot of the same name", async () => {
    useToken();
    const page = mountPage();
    const first = mountSurface(page.result.current);
    const second = mountSurface(page.result.current);
    vi.mocked(toast.loading).mockReturnValueOnce("t-first").mockReturnValueOnce("t-second");
    const answers: Array<(response: Response) => void> = [];
    respond(() => new Promise<Response>((resolve) => { answers.push(resolve); }));
    const firstOutcome = vi.fn();
    const secondOutcome = vi.fn();
    deliverAndAnnounce({ ...form }, "Form generated", { feedback: { owner: first.result.current, slot: "form-recovery" }, onOutcome: firstOutcome });
    // As a remounted tab does: the second instance begins in its own slot of the same name.
    deliverAndAnnounce({ ...form }, "Form generated", { feedback: { owner: second.result.current, slot: "form-recovery" }, onOutcome: secondOutcome });
    await vi.waitFor(() => expect(answers).toHaveLength(2));
    answers[0](docxResponse());
    answers[1](docxResponse());
    await vi.waitFor(() => expect(clicks).toHaveLength(2));
    await settle();
    expect(toast.dismiss).not.toHaveBeenCalled();
    expect(toast.success).toHaveBeenCalledWith("Form generated — download started.", { id: "t-first" });
    expect(firstOutcome).toHaveBeenCalledTimes(1);
    expect(toast.success).toHaveBeenCalledWith("Form generated — download started.", { id: "t-second" });
    expect(secondOutcome).toHaveBeenCalledTimes(1);
  });

  it.each([
    ["the page unmounts (the user leaves the estate)", (page: PageHook) => page.unmount()],
    ["the page moves to another estate", (page: PageHook) => page.rerender({ scope: "estate:estate-2" })],
  ])("when %s, every attempt begun on it is retired at once and says nothing later", async (_label, leave) => {
    useToken();
    const page = mountPage();
    vi.mocked(toast.loading).mockReturnValueOnce("t-1").mockReturnValueOnce("t-2").mockReturnValueOnce("t-3");
    const answers: Array<(response: Response) => void> = [];
    respond(() => new Promise<Response>((resolve) => { answers.push(resolve); }));
    const onOutcome = vi.fn();
    // Slots as two Forms instances and a Notes instance namespace them on the page owner.
    for (const slot of ["forms-1:form-recovery", "forms-2:form-recovery", "notes-1:notes"]) {
      deliverAndAnnounce({ ...form }, "Form generated", { feedback: { owner: page.result.current, slot }, onOutcome });
    }
    await vi.waitFor(() => expect(answers).toHaveLength(3));
    leave(page);
    const dismissedAtOnce = vi.mocked(toast.dismiss).mock.calls.map(([id]) => id);
    answers.forEach((answer) => answer(docxResponse()));
    // Feedback cleanup is not request cancellation: the browser still receives every file.
    await vi.waitFor(() => expect(clicks).toHaveLength(3));
    await settle();
    expect(dismissedAtOnce).toEqual(["t-1", "t-2", "t-3"]);
    expect(toast.success).not.toHaveBeenCalled();
    expect(toast.error).not.toHaveBeenCalled();
    expect(onOutcome).not.toHaveBeenCalled();
  });
});

describe("Task 13: cleanup runs exactly once and survives throwing observers", () => {
  it("a throwing loading toast never stops the delivery or reaches the caller", async () => {
    useToken();
    vi.mocked(toast.loading).mockImplementationOnce(() => { throw new Error("toaster unavailable"); });
    respond(() => docxResponse());
    const onOutcome = vi.fn();
    expect(() => deliverAndAnnounce({ ...form }, "Form generated", { onOutcome })).not.toThrow();
    await vi.waitFor(() => expect(onOutcome).toHaveBeenCalledWith(expect.objectContaining({ kind: "handed-off" })));
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    expect(clicks).toHaveLength(1);
  });

  it("a throwing result toast or onOutcome never rejects, re-posts or leaves the delivery held", async () => {
    useToken();
    const delivery: PostDelivery = { ...form };
    vi.mocked(toast.success).mockImplementationOnce(() => { throw new Error("toaster unavailable"); });
    respond(() => docxResponse());
    const onOutcome = vi.fn(() => { throw new Error("observer failed"); });
    deliverAndAnnounce(delivery, "Form generated", { onOutcome });
    await vi.waitFor(() => expect(onOutcome).toHaveBeenCalledTimes(1));
    await settle();
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    respond(() => docxResponse());
    await expect(deliverAttachment(delivery)).resolves.toMatchObject({ kind: "handed-off" });
    expect(fetchSpy).toHaveBeenCalledTimes(2);
    // The activation's own promise resolves although its observer throws.
    await expect(deliverAttachment({ ...form }, undefined, undefined, () => { throw new Error("observer failed"); })).resolves.toMatchObject({ kind: "handed-off" });
  });

  it("a result toast that throws does not leave its loading toast up", async () => {
    useToken();
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    vi.mocked(toast.success).mockImplementationOnce(() => { throw new Error("toaster unavailable"); });
    respond(() => docxResponse());
    deliverAndAnnounce({ ...form }, "Form generated");
    await vi.waitFor(() => expect(clicks).toHaveLength(1));
    await vi.waitFor(() => expect(toast.dismiss).toHaveBeenCalledWith("t-1"));
  });

  it("a throwing pending subscriber never reaches the caller, and the others hear exactly one registration and one release", async () => {
    useToken();
    const heard: string[] = [];
    const offFailing = subscribeDeliveryPending(() => { throw new Error("subscriber failed"); });
    const offCounting = subscribeDeliveryPending(() => { heard.push("change"); });
    try {
      respond(() => docxResponse());
      const onOutcome = vi.fn();
      expect(() => deliverAndAnnounce({ ...form }, "Form generated", { onOutcome })).not.toThrow();
      await vi.waitFor(() => expect(onOutcome).toHaveBeenCalledTimes(1));
      await settle();
      expect(heard).toEqual(["change", "change"]);
    } finally {
      offFailing();
      offCounting();
    }
  });

  it("a control that cannot be held fails the attempt once, sends nothing and holds nothing", async () => {
    useToken();
    const delivery: PostDelivery = { ...form };
    const button = document.createElement("button");
    vi.spyOn(button, "setAttribute").mockImplementationOnce(() => { throw new Error("cannot disable"); });
    await expect(deliverAttachment(delivery, button)).resolves.toEqual({ kind: "failed", reason: "invalid-response", message: GENERIC });
    expect(fetchSpy).not.toHaveBeenCalled();
    expect(toast.error).toHaveBeenCalledTimes(1);
    respond(() => docxResponse());
    // Neither the delivery nor the control was left held.
    await expect(deliverAttachment(delivery, button)).resolves.toMatchObject({ kind: "handed-off" });
  });
});
