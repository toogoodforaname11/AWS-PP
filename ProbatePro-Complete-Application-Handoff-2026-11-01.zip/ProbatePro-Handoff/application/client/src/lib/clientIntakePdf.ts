import { jsPDF } from "jspdf";
import {
  buildClientIntakeSummarySections,
  type ClientIntakeSummaryRow,
  type ClientIntakeSummarySection,
} from "@/lib/clientIntakeSummary";
import type { ClientIntakePayload } from "@shared/clientIntake";

export {
  buildClientIntakeSummarySections as buildClientIntakePdfSections,
  type ClientIntakeSummaryRow as ClientIntakePdfRow,
  type ClientIntakeSummarySection as ClientIntakePdfSection,
};

type ExportInput = {
  payload: ClientIntakePayload;
  submittedByName: string;
  submittedAt: number;
};

function safeFilenamePart(value: string) {
  const normalized = value
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return normalized.slice(0, 72) || "submission";
}

function exportDate(timestamp: number) {
  const date = new Date(timestamp);
  if (!Number.isFinite(date.getTime())) return "undated";
  return date.toISOString().slice(0, 10);
}

export function clientIntakePdfFilename(
  input: Pick<ExportInput, "submittedByName" | "submittedAt">
) {
  return `client-intake-${safeFilenamePart(input.submittedByName)}-${exportDate(input.submittedAt)}.pdf`;
}

/** Creates a browser-download PDF for the selected completed client submission. */
export function exportCompletedClientIntakePdf(input: ExportInput) {
  const doc = new jsPDF({ unit: "mm", format: "a4", compress: true });
  const filename = clientIntakePdfFilename(input);
  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 18;
  const contentWidth = pageWidth - margin * 2;
  let y = 20;

  const nextPage = () => {
    doc.addPage();
    y = margin;
  };
  const ensureSpace = (height: number) => {
    if (y + height > pageHeight - margin) nextPage();
  };
  const drawLines = (value: string, size: number, indent = 0) => {
    doc.setFontSize(size);
    const lines = doc.splitTextToSize(value, contentWidth - indent) as string[];
    ensureSpace(Math.max(lines.length, 1) * (size * 0.47));
    doc.text(lines, margin + indent, y);
    y += Math.max(lines.length, 1) * (size * 0.47);
  };

  doc.setProperties({
    title: "Client intake submission",
    subject: "Completed client intake submission",
    author: "ProbatePro",
    creator: "ProbatePro",
  });
  doc.setTextColor(27, 54, 91);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.text("Client intake submission", margin, y);
  y += 8;
  doc.setFont("helvetica", "normal");
  doc.setTextColor(81, 92, 110);
  drawLines(
    "Prepared from the client’s submitted portal responses. This record does not apply, verify, or replace estate Intake data.",
    9
  );
  y += 3;
  doc.setDrawColor(204, 213, 225);
  doc.setLineWidth(0.35);
  doc.line(margin, y, pageWidth - margin, y);
  y += 7;

  const submittedBy = input.submittedByName.trim() || "Client";
  doc.setTextColor(51, 65, 85);
  doc.setFont("helvetica", "bold");
  drawLines("Submission record", 11);
  doc.setFont("helvetica", "normal");
  drawLines(`Submitted by: ${submittedBy}`, 9);
  drawLines(`Submission date: ${exportDate(input.submittedAt)}`, 9);
  y += 4;

  for (const section of buildClientIntakeSummarySections(input.payload)) {
    ensureSpace(13);
    doc.setTextColor(27, 54, 91);
    doc.setFont("helvetica", "bold");
    drawLines(section.title, 12);
    y += 1;
    for (const row of section.rows) {
      doc.setTextColor(71, 85, 105);
      doc.setFont("helvetica", "bold");
      drawLines(`${row.label}:`, 8.5);
      doc.setTextColor(30, 41, 59);
      doc.setFont("helvetica", "normal");
      drawLines(row.value, 9, 4);
      y += 1.5;
    }
    y += 3;
  }

  doc.save(filename);
  return filename;
}
