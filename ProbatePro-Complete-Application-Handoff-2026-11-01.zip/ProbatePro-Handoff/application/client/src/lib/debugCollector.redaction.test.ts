/**
 * Development diagnostic redaction: no body, credential or arbitrary free text may be reported.
 * It wraps window.fetch and posts its captured network entries to /__manus__/logs, which the Vite
 * plugin appends to .manus-logs. This drives the REAL client/public/__manus__/debug-collector.js with
 * fictional sentinels and inspects exactly what it would send. No real credential or log is read.
 */
import fs from "node:fs";
import path from "node:path";
import { JSDOM } from "jsdom";
import { afterEach, describe, expect, it, vi } from "vitest";

const SENTINEL_AUTH = "FICTIONAL-SENTINEL-AUTH-7f3a";
const SENTINEL_ROTATED = "FICTIONAL-SENTINEL-ROTATED-9c1e";
// Vitest runs from the repository root (vitest.config.ts root); jsdom's import.meta.url is not a file URL.
const collectorSource = fs.readFileSync(path.resolve(process.cwd(), "client/public/__manus__/debug-collector.js"), "utf8");

const SENTINEL_BODY = "FICTIONAL-COLLECTOR-PRIVATE-TEXT-72b1";
const realms: JSDOM[] = [];
type Report = { consoleLogs: any[]; networkRequests: any[]; uiEvents: any[]; sessionEvents: any[]; _truncated?: boolean };

function responseFixture(text: string | null, mediaType = "application/json", length?: string, status = text === null ? 204 : 206) {
  const headers = new Headers({ "content-type": mediaType, "x-rotated-session": `app_session_id=${SENTINEL_ROTATED}` });
  if (length !== undefined) headers.set("content-length", length);
  const response = new Response(text, { status, statusText: SENTINEL_BODY, headers });
  const read = vi.spyOn(response, "text");
  const cloneText = vi.fn(async () => text ?? "");
  const clone = vi.spyOn(response, "clone").mockReturnValue({ text: cloneText } as unknown as Response);
  return { response, read, cloneText, clone };
}

function collector(options: { response?: Response; networkError?: Error; reportFailures?: number; xhrText?: string; xhrType?: string; xhrLength?: string; xhrReadError?: boolean } = {}) {
  // A fresh realm restores every directly-installed console/fetch/XHR/history wrapper and listener.
  // jsdom loads no external resources here; the only network implementations are these local fakes.
  const dom = new JSDOM("<!doctype html><html><body></body></html>", { url: "https://fictional.invalid/", runScripts: "outside-only" });
  realms.push(dom);
  const page = dom.window as any;
  page.Headers = Headers;
  const reports: string[] = [];
  const beacons: string[] = [];
  const intervals: Array<{ callback: () => Promise<void>; delay: number }> = [];
  page.setInterval = vi.fn((callback: () => Promise<void>, delay: number) => { intervals.push({ callback, delay }); return intervals.length; });
  const originalConsole = Object.fromEntries(["log", "debug", "info", "warn", "error"].map((method) => [method, vi.fn()]));
  for (const method of Object.keys(originalConsole)) page.console[method] = originalConsole[method];
  let failures = options.reportFailures ?? 0;
  const nativeFetch = vi.fn(async (input: any, init?: RequestInit) => {
    if (input === "/__manus__/logs") {
      reports.push(String(init?.body));
      if (failures-- > 0) throw new Error(SENTINEL_BODY);
      return new Response("{}", { status: 200 });
    }
    if (options.networkError) throw options.networkError;
    return options.response ?? new Response(null, { status: 204 });
  });
  page.fetch = nativeFetch;
  const responseTextRead = vi.fn(() => {
    if (options.xhrReadError) throw new Error(SENTINEL_BODY);
    return options.xhrText ?? SENTINEL_BODY;
  });
  class FakeXHR extends page.EventTarget {
    status = 207;
    statusText = SENTINEL_BODY;
    get responseText() { return responseTextRead(); }
    open(..._args: unknown[]) { return "original-open-result"; }
    send(..._args: unknown[]) { return "original-send-result"; }
    getResponseHeader(name: string) {
      if (name.toLowerCase() === "content-type") return options.xhrType ?? "text/plain";
      if (name.toLowerCase() === "content-length") return options.xhrLength ?? null;
      return null;
    }
  }
  const nativeOpen = vi.spyOn(FakeXHR.prototype, "open");
  const nativeSend = vi.spyOn(FakeXHR.prototype, "send");
  page.XMLHttpRequest = FakeXHR;
  const sendBeacon = vi.fn((_url: string, data: string) => { beacons.push(data); return true; });
  Object.defineProperty(page.navigator, "sendBeacon", { configurable: true, value: sendBeacon });
  page.eval(collectorSource); // The unchanged shipped script, not an exported helper or test reimplementation.
  const api = page.__MANUS_DEBUG_COLLECTOR__;
  api.store.consoleLogs.length = 0; // Ignore the collector's own initialization debug message.
  return { page, api, reports, beacons, intervals, nativeFetch, nativeOpen, nativeSend, responseTextRead, originalConsole, sendBeacon };
}

afterEach(() => {
  for (const dom of realms.splice(0)) dom.window.close();
  vi.restoreAllMocks();
});

function expectPrivateTextAbsent(value: unknown) {
  const text = typeof value === "string" ? value : JSON.stringify(value);
  for (const sentinel of [SENTINEL_AUTH, SENTINEL_ROTATED, SENTINEL_BODY]) expect(text).not.toContain(sentinel);
}

async function forceReport(harness: ReturnType<typeof collector>): Promise<Report> {
  // Drain the old clone/text/then/catch/finally microtasks too: red must not depend on their timing.
  for (let turn = 0; turn < 4; turn++) await Promise.resolve();
  await harness.api.forceReport();
  expect(harness.reports).toHaveLength(1);
  expectPrivateTextAbsent(harness.reports[0]);
  return JSON.parse(harness.reports[0]);
}

describe("development collector: real fetch and XHR wrappers", () => {
  it("redacts Authorization and rotated-session values while keeping safe headers and no bodies", async () => {
    const fixture = responseFixture(JSON.stringify({ neutral: SENTINEL_BODY }));
    const h = collector({ response: fixture.response });
    const init = { headers: { Authorization: `Bearer ${SENTINEL_AUTH}`, "Content-Type": "application/json" } };
    const received = await h.page.fetch("/api/trpc/auth.me", init);
    expect(received).toBe(fixture.response);
    expect(h.nativeFetch).toHaveBeenCalledWith("/api/trpc/auth.me", init);
    const report = await forceReport(h);
    const [entry] = report.networkRequests;
    expect(report.networkRequests).toHaveLength(1);
    expect(entry.url).toBe("/api/trpc"); // Closed route family, never an arbitrary RPC/path suffix.
    expect(entry.request.headers).toEqual({ authorization: "[REDACTED]", "content-type": "application/json" });
    expect(entry.response.headers).toEqual({ "content-type": "application/json", "x-rotated-session": "[REDACTED]" });
    expect(entry.request.body).toBeNull();
    expect(entry.response.body).toBe("[REDACTED]");
    expect(fixture.clone).not.toHaveBeenCalled();
    expect(fixture.read).not.toHaveBeenCalled();
    expect(fixture.cloneText).not.toHaveBeenCalled();
  });

  it.each([
    ["JSON", JSON.stringify({ neutral: SENTINEL_BODY }), "application/json", undefined],
    ["urlencoded", `descriptor=${SENTINEL_BODY}`, "application/x-www-form-urlencoded", "1"],
    ["plaintext", SENTINEL_BODY, "text/plain", undefined],
    ["empty supplied body", "", "text/plain", undefined],
    ["HTML", `<html>${SENTINEL_BODY}</html>`, "text/html", "1"],
    ["large without length", SENTINEL_BODY + "x".repeat(11000), "text/plain", undefined],
    ["large with misleading length", SENTINEL_BODY + "x".repeat(11000), "text/plain", "1"],
    ["declared large", SENTINEL_BODY, "text/plain", "999999"],
    ["streaming", SENTINEL_BODY, "text/event-stream", undefined],
    ["binary", SENTINEL_BODY, "application/pdf", undefined],
  ])("does not read %s response bodies or retain request bodies", async (_name, body, mediaType, length) => {
    const fixture = responseFixture(body!, mediaType!, length);
    const h = collector({ response: fixture.response });
    const url = `https://${SENTINEL_AUTH}:${SENTINEL_ROTATED}@fictional.invalid/api/download/form?q=${SENTINEL_BODY}#${SENTINEL_BODY}`;
    const init = { method: "post", headers: { "content-type": mediaType!, Authorization: `Bearer ${SENTINEL_AUTH}` }, body };
    expect(await h.page.fetch(url, init)).toBe(fixture.response);
    expect(h.nativeFetch).toHaveBeenCalledTimes(1);
    expect(h.nativeFetch.mock.calls[0][0]).toBe(url);
    expect(h.nativeFetch.mock.calls[0][1]).toBe(init);
    expect(init.body).toBe(body);
    expect(fixture.response.bodyUsed).toBe(false);
    expect(fixture.clone).not.toHaveBeenCalled();
    expect(fixture.read).not.toHaveBeenCalled();
    expect(fixture.cloneText).not.toHaveBeenCalled();
    expectPrivateTextAbsent(h.api.store);
    const report = await forceReport(h);
    expect(report.networkRequests).toHaveLength(1);
    expect(report.networkRequests[0]).toMatchObject({ type: "fetch", method: "POST", url: "/api/download/form", request: { body: "[REDACTED]" }, response: { status: 206, body: "[REDACTED]", headers: { "content-type": mediaType } }, duration: expect.any(Number), error: null });
    expect(report.networkRequests[0].response).not.toHaveProperty("statusText");
    if (length) expect(report.networkRequests[0].response.headers["content-length"]).toBe(length);
  });

  it("preserves absent arguments, null responses and Request body ownership without consuming a stream", async () => {
    const fixture = responseFixture(null);
    const h = collector({ response: fixture.response });
    expect(await h.page.fetch("/api/download/form")).toBe(fixture.response);
    expect(h.nativeFetch.mock.calls[0]).toEqual(["/api/download/form"]);
    const request = new Request("https://fictional.invalid/api/download/form", { method: "POST", headers: { Authorization: `Bearer ${SENTINEL_AUTH}` }, body: SENTINEL_BODY });
    expect(await h.page.fetch(request)).toBe(fixture.response);
    expect(h.nativeFetch.mock.calls[1]).toEqual([request]);
    expect(request.bodyUsed).toBe(false);
    const report = await forceReport(h);
    expect(report.networkRequests[0]).toMatchObject({ request: { body: null }, response: { status: 204, body: null } });
    expect(report.networkRequests[1]).toMatchObject({ method: "POST", request: { body: "[REDACTED]", headers: { authorization: "[REDACTED]" } }, response: { body: null } });
    expect(fixture.clone).not.toHaveBeenCalled();
  });

  it("preserves a rejected fetch error and emits only a closed error category", async () => {
    const error = new Error(SENTINEL_BODY);
    error.stack = SENTINEL_ROTATED;
    const h = collector({ networkError: error });
    const init = { method: "POST", body: SENTINEL_BODY };
    await expect(h.page.fetch(`/${SENTINEL_BODY}?secret=${SENTINEL_AUTH}`, init)).rejects.toBe(error);
    expect(h.nativeFetch.mock.calls[0][1]).toBe(init);
    expectPrivateTextAbsent(h.api.store);
    const report = await forceReport(h);
    expect(report.networkRequests[0]).toMatchObject({ url: "[unknown-route]", request: { body: "[REDACTED]" }, response: null, duration: expect.any(Number), error: { kind: "network_error" } });
    expect(report.uiEvents[0]).toMatchObject({ kind: "network_error", payload: { kind: "fetch", method: "POST", url: "[unknown-route]" } });
    expect(report.uiEvents).toEqual(report.sessionEvents);
  });

  it("retains HTTP failure status without copying fetch status text into either event stream", async () => {
    const fixture = responseFixture(SENTINEL_BODY, "text/html", undefined, 403);
    const h = collector({ response: fixture.response });
    expect(await h.page.fetch(`/api/download/form?q=${SENTINEL_BODY}`)).toBe(fixture.response);
    expectPrivateTextAbsent(h.api.store);
    const report = await forceReport(h);
    expect(report.networkRequests[0]).toMatchObject({ response: { status: 403, body: "[REDACTED]" } });
    expect(report.uiEvents).toHaveLength(1);
    expect(report.uiEvents[0].payload).toEqual({ kind: "fetch", method: "GET", url: "/api/download/form", status: 403 });
    expect(report.uiEvents).toEqual(report.sessionEvents);
    expect(fixture.clone).not.toHaveBeenCalled();
  });

  it.each([
    ["JSON", JSON.stringify({ neutral: SENTINEL_BODY }), "application/json", false],
    ["urlencoded", `descriptor=${SENTINEL_BODY}`, "application/x-www-form-urlencoded", false],
    ["HTML", `<html>${SENTINEL_BODY}</html>`, "text/html", false],
    ["empty supplied body", "", "text/plain", false],
    ["long text", SENTINEL_BODY + "x".repeat(11000), "text/plain", false],
    ["streaming", SENTINEL_BODY, "text/event-stream", false],
    ["binary", SENTINEL_BODY, "application/pdf", false],
    ["throwing getter", SENTINEL_BODY, "text/plain", true],
  ])("never reads XHR responseText for %s while preserving open/send/load", async (_name, text, mediaType, readError) => {
    const h = collector({ xhrText: String(text), xhrType: String(mediaType), xhrReadError: Boolean(readError), xhrLength: "1" });
    const xhr = new h.page.XMLHttpRequest();
    const url = `/api/download/form?name=${SENTINEL_BODY}#${SENTINEL_BODY}`;
    const onLoad = vi.fn();
    xhr.addEventListener("load", onLoad);
    expect(xhr.open("post", url, true, SENTINEL_AUTH, SENTINEL_ROTATED)).toBe("original-open-result");
    expect(xhr.send(text)).toBe("original-send-result");
    xhr.dispatchEvent(new h.page.Event("load"));
    expect(h.nativeOpen).toHaveBeenCalledWith("post", url, true, SENTINEL_AUTH, SENTINEL_ROTATED);
    expect(h.nativeSend).toHaveBeenCalledWith(text);
    expect(h.nativeOpen.mock.contexts[0]).toBe(xhr);
    expect(h.nativeSend.mock.contexts[0]).toBe(xhr);
    expect(onLoad).toHaveBeenCalledTimes(1);
    expect(h.responseTextRead).not.toHaveBeenCalled();
    expectPrivateTextAbsent(xhr._manusData);
    expectPrivateTextAbsent(h.api.store);
    const report = await forceReport(h);
    expect(report.networkRequests).toHaveLength(1);
    expect(report.networkRequests[0]).toMatchObject({ type: "xhr", method: "POST", url: "/api/download/form", request: { body: "[REDACTED]" }, response: { status: 207, body: "[REDACTED]", headers: { "content-type": mediaType, "content-length": "1" } }, duration: expect.any(Number), error: null });
  });

  it("preserves XHR error listeners, null request bodies, HTTP failure hints and send exceptions", async () => {
    const h = collector();
    const failed = new h.page.XMLHttpRequest();
    const onError = vi.fn();
    failed.addEventListener("error", onError);
    failed.open("GET", "/api/download/form");
    failed.send(null);
    failed.dispatchEvent(new h.page.Event("error"));
    expect(onError).toHaveBeenCalledTimes(1);
    const rejected = new h.page.XMLHttpRequest();
    rejected.open("POST", "/api/download/form");
    rejected.status = 403;
    rejected.send(SENTINEL_BODY);
    rejected.dispatchEvent(new h.page.Event("load"));
    const thrown = new Error(SENTINEL_BODY);
    h.nativeSend.mockImplementationOnce(() => { throw thrown; });
    const broken = new h.page.XMLHttpRequest();
    broken.open("POST", "/api/download/form");
    let receivedError: unknown;
    try { broken.send(SENTINEL_BODY); } catch (error) { receivedError = error; }
    expect(receivedError).toBe(thrown);
    const report = await forceReport(h);
    expect(report.networkRequests).toHaveLength(2);
    expect(report.networkRequests[0]).toMatchObject({ request: { body: null }, response: null, error: { kind: "network_error" } });
    expect(report.networkRequests[1]).toMatchObject({ response: { status: 403, body: "[REDACTED]" } });
    expect(report.uiEvents).toHaveLength(2);
    expect(report.uiEvents[1]).toMatchObject({ kind: "network_error", payload: { kind: "xhr", status: 403 } });
    expect(report.uiEvents).toEqual(report.sessionEvents);
    expect(h.responseTextRead).not.toHaveBeenCalled();
  });

  it("keeps internal diagnostics calls delegated without collecting them", async () => {
    const h = collector();
    const init = { method: "POST", body: "{}" };
    await h.page.fetch("/__manus__/other", init);
    const xhr = new h.page.XMLHttpRequest();
    xhr.open("POST", "/__manus__/other");
    xhr.send("{}");
    xhr.dispatchEvent(new h.page.Event("load"));
    expect(h.nativeFetch).toHaveBeenCalledWith("/__manus__/other", init);
    expect(h.nativeSend).toHaveBeenCalledWith("{}");
    expect(h.api.store.networkRequests).toHaveLength(0);
    await h.api.forceReport();
    expect(h.reports).toHaveLength(0);
  });
});

it("omits console/error/UI text before buffering while preserving console, DOM and history behavior", async () => {
  const h = collector();
  const error = new h.page.Error(SENTINEL_BODY);
  const facts = { neutral: SENTINEL_AUTH };
  h.page.console.log(SENTINEL_BODY, facts, error);
  expect(h.originalConsole.log).toHaveBeenCalledWith(SENTINEL_BODY, facts, error);
  h.page.console.error(error);
  expect(h.originalConsole.error).toHaveBeenCalledWith(error);
  h.page.dispatchEvent(new h.page.ErrorEvent("error", { message: SENTINEL_BODY, filename: SENTINEL_AUTH, error, lineno: 7, colno: 9 }));
  const rejection = new h.page.Event("unhandledrejection");
  Object.defineProperty(rejection, "reason", { value: error });
  h.page.dispatchEvent(rejection);
  const input = h.page.document.createElement("input");
  input.type = "text";
  input.id = input.name = input.value = SENTINEL_BODY;
  input.setAttribute("aria-label", SENTINEL_AUTH);
  h.page.document.body.append(input);
  input.dispatchEvent(new h.page.Event("change", { bubbles: true }));
  input.dispatchEvent(new h.page.Event("focusout", { bubbles: true }));
  input.dispatchEvent(new h.page.KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
  const link = h.page.document.createElement("a");
  link.textContent = SENTINEL_BODY;
  link.href = `https://${SENTINEL_AUTH}:${SENTINEL_ROTATED}@fictional.invalid/${SENTINEL_BODY}`;
  link.addEventListener("click", (event: Event) => event.preventDefault());
  h.page.document.body.append(link);
  link.dispatchEvent(new h.page.MouseEvent("click", { clientX: 10, clientY: 20, bubbles: true, cancelable: true }));
  const state = { neutral: SENTINEL_BODY };
  h.page.history.pushState(state, SENTINEL_BODY, `/estate/${SENTINEL_BODY}?name=${SENTINEL_AUTH}#${SENTINEL_ROTATED}`);
  expect(h.page.history.state).toBe(state);
  expect(h.page.location.pathname).toBe(`/estate/${SENTINEL_BODY}`);
  h.page.history.replaceState(state, SENTINEL_BODY, `/settings?q=${SENTINEL_BODY}`);
  expect(h.page.history.state).toBe(state);
  Object.defineProperty(h.page, "scrollY", { configurable: true, value: 25 });
  h.page.dispatchEvent(new h.page.Event("scroll"));
  expect(h.api.store.uiEvents.filter((entry: any) => entry.kind === "scroll")).toHaveLength(1);
  const count = h.api.store.uiEvents.length;
  input.className = "manus-no-record";
  input.dispatchEvent(new h.page.Event("change", { bubbles: true }));
  expect(h.api.store.uiEvents).toHaveLength(count);
  expect(input.value).toBe(SENTINEL_BODY);
  expect(link.textContent).toBe(SENTINEL_BODY);
  expectPrivateTextAbsent(h.api.store);
  const report = await forceReport(h);
  expect(report.consoleLogs[0]).toMatchObject({ level: "LOG", argumentCount: 3, timestamp: expect.any(Number) });
  expect(report.consoleLogs).toEqual(expect.arrayContaining([expect.objectContaining({ errorKind: "UncaughtError" }), expect.objectContaining({ errorKind: "UnhandledRejection" })]));
  expect(report.uiEvents).toEqual(report.sessionEvents);
  expect(report.uiEvents).toEqual(expect.arrayContaining([
    expect.objectContaining({ kind: "change", payload: { target: { tag: "input", type: "text" } } }),
    expect.objectContaining({ kind: "click", payload: { target: { tag: "a", type: null }, x: 10, y: 20 } }),
    expect.objectContaining({ kind: "keydown", payload: { target: { tag: "input", type: "text" }, key: "Enter" } }),
    expect.objectContaining({ kind: "navigate", url: "/estate/:id", payload: { reason: "pushState" } }),
    expect.objectContaining({ kind: "navigate", url: "/settings", payload: { reason: "replaceState" } }),
    expect.objectContaining({ kind: "error", payload: { lineno: 7, colno: 9 } }),
  ]));
});

function injectUntrustedStore(h: ReturnType<typeof collector>, large = false) {
  // Model an older/direct page sender using page-realm JSON, not mocked projection helpers.
  const copy = (value: unknown) => h.page.JSON.parse(JSON.stringify(value));
  for (let i = 0; i < (large ? 500 : 1); i++) h.api.store.consoleLogs.push(copy({ timestamp: i, level: "INFO", args: [SENTINEL_BODY], stack: SENTINEL_AUTH }));
  for (let i = 0; i < (large ? 200 : 1); i++) h.api.store.networkRequests.push(copy({ timestamp: i, type: "fetch", method: "POST", url: `/api/download/form?q=${SENTINEL_BODY}`, request: { body: { neutral: SENTINEL_BODY }, headers: [["Authorization", SENTINEL_AUTH], ["authorization", SENTINEL_ROTATED], ["Content-Type", "application/json"]] }, response: { status: 200, statusText: SENTINEL_BODY, body: SENTINEL_BODY }, duration: 1, error: null, extra: SENTINEL_BODY }));
  for (let i = 0; i < (large ? 500 : 1); i++) h.api.store.uiEvents.push(copy({ timestamp: i, kind: "change", url: `/settings?name=${SENTINEL_BODY}`, viewport: { width: 1280, height: 720 }, payload: { target: { tag: "input", type: "text", text: SENTINEL_BODY, href: SENTINEL_AUTH }, x: 10, y: 20, value: SENTINEL_BODY } }));
  if (!large) {
    for (const channel of ["consoleLogs", "networkRequests", "uiEvents"]) h.api.store[channel].push(SENTINEL_BODY, null, copy([SENTINEL_BODY]));
  }
}

describe("development collector: every outgoing transport", () => {
  it.each(["forced", "interval", "beacon", "shortened beacon", "retry"])("projects public-store entries again for %s reports", async (transport) => {
    const h = collector({ reportFailures: transport === "retry" ? 1 : 0 });
    injectUntrustedStore(h, transport === "shortened beacon");
    if (transport === "beacon" || transport === "shortened beacon") {
      h.page.dispatchEvent(new h.page.Event("beforeunload"));
      expect(h.beacons).toHaveLength(1);
      expect(h.sendBeacon).toHaveBeenCalledWith("/__manus__/logs", expect.any(String));
    } else if (transport === "interval") {
      expect(h.intervals).toHaveLength(1);
      expect(h.intervals[0].delay).toBe(2000);
      await h.intervals[0].callback();
    } else {
      await h.api.forceReport();
      if (transport === "retry") {
        expectPrivateTextAbsent(h.api.store);
        expect(h.api.store.networkRequests).toHaveLength(1);
        // A later mutation cannot bypass the next transport's projection either.
        h.api.store.networkRequests[0].response.statusText = SENTINEL_BODY;
        await h.api.forceReport();
        expect(h.reports).toHaveLength(2);
        expect(h.api.store.networkRequests).toHaveLength(0);
      }
    }
    const sent = [...h.reports, ...h.beacons];
    expect(sent).toHaveLength(transport === "retry" ? 2 : 1);
    for (const raw of sent) {
      expectPrivateTextAbsent(raw);
      const report = JSON.parse(raw) as Report;
      expect(report.consoleLogs).toHaveLength(transport === "shortened beacon" ? 50 : 1);
      expect(report.networkRequests).toHaveLength(transport === "shortened beacon" ? 20 : 1);
      expect(report.uiEvents).toHaveLength(transport === "shortened beacon" ? 100 : 1);
      expect(report.uiEvents).toEqual(report.sessionEvents);
      expect(report.consoleLogs[0]).toMatchObject({ level: "INFO", argumentCount: 1 });
      expect(report.networkRequests[0]).toMatchObject({ method: "POST", url: "/api/download/form", request: { body: "[REDACTED]", headers: { authorization: "[REDACTED]", "content-type": "application/json" } }, response: { status: 200, body: "[REDACTED]" }, duration: 1 });
      expect(report.uiEvents[0]).toMatchObject({ kind: "change", url: "/settings", viewport: { width: 1280, height: 720 }, payload: { target: { tag: "input", type: "text" }, x: 10, y: 20 } });
      if (transport === "shortened beacon") {
        expect(report._truncated).toBe(true);
        expect(report.consoleLogs[0].timestamp).toBe(450);
        expect(report.networkRequests[0].timestamp).toBe(180);
        expect(report.uiEvents[0].timestamp).toBe(400);
      }
    }
  });
});
