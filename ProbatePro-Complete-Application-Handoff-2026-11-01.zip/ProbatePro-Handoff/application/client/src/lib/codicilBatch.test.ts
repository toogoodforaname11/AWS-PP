import { describe, expect, it } from "vitest";
import { codicilClearIndices } from "./codicilBatch";

describe("codicilClearIndices", () => {
  it("removes entries from last to first so each following server index remains valid", () => {
    expect(codicilClearIndices(4)).toEqual([3, 2, 1, 0]);
  });

  it("does not produce delete operations for an empty or invalid count", () => {
    expect(codicilClearIndices(0)).toEqual([]);
    expect(codicilClearIndices(-2)).toEqual([]);
  });
});
