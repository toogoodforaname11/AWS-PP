import { parseCurrencyToCents } from "./formatters";
import { inventoryEffectiveValueInput, inventoryValueRecordedFromForm } from "./inventoryValue";
import { createXlsxWorkbook } from "./xlsxWorkbook";

export const INVENTORY_SPREADSHEET_HEADERS = [
  "category",
  "description",
  "location",
  "value",
  "passes_to_personal_representative",
  "subcategory",
  "bank_address",
  "account_holder",
  "account_number",
  "accrued_interest",
  "date_of_death_value",
  "pid",
  "legal_description",
  "market_value",
  "registered_owner",
  "ownership_details",
  "security_status",
  "secured_asset_id",
] as const;

export const INVENTORY_SPREADSHEET_EXAMPLE_ROWS = [
  {
    category: "financial",
    description: "TD Chequing",
    location: "in_bc",
    value: 15000,
    passes_to_personal_representative: "yes",
    subcategory: "chequing",
    bank_address: "123 Main St",
    account_holder: "John Smith",
    account_number: "12345678",
    accrued_interest: 50,
    date_of_death_value: 15050,
  },
  {
    category: "real_property",
    description: "123 Oak Ave",
    location: "in_bc",
    value: 850000,
    passes_to_personal_representative: "yes",
    pid: "",
    legal_description: "Lot 1 Plan 12345",
    market_value: 850000,
    registered_owner: "John Smith",
    ownership_details: "John Smith 1/2; Jane Smith 1/2",
  },
] as const;

export function createInventorySpreadsheetTemplate() {
  return createXlsxWorkbook({
    sheetName: "Inventory",
    headers: INVENTORY_SPREADSHEET_HEADERS,
    rows: INVENTORY_SPREADSHEET_EXAMPLE_ROWS,
  });
}

type SpreadsheetCell = string | number | boolean | Date | null | undefined;
type SpreadsheetRow = Record<string, SpreadsheetCell>;
type InventoryCategory = "unknown" | "real_property" | "tangible" | "financial" | "liability";
type InventoryLocation = "unknown" | "in_bc" | "outside_bc";

export interface SpreadsheetInventoryItem {
  category: InventoryCategory;
  description: string;
  location: InventoryLocation;
  value: number;
  /** Preserves a pending or malformed imported value for the review editor. */
  valueInput: string;
  valueRecorded: 0 | 1;
  passesToPersonalRepresentative: "" | "yes" | "no";
  subcategory: string;
  bankAddress: string;
  accountHolder: string;
  accountNumber: string;
  accruedInterest: number;
  dateOfDeathValue: number;
  pid: string;
  legalDescription: string;
  assessedMarketValue: number;
  registeredOwner: string;
  ownershipDetails: string;
  securityStatus: "unknown" | "secured" | "unsecured";
  securedAssetId: string;
}

export type SpreadsheetInventoryField = "category" | "description" | "location" | "value" | "accountNumber";

export interface SpreadsheetInventoryIssue {
  field: SpreadsheetInventoryField;
  message: string;
}

/**
 * Spreadsheet import deliberately permits an unknown appraisal/value and a
 * blank financial identifier: those are honest, later-completable facts. This
 * validator only rejects malformed spreadsheet basics that would otherwise
 * make the imported row hard to identify or sort into an inventory section.
 */
export function validateSpreadsheetInventoryItem(item: SpreadsheetInventoryItem): SpreadsheetInventoryIssue[] {
  const issues: SpreadsheetInventoryIssue[] = [];

  if (item.category === "unknown") {
    issues.push({ field: "category", message: "Choose a valid asset or liability type." });
  }
  if (!item.description.trim()) {
    issues.push({ field: "description", message: "Enter a description." });
  }
  if (item.location === "unknown") {
    issues.push({ field: "location", message: "Choose In BC or Outside BC." });
  }
  const normalizedValue = item.valueInput.trim().replace(/[$,\s]/g, "");
  if (normalizedValue && !/^-?\d+(?:\.\d{1,2})?$/.test(normalizedValue)) {
    issues.push({ field: "value", message: "Enter a non-negative dollar value or leave it blank if pending." });
  }
  if (!Number.isSafeInteger(item.value) || item.value < 0) {
    issues.push({ field: "value", message: "Enter a non-negative dollar value or leave it blank if pending." });
  }

  const accountCharacters = item.accountNumber.replace(/[^A-Za-z0-9]/g, "");
  if (item.accountNumber.trim() && accountCharacters.length < 4) {
    issues.push({ field: "accountNumber", message: "Use at least 4 letters or numbers for an account number." });
  }

  return issues;
}

function normalizedHeader(header: string): string {
  return header
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function cellText(value: SpreadsheetCell): string {
  return value === null || value === undefined ? "" : String(value).trim();
}

function normalizedRow(row: SpreadsheetRow): Record<string, string> {
  return Object.fromEntries(Object.entries(row).map(([header, value]) => [normalizedHeader(header), cellText(value)]));
}

function valueFrom(row: Record<string, string>, ...names: string[]): string {
  for (const name of names) {
    const value = row[normalizedHeader(name)];
    if (value !== undefined && value !== "") return value;
  }
  return "";
}

function parseMoney(value: string): number {
  // Excel can hand us either raw numbers or display values such as "$15,050.00".
  // Keep a minus sign intact so the server's liability guard remains authoritative.
  return parseCurrencyToCents(value.replace(/[$\s,]/g, "") || "0");
}

function isPopulated(row: SpreadsheetRow): boolean {
  return Object.values(row).some((value) => cellText(value) !== "");
}

export function inventorySpreadsheetRowsToItems(rows: SpreadsheetRow[]): SpreadsheetInventoryItem[] {
  return rows
    .filter(isPopulated)
    .map((rawRow) => {
      const row = normalizedRow(rawRow);
      const rawCategory = valueFrom(row, "category").toLowerCase().replace(/[\s-]+/g, "_");
      const category: InventoryCategory = ["real_property", "tangible", "financial", "liability"].includes(rawCategory)
        ? (rawCategory as Exclude<InventoryCategory, "unknown">)
        : "unknown";
      const rawLocation = valueFrom(row, "location").toLowerCase().replace(/[.\s-]+/g, "_");
      const rawValue = valueFrom(row, "value", "amount");
      const rawDateOfDeathValue = valueFrom(row, "date_of_death_value", "dateofdeathvalue", "dod_value");
      const rawAssessedMarketValue = valueFrom(row, "assessed_value", "assessedmarketvalue", "market_value");
      const rawPassage = valueFrom(row, "passes_to_personal_representative", "passestopersonalrepresentative").toLowerCase();
      const rawSecurityStatus = valueFrom(row, "security_status", "securitystatus").toLowerCase();

      return {
        category,
        description: valueFrom(row, "description", "name"),
        location: ["in_bc", "bc", "british_columbia"].includes(rawLocation)
          ? "in_bc"
          : ["outside_bc", "outside", "foreign"].includes(rawLocation)
            ? "outside_bc"
            : "unknown",
        value: parseMoney(rawValue),
        valueInput: category === "financial"
          ? rawDateOfDeathValue || rawValue
          : category === "real_property"
            ? rawAssessedMarketValue || rawValue
            : rawValue,
        valueRecorded: inventoryValueRecordedFromForm({
          category,
          value: rawValue,
          dateOfDeathValue: rawDateOfDeathValue,
          assessedMarketValue: rawAssessedMarketValue,
        }),
        passesToPersonalRepresentative: rawPassage === "yes" || rawPassage === "no" ? rawPassage : "",
        subcategory: valueFrom(row, "subcategory", "type", "account_type"),
        bankAddress: valueFrom(row, "bank_address", "bankaddress"),
        accountHolder: valueFrom(row, "account_holder", "accountholder", "holder"),
        accountNumber: valueFrom(row, "account_number", "accountnumber", "account_no"),
        accruedInterest: parseMoney(valueFrom(row, "accrued_interest", "accruedinterest")),
        dateOfDeathValue: parseMoney(
          String(
            category === "financial"
              ? inventoryEffectiveValueInput({ category, value: rawValue, dateOfDeathValue: rawDateOfDeathValue }) || ""
              : rawDateOfDeathValue,
          ),
        ),
        pid: valueFrom(row, "pid"),
        legalDescription: valueFrom(row, "legal_description", "legaldescription"),
        assessedMarketValue: parseMoney(
          String(
            category === "real_property"
              ? inventoryEffectiveValueInput({ category, value: rawValue, assessedMarketValue: rawAssessedMarketValue }) || ""
              : rawAssessedMarketValue,
          ),
        ),
        registeredOwner: valueFrom(row, "registered_owner", "registeredowner", "owner"),
        ownershipDetails: valueFrom(row, "ownership_details", "ownershipdetails"),
        securityStatus: rawSecurityStatus === "secured" || rawSecurityStatus === "unsecured" ? rawSecurityStatus : "unknown",
        securedAssetId: valueFrom(row, "secured_asset_id", "securedassetid"),
      };
    });
}
