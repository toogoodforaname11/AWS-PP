export type AssistantChimeTone = "harbor" | "ledger" | "beacon";

export const ASSISTANT_CHIME_TONES: Array<{ value: AssistantChimeTone; label: string; description: string }> = [
  { value: "harbor", label: "Harbor", description: "A warm, settled two-note arrival" },
  { value: "ledger", label: "Ledger", description: "A lower, measured filing cue" },
  { value: "beacon", label: "Beacon", description: "A clear, light confirmation" },
];

const TONE_PLAN: Record<AssistantChimeTone, ReadonlyArray<{ frequency: number; offset: number; type: OscillatorType }>> = {
  harbor: [
    { frequency: 523.25, offset: 0, type: "triangle" },
    { frequency: 783.99, offset: 0.105, type: "sine" },
  ],
  ledger: [
    { frequency: 392, offset: 0, type: "sine" },
    { frequency: 587.33, offset: 0.125, type: "triangle" },
  ],
  beacon: [
    { frequency: 659.25, offset: 0, type: "sine" },
    { frequency: 987.77, offset: 0.09, type: "sine" },
  ],
};

export function asAssistantChimeTone(value: unknown): AssistantChimeTone {
  return value === "ledger" || value === "beacon" || value === "harbor" ? value : "harbor";
}

export function clampAssistantChimeVolume(value: unknown): number {
  const numeric = typeof value === "number" ? value : Number(value);
  return Number.isFinite(numeric) ? Math.round(Math.min(100, Math.max(0, numeric))) : 35;
}

export function primeAssistantChime(existing: AudioContext | null): AudioContext | null {
  if (typeof window === "undefined") return null;
  const AudioContextConstructor = window.AudioContext || (window as Window & typeof globalThis & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextConstructor) return null;
  const context = existing ?? new AudioContextConstructor();
  if (context.state === "suspended") void context.resume().catch(() => {});
  return context;
}

export function playAssistantChime(context: AudioContext | null, tone: AssistantChimeTone, volume: number) {
  if (!context || context.state !== "running") return;
  const start = context.currentTime;
  const gain = context.createGain();
  const peak = 0.006 + (clampAssistantChimeVolume(volume) / 100) * 0.042;
  gain.gain.setValueAtTime(0.0001, start);
  gain.gain.exponentialRampToValueAtTime(peak, start + 0.014);
  gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.44);
  gain.connect(context.destination);
  TONE_PLAN[tone].forEach(({ frequency, offset, type }) => {
    const oscillator = context.createOscillator();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, start + offset);
    oscillator.connect(gain);
    oscillator.start(start + offset);
    oscillator.stop(start + 0.46);
  });
}
