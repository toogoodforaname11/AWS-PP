const DEFAULT_TIMEOUT_MS = 10_000;
const DEFAULT_MAX_RETRIES = 2;

type FetchLike = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

type TrpcTransportOptions = {
  fetchImpl?: FetchLike;
  timeoutMs?: number;
  maxRetries?: number;
  retryDelayMs?: (attempt: number) => number;
  onResponse?: (response: Response) => void | Promise<void>;
};

function unavailableResponse(message: string): Response {
  return new Response(JSON.stringify({
    error: {
      json: {
        message,
        code: -32603,
        data: { code: "INTERNAL_SERVER_ERROR", httpStatus: 503 },
      },
    },
  }), {
    status: 503,
    headers: { "content-type": "application/json" },
  });
}

function isAbortError(error: unknown): boolean {
  return error instanceof DOMException
    ? error.name === "AbortError"
    : typeof error === "object" && error !== null && "name" in error && (error as { name?: unknown }).name === "AbortError";
}

// Task 12 (P5): a caller abort ends the backoff at once with the caller's own reason; nothing else changes.
function wait(ms: number, signal?: AbortSignal | null): Promise<void> {
  return new Promise((resolve, reject) => {
    const abortReason = () => signal?.reason ?? new DOMException("The operation was aborted.", "AbortError");
    if (signal?.aborted) { reject(abortReason()); return; }
    const timer = setTimeout(() => { signal?.removeEventListener("abort", onAbort); resolve(); }, ms);
    function onAbort() { clearTimeout(timer); reject(abortReason()); }
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}

/**
 * Ensures that an infrastructure request cannot leave a React Query permanently
 * unresolved. Caller-initiated cancellation remains a cancellation, not an
 * invented server failure, and existing temporary-HTML 5xx retries remain
 * bounded before the user receives a safe retryable response.
 */
export function createTrpcTransportFetch(options: TrpcTransportOptions = {}): FetchLike {
  const fetchImpl = options.fetchImpl ?? globalThis.fetch.bind(globalThis);
  const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  const maxRetries = options.maxRetries ?? DEFAULT_MAX_RETRIES;
  const retryDelayMs = options.retryDelayMs ?? ((attempt: number) => 1_500 * (attempt + 1));
  const onResponse = options.onResponse;

  return async (input, init) => {
    let lastTransportFailure: "timeout" | "unavailable" = "unavailable";

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      const controller = new AbortController();
      let timedOut = false;
      const onCallerAbort = () => controller.abort();
      const callerSignal = init?.signal;
      if (callerSignal?.aborted) controller.abort();
      else callerSignal?.addEventListener("abort", onCallerAbort, { once: true });
      const timeout = setTimeout(() => {
        timedOut = true;
        controller.abort();
      }, timeoutMs);

      try {
        const response = await fetchImpl(input, {
          ...(init ?? {}),
          credentials: "include",
          signal: controller.signal,
        });
        await onResponse?.(response);
        const contentType = response.headers.get("content-type") || "";
        if (!contentType.includes("application/json") && response.status >= 400) {
          lastTransportFailure = "unavailable";
          // Task 12 (P5b): release the discarded non-JSON body; nothing downstream can.
          void response.body?.cancel().catch(() => undefined);
          if (attempt < maxRetries && response.status >= 500) {
            await wait(retryDelayMs(attempt), callerSignal);
            continue;
          }
          return unavailableResponse(`Server returned an error (${response.status}). Please try again.`);
        }
        return response;
      } catch (error) {
        if (callerSignal?.aborted) throw error;
        if (timedOut && isAbortError(error)) lastTransportFailure = "timeout";
        else lastTransportFailure = "unavailable";
        if (attempt < maxRetries) {
          await wait(retryDelayMs(attempt), callerSignal);
          continue;
        }
      } finally {
        clearTimeout(timeout);
        callerSignal?.removeEventListener("abort", onCallerAbort);
      }
    }

    return unavailableResponse(lastTransportFailure === "timeout"
      ? "The server took too long to respond. Please try again."
      : "Server is temporarily unavailable. Please try again in a moment.");
  };
}
