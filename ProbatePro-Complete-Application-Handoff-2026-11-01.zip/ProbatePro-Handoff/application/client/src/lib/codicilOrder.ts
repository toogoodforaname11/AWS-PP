/**
 * Return the existing codicil indexes in their intended new sequence.
 * `null` means the requested move is not a valid persisted reorder.
 */
export function moveCodicilOrder(length: number, fromIndex: number, toIndex: number): number[] | null {
  if (
    !Number.isInteger(length) || length < 1 ||
    !Number.isInteger(fromIndex) || !Number.isInteger(toIndex) ||
    fromIndex < 0 || toIndex < 0 || fromIndex >= length || toIndex >= length ||
    fromIndex === toIndex
  ) {
    return null;
  }

  const order = Array.from({ length }, (_, index) => index);
  const [moved] = order.splice(fromIndex, 1);
  order.splice(toIndex, 0, moved);
  return order;
}
