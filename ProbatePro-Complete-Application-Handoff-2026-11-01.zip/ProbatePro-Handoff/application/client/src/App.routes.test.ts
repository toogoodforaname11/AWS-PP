import { describe, expect, it } from "vitest";
import { isDashboardRoute } from "./App";

describe("application route classification", () => {
  it("keeps known workspace paths in the authenticated dashboard shell", () => {
    expect(isDashboardRoute("/")).toBe(true);
    expect(isDashboardRoute("/estate/file-123")).toBe(true);
    expect(isDashboardRoute("/settings")).toBe(true);
  });

  it("sends unknown and incomplete workspace-like paths to the standalone 404 page", () => {
    expect(isDashboardRoute("/missing-probate-record")).toBe(false);
    expect(isDashboardRoute("/estate")).toBe(false);
    expect(isDashboardRoute("/estate/file-123/extra")).toBe(false);
  });
});
