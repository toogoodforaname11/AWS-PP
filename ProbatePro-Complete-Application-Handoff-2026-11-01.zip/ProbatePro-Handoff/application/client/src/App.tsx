import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import DashboardLayout from "./components/DashboardLayout";
import Home from "./pages/Home";
import EstateDetail from "./pages/EstateDetail";
import Deadlines from "./pages/Deadlines";
import Settings from "./pages/Settings";
import ExecutorPortal from "./pages/ExecutorPortal";
import HowItWorks from "./pages/HowItWorks";
import ReportProblem from "./pages/ReportProblem";
import Administration from "./pages/Administration";
import Portal from "./pages/Portal";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import Goodbye from "./pages/Goodbye";
import { CookieConsent } from "./components/CookieConsent";
import { ScrollToTop } from "./components/ScrollToTop";

export function isDashboardRoute(pathname: string) {
  return pathname === "/" ||
    pathname === "/deadlines" ||
    pathname === "/how-it-works" ||
    pathname === "/executor-portal" ||
    pathname === "/report-a-problem" ||
    pathname === "/administration" ||
    pathname === "/settings" ||
    /^\/estate\/[^/]+$/.test(pathname);
}

function DashboardRoutes() {
  const [location] = useLocation();

  if (!isDashboardRoute(location)) {
    return <NotFound />;
  }

  return (
    <DashboardLayout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/estate/:id" component={EstateDetail} />
        <Route path="/deadlines" component={Deadlines} />
        <Route path="/how-it-works" component={HowItWorks} />
        <Route path="/executor-portal" component={ExecutorPortal} />
        <Route path="/report-a-problem" component={ReportProblem} />
        <Route path="/administration" component={Administration} />
        <Route path="/settings" component={Settings} />
        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/portal" component={Portal} />
      <Route path="/portal/:token" component={Portal} />{/* legacy URL support */}
      <Route path="/terms" component={Terms} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/goodbye" component={Goodbye} />
      <Route path="/404" component={NotFound} />
      <Route component={DashboardRoutes} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <TooltipProvider>
          <Toaster />
          <Router />
          <ScrollToTop />
          <CookieConsent />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
