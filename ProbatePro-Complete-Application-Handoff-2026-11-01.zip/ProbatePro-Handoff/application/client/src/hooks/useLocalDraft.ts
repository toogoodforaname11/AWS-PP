import { useEffect, useRef, useCallback, useState } from "react";

/**
 * useLocalDraft — debounced localStorage auto-save for form data.
 *
 * Saves a JSON snapshot of `data` to localStorage after a debounce delay (default 1s).
 * On mount, checks for an existing draft and exposes it via `pendingDraft`.
 * Call `acceptDraft()` to restore the draft into your form state.
 * Call `dismissDraft()` to discard the draft.
 * Call `clearDraft()` after a successful server save to remove the localStorage entry.
 * Call `flushDraft()` to write NOW, skipping the debounce — required before the
 * component goes away, because unmount cancels the pending debounce timer without
 * writing (edits younger than `debounceMs` would otherwise never reach disk).
 *
 * The debounce ensures typing is never blocked — localStorage writes happen
 * asynchronously after the user pauses.
 */

const DRAFT_PREFIX = "estate_draft_";

interface UseLocalDraftOptions<T> {
  /** Unique key for this form (e.g. `intake_${estateId}`) */
  key: string;
  /** Current form data to persist */
  data: T;
  /** Whether the form has unsaved changes (only persist when dirty) */
  isDirty: boolean;
  /** Debounce delay in ms (default: 1000) */
  debounceMs?: number;
  /** Max age in ms before draft is considered stale and auto-discarded (default: 24h) */
  maxAgeMs?: number;
}

interface DraftEntry<T> {
  data: T;
  savedAt: number;
}

interface UseLocalDraftReturn<T> {
  /** The pending draft data found on mount, or null if none */
  pendingDraft: T | null;
  /** Timestamp when the draft was saved */
  pendingDraftTime: number | null;
  /** Timestamp of the most recent successful local autosave for this form */
  lastSavedAt: number | null;
  /** Accept the pending draft (caller should merge into form state) */
  acceptDraft: () => T | null;
  /** Dismiss the pending draft without applying it */
  dismissDraft: () => void;
  /** Clear the draft from localStorage (call after successful server save) */
  clearDraft: () => void;
  /**
   * Write the current `data` to localStorage immediately, bypassing the debounce.
   * Unconditional — the caller decides whether there is anything worth keeping
   * (see the `isDirty` gates on the beforeunload and unmount-autosave paths).
   */
  flushDraft: () => void;
}

/**
 * Remove a draft by key without holding the hook — for late-resolving callbacks
 * that must clear the draft of the form they SAVED, not the one now on screen.
 */
export function clearLocalDraft(key: string): void {
  try {
    localStorage.removeItem(DRAFT_PREFIX + key);
  } catch {
    // localStorage unavailable — nothing to clear
  }
}

export function useLocalDraft<T>({
  key,
  data,
  isDirty,
  debounceMs = 1000,
  maxAgeMs = 24 * 60 * 60 * 1000,
}: UseLocalDraftOptions<T>): UseLocalDraftReturn<T> {
  const storageKey = DRAFT_PREFIX + key;
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Page-lifecycle events can occur before React has refreshed an effect
  // subscription. Keep the newest committed snapshot and dirty flag in refs so
  // pagehide, visibility changes, and beforeunload always protect the latest
  // in-progress draft rather than the closure from an earlier render.
  const dataRef = useRef(data);
  const dirtyRef = useRef(isDirty);
  dataRef.current = data;
  dirtyRef.current = isDirty;
  const [pendingDraft, setPendingDraft] = useState<T | null>(null);
  const [pendingDraftTime, setPendingDraftTime] = useState<number | null>(null);
  const [lastSavedAt, setLastSavedAt] = useState<number | null>(null);

  // On mount, check for an existing draft
  useEffect(() => {
    setPendingDraft(null);
    setPendingDraftTime(null);
    setLastSavedAt(null);
    try {
      const raw = localStorage.getItem(storageKey);
      if (raw) {
        const entry: DraftEntry<T> = JSON.parse(raw);
        const age = Date.now() - entry.savedAt;
        if (age < maxAgeMs) {
          setPendingDraft(entry.data);
          setPendingDraftTime(entry.savedAt);
          setLastSavedAt(entry.savedAt);
        } else {
          // Stale draft — discard
          localStorage.removeItem(storageKey);
        }
      }
    } catch {
      // Corrupted entry — remove it
      localStorage.removeItem(storageKey);
    }
  }, [storageKey, maxAgeMs]);

  // The single writer reads from the latest ref. This protects a just-edited
  // value even if the browser begins hiding or closing the page before React
  // has replaced an effect callback from the prior render.
  const flushDraft = useCallback(() => {
    try {
      const savedAt = Date.now();
      const entry: DraftEntry<T> = { data: dataRef.current, savedAt };
      localStorage.setItem(storageKey, JSON.stringify(entry));
      setLastSavedAt(savedAt);
    } catch {
      // localStorage full or unavailable — silently fail
    }
  }, [storageKey]);

  // Debounced save to localStorage when dirty
  useEffect(() => {
    if (!isDirty) return;

    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(flushDraft, debounceMs);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [isDirty, debounceMs, flushDraft]);

  // Save synchronously when the browser backgrounded, refreshes, or closes the
  // page. `pagehide` covers browser back-forward cache paths; visibilitychange
  // covers mobile browsers that may suspend a page without beforeunload.
  useEffect(() => {
    const flushIfDirty = () => {
      if (dirtyRef.current) flushDraft();
    };
    const handleVisibilityChange = () => {
      if (document.visibilityState === "hidden") flushIfDirty();
    };
    window.addEventListener("beforeunload", flushIfDirty);
    window.addEventListener("pagehide", flushIfDirty);
    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => {
      window.removeEventListener("beforeunload", flushIfDirty);
      window.removeEventListener("pagehide", flushIfDirty);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [flushDraft]);

  const acceptDraft = useCallback(() => {
    const draft = pendingDraft;
    setPendingDraft(null);
    setPendingDraftTime(null);
    localStorage.removeItem(storageKey);
    return draft;
  }, [pendingDraft, storageKey]);

  const dismissDraft = useCallback(() => {
    setPendingDraft(null);
    setPendingDraftTime(null);
    localStorage.removeItem(storageKey);
  }, [storageKey]);

  const clearDraft = useCallback(() => {
    setPendingDraft(null);
    setPendingDraftTime(null);
    localStorage.removeItem(storageKey);
  }, [storageKey]);

  return { pendingDraft, pendingDraftTime, lastSavedAt, acceptDraft, dismissDraft, clearDraft, flushDraft };
}
