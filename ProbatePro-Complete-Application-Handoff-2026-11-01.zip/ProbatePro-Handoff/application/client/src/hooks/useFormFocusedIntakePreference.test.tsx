import React from "react";
import { render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import {
  FORM_FOCUSED_INTAKE_STORAGE_KEY,
  FORM_FOCUSED_INTAKE_ONBOARDING_STORAGE_KEY,
  hasSeenFormFocusedIntakeOnboarding,
  markFormFocusedIntakeOnboardingSeen,
  storeFormFocusedIntakePreference,
  useFormFocusedIntakePreference,
} from "./useFormFocusedIntakePreference";

function PreferenceProbe({ accountValue }: { accountValue: unknown }) {
  const enabled = useFormFocusedIntakePreference(accountValue);
  return <output data-testid="form-mode-preference">{String(enabled)}</output>;
}

afterEach(() =>
  [FORM_FOCUSED_INTAKE_STORAGE_KEY, FORM_FOCUSED_INTAKE_ONBOARDING_STORAGE_KEY].forEach(
    (key) => window.localStorage.removeItem(key)
  )
);

describe("useFormFocusedIntakePreference", () => {
  it("restores the local preference before account settings are available", () => {
    storeFormFocusedIntakePreference(true);
    render(<PreferenceProbe accountValue={undefined} />);
    expect(screen.getByTestId("form-mode-preference").textContent).toBe("true");
  });

  it("uses the loaded account setting as authoritative and refreshes the local cache", async () => {
    storeFormFocusedIntakePreference(true);
    const { rerender } = render(<PreferenceProbe accountValue={undefined} />);
    expect(screen.getByTestId("form-mode-preference").textContent).toBe("true");

    rerender(<PreferenceProbe accountValue={false} />);
    await waitFor(() =>
      expect(screen.getByTestId("form-mode-preference").textContent).toBe(
        "false"
      )
    );
    expect(window.localStorage.getItem(FORM_FOCUSED_INTAKE_STORAGE_KEY)).toBe(
      "false"
    );
  });

  it("records the introductory guidance as seen only after the first activation", () => {
    expect(hasSeenFormFocusedIntakeOnboarding()).toBe(false);
    markFormFocusedIntakeOnboardingSeen();
    expect(hasSeenFormFocusedIntakeOnboarding()).toBe(true);
  });
});
