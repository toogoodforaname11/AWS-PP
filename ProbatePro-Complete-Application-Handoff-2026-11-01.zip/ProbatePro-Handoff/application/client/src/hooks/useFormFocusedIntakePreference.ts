import { useEffect, useState } from "react";

/**
 * A local, non-sensitive cache lets the workspace apply the selected Intake
 * presentation before the account-settings query completes. The account
 * setting remains authoritative as soon as it is available.
 */
export const FORM_FOCUSED_INTAKE_STORAGE_KEY = "probatepro.form-focused-intake";
export const FORM_FOCUSED_INTAKE_ONBOARDING_STORAGE_KEY =
  "probatepro.form-focused-intake-onboarding-seen";
export const FORM_FOCUSED_INTAKE_ACTIVATED_EVENT =
  "probatepro:form-focused-intake-activated";

function normalizeFormFocusedIntake(value: unknown): boolean | undefined {
  if (value === true || value === 1) return true;
  if (value === false || value === 0) return false;
  return undefined;
}

export function readFormFocusedIntakePreference(): boolean {
  try {
    if (typeof window === "undefined") return false;
    return (
      window.localStorage.getItem(FORM_FOCUSED_INTAKE_STORAGE_KEY) === "true"
    );
  } catch {
    return false;
  }
}

export function storeFormFocusedIntakePreference(enabled: boolean): void {
  try {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(
      FORM_FOCUSED_INTAKE_STORAGE_KEY,
      enabled ? "true" : "false"
    );
  } catch {
    // Local storage can be blocked or full; account settings still persist the choice.
  }
}

export function hasSeenFormFocusedIntakeOnboarding(): boolean {
  try {
    if (typeof window === "undefined") return true;
    return window.localStorage.getItem(FORM_FOCUSED_INTAKE_ONBOARDING_STORAGE_KEY) === "true";
  } catch {
    // If storage is unavailable, avoid reopening an onboarding message on every render.
    return true;
  }
}

export function markFormFocusedIntakeOnboardingSeen(): void {
  try {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(FORM_FOCUSED_INTAKE_ONBOARDING_STORAGE_KEY, "true");
  } catch {
    // A failed local write only affects whether a future browser session can see the tip.
  }
}

/** Notify the always-mounted sidebar after a saved user activation. */
export function announceFormFocusedIntakeActivation(): void {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent(FORM_FOCUSED_INTAKE_ACTIVATED_EVENT));
}

export function useFormFocusedIntakePreference(accountValue: unknown): boolean {
  const accountPreference = normalizeFormFocusedIntake(accountValue);
  const [localPreference, setLocalPreference] = useState(
    readFormFocusedIntakePreference
  );

  useEffect(() => {
    if (accountPreference === undefined) return;
    setLocalPreference(accountPreference);
    storeFormFocusedIntakePreference(accountPreference);
  }, [accountPreference]);

  return accountPreference ?? localPreference;
}
