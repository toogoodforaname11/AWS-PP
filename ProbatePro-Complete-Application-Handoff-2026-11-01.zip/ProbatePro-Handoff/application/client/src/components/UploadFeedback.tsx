import React, { useRef, useState } from "react";
import { AlertTriangle, CheckCircle2, FileImage, FileText, Loader2, Maximize2, X } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

export type UploadFeedbackState = {
  phase: "idle" | "reading" | "uploading" | "complete" | "error";
  progress: number;
  message?: string;
  fileName?: string;
  mimeType?: string;
  localPreviewUrl?: string;
};

export const IDLE_UPLOAD_FEEDBACK: UploadFeedbackState = { phase: "idle", progress: 0 };

export function invalidFileTypeMessage(fileName: string, acceptedTypes: string): string {
  const extension = fileName.includes(".") ? fileName.slice(fileName.lastIndexOf(".")).toUpperCase() : "This file";
  return `${extension} files are not accepted here. Choose ${acceptedTypes}.`;
}

export function fileTooLargeMessage(maxSize: string): string {
  return `This file is too large. Choose a file up to ${maxSize}.`;
}

export function UploadedDocumentVisual({
  fileName,
  mimeType,
  localPreviewUrl,
}: {
  fileName: string;
  mimeType?: string;
  localPreviewUrl?: string;
}) {
  const isImage = Boolean(mimeType?.startsWith("image/"));
  const extension = fileName.includes(".") ? fileName.slice(fileName.lastIndexOf(".") + 1).toUpperCase() : "FILE";
  const [previewOpen, setPreviewOpen] = useState(false);

  if (isImage && localPreviewUrl) {
    return (
      <>
        <button
          type="button"
          onClick={() => setPreviewOpen(true)}
          className="group relative h-10 w-10 shrink-0 overflow-hidden rounded border border-primary/15 bg-background text-primary transition-shadow hover:shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          aria-label={`Enlarge preview of ${fileName}`}
          data-testid="uploaded-document-thumbnail"
        >
          <img src={localPreviewUrl} alt={`Preview of ${fileName}`} className="h-full w-full object-cover" />
          <span className="absolute inset-0 grid place-items-center bg-primary/55 opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100">
            <Maximize2 className="h-4 w-4 text-primary-foreground" aria-hidden="true" />
          </span>
        </button>
        <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
          <DialogContent className="max-w-4xl p-3 sm:p-5" data-testid="uploaded-document-enlarged-preview">
            <DialogHeader>
              <DialogTitle className="truncate pr-8 text-sm">{fileName}</DialogTitle>
              <DialogDescription className="sr-only">Enlarged preview of the newly uploaded document.</DialogDescription>
            </DialogHeader>
            <img src={localPreviewUrl} alt={`Enlarged preview of ${fileName}`} className="mx-auto max-h-[72vh] w-auto max-w-full rounded border bg-muted/20 object-contain" />
          </DialogContent>
        </Dialog>
      </>
    );
  }

  const Icon = isImage ? FileImage : FileText;
  return (
    <div
      className="flex h-10 w-10 shrink-0 flex-col items-center justify-center rounded border border-primary/15 bg-background text-primary"
      role="img"
      aria-label={`${extension} document icon`}
      data-testid="uploaded-document-icon"
    >
      <Icon className="h-4 w-4" />
      <span className="mt-0.5 max-w-9 truncate text-[8px] font-semibold tracking-wide">{extension}</span>
    </div>
  );
}

export function UploadFeedback({
  state,
  className,
  compact = false,
  onRemove,
}: {
  state: UploadFeedbackState;
  className?: string;
  compact?: boolean;
  onRemove?: () => void;
}) {
  if (state.phase === "idle") return null;
  const isError = state.phase === "error";
  const isComplete = state.phase === "complete";
  const isWorking = state.phase === "reading" || state.phase === "uploading";
  const Icon = isError ? AlertTriangle : isComplete ? CheckCircle2 : Loader2;

  return (
    <div
      className={cn(
        "rounded-md border px-2.5 py-2 text-xs transition-[opacity,transform] duration-200 motion-reduce:transition-none",
        isError ? "border-destructive/25 bg-destructive/5 text-destructive" : "border-primary/15 bg-primary/[0.035] text-foreground",
        compact && "px-2 py-1.5 text-[11px]",
        className,
      )}
      role={isError ? "alert" : "status"}
      aria-live={isError ? "assertive" : "polite"}
      data-testid="upload-feedback"
    >
      <div className="flex items-center gap-1.5">
        <Icon className={cn("h-3.5 w-3.5 shrink-0", isWorking && "animate-spin motion-reduce:animate-none", isComplete && "text-primary")} />
        <span className="min-w-0 flex-1 leading-snug">{state.message}</span>
      </div>
      {isComplete && state.fileName && (
        <div className="mt-2 flex min-w-0 items-center gap-2 rounded border border-primary/10 bg-background/50 p-1.5">
          <UploadedDocumentVisual
            fileName={state.fileName}
            mimeType={state.mimeType}
            localPreviewUrl={state.localPreviewUrl}
          />
          <span className="min-w-0 truncate text-[11px] font-medium text-foreground">{state.fileName}</span>
          {onRemove && (
            <button
              type="button"
              className="ml-auto inline-flex h-7 shrink-0 items-center gap-1 rounded px-1.5 text-[10px] font-medium text-destructive transition-colors hover:bg-destructive/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              onClick={onRemove}
              aria-label={`Remove ${state.fileName}`}
              data-testid="uploaded-document-remove"
            >
              <X className="h-3.5 w-3.5" />
              Remove
            </button>
          )}
        </div>
      )}
      {!isError && !isComplete && (
        <Progress
          value={state.progress}
          aria-label={state.message || "File upload progress"}
          className="mt-1.5 h-1 bg-primary/15"
        />
      )}
    </div>
  );
}

/**
 * Adds a visible document drop target around an existing upload control. The
 * child browse button remains the keyboard-accessible fallback, while a drop
 * always enters the exact same validation and upload path as file selection.
 */
export function FileDropZone({
  children,
  onFileDrop,
  onFilesDrop,
  disabled = false,
  className,
  activeClassName,
  label = "Drop a file here to select it",
}: {
  children: React.ReactNode;
  onFileDrop?: (file: File) => void;
  onFilesDrop?: (files: File[]) => void;
  disabled?: boolean;
  className?: string;
  /** Additional visual treatment while a valid file is being dragged over the target. */
  activeClassName?: string;
  label?: string;
}) {
  const [isDragging, setIsDragging] = useState(false);
  const dragDepth = useRef(0);

  const hasFiles = (event: React.DragEvent<HTMLElement>) => Array.from(event.dataTransfer.types).includes("Files");
  const resetDrag = () => {
    dragDepth.current = 0;
    setIsDragging(false);
  };

  return (
    <div
      className={cn(
        "relative rounded-lg transition-[border-color,background-color,box-shadow] duration-150 motion-reduce:transition-none",
        isDragging && !disabled && ["ring-2 ring-primary/20 bg-primary/[0.035]", activeClassName],
        className,
      )}
      data-testid="file-drop-zone"
      onDragEnter={(event) => {
        if (disabled || !hasFiles(event)) return;
        event.preventDefault();
        dragDepth.current += 1;
        setIsDragging(true);
      }}
      onDragOver={(event) => {
        if (disabled || !hasFiles(event)) return;
        event.preventDefault();
        event.dataTransfer.dropEffect = "copy";
      }}
      onDragLeave={(event) => {
        if (disabled || !hasFiles(event)) return;
        dragDepth.current = Math.max(0, dragDepth.current - 1);
        if (dragDepth.current === 0) setIsDragging(false);
      }}
      onDrop={(event) => {
        if (disabled) return;
        event.preventDefault();
        const files = Array.from(event.dataTransfer.files || []);
        resetDrag();
        if (files.length === 0) return;
        if (onFilesDrop) onFilesDrop(files);
        else onFileDrop?.(files[0]);
      }}
    >
      {children}
      {isDragging && !disabled && (
        <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center rounded-lg border border-primary/40 bg-primary/[0.06] px-4 text-center text-sm font-medium text-primary" role="status" aria-live="polite">
          {label}
        </div>
      )}
    </div>
  );
}
