import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { useIsMobile } from "@/hooks/useMobile";
import { shortcutLabel } from "@/lib/labels";
import Landing from "@/pages/Landing";
import { TosGate } from "@/components/TosGate";
import { OnboardingGate } from "@/components/OnboardingGate";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { Briefcase, Clock, Settings, LogOut, PanelLeft, Scale, Sun, Moon, BotOff, CircleAlert, CircleHelp, Shield, ShieldCheck, FileText, Check, Sparkles } from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";
import React, { CSSProperties, useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { DashboardLayoutSkeleton } from './DashboardLayoutSkeleton';
import { ChatbotWidget } from "@/components/chatbot/ChatbotWidget";
import { AssistantConsentToggle } from "@/components/AssistantConsentToggle";
import { Popover, PopoverAnchor, PopoverContent } from "@/components/ui/popover";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Switch } from "@/components/ui/switch";
import {
  announceFormFocusedIntakeActivation,
  FORM_FOCUSED_INTAKE_ACTIVATED_EVENT,
  hasSeenFormFocusedIntakeOnboarding,
  markFormFocusedIntakeOnboardingSeen,
  storeFormFocusedIntakePreference,
  useFormFocusedIntakePreference,
} from "@/hooks/useFormFocusedIntakePreference";
import { toast } from "sonner";

export const menuItems = [
  { icon: Briefcase, label: "Estate Files", path: "/" },
  { icon: Clock, label: "Deadlines", path: "/deadlines" },
  { icon: Shield, label: "Executor Portal", path: "/executor-portal" },
  { icon: CircleHelp, label: "How It Works", path: "/how-it-works" },
  { icon: CircleAlert, label: "Report a Problem", path: "/report-a-problem" },
  { icon: Settings, label: "Settings", path: "/settings" },
];

/** Form-focused mode deliberately removes operational tracking from navigation. */
export function sidebarMenuItemsForMode(formFocusedIntake: boolean) {
  return formFocusedIntake
    ? menuItems.filter((item) => item.path !== "/deadlines")
    : menuItems;
}

/** Motion contract for sidebar items that appear or leave with Form-focused mode. */
export function sidebarNavigationItemMotion(reducedMotion: boolean) {
  return {
    initial: reducedMotion ? false : { opacity: 0, x: -8 },
    animate: { opacity: 1, x: 0 },
    exit: reducedMotion ? { opacity: 0 } : { opacity: 0, x: -8 },
    transition: reducedMotion
      ? { duration: 0.01 }
      : { duration: 0.18, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] },
  };
}

export function canViewAdministratorNavigation(user: { role?: string | null; suspendedAt?: unknown } | null | undefined) {
  return user?.role === "admin" && !user.suspendedAt;
}

export function PendingReportAttentionBadge({ count }: { count: number }) {
  if (count <= 0) return null;
  const label = `${count} pending report${count === 1 ? "" : "s"} requiring attention`;
  return <span aria-label={label} className="ml-auto inline-flex min-w-5 items-center justify-center rounded-full bg-amber-500 px-1.5 py-0.5 text-[10px] font-bold text-amber-950 shadow-sm dark:bg-amber-400">{count}</span>;
}

const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 260;
const MIN_WIDTH = 200;
const MAX_WIDTH = 480;

export function AssistantHiddenIndicator() {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <span
          className="ml-auto inline-flex size-5 shrink-0 items-center justify-center rounded-full border border-amber-500/35 bg-amber-500/10 text-amber-700 dark:text-amber-300"
          aria-label="Assistant is disabled. Enable it from the sidebar control."
          data-testid="chatbot-disabled-nav-indicator"
        >
          <BotOff className="size-3" aria-hidden="true" />
        </span>
      </TooltipTrigger>
      <TooltipContent side="right" sideOffset={8}>Assistant disabled — enable it from the sidebar</TooltipContent>
    </Tooltip>
  );
}

/** Logged-out landing visitors must not trigger staff-only dashboard requests. */
export function shouldFetchDashboardAccountData(user: unknown): boolean {
  return !!user;
}

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
  });
  const { loading, user } = useAuth();
  const accountDataEnabled = shouldFetchDashboardAccountData(user);
  const aiFeaturesQuery = trpc.system.aiFeatures.useQuery(undefined, { enabled: accountDataEnabled });
  const settingsQuery = trpc.settings.get.useQuery(undefined, { enabled: accountDataEnabled });
  const formFocusedIntake = useFormFocusedIntakePreference(settingsQuery.data?.formFocusedIntake);

  useEffect(() => {
    localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString());
  }, [sidebarWidth]);

  if (loading) {
    return <DashboardLayoutSkeleton />
  }

    if (!user) {
    return <Landing />;
  }
  return (
    <TosGate user={user}>
    <OnboardingGate user={user}>
    <SidebarProvider
      style={
        {
          "--sidebar-width": `${sidebarWidth}px`,
        } as CSSProperties
      }
    >
      <DashboardLayoutContent
        setSidebarWidth={setSidebarWidth}
        chatbotHiddenByPreference={settingsQuery.isSuccess && !(typeof settingsQuery.data?.aiProcessorApprovedAt === "number" && settingsQuery.data.aiProcessorApprovedAt > 0 && settingsQuery.data.showChatbot !== false)}
        formFocusedIntake={formFocusedIntake}
      >
        {children}
      </DashboardLayoutContent>
      <ChatbotWidget
        enabled={aiFeaturesQuery.isSuccess ? aiFeaturesQuery.data?.enabled === true : undefined}
        visible={settingsQuery.isSuccess && aiFeaturesQuery.isSuccess && settingsQuery.data?.showChatbot !== false && aiFeaturesQuery.data?.enabled === true}
      />
    </SidebarProvider>
    </OnboardingGate>
    </TosGate>
  );
}
type DashboardLayoutContentProps = {
  children: React.ReactNode;
  setSidebarWidth: (width: number) => void;
  chatbotHiddenByPreference: boolean;
  formFocusedIntake: boolean;
};

function DashboardLayoutContent({
  children,
  setSidebarWidth,
  chatbotHiddenByPreference,
  formFocusedIntake,
}: DashboardLayoutContentProps) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar, setOpenMobile } = useSidebar();
  const isCollapsed = state === "collapsed";
  const { data: deadlines, isError: deadlinesError } = trpc.deadline.list.useQuery(undefined, { refetchInterval: 60000 });
  const urgentDeadlineCount = (deadlines?.events || []).filter((event) =>
    event.kind === "obligation" &&
    (event.status === "due" || event.status === "overdue" ||
      (event.status === "upcoming" && event.daysRemaining !== undefined && event.daysRemaining <= 3))
  ).length;
  const canViewAdministration = canViewAdministratorNavigation(user);
  const adminReportsQuery = trpc.support.listAllReports.useQuery(undefined, { enabled: canViewAdministration, refetchInterval: 15_000, refetchOnWindowFocus: true });
  const pendingReportCount = (adminReportsQuery.data ?? []).filter((report) => report.issueStatus === "pending").length;
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const navigationMenuItems = sidebarMenuItemsForMode(formFocusedIntake);
  const visibleMenuItems = canViewAdministration
    ? [
        ...navigationMenuItems.filter((item) => item.path !== "/settings"),
        { icon: ShieldCheck, label: "Administrator", path: "/administration" },
        ...navigationMenuItems.filter((item) => item.path === "/settings"),
      ]
    : navigationMenuItems;
  const activeMenuItem = visibleMenuItems.find(item => location === item.path || (item.path !== "/" && location.startsWith(item.path)));
  const isMobile = useIsMobile();
  const reducedMotion = useReducedMotion();
  const sidebarNavigationMotion = sidebarNavigationItemMotion(Boolean(reducedMotion));

  useEffect(() => {
    if (isCollapsed) setIsResizing(false);
  }, [isCollapsed]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return;
      const sidebarLeft = sidebarRef.current?.getBoundingClientRect().left ?? 0;
      const newWidth = e.clientX - sidebarLeft;
      if (newWidth >= MIN_WIDTH && newWidth <= MAX_WIDTH) setSidebarWidth(newWidth);
    };
    const handleMouseUp = () => setIsResizing(false);
    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing, setSidebarWidth]);

  // Shared sidebar content rendered in both mobile and desktop branches
  const sidebarContent = (
    <>
      <SidebarHeader className="h-16 shrink-0 justify-center">
        <div className="flex items-center gap-3 px-2 transition-all w-full">
          {!isMobile && (
            <button
              onClick={toggleSidebar}
              className="h-8 w-8 flex items-center justify-center hover:bg-accent rounded-lg transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-ring shrink-0"
              aria-label="Toggle navigation"
            >
              <PanelLeft className="h-4 w-4 text-muted-foreground" />
            </button>
          )}
          {(!isCollapsed || isMobile) ? (
            <div className="flex items-center gap-2 min-w-0">
              <Scale className="h-5 w-5 text-primary shrink-0" />
              <span className="font-semibold tracking-tight truncate text-sm">
                ProbatePro
              </span>
            </div>
          ) : null}
        </div>
      </SidebarHeader>

      <SidebarContent className="gap-0">
        <SidebarMenu className="px-2 py-1" data-testid="sidebar-navigation-list">
          <AnimatePresence initial={false} mode="popLayout">
          {visibleMenuItems.map((item) => {
            const isActive = location === item.path || (item.path !== "/" && location.startsWith(item.path));
            return (
              <motion.li
                key={item.path}
                data-slot="sidebar-menu-item"
                data-sidebar="menu-item"
                className="group/menu-item relative"
                layout="position"
                {...sidebarNavigationMotion}
              >
                  <SidebarMenuButton
                    isActive={isActive}
                    onClick={() => { setLocation(item.path); if (isMobile) setOpenMobile(false); }}
                    tooltip={item.label}
                    className={`h-10 transition-colors font-normal relative ${
                      isActive ? "bg-accent" : "hover:bg-accent/60"
                    }`}
                  >
                    <item.icon className={`h-4 w-4 transition-colors ${isActive ? "text-primary" : ""}`} />
                    <span className={isActive ? "font-medium" : ""}>{item.label}</span>
                    {item.path === "/deadlines" && urgentDeadlineCount > 0 && (
                      <span className="ml-auto inline-flex items-center justify-center h-5 min-w-5 px-1 rounded-full bg-red-500 text-white text-[10px] font-bold">
                        {urgentDeadlineCount}
                      </span>
                    )}
                    {item.path === "/deadlines" && deadlinesError && (
                      <span
                        className="ml-auto inline-flex items-center justify-center h-5 min-w-5 px-1 rounded-full bg-red-500 text-white text-[10px] font-bold"
                        title="Deadline data is unavailable"
                        aria-label="Deadline data is unavailable"
                      >
                        !
                      </span>
                    )}
                    {item.path === "/administration" && <PendingReportAttentionBadge count={pendingReportCount} />}
                    {item.path === "/settings" && chatbotHiddenByPreference && <AssistantHiddenIndicator />}
                    {isActive && (
                      <motion.div
                        className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 bg-primary rounded-r-full"
                        layoutId={isMobile ? "sidebar-indicator-mobile" : "sidebar-indicator"}
                        transition={{ type: "spring", stiffness: 350, damping: 30 }}
                      />
                    )}
                  </SidebarMenuButton>
              </motion.li>
            );
          })}
          </AnimatePresence>
        </SidebarMenu>
      </SidebarContent>

      <SidebarFooter className="shrink-0 p-3">
        {(!isCollapsed || isMobile) && (
          <div className="px-2 pb-2 space-y-2">
            <AssistantConsentToggle />
            <FormFocusedIntakeToggle />
            <ThemeToggle />
            {!isMobile && (
              <p className="text-[10px] text-muted-foreground/50 flex items-center gap-1">
                <kbd className="inline-flex h-4 items-center rounded border border-border/40 bg-muted/50 px-1 font-mono text-[9px]">{shortcutLabel("B")}</kbd>
                <span>Toggle sidebar</span>
              </p>
            )}
          </div>
        )}
        {isCollapsed && !isMobile && <><AssistantConsentToggle compact /><FormFocusedIntakeToggle compact /><ThemeToggleCompact /></>}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-3 rounded-lg px-1 py-1 hover:bg-accent/50 transition-colors w-full text-left group-data-[collapsible=icon]:justify-center focus:outline-none focus-visible:ring-2 focus-visible:ring-ring">
              <Avatar className="h-9 w-9 border shrink-0 shadow-sm">
                <AvatarFallback className="text-xs font-medium bg-primary/5 text-primary">
                  {user?.name?.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className={`flex-1 min-w-0 ${!isMobile ? 'group-data-[collapsible=icon]:hidden' : ''}`}>
                <p className="text-sm font-medium truncate leading-none">
                  {user?.name || "-"}
                </p>
                <p className="text-xs text-muted-foreground truncate mt-1.5">
                  {user?.email || "-"}
                </p>
              </div>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuItem
              onClick={logout}
              className="cursor-pointer text-destructive focus:text-destructive"
            >
              <LogOut className="mr-2 h-4 w-4" />
              <span>Sign out</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </SidebarFooter>
    </>
  );

  return (
    <>
      {/* Desktop navigation stays viewport-pinned, with pages above and account controls below. */}
      {!isMobile && (
        <div className="relative" ref={sidebarRef}>
          <Sidebar collapsible="icon" className="border-r-0" disableTransition={isResizing}>
            {sidebarContent}
          </Sidebar>
          <div
            className={`absolute top-0 right-0 w-1 h-full cursor-col-resize hover:bg-primary/20 transition-colors ${isCollapsed ? "hidden" : ""}`}
            onMouseDown={() => { if (isCollapsed) return; setIsResizing(true); }}
            style={{ zIndex: 50 }}
          />
        </div>
      )}

      {/* Mobile sidebar: rendered as Sheet (portal-based overlay) — no DOM footprint in normal flow */}
      {isMobile && (
        <Sidebar collapsible="offcanvas" className="border-r-0">
          {sidebarContent}
        </Sidebar>
      )}

      <SidebarInset>
        {isMobile && (
          <div className="flex h-14 items-center justify-between px-2 sticky top-0 z-40 liquid-glass-header">
            <div className="flex items-center gap-2">
              <SidebarTrigger className="h-9 w-9 rounded-lg bg-background" />
              <span className="tracking-tight text-foreground">
                {activeMenuItem?.label ?? "ProbatePro"}
              </span>
            </div>
          </div>
        )}
        <motion.main
          className="flex-1 p-4 md:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
        >
          {children}
        </motion.main>
      </SidebarInset>
    </>
  );
}

export function FormFocusedIntakeToggle({ compact = false }: { compact?: boolean }) {
  const { data: settings, isLoading } = trpc.settings.get.useQuery();
  const utils = trpc.useUtils();
  const formFocusedIntake = useFormFocusedIntakePreference(settings?.formFocusedIntake);
  const [onboardingOpen, setOnboardingOpen] = useState(false);
  const showOnboarding = () => {
    if (hasSeenFormFocusedIntakeOnboarding()) return;
    markFormFocusedIntakeOnboardingSeen();
    setOnboardingOpen(true);
  };
  useEffect(() => {
    window.addEventListener(FORM_FOCUSED_INTAKE_ACTIVATED_EVENT, showOnboarding);
    return () => window.removeEventListener(FORM_FOCUSED_INTAKE_ACTIVATED_EVENT, showOnboarding);
  });
  const mutation = trpc.settings.update.useMutation({
    onSuccess: (_data, variables) => {
      if (typeof variables.formFocusedIntake === "boolean") {
        storeFormFocusedIntakePreference(variables.formFocusedIntake);
        if (variables.formFocusedIntake) announceFormFocusedIntakeActivation();
      }
      utils.settings.get.setData(undefined, (current) => current
        ? { ...current, formFocusedIntake: variables.formFocusedIntake ?? current.formFocusedIntake }
        : current);
      void utils.settings.get.invalidate();
      toast.success(variables.formFocusedIntake ? "Form-focused intake enabled" : "Full Intake restored");
    },
    onError: (error) => toast.error(error.message || "Unable to update Intake view"),
  });

  const control = (
    <Switch
      id={compact ? "sidebar-form-focused-intake-compact" : "sidebar-form-focused-intake"}
      checked={formFocusedIntake}
      disabled={isLoading || mutation.isPending}
      onCheckedChange={(next) => mutation.mutate({ formFocusedIntake: next })}
      aria-label="Use form-focused intake"
      data-testid="sidebar-form-focused-intake-toggle"
      className="sidebar-preference-switch"
    />
  );

  const controlContent = compact ? (
    <div>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-accent/50">
            {control}
          </div>
        </TooltipTrigger>
        <TooltipContent side="right" sideOffset={8}>
          {formFocusedIntake ? "Form-focused intake on" : "Use form-focused intake"}
        </TooltipContent>
      </Tooltip>
    </div>
  ) : (
    <div className={`sidebar-preference-control flex items-center justify-between gap-3 rounded-lg px-1 py-0.5 ${formFocusedIntake ? "bg-primary/5" : ""}`} data-enabled={formFocusedIntake ? "true" : "false"} data-testid="sidebar-form-focused-intake-control">
      <div className="flex min-w-0 items-center gap-2">
        <FileText className="h-3.5 w-3.5 shrink-0 text-primary" aria-hidden="true" />
        <div className="min-w-0">
          <label htmlFor="sidebar-form-focused-intake" className="cursor-pointer text-[11px] font-medium">Form-focused intake</label>
          <p className="mt-0.5 text-[10px] leading-tight text-muted-foreground">{formFocusedIntake ? "Document fields only" : "Full Intake"}</p>
        </div>
      </div>
      {control}
    </div>
  );

  return (
    <Popover open={onboardingOpen} onOpenChange={setOnboardingOpen}>
      <PopoverAnchor asChild>{controlContent}</PopoverAnchor>
      <PopoverContent side="right" align="end" className="z-[110] w-72 border-primary/20 p-3 shadow-xl" aria-label="Form-focused intake introduction" data-testid="form-focused-intake-onboarding">
        <div className="flex gap-2.5">
          <span className="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary"><Sparkles className="size-3.5" aria-hidden="true" /></span>
          <div className="min-w-0">
            <p className="text-xs font-semibold">A cleaner preparation view</p>
            <p className="mt-1 text-[11px] leading-snug text-muted-foreground">Form-focused intake keeps the fields that populate your documents in view while hiding curated case-management tracking.</p>
            <p className="mt-1.5 text-[11px] leading-snug text-muted-foreground">On the Forms tab, every supported form now appears together in catalog order. Required badges, completion prompts, and generation rules stay the same.</p>
            <button type="button" className="mt-2 inline-flex h-7 items-center rounded-md px-1.5 text-[11px] font-medium transition-colors hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" onClick={() => setOnboardingOpen(false)}>Got it <Check className="ml-1 size-3" aria-hidden="true" /></button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}

/* ─── Theme Toggle (expanded sidebar) ─────────────────────────────── */
function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  return (
    <button
      onClick={toggleTheme}
      className="flex items-center gap-2 w-full px-1 py-1.5 rounded-md text-[11px] text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-all group"
      aria-label="Toggle dark mode"
    >
      <div className="relative h-5 w-9 rounded-full bg-muted border border-border/50 transition-colors group-hover:border-primary/30">
        <motion.div
          className="absolute top-0.5 h-4 w-4 rounded-full bg-background shadow-sm border border-border/50 flex items-center justify-center"
          animate={{ x: theme === "dark" ? 16 : 2 }}
          transition={{ type: "spring", stiffness: 400, damping: 25 }}
        >
          {theme === "dark" ? (
            <Moon className="h-2.5 w-2.5 text-primary" />
          ) : (
            <Sun className="h-2.5 w-2.5 text-amber-500" />
          )}
        </motion.div>
      </div>
      <span>{theme === "dark" ? "Dark" : "Light"} mode</span>
    </button>
  );
}

/* ─── Theme Toggle (collapsed sidebar — icon only) ────────────────── */
function ThemeToggleCompact() {
  const { theme, toggleTheme } = useTheme();
  return (
    <button
      onClick={toggleTheme}
      className="flex items-center justify-center h-8 w-8 mx-auto rounded-lg hover:bg-accent/50 transition-colors mb-1"
      aria-label="Toggle dark mode"
    >
      {theme === "dark" ? (
        <Moon className="h-4 w-4 text-primary" />
      ) : (
        <Sun className="h-4 w-4 text-amber-500" />
      )}
    </button>
  );
}
