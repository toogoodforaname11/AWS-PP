import React, { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Scale, Shield, FileText, LoaderCircle } from "lucide-react";
import { toast } from "sonner";

interface TosGateProps {
  children: React.ReactNode;
  user: { tosAcceptedAt?: number | null } | null;
}

/**
 * Wraps the dashboard content. If the user hasn't accepted the TOS,
 * shows a full-screen interstitial requiring acceptance before proceeding.
 */
export function TosGate({ children, user }: TosGateProps) {
  const [agreed, setAgreed] = useState(false);
  const utils = trpc.useUtils();

  const acceptMutation = trpc.auth.acceptTos.useMutation({
    onSuccess: () => {
      utils.auth.me.invalidate();
      toast.success("Welcome to ProbatePro!");
    },
    onError: (err) => toast.error(err.message || "Failed to accept terms"),
  });

  // If user has already accepted, render children directly.
  if (user?.tosAcceptedAt) {
    return <>{children}</>;
  }

  return (
    <main className="tos-gate-screen flex min-h-screen items-center justify-center p-4 sm:p-6" data-testid="tos-gate-screen">
      <section className="tos-gate-content w-full max-w-lg" aria-labelledby="tos-gate-title">
        <header className="mb-7 text-center sm:mb-8">
          <div className="tos-gate-brand-mark mx-auto mb-4" aria-hidden="true">
            <Scale className="size-6" strokeWidth={2.15} />
          </div>
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.15em] text-primary/75">Account access</p>
          <h1 id="tos-gate-title" className="text-balance text-2xl font-semibold tracking-[-0.03em] text-foreground sm:text-[1.7rem]">
            Welcome to ProbatePro
          </h1>
          <p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-muted-foreground">
            Review the terms that govern this workspace, then confirm your agreement to continue.
          </p>
        </header>

        <div className="tos-gate-surface rounded-2xl border bg-card p-4 sm:p-6">
          <div className="space-y-2.5" aria-label="Terms and privacy documents">
            <a
              href="/terms"
              target="_blank"
              rel="noopener noreferrer"
              className="tos-gate-document-link group flex min-h-20 items-center gap-3 rounded-xl border px-3.5 py-3.5 sm:px-4"
            >
              <span className="tos-gate-document-icon grid size-9 shrink-0 place-items-center rounded-lg" aria-hidden="true">
                <FileText className="size-4" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-foreground">Terms of Service</span>
                <span className="mt-0.5 block text-xs leading-5 text-muted-foreground">Usage terms and account responsibilities</span>
              </span>
              <span className="shrink-0 text-xs font-semibold text-primary/80 transition-colors group-hover:text-primary group-focus-visible:text-primary">
                Review<span className="sr-only"> Terms of Service in a new tab</span>
              </span>
            </a>
            <a
              href="/privacy"
              target="_blank"
              rel="noopener noreferrer"
              className="tos-gate-document-link group flex min-h-20 items-center gap-3 rounded-xl border px-3.5 py-3.5 sm:px-4"
            >
              <span className="tos-gate-document-icon grid size-9 shrink-0 place-items-center rounded-lg" aria-hidden="true">
                <Shield className="size-4" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-foreground">Privacy Policy</span>
                <span className="mt-0.5 block text-xs leading-5 text-muted-foreground">How ProbatePro handles account and file information</span>
              </span>
              <span className="shrink-0 text-xs font-semibold text-primary/80 transition-colors group-hover:text-primary group-focus-visible:text-primary">
                Review<span className="sr-only"> Privacy Policy in a new tab</span>
              </span>
            </a>
          </div>

          <div className="my-5 h-px bg-border/75" aria-hidden="true" />

          <div className="tos-gate-consent flex items-start gap-3 rounded-xl px-3 py-3 transition-colors">
            <Checkbox
              checked={agreed}
              onCheckedChange={(checked) => setAgreed(checked === true)}
              className="mt-0.5 size-6 shrink-0 rounded-md"
              aria-describedby="tos-gate-consent-copy"
            />
            <span id="tos-gate-consent-copy" className="min-w-0 text-sm leading-6 text-muted-foreground">
              I have read and agree to the{" "}
              <a href="/terms" target="_blank" rel="noopener noreferrer" className="font-medium text-foreground underline decoration-border underline-offset-4 transition-colors hover:decoration-primary focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/35">
                Terms of Service
              </a>{" "}
              and{" "}
              <a href="/privacy" target="_blank" rel="noopener noreferrer" className="font-medium text-foreground underline decoration-border underline-offset-4 transition-colors hover:decoration-primary focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/35">
                Privacy Policy
              </a>
              .
            </span>
          </div>

          <Button
            className="probate-primary-action tos-gate-continue mt-5 w-full"
            size="lg"
            disabled={!agreed || acceptMutation.isPending}
            aria-busy={acceptMutation.isPending}
            onClick={() => acceptMutation.mutate()}
          >
            {acceptMutation.isPending ? <><LoaderCircle className="size-4 animate-spin motion-reduce:animate-none" aria-hidden="true" /> Confirming agreement…</> : "Continue to ProbatePro"}
          </Button>
        </div>

        <p className="mt-4 text-center text-xs text-muted-foreground/65">
          &copy; {new Date().getFullYear()} Kairo. All rights reserved.
        </p>
      </section>
    </main>
  );
}
