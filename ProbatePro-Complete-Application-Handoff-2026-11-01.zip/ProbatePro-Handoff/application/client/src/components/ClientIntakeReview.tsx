import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { exportCompletedClientIntakePdf } from "@/lib/clientIntakePdf";
import {
  CLIENT_INTAKE_APPLY_FIELDS,
  clientIntakeEstateFieldForApplyField,
  CLIENT_INTAKE_REVISION_FIELD_LABELS,
  type ClientIntakeApplyField,
  CLIENT_INTAKE_REVISION_FIELDS,
  formatClientIntakeReviewValue,
  clientIntakeReviewFields,
  type ClientIntakePayload,
  type ClientIntakeRevisionField,
  type ClientIntakeSelection,
} from "@shared/clientIntake";
import {
  CheckCircle2,
  ChevronDown,
  ClipboardCheck,
  Download,
  Loader2,
  MessageSquareMore,
  Undo2,
} from "lucide-react";
import React, { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

type Submission = {
  id: string;
  status: string;
  payload: ClientIntakePayload;
  reviewNotes: string;
  revisionRequest: string;
  revisionFieldComments: Array<{
    field: ClientIntakeRevisionField;
    comment: string;
  }>;
  submittedByName: string;
  submittedByEmail: string;
  submittedAt: number;
  approvedFields: ClientIntakeSelection[];
  undoAvailable: boolean;
};

type CurrentEstate = object | null | undefined;

function currentScalarValue(
  field: ClientIntakeSelection,
  currentEstate: CurrentEstate
) {
  if (
    !(CLIENT_INTAKE_APPLY_FIELDS as readonly string[]).includes(field) ||
    !currentEstate
  )
    return null;
  const estateField = clientIntakeEstateFieldForApplyField(
    field as ClientIntakeApplyField
  );
  const value = (currentEstate as Record<string, unknown>)[estateField];
  if (value === null || value === undefined || value === "")
    return "No current value recorded";
  return formatClientIntakeReviewValue(field, String(value));
}

function reviewOnlyMetadata(payload: ClientIntakePayload) {
  const reportedAges = [...payload.executors, ...payload.familyMembers]
    .filter(person => person.name && person.age)
    .map(person => `${person.name}: ${person.age}`);
  const entries = [
    payload.familyMembers.length > 0 && {
      label: "Reported family categories",
      value: payload.familyMembers
        .filter(person => person.name)
        .map(person => `${person.name}: ${person.category.replace(/_/g, " ")}`)
        .join("; "),
    },
    payload.clientDateOfBirth && {
      label: "Client date of birth",
      value: payload.clientDateOfBirth,
    },
    reportedAges.length > 0 && {
      label: "Reported ages",
      value: reportedAges.join("; "),
    },
    payload.documentsAvailable.length > 0 && {
      label: "Documents reported",
      value: payload.documentsAvailable
        .map(document => formatClientIntakeReviewValue("documentsAvailable", document))
        .join(", "),
    },
    payload.clientNotes && {
      label: "Client notes",
      value: payload.clientNotes,
    },
    ...payload.customQuestions
      .filter(question => question.answer.trim())
      .map(question => ({
        label: `Case-specific response · ${question.prompt}`,
        value: question.answer,
      })),
  ].filter(Boolean) as Array<{ label: string; value: string }>;
  return entries;
}

function dependencyFor(
  field: ClientIntakeSelection
): ClientIntakeSelection | null {
  const person =
    /^(client|executors\.\d+|familyMembers\.\d+)\.(?!name$)[^.]+$/.exec(field);
  if (person) return `${person[1]}.name` as ClientIntakeSelection;
  const item = /^(estateItems\.\d+)\.(?!description$)[^.]+$/.exec(field);
  if (item) return `${item[1]}.description` as ClientIntakeSelection;
  return null;
}

function dependencyMessage(field: ClientIntakeSelection) {
  return field.startsWith("estateItems.")
    ? "Apply item description first"
    : "Apply full name first";
}

function submissionStatusLabel(status: string) {
  if (status === "submitted") return "Ready for review";
  if (status === "approved") return "Applied";
  if (status === "revision_requested") return "Revision requested";
  return status.replace(/_/g, " ");
}

export function ClientIntakeReview({
  estateId,
  revision,
  hasUnsavedChanges = false,
  currentEstate,
}: {
  estateId: string;
  revision: number;
  hasUnsavedChanges?: boolean;
  currentEstate?: CurrentEstate;
}) {
  // Legacy Estate Detail unit harnesses intentionally mock only the procedures
  // exercised by their scenario. The real application always includes this
  // router; returning no optional panel keeps those focused screens isolated.
  if (
    !(trpc as any).clientIntake?.listForEstate ||
    !(trpc as any).clientIntake?.approve ||
    !(trpc as any).clientIntake?.undoLastApplication ||
    !(trpc as any).clientIntake?.requestRevision
  )
    return null;
  const utils = trpc.useUtils();
  const {
    data: submissions,
    isLoading,
    error: loadError,
  } = trpc.clientIntake.listForEstate.useQuery({ estateId });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selectedFields, setSelectedFields] = useState<ClientIntakeSelection[]>(
    []
  );
  const [reviewNotes, setReviewNotes] = useState("");
  const [revisionRequest, setRevisionRequest] = useState("");
  const [revisionFieldComments, setRevisionFieldComments] = useState<
    Partial<Record<ClientIntakeRevisionField, string>>
  >({});
  const [applyError, setApplyError] = useState("");
  const [confirmedRevision, setConfirmedRevision] = useState(revision);
  const orderedSubmissions = useMemo(
    () =>
      [...((submissions as Submission[] | undefined) || [])].sort(
        (left, right) => right.submittedAt - left.submittedAt
      ),
    [submissions]
  );
  const active = useMemo(
    () =>
      orderedSubmissions.find(
        submission => submission.id === selectedId
      ) || null,
    [orderedSubmissions, selectedId]
  );

  useEffect(() => {
    setConfirmedRevision(revision);
  }, [revision]);

  useEffect(() => {
    if (
      !selectedId ||
      !orderedSubmissions.some(
        submission => submission.id === selectedId
      )
    ) {
      setSelectedId(orderedSubmissions[0]?.id || null);
      setSelectedFields([]);
      setReviewNotes("");
      setRevisionRequest("");
      setRevisionFieldComments({});
      setApplyError("");
    }
  }, [orderedSubmissions, selectedId]);

  const approve = trpc.clientIntake.approve.useMutation({
    onSuccess: result => {
      if (Number.isInteger(result.revision) && result.revision >= 0) {
        setConfirmedRevision(current => Math.max(current, result.revision));
      }
      toast.success("Verified client details were applied to this estate.");
      setSelectedFields([]);
      setApplyError("");
      void utils.clientIntake.listForEstate.invalidate({ estateId });
      void utils.estate.get.invalidate({ id: estateId });
      void utils.estate.list.invalidate();
      void utils.contact?.list.invalidate({ estateId });
      void utils.inventory?.list.invalidate({ estateId });
      void utils.readiness.check.invalidate({ estateId });
    },
    onError: error => {
      const message =
        error.message ||
        "The selected facts could not be applied. Refresh and try again.";
      setApplyError(message);
      toast.error(message);
      if (/revision|conflict|refresh/i.test(message))
        void utils.clientIntake.listForEstate.invalidate({ estateId });
    },
  });
  const requestRevision = trpc.clientIntake.requestRevision.useMutation({
    onSuccess: () => {
      toast.success("Revision request sent to the client portal.");
      setSelectedId(null);
      setRevisionRequest("");
      void utils.clientIntake.listForEstate.invalidate({ estateId });
    },
    onError: error =>
      toast.error(
        error.message ||
          "The revision request could not be sent. Please try again."
      ),
  });
  const undoLastApplication = trpc.clientIntake.undoLastApplication.useMutation({
    onSuccess: result => {
      if (Number.isInteger(result.revision) && result.revision >= 0) {
        setConfirmedRevision(current => Math.max(current, result.revision));
      }
      toast.success("Client facts restored", {
        description:
          "The most recent verified client details are back in review.",
        duration: 5000,
        icon: <Undo2 className="h-4 w-4" aria-hidden="true" />,
      });
      setSelectedFields([]);
      setApplyError("");
      void utils.clientIntake.listForEstate.invalidate({ estateId });
      void utils.estate.get.invalidate({ id: estateId });
      void utils.estate.list.invalidate();
      void utils.contact?.list.invalidate({ estateId });
      void utils.inventory?.list.invalidate({ estateId });
      void utils.readiness.check.invalidate({ estateId });
    },
    onError: error => {
      const message =
        error.message ||
        "The client-intake application could not be undone. Refresh and try again.";
      setApplyError(message);
      toast.error(message);
      if (/revision|conflict|refresh|changed/i.test(message))
        void utils.clientIntake.listForEstate.invalidate({ estateId });
    },
  });

  if (isLoading)
    return (
      <Card>
        <CardContent className="flex items-center gap-2 py-6 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" />
          Loading client submissions…
        </CardContent>
      </Card>
    );
  if (loadError)
    return (
      <Card>
        <CardContent className="py-6 text-sm text-destructive" role="alert">
          Client submissions could not be loaded. Refresh this tab to try again.
        </CardContent>
      </Card>
    );
  if (!orderedSubmissions.length)
    return (
      <Card className="border-dashed">
        <CardContent className="flex items-center gap-3 py-6 text-sm text-muted-foreground">
          <ClipboardCheck className="h-4 w-4" />
          <span>
            <span className="font-medium text-foreground">
              No client submissions
            </span>
            <br />
            New client-portal submissions will appear here for lawyer review.
          </span>
        </CardContent>
      </Card>
    );

  const choose = (submission: Submission) => {
    setSelectedId(submission.id);
    setSelectedFields([]);
    setReviewNotes("");
    setRevisionRequest("");
    setRevisionFieldComments({});
    setApplyError("");
  };
  const toggle = (field: ClientIntakeSelection, checked: boolean) =>
    setSelectedFields(current => {
      if (checked) return Array.from(new Set([...current, field]));
      return current.filter(
        item => item !== field && dependencyFor(item) !== field
      );
    });
  const apply = (fields: ClientIntakeSelection[]) => {
    if (!active || fields.length === 0) return;
    setApplyError("");
    approve.mutate({
      estateId,
      submissionId: active.id,
      expectedRevision: confirmedRevision,
      approvedFields: fields,
      reviewNotes,
    });
  };
  const undo = () => {
    if (!active || !active.undoAvailable) return;
    setApplyError("");
    undoLastApplication.mutate({
      estateId,
      submissionId: active.id,
      expectedRevision: confirmedRevision,
    });
  };
  const downloadClientIntakePdf = () => {
    if (!active) return;
    try {
      const filename = exportCompletedClientIntakePdf({
        payload: active.payload,
        submittedByName: active.submittedByName,
        submittedAt: active.submittedAt,
      });
      toast.success("Client intake PDF downloaded", {
        description: `Saved ${filename}.`,
        duration: 5000,
      });
    } catch {
      toast.error("The client intake PDF could not be prepared. Please try again.");
    }
  };

  return (
    <Card className="@container overflow-hidden border-primary/20 shadow-sm">
      <CardHeader className="gap-4 border-b border-primary/10 bg-primary/[0.025] pb-5">
        <div className="flex items-start gap-3">
          <div className="rounded-xl border border-primary/10 bg-background p-2.5 text-primary shadow-sm">
            <ClipboardCheck className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <CardTitle className="text-base">Client intake review</CardTitle>
            <CardDescription className="mt-1 max-w-2xl leading-5">
              Compare the client report with the current Intake, then apply
              only the details you have verified.
            </CardDescription>
          </div>
        </div>
        <div
          className="flex flex-wrap gap-2"
          aria-label="Client intake submissions"
        >
          {orderedSubmissions.map(submission => (
            <Button
              key={submission.id}
              type="button"
              size="sm"
              variant={active?.id === submission.id ? "default" : "outline"}
              onClick={() => choose(submission)}
              className="min-h-9 max-w-full justify-start"
            >
              <span className="truncate">
                {submission.submittedByName ||
                  submission.submittedByEmail ||
                  "Client"}
              </span>
              <Badge
                variant="secondary"
                className="ml-1.5 border border-current/10 bg-background/70 text-[10px] text-foreground"
              >
                {submissionStatusLabel(submission.status)}
              </Badge>
            </Button>
          ))}
        </div>
        {active && (
          <Button
            type="button"
            size="sm"
            variant="outline"
            aria-label="Download client intake PDF"
            onClick={downloadClientIntakePdf}
            className="w-full sm:w-auto"
          >
            <Download className="mr-2 h-4 w-4" aria-hidden="true" />
            Download PDF
          </Button>
        )}
      </CardHeader>
      {active && (
        <CardContent className="space-y-5">
          {active.status !== "submitted" && (
            <div className="space-y-4">
              <dl className="divide-y rounded-lg border">
                {clientIntakeReviewFields(active.payload).map(field => (
                  <div
                    key={field.key}
                    className="grid gap-1 p-3 @lg:grid-cols-2"
                  >
                    <dt className="text-xs font-medium text-muted-foreground">
                      {field.label}
                    </dt>
                    <dd className="break-words text-sm">{field.value}</dd>
                  </div>
                ))}
              </dl>
              {reviewOnlyMetadata(active.payload).map(entry => (
                <p
                  key={entry.label}
                  className="text-sm whitespace-pre-wrap break-words"
                >
                  <span className="font-medium">{entry.label}: </span>
                  {entry.value}
                </p>
              ))}
            </div>
          )}
          {active.status === "approved" ? (
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg bg-emerald-500/10 px-3 py-3 text-sm text-emerald-800 dark:text-emerald-300">
              <span className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4" />
                This submission was already approved and preserved as a review
                record.
              </span>
              {active.undoAvailable && (
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  aria-label="Undo last applied client facts"
                  onClick={undo}
                  disabled={undoLastApplication.isPending || hasUnsavedChanges}
                  className="border-emerald-700/20 bg-background/70 text-emerald-900 hover:bg-background dark:text-emerald-200"
                >
                  {undoLastApplication.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Undoing…
                    </>
                  ) : (
                    <>
                      <Undo2 className="mr-2 h-4 w-4" />
                      Undo last apply
                    </>
                  )}
                </Button>
              )}
            </div>
          ) : active.status === "revision_requested" ? (
            <div className="space-y-2 rounded-lg border border-amber-500/25 bg-amber-500/10 px-3 py-3 text-sm text-amber-900 dark:text-amber-200">
              <div className="flex items-center gap-2 font-medium">
                <MessageSquareMore className="h-4 w-4" />
                Revision request sent to the client portal
              </div>
              <p className="whitespace-pre-wrap text-sm">
                {active.revisionRequest ||
                  "The client was asked to review and resubmit their details."}
              </p>
            </div>
          ) : (
            <>
              {(() => {
                const fields = clientIntakeReviewFields(active.payload);
                const applied = new Set(active.approvedFields);
                const unapplied = fields.filter(
                  field => !applied.has(field.key)
                );
                const metadata = reviewOnlyMetadata(active.payload);
                return (
                  <>
                    <div className="grid gap-4 rounded-xl border border-primary/15 bg-primary/[0.025] p-4 @xl:grid-cols-[minmax(0,1fr)_auto] @xl:items-center">
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <Badge className="border-0 bg-primary/10 text-primary hover:bg-primary/10">
                            Ready for review
                          </Badge>
                          <span
                            role="status"
                            aria-live="polite"
                            className="text-xs font-medium tabular-nums text-muted-foreground"
                          >
                            {selectedFields.length} {selectedFields.length === 1 ? "fact" : "facts"} selected
                          </span>
                        </div>
                        <h3 className="mt-2 text-sm font-semibold">
                          Ready for review
                        </h3>
                        <p className="mt-1 max-w-2xl text-xs leading-5 text-muted-foreground">
                          Compare each report with the current Intake before applying it. Applied facts remain in this submission as a review record.
                        </p>
                      </div>
                      <div className="flex flex-wrap gap-2 @xl:justify-self-end">
                        {active.undoAvailable && (
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            aria-label="Undo last applied client facts"
                            onClick={undo}
                            disabled={undoLastApplication.isPending || hasUnsavedChanges}
                          >
                            {undoLastApplication.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Undoing…
                              </>
                            ) : (
                              <>
                                <Undo2 className="mr-2 h-4 w-4" />
                                Undo last apply
                              </>
                            )}
                          </Button>
                        )}
                        <Button
                          type="button"
                          onClick={() => apply(unapplied.map(field => field.key))}
                          disabled={
                            approve.isPending ||
                            undoLastApplication.isPending ||
                            hasUnsavedChanges ||
                            unapplied.length === 0
                          }
                          className="min-h-10"
                        >
                          {approve.isPending ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Applying…
                            </>
                          ) : (
                            "Apply all ready facts"
                          )}
                        </Button>
                      </div>
                    </div>
                    {applyError && (
                      <p
                        role="alert"
                        className="rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive"
                      >
                        {applyError}
                      </p>
                    )}
                    {fields.length === 0 ? (
                      <p className="rounded-md border border-dashed px-3 py-4 text-sm text-muted-foreground">
                        This submission has no facts eligible to apply.
                      </p>
                    ) : (
                      <section
                        aria-labelledby="client-intake-comparison-heading"
                        className="space-y-3"
                      >
                        <div className="flex flex-col gap-2 @lg:flex-row @lg:items-end @lg:justify-between">
                          <div>
                            <h3
                              id="client-intake-comparison-heading"
                              className="text-sm font-semibold"
                            >
                              Compare reported facts
                            </h3>
                            <p className="mt-1 text-xs leading-5 text-muted-foreground">
                              Select individual facts, or apply a verified report in one action.
                            </p>
                          </div>
                          <p className="text-xs tabular-nums text-muted-foreground">
                            {unapplied.length} ready to apply
                          </p>
                        </div>
                        <div className="hidden grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)_minmax(0,.8fr)_auto] gap-4 px-4 text-[11px] font-semibold uppercase tracking-[0.08em] text-muted-foreground @3xl:grid">
                          <span>Field</span>
                          <span>Client report</span>
                          <span>Current Intake</span>
                          <span className="text-right">Decision</span>
                        </div>
                        <ul
                          className="overflow-hidden rounded-xl border border-border/80 bg-background"
                          aria-label="Reported facts"
                        >
                          {fields.map(field => {
                            const isApplied = applied.has(field.key);
                            const isSelected = selectedFields.includes(field.key);
                            const dependency = dependencyFor(field.key);
                            const dependencyApplied =
                              !dependency || applied.has(dependency);
                            const dependencySelected = Boolean(
                              dependency && selectedFields.includes(dependency)
                            );
                            const individuallyBlocked =
                              !isApplied && !dependencyApplied;
                            const currentValue = currentScalarValue(
                              field.key,
                              currentEstate
                            );
                            return (
                              <li
                                key={field.key}
                                className={`grid gap-3 border-b border-border/70 p-4 transition-colors duration-150 last:border-b-0 @3xl:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)_minmax(0,.8fr)_auto] @3xl:items-center ${
                                  isApplied
                                    ? "bg-emerald-500/[0.045]"
                                    : isSelected
                                      ? "bg-primary/[0.045]"
                                      : "bg-background"
                                }`}
                              >
                                <div className="min-w-0">
                                  <p className="text-sm font-medium">
                                    {field.label}
                                  </p>
                                  <p className="mt-0.5 text-xs text-muted-foreground">
                                    {field.destination}
                                  </p>
                                </div>
                                <div className="min-w-0">
                                  <p className="break-words text-sm leading-5">
                                    {field.value}
                                  </p>
                                </div>
                                <div className="min-w-0 rounded-md bg-muted/45 px-3 py-2 text-xs text-muted-foreground @3xl:bg-transparent @3xl:px-0 @3xl:py-0">
                                  {currentValue !== null && (
                                    <>
                                      <span className="block font-medium text-foreground/80 @3xl:hidden">
                                        Current record
                                      </span>
                                      <span className="mt-0.5 block break-words">
                                        {currentValue}
                                      </span>
                                    </>
                                  )}
                                </div>
                                <div className="flex min-h-9 items-center gap-2 @3xl:justify-end">
                                  {isApplied ? (
                                    <Badge
                                      variant="secondary"
                                      className="border border-emerald-600/15 bg-emerald-500/10 text-emerald-800 dark:text-emerald-300"
                                      aria-label={`${field.label} already applied`}
                                    >
                                      <CheckCircle2 className="mr-1 h-3.5 w-3.5" />
                                      Applied
                                    </Badge>
                                  ) : (
                                    <>
                                      <Checkbox
                                        aria-label={`Select ${field.label} for approval`}
                                        checked={isSelected}
                                        onCheckedChange={checked =>
                                          toggle(field.key, checked === true)
                                        }
                                        disabled={
                                          approve.isPending ||
                                          hasUnsavedChanges ||
                                          (individuallyBlocked &&
                                            !dependencySelected)
                                        }
                                      />
                                      <Button
                                        type="button"
                                        size="sm"
                                        variant="outline"
                                        aria-label={
                                          individuallyBlocked
                                            ? `${dependencyMessage(field.key)} before applying ${field.label}`
                                            : `Apply ${field.label}`
                                        }
                                        title={
                                          individuallyBlocked
                                            ? dependencyMessage(field.key)
                                            : undefined
                                        }
                                        onClick={() => apply([field.key])}
                                        disabled={
                                          approve.isPending ||
                                          hasUnsavedChanges ||
                                          individuallyBlocked
                                        }
                                      >
                                        {individuallyBlocked
                                          ? dependencyMessage(field.key)
                                          : "Apply"}
                                      </Button>
                                    </>
                                  )}
                                </div>
                              </li>
                            );
                          })}
                        </ul>
                      </section>
                    )}
                    {metadata.length > 0 && (
                      <section
                        aria-labelledby="client-intake-review-only-heading"
                        className="rounded-xl border border-border/70 bg-muted/35 p-4 text-sm"
                      >
                        <div className="flex flex-wrap items-baseline justify-between gap-2">
                          <h3
                            id="client-intake-review-only-heading"
                            className="text-sm font-semibold"
                          >
                            Review-only context
                          </h3>
                          <span className="text-xs text-muted-foreground">
                            Retained with this submission
                          </span>
                        </div>
                        <p className="mt-1 text-xs leading-5 text-muted-foreground">
                          These client reports inform your review and are not applied to the estate record.
                        </p>
                        <dl className="mt-3 space-y-2 border-t border-border/60 pt-3">
                          {metadata.map(entry => (
                            <div
                              key={entry.label}
                              className="grid gap-1 @lg:grid-cols-[11rem_1fr]"
                            >
                              <dt className="text-xs font-medium text-muted-foreground">
                                {entry.label}
                              </dt>
                              <dd className="whitespace-pre-wrap break-words text-sm">
                                {entry.value}
                              </dd>
                            </div>
                          ))}
                        </dl>
                      </section>
                    )}
                  </>
                );
              })()}
              <div className="space-y-2">
                <Label
                  htmlFor={`review-notes-${active.id}`}
                  className="text-xs"
                >
                  Internal review note (optional)
                </Label>
                <Textarea
                  id={`review-notes-${active.id}`}
                  value={reviewNotes}
                  onChange={event => setReviewNotes(event.target.value)}
                  maxLength={10000}
                  rows={3}
                  placeholder="Record what was verified or any follow-up taken."
                />
              </div>
              <details className="group overflow-hidden rounded-xl border border-border/70 bg-background">
                <summary className="flex min-h-12 cursor-pointer list-none items-center gap-3 px-4 py-3 text-sm font-medium marker:content-none [&::-webkit-details-marker]:hidden">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-muted text-muted-foreground">
                    <MessageSquareMore className="h-4 w-4" aria-hidden="true" />
                  </span>
                  <span className="min-w-0">
                    <span className="block">Request corrections</span>
                    <span className="mt-0.5 block text-xs font-normal leading-5 text-muted-foreground">
                      Send a general note or field-specific questions to the client portal.
                    </span>
                  </span>
                  <ChevronDown
                    className="ml-auto h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200 group-open:rotate-180 motion-reduce:transition-none"
                    aria-hidden="true"
                  />
                </summary>
                <div className="space-y-3 border-t border-border/70 px-4 py-4">
                  <div>
                    <Label
                      htmlFor={`revision-request-${active.id}`}
                      className="text-xs"
                    >
                      General request for revisions (optional)
                    </Label>
                    <Textarea
                      id={`revision-request-${active.id}`}
                      value={revisionRequest}
                      onChange={event => setRevisionRequest(event.target.value)}
                      maxLength={10000}
                      rows={3}
                      placeholder="Describe any general information to correct or add. This message is visible in the client portal."
                    />
                  </div>
                  <div className="space-y-2">
                    <p className="text-xs font-medium text-muted-foreground">
                      Field-specific comments (optional)
                    </p>
                    <div className="grid gap-2 md:grid-cols-2">
                      {CLIENT_INTAKE_REVISION_FIELDS.filter(
                        field =>
                          Boolean(active.payload[field]) &&
                          !(
                            field === "willStatus" &&
                            active.payload.willStatus === "unknown"
                          )
                      ).map(field => (
                        <div key={field} className="space-y-1">
                          <Label
                            htmlFor={`revision-field-${active.id}-${field}`}
                            className="text-xs"
                          >
                            {CLIENT_INTAKE_REVISION_FIELD_LABELS[field]}
                          </Label>
                          <Textarea
                            id={`revision-field-${active.id}-${field}`}
                            value={revisionFieldComments[field] || ""}
                            onChange={event =>
                              setRevisionFieldComments(current => ({
                                ...current,
                                [field]: event.target.value,
                              }))
                            }
                            maxLength={1000}
                            rows={2}
                            placeholder={`What should the client revise about ${CLIENT_INTAKE_REVISION_FIELD_LABELS[field].toLowerCase()}?`}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Requesting revisions keeps this submission as a review
                    record. Clients see only this request and any field
                    comments, then send updated details for a new lawyer review.
                  </p>
                </div>
              </details>
              <div className="flex flex-col justify-between gap-4 rounded-xl border border-primary/15 bg-primary/[0.025] p-4 @lg:flex-row @lg:items-center">
                <p className="max-w-2xl text-xs leading-5 text-muted-foreground">
                  {hasUnsavedChanges
                    ? "Save or discard the current Intake edits before applying this submission."
                    : "Approval applies only the selected verified facts using the current Intake revision. It does not create a court filing."}
                </p>
                <div className="flex flex-col gap-2 @sm:flex-row">
                  <Button
                    variant="outline"
                    onClick={() =>
                      requestRevision.mutate({
                        estateId,
                        submissionId: active.id,
                        revisionRequest,
                        revisionFieldComments: Object.entries(
                          revisionFieldComments
                        ).flatMap(([field, comment]) =>
                          comment.trim()
                            ? [
                                {
                                  field: field as ClientIntakeRevisionField,
                                  comment: comment.trim(),
                                },
                              ]
                            : []
                        ),
                      })
                    }
                    disabled={
                      requestRevision.isPending ||
                      (revisionRequest.trim().length < 3 &&
                        !Object.values(revisionFieldComments).some(
                          comment => comment?.trim().length
                        ))
                    }
                  >
                    {requestRevision.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Sending…
                      </>
                    ) : (
                      "Request revisions"
                    )}
                  </Button>
                  <Button
                    aria-label="Approve selected facts"
                    onClick={() => apply(selectedFields)}
                    disabled={
                      approve.isPending ||
                      selectedFields.length === 0 ||
                      hasUnsavedChanges
                    }
                  >
                    {approve.isPending ? (
                      <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Applying…
                        </>
                      ) : (
                        `Apply ${selectedFields.length} ${selectedFields.length === 1 ? "selected fact" : "selected facts"}`
                      )}
                    </Button>
                </div>
              </div>
            </>
          )}
        </CardContent>
      )}
    </Card>
  );
}
