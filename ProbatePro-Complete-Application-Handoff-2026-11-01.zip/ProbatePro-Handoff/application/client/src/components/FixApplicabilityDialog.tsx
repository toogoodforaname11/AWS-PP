// client/src/components/FixApplicabilityDialog.tsx
//
// The "generate an optional form" popup. Clicking Generate (or Preview) on any
// form in the Forms tab's Optional list opens this dialog with exactly the
// intake questions whose answers drive that form's formStatus() verdict
// (shared/applicabilityQuestions.ts), pre-filled with the estate's current
// values.
//
// Data scope — this is an OVERRIDE dialog, not an edit dialog:
//   - Nothing is written to the estate record. The answers ride ONE generate or
//     preview call as per-document overrides (shared/formOverrides.ts), the
//     server merges them at load, and the intake the user left is the intake
//     they come back to.
//   - The confirm button is ALWAYS enabled. formStatus() decides what is
//     REQUIRED; the lawyer decides what gets drafted (RULES.md Rule 22). The
//     live verdict below is shown as information — it never gates the button.
//   - formStatus() remains the single source of truth for applicability
//     (adr-formstatus-single-source-of-truth); overrides change the facts it
//     reads for one request, never how it decides.

import * as React from "react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TriToggle } from "@/components/TriToggle";
import { ClipboardList, Users } from "lucide-react";
import { findPrimaryApplicant, formStatus, isApplyingApplicant, isSoleChildApplicant, validateIntestatePriority, type FormApplicability } from "@shared/types";
import {
  APPLICABILITY_FIX,
  buildApplicabilityWritePayload,
  type ApplicabilityQuestion,
} from "@shared/applicabilityQuestions";

// One vocabulary for every surface that names a form's applicability (Nick
// 2026-09-02 third estate-#18 live audit: this popup said "Not required" for
// a verdict the Forms-tab card badges "Optional"). The card's two words are
// the ruled ones (Rule 22: an engine-na form is Optional, never N/A) — the
// card imports this helper so the two surfaces can never diverge again.
export function applicabilityLabel(a: FormApplicability): string {
  return a === "required" ? "Required" : "Optional";
}

/** Seed a control's draft value from the estate record. */
function seedValue(q: ApplicabilityQuestion, estate: any): unknown {
  if (q.control === "checkbox") return q.asInt ? (estate?.[q.column] ? 1 : 0) : !!estate?.[q.column];
  if (q.control === "yesNoInt") return estate?.[q.column] ? 1 : 0;
  if (q.resolveValue) return q.resolveValue(estate);
  return String(estate?.[q.column] ?? "");
}

export interface FixApplicabilityDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  formCode: string;
  formName: string;
  estate: any;
  contacts: any[];
  /** Preserve the deponent chosen before entering the applicability escape. */
  selectedContactId?: string;
  /** "preview" renders the same answers without persisting a document. */
  intent?: "generate" | "preview";
  /** Jump to the Contacts tab for contact-driven verdicts. */
  onGoToContacts?: () => void;
  /** Jump to the Intake tab to make an answer permanent. */
  onGoToIntake?: () => void;
  /**
   * Run the generation (or preview) with these per-document overrides.
   * `notApplicable` is the user's explicit opt-in for a form the recorded facts
   * do not call for — the server requires it to lift its own gate.
   */
  onProceed: (
    formCode: string,
    overrides: Record<string, unknown>,
    opts: { notApplicable: boolean; intent: "generate" | "preview" },
  ) => void;
  /**
   * Addendum 24.1: set when the dialog was entered via the preflight na
   * escape hatch — the server verdict was na, so Proceed carries
   * generateAnyway even if the client-side draft computes applicable
   * (a stale estate row must not loop the user into the same hard block).
   */
  forceNotApplicable?: boolean;
}

export function FixApplicabilityDialog(props: FixApplicabilityDialogProps): React.JSX.Element {
  const { open, onOpenChange, formCode, formName, estate, contacts, selectedContactId, intent = "generate", onGoToContacts, onGoToIntake, onProceed, forceNotApplicable } = props;
  const spec = APPLICABILITY_FIX[formCode];
  const questions = spec?.questions ?? [];

  // Draft answers keyed by estate column; seeded on open / form change.
  const [draft, setDraft] = useState<Record<string, unknown>>({});
  const seedRef = useRef<Record<string, unknown>>({});
  useEffect(() => {
    if (!open) return;
    const seed: Record<string, unknown> = {};
    for (const q of questions) seed[q.column] = seedValue(q, estate);
    seedRef.current = seed;
    setDraft(seed);
    // Reset only when the dialog (re)opens for a form — not on every estate
    // refetch while the user is mid-edit.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, formCode]);

  // Ordinarily only columns the user changed ride the request. On the forced
  // na escape, however, the dialog is the user's confirmation snapshot: every
  // displayed answer must ride so a concurrent estate change cannot authorize
  // and render from facts different from the ones the user just reviewed. The
  // server's overrideSummary still omits values equal to the stored record.
  const changed = useMemo(() => {
    const out: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(draft)) {
      if (!Object.is(value, seedRef.current[key])) out[key] = value;
    }
    return out;
  }, [draft]);

  const answersForRequest = forceNotApplicable === true ? draft : changed;

  // The same coupling the intake write path applies: willType carries
  // isElectronicWill, and each electronic-will axis re-derives the legacy
  // format token. Sending a half-applied answer would render the wrong sworn
  // branch on P1/P4/P45.
  const overrides = useMemo(
    () => buildApplicabilityWritePayload(estate, answersForRequest),
    [estate, answersForRequest],
  );
  const draftEstate = useMemo(() => ({ ...estate, ...overrides }), [estate, overrides]);

  const liveStatus = useMemo(
    () => formStatus(formCode, draftEstate as any, contacts || []),
    [formCode, draftEstate, contacts],
  );

  const stillNotApplicable = liveStatus.applicability === "na";
  const actionLabel = intent === "preview" ? "Preview" : "Generate";
  const p5Applicant = formCode === "P5"
    ? selectedContactId
      ? contacts.find((contact) => String(contact.id) === String(selectedContactId) && isApplyingApplicant(contact))
      : findPrimaryApplicant(contacts || [])
    : undefined;
  const p5Standing = p5Applicant ? validateIntestatePriority(
    p5Applicant.relationship || "",
    draftEstate.intestateConsentState === "majority_consent" ? "majority_consent"
      : draftEstate.intestateConsentState === "no_majority_consent" ? "no_majority_consent" : "self_consent",
    !!draftEstate.applicantIsNominee,
    !!draftEstate.applicantIsGovernmentNominee,
    p5Applicant.relationshipDurationMonths,
    isSoleChildApplicant(contacts || [], p5Applicant),
  ) : undefined;

  function handleConfirm(): void {
    onOpenChange(false);
    // forceNotApplicable (Addendum 24.1): when entered via the preflight
    // dialog's na escape hatch, the server verdict was na — carry
    // generateAnyway regardless of what the client-side draft computes, or a
    // stale estate row loops the user back into the same hard block.
    onProceed(formCode, overrides, { notApplicable: formCode === "P5" || stillNotApplicable || forceNotApplicable === true, intent });
  }

  function renderControl(q: ApplicabilityQuestion): React.JSX.Element {
    const value = draft[q.column];
    const set = (v: unknown) => setDraft((prev) => ({ ...prev, [q.column]: v }));
    switch (q.control) {
      case "select":
        return (
          <Select value={String(value ?? "")} onValueChange={set}>
            <SelectTrigger className="h-9" data-testid={`fix-question-${q.column}`}>
              <SelectValue placeholder="Select..." />
            </SelectTrigger>
            <SelectContent>
              {(q.options ?? []).filter((o) => o.value !== "").map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        );
      case "tri":
        return (
          <div data-testid={`fix-question-${q.column}`}>
            <TriToggle
              value={String(value ?? "")}
              onChange={set}
              options={q.triOptions ? [...q.triOptions] : undefined}
              labels={q.triLabels ? [...q.triLabels] : undefined}
            />
          </div>
        );
      case "yesNoInt":
        return (
          <div data-testid={`fix-question-${q.column}`}>
            <TriToggle
              value={value ? "yes" : "no"}
              onChange={(v) => set(v === "yes" ? 1 : 0)}
              options={["yes", "no"]}
              labels={["Yes", "No"]}
            />
          </div>
        );
      case "checkbox":
        return (
          <Checkbox
            checked={!!value}
            onCheckedChange={(checked) => set(q.asInt ? (checked ? 1 : 0) : !!checked)}
            data-testid={`fix-question-${q.column}`}
          />
        );
      case "date":
        return (
          <Input
            type="date"
            className="h-9"
            value={String(value ?? "")}
            onChange={(e) => set(e.target.value)}
            data-testid={`fix-question-${q.column}`}
          />
        );
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto" data-testid="fix-applicability-dialog">
        <DialogHeader>
          <DialogTitle>{actionLabel} {formCode} — {formName}</DialogTitle>
          <DialogDescription>
            {/* XC-11 (Nick 2026-09-01): the copy follows the LIVE verdict, never
                a static branch — a required-computing form must not be
                introduced as "not required". */}
            {questions.length > 0
              ? "Answer what this form needs. Your answers apply to this document only — the intake record is not changed."
              : stillNotApplicable
                ? "The recorded intake does not call for this form. You can still produce it — the intake record is not changed."
                : "You can produce this form — the intake record is not changed."}
          </DialogDescription>
        </DialogHeader>

        {/* Live verdict — information, never a gate. */}
        <div
          role="status"
          aria-live="polite"
          className={`rounded-md border p-2.5 text-xs ${stillNotApplicable ? "bg-muted/50 text-muted-foreground" : "border-green-300 bg-green-50 text-green-800 dark:border-green-800 dark:bg-green-950/30 dark:text-green-300"}`}
          data-testid="fix-live-status"
        >
          {stillNotApplicable ? (
            <span data-testid="fix-still-na">
              <strong>Not required for this estate:</strong> {liveStatus.reason} You can still {actionLabel.toLowerCase()} it — the draft will state the answers above, which your file does not yet record.
            </span>
          ) : (
            <span data-testid="fix-now-applicable">
              With these answers {formCode} is <strong>{applicabilityLabel(liveStatus.applicability)}</strong>. {liveStatus.reason}
            </span>
          )}
        </div>

        {spec?.note && (
          <p className="text-xs text-muted-foreground leading-relaxed" data-testid="fix-note">{spec.note}</p>
        )}

        {questions.length > 0 && (
          <div className="space-y-3">
            {questions.map((q) => (
              <div key={q.column} className={q.control === "checkbox" ? "flex items-center gap-2" : "space-y-1.5"}>
                {q.control === "checkbox" ? (
                  <>
                    {renderControl(q)}
                    <Label className="text-xs font-normal cursor-pointer">{q.label}</Label>
                  </>
                ) : (
                  <>
                    <Label className="text-xs font-medium text-muted-foreground">{q.label}</Label>
                    {renderControl(q)}
                  </>
                )}
                {q.help && <p className="text-[10px] text-muted-foreground leading-tight">{q.help}</p>}
              </div>
            ))}
            {formCode === "P5" && (
              <div className="rounded-md border p-2.5 text-xs space-y-1" data-testid="fix-p5-standing">
                <p><strong>Applicant standing</strong></p>
                <p>{p5Applicant?.name || "No applicant recorded"}{p5Applicant?.relationship ? ` — ${p5Applicant.relationship}` : ""}</p>
                {p5Standing?.valid && p5Standing.paragraph
                  ? <p>WESA s.130 paragraph ({p5Standing.paragraph}), based on the applicant's relationship and these answers.</p>
                  : p5Applicant?.relationship
                    ? <p>These answers do not establish statutory priority. The draft uses the recorded relationship.</p>
                    : <p>Record the applicant's relationship on their contact to complete the standing information.</p>}
                {p5Standing?.note && <p>{p5Standing.note}</p>}
              </div>
            )}
            <p className="text-[10px] text-muted-foreground leading-tight" data-testid="fix-transient-note">
              To make an answer permanent — so it re-buckets the Forms list, deadlines and probate-fee figures — record it on the Intake tab instead.
            </p>
          </div>
        )}

        <DialogFooter className="gap-2">
          <Button variant="ghost" onClick={() => onOpenChange(false)} data-testid="fix-cancel">
            Cancel
          </Button>
          {spec?.intakeNote && onGoToIntake && (
            <Button
              variant="outline"
              onClick={() => { onOpenChange(false); onGoToIntake(); }}
              data-testid="fix-go-intake"
            >
              <ClipboardList className="h-3.5 w-3.5 mr-1" /> Go to Intake
            </Button>
          )}
          {spec?.contactsNote && onGoToContacts && (
            <Button
              variant="outline"
              onClick={() => { onOpenChange(false); onGoToContacts(); }}
              data-testid="fix-go-contacts"
            >
              <Users className="h-3.5 w-3.5 mr-1" /> Go to Contacts
            </Button>
          )}
          <Button onClick={handleConfirm} data-testid="fix-confirm">
            {actionLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
