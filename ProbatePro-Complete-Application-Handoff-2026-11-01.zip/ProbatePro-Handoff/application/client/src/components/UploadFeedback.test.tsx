import React from "react";
import { describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen } from "@testing-library/react";
import { FileDropZone, UploadFeedback, UploadedDocumentVisual, fileTooLargeMessage, invalidFileTypeMessage } from "./UploadFeedback";

describe("UploadFeedback", () => {
  it("names the rejected file type and the accepted alternatives", () => {
    expect(invalidFileTypeMessage("scanned-will.heic", "a PDF, DOC/DOCX, PNG, JPG, or TIFF file"))
      .toBe(".HEIC files are not accepted here. Choose a PDF, DOC/DOCX, PNG, JPG, or TIFF file.");
  });

  it("provides an actionable maximum-size message", () => {
    expect(fileTooLargeMessage("20 MB")).toBe("This file is too large. Choose a file up to 20 MB.");
  });

  it("renders an accessible phase-progress indicator while uploading", () => {
    render(<UploadFeedback state={{ phase: "uploading", progress: 72, message: "Securely uploading will.pdf" }} />);
    expect(screen.getByRole("status").textContent).toContain("Securely uploading will.pdf");
    expect(screen.getByRole("progressbar").getAttribute("aria-label")).toBe("Securely uploading will.pdf");
  });

  it("announces a specific rejection as an alert", () => {
    render(<UploadFeedback state={{ phase: "error", progress: 0, message: ".HEIC files are not accepted here." }} />);
    expect(screen.getByRole("alert").textContent).toContain(".HEIC files are not accepted here.");
  });

  it("routes a dropped document to the supplied selection handler", () => {
    const onFileDrop = vi.fn();
    render(<FileDropZone onFileDrop={onFileDrop}><button type="button">Browse files</button></FileDropZone>);
    const file = new File(["%PDF-1.7"], "will.pdf", { type: "application/pdf" });
    fireEvent.drop(screen.getByTestId("file-drop-zone"), { dataTransfer: { files: [file], types: ["Files"] } });
    expect(onFileDrop).toHaveBeenCalledWith(file);
    expect(screen.getByRole("button", { name: "Browse files" })).toBeTruthy();
  });

  it("applies the caller's active treatment while a file is dragged over the drop zone", () => {
    render(
      <FileDropZone activeClassName="border-primary bg-primary/5">
        <button type="button">Browse workbook</button>
      </FileDropZone>,
    );
    const zone = screen.getByTestId("file-drop-zone");
    const file = new File(["workbook"], "inventory.xlsx", { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });

    fireEvent.dragEnter(zone, { dataTransfer: { files: [file], types: ["Files"] } });

    expect(zone.className).toContain("border-primary");
    expect(zone.className).toContain("bg-primary/5");
  });

  it("passes every dropped file to a multi-document selection handler", () => {
    const onFilesDrop = vi.fn();
    render(<FileDropZone onFilesDrop={onFilesDrop}><button type="button">Browse documents</button></FileDropZone>);
    const first = new File(["%PDF-1.7"], "first.pdf", { type: "application/pdf" });
    const second = new File(["%PDF-1.7"], "second.pdf", { type: "application/pdf" });
    fireEvent.drop(screen.getByTestId("file-drop-zone"), { dataTransfer: { files: [first, second], types: ["Files"] } });
    expect(onFilesDrop).toHaveBeenCalledWith([first, second]);
  });

  it("uses a local image thumbnail only for an uploaded image and a type icon for documents", () => {
    const { rerender } = render(<UploadedDocumentVisual fileName="signed-will.jpg" mimeType="image/jpeg" localPreviewUrl="blob:local-preview" />);
    expect(screen.getByAltText("Preview of signed-will.jpg")).toBeTruthy();
    rerender(<UploadedDocumentVisual fileName="signed-will.pdf" mimeType="application/pdf" />);
    expect(screen.getByTestId("uploaded-document-icon").getAttribute("aria-label")).toBe("PDF document icon");
  });

  it("opens an enlarged, dismissible dialog from an uploaded image thumbnail", () => {
    render(<UploadedDocumentVisual fileName="signed-will.jpg" mimeType="image/jpeg" localPreviewUrl="blob:local-preview" />);
    fireEvent.click(screen.getByRole("button", { name: "Enlarge preview of signed-will.jpg" }));
    expect(screen.getByTestId("uploaded-document-enlarged-preview")).toBeTruthy();
    expect(screen.getByAltText("Enlarged preview of signed-will.jpg")).toBeTruthy();
    fireEvent.keyDown(document, { key: "Escape" });
    expect(screen.queryByTestId("uploaded-document-enlarged-preview")).toBeNull();
  });

  it("offers an accessible remove action only when the caller provides one", () => {
    const onRemove = vi.fn();
    render(<UploadFeedback state={{ phase: "complete", progress: 100, message: "will.pdf uploaded", fileName: "will.pdf", mimeType: "application/pdf" }} onRemove={onRemove} />);
    fireEvent.click(screen.getByTestId("uploaded-document-remove"));
    expect(onRemove).toHaveBeenCalledOnce();
    expect(screen.getByTestId("uploaded-document-remove").getAttribute("aria-label")).toBe("Remove will.pdf");
  });
});
