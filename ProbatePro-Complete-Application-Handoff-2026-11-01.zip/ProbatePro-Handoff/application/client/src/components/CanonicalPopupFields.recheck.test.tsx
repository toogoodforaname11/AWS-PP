import React, { useState } from "react";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { checkFormRequirements } from "../../../shared/formRequirements";
import { coupleWillFilingTypeFacts } from "../../../shared/types";
import { PreGenerateDialog } from "./PreGenerateDialog";

function mount(failedRechecks = 0, waitSave?: Promise<void>) {
  const initial: any = { id: "fictional-refresh-popup", revision: 1, hasWill: 1, willStatus: "will",
    grantType: "grant_of_probate", willType: "", isElectronicWill: 0, willFilingType: "", deceasedLastName: "" };
  const inspect = (estate: any) => checkFormRequirements("P4", { estate, contacts: [], inventory: [], requiredDocuments: [], requiredCatalog: [] });
  let stored = initial;
  const writes: any[] = [];
  const apply = vi.fn();
  function Fixture() {
    const [estate, setEstate] = useState(initial);
    const [report, setReport] = useState(inspect(initial));
    apply.mockImplementation(async (...args: any[]) => {
      if (waitSave) await waitSave;
      const values = args[0] ?? {};
      const canonical = args[5] ?? {};
      const observer = args[6];
      // Same two existing coupling boundaries as the real parent and estate.update.
      const patch = coupleWillFilingTypeFacts({ ...coupleWillFilingTypeFacts(values), ...canonical }, stored);
      if (Object.keys(patch).length) {
        writes.push(patch);
        stored = { ...stored, ...patch, revision: stored.revision + 1 };
        setEstate(stored);
        if (Object.keys(canonical).length) observer?.onSaved({ estateId: stored.id, revision: stored.revision, record: stored });
      }
      if (failedRechecks > 0) { failedRechecks -= 1; return false; }
      const fresh = inspect({ ...stored, ...values });
      observer?.onRechecked();
      setReport(fresh);
      return true;
    });
    return <PreGenerateDialog open formName="P4" reports={[report]} estate={estate} contacts={[]}
      inlineEditingEnabled onApplyInline={apply} onProceed={vi.fn()} onOpenChange={vi.fn()} onCancel={vi.fn()} onJumpToTab={vi.fn()} />;
  }
  render(<Fixture />);
  return { apply, writes, stored: () => stored, report: () => inspect(stored) };
}
async function choose(id: string, label: string) {
  fireEvent.click(screen.getByTestId(id));
  fireEvent.click(await screen.findByRole("option", { name: label }));
}
async function chooseMixedOriginal() {
  await choose("pre-generate-canonical-willType", "Physical");
  await choose("pre-generate-input-willFilingType", "The electronic original.");
}
const applyButton = () => screen.getByTestId("pre-generate-apply");
beforeEach(() => {
  cleanup();
  for (const [key, value] of Object.entries({ hasPointerCapture: (): boolean => false, setPointerCapture: (): void => {}, releasePointerCapture: (): void => {}, scrollIntoView: (): void => {} })) Object.defineProperty(Element.prototype, key, { value, configurable: true });
});
afterEach(cleanup);

describe("canonical popup ownership across real refreshed requirements", () => {
  it("keeps newer filing/medium choices visible and eligible when the old successful recheck removes both gaps", async () => {
    let release!: () => void;
    const gate = new Promise<void>(resolve => { release = resolve; });
    const h = mount(0, gate);
    await chooseMixedOriginal();
    fireEvent.click(applyButton());
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(1));
    await choose("pre-generate-input-willFilingType", "A copy (original lost/destroyed).");
    await act(async () => { release(); });
    expect(h.report().gaps.some(gap => gap.requirementId === "p4_will_medium_answered")).toBe(false);
    expect(h.report().gaps.some(gap => gap.requirementId === "p4_rule_25_3_6_will_filing_type_unconfirmed")).toBe(false);
    expect(screen.getByTestId("pre-generate-canonical-willType").textContent).toContain("Physical");
    expect(screen.getByTestId("pre-generate-input-willFilingType").textContent).toContain("A copy");
    fireEvent.click(applyButton());
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(2));
    expect(h.apply.mock.calls[1][5]).toMatchObject({ willType: "physical", isElectronicWill: 0 });
    expect(h.stored()).toMatchObject({ willType: "physical", isElectronicWill: 0, willFilingType: "copy" });
  });

  it("banks an acknowledged mixed filing value even when recheck fails, so retry does not write it again", async () => {
    const h = mount(1);
    await chooseMixedOriginal();
    fireEvent.click(applyButton());
    await waitFor(() => expect(h.writes).toHaveLength(1));
    await act(async () => { await Promise.resolve(); });
    fireEvent.click(applyButton());
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(2));
    expect(h.apply.mock.calls[1][0]).toEqual({});
    expect(h.apply.mock.calls[1][5]).toEqual({});
    expect(h.writes).toHaveLength(1);
  });

  it("does not replay an old filing patch over a later acknowledged medium correction after two failed rechecks", async () => {
    const h = mount(2);
    await chooseMixedOriginal();
    fireEvent.click(applyButton());
    await waitFor(() => expect(h.writes).toHaveLength(1));
    await choose("pre-generate-canonical-willType", "Physical");
    fireEvent.click(applyButton());
    await waitFor(() => expect(h.writes).toHaveLength(2));
    expect(h.stored().willType).toBe("physical");
    await act(async () => { await Promise.resolve(); });
    fireEvent.click(applyButton());
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(3));
    expect(h.apply.mock.calls[2][0]).toEqual({});
    expect(h.apply.mock.calls[2][5]).toEqual({});
    expect(h.writes).toHaveLength(2);
    expect(h.stored()).toMatchObject({ willType: "physical", isElectronicWill: 0 });
  });
});
