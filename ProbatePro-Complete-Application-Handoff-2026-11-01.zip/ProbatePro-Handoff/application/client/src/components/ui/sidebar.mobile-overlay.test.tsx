import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarProvider, SidebarTrigger } from "./sidebar";

const originalInnerWidth = window.innerWidth;

function MobileSidebarFixture() {
  return (
      <SidebarProvider>
        <Sidebar>
        <SidebarHeader className="shrink-0">ProbatePro</SidebarHeader>
        <SidebarContent>Navigation content</SidebarContent>
        <SidebarFooter className="shrink-0">Pinned account controls</SidebarFooter>
      </Sidebar>
      <SidebarTrigger />
      <button type="button">Background action</button>
    </SidebarProvider>
  );
}

describe("mobile sidebar overlay", () => {
  beforeEach(() => {
    Object.defineProperty(window, "matchMedia", {
      configurable: true,
      value: () => ({ matches: true, addEventListener: () => undefined, removeEventListener: () => undefined }),
    });
  });

  afterEach(() => {
    Object.defineProperty(window, "innerWidth", { configurable: true, value: originalInnerWidth });
  });

  it("keeps the navigation scroll region between pinned header and footer segments on a narrow screen", () => {
    Object.defineProperty(window, "innerWidth", { configurable: true, value: 320 });
    render(<MobileSidebarFixture />);

    fireEvent.click(screen.getByRole("button", { name: "Toggle Sidebar" }));

    const drawer = document.querySelector('[data-sidebar="sidebar"][data-mobile="true"]');
    const backdrop = document.querySelector('[data-slot="sheet-overlay"]');
    const mobileFrame = document.querySelector('[data-slot="sidebar-mobile-frame"]');
    const header = document.querySelector('[data-slot="sidebar-header"]');
    const content = document.querySelector('[data-slot="sidebar-content"]');
    const footer = document.querySelector('[data-slot="sidebar-footer"]');
    expect(drawer?.className).toContain("!bg-sidebar-background");
    expect(drawer?.className).toContain("opacity-100");
    expect(drawer?.className).toContain("min-h-0");
    expect(backdrop?.className).toContain("!bg-background");
    expect(backdrop?.className).toContain("opacity-100");
    expect(mobileFrame?.className).toContain("h-full");
    expect(mobileFrame?.className).toContain("min-h-0");
    expect(mobileFrame?.className).toContain("flex-col");
    expect(header?.className).toContain("shrink-0");
    expect(content?.className).toContain("flex-1");
    expect(content?.className).toContain("overflow-auto");
    expect(footer?.className).toContain("shrink-0");
    expect(screen.getByText("Navigation content")).toBeTruthy();
    expect(screen.getByText("Pinned account controls")).toBeTruthy();
  });

  it("leaves browser touch scrolling alone and opens through the explicit menu control", () => {
    Object.defineProperty(window, "innerWidth", { configurable: true, value: 390 });
    render(<MobileSidebarFixture />);

    fireEvent.touchStart(document, {
      changedTouches: [{ clientX: 12, clientY: 280 }],
    });
    fireEvent.touchEnd(document, {
      changedTouches: [{ clientX: 96, clientY: 286 }],
    });
    expect(document.querySelector('[data-sidebar="sidebar"][data-mobile="true"]')).toBeNull();

    fireEvent.click(screen.getByRole("button", { name: "Toggle Sidebar" }));
    expect(document.querySelector('[data-sidebar="sidebar"][data-mobile="true"]')).toBeTruthy();
  });

  it("does not install document-level touch handlers for the sidebar", () => {
    const addEventListener = vi.spyOn(document, "addEventListener");
    render(<MobileSidebarFixture />);

    expect(addEventListener.mock.calls.some(([type]) => type === "touchstart" || type === "touchend")).toBe(false);
    addEventListener.mockRestore();
  });

  it("does not react to vertical page touch movement and exposes the entrance animation hook", () => {
    Object.defineProperty(window, "innerWidth", { configurable: true, value: 390 });
    render(<MobileSidebarFixture />);

    fireEvent.touchStart(document, {
      changedTouches: [{ clientX: 12, clientY: 120 }],
    });
    fireEvent.touchEnd(document, {
      changedTouches: [{ clientX: 92, clientY: 220 }],
    });
    expect(document.querySelector('[data-sidebar="sidebar"][data-mobile="true"]')).toBeNull();

    fireEvent.click(screen.getByRole("button", { name: "Toggle Sidebar" }));
    const drawer = document.querySelector('[data-sidebar="sidebar"][data-mobile="true"]');
    expect(drawer?.className).toContain("mobile-sidebar-content");
  });
});
