import React from "react";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { render } from "@testing-library/react";
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarProvider } from "./sidebar";

const originalInnerWidth = window.innerWidth;
const originalMatchMedia = window.matchMedia;

function DesktopSidebarFixture() {
  return (
    <SidebarProvider>
      <Sidebar collapsible="icon">
        <SidebarHeader className="shrink-0">ProbatePro</SidebarHeader>
        <SidebarContent>Navigation</SidebarContent>
        <SidebarFooter className="shrink-0">Account controls</SidebarFooter>
      </Sidebar>
      <main>Long workspace content</main>
    </SidebarProvider>
  );
}

describe("desktop sidebar viewport pinning", () => {
  beforeEach(() => {
    Object.defineProperty(window, "innerWidth", { configurable: true, value: 1280 });
    Object.defineProperty(window, "matchMedia", {
      configurable: true,
      value: () => ({ matches: false, addEventListener: () => undefined, removeEventListener: () => undefined }),
    });
  });

  afterEach(() => {
    Object.defineProperty(window, "innerWidth", { configurable: true, value: originalInnerWidth });
    Object.defineProperty(window, "matchMedia", { configurable: true, value: originalMatchMedia });
  });

  it("pins the desktop frame while preserving a top navigation segment and bottom account segment", () => {
    const { container } = render(<DesktopSidebarFixture />);

    const sidebarContainer = container.querySelector('[data-slot="sidebar-container"]');
    const sidebarInner = container.querySelector('[data-slot="sidebar-inner"]');
    const header = container.querySelector('[data-slot="sidebar-header"]');
    const content = container.querySelector('[data-slot="sidebar-content"]');
    const footer = container.querySelector('[data-slot="sidebar-footer"]');
    const containerClasses = sidebarContainer?.className.split(/\s+/) ?? [];
    const innerClasses = sidebarInner?.className.split(/\s+/) ?? [];
    const contentClasses = content?.className.split(/\s+/) ?? [];

    expect(containerClasses).toContain("fixed");
    expect(containerClasses).toContain("inset-y-0");
    expect(containerClasses).toContain("h-svh");
    expect(innerClasses).toContain("flex-col");
    expect(header?.className).toContain("shrink-0");
    expect(contentClasses).toContain("flex-1");
    expect(contentClasses).toContain("overflow-auto");
    expect(footer?.className).toContain("shrink-0");
  });
});
