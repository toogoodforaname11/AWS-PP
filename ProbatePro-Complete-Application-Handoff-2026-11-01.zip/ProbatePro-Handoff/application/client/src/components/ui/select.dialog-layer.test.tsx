import React from "react";
import { afterEach, describe, expect, it } from "vitest";
import { cleanup, render, screen } from "@testing-library/react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "./dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./select";

afterEach(cleanup);

describe("SelectContent in an elevated form dialog", () => {
  it("renders its portal above the missing-information dialog layer", () => {
    render(
      <Dialog open onOpenChange={() => {}}>
        <DialogContent className="z-[60]" overlayClassName="z-[60]">
          <DialogTitle>Missing information</DialogTitle>
          <DialogDescription>Choose the recorded answer.</DialogDescription>
          <Select open onOpenChange={() => {}}>
            <SelectTrigger aria-label="Recorded answer"><SelectValue placeholder="Select…" /></SelectTrigger>
            <SelectContent data-testid="dialog-select-content">
              <SelectItem value="yes">Yes</SelectItem>
              <SelectItem value="no">No</SelectItem>
            </SelectContent>
          </Select>
        </DialogContent>
      </Dialog>,
    );

    const menu = screen.getByTestId("dialog-select-content");
    expect(menu.className).toContain("z-[70]");
    expect(screen.getByText("Yes")).toBeTruthy();
    expect(document.querySelector('[data-slot="dialog-content"]')?.className).toContain("z-[60]");
  });
});
