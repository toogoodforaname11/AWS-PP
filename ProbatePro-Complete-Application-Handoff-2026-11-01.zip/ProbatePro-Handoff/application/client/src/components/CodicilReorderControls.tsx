import React from "react";
import { Button } from "@/components/ui/button";

export function CodicilReorderControls({
  fileName,
  index,
  total,
  disabled,
  onMove,
}: {
  fileName: string;
  index: number;
  total: number;
  disabled: boolean;
  onMove: (fromIndex: number, toIndex: number) => void;
}) {
  return (
    <div className="flex shrink-0 items-center gap-0.5" aria-label={`Reorder ${fileName}`}>
      <Button
        variant="ghost"
        size="sm"
        className="h-7 px-2 text-[11px]"
        aria-label={`Move ${fileName} up`}
        title="Move up"
        data-testid={`codicil-move-up-${index}`}
        onClick={() => onMove(index, index - 1)}
        disabled={disabled || index === 0}
      >Up</Button>
      <Button
        variant="ghost"
        size="sm"
        className="h-7 px-2 text-[11px]"
        aria-label={`Move ${fileName} down`}
        title="Move down"
        data-testid={`codicil-move-down-${index}`}
        onClick={() => onMove(index, index + 1)}
        disabled={disabled || index === total - 1}
      >Down</Button>
    </div>
  );
}
