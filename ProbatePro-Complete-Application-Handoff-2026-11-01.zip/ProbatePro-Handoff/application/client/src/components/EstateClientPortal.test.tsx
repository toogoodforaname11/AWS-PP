import React from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
const mocks = vi.hoisted(() => ({
  create: vi.fn(),
  reissue: vi.fn(),
  writeClipboard: vi.fn(() => Promise.resolve()),
  query: vi.fn(),
  review: vi.fn(),
  questions: vi.fn(),
  scoped: "e1",
}));
vi.mock("@/lib/trpc", () => ({
  trpc: {
    useUtils: () => ({ portalAccess: { listAll: { invalidate: vi.fn() } } }),
    estate: {
      list: {
        useQuery: () => ({
          data: [
            {
              id: "e1",
              fileNumber: "01",
              deceasedFirstName: "Fictional",
              deceasedLastName: "Example",
            },
            {
              id: "e2",
              fileNumber: "02",
              deceasedFirstName: "Other",
              deceasedLastName: "Example",
            },
          ],
        }),
      },
    },
    portalAccess: {
      listAll: {
        useQuery: (input: unknown) => {
          mocks.query(input);
          return {
            data: [
              {
                id: "a1",
                estateId: "e1",
                contactName: "Client one",
                email: "one@example.com",
                active: 1,
                expiresAt: Date.now() + 999999,
                createdAt: Date.now(),
              },
              {
                id: "a2",
                estateId: "e2",
                contactName: "Other client",
                email: "two@example.com",
                active: 1,
                expiresAt: Date.now() + 999999,
                createdAt: Date.now(),
              },
            ],
          };
        },
      },
      create: {
        useMutation: (callbacks?: { onSuccess?: (data: { accessToken: string; expiresAt: number }) => void }) => ({
          mutate: (input: unknown) => {
            mocks.create(input);
            callbacks?.onSuccess?.({ accessToken: "issued-access-token", expiresAt: Date.now() + 999999 });
          },
          isPending: false,
        }),
      },
      revoke: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
      extend: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
      reissue: {
        useMutation: (callbacks?: { onSuccess?: (data: { accessToken: string; expiresAt: number }) => void }) => ({
          mutate: (input: unknown, options?: { onSuccess?: (data: { accessToken: string; expiresAt: number }) => void }) => {
            mocks.reissue(input);
            const result = { accessToken: "replacement-access-token", expiresAt: Date.now() + 999999 };
            callbacks?.onSuccess?.(result);
            options?.onSuccess?.(result);
          },
          isPending: false,
        }),
      },
    },
  },
}));
vi.mock("./ClientIntakeReview", () => ({
  ClientIntakeReview: (props: unknown) => {
    mocks.review(props);
    return <div data-testid="scoped-review" />;
  },
}));
vi.mock("./ClientIntakeQuestions", () => ({
  ClientIntakeQuestions: (props: unknown) => {
    mocks.questions(props);
    return <div data-testid="custom-question-authoring" />;
  },
}));
import { EstateClientPortal } from "./EstateClientPortal";
beforeEach(() => {
  vi.clearAllMocks();
  Object.defineProperty(navigator, "clipboard", {
    configurable: true,
    value: { writeText: mocks.writeClipboard },
  });
});
describe("estate Client Portal workspace", () => {
  it("shows only this estate's access links and pins the review to its current revision", () => {
    render(
      <EstateClientPortal
        estateId="e1"
        estate={{ revision: 7 }}
        hasUnsavedChanges
      />
    );
    expect(screen.getByRole("heading", { name: "Client Portal" })).toBeTruthy();
    expect(screen.getByText("Client one")).toBeTruthy();
    expect(screen.queryByText("Other client")).toBeNull();
    expect(mocks.query).toHaveBeenCalledWith({ estateId: "e1" });
    expect(mocks.review).toHaveBeenCalledWith(
      expect.objectContaining({
        estateId: "e1",
        revision: 7,
        hasUnsavedChanges: true,
      })
    );
    expect(mocks.questions).toHaveBeenCalledWith(
      expect.objectContaining({ estateId: "e1", revision: 7 })
    );
  });
  it("creates access for this estate without asking for a different estate", () => {
    render(<EstateClientPortal estateId="e1" estate={{ revision: 7 }} />);
    fireEvent.click(screen.getByRole("button", { name: /grant access/i }));
    expect(screen.queryByText("Select estate...")).toBeNull();
    fireEvent.change(screen.getByPlaceholderText("e.g. John Smith"), {
      target: { value: "Client Test" },
    });
    fireEvent.change(screen.getByPlaceholderText("e.g. john@example.com"), {
      target: { value: "test@example.com" },
    });
    fireEvent.click(
      screen.getByRole("button", { name: /create access link/i })
    );
    expect(mocks.create).toHaveBeenCalledWith({
      estateId: "e1",
      email: "test@example.com",
      contactName: "Client Test",
    });
  });

  it("keeps a newly issued link visible for copying and names replacement explicitly", async () => {
    render(<EstateClientPortal estateId="e1" estate={{ revision: 7 }} />);

    expect(screen.getByRole("button", { name: "Replace client intake link" })).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: /grant access/i }));
    fireEvent.change(screen.getByPlaceholderText("e.g. John Smith"), {
      target: { value: "Client Test" },
    });
    fireEvent.click(screen.getByRole("button", { name: /create access link/i }));

    const issuedUrl = `${window.location.origin}/portal?t=issued-access-token`;
    expect(await screen.findByDisplayValue(issuedUrl)).toBeTruthy();
    expect(mocks.writeClipboard).toHaveBeenCalledWith(issuedUrl);
    fireEvent.click(screen.getByRole("button", { name: "Copy client intake link" }));
    expect(mocks.writeClipboard).toHaveBeenLastCalledWith(issuedUrl);
    expect(mocks.reissue).not.toHaveBeenCalled();
  });
});
