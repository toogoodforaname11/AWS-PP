import React from "react";
import { describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen } from "@testing-library/react";
import {
  FORM_FOCUSED_INTAKE_ACTIVATED_EVENT,
  FORM_FOCUSED_INTAKE_ONBOARDING_STORAGE_KEY,
  FORM_FOCUSED_INTAKE_STORAGE_KEY,
} from "@/hooks/useFormFocusedIntakePreference";

const mocks = vi.hoisted(() => ({
  settings: { formFocusedIntake: false } as any,
  update: vi.fn(),
  setData: vi.fn(),
  invalidate: vi.fn(),
  toastSuccess: vi.fn(),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    settings: {
      get: { useQuery: () => ({ data: mocks.settings, isLoading: false }) },
      update: {
        useMutation: (options: any) => ({
          mutate: (input: any) => {
            mocks.update(input);
            options?.onSuccess?.({}, input);
          },
          isPending: false,
        }),
      },
    },
    useUtils: () => ({ settings: { get: { setData: mocks.setData, invalidate: mocks.invalidate } } }),
  },
}));

vi.mock("sonner", () => ({ toast: { success: mocks.toastSuccess, error: vi.fn() } }));

import {
  AssistantHiddenIndicator,
  canViewAdministratorNavigation,
  FormFocusedIntakeToggle,
  PendingReportAttentionBadge,
  sidebarNavigationItemMotion,
  sidebarMenuItemsForMode,
  shouldFetchDashboardAccountData,
} from "./DashboardLayout";

describe("AssistantHiddenIndicator", () => {
  it("labels the Settings navigation reminder accessibly", () => {
    render(<AssistantHiddenIndicator />);
    expect(screen.getByTestId("chatbot-disabled-nav-indicator").getAttribute("aria-label"))
      .toBe("Assistant is disabled. Enable it from the sidebar control.");
  });

  it("shows the Administrator navigation item only to active administrators", () => {
    expect(canViewAdministratorNavigation({ role: "admin", suspendedAt: null })).toBe(true);
    expect(canViewAdministratorNavigation({ role: "user", suspendedAt: null })).toBe(false);
    expect(canViewAdministratorNavigation({ role: "admin", suspendedAt: Date.now() })).toBe(false);
  });

  it("renders an accessible attention count only when pending reports exist", () => {
    const empty = render(<PendingReportAttentionBadge count={0} />);
    expect(screen.queryByLabelText(/pending report/i)).toBeNull();
    empty.unmount();
    render(<PendingReportAttentionBadge count={3} />);
    expect(screen.getByLabelText("3 pending reports requiring attention").textContent).toBe("3");
  });

  it("does not enable staff-only dashboard queries until a user is present", () => {
    expect(shouldFetchDashboardAccountData(null)).toBe(false);
    expect(shouldFetchDashboardAccountData(undefined)).toBe(false);
    expect(shouldFetchDashboardAccountData({ id: 1 })).toBe(true);
  });

  it("hides Deadlines navigation only in the form-focused workspace", () => {
    expect(sidebarMenuItemsForMode(true).map((item) => item.path)).not.toContain("/deadlines");
    expect(sidebarMenuItemsForMode(false).map((item) => item.path)).toContain("/deadlines");
  });

  it("uses layout-aware enter and exit motion while respecting reduced-motion preferences", () => {
    expect(sidebarNavigationItemMotion(false)).toMatchObject({
      initial: { opacity: 0, x: -8 },
      animate: { opacity: 1, x: 0 },
      exit: { opacity: 0, x: -8 },
      transition: { duration: 0.18 },
    });
    expect(sidebarNavigationItemMotion(true)).toMatchObject({
      initial: false,
      animate: { opacity: 1, x: 0 },
      exit: { opacity: 0 },
      transition: { duration: 0.01 },
    });
  });

  it("persists form-focused Intake from the sidebar and reflects the current mode", () => {
    window.localStorage.removeItem(FORM_FOCUSED_INTAKE_STORAGE_KEY);
    window.localStorage.removeItem(FORM_FOCUSED_INTAKE_ONBOARDING_STORAGE_KEY);
    mocks.settings = { formFocusedIntake: false };
    mocks.update.mockReset();
    mocks.toastSuccess.mockReset();
    const view = render(<FormFocusedIntakeToggle />);

    const intakeControl = screen.getByTestId("sidebar-form-focused-intake-control");
    expect(intakeControl.textContent).toContain("Full Intake");
    expect(intakeControl.getAttribute("data-enabled")).toBe("false");
    expect(screen.getByRole("switch", { name: "Use form-focused intake" }).className).toContain("sidebar-preference-switch");
    fireEvent.click(screen.getByRole("switch", { name: "Use form-focused intake" }));
    expect(mocks.update).toHaveBeenCalledWith({ formFocusedIntake: true });
    expect(mocks.toastSuccess).toHaveBeenCalledWith("Form-focused intake enabled");
    expect(window.localStorage.getItem(FORM_FOCUSED_INTAKE_STORAGE_KEY)).toBe("true");
    mocks.settings = { formFocusedIntake: true };
    view.rerender(<FormFocusedIntakeToggle />);
    expect(screen.getByTestId("sidebar-form-focused-intake-control").getAttribute("data-enabled")).toBe("true");
    expect(screen.getByTestId("form-focused-intake-onboarding").textContent).toMatch(/A cleaner preparation view/i);
    expect(screen.getByTestId("form-focused-intake-onboarding").textContent).toMatch(/every supported form now appears together/i);
    expect(window.localStorage.getItem(FORM_FOCUSED_INTAKE_ONBOARDING_STORAGE_KEY)).toBe("true");
  });

  it("shows the form-focused introduction once and lets the user dismiss it", () => {
    window.localStorage.removeItem(FORM_FOCUSED_INTAKE_STORAGE_KEY);
    window.localStorage.removeItem(FORM_FOCUSED_INTAKE_ONBOARDING_STORAGE_KEY);
    mocks.settings = { formFocusedIntake: false };
    const first = render(<FormFocusedIntakeToggle />);

    fireEvent.click(screen.getByRole("switch", { name: "Use form-focused intake" }));
    fireEvent.click(screen.getByRole("button", { name: /got it/i }));
    expect(screen.queryByTestId("form-focused-intake-onboarding")).toBeNull();
    first.unmount();

    render(<FormFocusedIntakeToggle />);
    window.dispatchEvent(new CustomEvent(FORM_FOCUSED_INTAKE_ACTIVATED_EVENT));
    expect(screen.queryByTestId("form-focused-intake-onboarding")).toBeNull();
  });

  it("anchors the introduction to the compact sidebar control too", () => {
    window.localStorage.removeItem(FORM_FOCUSED_INTAKE_STORAGE_KEY);
    window.localStorage.removeItem(FORM_FOCUSED_INTAKE_ONBOARDING_STORAGE_KEY);
    mocks.settings = { formFocusedIntake: false };
    render(<FormFocusedIntakeToggle compact />);

    fireEvent.click(screen.getByRole("switch", { name: "Use form-focused intake" }));
    expect(screen.getByTestId("form-focused-intake-onboarding")).toBeTruthy();
  });
});
