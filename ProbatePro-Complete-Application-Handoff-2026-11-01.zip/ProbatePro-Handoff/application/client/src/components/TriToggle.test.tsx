/**
 * TriToggle — honest unanswered state (RULES.md Rule 11, 2026-07-22).
 *
 * An unrecorded will-answer must not be painted as a phantom "No". The intake
 * `triField` helper now passes `value={form[key] || ""}` (was `|| "no"`), so a blank
 * value highlights NOTHING until the user actively answers — the honest "unanswered"
 * state that lets the P4 gate legitimately ask for an explicit answer without the UI
 * pretending the question is already answered. This guards against re-adding `|| "no"`.
 */
import { describe, it, expect } from "vitest";
import React from "react";
import { render, screen } from "@testing-library/react";
import { TriToggle } from "./TriToggle";

const SELECTED = "bg-slate-700"; // TriToggle marks the active option with this class
const isSelected = (name: string) =>
  screen.getByRole("button", { name }).className.includes(SELECTED);

describe("TriToggle honest unanswered state", () => {
  it("highlights no option when value is empty (no phantom default)", () => {
    render(<TriToggle value="" onChange={() => {}} options={["na", "yes", "no"]} />);
    expect(isSelected("N/A")).toBe(false);
    expect(isSelected("Yes")).toBe(false);
    expect(isSelected("No")).toBe(false);
  });

  it("highlights only the matching option when value is set", () => {
    render(<TriToggle value="no" onChange={() => {}} options={["na", "yes", "no"]} />);
    expect(isSelected("No")).toBe(true);
    expect(isSelected("Yes")).toBe(false);
    expect(isSelected("N/A")).toBe(false);
  });
});
