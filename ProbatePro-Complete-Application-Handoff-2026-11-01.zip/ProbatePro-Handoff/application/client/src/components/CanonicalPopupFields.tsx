import React from "react";
import type { FormGap } from "../../../shared/formRequirements";
import { applyElectronicWillAxis, electronicWillFacts, estateWillStatus } from "../../../shared/types";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

// UI completion only. These are existing Intake columns, not additions to the
// server's document-override allowlist. The parent saves explicit changes through
// estate.update before re-checking; an unedited control never supplies a fact.
export type CanonicalPopupPatch = Record<string, string | number>;
export interface CanonicalPopupSaveReceipt {
  estateId: string;
  revision?: number;
  record: Record<string, unknown>;
}
export interface CanonicalPopupApplyObserver {
  onSaved: (receipt: CanonicalPopupSaveReceipt) => void;
  onRechecked: () => void;
  /** Newer explicit input must be reviewed before an older all-green check proceeds. */
  hasNewerEdits?: () => boolean;
}
type Option = { value: string; label: string };
type Field = {
  label: string;
  kind: "text" | "textarea" | "date" | "select" | "multi" | "affidavits";
  forms: readonly string[];
  options?: readonly Option[];
  maxRows?: number;
};
const p4 = ["P4"];
const p2p4 = ["P2", "P4"];
const yesNo = [{ value: "yes", label: "Yes" }, { value: "no", label: "No" }];

// Exact existing Intake labels/tokens (EstateDetail.tsx); no new legal choices.
export const POPUP_WESA_S80_OPTIONS = [
  { value: "a", label: "(a) with the law of the place where the will is made," },
  { value: "b", label: "(b) with the law of the will-maker's domicile, either at the date the will is made or at the date of the will-maker's death," },
  { value: "c", label: "(c) with the law of the will-maker's ordinary residence, either at the date the will is made or at the date of the will-maker's death," },
  { value: "d", label: "(d) with the law of a country of which the will-maker was a citizen, either at the date the will is made or at the date of the will-maker's death," },
  { value: "e", label: "(e) with the law of British Columbia, but the will is made outside British Columbia," },
  { value: "f", label: "(f) with the law of the place where the will-maker's property is situated at the date the will is made or at the date of the will-maker's death," },
  { value: "g", label: "(g) in the case of a will made on board a vessel or aircraft of any description, with the law of the place with which, having regard to the registration, if any, of a vessel or aircraft, the vessel or aircraft is most closely connected, or" },
  { value: "h", label: "(h) to the extent that the will exercises a power of appointment, with the law governing the essential validity of that power." },
] as const;

const fields: Record<string, Field> = {
  willStatus: { label: "Will Status", kind: "select", forms: ["P5", "P9", "LETTER", "PGT_INFO"], options: [
    { value: "unknown", label: "Not confirmed" }, { value: "will", label: "Will present" }, { value: "no_will", label: "No will" },
  ] },
  orderFiled: { label: "Court-order filing status", kind: "select", forms: ["P2"], options: [
    { value: "filed", label: "Filed" }, { value: "not_yet_filed", label: "Being filed with this submission" },
  ] },
  referencedDocumentNames: { label: "Name/describe the referenced document(s)", kind: "text", forms: p2p4 },
  referencedDocumentsCannotObtainReason: { label: "Describe the referenced document(s) and why they cannot be obtained", kind: "textarea", forms: p2p4 },
  referencedDocumentsNotTestamentary: { label: "Describe the document(s) and why each is not testamentary", kind: "textarea", forms: p2p4 },
  treatyFirstNationName: { label: "Treaty First Nation Name", kind: "text", forms: ["P2"] },
  interlineationTreatment: { label: "Interlineation treatment", kind: "select", forms: p4, options: [
    { value: "compliant", label: "Made in compliance with WESA Div. 1 Part 4" },
    { value: "authenticated", label: "Authenticated by re-execution or a codicil" },
    { value: "affidavit_evidence", label: "Cannot confirm — affidavit evidence (Rule 25-3 (20)(a))" },
    { value: "no_information", label: "No information as to the will-maker's intentions" },
  ] },
  erasureStatus: { label: "Words erased or obliterated", kind: "select", forms: p4, options: [
    { value: "effaced", label: "Entirely effaced — cannot be ascertained" },
    { value: "readable_mixed", label: "Some readable; none of the boxes below apply to all" },
    { value: "words_erased", label: "Words were erased or obliterated and…" },
  ] },
  erasureTreatments: { label: "Erasure treatments", kind: "multi", forms: p4, options: [
    { value: "compliant", label: "Made in compliance with WESA Div. 1 Part 4" },
    { value: "authenticated", label: "Authenticated by re-execution or a codicil" },
    { value: "should_not_form_part", label: "Should not form part — affidavits (Rule 25-3 (21)(a))" },
    { value: "no_information", label: "No information as to intentions" },
  ] },
  appearanceIssueTypes: { label: "Issues from the appearance of the will", kind: "multi", forms: p4, options: [
    { value: "revocation_attempt", label: "An attempt was made to revoke the will" },
    { value: "missing_attachment", label: "A page/document previously attached is missing" },
    { value: "incomplete", label: "The will is incomplete" },
    { value: "non_compliant_alteration", label: "Altered otherwise than in compliance with WESA" },
    { value: "other", label: "Other (specify)" },
  ] },
  appearanceIssueOther: { label: "Other appearance issue (specify)", kind: "text", forms: p4 },
  militaryWillDescription: { label: "Describe the military service and circumstances (for P4 affidavit)", kind: "textarea", forms: p4 },
  foreignWillSection80Paragraph: { label: "Applicable paragraph of WESA s.80(1)", kind: "select", forms: p4, options: POPUP_WESA_S80_OPTIONS },
  foreignWillAffidavitName: { label: "Supporting affidavit deponent", kind: "text", forms: p4 },
  foreignWillAffidavitDate: { label: "Supporting affidavit sworn date", kind: "date", forms: p4 },
  specialCircumstances: { label: "Special execution circumstances", kind: "multi", forms: p4, options: [
    { value: "none", label: "None" },
    { value: "blind", label: "The will-maker was blind" },
    { value: "illiterate", label: "The will-maker was illiterate" },
    { value: "non_english", label: "The will-maker did not fully understand the language in which the will was written" },
    { value: "signed_by_mark", label: "The will-maker signed by a means of a mark instead of handwritten words" },
    { value: "signed_by_another", label: "The will-maker directed another person to sign the will on behalf of the will-maker in the will-maker's presence" },
  ] },
  specialCircumstancesFollowUp: { label: "How will the circumstance be addressed in the P4 affidavit?", kind: "select", forms: p4, options: [
    { value: "attestation_indicates", label: "The attestation clause in the will indicates that the circumstance applied to the will-maker at the time of the signing of the will." },
    { value: "supporting_affidavits", label: "The following affidavit(s) is/are submitted for filing with the submission for estate grant as evidence that the requirements of the Wills, Estates and Succession Act relating to the execution of the will were met and that the will-maker knew and approved of the content of the will:" },
    { value: "s80_validity", label: "The will is valid as to the formal requirements for making the will and is admissible to probate under section 80 of the Wills, Estates and Succession Act, and the following affidavit(s) confirm that validity:" },
  ] },
  willCopyAffidavit: { label: "Physical-copy supporting affidavit", kind: "affidavits", forms: p4, maxRows: 1 },
  specialCircumstancesAffidavits: { label: "Supporting affidavit(s)", kind: "affidavits", forms: p4 },
  electronicOriginalUnavailableKnowledge: { label: "Basis for explaining why the original electronic form cannot be submitted", kind: "select", forms: p4, options: [
    { value: "first_hand", label: "The deponent has first-hand knowledge of the reason." },
    { value: "affidavit", label: "A separate affidavit explains why a copy is available but the original is not." },
  ] },
  electronicOriginalUnavailableReason: { label: "State the first-hand reason the original electronic form cannot be submitted.", kind: "textarea", forms: p4 },
  electronicOriginalUnavailableAffidavits: { label: "Unavailable-electronic-original affidavit", kind: "affidavits", forms: p4, maxRows: 1 },
  testamentaryDocStatus: { label: "Has a testamentary document dated later than the will been found?", kind: "select", forms: p4, options: [
    { value: "na", label: "N/A" },
    { value: "none_found", label: "No testamentary document dated later than the will has been found." },
    { value: "found", label: "One or more testamentary documents dated later than the will have been found." },
  ] },
  willType: { label: "Type of Will", kind: "select", forms: p4, options: [
    { value: "na", label: "N/A" }, { value: "physical", label: "Physical" }, { value: "electronic", label: "Electronic" },
  ] },
  willAlterationTypes: { label: "P4 §7 — Which of the following are present?", kind: "multi", forms: p4, options: [
    { value: "interlineations", label: "(a) Interlineations" },
    { value: "erasures", label: "(b) Words erased or obliterated" },
    { value: "appearance", label: "(c) Issues from the appearance of the will" },
  ] },
  electronicWillFirstSavedPdf: { label: "Was the will FIRST SAVED in PDF format? (Rule 25-3(3)(a.1)(ii)/(iii))", kind: "select", forms: p4, options: yesNo },
  electronicWillInRepository: { label: "Is the will maintained in a THIRD-PARTY electronic repository? (Rule 25-3(3)(a.1)(iv))", kind: "select", forms: p4, options: yesNo },
  electronicWillOriginalAvailable: { label: "Does the original electronic form exist and is it available to submit? (Rule 25-3(3)(a.1)(i))", kind: "select", forms: p4, options: yesNo },
};

const predicateFields: Record<string, readonly string[]> = {
  p4_rule_25_3_6_diligent_search_unconfirmed: ["testamentaryDocStatus"],
  p4_rule_25_3_6_special_circumstances_unconfirmed: ["specialCircumstances"],
  p4_alteration_details_complete: ["willAlterationTypes"],
  p4_will_medium_answered: ["willType"],
  p4_electronic_copy_format: ["electronicWillFirstSavedPdf", "electronicWillInRepository", "electronicWillOriginalAvailable"],
  p4_will_copy_affidavit_complete: ["willCopyAffidavit"],
  p4_special_circumstances_affidavits_complete: ["specialCircumstancesAffidavits"],
  p4_electronic_original_unavailable_affidavit_complete: ["electronicOriginalUnavailableAffidavits"],
};
const axes = ["electronicWillFirstSavedPdf", "electronicWillInRepository", "electronicWillOriginalAvailable"] as const;
function ownField(column: string): Field | undefined {
  return Object.prototype.hasOwnProperty.call(fields, column) ? fields[column] : undefined;
}
export function canonicalFieldsForGap(formCode: string, gap: FormGap): string[] {
  const direct = gap.missingFields.flatMap(accessor => /^estate\.([A-Za-z][A-Za-z0-9]*)$/.exec(accessor)?.[1] ?? []);
  const hints = Object.prototype.hasOwnProperty.call(predicateFields, gap.requirementId) ? predicateFields[gap.requirementId] : [];
  return Array.from(new Set([...direct, ...hints])).filter(column => ownField(column)?.forms.includes(formCode));
}
function tokens(value: unknown): string[] {
  return String(value ?? "").split(",").map(value => value.trim()).filter(Boolean);
}
export function canonicalFieldValue(record: Record<string, unknown>, column: string): string {
  if (column === "willStatus") return estateWillStatus(record as any);
  if (column === "willType") return String(record.willType || (record.isElectronicWill ? "electronic" : ""));
  if ((axes as readonly string[]).includes(column)) {
    const value = electronicWillFacts(record as any);
    return column === "electronicWillFirstSavedPdf" ? value.firstSavedPdf
      : column === "electronicWillInRepository" ? value.inRepository : value.originalAvailable;
  }
  return String(record[column] ?? "");
}

export const CANONICAL_APPEARANCE_DETAILS: ReadonlySet<string> = new Set([
  "appearanceIssueTypes", "appearanceIssueOther", "appearanceAffidavits",
]);

// Visibility mirrors existing Intake follow-ups. It never changes a server gap,
// its severity, or generation permission. A stale row instead asks for re-check.
export function canonicalFieldActive(column: string, record: Record<string, unknown>, clearingAppearance = false): boolean {
  if (clearingAppearance && CANONICAL_APPEARANCE_DETAILS.has(column)) return false;
  const is = (key: string, allowed: readonly string[]) => !String(record[key] ?? "") || allowed.includes(String(record[key]));
  if (column === "referencedDocumentNames") return is("referencedDocuments", ["filed", "yes"]);
  if (column === "referencedDocumentsCannotObtainReason") return is("referencedDocuments", ["cannot_be_obtained"]);
  if (column === "referencedDocumentsNotTestamentary") return is("referencedDocuments", ["not_testamentary"]);
  if (column === "erasureTreatments") return is("erasureStatus", ["words_erased"]);
  if (column === "appearanceIssueOther") return !String(record.appearanceIssueTypes ?? "") || tokens(record.appearanceIssueTypes).includes("other");
  if (column === "militaryWillDescription") return is("isMilitaryWill", ["yes"]);
  if (column.startsWith("foreignWill")) return is("foreignWillStatus", ["foreign_non_compliant"]);
  if (column === "specialCircumstancesFollowUp" || column === "specialCircumstancesAffidavits") {
    if (record.specialCircumstances === "none") return false;
    return column !== "specialCircumstancesAffidavits" || record.specialCircumstancesFollowUp !== "attestation_indicates";
  }
  if (column === "willCopyAffidavit") return is("willCopyKnowledge", ["affidavit"]);
  if (column === "electronicOriginalUnavailableReason") return is("electronicOriginalUnavailableKnowledge", ["first_hand"]);
  if (column === "electronicOriginalUnavailableAffidavits") return is("electronicOriginalUnavailableKnowledge", ["affidavit"]);
  return true;
}

type AffidavitRow = Record<string, unknown> & { name: string; sworn: string };
function parseAffidavits(value: string): AffidavitRow[] | null {
  if (!value) return [];
  try {
    const rows: unknown = JSON.parse(value);
    if (!Array.isArray(rows) || rows.some(row => !row || typeof row !== "object" || Array.isArray(row)
      || typeof row.name !== "string" || typeof row.sworn !== "string")) return null;
    return rows;
  } catch { return null; }
}
function savedValue(column: string, value: string): string | null {
  const field = ownField(column);
  if (!field) return null;
  if (field.kind === "select" && value && !field.options?.some(option => option.value === value)) return null;
  if (field.kind === "multi" && tokens(value).some(token => !field.options?.some(option => option.value === token))) return null;
  if (field.kind !== "affidavits") return value;
  const rows = parseAffidavits(value);
  if (!rows) return null; // never silently erase an unrecognized stored list
  const nonempty = rows.filter(row => row.name || row.sworn);
  return nonempty.length ? JSON.stringify(nonempty) : "";
}
export function canonicalDraftMatchesRecord(column: string, raw: string, record: Record<string, unknown>): boolean {
  const value = savedValue(column, raw);
  return value !== null && value === canonicalFieldValue(record, column);
}
function validatedDrafts(drafts: Record<string, string>, offered: ReadonlySet<string>): Record<string, string> {
  const valid: Record<string, string> = {};
  for (const [column, raw] of Object.entries(drafts)) {
    if (!offered.has(column)) continue;
    const value = savedValue(column, raw);
    if (value !== null) valid[column] = value;
  }
  return valid;
}
export function canonicalAppearanceRemoval(drafts: Record<string, string>, seed: Record<string, unknown>, offered: ReadonlySet<string>, pending = false): boolean {
  const valid = validatedDrafts(drafts, offered);
  return Object.prototype.hasOwnProperty.call(valid, "willAlterationTypes")
    && (pending || tokens(seed.willAlterationTypes).includes("appearance"))
    && !tokens(valid.willAlterationTypes).includes("appearance");
}
function coupledAxisValues(record: Record<string, unknown>, drafts: Record<string, string>): CanonicalPopupPatch {
  // Snapshot explicit edits before the helper returns sibling keys. Resolve the
  // legacy facts from the PRE-draft record, exactly as the existing Intake does.
  const explicit = axes.filter(axis => Object.prototype.hasOwnProperty.call(drafts, axis)).map(axis => [axis, drafts[axis]] as const);
  let current = { ...record };
  const values: CanonicalPopupPatch = {};
  for (const [axis, value] of explicit) {
    const next = applyElectronicWillAxis(current as any, axis, value);
    Object.assign(values, next);
    current = { ...current, ...next };
  }
  return values;
}
export function canonicalPopupRecord(record: Record<string, unknown>, drafts: Record<string, string>, offered: ReadonlySet<string>, filingMedium?: CanonicalPopupPatch): Record<string, unknown> {
  const valid = validatedDrafts(drafts, offered);
  return { ...record, ...valid, ...coupledAxisValues(record, valid), ...filingMedium };
}
export function canonicalPopupPatch(
  drafts: Record<string, string>,
  seed: Record<string, unknown>,
  offered: ReadonlySet<string>,
  record: Record<string, unknown>,
  uncertainColumns: ReadonlySet<string> = new Set(),
  filingMedium?: CanonicalPopupPatch,
  pendingAppearanceRemoval = false,
): CanonicalPopupPatch {
  const patch: CanonicalPopupPatch = {};
  const valid = validatedDrafts(drafts, offered);
  const clearingAppearance = pendingAppearanceRemoval || canonicalAppearanceRemoval(drafts, seed, offered);
  const visible = canonicalPopupRecord(record, valid, offered, filingMedium);
  for (const [column, rawValue] of Object.entries(valid)) {
    const value = column === "willType" && filingMedium ? String(filingMedium.willType) : rawValue;
    if (!canonicalFieldActive(column, visible, clearingAppearance)
      || (value === canonicalFieldValue(seed, column) && !uncertainColumns.has(column)
        && !(column === "willAlterationTypes" && clearingAppearance))) continue;
    patch[column] = value;
  }
  if (Object.prototype.hasOwnProperty.call(patch, "willStatus")) patch.hasWill = patch.willStatus === "no_will" ? 0 : 1;
  if (Object.prototype.hasOwnProperty.call(patch, "willType")) patch.isElectronicWill = patch.willType === "electronic" ? 1 : 0;
  if (axes.some(axis => Object.prototype.hasOwnProperty.call(patch, axis))) {
    Object.assign(patch, coupledAxisValues(record, valid));
  }
  if (Object.prototype.hasOwnProperty.call(patch, "willAlterationTypes") && clearingAppearance) {
    Object.assign(patch, { appearanceIssueTypes: "", appearanceIssueOther: "", appearanceAffidavits: "" });
  }
  return patch;
}

export function CanonicalPopupField({ column, value, record, onChange, disabled = false, description, clearingAppearance = false }: {
  column: string;
  value: string;
  record: Record<string, unknown>;
  onChange: (value: string) => void;
  disabled?: boolean;
  description?: string;
  clearingAppearance?: boolean;
}): React.JSX.Element | null {
  const field = ownField(column);
  if (!field || !canonicalFieldActive(column, record, clearingAppearance)) return null;
  const id = `pre-generate-canonical-${column}`;
  if (field.kind === "multi") {
    const selected = tokens(value);
    return <fieldset className="min-w-0 space-y-2" data-testid={id}>
      <legend className="text-xs font-medium">{field.label}</legend>
      {field.options!.map(option => <Label key={option.value} htmlFor={`${id}-${option.value}`} className="flex items-start gap-2 text-xs font-normal leading-relaxed">
        <Checkbox id={`${id}-${option.value}`} className="mt-0.5 shrink-0" checked={selected.includes(option.value)} onCheckedChange={checked => {
          if (column === "specialCircumstances" && option.value === "none") { onChange("none"); return; }
          const current = column === "specialCircumstances" ? selected.filter(token => token !== "none") : selected;
          const next = checked === true ? Array.from(new Set([...current, option.value])) : current.filter(token => token !== option.value);
          onChange(next.join(","));
        }} />
        <span className="min-w-0 break-words">{option.label}</span>
      </Label>)}
    </fieldset>;
  }
  if (field.kind === "affidavits") {
    const parsed = parseAffidavits(value);
    if (parsed === null) return <div className="space-y-2" data-testid={id}>
      <p className="text-xs">The stored affidavit list could not be read. It has not been changed.</p>
      <Button type="button" variant="outline" size="sm" onClick={() => onChange("")}>Replace this unreadable list</Button>
    </div>;
    const rows = parsed.length ? parsed : [{ name: "", sworn: "" }];
    const change = (index: number, key: "name" | "sworn", next: string) => onChange(JSON.stringify(rows.map((row, i) => i === index ? { ...row, [key]: next } : row)));
    return <fieldset className="min-w-0 space-y-3" data-testid={id}>
      <legend className="text-xs font-medium">{field.label}</legend>
      {rows.map((row, index) => <div key={index} className="grid min-w-0 grid-cols-1 gap-2 rounded-md border border-border/60 p-2 sm:grid-cols-[minmax(0,1fr)_9rem_auto]">
        <div className="min-w-0 space-y-1"><Label htmlFor={`${id}-${index}-name`} className="text-xs">Affidavit of (name)</Label><Input id={`${id}-${index}-name`} value={row.name} onChange={event => change(index, "name", event.target.value)} /></div>
        <div className="min-w-0 space-y-1"><Label htmlFor={`${id}-${index}-sworn`} className="text-xs">Date sworn</Label><Input id={`${id}-${index}-sworn`} type="date" value={row.sworn} onChange={event => change(index, "sworn", event.target.value)} /></div>
        <Button type="button" variant="ghost" size="sm" className="self-end" aria-label={`Remove affidavit ${index + 1}`} onClick={() => onChange(JSON.stringify(rows.filter((_, i) => i !== index)))}>Remove</Button>
      </div>)}
      {(!field.maxRows || rows.length < field.maxRows) && <Button type="button" variant="outline" size="sm" onClick={() => onChange(JSON.stringify([...rows, { name: "", sworn: "" }]))}>Add affidavit</Button>}
    </fieldset>;
  }
  return <div className="min-w-0 space-y-1">
    <Label htmlFor={id} className="text-xs">{field.label}</Label>
    {field.kind === "select" ? <Select value={value || undefined} onValueChange={onChange} disabled={disabled}>
      <SelectTrigger id={id} data-testid={id} aria-describedby={description ? `${id}-description` : undefined} className="h-auto min-h-10 w-full text-left [&>span]:min-w-0 [&>span]:whitespace-normal [&>span]:break-words"><SelectValue placeholder="Select…" /></SelectTrigger>
      <SelectContent className="max-w-[calc(100vw-2rem)]">
        {field.options!.map(option => <SelectItem key={option.value} value={option.value} className="whitespace-normal break-words">{option.label}</SelectItem>)}
      </SelectContent>
    </Select> : field.kind === "textarea"
      ? <Textarea id={id} data-testid={id} value={value} onChange={event => onChange(event.target.value)} rows={3} />
      : <Input id={id} data-testid={id} type={field.kind === "date" ? "date" : "text"} value={value} onChange={event => onChange(event.target.value)} />}
    {description && <p id={`${id}-description`} className="text-xs text-muted-foreground">{description}</p>}
  </div>;
}
