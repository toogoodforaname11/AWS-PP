import React from "react";
import { act, fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  clientIntakePayloadSchema,
  type ClientIntakePayload,
  type ClientIntakeSelection,
} from "@shared/clientIntake";

const mocks = vi.hoisted(() => ({
  approve: vi.fn(),
  undo: vi.fn(),
  requestRevision: vi.fn(),
  exportPdf: vi.fn(() => "client-intake-jordan-1970-01-01.pdf"),
  toastSuccess: vi.fn(),
  toastError: vi.fn(),
  invalidateSubmissions: vi.fn(),
  invalidateEstate: vi.fn(),
  invalidateEstateList: vi.fn(),
  invalidateReadiness: vi.fn(),
  data: undefined as unknown,
  isLoading: false,
  approvePending: false,
  approveOptions: undefined as
    | undefined
    | {
        onSuccess?: (result: { revision: number }) => void;
        onError?: (error: { message: string }) => void;
      },
  undoOptions: undefined as
    | undefined
    | {
        onSuccess?: (result: { revision: number }) => void;
        onError?: (error: { message: string }) => void;
      },
}));

vi.mock("sonner", () => ({
  toast: { success: mocks.toastSuccess, error: mocks.toastError },
}));

vi.mock("@/lib/clientIntakePdf", () => ({
  exportCompletedClientIntakePdf: mocks.exportPdf,
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    useUtils: () => ({
      clientIntake: {
        listForEstate: { invalidate: mocks.invalidateSubmissions },
      },
      estate: {
        get: { invalidate: mocks.invalidateEstate },
        list: { invalidate: mocks.invalidateEstateList },
      },
      readiness: { check: { invalidate: mocks.invalidateReadiness } },
    }),
    clientIntake: {
      listForEstate: {
        useQuery: () => ({ data: mocks.data, isLoading: mocks.isLoading }),
      },
      approve: {
        useMutation: (options: {
          onSuccess?: (result: { revision: number }) => void;
          onError?: (error: { message: string }) => void;
        }) => {
          mocks.approveOptions = options;
          return { mutate: mocks.approve, isPending: mocks.approvePending };
        },
      },
      undoLastApplication: {
        useMutation: (options: {
          onSuccess?: (result: { revision: number }) => void;
          onError?: (error: { message: string }) => void;
        }) => {
          mocks.undoOptions = options;
          return { mutate: mocks.undo, isPending: false };
        },
      },
      requestRevision: {
        useMutation: () => ({
          mutate: mocks.requestRevision,
          isPending: false,
        }),
      },
    },
  },
}));

import { ClientIntakeReview } from "./ClientIntakeReview";

function payload(overrides: Partial<ClientIntakePayload> = {}) {
  return clientIntakePayloadSchema.parse({
    deceasedFirstName: "Avery",
    willStatus: "unknown",
    executors: [],
    familyMembers: [],
    estateItems: [],
    ...overrides,
  });
}

function submission(
  overrides: Partial<{
    id: string;
    status: string;
    payload: ClientIntakePayload;
    approvedFields: ClientIntakeSelection[];
    submittedAt: number;
  }> = {}
) {
  return {
    id: "submission-1",
    status: "submitted",
    payload: payload(),
    reviewNotes: "",
    revisionRequest: "",
    revisionFieldComments: [],
    submittedByName: "Jordan",
    submittedByEmail: "jordan@example.com",
    submittedAt: 1,
    approvedFields: [],
    ...overrides,
  };
}

describe("ClientIntakeReview", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.data = [submission()];
    mocks.isLoading = false;
    mocks.approvePending = false;
    mocks.approveOptions = undefined;
    mocks.undoOptions = undefined;
  });

  it("blocks all apply controls until existing Intake edits are saved or discarded", () => {
    render(
      <ClientIntakeReview estateId="estate-1" revision={4} hasUnsavedChanges />
    );
    expect(
      screen.getByText(/Save or discard the current Intake edits/i)
    ).toBeTruthy();
    expect(
      screen
        .getByRole("button", { name: /approve selected facts/i })
        .hasAttribute("disabled")
    ).toBe(true);
    expect(
      screen
        .getByRole("button", { name: "Apply Deceased first name" })
        .hasAttribute("disabled")
    ).toBe(true);
    expect(
      screen
        .getByRole("button", { name: "Apply all ready facts" })
        .hasAttribute("disabled")
    ).toBe(true);
  });

  it("uses the confirmed revision for an immediate second client-fact application", () => {
    mocks.data = [
      submission({
        payload: payload({ dateOfDeath: "2025-02-02" }),
      }),
    ];
    render(<ClientIntakeReview estateId="estate-1" revision={4} />);

    fireEvent.click(
      screen.getByRole("button", { name: "Apply Deceased first name" })
    );
    expect(mocks.approve).toHaveBeenLastCalledWith(
      expect.objectContaining({ expectedRevision: 4 })
    );

    act(() => mocks.approveOptions?.onSuccess?.({ revision: 5 }));
    fireEvent.click(screen.getByRole("button", { name: "Apply Date of death" }));

    expect(mocks.approve).toHaveBeenLastCalledWith(
      expect.objectContaining({ expectedRevision: 5 })
    );
  });

  it("opens the newest submission even when an older pending record arrives first", () => {
    mocks.data = [
      submission({
        id: "submission-older",
        submittedAt: 100,
        payload: payload({ deceasedFirstName: "Older report" }),
      }),
      submission({
        id: "submission-newer",
        submittedAt: 200,
        payload: payload({ deceasedFirstName: "Newest report" }),
      }),
    ];

    render(<ClientIntakeReview estateId="estate-1" revision={4} />);

    expect(screen.getByText("Newest report")).toBeTruthy();
    expect(screen.queryByText("Older report")).toBeNull();
  });

  it("shows submitted custom answers as review-only context without an Apply control", () => {
    mocks.data = [
      submission({
        payload: payload({
          customQuestions: [
            {
              id: "cq_propertyfact1",
              prompt: "Who has keys to the property?",
              helpText: "",
              required: true,
              answer: "Jordan Morgan",
            },
          ],
        }),
      }),
    ];
    render(<ClientIntakeReview estateId="estate-1" revision={4} />);
    expect(
      screen.getByText("Case-specific response · Who has keys to the property?")
    ).toBeTruthy();
    expect(screen.getByText("Jordan Morgan")).toBeTruthy();
    expect(
      screen.queryByRole("button", { name: /apply.*keys to the property/i })
    ).toBeNull();
  });

  it("offers a scoped Undo only for the submission's most recent saved application", () => {
    mocks.data = [
      submission({
        approvedFields: ["deceasedFirstName"],
        undoAvailable: true,
      } as any),
    ];
    render(<ClientIntakeReview estateId="estate-1" revision={5} />);

    fireEvent.click(
      screen.getByRole("button", { name: "Undo last applied client facts" })
    );
    expect(mocks.undo).toHaveBeenCalledWith({
      estateId: "estate-1",
      submissionId: "submission-1",
      expectedRevision: 5,
    });
  });

  it("confirms a successful undo with a concise success toast", () => {
    mocks.data = [
      submission({
        approvedFields: ["deceasedFirstName"],
        undoAvailable: true,
      } as any),
    ];
    render(<ClientIntakeReview estateId="estate-1" revision={5} />);

    act(() => mocks.undoOptions?.onSuccess?.({ revision: 6 }));

    expect(mocks.toastSuccess).toHaveBeenCalledWith(
      "Client facts restored",
      expect.objectContaining({
        description:
          "The most recent verified client details are back in review.",
        duration: 5000,
      })
    );
  });

  it("downloads the selected client submission as a PDF without applying any facts", () => {
    const activeSubmission = submission({
      payload: payload({
        clientName: "Jordan Morgan",
        customQuestions: [
          {
            id: "cq_propertyfact1",
            prompt: "Who has keys to the property?",
            helpText: "",
            required: true,
            answer: "Jordan Morgan",
          },
        ],
      }),
    });
    mocks.data = [activeSubmission];
    render(<ClientIntakeReview estateId="estate-1" revision={5} />);

    fireEvent.click(
      screen.getByRole("button", { name: "Download client intake PDF" })
    );

    expect(mocks.exportPdf).toHaveBeenCalledWith({
      payload: activeSubmission.payload,
      submittedByName: "Jordan",
      submittedAt: 1,
    });
    expect(mocks.approve).not.toHaveBeenCalled();
    expect(mocks.undo).not.toHaveBeenCalled();
  });

  it("organizes pending review around a visible decision summary and comparison columns", () => {
    mocks.data = [
      submission({
        payload: payload({
          customQuestions: [
            {
              id: "cq_propertyfact1",
              prompt: "Who has keys to the property?",
              helpText: "",
              required: true,
              answer: "Jordan Morgan",
            },
          ],
        }),
      }),
    ];
    render(<ClientIntakeReview estateId="estate-1" revision={4} />);

    expect(
      screen.getByRole("heading", { name: "Ready for review" })
    ).toBeTruthy();
    expect(screen.getByText("0 facts selected")).toBeTruthy();
    expect(
      screen.getByRole("heading", { name: "Compare reported facts" })
    ).toBeTruthy();
    expect(screen.getByText("Client report")).toBeTruthy();
    expect(screen.getByText("Current Intake")).toBeTruthy();
    expect(screen.getByText("Decision")).toBeTruthy();
    expect(screen.getByText("Review-only context")).toBeTruthy();

    fireEvent.click(
      screen.getByRole("checkbox", {
        name: "Select Deceased first name for approval",
      })
    );
    expect(screen.getByText("1 fact selected")).toBeTruthy();
    expect(
      screen.getByRole("button", { name: "Approve selected facts" }).textContent
    ).toContain("Apply 1 selected");
    expect(
      screen.queryByRole("button", { name: /apply.*keys to the property/i })
    ).toBeNull();
  });

  it("applies exactly one field with the estate and revision scope", () => {
    render(
      <ClientIntakeReview
        estateId="estate-1"
        revision={4}
        currentEstate={{ deceasedFirstName: "Earlier name" }}
      />
    );
    expect(screen.getByText("Earlier name")).toBeTruthy();
    fireEvent.click(
      screen.getByRole("button", { name: "Apply Deceased first name" })
    );
    expect(mocks.approve).toHaveBeenCalledWith({
      estateId: "estate-1",
      submissionId: "submission-1",
      expectedRevision: 4,
      approvedFields: ["deceasedFirstName"],
      reviewNotes: "",
    });
  });

  it("shows separately reported alias parts with their matching current Intake fields", () => {
    mocks.data = [
      submission({
        payload: payload({
          deceasedAkaFirstName: "Taylor",
          deceasedAkaMiddleName: "Jordan",
          deceasedAkaLastName: "Morgan",
        }),
      }),
    ];
    render(
      <ClientIntakeReview
        estateId="estate-1"
        revision={4}
        currentEstate={{
          akaFirstName: "Earlier",
          akaMiddleName: "",
          akaLastName: "Name",
        }}
      />
    );

    expect(
      screen.getAllByText("Other name first name").length
    ).toBeGreaterThan(0);
    expect(
      screen.getAllByText("Other name middle name(s)").length
    ).toBeGreaterThan(0);
    expect(
      screen.getAllByText("Other name last name").length
    ).toBeGreaterThan(0);
    expect(screen.getByText("Earlier")).toBeTruthy();
    expect(screen.getByText("Name")).toBeTruthy();
    fireEvent.click(
      screen.getByRole("button", { name: "Apply Other name first name" })
    );
    expect(mocks.approve).toHaveBeenCalledWith(
      expect.objectContaining({
        approvedFields: ["deceasedAkaFirstName"],
      })
    );
  });

  it("uses readable labels for reported and current Intake enum values", () => {
    mocks.data = [
      submission({
        payload: payload({
          willStatus: "will",
          treatyFirstNation: "nisga",
          estateItems: [
            {
              category: "financial",
              description: "Savings account",
              location: "in_bc",
              value: "12000",
              bankAddress: "",
              accountNumber: "",
              accountHolder: "",
              pid: "",
              legalDescription: "",
              registeredOwner: "",
              ownershipDetails: "",
            },
          ],
        }),
      }),
    ];
    render(
      <ClientIntakeReview
        estateId="estate-1"
        revision={4}
        currentEstate={{ willStatus: "no_will", treatyFirstNation: "nisga" }}
      />
    );

    expect(screen.getByText("Will present")).toBeTruthy();
    expect(screen.getByText("No will")).toBeTruthy();
    expect(screen.getAllByText("Yes — Nisga’a citizen")).toHaveLength(2);
    expect(screen.getByText("In British Columbia")).toBeTruthy();
    expect(screen.getByText("$12,000.00")).toBeTruthy();
    expect(screen.queryByText("in_bc")).toBeNull();
    expect(screen.queryByText("no_will")).toBeNull();
  });

  it("applies all eligible, unapplied scalar and collection fields", () => {
    mocks.data = [
      submission({
        payload: payload({
          deceasedFirstName: "Avery",
          deceasedLastName: "Stone",
          clientName: "Jordan Client",
          clientEmail: "jordan@example.com",
          executors: [
            {
              name: "Morgan Executor",
              relationship: "friend",
              age: "",
              occupation: "",
              address: "",
              email: "",
              phone: "",
              category: "executor",
            },
          ],
          familyMembers: [
            {
              name: "Casey Family",
              relationship: "child",
              age: "12",
              occupation: "student",
              address: "",
              email: "casey@example.com",
              phone: "",
              category: "child",
            },
          ],
          estateItems: [
            {
              category: "financial",
              description: "Savings account",
              location: "in_bc",
              value: "12000",
              bankAddress: "",
              accountNumber: "",
              accountHolder: "",
              pid: "",
              legalDescription: "",
              registeredOwner: "",
              ownershipDetails: "",
            },
          ],
        }),
        approvedFields: ["deceasedFirstName", "executors.0.name"],
      }),
    ];
    render(<ClientIntakeReview estateId="estate-1" revision={9} />);
    fireEvent.click(
      screen.getByRole("button", { name: "Apply all ready facts" })
    );
    expect(mocks.approve).toHaveBeenCalledWith({
      estateId: "estate-1",
      submissionId: "submission-1",
      expectedRevision: 9,
      reviewNotes: "",
      approvedFields: [
        "deceasedLastName",
        "client.name",
        "client.email",
        "executors.0.relationship",
        "familyMembers.0.name",
        "familyMembers.0.relationship",
        "familyMembers.0.occupation",
        "familyMembers.0.email",
        "estateItems.0.description",
        "estateItems.0.location",
        "estateItems.0.value",
      ],
    });
    expect(
      screen.getByLabelText("Deceased first name already applied")
    ).toBeTruthy();
    expect(
      screen.getByLabelText("Morgan Executor · Full name already applied")
    ).toBeTruthy();
  });

  it("requires contact name and inventory description before individually applying dependent fields", () => {
    mocks.data = [
      submission({
        payload: payload({
          executors: [
            {
              name: "Morgan Executor",
              relationship: "friend",
              age: "",
              occupation: "",
              address: "",
              email: "",
              phone: "",
              category: "executor",
            },
          ],
          estateItems: [
            {
              category: "financial",
              description: "Savings account",
              location: "in_bc",
              value: "12000",
              bankAddress: "",
              accountNumber: "",
              accountHolder: "",
              pid: "",
              legalDescription: "",
              registeredOwner: "",
              ownershipDetails: "",
            },
          ],
        }),
      }),
    ];
    render(<ClientIntakeReview estateId="estate-1" revision={4} />);
    expect(
      screen
        .getByRole("button", {
          name: "Apply full name first before applying Morgan Executor · Relationship",
        })
        .hasAttribute("disabled")
    ).toBe(true);
    expect(
      screen
        .getByRole("button", {
          name: "Apply item description first before applying Savings account · Estimated value",
        })
        .hasAttribute("disabled")
    ).toBe(true);
  });

  it("disables all apply actions while an approval mutation is pending", () => {
    mocks.approvePending = true;
    render(<ClientIntakeReview estateId="estate-1" revision={4} />);
    expect(
      screen
        .getByRole("button", { name: "Apply Deceased first name" })
        .hasAttribute("disabled")
    ).toBe(true);
    expect(
      screen
        .getByRole("button", { name: "Applying…" })
        .hasAttribute("disabled")
    ).toBe(true);
    expect(
      screen
        .getByRole("button", { name: /approve selected facts/i })
        .hasAttribute("disabled")
    ).toBe(true);
  });

  it("surfaces an approval conflict and refreshes the scoped submission list", () => {
    render(<ClientIntakeReview estateId="estate-1" revision={4} />);
    act(() =>
      mocks.approveOptions?.onError?.({
        message: "Intake revision conflict. Refresh and try again.",
      })
    );
    expect(screen.getByRole("alert").textContent).toContain(
      "Intake revision conflict"
    );
    expect(mocks.invalidateSubmissions).toHaveBeenCalledWith({
      estateId: "estate-1",
    });
  });

  it("keeps the selected-facts flow opt-in and allows an identity with its dependent field in the same batch", () => {
    mocks.data = [
      submission({
        payload: payload({
          executors: [
            {
              name: "Morgan Executor",
              relationship: "friend",
              age: "",
              occupation: "",
              address: "",
              email: "",
              phone: "",
              category: "executor",
            },
          ],
        }),
      }),
    ];
    render(<ClientIntakeReview estateId="estate-1" revision={4} />);
    expect(
      screen
        .getByRole("button", { name: /approve selected facts/i })
        .hasAttribute("disabled")
    ).toBe(true);
    fireEvent.click(
      screen.getByRole("checkbox", {
        name: "Select Morgan Executor · Full name for approval",
      })
    );
    fireEvent.click(
      screen.getByRole("checkbox", {
        name: "Select Morgan Executor · Relationship for approval",
      })
    );
    fireEvent.click(
      screen.getByRole("button", { name: /approve selected facts/i })
    );
    expect(mocks.approve).toHaveBeenCalledWith({
      estateId: "estate-1",
      submissionId: "submission-1",
      expectedRevision: 4,
      approvedFields: ["executors.0.name", "executors.0.relationship"],
      reviewNotes: "",
    });
  });

  it("shows a concise empty state when the estate has no submissions", () => {
    mocks.data = [];
    render(<ClientIntakeReview estateId="estate-1" revision={4} />);
    expect(screen.getByText("No client submissions")).toBeTruthy();
  });

  it("sends a specific client-visible request through the secure revision procedure", () => {
    render(<ClientIntakeReview estateId="estate-1" revision={4} />);
    fireEvent.change(screen.getByLabelText(/general request for revisions/i), {
      target: { value: "Please confirm the original will location." },
    });
    fireEvent.click(screen.getByRole("button", { name: /request revisions/i }));
    expect(mocks.requestRevision).toHaveBeenCalledWith({
      estateId: "estate-1",
      submissionId: "submission-1",
      revisionRequest: "Please confirm the original will location.",
      revisionFieldComments: [],
    });
  });

  it("sends an allowlisted field-specific comment without requiring a general request", () => {
    render(<ClientIntakeReview estateId="estate-1" revision={4} />);
    fireEvent.change(screen.getByLabelText("Deceased first name"), {
      target: {
        value: "Please confirm the spelling shown on the death certificate.",
      },
    });
    fireEvent.click(screen.getByRole("button", { name: /request revisions/i }));
    expect(mocks.requestRevision).toHaveBeenCalledWith({
      estateId: "estate-1",
      submissionId: "submission-1",
      revisionRequest: "",
      revisionFieldComments: [
        {
          field: "deceasedFirstName",
          comment:
            "Please confirm the spelling shown on the death certificate.",
        },
      ],
    });
  });
});
