import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { checkFormRequirements } from "../../../shared/formRequirements";
import { coupleWillFilingTypeFacts } from "../../../shared/types";
import { PreGenerateDialog } from "./PreGenerateDialog";

function mount() {
  const estate: any = {
    id: "fictional-filing-composition", revision: 1, hasWill: 1, willStatus: "will",
    willType: "", isElectronicWill: 0, willFilingType: "", grantType: "grant_of_probate",
  };
  const report = checkFormRequirements("P4", { estate, contacts: [], inventory: [], requiredDocuments: [], requiredCatalog: [] });
  expect(report.gaps.some(gap => gap.requirementId === "p4_rule_25_3_6_will_filing_type_unconfirmed")).toBe(true);
  expect(report.gaps.some(gap => gap.requirementId === "p4_will_medium_answered")).toBe(true);
  const apply = vi.fn().mockResolvedValue(true);
  render(<PreGenerateDialog open formName="P4" reports={[report]} estate={estate} contacts={[]}
    inlineEditingEnabled onApplyInline={apply} onProceed={vi.fn()} onOpenChange={vi.fn()} onCancel={vi.fn()} onJumpToTab={vi.fn()} />);
  return { apply, estate };
}
const medium = () => screen.getByTestId("pre-generate-canonical-willType");
async function choose(id: string, label: string) {
  fireEvent.click(screen.getByTestId(id));
  fireEvent.click(await screen.findByRole("option", { name: label }));
}
beforeEach(() => {
  cleanup();
  for (const [key, value] of Object.entries({ hasPointerCapture: (): boolean => false, setPointerCapture: (): void => {}, releasePointerCapture: (): void => {}, scrollIntoView: (): void => {} })) {
    Object.defineProperty(Element.prototype, key, { value, configurable: true });
  }
});
afterEach(cleanup);

describe("P4 popup composition against actual unchanged requirements", () => {
  it("shows the existing coupled medium after an original filing choice rather than an apparently missing independent answer", async () => {
    const h = mount();
    await choose("pre-generate-input-willFilingType", "The electronic original.");
    expect(medium().textContent).toContain("Electronic");
    expect((medium() as HTMLButtonElement).disabled).toBe(true);
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(1));
    const values = h.apply.mock.calls[0][0];
    expect(coupleWillFilingTypeFacts(values, h.estate)).toMatchObject({ willType: "electronic", isElectronicWill: 1 });
  });

  it("displays and submits the same coupled answer when the user picked a medium before the original filing type", async () => {
    const h = mount();
    await choose("pre-generate-canonical-willType", "Physical");
    await choose("pre-generate-input-willFilingType", "The electronic original.");
    expect(medium().textContent).toContain("Electronic");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(1));
    const call = h.apply.mock.calls[0];
    const submitted = { ...coupleWillFilingTypeFacts(call[0]), ...call[5] };
    expect(submitted).toMatchObject({ willType: "electronic", isElectronicWill: 1 });
    expect(coupleWillFilingTypeFacts(submitted, h.estate)).toEqual(submitted);
  });

  it("retains the explicit medium when a copy is chosen, without inferring a new medium", async () => {
    const h = mount();
    await choose("pre-generate-canonical-willType", "Physical");
    await choose("pre-generate-input-willFilingType", "The electronic original.");
    await choose("pre-generate-input-willFilingType", "A copy (original lost/destroyed).");
    expect(medium().textContent).toContain("Physical");
    expect((medium() as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(1));
    expect(h.apply.mock.calls[0][5]).toMatchObject({ willType: "physical", isElectronicWill: 0 });
  });

  it("keeps the explicit medium when the user switches to copy while the old original save is in flight", async () => {
    const h = mount();
    let release!: () => void;
    const gate = new Promise<void>(resolve => { release = resolve; });
    h.apply.mockImplementation(async (...args: any[]) => {
      await gate;
      const saved = coupleWillFilingTypeFacts({ ...args[0], ...args[5] }, h.estate);
      args[6].onSaved({ estateId: h.estate.id, revision: 2, record: { ...h.estate, ...saved, revision: 2 } });
      args[6].onRechecked();
      return true;
    });
    await choose("pre-generate-canonical-willType", "Physical");
    await choose("pre-generate-input-willFilingType", "The electronic original.");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(1));
    await choose("pre-generate-input-willFilingType", "A copy (original lost/destroyed).");
    expect(medium().textContent).toContain("Physical");
    await act(async () => { release(); });
    expect(medium().textContent).toContain("Physical");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(2));
    expect(h.apply.mock.calls[1][5]).toMatchObject({ willType: "physical", isElectronicWill: 0 });
  });
});
