import React, { useEffect, useMemo, useState } from "react";
import { ArrowDown, ArrowUp, ClipboardList, Plus, Save, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import type { ClientIntakeCustomQuestion } from "@shared/clientIntake";

const MAX_QUESTIONS = 20;

function createQuestionId() {
  const suffix = typeof crypto !== "undefined" && typeof crypto.randomUUID === "function"
    ? crypto.randomUUID().replace(/-/g, "")
    : `${Date.now()}${Math.random().toString(36).slice(2)}`;
  return `cq_${suffix.slice(0, 32)}`;
}

export function ClientIntakeQuestions({
  estateId,
  revision,
  onSaved,
}: {
  estateId: string;
  revision: number;
  onSaved?: (revision: number) => void;
}) {
  const utils = trpc.useUtils();
  const { data, isLoading, isError } = trpc.clientIntake.questions.useQuery({ estateId });
  const [questions, setQuestions] = useState<ClientIntakeCustomQuestion[]>([]);
  const [loadedRevision, setLoadedRevision] = useState<number | null>(null);

  useEffect(() => {
    if (!data || loadedRevision === data.revision) return;
    setQuestions(data.questions);
    setLoadedRevision(data.revision);
  }, [data, loadedRevision]);

  const update = trpc.clientIntake.updateQuestions.useMutation({
    onSuccess: result => {
      setQuestions(result.questions);
      setLoadedRevision(result.revision);
      onSaved?.(result.revision);
      void utils.clientIntake.questions.invalidate({ estateId });
      toast.success("Case-specific questions saved.");
    },
    onError: error => toast.error(error.message || "Case-specific questions could not be saved."),
  });

  const displayedRevision = data?.revision ?? revision;
  const isDirty = useMemo(
    () => data ? JSON.stringify(questions) !== JSON.stringify(data.questions) : false,
    [data, questions]
  );

  const updateQuestion = <K extends keyof ClientIntakeCustomQuestion>(
    id: string,
    key: K,
    value: ClientIntakeCustomQuestion[K]
  ) => setQuestions(current => current.map(question => question.id === id ? { ...question, [key]: value } : question));

  const moveQuestion = (index: number, direction: -1 | 1) => {
    const destination = index + direction;
    if (destination < 0 || destination >= questions.length) return;
    setQuestions(current => {
      const next = [...current];
      [next[index], next[destination]] = [next[destination], next[index]];
      return next;
    });
  };

  if (isLoading) {
    return <Card aria-busy="true" aria-label="Loading case-specific questions"><CardContent className="py-6 text-sm text-muted-foreground">Loading case-specific questions…</CardContent></Card>;
  }
  if (isError) {
    return <Card role="alert"><CardContent className="py-6 text-sm text-destructive">Case-specific questions could not be loaded. Refresh this tab to try again.</CardContent></Card>;
  }

  return (
    <Card>
      <CardHeader className="gap-1.5 pb-4">
        <div className="flex items-start gap-3">
          <span className="mt-0.5 rounded-md bg-primary/10 p-2 text-primary"><ClipboardList className="h-4 w-4" aria-hidden="true" /></span>
          <div className="min-w-0">
            <CardTitle className="text-base">Case-specific questions</CardTitle>
            <CardDescription className="mt-1 max-w-2xl leading-5">Add only questions that need an answer for this estate. Clients see these before they send the intake; answers stay in the submission for your review and are never applied automatically.</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {questions.length === 0 ? (
          <div className="rounded-lg border border-dashed border-border/80 bg-muted/20 px-4 py-5 text-sm text-muted-foreground">No case-specific questions. The standard client intake will be sent as-is.</div>
        ) : (
          <div className="space-y-3">
            {questions.map((question, index) => {
              const label = `Question ${index + 1}`;
              const promptId = `client-question-${question.id}`;
              const helpId = `${promptId}-help`;
              return (
                <div key={question.id} className="rounded-lg border border-border/70 bg-background p-4 shadow-[0_1px_0_hsl(var(--background))]">
                  <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                    <Label htmlFor={promptId} className="text-sm font-semibold">{label}</Label>
                    <div className="flex items-center gap-1">
                      <Button type="button" variant="ghost" size="icon" className="h-8 w-8" onClick={() => moveQuestion(index, -1)} disabled={index === 0} aria-label={`Move ${label.toLowerCase()} up`}><ArrowUp className="h-4 w-4" /></Button>
                      <Button type="button" variant="ghost" size="icon" className="h-8 w-8" onClick={() => moveQuestion(index, 1)} disabled={index === questions.length - 1} aria-label={`Move ${label.toLowerCase()} down`}><ArrowDown className="h-4 w-4" /></Button>
                      <Button type="button" variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setQuestions(current => current.filter(item => item.id !== question.id))} aria-label={`Remove ${label.toLowerCase()}`}><Trash2 className="h-4 w-4" /></Button>
                    </div>
                  </div>
                  <Textarea id={promptId} value={question.prompt} onChange={event => updateQuestion(question.id, "prompt", event.target.value)} maxLength={500} rows={2} aria-describedby={helpId} placeholder="Write a clear question for the client" />
                  <div className="mt-3 grid gap-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end">
                    <div className="space-y-1.5">
                      <Label htmlFor={helpId} className="text-xs text-muted-foreground">Optional guidance</Label>
                      <Input id={helpId} value={question.helpText} onChange={event => updateQuestion(question.id, "helpText", event.target.value)} maxLength={500} placeholder="Explain what would be helpful to include" />
                    </div>
                    <label className="flex min-h-9 cursor-pointer items-center gap-2 text-sm font-medium">
                      <Checkbox checked={question.required} onCheckedChange={checked => updateQuestion(question.id, "required", checked === true)} />
                      Client must answer this question
                    </label>
                  </div>
                </div>
              );
            })}
          </div>
        )}
        <div className="flex flex-col gap-3 border-t border-border/70 pt-4 sm:flex-row sm:items-center sm:justify-between">
          <Button type="button" variant="outline" onClick={() => setQuestions(current => current.length >= MAX_QUESTIONS ? current : [...current, { id: createQuestionId(), prompt: "", helpText: "", required: false }])} disabled={questions.length >= MAX_QUESTIONS}>
            <Plus className="mr-2 h-4 w-4" aria-hidden="true" />
            Add question
          </Button>
          <Button type="button" onClick={() => update.mutate({ estateId, expectedRevision: displayedRevision, questions })} disabled={update.isPending || !isDirty || questions.some(question => !question.prompt.trim())}>
            <Save className="mr-2 h-4 w-4" aria-hidden="true" />
            {update.isPending ? "Saving…" : "Save questions"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
