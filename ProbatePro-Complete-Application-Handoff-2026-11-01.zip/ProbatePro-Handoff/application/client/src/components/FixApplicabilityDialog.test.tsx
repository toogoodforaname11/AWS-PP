/**
 * Optional-form popup wiring tests (RULES.md Rule 22).
 *
 * This file replaced a suite that pinned the PREVIOUS contract — answers were
 * persisted to the estate via estate.update and the confirm button stayed
 * disabled until the form legitimately stopped being "na". That gate could
 * never be satisfied for forms whose verdict no answer can flip (P2 on a
 * resealing estate, P8 without co-applicants), so the button was permanently
 * dead on exactly the rows it existed to serve. The assertions below pin the
 * behaviour that replaced it, deliberately and with the reversal recorded.
 *
 * What is verified now:
 *   - prefill from the estate record (incl. resolveValue axis seeding)
 *   - the confirm button is ALWAYS enabled — unchanged, changed, still-na
 *   - NOTHING is persisted: touching estate.update at all fails the suite
 *   - onProceed carries (formCode, overrides, { notApplicable, intent })
 *   - only CHANGED columns ride as overrides
 *   - electronic-will axis answers ride applyElectronicWillAxis, and willType
 *     carries isElectronicWill (the 2026-08-05 HIGH coupling)
 *   - a form with no questions (P8) still generates
 *   - preview intent relabels the action and rides through to onProceed
 *
 * TriToggle-driven forms (P13, P45) drive the interaction tests — Radix Select
 * needs pointer-capture APIs jsdom lacks; the select-driven registry entries
 * are covered by shared/applicabilityQuestions.test.ts efficacy fixtures.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";
import React from "react";
import { render, screen, fireEvent, cleanup } from "@testing-library/react";

// The popup must not write. If a future edit reintroduces a mutation, this
// mock turns that into a loud failure instead of a silent intake edit.
vi.mock("@/lib/trpc", () => ({
  trpc: new Proxy({}, {
    get() {
      throw new Error("FixApplicabilityDialog must not call tRPC — its answers are per-document overrides, never persisted (RULES.md Rule 22).");
    },
  }),
}));

import { FixApplicabilityDialog } from "./FixApplicabilityDialog";

const applicant = {
  id: "applicant-1",
  role: "applicant,executor",
  executorStatus: "applying",
  executorRank: "primary",
  name: "Alex Applicant",
};

/** Mirror of the applicability suite's clean probate estate. */
function cleanEstate(overrides: Record<string, unknown> = {}) {
  return {
    id: "estate-1",
    grantType: "grant_of_probate",
    hasWill: 1,
    willType: "physical",
    isElectronicWill: 0,
    testamentaryDocStatus: "none_found",
    beliefLastBcWill: "yes",
    specialCircumstances: "none",
    willFilingType: "physical_original",
    foreignWillStatus: "made_in_bc",
    wesaS58Reliance: "no",
    ordersAffectingWill: "no",
    vsaCertificateResult: "no_notice",
    isMilitaryWill: "no",
    executionIssues: "no_issues",
    willAlterations: "no_alterations",
    willAppearanceIssues: "no",
    referencedDocuments: "no",
    willDocumentsAttached: "yes",
    otherGrantsStatus: "no_other_grants",
    notifyPGT: "no",
    pgtIsApplicant: "no",
    p1NotRequired: 1,
    deceasedDomiciledInBC: "yes",
    deceasedFirstName: "Alex",
    deceasedLastName: "North",
    willDate: "2024-01-15",
    codicilFiles: "[]",
    ...overrides,
  };
}

function renderDialog(formCode: string, overrides: Partial<React.ComponentProps<typeof FixApplicabilityDialog>> = {}) {
  const handlers = {
    onOpenChange: vi.fn(),
    onProceed: vi.fn(),
    onGoToContacts: vi.fn(),
    onGoToIntake: vi.fn(),
  };
  render(
    <FixApplicabilityDialog
      open={true}
      formCode={formCode}
      formName="Test Form"
      estate={cleanEstate()}
      contacts={[applicant]}
      {...handlers}
      {...overrides}
    />,
  );
  return handlers;
}

/** Click a TriToggle option by its visible label. */
function clickTri(testId: string, label: string): void {
  const tri = screen.getByTestId(testId);
  fireEvent.click(Array.from(tri.querySelectorAll("button")).find((b) => b.textContent === label)!);
}

const confirmButton = () => screen.getByTestId("fix-confirm") as HTMLButtonElement;

beforeEach(() => {
  cleanup();
});

describe("the action is never gated", () => {
  it("P5 retains its explicit draft opt-in when its answers make the form Required", () => {
    const handlers = renderDialog("P5", { estate: cleanEstate({ grantType: "grant_of_admin", willStatus: "no_will", hasWill: 0 }) });
    expect(screen.getByTestId("fix-now-applicable").textContent).toContain("Required");
    fireEvent.click(confirmButton());
    expect(handlers.onProceed).toHaveBeenCalledWith("P5", {}, { notApplicable: true, intent: "generate" });
  });

  it("P5 standing follows the selected secondary applicant through the applicability escape", () => {
    renderDialog("P5", {
      contacts: [{ ...applicant, relationship: "child" }, { ...applicant, id: "second-applicant", name: "Taylor Spouse", executorRank: "secondary", relationship: "spouse" }],
      selectedContactId: "second-applicant",
      forceNotApplicable: true,
    });
    const standing = screen.getByTestId("fix-p5-standing").textContent || "";
    expect(standing).toContain("Taylor Spouse — spouse");
    expect(standing).toContain("paragraph (a)");
    expect(standing).not.toContain("Alex Applicant");
  });
  it("P5 keeps generation available on a will-based file and explains section 5 remains blank", () => {
    const handlers = renderDialog("P5", { contacts: [{ ...applicant, relationship: "child" }] });
    expect(screen.getByTestId("fix-note").textContent).toContain("section 5 is left blank for review");
    expect(screen.getByTestId("fix-p5-standing").textContent).toContain("paragraph (b)");
    expect(screen.getByTestId("fix-question-willStatus").querySelector('[aria-pressed="true"]')?.textContent).toBe("Will present");
    expect(confirmButton().disabled).toBe(false);
    fireEvent.click(confirmButton());
    expect(handlers.onProceed).toHaveBeenCalledWith("P5", {}, { notApplicable: true, intent: "generate" });
  });

  it("P5 takes transient Will Status and nomination answers without requiring a grant-type change", () => {
    const estate = cleanEstate({ willStatus: "will" });
    const handlers = renderDialog("P5", { estate, contacts: [{ ...applicant, relationship: "child" }] });
    clickTri("fix-question-willStatus", "No will");
    fireEvent.click(screen.getByTestId("fix-question-applicantIsGovernmentNominee"));
    expect(screen.getByTestId("fix-p5-standing").textContent).toContain("paragraph (f.1)");
    expect(screen.getByTestId("fix-still-na").textContent).toContain("will-based grants");
    expect(confirmButton().disabled).toBe(false);
    fireEvent.click(confirmButton());
    expect(handlers.onProceed).toHaveBeenCalledWith("P5", { willStatus: "no_will", hasWill: 0, applicantIsGovernmentNominee: 1 }, { notApplicable: true, intent: "generate" });
    expect(estate).toMatchObject({ willStatus: "will", hasWill: 1, grantType: "grant_of_probate" });
  });
  it("is enabled with nothing answered on a form the estate does not require", () => {
    renderDialog("P13");
    expect(screen.getByTestId("fix-still-na").textContent).toContain("Public Guardian and Trustee");
    expect(confirmButton().disabled).toBe(false);
  });

  it("stays enabled when an answer does NOT flip the verdict", () => {
    // P45 on a physical-will estate: answering ONLY hasWill leaves it na.
    // Under the previous contract this was the permanently-dead-button case.
    renderDialog("P45", { estate: cleanEstate({ hasWill: 0 }) });
    clickTri("fix-question-hasWill", "Yes");
    expect(screen.getByTestId("fix-still-na")).toBeTruthy();
    expect(confirmButton().disabled).toBe(false);
  });

  it("is enabled on a form with no answerable questions at all (P8)", () => {
    renderDialog("P8");
    expect(screen.getByTestId("fix-note").textContent).toContain("Contacts tab");
    expect(confirmButton().disabled).toBe(false);
  });

  it("is enabled on the explain-only P44 grant-issued bar", () => {
    renderDialog("P44");
    expect(confirmButton().disabled).toBe(false);
  });
});

describe("the copy tells the truth about what the answers do", () => {
  it("says the answers apply to this document only and leave the record alone", () => {
    renderDialog("P13");
    expect(screen.getByText(/apply to this document only/i)).toBeTruthy();
    expect(screen.getByText(/intake record is not changed/i)).toBeTruthy();
  });

  it("never claims the estate record is edited", () => {
    renderDialog("P13");
    expect(screen.queryByText(/update the estate record/i)).toBeNull();
  });

  it("points at Intake as the place to make an answer permanent", () => {
    renderDialog("P13");
    expect(screen.getByTestId("fix-transient-note").textContent).toMatch(/permanent/i);
  });

  it("states the draft will assert facts the file does not record", () => {
    renderDialog("P13");
    expect(screen.getByTestId("fix-still-na").textContent).toMatch(/your file does not yet record/i);
  });
});

describe("overrides carried to onProceed (P13)", () => {
  it("passes only the changed column, flags the form as applicable, and closes", () => {
    const handlers = renderDialog("P13");
    clickTri("fix-question-pgtIsApplicant", "Yes");

    expect(screen.getByTestId("fix-now-applicable").textContent).toContain("P13 is");
    fireEvent.click(confirmButton());

    expect(handlers.onProceed).toHaveBeenCalledWith(
      "P13",
      { pgtIsApplicant: "yes" },
      { notApplicable: false, intent: "generate" },
    );
    expect(handlers.onOpenChange).toHaveBeenCalledWith(false);
  });

  it("sends an EMPTY override set when the user answered nothing", () => {
    // The audit trail names substituted facts — an untouched answer must not
    // appear there as if the user had supplied it.
    const handlers = renderDialog("P13");
    fireEvent.click(confirmButton());
    expect(handlers.onProceed).toHaveBeenCalledWith("P13", {}, { notApplicable: true, intent: "generate" });
  });

  it("re-answering back to the seeded value drops the column again", () => {
    const handlers = renderDialog("P13");
    clickTri("fix-question-pgtIsApplicant", "Yes");
    clickTri("fix-question-pgtIsApplicant", "No");
    fireEvent.click(confirmButton());
    expect(handlers.onProceed).toHaveBeenCalledWith("P13", {}, expect.anything());
  });

  it("marks notApplicable when the answers leave the form not required", () => {
    const handlers = renderDialog("P45", { estate: cleanEstate({ hasWill: 0 }) });
    clickTri("fix-question-hasWill", "Yes");
    fireEvent.click(confirmButton());
    expect(handlers.onProceed).toHaveBeenCalledWith(
      "P45",
      expect.objectContaining({ hasWill: 1 }),
      expect.objectContaining({ notApplicable: true }),
    );
  });

  it("Cancel proceeds with nothing", () => {
    const handlers = renderDialog("P13");
    fireEvent.click(screen.getByTestId("fix-cancel"));
    expect(handlers.onProceed).not.toHaveBeenCalled();
    expect(handlers.onOpenChange).toHaveBeenCalledWith(false);
  });

  it("carries the P4 long-form override as an int (1), matching the intake column", () => {
    const handlers = renderDialog("P4");
    fireEvent.click(screen.getByTestId("fix-question-useLongFormAffidavit"));
    expect(screen.getByTestId("fix-now-applicable").textContent).toContain("P4 is");
    fireEvent.click(confirmButton());
    expect(handlers.onProceed).toHaveBeenCalledWith(
      "P4",
      { useLongFormAffidavit: 1 },
      expect.anything(),
    );
  });
});

describe("preview intent", () => {
  it("relabels the action and rides the intent through to onProceed", () => {
    const handlers = renderDialog("P13", { intent: "preview" });
    expect(confirmButton().textContent).toBe("Preview");
    clickTri("fix-question-pgtIsApplicant", "Yes");
    fireEvent.click(confirmButton());
    expect(handlers.onProceed).toHaveBeenCalledWith(
      "P13",
      { pgtIsApplicant: "yes" },
      { notApplicable: false, intent: "preview" },
    );
  });
});

describe("electronic-will axes (P45)", () => {
  it("routes axis answers through applyElectronicWillAxis so the derived token rides the overrides", () => {
    const handlers = renderDialog("P45");
    clickTri("fix-question-willType", "Electronic");
    // first-saved-PDF → No ((iii) branch — mandates P45)
    clickTri("fix-question-electronicWillFirstSavedPdf", "No");

    expect(screen.getByTestId("fix-now-applicable")).toBeTruthy();
    fireEvent.click(confirmButton());

    const payload = handlers.onProceed.mock.calls[0][1];
    expect(payload.willType).toBe("electronic");
    // 2026-08-05 review (HIGH): willType alone left isElectronicWill at 0 and
    // P1/P9 printed physical-will wording. Both must ride together — and now
    // that they ride as overrides, the SAME coupling has to survive, because
    // the server renders straight from this object.
    expect(payload.isElectronicWill).toBe(1);
    expect(payload.electronicWillFirstSavedPdf).toBe("no");
    expect(payload.electronicWillFormat).toBe("other_format");
    expect(payload).toHaveProperty("electronicWillInRepository");
    expect(payload).toHaveProperty("electronicWillOriginalAvailable");
  });

  it("seeds the axis toggles from the resolved legacy token (P15PLUS-006 display parity)", () => {
    const handlers = renderDialog("P45", {
      estate: cleanEstate({ willType: "electronic", electronicWillFormat: "third_party_repo" }),
    });
    // The legacy token resolves inRepository to "yes" — clicking "Yes" is a
    // no-op change, so no override may ride (proves the seed).
    clickTri("fix-question-electronicWillInRepository", "Yes");
    fireEvent.click(confirmButton());
    expect(handlers.onProceed).toHaveBeenCalledWith("P45", {}, expect.anything());
  });
});

describe("navigation affordances", () => {
  it("offers Go to Contacts for contact-driven verdicts", () => {
    const handlers = renderDialog("P8");
    fireEvent.click(screen.getByTestId("fix-go-contacts"));
    expect(handlers.onGoToContacts).toHaveBeenCalled();
  });

  it("offers Go to Intake where the note sends the user back to intake", () => {
    const handlers = renderDialog("P44");
    expect(screen.getByTestId("fix-note").textContent).toContain("Rule 25-3.2(1)");
    fireEvent.click(screen.getByTestId("fix-go-intake"));
    expect(handlers.onGoToIntake).toHaveBeenCalled();
  });
});

// Addendum 24.1: entered via the preflight na escape hatch, Proceed must carry
// generateAnyway even when the client-side draft computes applicable — the
// SERVER said na, and a stale estate row must not loop the user back into the
// same hard block.
describe("forceNotApplicable (na escape hatch)", () => {
  it("forces notApplicable: true on Proceed even when the live status computes applicable", () => {
    const onProceed = vi.fn();
    renderDialog("P13", {
      estate: cleanEstate({ pgtIsApplicant: "yes" }),
      forceNotApplicable: true,
      onProceed,
    });
    expect(screen.getByTestId("fix-now-applicable")).toBeTruthy();
    fireEvent.click(confirmButton());
    expect(onProceed).toHaveBeenCalledWith(
      "P13",
      { pgtIsApplicant: "yes" },
      expect.objectContaining({ notApplicable: true }),
    );
  });

  it("without the flag, an applicable live status proceeds with notApplicable: false (unchanged behavior)", () => {
    const onProceed = vi.fn();
    renderDialog("P13", {
      estate: cleanEstate({ pgtIsApplicant: "yes" }),
      onProceed,
    });
    fireEvent.click(confirmButton());
    expect(onProceed).toHaveBeenCalledWith("P13", expect.anything(), expect.objectContaining({ notApplicable: false }));
  });
});
