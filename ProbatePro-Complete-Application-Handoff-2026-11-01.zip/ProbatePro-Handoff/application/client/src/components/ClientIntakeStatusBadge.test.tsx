import React from "react";
import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { ClientIntakeStatusBadge, getClientIntakeStatusDetail } from "./ClientIntakeStatusBadge";

describe("ClientIntakeStatusBadge", () => {
  it.each([
    ["submitted", "Under Review"],
    ["revision_requested", "Pending Revision"],
    ["approved", "Approved"],
  ])("shows %s as %s", (status, label) => {
    render(<ClientIntakeStatusBadge status={status} />);
    expect(screen.getByLabelText(`Intake status: ${label}`)).toBeTruthy();
  });

  it("keeps an unknown persisted status safely under review", () => {
    expect(getClientIntakeStatusDetail("future_status")).toMatch(/reviewing/i);
  });
});
