/**
 * FormDetailsDialog wiring tests.
 *
 * Verifies the per-form config renders the right controls (and only those) and
 * that every control writes to the correct column / callback:
 *   - oath toggle            → estate.update { oathType }
 *   - P2 certified-copy quantities → popup controls persist before generation
 *   - electronic-will wording → derives from Intake's Type of Will (no dialog write)
 *   - form-local jurat / P10-P11 eligibility fields → estate.update
 *   - P9 recipient check     → delivery.upsert (real row) / uncheck → delivery.delete
 *   - signature date change  → param callback only, NO mutation
 *   - Generate/Preview       → onGenerate/onPreview with selectedContactId/deponentId
 */
import { describe, it, expect, vi, beforeEach } from "vitest";
import React from "react";
import { act, render, screen, fireEvent, waitFor, cleanup } from "@testing-library/react";

vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }) }));
import { toast } from "sonner";

const mocks = vi.hoisted(() => ({
  estateUpdate: vi.fn(),
  estateUpdateAsync: vi.fn().mockResolvedValue({ success: true }),
  deliveryUpsert: vi.fn().mockResolvedValue({}),
  deliveryDelete: vi.fn().mockResolvedValue({}),
  bulkCreate: vi.fn().mockResolvedValue({}),
  deliveryFetch: vi.fn(),
  estateUpdatePending: false,
  preflightData: { formCode: "P3", ok: true, gaps: [] } as any,
  preflightInputs: [] as any[],
  deliveries: [] as any[],
  recipients: [] as any[],
  // Drives the synthetic Settings-lawyer deponent (Nick ruling G3, 2026-07-12);
  // null keeps pre-existing tests on their contact-based pools.
  settings: null as any,
  // Whole-query-result overrides (null = the plain { data } shape every other
  // test relies on) so a test can simulate isError / still-loading.
  deliveryListQuery: null as any,
  recipientsQuery: null as any,
  preflightQuery: null as any,
}));

vi.mock("@/lib/trpc", () => {
  const mutation = (mutate: any) => ({ useMutation: (options: any) => ({
    mutate,
    mutateAsync: async (input: any) => {
      try {
        options?.onMutate?.(input);
        const result = await mutate(input);
        options?.onSuccess?.(result, input);
        return result;
      } catch (error) { options?.onError?.(error); throw error; }
      finally { options?.onSettled?.(); }
    },
    isPending: false,
  }) });
  return {
    trpc: {
      estate: { update: { useMutation: (options: any) => ({
        mutate: mocks.estateUpdate,
        mutateAsync: async (input: any) => {
          try { return await mocks.estateUpdateAsync(input); }
          catch (error) { options?.onError?.(error); throw error; }
        },
        isPending: mocks.estateUpdatePending,
      }) } },
      document: {
        preflight: { useQuery: (input: any) => { mocks.preflightInputs.push(input); return mocks.preflightQuery ?? { data: mocks.preflightData }; } },
      },
      delivery: {
        list: { useQuery: () => mocks.deliveryListQuery ?? { data: mocks.deliveries } },
        getRecipients: { useQuery: () => mocks.recipientsQuery ?? { data: mocks.recipients } },
        upsert: mutation(mocks.deliveryUpsert),
        delete: mutation(mocks.deliveryDelete),
        bulkCreate: mutation(mocks.bulkCreate),
      },
      settings: {
        get: { useQuery: () => ({ data: mocks.settings }) },
      },
      useUtils: () => ({
        estate: { get: { invalidate: vi.fn() } },
        readiness: { check: { invalidate: vi.fn() }, timeline: { invalidate: vi.fn() } },
        deadline: { list: { invalidate: vi.fn() } },
        document: { preflight: { invalidate: vi.fn() }, preflightMany: { invalidate: vi.fn() } },
        delivery: { list: {
          invalidate: vi.fn(),
          fetch: mocks.deliveryFetch,
          setData: (_input: any, updater: any) => { mocks.deliveries = updater(mocks.deliveries); },
        } },
      }),
    },
  };
});

import { FormDetailsDialog, FORM_DETAILS, __test } from "./FormDetailsDialog";

const primaryExec = { id: "c-primary", name: "Prime Executor", role: "executor", executorStatus: "applying", executorRank: "primary" };
const secondExec = { id: "c-two", name: "Second Executor", role: "executor", executorStatus: "applying", executorRank: "" };
const beneficiary = { id: "c-ben", name: "Bob Beneficiary", role: "beneficiary", executorStatus: "", recipientType: "beneficiary" };

const baseEstate = { id: "e1", revision: 1, oathType: "affirmed", isElectronicWill: 0, certifiedCopies: 3, certifiedCopiesAuthorization: 0, certifiedCopiesP10: 0, certifiedCopiesP11: 0, p11AffidavitOrdinal: "1st", juratCity: "Vancouver", domicileCity: "Victoria", deceasedDomiciledInBC: "unknown", deceasedOrdinarilyResidentInBC: "unknown", foreignAdministrationConfirmed: "unknown", p11DiligentSearchConfirmed: "unknown" };

function renderDialog(formCode: string, overrides: Partial<React.ComponentProps<typeof FormDetailsDialog>> = {}) {
  const handlers = {
    onGenerate: vi.fn(),
    onPreview: vi.fn(),
    onCancel: vi.fn(),
    onSignatoryTypeChange: vi.fn(),
    onSignatureDateChange: vi.fn(),
  };
  render(
    <FormDetailsDialog
      open={true}
      onOpenChange={() => {}}
      formCode={formCode}
      formName="Test Form"
      estateId="e1"
      estate={baseEstate}
      contacts={[primaryExec, secondExec, beneficiary]}
      signatoryType="lawyer"
      signatureDate="2026-07-11"
      {...handlers}
      {...overrides}
    />,
  );
  return handlers;
}

beforeEach(() => {
  vi.mocked(toast.error).mockClear();
  mocks.estateUpdate.mockClear();
  mocks.estateUpdateAsync.mockClear();
  mocks.deliveryUpsert.mockReset().mockResolvedValue({});
  mocks.deliveryDelete.mockReset().mockResolvedValue({});
  mocks.bulkCreate.mockReset().mockResolvedValue({});
  mocks.deliveryFetch.mockReset().mockImplementation(async () => mocks.deliveries);
  mocks.estateUpdatePending = false;
  mocks.preflightData = { formCode: "P3", ok: true, gaps: [] };
  mocks.preflightInputs.length = 0;
  mocks.deliveries = [];
  mocks.recipients = [];
  mocks.settings = null;
  mocks.deliveryListQuery = null;
  mocks.recipientsQuery = null;
  mocks.preflightQuery = null;
});

describe("FORM_DETAILS config", () => {
  it("covers exactly P1–P12 plus P14, P15, P16, P26, P34, P44, P45 and P46", () => {
    // P12 joined 2026-09-01 (Nick directive): translator jurat-city + date only.
    expect(Object.keys(FORM_DETAILS).sort()).toEqual(["P1", "P10", "P11", "P12", "P14", "P15", "P16", "P2", "P26", "P3", "P34", "P4", "P44", "P45", "P46", "P5", "P6", "P7", "P8", "P9"]);
  });

  it("keeps jurat-city entry within affidavit generation details and P10 adds only its legal eligibility determinations", () => {
    expect(FORM_DETAILS.P26).toEqual([
      { kind: "deponent", param: "selectedContactId", applicantsOnly: true },
      { kind: "oath" },
      { kind: "date" },
      { kind: "affidavitOrdinal" },
      {
        kind: "persistedText",
        column: "domicileCity",
        label: "Jurat city",
        placeholder: "Defaults to your firm's city",
        description: "The British Columbia city where this affidavit will be sworn or affirmed. It is never taken from the deceased's residential address.",
      },
    ]);
    expect(FORM_DETAILS.P26).toBe(FORM_DETAILS.P15);
    expect(FORM_DETAILS.P15).toBe(FORM_DETAILS.P14);
    expect(FORM_DETAILS.P10).toEqual(expect.arrayContaining([
      expect.objectContaining({ kind: "persistedSelect", column: "deceasedDomiciledInBC" }),
      expect.objectContaining({ kind: "persistedSelect", column: "deceasedOrdinarilyResidentInBC" }),
      expect.objectContaining({ kind: "persistedSelect", column: "foreignAdministrationConfirmed" }),
    ]));
    expect(FORM_DETAILS.P14).not.toBe(FORM_DETAILS.P10);
    expect(FORM_DETAILS.P10).not.toBe(FORM_DETAILS.P3);
  });

  it("P16 gets fact-witness affidavit fields (deponent + oath + date)", () => {
    expect(FORM_DETAILS.P16).toEqual([
      { kind: "deponent", param: "selectedContactId" },
      { kind: "oath" },
      { kind: "date" },
      { kind: "affidavitOrdinal" },
      {
        kind: "persistedText",
        column: "domicileCity",
        label: "Jurat city",
        placeholder: "Defaults to your firm's city",
        description: "The British Columbia city where this affidavit will be sworn or affirmed. It is never taken from the deceased's residential address.",
      },
    ]);
    expect(FORM_DETAILS.P16).not.toBe(FORM_DETAILS.P26);
  });

  // Nick 2026-09-02 (third estate-#18 live audit): "address, occupation, jurat
  // city still blank after we typed them" — this dialog offered only the jurat
  // city; the preamble's address and occupation are now typed here too.
  it("P12 collects the translator's address, occupation and jurat city (all persisted estate columns)", () => {
    expect(FORM_DETAILS.P12).toEqual([
      { kind: "date" },
      { kind: "affidavitOrdinal" },
      expect.objectContaining({ kind: "persistedText", column: "translatorAddress" }),
      expect.objectContaining({ kind: "persistedText", column: "translatorOccupation" }),
      expect.objectContaining({ kind: "persistedText", column: "p12JuratCity" }),
    ]);
    renderDialog("P12");
    expect(screen.getByTestId("form-details-translatorAddress")).toBeTruthy();
    expect(screen.getByTestId("form-details-translatorOccupation")).toBeTruthy();
    expect(screen.getByTestId("form-details-p12JuratCity")).toBeTruthy();
  });

  it("P11's affidavit number is a document-local override — the header derives the ordinal when it is blank", () => {
    expect(FORM_DETAILS.P11).toContainEqual({ kind: "affidavitOrdinal" });
    expect(FORM_DETAILS.P11.some((f: any) => f.kind === "persistedText" && f.column === "p11AffidavitOrdinal")).toBe(false);
  });

  it("offers every ordinal-caption affidavit a document-local affidavit-number override", () => {
    const ordinalForms = ["P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10", "P11", "P12", "P14", "P15", "P16", "P26", "P34", "P45"];
    for (const formCode of ordinalForms) {
      expect(FORM_DETAILS[formCode], formCode).toContainEqual({ kind: "affidavitOrdinal" });
    }

    const handlers = renderDialog("P3");
    const input = screen.getByTestId("form-details-affidavit-ordinal") as HTMLInputElement;
    expect(input.value).toBe("");
    fireEvent.change(input, { target: { value: "6th" } });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    expect(handlers.onGenerate).toHaveBeenCalledWith({ selectedContactId: "c-primary", affidavitOrdinal: "6th" });
    expect(mocks.estateUpdateAsync).not.toHaveBeenCalled();
  });

  it("P45 shares the fact-witness affidavit fields with P16", () => {
    expect(FORM_DETAILS.P45).toEqual([
      { kind: "deponent", param: "selectedContactId" },
      { kind: "oath" },
      { kind: "date" },
      { kind: "affidavitOrdinal" },
      {
        kind: "persistedText",
        column: "domicileCity",
        label: "Jurat city",
        placeholder: "Defaults to your firm's city",
        description: "The British Columbia city where this affidavit will be sworn or affirmed. It is never taken from the deceased's residential address.",
      },
    ]);
    expect(FORM_DETAILS.P45).toBe(FORM_DETAILS.P16);
  });

  it("P44 collects its selected applicant-or-lawyer signature role and date", () => {
    expect(FORM_DETAILS.P44).toEqual([{ kind: "signatory" }, { kind: "date" }]);
    renderDialog("P44", { signatoryType: "lawyer" });
    const signatory = screen.getByTestId("form-details-signatory");
    expect(signatory.textContent).toMatch(/lawyer/i);
    expect(screen.getByTestId("form-details-date")).toBeTruthy();
  });

  it("P46 collects the demandant's actual signature date before a selected delivery is generated", () => {
    expect(FORM_DETAILS.P46).toEqual([{ kind: "date" }]);
    const handlers = renderDialog("P46");
    fireEvent.change(screen.getByTestId("form-details-date"), { target: { value: "2026-10-11" } });
    expect(handlers.onSignatureDateChange).toHaveBeenCalledWith("2026-10-11");
    fireEvent.click(screen.getByTestId("form-details-generate"));
    expect(handlers.onGenerate).toHaveBeenCalledWith({});
  });

  it("P34 collects the citor's actual signature date before the selected citation is generated", () => {
    expect(FORM_DETAILS.P34).toEqual([{ kind: "date" }, { kind: "affidavitOrdinal" }]);
    const handlers = renderDialog("P34");
    fireEvent.change(screen.getByTestId("form-details-date"), { target: { value: "2026-10-11" } });
    expect(handlers.onSignatureDateChange).toHaveBeenCalledWith("2026-10-11");
    fireEvent.click(screen.getByTestId("form-details-generate"));
    expect(handlers.onGenerate).toHaveBeenCalledWith({});
  });
});

describe("per-form rendering", () => {
  it("P1 shows signatory + signature date, no oath / deponent / checklist", () => {
    renderDialog("P1");
    expect(screen.getByTestId("form-details-signatory")).toBeTruthy();
    expect(screen.getByTestId("form-details-date")).toBeTruthy();
    expect(screen.queryByRole("button", { name: "Affirmed" })).toBeNull();
    expect(screen.queryByText("Deponent")).toBeNull();
    expect(screen.queryByTestId("p9-delivery-checklist")).toBeNull();
    expect(screen.getByText("Signature date")).toBeTruthy();
  });

  it("P3 shows deponent + oath + affidavit date, no signatory / copies", () => {
    renderDialog("P3");
    expect(screen.getByTestId("form-details-deponent")).toBeTruthy();
    expect(screen.getByRole("button", { name: "Affirmed" })).toBeTruthy();
    expect(screen.getByText("Affidavit date")).toBeTruthy();
    expect(screen.queryByTestId("form-details-signatory")).toBeNull();
    expect(screen.queryByText("Certified copies requested")).toBeNull();
  });

  it("P5 presents the exact WESA s.130 rows as one-choice checkboxes and saves the selected citation", async () => {
    renderDialog("P5");

    expect(screen.getByTestId("form-details-applicantPriorityParagraph")).toBeTruthy();
    expect(screen.getByText("(c) a person nominated by a child of the deceased person if that person has the consent of a majority of the deceased person's children")).toBeTruthy();
    expect(screen.getByText("(e.1) a person, other than the spouse or child of the deceased person, nominated by an intestate successor of the deceased person if that person has the consent of the intestate successors representing a majority in interest of the estate, including the intestate successor who nominated the person to apply for a grant of administration")).toBeTruthy();

    const paragraphC = screen.getByTestId("form-details-applicantPriorityParagraph-c");
    const paragraphE1 = screen.getByTestId("form-details-applicantPriorityParagraph-e-1");
    expect(paragraphC.getAttribute("data-state")).toBe("unchecked");
    expect(paragraphE1.getAttribute("data-state")).toBe("unchecked");

    fireEvent.click(paragraphC);
    expect(paragraphC.getAttribute("data-state")).toBe("checked");
    expect(paragraphE1.getAttribute("data-state")).toBe("unchecked");
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledWith(expect.objectContaining({
      data: { applicantPriorityParagraph: "c" },
    })));

    fireEvent.click(paragraphE1);
    expect(paragraphC.getAttribute("data-state")).toBe("unchecked");
    expect(paragraphE1.getAttribute("data-state")).toBe("checked");
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledWith(expect.objectContaining({
      data: { applicantPriorityParagraph: "e.1" },
    })));
  });

  // 1(c) oath-flow sweep 2026-07-21: the deponent helper must not promise
  // "swears" alone — the estate's recorded oath may be affirmed.
  it("deponent helper copy covers both oath verbs (swears or affirms)", () => {
    renderDialog("P3");
    expect(screen.getByText(/who swears or affirms this affidavit\./)).toBeTruthy();
    expect(screen.queryByText(/who swears this affidavit\./)).toBeNull();
  });

  // Nick ruling 2026-07-21: the toggle drives the opening statement, the
  // exhibit stamps, and the jurat signing-block heading on both surfaces —
  // the copy must name all three so the generated document matches the promise.
  it("oath helper copy names all three printed surfaces", () => {
    renderDialog("P3");
    expect(screen.getByText(/Sets the oath wording on all of this estate's affidavits/)).toBeTruthy();
    expect(screen.queryByText(/Sets the preamble wording/)).toBeNull();
  });

  it("P2 collects each official certified-copy request in the generation dialog", async () => {
    renderDialog("P2");

    expect(screen.queryByTestId("form-details-certified-copies-source")).toBeNull();
    expect(screen.getByTestId("form-details-certifiedCopies")).toBeTruthy();
    expect(screen.getByTestId("form-details-certifiedCopiesP10")).toBeTruthy();
    expect(screen.getByTestId("form-details-certifiedCopiesP11")).toBeTruthy();
    expect(screen.getByTestId("form-details-certifiedCopiesP10-request").getAttribute("data-state")).toBe("unchecked");

    fireEvent.click(screen.getByTestId("form-details-certifiedCopiesP10-request"));
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledWith({
      id: "e1", expectedRevision: 1, data: { certifiedCopiesP10: 1 },
    }));

    const p10Copies = screen.getByTestId("form-details-certifiedCopiesP10");
    fireEvent.change(p10Copies, { target: { value: "2" } });
    fireEvent.blur(p10Copies);
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenLastCalledWith({
      id: "e1", expectedRevision: 2, data: { certifiedCopiesP10: 2 },
    }));
  });

  it("P9 shows the delivery checklist and Intake-owned electronic-will source note", () => {
    renderDialog("P9");
    expect(screen.getByTestId("p9-delivery-checklist")).toBeTruthy();
    expect(screen.getByTestId("form-details-electronic-will-source").textContent).toContain("Type of Will recorded in Intake");
    expect(screen.queryByTestId("form-details-electronic-will")).toBeNull();
  });

  it("#5: the electronic-will control does not claim that it proves no recipient made a demand", () => {
    renderDialog("P9", { estate: { ...baseEstate, isElectronicWill: 1 } });
    expect(screen.queryByText(/Adds section 5: no recipient demanded the will/i)).toBeNull();
  });

  it("P11 shows applicant deponent, oath, date, and its non-duplicated non-domiciled-estate details", () => {
    renderDialog("P11");
    expect(screen.getByTestId("form-details-deponent")).toBeTruthy();
    expect(screen.getByRole("button", { name: "Affirmed" })).toBeTruthy();
    expect(screen.getByTestId("form-details-date")).toBeTruthy();
    expect((screen.getByTestId("form-details-affidavit-ordinal") as HTMLInputElement).value).toBe("");
    expect(screen.queryByTestId("form-details-p11AffidavitOrdinal")).toBeNull();
    expect((screen.getByTestId("form-details-juratCity") as HTMLInputElement).value).toBe("Vancouver");
    expect(screen.getByTestId("form-details-deceasedDomicileJurisdiction")).toBeTruthy();
    expect(screen.getByTestId("form-details-p11DiligentSearchConfirmed")).toBeTruthy();
    expect(screen.getByTestId("form-details-deceasedDomiciledInBC")).toBeTruthy();
  });

  it("P15 shows deponent + oath + affidavit date, no signatory / copies (P14 parity, Rule 8b pool)", () => {
    renderDialog("P15");
    expect(screen.getByTestId("form-details-deponent")).toBeTruthy();
    expect(screen.getByRole("button", { name: "Affirmed" })).toBeTruthy();
    expect(screen.getByText("Affidavit date")).toBeTruthy();
    expect(screen.queryByTestId("form-details-signatory")).toBeNull();
    expect(screen.queryByText("Certified copies requested")).toBeNull();
  });
});

describe("column wiring (persist-on-change)", () => {
  it("oath toggle persists estates.oathType", async () => {
    renderDialog("P3");
    fireEvent.click(screen.getByRole("button", { name: "Sworn" }));
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledWith({ id: "e1", expectedRevision: 1, data: { oathType: "sworn" } }));
  });

  it("unchecking a P2 certified-copy request saves a zero quantity", async () => {
    renderDialog("P2", { estate: { ...baseEstate, certifiedCopiesP10: 2 } });
    const p10Request = screen.getByTestId("form-details-certifiedCopiesP10-request");
    expect(p10Request.getAttribute("data-state")).toBe("checked");

    fireEvent.click(p10Request);
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledWith({
      id: "e1", expectedRevision: 1, data: { certifiedCopiesP10: 0 },
    }));
  });

  it("P2 keeps a selected quantity input editable while replacing its existing value", async () => {
    renderDialog("P2", { estate: { ...baseEstate, certifiedCopiesP10: 2 } });
    const p10Copies = screen.getByTestId("form-details-certifiedCopiesP10") as HTMLInputElement;

    fireEvent.change(p10Copies, { target: { value: "" } });
    expect(p10Copies.disabled).toBe(false);
    fireEvent.change(p10Copies, { target: { value: "3" } });
    fireEvent.blur(p10Copies);

    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledWith({
      id: "e1", expectedRevision: 1, data: { certifiedCopiesP10: 3 },
    }));
  });

  it("electronic-will wording is read-only here and does not persist a duplicate answer", () => {
    renderDialog("P9");
    expect(screen.queryByTestId("form-details-electronic-will")).toBeNull();
    expect(mocks.estateUpdateAsync).not.toHaveBeenCalled();
  });

  it("signature date change calls the param callback and fires NO mutation", () => {
    const handlers = renderDialog("P3");
    fireEvent.change(screen.getByTestId("form-details-date"), { target: { value: "2026-08-01" } });
    expect(handlers.onSignatureDateChange).toHaveBeenCalledWith("2026-08-01");
    expect(mocks.estateUpdate).not.toHaveBeenCalled();
  });

  it("P11 jurat city persists its estate column on blur", async () => {
    renderDialog("P11");
    const city = screen.getByTestId("form-details-juratCity");
    fireEvent.change(city, { target: { value: "Victoria" } });
    fireEvent.blur(city);
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledWith({ id: "e1", expectedRevision: 1, data: { juratCity: "Victoria" } }));
  });

  it("persists P10/P11 legal eligibility selections from the generation dialog", async () => {
    renderDialog("P10");
    fireEvent.click(screen.getByTestId("form-details-deceasedDomiciledInBC"));
    fireEvent.click(screen.getByRole("option", { name: "No" }));
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledWith({ id: "e1", expectedRevision: 1, data: { deceasedDomiciledInBC: "no" } }));
  });
});

describe("flush-before-submit (K7: unblurred edits must reach the doc)", () => {
  it("typing an affidavit number without blurring passes a document-local override on Generate", () => {
    const handlers = renderDialog("P11");
    fireEvent.change(screen.getByTestId("form-details-affidavit-ordinal"), { target: { value: "2nd" } });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    expect(handlers.onGenerate).toHaveBeenCalledWith({ selectedContactId: "c-primary", affidavitOrdinal: "2nd" });
    expect(mocks.estateUpdateAsync).not.toHaveBeenCalled();
  });

  it("P2 flushes an unblurred certified-copy quantity before Generate", async () => {
    const handlers = renderDialog("P2");
    fireEvent.click(screen.getByTestId("form-details-certifiedCopiesP10-request"));
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledTimes(1));

    fireEvent.change(screen.getByTestId("form-details-certifiedCopiesP10"), { target: { value: "2" } });
    fireEvent.click(screen.getByTestId("form-details-generate"));

    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenLastCalledWith({
      id: "e1", expectedRevision: 2, data: { certifiedCopiesP10: 2 },
    }));
    await waitFor(() => expect(handlers.onGenerate).toHaveBeenCalledWith({}));
    expect(mocks.estateUpdateAsync.mock.invocationCallOrder[1]).toBeLessThan(handlers.onGenerate.mock.invocationCallOrder[0]);
  });

  it("no dirty edits — Generate fires synchronously and mutateAsync is never called", () => {
    const handlers = renderDialog("P11");
    fireEvent.click(screen.getByTestId("form-details-generate"));
    expect(handlers.onGenerate).toHaveBeenCalledWith({ selectedContactId: "c-primary" });
    expect(mocks.estateUpdateAsync).not.toHaveBeenCalled();
  });

  it("blur-then-Generate does not double-write the already-persisted value", async () => {
    const handlers = renderDialog("P11");
    const city = screen.getByTestId("form-details-juratCity");
    fireEvent.change(city, { target: { value: "Victoria" } });
    fireEvent.blur(city);
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledTimes(1));

    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(handlers.onGenerate).toHaveBeenCalledWith({ selectedContactId: "c-primary" }));
    expect(mocks.estateUpdateAsync).toHaveBeenCalledTimes(1);
  });

  it("a failed flush never generates against the stale pre-edit value (2026-07-12 review)", async () => {
    mocks.estateUpdateAsync.mockRejectedValueOnce(new Error("save failed"));
    const handlers = renderDialog("P11");
    fireEvent.change(screen.getByTestId("form-details-juratCity"), { target: { value: "Victoria" } });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledWith({ id: "e1", expectedRevision: 1, data: { juratCity: "Victoria" } }));
    // Let the rejection settle — onGenerate must never fire.
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledTimes(1));
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(handlers.onGenerate).not.toHaveBeenCalled();
  });

  it("keeps the form-details dialog open and Generate retryable when the shared handoff rejects", async () => {
    const rejectedHandoff = vi.fn().mockRejectedValue(new Error("preflight unavailable"));
    renderDialog("P4", { onGenerate: rejectedHandoff });

    fireEvent.click(screen.getByTestId("form-details-generate"));

    await waitFor(() => expect(rejectedHandoff).toHaveBeenCalledWith({ selectedContactId: "c-primary" }));
    await waitFor(() => expect(screen.getByTestId("form-details-dialog")).toBeTruthy());
    await waitFor(() => expect(screen.getByTestId("form-details-generate").textContent).toBe("Generate"));
    await waitFor(() => expect(toast.error).toHaveBeenCalledWith("preflight unavailable"));
  });

  it("P8 retries a failed unblurred city save before handing off to generate", async () => {
    mocks.estateUpdateAsync.mockRejectedValueOnce(new Error("City save failed"));
    const handlers = renderDialog("P8", { initialDeponentId: "c-two" });
    fireEvent.change(screen.getByTestId("form-details-domicileCity"), { target: { value: "Nanaimo" } });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(toast.error).toHaveBeenCalledWith("Failed to save form details: City save failed"));
    expect(handlers.onGenerate).not.toHaveBeenCalled();
    expect((screen.getByTestId("form-details-domicileCity") as HTMLInputElement).value).toBe("Nanaimo");
    await waitFor(() => expect((screen.getByTestId("form-details-generate") as HTMLButtonElement).disabled).toBe(false));

    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledTimes(2));
    expect(mocks.estateUpdateAsync).toHaveBeenLastCalledWith({ id: "e1", expectedRevision: 1, data: { domicileCity: "Nanaimo" } });
    await waitFor(() => expect(handlers.onGenerate).toHaveBeenCalledWith({ deponentId: "c-two" }));
  });

  it("cancelling P8 while its city save is pending never starts the abandoned generation", async () => {
    let finishSave!: (value: { success: true; revision: number }) => void;
    mocks.estateUpdateAsync.mockImplementationOnce(() => new Promise((resolve) => { finishSave = resolve; }));
    const handlers = renderDialog("P8", { initialDeponentId: "c-two" });
    fireEvent.change(screen.getByTestId("form-details-domicileCity"), { target: { value: "Nanaimo" } });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledTimes(1));
    fireEvent.click(screen.getByTestId("form-details-cancel"));
    expect(handlers.onCancel).toHaveBeenCalledOnce();
    await act(async () => { finishSave({ success: true, revision: 2 }); });
    expect(handlers.onGenerate).not.toHaveBeenCalled();
    expect(handlers.onPreview).not.toHaveBeenCalled();
    expect((screen.getByTestId("form-details-generate") as HTMLButtonElement).disabled).toBe(false);
  });

  it("serializes rapid persisted edits and chains the returned revision", async () => {
    let releaseFirst!: (value: { success: true; revision: number }) => void;
    mocks.estateUpdateAsync
      .mockImplementationOnce(() => new Promise((resolve) => { releaseFirst = resolve; }))
      .mockResolvedValueOnce({ success: true, revision: 3 });
    renderDialog("P11");

    const domicile = screen.getByTestId("form-details-deceasedDomicileJurisdiction");
    fireEvent.change(domicile, { target: { value: "Washington" } });
    fireEvent.blur(domicile);
    const city = screen.getByTestId("form-details-juratCity");
    fireEvent.change(city, { target: { value: "Victoria" } });
    fireEvent.blur(city);

    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledTimes(1));
    expect(mocks.estateUpdateAsync).toHaveBeenNthCalledWith(1, {
      id: "e1", expectedRevision: 1, data: { deceasedDomicileJurisdiction: "Washington" },
    });
    releaseFirst({ success: true, revision: 2 });
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenNthCalledWith(2, {
      id: "e1", expectedRevision: 2, data: { juratCity: "Victoria" },
    }));
  });

  it("keeps a rejected persisted-text draft visible for correction or retry", async () => {
    mocks.estateUpdateAsync.mockRejectedValueOnce(new Error("conflict"));
    renderDialog("P11");
    const city = screen.getByTestId("form-details-juratCity") as HTMLInputElement;
    fireEvent.change(city, { target: { value: "Victoria" } });
    fireEvent.blur(city);
    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(city.value).toBe("Victoria"));
  });
});

describe("deponent params", () => {
  it("P3 Generate returns the default (primary) deponent as selectedContactId", () => {
    const handlers = renderDialog("P3");
    fireEvent.click(screen.getByTestId("form-details-generate"));
    expect(handlers.onGenerate).toHaveBeenCalledWith({ selectedContactId: "c-primary" });
  });

  it("P3 Preview returns the deponent as selectedContactId", () => {
    const handlers = renderDialog("P3");
    fireEvent.click(screen.getByTestId("form-details-preview"));
    expect(handlers.onPreview).toHaveBeenCalledWith({ selectedContactId: "c-primary" });
  });

  it("P8 Generate returns the pre-selected co-applicant as deponentId", () => {
    const handlers = renderDialog("P8", { initialDeponentId: "c-two" });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    expect(handlers.onGenerate).toHaveBeenCalledWith({ deponentId: "c-two" });
    expect(mocks.preflightInputs.at(-1)).toMatchObject({ formCode: "P8", selectedContactId: "c-two" });
  });

  it("P8 with only the primary applicant never substitutes them as the co-applicant", () => {
    const handlers = renderDialog("P8", { contacts: [primaryExec], initialDeponentId: "c-two" });
    expect(screen.getByTestId("form-details-no-deponent").textContent).toContain("co-applicant");
    fireEvent.click(screen.getByTestId("form-details-generate"));
    expect(handlers.onGenerate).toHaveBeenCalledWith({});
    expect(mocks.preflightInputs.at(-1).selectedContactId).toBeUndefined();
  });

  it("P8 drops a co-applicant who stops applying while the dialog is open", () => {
    const onGenerate = vi.fn();
    const props: React.ComponentProps<typeof FormDetailsDialog> = {
      open: true, onOpenChange: vi.fn(), formCode: "P8", formName: "Test Form", estateId: "e1",
      estate: baseEstate, contacts: [primaryExec, secondExec], initialDeponentId: "c-two",
      signatoryType: "executor", onSignatoryTypeChange: vi.fn(), signatureDate: "2026-07-11",
      onSignatureDateChange: vi.fn(), onGenerate, onPreview: vi.fn(), onCancel: vi.fn(),
    };
    const { rerender } = render(<FormDetailsDialog {...props} />);
    expect(screen.getByTestId("form-details-single-deponent").textContent).toBe("Second Executor");
    rerender(<FormDetailsDialog {...props} contacts={[primaryExec, { ...secondExec, executorStatus: "renounced" }]} />);
    expect(screen.getByTestId("form-details-no-deponent")).toBeTruthy();
    fireEvent.click(screen.getByTestId("form-details-generate"));
    expect(onGenerate).toHaveBeenCalledWith({});
    expect(mocks.preflightInputs.at(-1).selectedContactId).toBeUndefined();
  });

  it("reopening P8 for another co-applicant selects that row even while the previous deponent remains eligible", () => {
    const onGenerate = vi.fn();
    const thirdExec = { ...secondExec, id: "c-three", name: "Third Executor" };
    const props: React.ComponentProps<typeof FormDetailsDialog> = {
      open: true, onOpenChange: vi.fn(), formCode: "P8", formName: "Test Form", estateId: "e1",
      estate: baseEstate, contacts: [primaryExec, secondExec, thirdExec], initialDeponentId: "c-two",
      signatoryType: "executor", onSignatoryTypeChange: vi.fn(), signatureDate: "2026-07-11",
      onSignatureDateChange: vi.fn(), onGenerate, onPreview: vi.fn(), onCancel: vi.fn(),
    };
    const { rerender } = render(<FormDetailsDialog {...props} />);
    expect(screen.getByTestId("form-details-deponent").textContent).toContain("Second Executor");
    rerender(<FormDetailsDialog {...props} open={false} />);
    rerender(<FormDetailsDialog {...props} initialDeponentId="c-three" />);
    expect(screen.getByTestId("form-details-deponent").textContent).toContain("Third Executor");
    fireEvent.click(screen.getByTestId("form-details-generate"));
    expect(onGenerate).toHaveBeenCalledWith({ deponentId: "c-three" });
    expect(mocks.preflightInputs.at(-1)).toMatchObject({ formCode: "P8", selectedContactId: "c-three" });
  });

  it("P11 defaults to the primary applicant and excludes a lawyer-only deponent", () => {
    const lawyer = { id: "c-law", name: "Counsel Lawyer", role: "lawyer", executorStatus: "" };
    const handlers = renderDialog("P11", {
      estate: { ...baseEstate, applicantType: "lawyer" },
      contacts: [lawyer, primaryExec, secondExec, beneficiary],
    });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    expect(handlers.onGenerate).toHaveBeenCalledWith({ selectedContactId: "c-primary" });
  });

  it("P1 Generate returns no deponent param", () => {
    const handlers = renderDialog("P1");
    fireEvent.click(screen.getByTestId("form-details-generate"));
    expect(handlers.onGenerate).toHaveBeenCalledWith({});
  });

  it("Cancel fires onCancel and no mutations", () => {
    const handlers = renderDialog("P3");
    fireEvent.click(screen.getByTestId("form-details-cancel"));
    expect(handlers.onCancel).toHaveBeenCalledTimes(1);
    expect(mocks.estateUpdate).not.toHaveBeenCalled();
  });
});

describe("P9 recipient checklist (real delivery rows)", () => {
  beforeEach(() => {
    Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
    Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
    Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
    Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
  });

  function selectPersonalDelivery(): void {
    fireEvent.click(screen.getByTestId("p9-method-c-ben"));
    fireEvent.click(screen.getByRole("option", { name: "Personal Delivery" }));
  }

  it("saves Avery's selected personal delivery and unblurred date before generation", async () => {
    mocks.recipients = [{ contactId: "c-ben", name: "Avery Calder-Quay", address: "300 Elm St", email: "" }];
    const handlers = renderDialog("P9");
    fireEvent.click(screen.getByTestId("p9-served-c-ben"));
    selectPersonalDelivery();
    fireEvent.change(screen.getByTestId("p9-date-c-ben"), { target: { value: "2026-09-06" } });
    expect(mocks.deliveryUpsert).not.toHaveBeenCalled();
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(handlers.onGenerate).toHaveBeenCalledOnce());
    expect(mocks.deliveryUpsert).toHaveBeenCalledWith(expect.objectContaining({
      estateId: "e1", contactId: "c-ben", recipientName: "Avery Calder-Quay",
      deliveryMethod: "personal", deliveryDate: "2026-09-06",
    }));
    expect(mocks.deliveryFetch).toHaveBeenCalledWith({ estateId: "e1" });
    expect(mocks.deliveryUpsert.mock.invocationCallOrder[0]).toBeLessThan(handlers.onGenerate.mock.invocationCallOrder[0]);
  });

  it("warns on a no-notice P9 path but continues to the explicit generation decision without adding applicant delivery", async () => {
    const handlers = renderDialog("P9", { contacts: [primaryExec], estate: { ...baseEstate, grantType: "probate", hasWill: 1, noticeContactsComplete: "yes" } });
    expect(screen.getByTestId("p9-no-recipients").textContent).toContain("P2");
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("p9-delivery-error").textContent).toContain("P2"));
    await waitFor(() => expect(handlers.onGenerate).toHaveBeenCalledOnce());
    expect(mocks.deliveryUpsert).not.toHaveBeenCalled();
    expect(mocks.bulkCreate).not.toHaveBeenCalled();
  });

  it("keeps an incomplete selected recipient unsaved while continuing to the explicit blank-draft generation decision", async () => {
    mocks.recipients = [{ contactId: "c-ben", name: "Avery Calder-Quay", address: "", email: "" }];
    const handlers = renderDialog("P9");
    fireEvent.click(screen.getByTestId("p9-served-c-ben"));
    selectPersonalDelivery();
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("p9-delivery-error").textContent).toContain("generate a blank draft"));
    await waitFor(() => expect(handlers.onGenerate).toHaveBeenCalledOnce());
    expect(mocks.deliveryUpsert).not.toHaveBeenCalled();
  });

  it("retains a failed delivery save for retry and never generates from the failed row", async () => {
    mocks.recipients = [{ contactId: "c-ben", name: "Avery Calder-Quay", address: "", email: "" }];
    mocks.deliveryUpsert.mockRejectedValueOnce(new Error("Delivery save failed"));
    const handlers = renderDialog("P9");
    fireEvent.click(screen.getByTestId("p9-served-c-ben"));
    selectPersonalDelivery();
    fireEvent.change(screen.getByTestId("p9-date-c-ben"), { target: { value: "2026-09-06" } });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("p9-delivery-error").textContent).toContain("Delivery save failed"));
    expect(handlers.onGenerate).not.toHaveBeenCalled();
    expect(mocks.deliveries).toEqual([]);
    expect((screen.getByTestId("p9-date-c-ben") as HTMLInputElement).value).toBe("2026-09-06");
    await waitFor(() => expect((screen.getByTestId("form-details-generate") as HTMLButtonElement).disabled).toBe(false));
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(handlers.onGenerate).toHaveBeenCalledOnce());
    expect(mocks.deliveryUpsert).toHaveBeenCalledTimes(2);
  });

  it("waits for the actual delivery write and suppresses generation after cancellation", async () => {
    let finishSave!: (value: object) => void;
    mocks.deliveryUpsert.mockImplementationOnce(() => new Promise((resolve) => { finishSave = resolve; }));
    mocks.recipients = [{ contactId: "c-ben", name: "Avery Calder-Quay", address: "", email: "" }];
    const handlers = renderDialog("P9");
    fireEvent.click(screen.getByTestId("p9-served-c-ben"));
    selectPersonalDelivery();
    fireEvent.change(screen.getByTestId("p9-date-c-ben"), { target: { value: "2026-09-06" } });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(mocks.deliveryUpsert).toHaveBeenCalledOnce());
    expect(handlers.onGenerate).not.toHaveBeenCalled();
    fireEvent.click(screen.getByTestId("form-details-cancel"));
    await act(async () => { finishSave({}); });
    expect(handlers.onGenerate).not.toHaveBeenCalled();
    expect(handlers.onPreview).not.toHaveBeenCalled();
  });

  it("does not continue from cached proof when the fresh delivery check fails", async () => {
    mocks.deliveries = [{ id: "d-ben", contactId: "c-ben", recipientName: "Avery Calder-Quay", deliveryMethod: "personal", deliveryDate: "2026-09-06", dispensedByOrder: 0 }];
    mocks.deliveryFetch.mockRejectedValueOnce(new Error("Delivery check unavailable"));
    const handlers = renderDialog("P9");
    fireEvent.click(screen.getByTestId("form-details-preview"));
    await waitFor(() => expect(screen.getByTestId("p9-delivery-error").textContent).toContain("Delivery check unavailable"));
    expect(handlers.onPreview).not.toHaveBeenCalled();
  });

  it("does not save the same delivery twice after blur commits the date", async () => {
    mocks.recipients = [{ contactId: "c-ben", name: "Avery Calder-Quay", address: "", email: "" }];
    const handlers = renderDialog("P9");
    fireEvent.click(screen.getByTestId("p9-served-c-ben"));
    selectPersonalDelivery();
    const date = screen.getByTestId("p9-date-c-ben");
    fireEvent.change(date, { target: { value: "2026-09-06" } });
    await act(async () => { fireEvent.blur(date); });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(handlers.onGenerate).toHaveBeenCalledOnce());
    expect(mocks.deliveryUpsert).toHaveBeenCalledOnce();
  });

  it("#23: checking an unserved recipient links a draft row without fabricating a method or date", () => {
    mocks.recipients = [{ contactId: "c-ben", name: "Bob Beneficiary", address: "300 Elm St", email: "bob@example.com" }];
    renderDialog("P9");
    fireEvent.click(screen.getByTestId("p9-served-c-ben"));
    expect(mocks.deliveryUpsert).not.toHaveBeenCalled();
    expect(screen.getByTestId("p9-date-c-ben")).toBeTruthy();
    const methodSelect = screen.getByTestId("p9-method-c-ben") as HTMLSelectElement;
    expect(methodSelect.value).toBe("");
  });

  it("unchecking a served recipient deletes the delivery row", async () => {
    mocks.recipients = [{ contactId: "c-ben", name: "Bob Beneficiary", address: "300 Elm St", email: "" }];
    mocks.deliveries = [{ id: "d-ben", contactId: "c-ben", recipientName: "Bob Beneficiary", deliveryMethod: "ordinary_mail", deliveryDate: "2026-07-01", ackDate: "", dispensedByOrder: 0 }];
    renderDialog("P9");
    await act(async () => { fireEvent.click(screen.getByTestId("p9-served-c-ben")); });
    expect(mocks.deliveryDelete).toHaveBeenCalledWith({ id: "d-ben", estateId: "e1" });
  });

  it("ack-date edit commits on BLUR and re-upserts the row with the new ackDate", async () => {
    mocks.recipients = [{ contactId: "c-ben", name: "Bob Beneficiary", address: "", email: "" }];
    mocks.deliveries = [{ id: "d-ben", contactId: "c-ben", recipientName: "Bob Beneficiary", deliveryMethod: "electronic", deliveryDate: "2026-07-01", emailAddress: "bob@example.com", ackDate: "", dispensedByOrder: 0 }];
    renderDialog("P9");
    const input = screen.getByTestId("p9-ack-c-ben");
    fireEvent.change(input, { target: { value: "2026-07-05" } });
    expect(mocks.deliveryUpsert).not.toHaveBeenCalled();
    await act(async () => { fireEvent.blur(input); });
    expect(mocks.deliveryUpsert).toHaveBeenCalledWith(expect.objectContaining({ id: "d-ben", ackDate: "2026-07-05", deliveryMethod: "electronic" }));
  });

  it("delivery-date keystrokes never mutate mid-edit — a transient empty value is not persisted", async () => {
    mocks.recipients = [{ contactId: "c-ben", name: "Bob Beneficiary", address: "", email: "" }];
    mocks.deliveries = [{ id: "d-ben", contactId: "c-ben", recipientName: "Bob Beneficiary", deliveryMethod: "ordinary_mail", deliveryDate: "2026-07-01", ackDate: "", dispensedByOrder: 0 }];
    renderDialog("P9");
    const input = screen.getByTestId("p9-date-c-ben");
    // browser mid-edit state: incomplete date reports ""
    fireEvent.change(input, { target: { value: "" } });
    expect(mocks.deliveryUpsert).not.toHaveBeenCalled();
    // user completes the edit; blur commits the final value once
    fireEvent.change(input, { target: { value: "2026-07-04" } });
    await act(async () => { fireEvent.blur(input); });
    expect(mocks.deliveryUpsert).toHaveBeenCalledTimes(1);
    expect(mocks.deliveryUpsert).toHaveBeenCalledWith(expect.objectContaining({ id: "d-ben", deliveryDate: "2026-07-04" }));
  });

  it("shows the amber e-ack warning when an electronic row has no ackDate, and the ok line when all acked", () => {
    mocks.recipients = [{ contactId: "c-ben", name: "Bob Beneficiary", address: "", email: "" }];
    mocks.deliveries = [{ id: "d-ben", contactId: "c-ben", recipientName: "Bob Beneficiary", deliveryMethod: "electronic", deliveryDate: "2026-07-01", ackDate: "", dispensedByOrder: 0 }];
    renderDialog("P9");
    expect(screen.getByTestId("p9-ack-status-missing")).toBeTruthy();
    expect(screen.queryByTestId("p9-ack-status-ok")).toBeNull();
  });

  it("e-ack status excludes PGT electronic rows, mirroring buildP9's printable filter", () => {
    // Unacked PGT electronic row + acked regular electronic row → clauses DO
    // print (buildP9 excludes PGT from the gate), so the ok line must show.
    mocks.recipients = [{ contactId: "c-ben", name: "Bob Beneficiary", address: "", email: "" }];
    mocks.deliveries = [
      { id: "d-ben", contactId: "c-ben", recipientName: "Bob Beneficiary", deliveryMethod: "electronic", deliveryDate: "2026-07-01", ackDate: "2026-07-02", dispensedByOrder: 0 },
      { id: "d-pgt", contactId: "c-pgt", recipientName: "Public Guardian and Trustee", deliveryMethod: "electronic", deliveryDate: "2026-07-01", ackDate: "", dispensedByOrder: 0 },
    ];
    render(
      <FormDetailsDialog
        open={true}
        onOpenChange={() => {}}
        formCode="P9"
        formName="Affidavit of Delivery"
        estateId="e1"
        estate={baseEstate}
        contacts={[primaryExec, beneficiary, { id: "c-pgt", name: "Public Guardian and Trustee", role: "", executorStatus: "", recipientType: "pgt" }]}
        signatoryType="executor"
        signatureDate="2026-07-11"
        onGenerate={vi.fn()}
        onPreview={vi.fn()}
        onCancel={vi.fn()}
        onSignatoryTypeChange={vi.fn()}
        onSignatureDateChange={vi.fn()}
      />,
    );
    expect(screen.getByTestId("p9-ack-status-ok")).toBeTruthy();
    expect(screen.queryByTestId("p9-ack-status-missing")).toBeNull();
  });

  it("shows the ok e-ack line when every electronic row is acknowledged", () => {
    mocks.recipients = [{ contactId: "c-ben", name: "Bob Beneficiary", address: "", email: "" }];
    mocks.deliveries = [{ id: "d-ben", contactId: "c-ben", recipientName: "Bob Beneficiary", deliveryMethod: "electronic", deliveryDate: "2026-07-01", ackDate: "2026-07-02", dispensedByOrder: 0 }];
    renderDialog("P9");
    expect(screen.getByTestId("p9-ack-status-ok")).toBeTruthy();
    expect(screen.queryByTestId("p9-ack-status-missing")).toBeNull();
  });

  it("Mark All Delivered routes through delivery.bulkCreate with the shared date + method, and offers no registered mail", async () => {
    mocks.recipients = [
      { contactId: "c-ben", name: "Bob Beneficiary", address: "", email: "" },
      { contactId: "c-car", name: "Carol Beneficiary", address: "", email: "" },
    ];
    renderDialog("P9");
    fireEvent.click(screen.getByRole("button", { name: /Mark All Delivered \(2\)/ }));
    // Registered mail never prints on the P9 face — bulk-create must not offer it.
    expect(screen.queryByRole("button", { name: "Registered Mail" })).toBeNull();
    fireEvent.change(screen.getByTestId("p9-bulk-delivery-date"), { target: { value: "2026-07-01" } });
    await act(async () => { fireEvent.click(screen.getByRole("button", { name: "Ordinary Mail" })); });
    expect(mocks.bulkCreate).toHaveBeenCalledWith({ estateId: "e1", deliveryMethod: "ordinary_mail", deliveryDate: "2026-07-01" });
  });

  it("electronic rows expose an email input that commits on blur", async () => {
    mocks.recipients = [{ contactId: "c-ben", name: "Bob Beneficiary", address: "", email: "" }];
    mocks.deliveries = [{ id: "d-ben", contactId: "c-ben", recipientName: "Bob Beneficiary", deliveryMethod: "electronic", deliveryDate: "2026-07-01", emailAddress: "", ackDate: "", dispensedByOrder: 0 }];
    renderDialog("P9");
    const input = screen.getByTestId("p9-email-c-ben");
    fireEvent.change(input, { target: { value: "bob@example.com" } });
    expect(mocks.deliveryUpsert).not.toHaveBeenCalled();
    await act(async () => { fireEvent.blur(input); });
    expect(mocks.deliveryUpsert).toHaveBeenCalledWith(expect.objectContaining({ id: "d-ben", emailAddress: "bob@example.com", deliveryMethod: "electronic" }));
  });

  it("Generate and Preview are disabled while a persisted write is in flight", () => {
    mocks.estateUpdatePending = true;
    const handlers = renderDialog("P3");
    const generate = screen.getByTestId("form-details-generate") as HTMLButtonElement;
    const preview = screen.getByTestId("form-details-preview") as HTMLButtonElement;
    expect(generate.disabled).toBe(true);
    expect(preview.disabled).toBe(true);
    fireEvent.click(generate);
    expect(handlers.onGenerate).not.toHaveBeenCalled();
  });
});

describe("gap note", () => {
  it("shows the advisory missing-fields note when preflight reports gaps", () => {
    mocks.preflightData = { formCode: "P3", ok: false, gaps: [{ requirementId: "a" }, { requirementId: "b" }] };
    renderDialog("P3");
    // Nick 2026-09-02: soft gaps are never announced as "required" — only a
    // hard (applicability) gap is; this fixture's two gaps are soft.
    expect(screen.getByTestId("form-details-gap-note").textContent).toContain("2 items to complete");
    expect(screen.getByTestId("form-details-gap-note").textContent).toContain("none blocks generation");
    expect(screen.getByTestId("form-details-gap-note").textContent).not.toContain("required field");
  });

  it("hides the note when preflight is clean", () => {
    renderDialog("P3");
    expect(screen.queryByTestId("form-details-gap-note")).toBeNull();
  });
});

describe("helpers", () => {
  it("deponentCandidates filters to applying executors/applicants and lawyers", () => {
    const pool = __test.deponentCandidates([primaryExec, secondExec, beneficiary, { id: "c-ren", name: "R", role: "executor", executorStatus: "renounced" }, { id: "c-law", name: "Lawyer", role: "lawyer" }]);
    expect(pool.applicants.map((c: any) => c.id)).toEqual(["c-primary", "c-two"]);
    expect(pool.lawyers.map((c: any) => c.id)).toEqual(["c-law"]);
  });

  it("deponentCandidates puts the Settings lawyer first when lawyerName is set (no contact row needed)", () => {
    const pool = __test.deponentCandidates([primaryExec, { id: "c-law", name: "Contact Lawyer", role: "lawyer" }], "Settings Lawyer");
    expect(pool.lawyers.map((c: any) => c.id)).toEqual(["settings_lawyer", "c-law"]);
    expect(pool.lawyers[0].name).toBe("Settings Lawyer");
  });

  // Nick ruling C (2026-07-22): the lawyer is the default ONLY for forms that
  // prefer it (P9 delivery, prefersLawyer=true). Other affidavits default to the
  // applicant even when a lawyer is also a valid fact-witness candidate.
  it("defaultDeponentId picks the lawyer only when the form prefers it, else the applicant", () => {
    const pool = { applicants: [secondExec, primaryExec], lawyers: [{ id: "c-law", name: "Lawyer", role: "lawyer" }] };
    // prefersLawyer=true (P9): the lawyer
    expect(__test.defaultDeponentId(pool, true)).toBe("c-law");
    // prefersLawyer=false (applicant-sworn): the primary applicant, even with a lawyer present
    expect(__test.defaultDeponentId(pool, false)).toBe("c-primary");
    expect(__test.defaultDeponentId({ applicants: [secondExec, primaryExec], lawyers: [] }, false)).toBe("c-primary");
    expect(__test.defaultDeponentId({ applicants: [secondExec], lawyers: [] }, true)).toBe("c-two");
    expect(__test.defaultDeponentId({ applicants: [], lawyers: [] }, false)).toBe("");
  });
});

describe("Deponent default + lawyer warning (Nick rulings G3 2026-07-12, C 2026-07-22)", () => {
  it("P3 defaults the deponent to the applicant, not the Settings lawyer (Nick ruling C, 2026-07-22)", async () => {
    mocks.settings = { lawyerName: "Nick Lawyer" };
    const handlers = renderDialog("P3");
    // No lawyer-deponent warning at the applicant default.
    expect(screen.queryByTestId("form-details-lawyer-deponent-warning")).toBeNull();
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => {
      expect(handlers.onGenerate).toHaveBeenCalledWith(expect.objectContaining({ selectedContactId: "c-primary" }));
    });
  });

  it("P4 never offers the lawyer — a stale lawyer selection falls back to the applicant (Rule 15, 2026-08-04)", async () => {
    // Rule 15 superseded the warn-only lawyer selection on P3–P7: the pool is
    // applicants-only, so a saved/stale settings-lawyer selection is invalid
    // and the dialog re-defaults to the applicant with no warning to show.
    mocks.settings = { lawyerName: "Nick Lawyer" };
    const handlers = renderDialog("P4", { initialDeponentId: "settings_lawyer" } as any);
    expect(screen.queryByTestId("form-details-lawyer-deponent-warning")).toBeNull();
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => {
      expect(handlers.onGenerate).toHaveBeenCalledWith(expect.objectContaining({ selectedContactId: "c-primary" }));
    });
    expect(handlers.onGenerate).not.toHaveBeenCalledWith(expect.objectContaining({ selectedContactId: "settings_lawyer" }));
  });

  it.each(["P10", "P14", "P15", "P26"])(
    "%s never offers the lawyer — a stale lawyer selection falls back to the applicant (Rule 18)",
    async (formCode) => {
      mocks.settings = { lawyerName: "Nick Lawyer" };
      const handlers = renderDialog(formCode, { initialDeponentId: "settings_lawyer" } as any);
      fireEvent.click(screen.getByTestId("form-details-generate"));
      await waitFor(() => {
        expect(handlers.onGenerate).toHaveBeenCalledWith(expect.objectContaining({ selectedContactId: "c-primary" }));
      });
      expect(handlers.onGenerate).not.toHaveBeenCalledWith(expect.objectContaining({ selectedContactId: "settings_lawyer" }));
    },
  );

  it("does not warn for P9 (Affidavit of Delivery) — a lawyer legitimately swears delivery", () => {
    mocks.settings = { lawyerName: "Nick Lawyer" };
    renderDialog("P9", { initialDeponentId: "settings_lawyer" } as any);
    expect(screen.getByText("The lawyer who swears or affirms this affidavit.")).toBeTruthy();
  });

  it("P15PLUS-004: P16 shows the presence warning until the deponent's presence at signing is confirmed", () => {
    // Unconfirmed ("" default) → warn-only note on the deponent picker.
    renderDialog("P16");
    expect(screen.getByTestId("form-details-p16-presence-warning")).toBeTruthy();
  });

  it("P15PLUS-004: no P16 presence warning once the estate records presence = yes (and never on other forms)", () => {
    renderDialog("P16", { estate: { ...baseEstate, p16DeponentPresentAtSigning: "yes" } as any });
    expect(screen.queryByTestId("form-details-p16-presence-warning")).toBeNull();
    cleanup();
    renderDialog("P3");
    expect(screen.queryByTestId("form-details-p16-presence-warning")).toBeNull();
  });

  it("P11 (applicants-only) never offers the Settings lawyer", async () => {
    mocks.settings = { lawyerName: "Nick Lawyer" };
    const handlers = renderDialog("P11");
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => {
      expect(handlers.onGenerate).toHaveBeenCalledWith(expect.objectContaining({ selectedContactId: "c-primary" }));
    });
  });

  it("P8 (co-applicant deponentId) never offers the Settings lawyer", async () => {
    mocks.settings = { lawyerName: "Nick Lawyer" };
    // FormsTab always opens P8 per co-applicant with initialDeponentId — mirror that
    const handlers = renderDialog("P8", { initialDeponentId: "c-two" } as any);
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => {
      expect(handlers.onGenerate).toHaveBeenCalledWith(expect.objectContaining({ deponentId: "c-two" }));
    });
    expect(handlers.onGenerate).not.toHaveBeenCalledWith(expect.objectContaining({ deponentId: "settings_lawyer" }));
  });

  // Rule 10 R3 (Nick, 2026-07-22) — the estate #17 no-applicant edge. An applicant-sworn
  // form with no applying applicant/executor (only the Settings lawyer) must show the
  // honest blank-draft note, NOT the lawyer read-only, and must swear nobody (Rule 8c: a
  // lawyer can never be silently sworn as the applicant).
  it("P5 with no applying applicant shows the blank-draft note (not the lawyer) and swears nobody", async () => {
    mocks.settings = { lawyerName: "Nick Lawyer" };
    // Only a non-applying contact on file → no applicant/executor available to swear P5.
    const handlers = renderDialog("P5", { contacts: [beneficiary] } as any);
    expect(screen.getByTestId("form-details-no-deponent")).toBeTruthy();
    expect(screen.queryByTestId("form-details-single-deponent")).toBeNull();
    expect(screen.queryByTestId("form-details-deponent")).toBeNull();
    expect(screen.queryByTestId("form-details-lawyer-deponent-warning")).toBeNull();
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => {
      expect(handlers.onGenerate).toHaveBeenCalled();
    });
    expect(handlers.onGenerate.mock.calls[0][0].selectedContactId).toBeUndefined();
  });
});

// ─── Silent-failure regressions (review of a800bb2) ──────────────────
//
// Every case here is a path where the dialog previously dropped, hid or
// overwrote a fact the sworn P9 depends on. They are contract tests: the
// message text and testids are the user-visible promise, not internals.

describe("silent-failure regressions (P9 delivery + preflight)", () => {
  beforeEach(() => {
    Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
    Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
    Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
    Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
  });

  const recordedBen = { id: "d-ben", contactId: "c-ben", recipientName: "Bob Beneficiary", recipientAddress: "300 Elm St", deliveryMethod: "personal", deliveryDate: "2026-01-10", emailAddress: "", ackDate: "", dispensedByOrder: 0 };
  const benRecipient = { contactId: "c-ben", name: "Bob Beneficiary", address: "300 Elm St", email: "" };

  it("SF-001: a second edit during an in-flight save is written after it, not dropped", async () => {
    mocks.recipients = [benRecipient];
    mocks.deliveries = [{ ...recordedBen }];
    let finishFirst!: (value: object) => void;
    mocks.deliveryUpsert.mockImplementationOnce(() => new Promise((resolve) => { finishFirst = resolve; }));
    renderDialog("P9");

    const date = screen.getByTestId("p9-date-c-ben");
    fireEvent.change(date, { target: { value: "2026-02-11" } });
    await act(async () => { fireEvent.blur(date); });
    await waitFor(() => expect(mocks.deliveryUpsert).toHaveBeenCalledOnce());

    // De-dup still holds: re-blurring the unchanged value writes nothing extra.
    await act(async () => { fireEvent.blur(date); });
    expect(mocks.deliveryUpsert).toHaveBeenCalledOnce();

    // A genuinely new edit while the first save is in flight must be chained, not lost.
    fireEvent.click(screen.getByTestId("p9-method-c-ben"));
    await act(async () => { fireEvent.click(screen.getByRole("option", { name: "Electronic (Email/Fax)" })); });
    await act(async () => { finishFirst({}); });

    await waitFor(() => expect(mocks.deliveryUpsert).toHaveBeenCalledTimes(2));
    expect(mocks.deliveryUpsert).toHaveBeenLastCalledWith(expect.objectContaining({
      id: "d-ben", deliveryMethod: "electronic", deliveryDate: "2026-02-11",
    }));
  });

  it("SF-002: a failed delivery load renders no rows, offers retry, and blocks generation", async () => {
    const refetch = vi.fn();
    mocks.recipients = [benRecipient];
    mocks.deliveryListQuery = { data: undefined, isError: true, refetch };
    const handlers = renderDialog("P9");

    expect(screen.queryByTestId("p9-served-c-ben")).toBeNull();
    expect(screen.queryByTestId("p9-recipient-row-c-ben")).toBeNull();
    const alert = screen.getByTestId("p9-delivery-unavailable");
    expect(alert.getAttribute("role")).toBe("alert");
    expect(alert.textContent).toContain("could not be loaded");

    fireEvent.click(screen.getByTestId("p9-delivery-retry"));
    expect(refetch).toHaveBeenCalled();

    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("p9-delivery-error").textContent).toContain("could not be loaded"));
    expect(handlers.onGenerate).not.toHaveBeenCalled();
  });

  it("SF-002: a still-loading delivery list is not treated as an empty one", async () => {
    mocks.deliveryListQuery = { data: undefined, isError: false, refetch: vi.fn() };
    mocks.recipientsQuery = { data: undefined, isError: false, refetch: vi.fn() };
    const handlers = renderDialog("P9");

    expect(screen.getByTestId("p9-delivery-loading")).toBeTruthy();
    expect(screen.queryByTestId("p9-served-c-ben")).toBeNull();
    expect(screen.queryByTestId("p9-no-recipients")).toBeNull();

    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("form-details-generate")).toBeTruthy());
    expect(handlers.onGenerate).not.toHaveBeenCalled();
  });

  it("SF-003: a staged row with a method the P9 face cannot print blocks generation", async () => {
    mocks.recipients = [benRecipient];
    mocks.deliveries = [{ ...recordedBen, deliveryMethod: "registered_mail", trackingNumber: "RM123" }];
    const handlers = renderDialog("P9");

    // Keystroke only — the date input stages the row without committing it.
    fireEvent.change(screen.getByTestId("p9-date-c-ben"), { target: { value: "2026-02-11" } });
    fireEvent.click(screen.getByTestId("form-details-generate"));

    await waitFor(() => expect(screen.getByTestId("p9-delivery-error").textContent).toContain("ordinary mail, personal or electronic"));
    expect(handlers.onGenerate).not.toHaveBeenCalled();
    expect(mocks.deliveryUpsert).not.toHaveBeenCalledWith(expect.objectContaining({ deliveryMethod: "registered_mail" }));
  });

  it("SF-004: a failed bulk write keeps blocking until a later write actually succeeds", async () => {
    mocks.recipients = [benRecipient, { contactId: "c-car", name: "Carol Beneficiary", address: "", email: "" }];
    mocks.deliveries = [{ ...recordedBen }];
    mocks.bulkCreate.mockRejectedValueOnce(new Error("bulk failed"));
    const handlers = renderDialog("P9");

    fireEvent.click(screen.getByRole("button", { name: /Mark All Delivered \(1\)/ }));
    fireEvent.change(screen.getByTestId("p9-bulk-delivery-date"), { target: { value: "2026-07-01" } });
    await act(async () => { fireEvent.click(screen.getByRole("button", { name: "Ordinary Mail" })); });
    await waitFor(() => expect(screen.getByTestId("p9-delivery-error").textContent).toContain("bulk failed"));

    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("p9-delivery-error").textContent).toContain("bulk failed"));
    expect(handlers.onGenerate).not.toHaveBeenCalled();

    const date = screen.getByTestId("p9-date-c-ben");
    fireEvent.change(date, { target: { value: "2026-02-11" } });
    await act(async () => { fireEvent.blur(date); });
    await waitFor(() => expect(mocks.deliveryUpsert).toHaveBeenCalledOnce());
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(handlers.onGenerate).toHaveBeenCalledOnce());
  });

  it("SF-005: an unavailable advisory preflight says so instead of showing a clean gap list", () => {
    mocks.preflightQuery = { data: undefined, isError: true };
    renderDialog("P3");
    expect(screen.getByTestId("form-details-preflight-unavailable").textContent).toContain("Requirements could not be checked");
    expect(screen.queryByTestId("form-details-gap-note")).toBeNull();
    expect((screen.getByTestId("form-details-generate") as HTMLButtonElement).disabled).toBe(false);
  });

  it("SF-009: a jurat-city keystroke typed while the delivery check runs is still saved first", async () => {
    mocks.recipients = [benRecipient];
    mocks.deliveries = [{ ...recordedBen }];
    let finishFetch!: (rows: any[]) => void;
    mocks.deliveryFetch.mockImplementationOnce(() => new Promise((resolve) => { finishFetch = resolve; }));
    const handlers = renderDialog("P9");

    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(mocks.deliveryFetch).toHaveBeenCalledOnce());
    // P9's persisted jurat city is the domicileCity column (ESTATE_JURAT_CITY_FIELD).
    fireEvent.change(screen.getByTestId("form-details-domicileCity"), { target: { value: "Nanaimo" } });
    await act(async () => { finishFetch(mocks.deliveries); });

    await waitFor(() => expect(mocks.estateUpdateAsync).toHaveBeenCalledWith(expect.objectContaining({ data: { domicileCity: "Nanaimo" } })));
    await waitFor(() => expect(handlers.onGenerate).toHaveBeenCalledOnce());
    expect(mocks.estateUpdateAsync.mock.invocationCallOrder[0]).toBeLessThan(handlers.onGenerate.mock.invocationCallOrder[0]);
  });

  it("CITE-001: the missing-acknowledgement warning cites Rule 25-2 (6) and Form P9 section 2", () => {
    mocks.recipients = [benRecipient];
    mocks.deliveries = [{ ...recordedBen, deliveryMethod: "electronic", emailAddress: "bob@example.com", ackDate: "" }];
    renderDialog("P9");
    const warning = screen.getByTestId("p9-ack-status-missing").textContent || "";
    expect(warning).toContain("Rule 25-2 (6)");
    expect(warning).toContain("Form P9 section 2");
    expect(warning).not.toContain("Rule 25-2(7)");
  });
});
