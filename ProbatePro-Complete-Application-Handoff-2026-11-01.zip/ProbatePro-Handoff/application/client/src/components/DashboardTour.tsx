import React, { useEffect, useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";

const TOUR_STEPS = [
  {
    target: "new-estate-action",
    eyebrow: "Getting started",
    title: "Create your first estate file",
    description: "Use New Estate to open a matter, set its file type, and choose the registry before completing the intake.",
  },
  {
    target: "estate-workspace",
    eyebrow: "Stay organised",
    title: "Find the file you need",
    description: "Search across estate names, file numbers, registries, and notes, then narrow the list by its current filing status.",
  },
  {
    target: "dashboard-overview",
    eyebrow: "Keep work moving",
    title: "Use the dashboard as your control centre",
    description: "Your estate metrics, deadlines, forms, and firm preferences stay connected from this workspace.",
  },
] as const;

export function DashboardTour({
  open,
  onComplete,
  onDismiss,
  isSaving = false,
}: {
  open: boolean;
  onComplete: () => void;
  onDismiss: () => void;
  isSaving?: boolean;
}) {
  const [stepIndex, setStepIndex] = useState(0);
  const step = TOUR_STEPS[stepIndex];
  const isLastStep = stepIndex === TOUR_STEPS.length - 1;

  useEffect(() => {
    if (!open) {
      setStepIndex(0);
      return;
    }
    const target = document.querySelector<HTMLElement>(`[data-tour="${step.target}"]`);
    if (!target) return;
    const timer = window.setTimeout(() => {
      target.setAttribute("data-tour-highlight", "true");
      target.scrollIntoView?.({ behavior: window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "center" });
    }, 20);
    return () => {
      window.clearTimeout(timer);
      target.removeAttribute("data-tour-highlight");
    };
  }, [open, step.target]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[90]" role="dialog" aria-label="ProbatePro dashboard tour" data-testid="dashboard-tour">
      <div className="absolute inset-0 bg-slate-950/45 backdrop-blur-[1px]" aria-hidden="true" />
      <section className="tour-card fixed bottom-4 left-4 right-4 z-[100] mx-auto max-w-md rounded-2xl border bg-background p-5 shadow-2xl sm:left-auto sm:right-6" aria-live="polite">
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-primary">{step.eyebrow}</p>
            <h2 className="mt-1 text-lg font-semibold tracking-tight">{step.title}</h2>
          </div>
          <Button variant="ghost" size="icon" className="-mr-2 -mt-2 shrink-0" onClick={onDismiss} disabled={isSaving} aria-label="Skip dashboard tour">
            <X className="h-4 w-4" />
          </Button>
        </div>
        <p className="mt-3 text-sm leading-6 text-muted-foreground">{step.description}</p>
        <div className="mt-5 flex items-center justify-between gap-3">
          <span className="text-xs font-medium text-muted-foreground">Step {stepIndex + 1} of {TOUR_STEPS.length}</span>
          <div className="flex items-center gap-2">
            {stepIndex > 0 && (
              <Button variant="ghost" size="sm" onClick={() => setStepIndex((index) => index - 1)} disabled={isSaving}>Back</Button>
            )}
            <Button size="sm" onClick={isLastStep ? onComplete : () => setStepIndex((index) => index + 1)} disabled={isSaving} data-testid="dashboard-tour-next">
              {isSaving ? "Saving…" : isLastStep ? "Finish tour" : "Next"}
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
