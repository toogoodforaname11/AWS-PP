import * as React from "react";
import { AlertTriangle, Loader2, UsersRound } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

type ApplicantRole = "executor_applicant" | "applicant";

export function P8CoApplicantIntakeDialog({
  open,
  estateId,
  onOpenChange,
  onCreated,
  onGoToContacts,
}: {
  open: boolean;
  estateId: string;
  onOpenChange: (open: boolean) => void;
  onCreated: (contactId: string) => void;
  onGoToContacts?: () => void;
}) {
  const [name, setName] = React.useState("");
  const [address, setAddress] = React.useState("");
  const [occupation, setOccupation] = React.useState("");
  const [relationship, setRelationship] = React.useState("");
  const [role, setRole] = React.useState<ApplicantRole>("executor_applicant");
  const [formError, setFormError] = React.useState("");
  const [invalidFields, setInvalidFields] = React.useState<string[]>([]);
  const utils = trpc.useUtils();

  React.useEffect(() => {
    if (!open) return;
    setName("");
    setAddress("");
    setOccupation("");
    setRelationship("");
    setRole("executor_applicant");
    setFormError("");
    setInvalidFields([]);
  }, [open]);

  const createMutation = trpc.contact.create.useMutation({
    onSuccess: (created, variables) => {
      // Do not wait for query invalidation before opening the P8 details
      // dialog. A just-created co-applicant otherwise can be absent from the
      // stale contact snapshot, so the P8 deponent resolver drops the selected
      // id and the user is stranded without a DOCX. Seed the authenticated
      // contact cache with the exact saved facts, then refresh in the background.
      utils.contact.list.setData({ estateId }, (current) => {
        const contacts = Array.isArray(current) ? current : [];
        const savedContact = { ...variables, id: created.id };
        const existingIndex = contacts.findIndex((contact: any) => contact?.id === created.id);
        return existingIndex === -1
          ? [...contacts, savedContact]
          : contacts.map((contact: any, index: number) => index === existingIndex ? { ...contact, ...savedContact } : contact);
      });
      void utils.contact.list.invalidate({ estateId });
      onOpenChange(false);
      onCreated(created.id);
    },
    onError: (error) => {
      const message = error.message || "The co-applicant could not be saved. No Form P8 was generated.";
      setFormError(message);
      toast.error(message);
    },
  });

  const save = () => {
    const requiredFields = [
      { id: "name", label: "full legal name", value: name },
      { id: "address", label: "residential address", value: address },
      { id: "occupation", label: "occupation", value: occupation },
      { id: "relationship", label: "relationship to the deceased", value: relationship },
    ];
    const missing = requiredFields.filter((field) => !field.value.trim());
    if (missing.length > 0) {
      setInvalidFields(missing.map((field) => field.id));
      setFormError(`Complete the co-applicant’s ${missing.map((field) => field.label).join(", ")} before continuing. Form P8 has not been generated yet.`);
      return;
    }
    setFormError("");
    setInvalidFields([]);
    const applyingExecutor = role === "executor_applicant";
    void createMutation.mutateAsync({
      estateId,
      name: name.trim(),
      role: applyingExecutor ? "executor,applicant" : "applicant",
      executorStatus: applyingExecutor ? "applying" : "",
      executorRank: "alternate",
      applicantKind: "individual",
      residentialAddress: address.trim(),
      residenceStreet: address.trim(),
      occupation: occupation.trim(),
      relationship: relationship.trim(),
    }).catch(() => undefined);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[calc(100dvh-2rem)] overflow-y-auto sm:max-w-lg" data-testid="p8-co-applicant-intake-dialog">
        <DialogHeader>
          <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl border border-primary/15 bg-primary/5 text-primary">
            <UsersRound className="h-5 w-5" aria-hidden="true" />
          </div>
          <DialogTitle>Add the applying co-applicant for Form P8</DialogTitle>
          <DialogDescription>
            Form P8 is sworn by an additional applying applicant. Add only the person who is actually applying; these facts are saved to Contacts and used in the affidavit.
          </DialogDescription>
        </DialogHeader>

        {formError && (
          <Alert variant="destructive" role="alert" data-testid="p8-co-applicant-error">
            <AlertTriangle className="h-4 w-4" aria-hidden="true" />
            <AlertDescription>{formError}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-4 py-1">
          <div className="space-y-1.5">
            <Label htmlFor="p8-coapplicant-name">Full legal name</Label>
            <Input id="p8-coapplicant-name" value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" aria-invalid={invalidFields.includes("name")} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="p8-coapplicant-address">Residential address</Label>
            <Input id="p8-coapplicant-address" value={address} onChange={(event) => setAddress(event.target.value)} autoComplete="street-address" aria-invalid={invalidFields.includes("address")} />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="p8-coapplicant-occupation">Occupation</Label>
              <Input id="p8-coapplicant-occupation" value={occupation} onChange={(event) => setOccupation(event.target.value)} aria-invalid={invalidFields.includes("occupation")} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="p8-coapplicant-relationship">Relationship to deceased</Label>
              <Input id="p8-coapplicant-relationship" value={relationship} onChange={(event) => setRelationship(event.target.value)} aria-invalid={invalidFields.includes("relationship")} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="p8-coapplicant-role">Role in this estate</Label>
            <Select value={role} onValueChange={(value) => setRole(value as ApplicantRole)}>
              <SelectTrigger id="p8-coapplicant-role"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="executor_applicant">Applying executor and applicant</SelectItem>
                <SelectItem value="applicant">Applying applicant</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          {onGoToContacts && <Button type="button" variant="ghost" onClick={onGoToContacts}>Go to Contacts</Button>}
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={createMutation.isPending}>Cancel</Button>
          <Button type="button" onClick={save} disabled={createMutation.isPending} data-testid="p8-save-co-applicant">
            {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />}
            Save co-applicant and continue
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
