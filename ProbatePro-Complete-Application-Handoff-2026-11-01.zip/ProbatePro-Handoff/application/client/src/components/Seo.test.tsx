import { cleanup, render } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";
import React from "react";
import { Seo } from "./Seo";

function queryMeta(attribute: "name" | "property", value: string) {
  return document.head.querySelector(`meta[${attribute}="${value}"]`) as HTMLMetaElement | null;
}

afterEach(() => {
  cleanup();
  document.head.querySelectorAll("[data-probatepro-seo]").forEach((node) => node.remove());
  document.title = "";
});

describe("Seo", () => {
  it("publishes public metadata, a canonical URL, and visible-content structured data", () => {
    render(
      <Seo
        title="BC Probate Software | ProbatePro"
        description="Manage British Columbia probate workflow."
        path="/"
        index
        structuredData={{
          "@context": "https://schema.org",
          "@type": "SoftwareApplication",
          name: "ProbatePro",
        }}
      />,
    );

    expect(document.title).toBe("BC Probate Software | ProbatePro");
    expect(queryMeta("name", "description")?.content).toBe("Manage British Columbia probate workflow.");
    expect(queryMeta("name", "robots")?.content).toBe("index, follow");
    expect(document.head.querySelector('link[rel="canonical"]')?.getAttribute("href")).toBe("https://probate-pro.com/");
    expect(queryMeta("property", "og:url")?.content).toBe("https://probate-pro.com/");

    const schema = document.head.querySelector('script[type="application/ld+json"][data-probatepro-seo]');
    expect(JSON.parse(schema?.textContent || "{}")).toMatchObject({
      "@type": "SoftwareApplication",
      name: "ProbatePro",
    });
  });

  it("marks a private route as non-indexable while retaining its canonical path", () => {
    render(
      <Seo
        title="Settings | ProbatePro"
        description="Private workspace settings."
        path="/settings"
        index={false}
      />,
    );

    expect(document.title).toBe("Settings | ProbatePro");
    expect(queryMeta("name", "robots")?.content).toBe("noindex, nofollow");
    expect(document.head.querySelector('link[rel="canonical"]')?.getAttribute("href")).toBe("https://probate-pro.com/settings");
    expect(document.head.querySelector('script[type="application/ld+json"][data-probatepro-seo]')).toBeNull();
  });
});
