import React, { useState } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { checkFormRequirements } from "../../../shared/formRequirements";
import { PreGenerateDialog } from "./PreGenerateDialog";

const typeId = "pre-generate-canonical-willAlterationTypes";
const detailId = "pre-generate-canonical-appearanceIssueTypes";
const control = (id: string) => {
  const element = document.getElementById(id);
  expect(element, `visible fixture control ${id}`).not.toBeNull();
  return element!;
};
function mount(failRecheck = false, waitSave?: Promise<void>, loseAcknowledgement = false, completeInterlineations = false) {
  const initial: any = {
    id: "fictional-appearance-popup", revision: 1, grantType: "grant_of_probate", hasWill: 1,
    willStatus: "will", willType: "physical", willFilingType: "physical_original",
    willAlterations: "has_alterations", willAlterationTypes: "appearance",
    willAppearanceIssues: "yes", appearanceIssueTypes: "", appearanceIssueOther: "", appearanceAffidavits: "",
    interlineationTreatment: completeInterlineations ? "compliant" : "",
  };
  const input = (estate: any) => ({ estate, contacts: [], inventory: [], requiredDocuments: [], requiredCatalog: [] });
  const report = checkFormRequirements("P4", input(initial));
  expect(report.gaps.map(g => g.requirementId)).toEqual(expect.arrayContaining(["p4_alteration_details_complete", "p4_appearance_types"]));
  let stored = initial;
  let failed = false;
  const apply = vi.fn();
  function Fixture() {
    const [estate, setEstate] = useState(initial);
    apply.mockImplementation(async (...args: any[]) => {
      const patch = args[5] ?? {};
      const observer = args[6];
      if (waitSave) await waitSave;
      if (Object.keys(patch).length) {
        stored = { ...stored, ...patch, revision: stored.revision + 1 };
        setEstate(stored);
        if (loseAcknowledgement && !failed) { failed = true; return false; }
        observer?.onSaved({ estateId: stored.id, revision: stored.revision, record: stored });
      }
      if (failRecheck && !failed) { failed = true; return false; }
      observer?.onRechecked();
      return true;
    });
    return <PreGenerateDialog open formName="P4" reports={[checkFormRequirements("P4", input(estate))]}
      estate={estate} contacts={[]} inlineEditingEnabled onApplyInline={apply} onProceed={vi.fn()}
      onOpenChange={vi.fn()} onCancel={vi.fn()} onJumpToTab={vi.fn()} />;
  }
  render(<Fixture />);
  return { apply, stored: () => stored };
}
function editAndRemove() {
  fireEvent.click(control(`${detailId}-incomplete`));
  expect(control(`${detailId}-incomplete`).getAttribute("data-state")).toBe("checked");
  fireEvent.click(control(`${typeId}-appearance`));
  fireEvent.click(control(`${typeId}-interlineations`));
}
beforeEach(() => {
  cleanup();
  for (const [key, value] of Object.entries({ hasPointerCapture: (): boolean => false, setPointerCapture: (): void => {}, releasePointerCapture: (): void => {}, scrollIntoView: (): void => {} })) Object.defineProperty(Element.prototype, key, { value, configurable: true });
});
afterEach(cleanup);

describe("appearance removal with actual P4 gap requirements", () => {
  it("does not display a selected child answer while the explicit branch removal will clear it", () => {
    mount(); editAndRemove();
    expect(screen.queryByTestId(detailId)).toBeNull();
  });
  it("retains the explicit draft if the appearance branch is restored before applying", () => {
    mount(); editAndRemove();
    fireEvent.click(control(`${typeId}-appearance`));
    expect(control(`${detailId}-incomplete`).getAttribute("data-state")).toBe("checked");
  });
  it("retains the draft if the user restores the branch while the old removal save is in flight", async () => {
    let release!: () => void;
    const gate = new Promise<void>(resolve => { release = resolve; });
    const h = mount(false, gate); editAndRemove();
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(1));
    fireEvent.click(control(`${typeId}-appearance`));
    await act(async () => { release(); });
    await waitFor(() => expect(h.stored().appearanceIssueTypes).toBe(""));
    expect(control(`${detailId}-incomplete`).getAttribute("data-state")).toBe("checked");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(2));
    expect(h.apply.mock.calls[1][5]).toMatchObject({ appearanceIssueTypes: "incomplete" });
  });
  it("retains the explicitly restored owner when an old successful save removes its aggregate gap", async () => {
    let release!: () => void;
    const gate = new Promise<void>(resolve => { release = resolve; });
    const h = mount(false, gate, false, true); editAndRemove();
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(1));
    fireEvent.click(control(`${typeId}-appearance`));
    await act(async () => { release(); });
    const fresh = checkFormRequirements("P4", { estate: h.stored(), contacts: [], inventory: [], requiredDocuments: [], requiredCatalog: [] });
    expect(fresh.gaps.some(gap => gap.requirementId === "p4_alteration_details_complete")).toBe(false);
    expect(control(`${typeId}-appearance`).getAttribute("data-state")).toBe("checked");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(2));
    expect(h.apply.mock.calls[1][5].willAlterationTypes.split(",")).toContain("appearance");
    expect(h.apply.mock.calls[1][5]).toMatchObject({ appearanceIssueTypes: "incomplete" });
  });
  it("does not resurrect a cleared child answer after an acknowledged save and failed recheck", async () => {
    const h = mount(true); editAndRemove();
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(1));
    await waitFor(() => expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(false));
    expect(h.stored()).toMatchObject({ willAlterationTypes: "interlineations", appearanceIssueTypes: "" });
    expect(control(`${detailId}-incomplete`).getAttribute("data-state")).toBe("unchecked");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(2));
    expect(h.apply.mock.calls[1][5]).toEqual({});
    expect(h.stored().appearanceIssueTypes).toBe("");
  });
  it("keeps the explicit clearing intent when a committed response is lost and newer props already show the removal", async () => {
    const h = mount(false, undefined, true); editAndRemove();
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(h.stored().revision).toBe(2));
    expect(screen.queryByTestId(detailId)).toBeNull();
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(2));
    expect(h.apply.mock.calls[1][5]).toMatchObject({ appearanceIssueTypes: "" });
    expect(h.stored().appearanceIssueTypes).toBe("");
  });
});
