import { ReactNode } from "react";

import type { HTMLAttributes } from "react";

/**
 * Clean card component with subtle hover state.
 * No gimmicks — just a well-crafted container.
 */
export function SpotlightCard({
  children,
  className = "",
  ...props
}: {
  children: ReactNode;
  className?: string;
} & HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      {...props}
      className={`rounded-lg border bg-card text-card-foreground shadow-sm transition-[box-shadow,border-color] duration-200 hover:shadow-md hover:border-border/80 ${props.onClick ? "cursor-pointer" : ""} ${className}`}
    >
      {children}
    </div>
  );
}
