/**
 * Minimal background for the login page.
 * Dot grid pattern + subtle top gradient wash. No floating orbs, no noise.
 */
export function AnimatedBackground() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      {/* Dot grid pattern */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: `radial-gradient(circle, currentColor 0.7px, transparent 0.7px)`,
          backgroundSize: "32px 32px",
        }}
      />
      {/* Subtle top gradient wash */}
      <div className="absolute inset-x-0 top-0 h-96 bg-gradient-to-b from-primary/[0.02] to-transparent" />
    </div>
  );
}
