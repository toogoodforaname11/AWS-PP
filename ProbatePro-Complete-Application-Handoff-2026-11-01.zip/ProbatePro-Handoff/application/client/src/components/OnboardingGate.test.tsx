import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { FORM_FOCUSED_INTAKE_STORAGE_KEY } from "@/hooks/useFormFocusedIntakePreference";
import { FirstLoginWelcome, OnboardingGate, WORKSPACE_HANDOFF_DELAY_MS } from "./OnboardingGate";

const mocks = vi.hoisted(() => ({
  settings: { firmName: "" } as any,
  update: vi.fn(),
  invalidate: vi.fn(),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    settings: {
      get: { useQuery: () => ({ data: mocks.settings, isLoading: false }) },
      update: {
        useMutation: (options: any = {}) => ({
          mutate: (input: any, mutationOptions?: any) => {
            mocks.update(input);
            options.onSuccess?.({ success: true }, input);
            mutationOptions?.onSuccess?.({ success: true }, input);
          },
          isPending: false,
        }),
      },
    },
    useUtils: () => ({ settings: { get: { invalidate: mocks.invalidate } } }),
  },
}));

vi.mock("@/components/AddressAutocomplete", () => ({
  AddressAutocomplete: ({ value, onChange, placeholder }: any) => <input value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} />,
}));

beforeEach(() => {
  (globalThis as any).ResizeObserver = class {
    observe() {}
    unobserve() {}
    disconnect() {}
  };
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
});

afterEach(() => {
  cleanup();
  mocks.settings = { firmName: "" };
  mocks.update.mockReset();
  mocks.invalidate.mockReset();
  window.localStorage.clear();
  vi.useRealTimers();
});

describe("FirstLoginWelcome", () => {
  it("shows a useful welcome only while the persisted first-login state is open", () => {
    const onDismiss = vi.fn();
    const onStartTour = vi.fn();
    const { rerender } = render(<FirstLoginWelcome open={false} userName="Jordan Smith" onDismiss={onDismiss} onStartTour={onStartTour} />);
    expect(screen.queryByTestId("first-login-welcome-dialog")).toBeNull();

    rerender(<FirstLoginWelcome open userName="Jordan Smith" onDismiss={onDismiss} onStartTour={onStartTour} />);
    expect(screen.getByTestId("first-login-welcome-dialog").className).toContain("welcome-dialog-enter");
    expect(screen.getByText("Welcome to ProbatePro, Jordan")).toBeTruthy();
    expect(screen.getByText(/shown or hidden at any time in Settings/i)).toBeTruthy();
  });

  it("persists dismissal through the supplied callback", () => {
    const onDismiss = vi.fn();
    render(<FirstLoginWelcome open userName="Jordan Smith" onDismiss={onDismiss} onStartTour={vi.fn()} />);
    fireEvent.click(screen.getByTestId("first-login-welcome-dismiss"));
    expect(onDismiss).toHaveBeenCalledTimes(1);
  });

  it("starts the guided dashboard tour through the supplied callback", () => {
    const onStartTour = vi.fn();
    render(<FirstLoginWelcome open userName="Jordan Smith" onDismiss={vi.fn()} onStartTour={onStartTour} />);
    fireEvent.click(screen.getByTestId("first-login-start-tour"));
    expect(onStartTour).toHaveBeenCalledTimes(1);
  });
});

describe("first-run lawyer workflow choice", () => {
  it("acknowledges a saved workspace choice before transitioning to the dashboard", () => {
    vi.useFakeTimers();
    const { rerender } = render(<OnboardingGate user={{ name: "Jordan Smith", email: "jordan@example.test" }}><div>Workspace</div></OnboardingGate>);

    fireEvent.click(screen.getByRole("radio", { name: /Personal executor/i }));
    fireEvent.click(screen.getByTestId("onboarding-continue"));

    expect(screen.getByTestId("onboarding-screen").getAttribute("data-state")).toBe("handoff");
    expect(screen.getByRole("button", { name: /Preparing workspace/i })).toBeTruthy();
    expect(mocks.invalidate).not.toHaveBeenCalled();

    act(() => vi.advanceTimersByTime(WORKSPACE_HANDOFF_DELAY_MS));
    expect(mocks.invalidate).toHaveBeenCalledTimes(1);

    mocks.settings = { accountPurpose: "personal_executor", welcomeDismissed: true };
    rerender(<OnboardingGate user={{ name: "Jordan Smith", email: "jordan@example.test" }}><div>Workspace</div></OnboardingGate>);
    expect(screen.getByText("Workspace").parentElement?.className).toContain("workspace-handoff-enter");
  });

  it("offers an explicit personal-executor purpose with a neutral profile and Full Intake default", () => {
    window.localStorage.setItem(FORM_FOCUSED_INTAKE_STORAGE_KEY, "true");
    render(<OnboardingGate user={{ name: "Jordan Smith", email: "jordan@example.test" }}><div>Workspace</div></OnboardingGate>);
    expect(screen.getByRole("heading", { name: "How will you use ProbatePro?" })).toBeTruthy();
    fireEvent.click(screen.getByRole("radio", { name: /Personal executor/i }));
    const personalExecutorCard = screen.getByRole("radio", { name: /Personal executor/i }).closest("label");
    expect(personalExecutorCard?.getAttribute("data-state")).toBe("selected");
    expect(personalExecutorCard?.className).toContain("onboarding-purpose-card");
    expect(personalExecutorCard?.className).toContain("grid-rows-[auto_1fr_auto]");
    expect(screen.getByText("Starts with Full Intake")).toBeTruthy();
    expect(screen.getByTestId("onboarding-brand-scale").querySelector("svg")).toBeTruthy();
    expect(screen.getByTestId("onboarding-brand-scale").textContent).not.toContain("P");
    expect(screen.getByLabelText("Your name")).toHaveProperty("value", "Jordan Smith");
    expect((screen.getByLabelText("Your name") as HTMLInputElement).readOnly).toBe(true);
    expect((screen.getByLabelText("Email") as HTMLInputElement).readOnly).toBe(true);
    expect(screen.queryByText("Firm Name")).toBeNull();
    const continueButton = screen.getByTestId("onboarding-continue");
    expect(continueButton.className).toContain("probate-primary-action");
    expect(continueButton.textContent).not.toContain("→");
    fireEvent.click(continueButton);
    expect(mocks.update).toHaveBeenCalledWith(expect.objectContaining({
      accountPurpose: "personal_executor", formFocusedIntake: false,
    }));
    expect(mocks.update.mock.calls[0][0]).not.toHaveProperty("firmName");
    expect(mocks.update.mock.calls[0][0]).not.toHaveProperty("lawyerName");
    expect(mocks.update.mock.calls[0][0]).not.toHaveProperty("firmEmail");
    expect(window.localStorage.getItem(FORM_FOCUSED_INTAKE_STORAGE_KEY)).toBe("false");
  });

  it("offers a personal-executor welcome action without claiming appointment", () => {
    render(<FirstLoginWelcome open accountPurpose="personal_executor" userName="Jordan Smith" onDismiss={vi.fn()} onStartTour={vi.fn()} onStartIntake={vi.fn()} />);
    expect(screen.getByText(/does not establish that you have been appointed/i)).toBeTruthy();
    expect(screen.getByRole("button", { name: /start an estate file/i })).toBeTruthy();
  });

  it("recommends form-focused mode for lawyers and persists the chosen setting with the first profile save", async () => {
    render(<OnboardingGate user={{ name: "Jordan Smith", email: "jordan@example.test" }}><div>Workspace</div></OnboardingGate>);

    expect(screen.getByRole("group", { name: "Choose your workspace" })).toBeTruthy();
    expect((screen.getByRole("button", { name: /continue to your workspace/i }) as HTMLButtonElement).disabled).toBe(true);
    const help = screen.getByRole("button", { name: "What does account purpose change?" });
    fireEvent.pointerMove(help, { pointerType: "mouse" });
    await waitFor(() => expect(screen.getAllByText(/does not confirm your appointment/i).length).toBeGreaterThan(0));

    fireEvent.click(screen.getByRole("radio", { name: /Lawyer/i }));
    expect((screen.getByRole("radio", { name: /Lawyer/i }) as HTMLInputElement).checked).toBe(true);
    expect(screen.getByRole("radio", { name: /Lawyer/i }).closest("label")?.getAttribute("data-state")).toBe("selected");
    expect(screen.getByText("Starts with Form-focused Intake")).toBeTruthy();
    expect(screen.getAllByText(/This only sets your starting view/i)).toHaveLength(1);
    expect(screen.getByRole("status").textContent).toMatch(/Form-focused Intake is recommended/i);
    fireEvent.change(screen.getByPlaceholderText(/Smith & Associates Law/i), { target: { value: "Smith Law" } });
    fireEvent.click(screen.getByRole("button", { name: /continue to your workspace/i }));

    expect(mocks.update).toHaveBeenCalledWith(expect.objectContaining({
      firmName: "Smith Law",
      lawyerName: "Jordan Smith",
      accountPurpose: "lawyer",
      formFocusedIntake: true,
    }));
    expect(window.localStorage.getItem(FORM_FOCUSED_INTAKE_STORAGE_KEY)).toBe("true");
  });

  it("preserves completed legacy firm accounts without reasking their purpose", () => {
    mocks.settings = { firmName: "Existing Firm", accountPurpose: "unselected", welcomeDismissed: true };
    render(<OnboardingGate user={{ name: "Jordan Smith", email: "jordan@example.test" }}><div>Workspace</div></OnboardingGate>);
    expect(screen.getByText("Workspace")).toBeTruthy();
    expect(screen.queryByRole("heading", { name: "How will you use ProbatePro?" })).toBeNull();
    expect(mocks.update).not.toHaveBeenCalled();
  });

  it("does not re-open onboarding after a corrected account type is saved", () => {
    mocks.settings = { firmName: "", accountPurpose: "lawyer", welcomeDismissed: true };
    render(<OnboardingGate user={{ name: "Jordan Smith", email: "jordan@example.test" }}><div>Workspace</div></OnboardingGate>);
    expect(screen.getByText("Workspace")).toBeTruthy();
    expect(screen.queryByRole("heading", { name: "How will you use ProbatePro?" })).toBeNull();
  });
});
