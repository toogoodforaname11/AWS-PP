import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";

const css = readFileSync(join(process.cwd(), "client/src/index.css"), "utf8");

describe("sidebar preference switch motion", () => {
  it("uses short interruptible transitions for the shared switch and thumb", () => {
    expect(css).toMatch(/\.sidebar-preference-switch\s*\{[\s\S]*?transition:\s*background-color\s+160ms[\s\S]*?transform\s+120ms/);
    expect(css).toMatch(/\.sidebar-preference-switch \[data-slot="switch-thumb"\]\s*\{[\s\S]*?transition:\s*transform\s+180ms/);
    expect(css).toContain("@keyframes sidebar-preference-settle");
  });

  it("keeps the Assistant halo state-driven rather than continuously pulsing", () => {
    expect(css).toMatch(/\.assistant-sidebar-control--active::before\s*\{[\s\S]*?opacity:\s*0\.48/);
    expect(css).not.toContain("assistant-active-presence");
  });

  it("removes movement for users who prefer reduced motion", () => {
    expect(css).toMatch(/@media \(prefers-reduced-motion: reduce\)[\s\S]*?\.sidebar-preference-control,[\s\S]*?transition:\s*none/);
  });

  it("keeps compact sidebar switches comfortably tappable on mobile without changing their visible size", () => {
    expect(css).toMatch(/@media \(max-width: 767px\)[\s\S]*?\.sidebar-preference-switch::after\s*\{[\s\S]*?inset:\s*-0\.8rem -0\.55rem/);
    expect(css).toMatch(/\.sidebar-preference-switch\s*\{[\s\S]*?position:\s*relative/);
  });
});
