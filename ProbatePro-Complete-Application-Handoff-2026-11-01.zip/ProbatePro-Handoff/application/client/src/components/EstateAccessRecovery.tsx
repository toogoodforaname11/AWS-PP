import React from "react";
import { ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export function EstateAccessRecovery({ onBack }: { onBack: () => void }) {
  return (
    <div className="mx-auto flex min-h-[18rem] max-w-lg items-center px-4 py-12">
      <Card className="w-full border-amber-200/80 bg-amber-50/40 shadow-sm dark:border-amber-900/60 dark:bg-amber-950/15">
        <CardHeader className="items-start gap-3 sm:flex-row">
          <div className="rounded-lg bg-amber-100 p-2 text-amber-800 dark:bg-amber-900/50 dark:text-amber-200">
            <ShieldAlert className="h-5 w-5" aria-hidden="true" />
          </div>
          <div className="space-y-1">
            <CardTitle>Estate workspace unavailable</CardTitle>
            <CardDescription>
              This estate may no longer be available to your account, or the link may be out of date. Return to Estate Files and open a file you can access.
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <Button onClick={onBack} variant="outline" data-testid="estate-access-recovery-back">Return to Estate Files</Button>
        </CardContent>
      </Card>
    </div>
  );
}
