import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { PreGenerateDialog, type PreGenerateDialogProps } from "./PreGenerateDialog";
import type { FormGap } from "../../../shared/formRequirements";

const legacy = {
  id: "fictional-legacy-will", revision: 3, willStatus: "will", hasWill: 1,
  willType: "electronic", isElectronicWill: 1, willFilingType: "copy",
  electronicWillFormat: "pdf_original", electronicWillFirstSavedPdf: "",
  electronicWillInRepository: "", electronicWillOriginalAvailable: "",
};
const axes = ["electronicWillFirstSavedPdf", "electronicWillInRepository", "electronicWillOriginalAvailable"];
function gap(fields = axes, id = "p4_electronic_copy_format"): FormGap {
  return { requirementId: id, label: "Existing electronic-will facts", missingFields: fields.map(f => `estate.${f}`), tab: "intake", source: "Existing Intake fields" };
}
function mount(extra: Record<string, unknown> = {}) {
  const apply = vi.fn().mockResolvedValue(true);
  const props: PreGenerateDialogProps = {
    open: true, formName: "P4", reports: [{ formCode: "P4", ok: false, gaps: [gap()] }],
    estate: { ...legacy, ...extra }, contacts: [], inlineEditingEnabled: true,
    onApplyInline: apply, onProceed: vi.fn(), onOpenChange: vi.fn(), onCancel: vi.fn(), onJumpToTab: vi.fn(),
  };
  const view = render(<PreGenerateDialog {...props} />);
  return { ...view, props, apply };
}
const control = (axis: string) => screen.getByTestId(`pre-generate-canonical-${axis}`);
async function choose(axis: string, answer: "Yes" | "No") {
  fireEvent.click(control(axis));
  fireEvent.click(await screen.findByRole("option", { name: answer }));
}
async function submit(apply: ReturnType<typeof vi.fn>) {
  fireEvent.click(screen.getByTestId("pre-generate-apply"));
  await waitFor(() => expect(apply).toHaveBeenCalledTimes(1));
  return apply.mock.calls[0][5];
}
beforeEach(() => {
  cleanup();
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: (): boolean => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: (): void => {}, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: (): void => {}, configurable: true });
  Object.defineProperty(Element.prototype, "scrollIntoView", { value: (): void => {}, configurable: true });
});
afterEach(cleanup);

describe("canonical popup electronic-axis preservation", () => {
  it("keeps legacy-established sibling answers visibly intact when one missing answer changes", async () => {
    mount();
    expect(control("electronicWillFirstSavedPdf").textContent).toBe("Yes");
    expect(control("electronicWillInRepository").textContent).toBe("No");
    await choose("electronicWillOriginalAvailable", "Yes");
    expect(control("electronicWillFirstSavedPdf").textContent).toBe("Yes");
    expect(control("electronicWillInRepository").textContent).toBe("No");
  });

  it("preserves the legacy facts in the actual canonical save payload and after banking", async () => {
    const h = mount();
    await choose("electronicWillOriginalAvailable", "Yes");
    expect(await submit(h.apply)).toEqual({
      electronicWillOriginalAvailable: "yes", electronicWillFirstSavedPdf: "yes",
      electronicWillInRepository: "no", electronicWillFormat: "pdf_original",
    });
    expect(control("electronicWillFirstSavedPdf").textContent).toBe("Yes");
    expect(control("electronicWillInRepository").textContent).toBe("No");
    await waitFor(() => expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(true));
  });

  it("keeps both explicit axis edits and the legacy-only original-availability fact", async () => {
    const h = mount({ electronicWillFormat: "original_unavailable" });
    await choose("electronicWillFirstSavedPdf", "No");
    await choose("electronicWillInRepository", "Yes");
    expect(await submit(h.apply)).toEqual({
      electronicWillOriginalAvailable: "no", electronicWillFirstSavedPdf: "no",
      electronicWillInRepository: "yes", electronicWillFormat: "third_party_repo",
    });
  });

  it("does not apply a stale draft for an axis whose editor disappeared before submission", async () => {
    const h = mount();
    await choose("electronicWillFirstSavedPdf", "No");
    await choose("electronicWillOriginalAvailable", "Yes");
    h.rerender(<PreGenerateDialog {...h.props} reports={[{ formCode: "P4", ok: false, gaps: [gap(["electronicWillOriginalAvailable"], "p4_specific_remaining_axis")] }]} />);
    expect(screen.queryByTestId("pre-generate-canonical-electronicWillFirstSavedPdf")).toBeNull();
    expect(await submit(h.apply)).toEqual({
      electronicWillOriginalAvailable: "yes", electronicWillFirstSavedPdf: "yes",
      electronicWillInRepository: "no", electronicWillFormat: "pdf_original",
    });
  });

  it("does not invent a format fact from legacy original-unavailability alone", async () => {
    const h = mount({ electronicWillFormat: "original_unavailable" });
    await choose("electronicWillInRepository", "No");
    expect(await submit(h.apply)).toEqual({
      electronicWillOriginalAvailable: "no", electronicWillFirstSavedPdf: "",
      electronicWillInRepository: "no", electronicWillFormat: "original_unavailable",
    });
  });

  it("keeps an acknowledged sibling after its editor disappears while estate props still lag", async () => {
    const h = mount();
    await choose("electronicWillFirstSavedPdf", "No");
    const first = await submit(h.apply);
    expect(first).toMatchObject({ electronicWillFirstSavedPdf: "no", electronicWillInRepository: "no", electronicWillFormat: "other_format" });
    await waitFor(() => expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(true));
    h.rerender(<PreGenerateDialog {...h.props} reports={[{ formCode: "P4", ok: false, gaps: [gap(["electronicWillOriginalAvailable"], "p4_specific_remaining_axis")] }]} />);
    await choose("electronicWillOriginalAvailable", "Yes");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(2));
    expect(h.apply.mock.calls[1][5]).toEqual({
      electronicWillOriginalAvailable: "yes", electronicWillFirstSavedPdf: "no",
      electronicWillInRepository: "no", electronicWillFormat: "other_format",
    });
  });

  it("does not let a banked old snapshot overwrite siblings in a genuinely newer estate revision", async () => {
    const h = mount();
    await choose("electronicWillFirstSavedPdf", "No");
    await submit(h.apply);
    await waitFor(() => expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(true));
    h.rerender(<PreGenerateDialog {...h.props} estate={{ ...legacy, revision: 5, electronicWillFirstSavedPdf: "yes", electronicWillInRepository: "yes", electronicWillFormat: "third_party_repo" }} reports={[{ formCode: "P4", ok: false, gaps: [gap(["electronicWillOriginalAvailable"], "p4_specific_remaining_axis")] }]} />);
    await choose("electronicWillOriginalAvailable", "Yes");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(2));
    expect(h.apply.mock.calls[1][5]).toEqual({
      electronicWillOriginalAvailable: "yes", electronicWillFirstSavedPdf: "yes",
      electronicWillInRepository: "yes", electronicWillFormat: "third_party_repo",
    });
  });
});
