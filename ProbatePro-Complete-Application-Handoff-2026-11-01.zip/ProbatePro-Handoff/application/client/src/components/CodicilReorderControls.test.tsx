import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { CodicilReorderControls } from "./CodicilReorderControls";

describe("CodicilReorderControls", () => {
  it("keeps edge moves unavailable and sends the precise persisted move for enabled controls", () => {
    const onMove = vi.fn();
    render(<CodicilReorderControls fileName="Second codicil.pdf" index={1} total={3} disabled={false} onMove={onMove} />);

    fireEvent.click(screen.getByTestId("codicil-move-up-1"));
    fireEvent.click(screen.getByTestId("codicil-move-down-1"));
    expect(onMove).toHaveBeenNthCalledWith(1, 1, 0);
    expect(onMove).toHaveBeenNthCalledWith(2, 1, 2);
  });

  it("disables unavailable movements while a persisted reorder is pending", () => {
    render(<CodicilReorderControls fileName="First codicil.pdf" index={0} total={2} disabled={true} onMove={() => {}} />);
    expect(screen.getByTestId("codicil-move-up-0").hasAttribute("disabled")).toBe(true);
    expect(screen.getByTestId("codicil-move-down-0").hasAttribute("disabled")).toBe(true);
  });
});
