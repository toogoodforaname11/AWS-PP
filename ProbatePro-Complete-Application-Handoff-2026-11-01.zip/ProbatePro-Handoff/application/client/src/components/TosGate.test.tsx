import React from "react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { TosGate } from "./TosGate";

const mocks = vi.hoisted(() => ({
  invalidate: vi.fn(),
  accept: vi.fn(),
  toastSuccess: vi.fn(),
  toastError: vi.fn(),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    useUtils: () => ({ auth: { me: { invalidate: mocks.invalidate } } }),
    auth: {
      acceptTos: {
        useMutation: (options: any) => ({
          mutate: () => {
            mocks.accept();
            options.onSuccess();
          },
          isPending: false,
        }),
      },
    },
  },
}));

vi.mock("sonner", () => ({
  toast: { success: mocks.toastSuccess, error: mocks.toastError },
}));

afterEach(() => {
  cleanup();
  mocks.invalidate.mockReset();
  mocks.accept.mockReset();
  mocks.toastSuccess.mockReset();
  mocks.toastError.mockReset();
});

describe("TosGate", () => {
  it("uses a polished consent surface with plain-language document actions", () => {
    render(<TosGate user={{}}><div>Workspace</div></TosGate>);

    expect(screen.getByTestId("tos-gate-screen").className).toContain("tos-gate-screen");
    expect(screen.getByRole("heading", { name: "Welcome to ProbatePro" })).toBeTruthy();
    expect(screen.getAllByText("Review")).toHaveLength(2);
    const documentLinks = screen.getAllByRole("link").filter((link) => link.classList.contains("tos-gate-document-link"));
    expect(documentLinks.map((link) => link.getAttribute("href"))).toEqual(["/terms", "/privacy"]);
    expect(documentLinks.every((link) => link.getAttribute("target") === "_blank" && link.getAttribute("rel") === "noopener noreferrer")).toBe(true);
    expect(screen.getByTestId("tos-gate-screen").textContent).not.toContain("→");

    const consent = screen.getByRole("checkbox");
    expect(consent.getAttribute("aria-describedby")).toBe("tos-gate-consent-copy");
    expect(consent.className).toContain("size-6");
    expect(consent.closest("label")).toBeNull();
    expect(screen.getByText("Terms of Service", { selector: "a" }).getAttribute("target")).toBe("_blank");
    expect(screen.getByText("Privacy Policy", { selector: "a" }).getAttribute("target")).toBe("_blank");

    const continueButton = screen.getByRole("button", { name: "Continue to ProbatePro" }) as HTMLButtonElement;
    expect(continueButton.disabled).toBe(true);
    expect(continueButton.className).toContain("probate-primary-action");
  });

  it("keeps consent explicit before accepting the terms", () => {
    render(<TosGate user={{}}><div>Workspace</div></TosGate>);

    fireEvent.click(screen.getByRole("checkbox"));
    const continueButton = screen.getByRole("button", { name: "Continue to ProbatePro" }) as HTMLButtonElement;
    expect(continueButton.disabled).toBe(false);
    fireEvent.click(continueButton);

    expect(mocks.accept).toHaveBeenCalledTimes(1);
    expect(mocks.invalidate).toHaveBeenCalledTimes(1);
  });

  it("does not gate an account that has already accepted the terms", () => {
    render(<TosGate user={{ tosAcceptedAt: Date.now() }}><div>Workspace</div></TosGate>);
    expect(screen.getByText("Workspace")).toBeTruthy();
    expect(screen.queryByTestId("tos-gate-screen")).toBeNull();
  });
});
