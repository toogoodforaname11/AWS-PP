import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  settings: {
    showChatbot: false,
    aiProcessorApprovedAt: 0,
    assistantOnboardingDismissed: false,
    assistantResponseStyle: "balanced",
    assistantCompletionCue: false,
    assistantCompletionTone: "harbor",
    assistantCompletionVolume: 35,
  },
  mutate: vi.fn(),
  setData: vi.fn(),
  invalidate: vi.fn(),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    settings: {
      get: { useQuery: () => ({ data: mocks.settings, isLoading: false }) },
      update: { useMutation: () => ({ mutate: mocks.mutate, isPending: false }) },
    },
    useUtils: () => ({ settings: { get: { setData: mocks.setData, invalidate: mocks.invalidate } } }),
  },
}));

vi.mock("sonner", () => ({ toast: { success: vi.fn(), error: vi.fn() } }));

import { AssistantConsentToggle } from "./AssistantConsentToggle";

describe("AssistantConsentToggle", () => {
  beforeEach(() => {
    mocks.mutate.mockReset();
    mocks.settings = {
      showChatbot: false,
      aiProcessorApprovedAt: 0,
      assistantOnboardingDismissed: false,
      assistantResponseStyle: "balanced",
      assistantCompletionCue: false,
      assistantCompletionTone: "harbor",
      assistantCompletionVolume: 35,
    };
  });

  it("shows the onboarding cue until the user dismisses it", () => {
    render(<AssistantConsentToggle />);

    expect(screen.getByText("Assistant lives here")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: /got it/i }));
    expect(mocks.mutate).toHaveBeenCalledWith({ assistantOnboardingDismissed: true });
  });

  it("exposes the compact response-style menu beside the Assistant control", () => {
    mocks.settings.assistantOnboardingDismissed = true;
    render(<AssistantConsentToggle />);

    expect(screen.getByTestId("assistant-response-style-menu").getAttribute("aria-label")).toBe("Assistant response settings");
    expect(screen.getByText("Off · Balanced")).toBeTruthy();
  });

  it("marks the approved Assistant control for the shared sidebar switch settle", () => {
    mocks.settings = {
      ...mocks.settings,
      showChatbot: true,
      aiProcessorApprovedAt: Date.now(),
      assistantOnboardingDismissed: true,
    };
    render(<AssistantConsentToggle />);

    expect(screen.getByTestId("sidebar-assistant-approval-control").getAttribute("data-enabled")).toBe("true");
    expect(screen.getByRole("switch", { name: "Enable ProbatePro Assistant and approve AI processing" }).className).toContain("sidebar-preference-switch");
  });

  it("explains enterprise AI processing and the no-training commitment before approval", async () => {
    mocks.settings.assistantOnboardingDismissed = true;
    render(<AssistantConsentToggle />);

    const control = screen.getByRole("switch", { name: "Enable ProbatePro Assistant and approve AI processing" });
    control.focus();
    fireEvent.click(control);

    expect(screen.getByRole("heading", { name: "Enable ProbatePro Assistant?" })).toBeTruthy();
    expect(screen.getByText(/third-party enterprise AI processor/i)).toBeTruthy();
    expect(screen.getByText(/not used to train AI models/i)).toBeTruthy();
    expect(screen.getByRole("button", { name: "Approve and enable" })).toBeTruthy();

    fireEvent.keyDown(screen.getByRole("dialog"), { key: "Escape" });
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
    await waitFor(() => expect(document.activeElement).toBe(control));
  });
});
