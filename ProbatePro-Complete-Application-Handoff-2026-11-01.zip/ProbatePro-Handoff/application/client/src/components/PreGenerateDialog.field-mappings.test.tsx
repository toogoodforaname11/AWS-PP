import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { PreGenerateDialog } from "./PreGenerateDialog";
import type { FormGap } from "../../../shared/formRequirements";

function mount(formCode: string, id: string, fields: string[], extra: Record<string, unknown> = {}) {
  const onApplyInline = vi.fn().mockResolvedValue(true);
  const onProceed = vi.fn();
  const gap: FormGap = { requirementId: id, label: "Existing missing fact", missingFields: fields, tab: "intake", source: "Existing requirement" };
  render(<PreGenerateDialog open formName={formCode} reports={[{ formCode, ok: false, gaps: [gap] }]}
    estate={{ id: "fictional", revision: 1, ...extra }} contacts={[]}
    inlineEditingEnabled onApplyInline={onApplyInline} onProceed={onProceed}
    onOpenChange={vi.fn()} onCancel={vi.fn()} onJumpToTab={vi.fn()} />);
  return { onApplyInline, onProceed };
}
beforeEach(() => {
  cleanup();
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: (): boolean => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: (): void => {}, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: (): void => {}, configurable: true });
  Object.defineProperty(Element.prototype, "scrollIntoView", { value: (): void => {}, configurable: true });
});
afterEach(cleanup);

describe("remaining single-form Intake mapping regressions", () => {
  for (const form of ["P4", "P5", "P6", "P7"]) {
    it(`${form}: retains the derived PGT workflow warning without inventing an editable fact or blocking an explicit draft`, () => {
      const id = `${form.toLowerCase()}_pgt_auto_required`;
      const h = mount(form, id, []);
      expect(screen.getByTestId(`pre-generate-gap-${id}`)).toBeTruthy();
      expect(screen.getByTestId(`pre-generate-jump-${id}`)).toBeTruthy();
      expect(screen.queryByTestId("pre-generate-input-notifyPGT")).toBeNull();
      fireEvent.click(screen.getByTestId("pre-generate-proceed"));
      expect(h.onProceed).toHaveBeenCalledWith({ generateAnyway: true });
      expect(h.onApplyInline).not.toHaveBeenCalled();
    });
  }

  it("uses the existing three other-grant branches for P5's predicate-only missing answer", async () => {
    const h = mount("P5", "p5_other_grants_status_valid", []);
    expect(screen.queryByTestId("pre-generate-jump-p5_other_grants_status_valid")).toBeNull();
    fireEvent.click(screen.getByTestId("pre-generate-input-otherGrantsStatus"));
    fireEvent.click(await screen.findByRole("option", { name: "No other application or grant is known" }));
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.onApplyInline).toHaveBeenCalledTimes(1));
    expect(h.onApplyInline.mock.calls[0][0]).toEqual({ otherGrantsStatus: "no_other_grants" });
  });

  it("reuses the existing canonical alias editor for the P11 missing-name row", async () => {
    const h = mount("P11", "p11_deceased_aliases", ["ANY_OF:", "estate.deceasedAliases", "estate.akaLastName"], { hasOtherNames: "yes" });
    const group = screen.getByTestId("pre-generate-p1-aliases");
    expect(screen.queryByTestId("pre-generate-jump-p11_deceased_aliases")).toBeNull();
    const inputs = within(group).getAllByRole("textbox");
    fireEvent.change(inputs[0], { target: { value: "Fictional" } });
    fireEvent.change(inputs[2], { target: { value: "Alias" } });
    fireEvent.change(inputs[3], { target: { value: "Another Alias" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.onApplyInline).toHaveBeenCalledTimes(1));
    expect(h.onApplyInline.mock.calls[0][4].estate).toEqual({
      akaFirstName: "Fictional", akaMiddleName: "", akaLastName: "Alias",
      hasAdditionalNames: "yes", deceasedAliases: "Fictional Alias; Another Alias",
    });
  });

  it("does not mislabel an ANY_OF marker or a legacy address alternative as an extra unfillable fact", () => {
    mount("P2", "p2_deceased_address", ["ANY_OF:", "estate.deceasedAddress", "estate.addressStreet", "estate.deceasedPostOfficeBox"]);
    expect(screen.getByTestId("pre-generate-input-addressStreet")).toBeTruthy();
    expect(screen.getByTestId("pre-generate-input-deceasedPostOfficeBox")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-fields-p2_deceased_address")).toBeNull();
  });

});
