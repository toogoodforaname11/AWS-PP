import React, { useEffect, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { AddressAutocomplete } from "@/components/AddressAutocomplete";
import { DashboardTour } from "@/components/DashboardTour";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { markFormFocusedIntakeOnboardingSeen, storeFormFocusedIntakePreference } from "@/hooks/useFormFocusedIntakePreference";
import { Scale, Building2, CircleHelp, UserRound, BriefcaseBusiness, Check, LoaderCircle } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";

interface OnboardingGateProps {
  children: React.ReactNode;
  user: { name?: string | null; email?: string | null } | null;
}

/** A brief acknowledged transition prevents a successful setup from cutting to the dashboard. */
export const WORKSPACE_HANDOFF_DELAY_MS = 260;

/**
 * Wraps the dashboard. A new account chooses its workspace purpose before any
 * estate facts are entered; existing firm profiles retain their previous flow.
 * Name and email are prefilled from the signed-in profile when available.
 */
export function OnboardingGate({ children, user }: OnboardingGateProps) {
  const { data: settings, isLoading } = trpc.settings.get.useQuery();
  const utils = trpc.useUtils();
  const [, setLocation] = useLocation();

  const [lawyerName, setLawyerName] = useState("");
  const [firmName, setFirmName] = useState("");
  const [firmAddress, setFirmAddress] = useState("");
  const [firmPhone, setFirmPhone] = useState("");
  const [firmFax, setFirmFax] = useState("");
  const [firmEmail, setFirmEmail] = useState("");
  const [accountPurpose, setAccountPurpose] = useState<"lawyer" | "personal_executor" | null>(null);
  const [tourOpen, setTourOpen] = useState(false);
  const [isWorkspaceHandoff, setIsWorkspaceHandoff] = useState(false);
  const [shouldAnimateWorkspace, setShouldAnimateWorkspace] = useState(false);
  const handoffTimerRef = useRef<number | null>(null);

  useEffect(() => () => {
    if (handoffTimerRef.current) window.clearTimeout(handoffTimerRef.current);
  }, []);

  // Pre-fill from OAuth user info
  useEffect(() => {
    if (user?.name) setLawyerName(user.name);
    if (user?.email) setFirmEmail(user.email);
  }, [user?.name, user?.email]);

  const updateMutation = trpc.settings.update.useMutation({
    onSuccess: (_data, variables) => {
      if (typeof variables.formFocusedIntake === "boolean") {
        storeFormFocusedIntakePreference(variables.formFocusedIntake);
        // The onboarding question already explains the recommendation, so avoid
        // immediately repeating the separate sidebar introduction for lawyers.
        if (variables.formFocusedIntake) markFormFocusedIntakeOnboardingSeen();
      }
      setIsWorkspaceHandoff(true);
      handoffTimerRef.current = window.setTimeout(() => {
        setShouldAnimateWorkspace(true);
        utils.settings.get.invalidate();
        toast.success("Your workspace is ready.");
      }, WORKSPACE_HANDOFF_DELAY_MS);
    },
    onError: (err) => toast.error(err.message || "Failed to save settings"),
  });
  const dismissWelcomeMutation = trpc.settings.update.useMutation({
    onSuccess: () => {
      utils.settings.get.invalidate();
    },
    onError: (err) => toast.error(err.message || "Unable to dismiss welcome message"),
  });

  // If settings are loading, show nothing (parent skeleton handles it)
  if (isLoading) return null;

  // A saved workspace choice is complete even if optional lawyer profile details
  // are filled later in Settings; do not send a corrected account back through onboarding.
  if (settings?.firmName || settings?.accountPurpose === "personal_executor" || settings?.accountPurpose === "lawyer") {
    return (
      <>
        <FirstLoginWelcome
          open={settings.welcomeDismissed !== true && !tourOpen}
          userName={user?.name}
          accountPurpose={settings.accountPurpose}
          onDismiss={() => dismissWelcomeMutation.mutate({ welcomeDismissed: true })}
          onStartIntake={() => dismissWelcomeMutation.mutate(
            { welcomeDismissed: true, dashboardTourCompleted: true },
            { onSuccess: () => setLocation("/?start-intake=1") },
          )}
          onStartTour={() => dismissWelcomeMutation.mutate(
            { welcomeDismissed: true, dashboardTourCompleted: false },
            { onSuccess: () => setTourOpen(true) },
          )}
          isSaving={dismissWelcomeMutation.isPending}
        />
        <DashboardTour
          open={tourOpen}
          isSaving={dismissWelcomeMutation.isPending}
          onComplete={() => dismissWelcomeMutation.mutate(
            { welcomeDismissed: true, dashboardTourCompleted: true },
            { onSuccess: () => setTourOpen(false) },
          )}
          onDismiss={() => dismissWelcomeMutation.mutate(
            { welcomeDismissed: true, dashboardTourCompleted: true },
            { onSuccess: () => setTourOpen(false) },
          )}
        />
        <div className={shouldAnimateWorkspace ? "workspace-handoff-enter" : undefined}>{children}</div>
      </>
    );
  }

  const handleSubmit = () => {
    if (!accountPurpose) {
      toast.error("Choose how you will use ProbatePro");
      return;
    }
    if (accountPurpose === "lawyer" && !firmName.trim()) {
      toast.error("Please enter your firm name");
      return;
    }
    updateMutation.mutate(accountPurpose === "personal_executor" ? {
      accountPurpose,
      formFocusedIntake: false,
    } : {
      accountPurpose,
      firmName: firmName.trim(),
      firmAddress: firmAddress.trim(),
      firmPhone: firmPhone.trim(),
      firmFax: firmFax.trim(),
      firmEmail: firmEmail.trim(),
      lawyerName: lawyerName.trim(),
      formFocusedIntake: true,
    });
  };

  return (
    <div className="onboarding-screen flex min-h-screen items-center justify-center p-4" data-state={isWorkspaceHandoff ? "handoff" : "ready"} data-testid="onboarding-screen">
      <div className="w-full max-w-xl">
        {/* Logo/Header */}
        <div className="mb-8 text-center">
          <div className="onboarding-brand-mark mx-auto mb-4" data-testid="onboarding-brand-scale" aria-hidden="true">
            <Scale className="size-6" strokeWidth={2.15} />
          </div>
          <h1 className="text-2xl font-semibold text-[#1a1a2e] tracking-tight">
            How will you use ProbatePro?
          </h1>
          <p className="text-sm text-muted-foreground mt-2 max-w-sm mx-auto">
            Choose the workspace that fits you. You can change your Intake view later.
          </p>
        </div>

        {/* Form Card */}
        <div className="onboarding-surface space-y-6 rounded-2xl border bg-card p-5 sm:p-7">
          <fieldset>
            <legend className="flex items-center gap-2 text-[15px] font-semibold tracking-[-0.01em] text-foreground">
              Choose your workspace
              <Tooltip delayDuration={360} skipDelayDuration={160}>
                <TooltipTrigger asChild>
                  <button type="button" aria-label="What does account purpose change?" className="inline-flex size-6 items-center justify-center rounded-full text-muted-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/35">
                    <CircleHelp className="h-4 w-4" aria-hidden="true" />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="top" sideOffset={8} className="max-w-xs rounded-xl border bg-popover px-3 py-2 text-xs leading-relaxed text-popover-foreground shadow-lg">
                  Lawyers may already know which forms they need, so Form-focused Intake is recommended; Full Intake remains available. Personal executors start with the app&apos;s Full Intake guidance. This choice does not confirm your appointment as an executor or change who may access an estate file.
                </TooltipContent>
              </Tooltip>
            </legend>
            <p className="mt-1 text-xs leading-5 text-muted-foreground">This only sets your starting view. It does not change estate access or confirm an appointment.</p>
            <div className="onboarding-purpose-grid mt-4 grid gap-3 sm:grid-cols-2">
              {([
                { value: "lawyer", label: "Lawyer", description: "I prepare estate files as a legal professional.", startingView: "Form-focused Intake", icon: BriefcaseBusiness },
                { value: "personal_executor", label: "Personal executor", description: "I am organizing an estate in a personal capacity.", startingView: "Full Intake", icon: UserRound },
              ] as const).map(({ value, label, description, startingView, icon: Icon }) => {
                const selected = accountPurpose === value;
                return (
                <label key={value} data-state={selected ? "selected" : "idle"} className="onboarding-purpose-card grid min-h-48 cursor-pointer grid-rows-[auto_1fr_auto] gap-4 rounded-xl border p-4 sm:min-h-52">
                  <input type="radio" name="accountPurpose" value={value} checked={accountPurpose === value} onChange={() => setAccountPurpose(value)} className="sr-only" data-testid={value === "lawyer" ? "lawyer-workflow-yes" : "lawyer-workflow-no"} />
                  <span className="flex items-center justify-between gap-2 text-foreground">
                    <span className="grid size-8 place-items-center rounded-lg border border-border/80 bg-muted/45 text-primary"><Icon className="size-4" aria-hidden="true" /></span>
                    <span className="onboarding-purpose-check grid size-5 place-items-center rounded-md" aria-hidden="true">
                      {selected && <Check className="size-3.5" strokeWidth={2.6} />}
                    </span>
                  </span>
                    <span className="block self-start">
                    <span className="block text-[15px] font-semibold tracking-[-0.01em]">{label}</span>
                    <span className="mt-1.5 block text-[13px] leading-5 text-muted-foreground">{description}</span>
                    </span>
                    <span className="onboarding-purpose-starting-view inline-flex min-h-6 w-fit max-w-full items-center self-start rounded-md px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.1em]">Starts with {startingView}</span>
                </label>
              )})}
            </div>
          </fieldset>

          {accountPurpose && <div className="space-y-4 border-t border-border/70 pt-5" data-testid="purpose-profile-details">
            <div className="flex items-center gap-2">
              {accountPurpose === "lawyer" ? <Building2 className="h-4 w-4 text-primary" /> : <UserRound className="h-4 w-4 text-primary" />}
              <span className="text-sm font-semibold">{accountPurpose === "lawyer" ? "Professional details" : "Your details"}</span>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="onboarding-name" className="text-xs">{accountPurpose === "lawyer" ? "Your name (lawyer)" : "Your name"}</Label>
                <Input id="onboarding-name" value={lawyerName} onChange={accountPurpose === "lawyer" ? (e) => setLawyerName(e.target.value) : undefined} readOnly={accountPurpose === "personal_executor"} placeholder="From your sign-in profile" />
                <p className="text-xs text-muted-foreground">{accountPurpose === "lawyer" ? "Pre-filled from your account" : "Shown from your sign-in profile; not added to estate contacts."}</p>
              </div>
              {accountPurpose === "lawyer" && <div className="space-y-1.5">
                <Label htmlFor="onboarding-firm" className="text-xs">Firm Name <span className="text-destructive">*</span></Label>
                <Input id="onboarding-firm" value={firmName} onChange={(e) => setFirmName(e.target.value)} placeholder="e.g. Smith & Associates Law" />
              </div>}
              {accountPurpose === "personal_executor" && <div className="space-y-1.5">
                <Label htmlFor="onboarding-email" className="text-xs">Email</Label>
                <Input id="onboarding-email" type="email" value={firmEmail} readOnly placeholder="From your sign-in profile" />
                <p className="text-xs text-muted-foreground">Shown from your sign-in profile; not used as a firm contact.</p>
              </div>}
            </div>
            {accountPurpose === "lawyer" && <>
              <div className="space-y-1.5">
                <Label className="text-xs">Firm Address</Label>
                <AddressAutocomplete value={firmAddress} onChange={setFirmAddress} onSelect={(components) => {
                  const parts = [components.street];
                  if (components.unit) parts.unshift(components.unit);
                  parts.push(`${components.city} ${components.province} ${components.postalCode}`);
                  setFirmAddress(parts.filter(Boolean).join(", "));
                }} placeholder="Start typing firm address..." />
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5"><Label htmlFor="onboarding-phone" className="text-xs">Phone</Label><Input id="onboarding-phone" value={firmPhone} onChange={(e) => setFirmPhone(e.target.value)} placeholder="604-555-1234" /></div>
                <div className="space-y-1.5"><Label htmlFor="onboarding-fax" className="text-xs">Fax (optional)</Label><Input id="onboarding-fax" value={firmFax} onChange={(e) => setFirmFax(e.target.value)} placeholder="604-555-1235" /></div>
              </div>
              <div className="space-y-1.5"><Label htmlFor="onboarding-firm-email" className="text-xs">Firm email</Label><Input id="onboarding-firm-email" type="email" value={firmEmail} onChange={(e) => setFirmEmail(e.target.value)} placeholder="info@firm.ca" /></div>
            </>}
            <p className="text-xs leading-5 text-muted-foreground" role="status">
              {accountPurpose === "lawyer" ? "Form-focused Intake is recommended for lawyers. Switch to Full Intake at any time in the sidebar." : "Full Intake is selected. Work through the questions at your own pace; you can change the view later."}
            </p>
          </div>}

          {/* Submit button */}
          <Button
            className="probate-primary-action w-full"
            size="lg"
            disabled={isWorkspaceHandoff || updateMutation.isPending || !accountPurpose || (accountPurpose === "lawyer" && !firmName.trim())}
            onClick={handleSubmit}
            data-testid="onboarding-continue"
          >
            {isWorkspaceHandoff || updateMutation.isPending ? <><LoaderCircle aria-hidden="true" className="size-4 animate-spin motion-reduce:animate-none" /> Preparing workspace…</> : "Continue to your workspace"}
          </Button>
        </div>

        {/* Footer note */}
        <p className="text-center text-xs text-muted-foreground/65 mt-4">
          You can update these details anytime from the Settings page.
        </p>
      </div>
    </div>
  );
}

export function FirstLoginWelcome({
  open,
  userName,
  accountPurpose,
  onDismiss,
  onStartTour,
  onStartIntake,
  isSaving = false,
}: {
  open: boolean;
  userName?: string | null;
  accountPurpose?: "unselected" | "lawyer" | "personal_executor";
  onDismiss: () => void;
  onStartTour: () => void;
  onStartIntake?: () => void;
  isSaving?: boolean;
}) {
  const personalExecutor = accountPurpose === "personal_executor";
  return (
    <Dialog open={open} onOpenChange={(nextOpen) => { if (!nextOpen && !isSaving) onDismiss(); }}>
      <DialogContent className="sm:max-w-md welcome-dialog-enter" data-testid="first-login-welcome-dialog">
        <DialogHeader>
          <div className="mb-2 flex h-11 w-11 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <Scale className="h-5 w-5" />
          </div>
          <DialogTitle>Welcome to ProbatePro{userName ? `, ${userName.split(" ")[0]}` : ""}</DialogTitle>
          <DialogDescription className="leading-6">
            {personalExecutor
              ? "Start by opening an estate file. You can then work through Full Intake at your own pace. Review and change your answers as you go."
              : "Your firm workspace is ready. Start an estate from Estate Files, track key dates in Deadlines, and manage your firm details in Settings."}
          </DialogDescription>
        </DialogHeader>
        <div className="rounded-lg border bg-muted/30 px-3 py-2.5 text-sm text-muted-foreground">
          {personalExecutor
            ? "Choosing a personal workspace does not establish that you have been appointed as an executor. Record the appropriate people and roles in the estate file."
            : "The ProbatePro Assistant can be shown or hidden at any time in Settings."}
        </div>
        <DialogFooter>
          {personalExecutor ? <>
            <Button variant="outline" onClick={onDismiss} disabled={isSaving} data-testid="first-login-welcome-dismiss">Go to dashboard</Button>
            <Button className="probate-primary-action" onClick={onStartIntake} disabled={isSaving} data-testid="first-login-start-intake">{isSaving ? "Saving…" : "Start an estate file"}</Button>
          </> : <>
            <Button variant="outline" onClick={onStartTour} disabled={isSaving} data-testid="first-login-start-tour">Start tour</Button>
            <Button className="probate-primary-action" onClick={onDismiss} disabled={isSaving} data-testid="first-login-welcome-dismiss">{isSaving ? "Saving…" : "Get started"}</Button>
          </>}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
