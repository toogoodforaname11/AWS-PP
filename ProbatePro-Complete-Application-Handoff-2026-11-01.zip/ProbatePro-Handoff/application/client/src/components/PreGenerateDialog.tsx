// client/src/components/PreGenerateDialog.tsx
//
// Reusable pre-generate gap dialog. Rendered ONCE per EstateDetail page (see PROMPT 40)
// and driven by imperative state passed from the parent. This component does NOT
// call the preflight query itself — the parent runs the query and passes the report.
//
// Inline fill (Rule 22 addendum): for a gap naming a blank estate column that
// the hand-curated INLINE_FIELD_CONTROLS registry can edit, the row renders a
// correctly-typed editor in place. "Apply & re-check" hands the typed values to
// the parent, which merges them into the pending render's per-document
// overrides channel and re-runs this same gap check — the list shrinks without
// leaving the dialog, and what cleared a gap is exactly what the document will
// print. Columns with no registry entry, non-estate namespaces, equality
// assertions (estate.<col>=<value>) and manual-confirm sentinels keep the
// jump-to-tab button unchanged. Editors appear only when the parent says the
// pending mutation actually consumes overrides — never for package/bulk runs.
//
// Inline-fill wave 2 (Nick 2026-08-21): gaps may also carry server-resolved
// GapEditor descriptors (contact / inventory / inventoryAdd) — those render
// per-row editors whose values PERSIST through contact.update /
// inventory.update / inventory.create on Apply (they never ride overrides;
// the render re-reads the DB). Predicate-only confirmation gaps
// (missingFields: []) with a GAP_EDIT_HINTS entry render their estate-column
// editors through the ordinary overrides + optional-persist pipeline.
//
// Statutory anchor (verbatim): SCCR Rule 25-2(3) content list is enumerated in the
// engine's FORM_REQUIREMENTS registry (see shared/formRequirements.ts and PROMPT 39).

import * as React from "react";
import { useEffect, useMemo, useRef, useState } from "react";
import type { FormGapReport, FormGap } from "@shared/formRequirements";
import { FORM_REQUIREMENTS } from "@shared/formRequirements";
import { P16_ALTERATION_WORDS_MAX_LENGTH } from "@shared/formOverrides";
import type { ReadinessTab } from "@shared/types";
import { applyElectronicWillAxis, coupleWillFilingTypeFacts, contactHasRole, findPrimaryApplicant, isApplyingApplicant, p1NoticeRecipients, p8ApplyingCoApplicants, primaryAffidavitDeponentFromDocuments, suggestWesaSpouseStatus } from "@shared/types";
import { REQUIRED_DOCUMENTS } from "@shared/types";
import {
  GAP_EDIT_HINTS,
  INLINE_FIELD_CONTROLS,
  INVENTORY_ACCESSOR_COLUMN_ALIASES,
  INVENTORY_INLINE_FIELD_CONTROLS,
  INVENTORY_QUICK_ADD_CATEGORY_OPTIONS,
  inlineEditableColumn,
  inlineEditableDocKey,
  type GapEditor,
  type InlineFieldControl,
} from "@shared/inlineFieldControls";
import { formatCurrency, parseCurrencyToCents } from "@/lib/formatters";
import { inventoryValueRecordedFromForm } from "@/lib/inventoryValue";
import { CANONICAL_APPEARANCE_DETAILS, canonicalAppearanceRemoval, canonicalDraftMatchesRecord, type CanonicalPopupSaveReceipt, type CanonicalPopupApplyObserver, CanonicalPopupField, canonicalFieldsForGap, canonicalFieldActive, canonicalFieldValue, canonicalPopupPatch, canonicalPopupRecord, type CanonicalPopupPatch } from "./CanonicalPopupFields";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Loader2, CheckCircle2, CircleAlert, FileCheck2 } from "lucide-react";

function tabLabel(tab: ReadinessTab): string {
  return tab.charAt(0).toUpperCase() + tab.slice(1);
}

/**
 * The estate accessors a gap's editors derive from: its own missingFields, or
 * — for a predicate-only confirmation row (missingFields: []) — the audited
 * GAP_EDIT_HINTS accessors that cure it. Nick 2026-09-02 (loop 3): a row whose
 * missingFields are ALL equality assertions (`estate.<col>=<value>`, e.g. the
 * P11 sworn-fact rows) resolves to no editor by construction, so its hint
 * rides along too — the hint names the fillable column behind the assertion.
 */
function estateAccessorsFor(gap: FormGap): readonly string[] {
  // P3's unanswered Rule 25-3(6) rows ask for the same factual fields as the
  // established P4 completion rows. The form differs in requiredness, not in
  // where the practitioner records the answer.
  const p4EquivalentId = gap.requirementId.replace(/^p3_rule_25_3_6_/, "p4_rule_25_3_6_");
  // This row is an unanswered recorded fact. Derived workflow conditions
  // (including automatic PGT requirements) deliberately keep their guards.
  const popupHints = gap.requirementId === "p5_other_grants_status_valid" ? ["estate.otherGrantsStatus"] : [];
  const hints = GAP_EDIT_HINTS[gap.requirementId] ?? GAP_EDIT_HINTS[p4EquivalentId] ?? popupHints;
  if (gap.missingFields.length === 0) return hints;
  return gap.missingFields.some((accessor) => inlineEditableColumn(accessor) !== null)
    ? gap.missingFields
    : [...gap.missingFields, ...hints];
}

// Form P1's popup is limited to facts that its generated face actually uses.
// Delivery evidence, notice-recipient administration, and electronic-will
// recordkeeping remain in the estate preflight report, but do not belong in a
// P1 content-completion popup. They must never block a draft's generation.
const P1_NON_RENDERED_OUTPUT_GAP_IDS = new Set([
  "p1_deceased_other_names",
  "p1_deceased_birth",
  "p1_deceased_place_of_birth",
  "p1_recipient_list",
  "p1_wesa_spouse_status",
  "p1_spouse_name",
  "p1_spouse_address",
  "p1_electronic_will_no_signature_reason",
  "p1_will_copy_upload",
  "p1_codicil_uploads",
  "p1_foreign_grant_upload",
  "p1_foreign_grant_will_inclusion",
]);

// P2's popup likewise excludes file-management and workflow evidence that its
// rendered face does not consume. In particular, section 3's prescribed VSA
// statement is fixed text: its certificate receipt, outcome, and name-search
// records do not alter P2. The same is true of government-ID and source-file
// tracking. P2's direct content facts and the companion P9 evidence used in
// section 2 remain available to the user.
const P2_NON_RENDERED_OUTPUT_GAP_IDS = new Set([
  "p2_vsa_certificate_received",
  "p2_vsa_certificate_outcome",
  "p2_vsa_all_names_searched",
  "p2_notice_recipients_resolved",
  "p2_notice_wait_elapsed",
  "p2_pgt_grant_gate",
  "p2_death_certificate_source",
  "p2_original_will_source",
  "p2_asset_statements_source",
  "p2_applicant_id_source",
  "p2_deceased_place_of_birth",
  "p2_ancillary_foreign_grant_upload",
  "p2_ancillary_foreign_grant_certification",
  "p2_ancillary_will_inclusion",
  "p2_ancillary_will_certification",
  "p2_ancillary_separate_will_upload",
  "p2_ancillary_codicil_uploads",
  "p2_priority_paragraph",
]);

// P3 paragraphs 7 and 8 are prescribed statements, so the related will-file
// receipt and VSA certificate tracking do not alter P3's DOCX or preview.
// P3 also never prints the will date. These remain available in the broader
// readiness record, but do not belong in a P3 content-completion popup.
const P3_NON_RENDERED_OUTPUT_GAP_IDS = new Set([
  "p3_will_date",
  "p3_vsa_certificate_received",
  "p3_original_will_source",
]);

// P4 keeps every fact that selects a sworn branch or supplies its text. The
// exclusions below are different: they are receipt/upload evidence or only
// explain why P4 was selected instead of P3. P4's own DOCX and preview never
// read them, so they do not belong in the P4 content-completion popup.
const P4_NON_RENDERED_OUTPUT_GAP_IDS = new Set([
  "p4_wesa_s58_order",
  "p4_vsa_certificate_received",
  "p4_original_will_source",
  "p4_rule_25_3_6_belief_last_bc_will_unconfirmed",
  "p4_rule_25_3_6_wesa_s58_unconfirmed",
  "p4_rule_25_3_6_orders_affecting_will_unconfirmed",
  "p4_rule_25_3_6_documents_attached_unconfirmed",
]);

// P5 section 2 derives its selected official alternative from the applicant's
// relationship, nominee status, duration, and estate consent state. It never
// prints the per-contact prior-right consent workflow or the estate-level WESA
// spouse determination, so those workflow-only rows do not belong in P5's
// content-completion popup.
const P5_NON_RENDERED_OUTPUT_GAP_IDS = new Set([
  "p5_prior_rights_consent",
  "p5_prior_rights_inquiry_details",
  "p5_wesa_spouse_status",
]);

// Exact WESA s.130 priority rows presented in the P5 completion popup. One
// explicit user selection becomes the sole source for the paragraph cited on
// the sworn P5 face; no contact-role or consent inference replaces it.
const P5_PRIORITY_OPTIONS = [
  { value: "a", label: "(a) the spouse of the deceased person or a person nominated by the spouse" },
  { value: "b", label: "(b) a child of the deceased person having the consent of a majority of the children of the deceased person" },
  { value: "c", label: "(c) a person nominated by a child of the deceased person if that person has the consent of a majority of the deceased person's children" },
  { value: "d", label: "(d) a child of the deceased person not having the consent of a majority of the deceased person's children" },
  { value: "e", label: "(e) an intestate successor other than the spouse or child of the deceased person, having the consent of the intestate successors representing a majority in interest of the estate, including the intestate successor who applies for a grant of administration" },
  { value: "e.1", label: "(e.1) a person, other than the spouse or child of the deceased person, nominated by an intestate successor of the deceased person if that person has the consent of the intestate successors representing a majority in interest of the estate, including the intestate successor who nominated the person to apply for a grant of administration" },
  { value: "f", label: "(f) an intestate successor other than the spouse or child of the deceased person, not having the consent of the intestate successors representing a majority in interest of the estate, including the intestate successor who applies for a grant of administration" },
  { value: "f.1", label: "(f.1) in the case of a deceased person whose estate would pass to the government and would be subject to the Escheat Act, a person nominated by the government" },
  { value: "g", label: "(g) any other person the court considers appropriate to appoint, including, without limitation, and subject to the Public Guardian and Trustee's consent, the Public Guardian and Trustee" },
] as const;

// P6 does not print the foreign-grant filing metadata, the will date, or a
// certificate receipt. Its selected VSA result, search result, PGT choice,
// applicant facts, and jurat facts remain visible because they affect P6's
// actual face.
const P6_NON_RENDERED_OUTPUT_GAP_IDS = new Set([
  "p6_foreign_grant_issued_date",
  "p6_foreign_grant_issuing_court",
  "p6_foreign_grant_issuing_jurisdiction",
  "p6_will_date",
  "p6_vsa_certificate_received",
]);

// P7 prints the foreign court, jurisdiction, and issued date in paragraph 1,
// but never lists foreign-grant grantees. It also does not print a certificate
// receipt; the VSA result itself remains because it selects paragraph 6.
const P7_NON_RENDERED_OUTPUT_GAP_IDS = new Set([
  "p7_foreign_grant_grantees",
  "p7_wills_notice_found_omits_para6",
  "p7_vsa_certificate_received",
]);

// P9 section 2 identifies a will from the recorded will facts, not the
// storage receipt for the delivered copy. The receipt is an estate-file
// workflow item; foreign-grant storage, delivery facts, acknowledgements, and
// all other P9 requirements still change a sworn line or selected branch.
const P9_NON_RENDERED_OUTPUT_GAP_IDS = new Set([
  "p9_will_copy_available",
]);

// P10 Exhibit A does not vary from the recorded foreign-grant scope advisory:
// it still prints the same Part III rows. Keep the user-facing inventory facts
// that populate the exhibit, but omit this non-editable review notice from the
// single-form popup.
const P10_NON_RENDERED_OUTPUT_GAP_IDS = new Set([
  "p10_part3_foreign_grant_scope",
]);

// The form popup is a document-completion surface, not a filing-readiness
// checklist. These additions were verified form-by-form against the P1–P10
// DOCX and preview builders: each is operational, availability, source-file,
// or cross-form consistency information that does not populate its own face.
const P1_TO_P10_ADDITIONAL_NON_OUTPUT_GAP_IDS = new Set([
  "p1_will_status_required", "p1_applicability",
  "p2_notice_circle_confirmed", "p2_will_status_required", "p2_grant_will_consistency", "p2_ancillary_filing_attachments", "p2_applicability",
  "p3_pgt_auto_required", "p3_will_status_required", "p3_grant_will_consistency", "p3_applicability",
  "p3_rule_25_3_6_completion_required", "p3_rule_25_3_6_short_form_unavailable",
  "p4_will_status_required", "p4_grant_will_consistency", "p4_applicability",
  "p5_marriage_like_duration", "p5_intestate_successors", "p5_grant_type_required", "p5_grant_will_consistency", "p5_applicability", "p5_without_will_affidavit_on_will_grant",
  "p6_will_status_required", "p6_grant_type_required", "p6_grant_will_consistency", "p6_applicability",
  "p7_will_status_required", "p7_grant_type_required", "p7_grant_will_consistency", "p7_applicability",
  "p8_co_applicants", "p8_will_status_required", "p8_grant_type_required", "p8_grant_will_consistency", "p8_applicability", "p8_primary_affidavit_missing", "p8_primary_affidavit_ambiguous", "p8_primary_affidavit_non_applicant",
  "p9_dispensation_order", "p9_applicability",
  "p10_will_status_required", "p10_grant_will_consistency", "p10_applicability",
]);

// Each remaining shared-dialog form was traced independently against both its
// DOCX and preview builder. Keep direct face facts and visible alternatives;
// omit availability, readiness, filing history, attachment/provenance, and
// reconciliation rows even when legacy preflight marks them hard. A broad
// inventory requirement is excluded where its evaluator is wider than the
// exact inventory subset printed by the owning form.
const POST_P10_NON_OUTPUT_GAP_IDS = new Set([
  "p11_deponent_is_applicant", "p11_domicile_jurisdiction", "p11_secured_liability_asset_valid", "p11_secured_link_requires_status", "p11_will_status_required", "p11_grant_will_consistency", "p11_applicability",
  "p12_will_language_check", "p12_will_status_required", "p12_grant_type_required", "p12_grant_will_consistency", "p12_applicability",
  "p14_supplemental_inventory", "p14_asset_descriptions", "p14_inventory_categories", "p14_asset_locations", "p14_inventory_values", "p14_supplemental_provenance", "p14_has_supplemental_disclosure", "p14_secured_liability_asset_valid", "p14_secured_link_requires_status", "p14_will_status_required", "p14_grant_will_consistency", "p14_applicability",
  "p15_will_status_required", "p15_grant_will_consistency", "p15_applicability",
  "p16_route_selected", "p16_presence_confirmed", "p16_will_alterations_flag", "p16_contradicts_p4_no_alterations", "p16_will_status_required", "p16_grant_type_required", "p16_grant_will_consistency", "p16_applicability",
  "p17_will_status_required", "p17_grant_type_required", "p17_grant_will_consistency", "p17_applicability",
  "p26_inventory", "p26_asset_descriptions", "p26_inventory_categories", "p26_asset_locations", "p26_inventory_values", "p26_supplemental_provenance", "p26_has_supplemental_disclosure", "p26_secured_liability_asset_valid", "p26_secured_link_requires_status", "p26_will_status_required", "p26_grant_type_required", "p26_grant_will_consistency", "p26_applicability",
  "p34_citation_exhibit", "p34_service_date_and_route", "p34_supporting_service_affidavit", "p34_no_response_consistency", "p34_response_evidence", "p34_no_cited_grant", "p34_eligibility_period", "p34_will_status_required", "p34_grant_type_required", "p34_grant_will_consistency", "p34_applicability",
  "p44_application_filed", "p44_recipient_list", "p44_will_status_required", "p44_grant_type_required", "p44_grant_will_consistency", "p44_applicability",
  "p45_electronic_will_format", "p45_repo_name", "p45_repo_address", "p45_repo_access", "p45_will_status_required", "p45_grant_type_required", "p45_grant_will_consistency", "p45_applicability",
  "p46_will_status_required", "p46_grant_type_required", "p46_grant_will_consistency", "p46_applicability",
  "vsa532_will_status_required", "vsa532_grant_type_required", "vsa532_grant_will_consistency", "vsa532_applicability",
  "pgt_info_notify_pgt_flag", "pgt_info_applicability",
]);

const CONTENT_ONLY_POPUP_FORM_CODES = new Set([
  "P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10",
  "P11", "P12", "P14", "P15", "P16", "P17", "P26", "P34", "P44", "P45", "P46", "VSA532", "PGT_INFO",
]);

const P3_NON_OUTPUT_FACT_PREFIX = "p3_rule_25_3_6_";
const P8_PRIMARY_AFFIDAVIT_KEYS = [
  "p8PrimaryAffidavitForm",
  "p8PrimaryAffidavitDate",
  "p8PrimaryAffidavitDeponentName",
] as const;

// These generic readiness items are the rare bridges that feed a visible
// selection or value in the named form. Every other readiness bridge is kept
// out of the popup, even when its original requirement was marked hard.
const DIRECT_READINESS_GAP_IDS: Readonly<Record<string, ReadonlySet<string>>> = {
  P2: new Set([
    "readiness:executor_primary_missing", "readiness:executor_primary_duplicate",
    "readiness:separation_date_missing", "readiness:reconciliation_primary_purpose",
    "readiness:reconciliation_duration", "readiness:p1_recipient_determination",
  ]),
  P10: new Set([
    "readiness:separation_date_missing", "readiness:reconciliation_primary_purpose",
    "readiness:reconciliation_duration", "readiness:p10_distribution",
  ]),
};

function popupGapPopulatesForm(formCode: string, requirementId: string): boolean {
  if (!CONTENT_ONLY_POPUP_FORM_CODES.has(formCode)) return true;
  if (requirementId.startsWith("readiness:")) {
    return DIRECT_READINESS_GAP_IDS[formCode]?.has(requirementId) === true;
  }
  if (P1_TO_P10_ADDITIONAL_NON_OUTPUT_GAP_IDS.has(requirementId)) return false;
  if (POST_P10_NON_OUTPUT_GAP_IDS.has(requirementId)) return false;
  if (formCode === "P34" && requirementId.startsWith("p34_missing_citation:")) return false;
  if (formCode === "P3" && requirementId.startsWith(P3_NON_OUTPUT_FACT_PREFIX)) return false;
  const excluded = formCode === "P1" ? P1_NON_RENDERED_OUTPUT_GAP_IDS
    : formCode === "P2" ? P2_NON_RENDERED_OUTPUT_GAP_IDS
      : formCode === "P3" ? P3_NON_RENDERED_OUTPUT_GAP_IDS
        : formCode === "P4" ? P4_NON_RENDERED_OUTPUT_GAP_IDS
          : formCode === "P5" ? P5_NON_RENDERED_OUTPUT_GAP_IDS
            : formCode === "P6" ? P6_NON_RENDERED_OUTPUT_GAP_IDS
              : formCode === "P7" ? P7_NON_RENDERED_OUTPUT_GAP_IDS
                : formCode === "P9" ? P9_NON_RENDERED_OUTPUT_GAP_IDS
                  : formCode === "P10" ? P10_NON_RENDERED_OUTPUT_GAP_IDS
                    : null;
  return !excluded?.has(requirementId);
}

const P16_ALTERATION_COLUMNS = [
  "p16AlterationPage", "p16AlterationLine", "p16AlterationType",
  "p16AlterationWords", "p16DeponentPresentAtSigning",
] as const;
const p16AlterationColumn = (column: string): boolean => P16_ALTERATION_COLUMNS.some((value) => value === column);

/** Draft key for one row-editor descriptor. */
function rowEditorKey(editor: GapEditor): string {
  return `${editor.kind}:${editor.id ?? ""}:${editor.column ?? ""}`;
}

/** Persisted row edits collected by the dialog (contact/inventory branches). */
export interface PreGenerateRowEdits {
  contacts: Array<{ id: string; data: Record<string, string> }>;
  inventory: Array<{ id: string; data: Record<string, string | number> }>;
  createInventory: Array<Record<string, string | number>>;
}

/**
 * Form-local actions that cannot safely ride the estate override channel.
 * Contact roles and stored legal evidence are canonical file records; FormsTab
 * persists these first and then rechecks the form from the database before it
 * can generate.
 */
export interface P1InlineActions {
  estate: Record<string, string>;
  contacts: Array<{
    mode: "createApplicant" | "createRecipient" | "createSpouse" | "createIntestateSuccessor" | "designateIntestateSuccessor" | "createRenouncer" | "update";
    id?: string;
    name?: string;
    residentialAddress?: string;
    postalAddress?: string;
    recipientType?: string;
    role?: string;
    /** createSpouse only: a widowed file's late spouse (P2 Schedule §2(a) "(deceased)"). */
    isPredeceased?: 1;
    occupation?: string;
    relationshipDurationMonths?: string | number;
    priorityConsent?: string;
    priorityConsentInquiryDetails?: string;
    residenceStreet?: string;
    residenceCity?: string;
    residenceProvince?: string;
    residencePostalCode?: string;
    residenceCountry?: string;
    orgSignatoryName?: string;
    orgSignatoryTitle?: string;
    pgtInfoReviewed?: boolean;
  }>;
  uploads: Array<{ kind: "will" | "foreignGrant" | "codicil"; file: File }>;
}

/** Fixed field order of the quick-add mini form (inventoryAdd descriptor). */
const QUICK_ADD_FIELDS = ["category", "description", "location", "value", "passesToPersonalRepresentative"] as const;

/** Resolve a gap's requirement mode from the shared registry ("any" = OR-set). */
function gapMode(formCode: string, requirementId: string): "all" | "any" {
  const req = (FORM_REQUIREMENTS[formCode] ?? []).find((r) => r.id === requirementId);
  return req?.mode === "any" ? "any" : "all";
}

export interface PreGenerateDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Human-readable form name shown in the title, e.g. "P1 Notice" or "Grant Package". */
  formName: string;
  /** Reports for one or more forms. Pass a single-item array for single-form generate. */
  reports: ReadonlyArray<FormGapReport>;
  /** Called when the user continues, with an explicit draft opt-in when non-face preflight rows were suppressed. */
  onProceed: (options?: { generateAnyway?: boolean }) => void;
  /** Called when user clicks "Go to <tab>". Parent decides how to navigate. */
  onJumpToTab: (tab: ReadinessTab) => void;
  /** Called when user clicks Cancel or closes the dialog. */
  onCancel: () => void;
  /** Disables the Proceed button while the mutation is in flight. */
  proceeding?: boolean;
  /** The action being confirmed; controls truthful dialog/button copy. */
  action?: "generate" | "preview" | "download";
  /** Current estate row — seeds the inline editors. */
  estate?: Record<string, unknown> | null;
  /** Pending document answers: visibility context only; never implicitly saved. */
  renderOverrides?: Record<string, unknown>;
  /** Current estate contacts — used only for P1's canonical contact editors. */
  contacts?: Array<Record<string, unknown>>;
  /** Generated-document history used only to resolve P8's actual primary-affidavit deponent. */
  documents?: Array<{ formCode: string; deponentId?: string | null; deponentName?: string | null; signatureDate?: string | null }>;
  /** Current selected contact in the pending single-form action, used for P10’s deponent contact facts. */
  selectedContactId?: string | null;
  /**
   * True only when the pending mutation consumes the overrides channel
   * (single-form generate/preview/download). Package and bulk runs pass false
   * and this dialog renders exactly as before — typed values that a mutation
   * would drop must never be collectable.
   */
  inlineEditingEnabled?: boolean;
  /**
   * Apply the typed values: merge into the pending render's overrides,
   * optionally persist to the intake, and re-run the gap check. Resolves true
   * when the values were actually applied — false means the run aborted (a
   * failed save, or the user proceeded/cancelled mid-flight), and the dialog
   * then keeps the typed values pending rather than treating them as banked.
   */
  onApplyInline?: (values: Record<string, string | number>, saveToIntake: boolean, docKeysReceived?: string[], rowEdits?: PreGenerateRowEdits, p1Actions?: P1InlineActions, canonicalEstate?: CanonicalPopupPatch, canonicalObserver?: CanonicalPopupApplyObserver) => void | Promise<void | boolean>;
  /** Disables Apply & re-check while a save or re-check is in flight. */
  applying?: boolean;
  /**
   * Escape hatch for the not-applicable hard block on a user-initiated
   * single-form action (RULES.md Rule 24): instead of a dead "Blocked" button,
   * the dialog offers "Answer & <action> anyway", and the parent re-routes
   * through the applicability popup with generateAnyway. Absent on package/bulk
   * runs — those stay hard-gated (Rule 22 §6).
   */
  onOverrideNotApplicable?: () => void;
  /**
   * When true, the dialog shows a success animation before closing.
   * Set by the parent after the generation mutation succeeds.
   */
  succeeded?: boolean;
  /**
   * Task 13 r3 (Nick, 2026-10-24): set only for a "Review and generate again" review — the choices it will replay,
   * read from the request that was sent. The dialog says that confirming replaces the current version.
   */
  retainedChoices?: ReadonlyArray<{ label: string; value: string }>;
  /** Task 13 r3.1: the replayed form is a primary affidavit (P3–P7), which replaces whichever one is current. */
  retainedPrimaryAffidavit?: boolean;
}

export function PreGenerateDialog(props: PreGenerateDialogProps): React.JSX.Element {
  const {
    open, onOpenChange, formName, reports, onProceed, onJumpToTab, onCancel,
    proceeding, action = "generate", estate, renderOverrides, inlineEditingEnabled, onApplyInline, applying, succeeded,
    onOverrideNotApplicable, contacts = [], documents = [], selectedContactId, retainedChoices, retainedPrimaryAffidavit,
  } = props;

  // Internal state for the success animation
  const [showSuccess, setShowSuccess] = useState(false);
  const successTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (succeeded && open) {
      setShowSuccess(true);
      successTimerRef.current = setTimeout(() => {
        setShowSuccess(false);
        onCancel();
      }, 3000);
    }
    return () => {
      if (successTimerRef.current) clearTimeout(successTimerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [succeeded]);

  // Reset success state when dialog closes
  useEffect(() => {
    if (!open) setShowSuccess(false);
  }, [open]);

  type PendingCanonicalGap = { estateId: string; formCode: string; gap: FormGap; columns: string[] };
  const [pendingCanonicalGaps, setPendingCanonicalGaps] = useState<PendingCanonicalGap[]>([]);
  const allGaps: Array<{ formCode: string; gap: FormGap }> = [];
  for (const r of reports) {
    for (const g of r.gaps) allGaps.push({ formCode: r.formCode, gap: g });
  }

  const serverHardBlocked = reports.some((report) => report.hardBlocked === true)
    || allGaps.some(({ gap }) => gap.blocker === "hard");
  const notApplicable = reports.some((report) => report.notApplicable === true);
  const actionWord = action === "preview" ? "preview" : action === "download" ? "download" : "generate";
  const actionLabel = actionWord.charAt(0).toUpperCase() + actionWord.slice(1);
  const blockedActionLabel = action === "generate" ? "Generation" : actionLabel;

  const canEditInline = inlineEditingEnabled === true && typeof onApplyInline === "function";
  // P1 is the first form-local completion workflow. Its fields must persist to
  // canonical estate/contact/storage records before the re-check, rather than
  // silently riding a one-document override. Other forms retain their existing
  // editor behavior until their own dedicated task is completed.
  const isP1Only = reports.length === 1 && reports[0]?.formCode === "P1";
  const isP2Only = reports.length === 1 && reports[0]?.formCode === "P2";
  const isP3Only = reports.length === 1 && reports[0]?.formCode === "P3";
  const isP4Only = reports.length === 1 && reports[0]?.formCode === "P4";
  const isP5Only = reports.length === 1 && reports[0]?.formCode === "P5";
  const isP6Only = reports.length === 1 && reports[0]?.formCode === "P6";
  const isP7Only = reports.length === 1 && reports[0]?.formCode === "P7";
  const isP8Only = reports.length === 1 && reports[0]?.formCode === "P8";
  const isP9Only = reports.length === 1 && reports[0]?.formCode === "P9";
  const isP10Only = reports.length === 1 && reports[0]?.formCode === "P10";
  const isP11Only = reports.length === 1 && reports[0]?.formCode === "P11";
  const isP12Only = reports.length === 1 && reports[0]?.formCode === "P12";
  const isP14Only = reports.length === 1 && reports[0]?.formCode === "P14";
  const isP15Only = reports.length === 1 && reports[0]?.formCode === "P15";
  const isP16Only = reports.length === 1 && reports[0]?.formCode === "P16";
  const showP16AlterationEditor = isP16Only && canEditInline;
  const isP17Only = reports.length === 1 && reports[0]?.formCode === "P17";
  const isP26Only = reports.length === 1 && reports[0]?.formCode === "P26";
  const isP34Only = reports.length === 1 && reports[0]?.formCode === "P34";
  const isP44Only = reports.length === 1 && reports[0]?.formCode === "P44";
  const isP45Only = reports.length === 1 && reports[0]?.formCode === "P45";
  const isP46Only = reports.length === 1 && reports[0]?.formCode === "P46";
  const isVsa532Only = reports.length === 1 && reports[0]?.formCode === "VSA532";
  const isPgtInfoOnly = reports.length === 1 && reports[0]?.formCode === "PGT_INFO";
  const isCanonicalCompletionForm = isP1Only || isP2Only || isP3Only || isP4Only || isP5Only || isP6Only || isP7Only || isP8Only || isP9Only || isP10Only || isP11Only || isP12Only || isP14Only || isP15Only || isP16Only || isP17Only || isP26Only || isP34Only || isP44Only || isP45Only || isP46Only || isVsa532Only || isPgtInfoOnly;
  const p1GapIds = useMemo(() => new Set(
    isP1Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP1Only, reports]);
  const p2GapIds = useMemo(() => new Set(
    isP2Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP2Only, reports]);
  const p3GapIds = useMemo(() => new Set(
    isP3Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP3Only, reports]);
  const p4GapIds = useMemo(() => new Set(
    isP4Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP4Only, reports]);
  const p5GapIds = useMemo(() => new Set(
    isP5Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP5Only, reports]);
  const p6GapIds = useMemo(() => new Set(
    isP6Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP6Only, reports]);
  const p7GapIds = useMemo(() => new Set(
    isP7Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP7Only, reports]);
  const p8GapIds = useMemo(() => new Set(
    isP8Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP8Only, reports]);
  const p17GapIds = useMemo(() => new Set(
    isP17Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP17Only, reports]);
  const p9GapIds = useMemo(() => new Set(
    isP9Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP9Only, reports]);
  const p10GapIds = useMemo(() => new Set(
    isP10Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP10Only, reports]);
  const p11GapIds = useMemo(() => new Set(
    isP11Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP11Only, reports]);
  const p26GapIds = useMemo(() => new Set(
    isP26Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP26Only, reports]);
  const p44GapIds = useMemo(() => new Set(
    isP44Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP44Only, reports]);
  const p45GapIds = useMemo(() => new Set(
    isP45Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP45Only, reports]);
  const p46GapIds = useMemo(() => new Set(
    isP46Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isP46Only, reports]);
  const vsa532GapIds = useMemo(() => new Set(
    isVsa532Only ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isVsa532Only, reports]);
  const pgtInfoGapIds = useMemo(() => new Set(
    isPgtInfoOnly ? allGaps.map(({ gap }) => gap.requirementId) : [],
  ), [isPgtInfoOnly, reports]);
  // Filter per owning form, rather than per report, so a package cannot make
  // a non-output readiness, availability, attachment, or history row reappear.
  // A legacy hard label never turns a non-rendered row into a completion-card
  // blocker; explicit user continuation carries draft intent to the mutation.
  const currentDisplayedGaps = allGaps.filter(({ formCode, gap }) => popupGapPopulatesForm(formCode, gap.requirementId));
  const currentGapKeys = new Set(currentDisplayedGaps.map(({ formCode, gap }) => `${formCode}:${gap.requirementId}`));
  // These rows were offered in this exact dialog when an Apply began. Retain
  // only newer explicit input that the older save/recheck could not include.
  // They are pending editors, not newly invented server gaps or legal blocks.
  const retainedCanonicalGaps = canEditInline && reports.length === 1 ? pendingCanonicalGaps.filter(row =>
    row.estateId === String(estate?.id ?? "") && row.formCode === reports[0].formCode
    && !currentGapKeys.has(`${row.formCode}:${row.gap.requirementId}`)) : [];
  const retainedCanonicalByKey = new Map(retainedCanonicalGaps.map(row => [`${row.formCode}:${row.gap.requirementId}`, row]));
  const hasPendingCanonicalRows = retainedCanonicalGaps.length > 0;
  const displayedGaps = [...currentDisplayedGaps, ...retainedCanonicalGaps];
  const isReady = currentDisplayedGaps.length === 0;
  const hardBlocked = serverHardBlocked && currentDisplayedGaps.some(({ gap }) => gap.blocker === "hard");
  const requiresDraftOptIn = allGaps.some(({ formCode, gap }) => !popupGapPopulatesForm(formCode, gap.requirementId));
  // The not-applicable route remains available only when the displayed form
  // content has no separate hard truth gate. Hidden availability rows go
  // through the ordinary explicit draft action rather than a second popup.
  const naOnlyHardBlock = hardBlocked && notApplicable
    && currentDisplayedGaps
      .filter(({ gap }) => gap.blocker === "hard")
      .every(({ gap }) => gap.requirementId.endsWith("_applicability"));

  type ContactDraft = {
    name: string;
    residentialAddress: string;
    postalAddress: string;
    occupation: string;
    relationshipDurationMonths: string;
    priorityConsent: string;
    priorityConsentInquiryDetails: string;
    residenceStreet: string;
    residenceCity: string;
    residenceProvince: string;
    residencePostalCode: string;
    residenceCountry: string;
    orgSignatoryName: string;
    orgSignatoryTitle: string;
    pgtInfoReviewed: boolean;
  };
  const [p1ContactDrafts, setP1ContactDrafts] = useState<Record<string, ContactDraft>>({});
  const [p1ApplicantDraft, setP1ApplicantDraft] = useState<ContactDraft>({ name: "", residentialAddress: "", postalAddress: "", occupation: "", relationshipDurationMonths: "", priorityConsent: "unknown", priorityConsentInquiryDetails: "", residenceStreet: "", residenceCity: "", residenceProvince: "", residencePostalCode: "", residenceCountry: "", orgSignatoryName: "", orgSignatoryTitle: "", pgtInfoReviewed: false });
  const [p1RecipientDraft, setP1RecipientDraft] = useState<ContactDraft & { recipientType: string }>({ name: "", residentialAddress: "", postalAddress: "", recipientType: "beneficiary", occupation: "", relationshipDurationMonths: "", priorityConsent: "unknown", priorityConsentInquiryDetails: "", residenceStreet: "", residenceCity: "", residenceProvince: "", residencePostalCode: "", residenceCountry: "", orgSignatoryName: "", orgSignatoryTitle: "", pgtInfoReviewed: false });
  const [p1SpouseDraft, setP1SpouseDraft] = useState<ContactDraft>({ name: "", residentialAddress: "", postalAddress: "", occupation: "", relationshipDurationMonths: "", priorityConsent: "unknown", priorityConsentInquiryDetails: "", residenceStreet: "", residenceCity: "", residenceProvince: "", residencePostalCode: "", residenceCountry: "", orgSignatoryName: "", orgSignatoryTitle: "", pgtInfoReviewed: false });
  const [p5SuccessorDraft, setP5SuccessorDraft] = useState({ contactId: "", name: "", residentialAddress: "" });
  const [p1OtherNamesDraft, setP1OtherNamesDraft] = useState({ first: "", middle: "", last: "", additional: "" });
  const [p1EstateDraft, setP1EstateDraft] = useState<Record<string, string>>({});
  const [p1Uploads, setP1Uploads] = useState<Record<"will" | "foreignGrant" | "codicil", File[]>>({ will: [], foreignGrant: [], codicil: [] });

  // Draft values keyed by estate column. Seeded from the estate row each time
  // the dialog opens; kept across re-checks so the list shrinks around what
  // the user already typed. A column named by several gaps binds to ONE draft.
  const [draft, setDraft] = useState<Record<string, string>>({});
  const [seed, setSeed] = useState<Record<string, string>>({});
  const [canonicalDraft, setCanonicalDraft] = useState<Record<string, string>>({});
  const latestCouplingChoicesRef = useRef({ filing: draft.willFilingType, canonical: canonicalDraft });
  latestCouplingChoicesRef.current = { filing: draft.willFilingType, canonical: canonicalDraft };
  const canonicalInputVersionsRef = useRef<Record<string, number>>({});
  const filingInputVersionRef = useRef(0);
  const latestCanonicalRecordRef = useRef<Record<string, unknown>>({});
  const [canonicalFilingIntent, setCanonicalFilingIntent] = useState<{
    cycle: number; filing: string; filingVersion: number; mediumVersion: number;
    medium: { willType: string; isElectronicWill: number };
  } | null>(null);
  const [canonicalAppearanceRemovalPending, setCanonicalAppearanceRemovalPending] = useState(false);
  const [canonicalSeed, setCanonicalSeed] = useState<Record<string, unknown>>({});
  const [canonicalCommitted, setCanonicalCommitted] = useState<(CanonicalPopupSaveReceipt & { observedEstate: typeof estate }) | null>(null);
  const [canonicalSavedKeys, setCanonicalSavedKeys] = useState<Set<string>>(new Set());
  const [canonicalUncertainKeys, setCanonicalUncertainKeys] = useState<Set<string>>(new Set());
  const [canonicalNeedsRecheck, setCanonicalNeedsRecheck] = useState(false);
  const canonicalCycleRef = useRef(0);
  const [p8PrimaryDraft, setP8PrimaryDraft] = useState<Record<string, string>>({});
  const [p8PrimarySeed, setP8PrimarySeed] = useState<Record<string, string>>({});
  const [saveToIntake, setSaveToIntake] = useState(true);
  // Required-document receipts the user ticks in place. A doc key only appears
  // in a gap while UNreceived, so every checkbox seeds unchecked; ticking one
  // is a real receipt record persisted via requiredDoc.upsert on Apply — it
  // never rides the overrides channel (shared/inlineFieldControls.ts).
  const [docDraft, setDocDraft] = useState<Record<string, boolean>>({});
  // Row-editor drafts keyed `${kind}:${id}:${column}` (descriptor edits) and
  // the quick-add mini form's own field drafts. A row+column named by several
  // gaps binds to ONE draft — the same dedupe rule as estate columns. Row
  // seeds start empty (descriptors only exist for blank columns); the seed map
  // exists so a confirmed Apply banks what was sent (a second Apply must not
  // rewrite already-persisted row values).
  const [rowDraft, setRowDraft] = useState<Record<string, string>>({});
  const [rowSeed, setRowSeed] = useState<Record<string, string>>({});
  const [addDraft, setAddDraft] = useState<Record<string, string>>({});
  // Idempotency id for the quick-add row, stable across retries of the SAME
  // draft: a committed-but-rejected inventory.create (row inserted, response
  // lost) replays with the same id and the server resolves to the committed
  // row instead of a duplicate sworn asset (2026-08-21 goal loop). Minted
  // lazily on first payload build; reset with the draft.
  const quickAddIdRef = useRef<string | null>(null);
  useEffect(() => {
    canonicalCycleRef.current += 1;
    canonicalInputVersionsRef.current = {};
    filingInputVersionRef.current = 0;
    setCanonicalFilingIntent(null);
    setPendingCanonicalGaps([]);
    if (!open) return;
    const seeded: Record<string, string> = {};
    for (const { gap } of displayedGaps) {
      for (const accessor of estateAccessorsFor(gap)) {
        const column = inlineEditableColumn(accessor);
        if (column !== null && !(column in seeded)) {
          const current = estate?.[column];
          seeded[column] = current === null || current === undefined ? "" : String(current);
        }
      }
    }
    // P16 reviews its separate facts even when they are already populated.
    // Preserve their literal recorded values so the user can correct them.
    if (showP16AlterationEditor) {
      for (const column of P16_ALTERATION_COLUMNS) seeded[column] = String(estate?.[column] ?? "");
    }
    // WESA s.2 is collected only when the relevant form needs it. Civil
    // status supplies a starting point, but the blank seed keeps that proposal
    // a pending change until the user explicitly clicks Apply & re-check.
    const initialDraft = { ...seeded };
    if ("spouseStatus" in seeded && !seeded.spouseStatus) {
      initialDraft.spouseStatus = suggestWesaSpouseStatus(String(estate?.maritalStatus ?? ""))?.status ?? "";
    }
    setDraft(initialDraft);
    setSeed(seeded);
    setCanonicalDraft({});
    setCanonicalSeed({ ...(estate ?? {}), ...renderOverrides });
    setCanonicalCommitted(null);
    setCanonicalSavedKeys(new Set());
    setCanonicalUncertainKeys(new Set());
    setCanonicalNeedsRecheck(false);
    setCanonicalAppearanceRemovalPending(false);
    const retainedPrimary = documents.find((document) => ["P3", "P4", "P5", "P6", "P7"].includes(document.formCode));
    const retainedPrimaryContact = retainedPrimary?.deponentId
      ? contacts.find((contact) => String(contact.id ?? "") === String(retainedPrimary.deponentId))
      : undefined;
    const p8Seed = {
      p8PrimaryAffidavitForm: retainedPrimary?.formCode && ["P3", "P4", "P5", "P6", "P7"].includes(retainedPrimary.formCode) ? retainedPrimary.formCode : "",
      p8PrimaryAffidavitDate: String(retainedPrimary?.signatureDate ?? ""),
      p8PrimaryAffidavitDeponentName: String(retainedPrimary?.deponentName ?? retainedPrimaryContact?.name ?? ""),
    };
    setP8PrimaryDraft(p8Seed);
    setP8PrimarySeed(p8Seed);
    setDocDraft({});
    setRowDraft({});
    setRowSeed({});
    setAddDraft({});
    quickAddIdRef.current = null;
    setSaveToIntake(true);
    const contactSeeds: Record<string, ContactDraft> = {};
    for (const contact of contacts) {
      contactSeeds[String(contact.id)] = {
        name: String(contact.name ?? ""),
        residentialAddress: String(contact.residentialAddress || contact.address || ""),
        postalAddress: String(contact.postalAddress ?? ""),
        occupation: String(contact.occupation ?? ""),
        relationshipDurationMonths: contact.relationshipDurationMonths === null || contact.relationshipDurationMonths === undefined ? "" : String(contact.relationshipDurationMonths),
        priorityConsent: String(contact.priorityConsent ?? "unknown"),
        priorityConsentInquiryDetails: String(contact.priorityConsentInquiryDetails ?? ""),
        residenceStreet: String(contact.residenceStreet ?? ""),
        residenceCity: String(contact.residenceCity ?? ""),
        residenceProvince: String(contact.residenceProvince ?? ""),
        residencePostalCode: String((contact as any).residencePostalCode ?? ""),
        residenceCountry: String(contact.residenceCountry ?? ""),
        orgSignatoryName: String(contact.orgSignatoryName ?? ""),
        orgSignatoryTitle: String(contact.orgSignatoryTitle ?? ""),
        pgtInfoReviewed: Number(contact.pgtInfoReviewed) === 1,
      };
    }
    setP1ContactDrafts(contactSeeds);
    setP1ApplicantDraft({ name: "", residentialAddress: "", postalAddress: "", occupation: "", relationshipDurationMonths: "", priorityConsent: "unknown", priorityConsentInquiryDetails: "", residenceStreet: "", residenceCity: "", residenceProvince: "", residencePostalCode: "", residenceCountry: "", orgSignatoryName: "", orgSignatoryTitle: "", pgtInfoReviewed: false });
    setP1RecipientDraft({ name: "", residentialAddress: "", postalAddress: "", recipientType: "beneficiary", occupation: "", relationshipDurationMonths: "", priorityConsent: "unknown", priorityConsentInquiryDetails: "", residenceStreet: "", residenceCity: "", residenceProvince: "", residencePostalCode: "", residenceCountry: "", orgSignatoryName: "", orgSignatoryTitle: "", pgtInfoReviewed: false });
    setP1SpouseDraft({ name: "", residentialAddress: "", postalAddress: "", occupation: "", relationshipDurationMonths: "", priorityConsent: "unknown", priorityConsentInquiryDetails: "", residenceStreet: "", residenceCity: "", residenceProvince: "", residencePostalCode: "", residenceCountry: "", orgSignatoryName: "", orgSignatoryTitle: "", pgtInfoReviewed: false });
    setP5SuccessorDraft({ contactId: "", name: "", residentialAddress: "" });
    setP1OtherNamesDraft({
      first: String(estate?.akaFirstName ?? ""),
      middle: String(estate?.akaMiddleName ?? ""),
      last: String(estate?.akaLastName ?? ""),
      additional: String(estate?.deceasedAliases ?? "").split(";").slice(1).map((value) => value.trim()).filter(Boolean).join("\n"),
    });
    setP1EstateDraft({
      noVisibleSignatureReason: String(estate?.noVisibleSignatureReason ?? ""),
      foreignGrantIncludesWill: String(estate?.foreignGrantIncludesWill ?? ""),
      grantType: String(estate?.grantType ?? "unknown"),
      testamentaryDocStatus: String(estate?.testamentaryDocStatus ?? ""),
      foreignGrantIssuedDate: String(estate?.foreignGrantIssuedDate ?? ""),
      foreignGrantCertifiedByIssuingCourt: String(estate?.foreignGrantCertifiedByIssuingCourt ?? ""),
      ancillaryWillDocumentsCertifiedByIssuingCourt: String(estate?.ancillaryWillDocumentsCertifiedByIssuingCourt ?? ""),
      orderFiled: String(estate?.orderFiled ?? ""),
      electronicWillOriginalAvailable: String(estate?.electronicWillOriginalAvailable ?? ""),
      electronicWillFirstSavedPdf: String(estate?.electronicWillFirstSavedPdf ?? ""),
      electronicWillInRepository: String(estate?.electronicWillInRepository ?? ""),
      electronicWillFormat: String(estate?.electronicWillFormat ?? ""),
    });
    setP1Uploads({ will: [], foreignGrant: [], codicil: [] });
    // Re-seed only on open — not on every report refresh mid-edit.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const p1ApplyingContacts = useMemo(
    () => contacts.filter((contact) => isApplyingApplicant(contact as any)),
    [contacts],
  );
  const p1SpouseContacts = useMemo(
    () => contacts.filter((contact) => contactHasRole(contact as any, "spouse")
      || String(contact.recipientType || "") === "spouse"
      || ["spouse", "common-law partner"].includes(String(contact.relationship || ""))),
    [contacts],
  );
  const p5PrimaryApplicant = useMemo(
    () => findPrimaryApplicant(contacts as any[]) as Record<string, unknown> | undefined,
    [contacts],
  );
  const pgtInfoRecipients = useMemo(
    () => isPgtInfoOnly ? p1NoticeRecipients(estate as any, contacts as any[]) as Array<Record<string, unknown>> : [],
    [contacts, estate, isPgtInfoOnly],
  );
  const p8PrimaryHistory = useMemo(
    () => primaryAffidavitDeponentFromDocuments(documents),
    [documents],
  );
  const p8CoApplicantContacts = useMemo(() => {
    if (!isP8Only || p8PrimaryHistory.ambiguous || !p8PrimaryHistory.deponentId) return [];
    return p8ApplyingCoApplicants(contacts as any[], p8PrimaryHistory.deponentId).coApplicants as Array<Record<string, unknown>>;
  }, [contacts, isP8Only, p8PrimaryHistory]);
  const p10Deponent = useMemo(() => {
    if ((!isP10Only && !isP11Only) || !selectedContactId) return undefined;
    return contacts.find((contact) => String(contact.id ?? "") === String(selectedContactId));
  }, [contacts, isP10Only, selectedContactId]);
  const p5PriorRightContacts = useMemo(() => contacts.filter((contact) => {
    const id = String(contact.id ?? "");
    if (!id || id === String(p5PrimaryApplicant?.id ?? "") || isApplyingApplicant(contact as any)) return false;
    if (String(contact.priorityConsent ?? "unknown") === "not_required") return false;
    return ["spouse", "child", "intestate_successor"].includes(String(contact.role ?? ""))
      || ["spouse", "child", "intestate_successor"].includes(String(contact.recipientType ?? ""));
  }), [contacts, p5PrimaryApplicant]);

  function setP1ContactDraft(contactId: string, patch: Partial<ContactDraft>): void {
    setP1ContactDrafts((current) => ({
      ...current,
      [contactId]: { ...(current[contactId] ?? { name: "", residentialAddress: "" }), ...patch },
    }));
  }

  function p1ContactChanged(contact: Record<string, unknown>, field: keyof ContactDraft): boolean {
    const draftValue = p1ContactDrafts[String(contact.id)]?.[field] ?? "";
    const currentValue = field === "residentialAddress"
      ? String(contact.residentialAddress || contact.address || "")
      : field === "relationshipDurationMonths"
        ? contact.relationshipDurationMonths === null || contact.relationshipDurationMonths === undefined ? "" : String(contact.relationshipDurationMonths)
        : field === "priorityConsent"
          ? String(contact.priorityConsent ?? "unknown")
          : String(contact[field] ?? "");
    return draftValue !== "" && draftValue !== currentValue;
  }

  function buildP1Actions(): P1InlineActions | undefined {
    if (!isP1Only && !isP2Only && !isP3Only && !isP4Only && !isP5Only && !isP6Only && !isP7Only && !isP8Only && !isP9Only && !isP10Only && !isP11Only && !isP17Only && !isP26Only && !isP44Only && !isP45Only && !isP46Only && !isVsa532Only && !isPgtInfoOnly) return undefined;
    const actions: P1InlineActions = { estate: {}, contacts: [], uploads: [] };
    const wantsApplicant = p1GapIds.has("p1_applicant_contact") || p2GapIds.has("p2_applicant_contact") || p3GapIds.has("p3_applicant_contact") || p6GapIds.has("p6_applicant_contact") || p7GapIds.has("p7_applicant_contact") || p8GapIds.has("p8_co_applicants") || p44GapIds.has("p44_applicant_contact") || p46GapIds.has("p46_applicant_contact") || (isVsa532Only && !p5PrimaryApplicant && vsa532GapIds.has("vsa532_applicant_contact"));
    if (wantsApplicant && (p1ApplicantDraft.name.trim() || p1ApplicantDraft.residentialAddress.trim())) {
      actions.contacts.push({ mode: "createApplicant", name: p1ApplicantDraft.name, residentialAddress: p1ApplicantDraft.residentialAddress, ...(p1ApplicantDraft.postalAddress.trim() ? { postalAddress: p1ApplicantDraft.postalAddress } : {}), ...(p1ApplicantDraft.occupation.trim() ? { occupation: p1ApplicantDraft.occupation } : {}) });
    }
    // Nick 2026-09-01 directive (P17): the renouncer is collectable in place —
    // never defaulted to the applicant.
    const wantsRenouncer = p17GapIds.has("p17_renouncer_contact");
    if (wantsRenouncer && (p1ApplicantDraft.name.trim() || p1ApplicantDraft.residentialAddress.trim())) {
      actions.contacts.push({ mode: "createRenouncer", name: p1ApplicantDraft.name, residentialAddress: p1ApplicantDraft.residentialAddress, ...(p1ApplicantDraft.occupation.trim() ? { occupation: p1ApplicantDraft.occupation } : {}) });
    }
    const wantsRecipient = p1GapIds.has("p1_recipient_list") || p44GapIds.has("p44_recipient_list");
    if (wantsRecipient && (p1RecipientDraft.name.trim() || p1RecipientDraft.residentialAddress.trim())) {
      actions.contacts.push({ mode: "createRecipient", name: p1RecipientDraft.name, residentialAddress: p1RecipientDraft.residentialAddress, recipientType: p1RecipientDraft.recipientType });
    }
    const wantsLateSpouse = p2GapIds.has("p2_late_spouse_contact");
    const wantsSpouse = p1GapIds.has("p1_spouse_name") || p1GapIds.has("p1_spouse_address") || p2GapIds.has("p2_spouse_contact") || wantsLateSpouse;
    if (wantsSpouse && p1SpouseContacts.length === 0 && (p1SpouseDraft.name.trim() || p1SpouseDraft.residentialAddress.trim())) {
      // Nick 2026-09-02 (P2-05): the late spouse is a real predeceased spouse
      // contact — Schedule §2(a) then prints the name with "(deceased)".
      actions.contacts.push({ mode: "createSpouse", name: p1SpouseDraft.name, residentialAddress: p1SpouseDraft.residentialAddress, ...(wantsLateSpouse ? { isPredeceased: 1 as const } : {}) });
    }
    const contactsToEdit = [
      ...(p1GapIds.has("p1_applicant_names") || p1GapIds.has("p1_applicant_postal") ? p1ApplyingContacts : []),
      ...(wantsSpouse ? p1SpouseContacts : []),
    ];
    if (isVsa532Only && p5PrimaryApplicant) {
      const id = String(p5PrimaryApplicant.id ?? "");
      const draft = p1ContactDrafts[id];
      if (id && draft) {
        const nameChanged = vsa532GapIds.has("vsa532_applicant_contact") && p1ContactChanged(p5PrimaryApplicant, "name");
        const postalChanged = vsa532GapIds.has("vsa532_applicant_postal") && p1ContactChanged(p5PrimaryApplicant, "postalAddress");
        if (nameChanged || postalChanged) actions.contacts.push({ mode: "update", id, ...(nameChanged ? { name: draft.name } : {}), ...(postalChanged ? { postalAddress: draft.postalAddress } : {}) });
      }
    }
    if (isPgtInfoOnly) {
      for (const recipient of pgtInfoRecipients) {
        const id = String(recipient.id ?? "");
        const draft = p1ContactDrafts[id];
        if (!id || !draft) continue;
        const nameChanged = pgtInfoGapIds.has("pgt_info_recipient_names") && draft.name.trim() !== String(recipient.name ?? "").trim();
        const reviewConfirmed = pgtInfoGapIds.has("pgt_info_recipient_details_reviewed")
          && Number(recipient.pgtInfoReviewed) !== 1
          && draft.pgtInfoReviewed;
        if (nameChanged || reviewConfirmed) {
          actions.contacts.push({ mode: "update", id, ...(nameChanged ? { name: draft.name } : {}), ...(reviewConfirmed ? { pgtInfoReviewed: true } : {}) });
        }
      }
    }
    const seenContacts = new Set<string>();
    for (const contact of contactsToEdit) {
      const id = String(contact.id);
      if (!id || seenContacts.has(id)) continue;
      seenContacts.add(id);
      const draft = p1ContactDrafts[id];
      if (!draft) continue;
      const nameChanged = p1ContactChanged(contact, "name");
      const addressChanged = p1ContactChanged(contact, "residentialAddress");
      if (nameChanged || addressChanged) {
        actions.contacts.push({ mode: "update", id, ...(nameChanged ? { name: draft.name } : {}), ...(addressChanged ? { residentialAddress: draft.residentialAddress } : {}) });
      }
    }
    if (p1GapIds.has("p1_deceased_other_names") || p11GapIds.has("p11_deceased_aliases")) {
      const firstAlias = [p1OtherNamesDraft.first, p1OtherNamesDraft.middle, p1OtherNamesDraft.last].map((value) => value.trim()).filter(Boolean).join(" ");
      const additionalAliases = p1OtherNamesDraft.additional.split("\n").map((value) => value.trim()).filter(Boolean);
      if (firstAlias || additionalAliases.length > 0) {
        actions.estate.akaFirstName = p1OtherNamesDraft.first.trim();
        actions.estate.akaMiddleName = p1OtherNamesDraft.middle.trim();
        actions.estate.akaLastName = p1OtherNamesDraft.last.trim();
        actions.estate.hasAdditionalNames = additionalAliases.length > 0 ? "yes" : "no";
        actions.estate.deceasedAliases = [firstAlias, ...additionalAliases].filter(Boolean).join("; ");
      }
    }
    const noVisibleSignatureReason = p1EstateDraft.noVisibleSignatureReason || "";
    if (p1GapIds.has("p1_electronic_will_no_signature_reason") && noVisibleSignatureReason.trim()) {
      actions.estate.noVisibleSignatureReason = noVisibleSignatureReason.trim();
    }
    if ((p1GapIds.has("p1_foreign_grant_will_inclusion") || p9GapIds.has("p9_foreign_grant_will_inclusion")) && ["yes", "no"].includes(p1EstateDraft.foreignGrantIncludesWill)) {
      actions.estate.foreignGrantIncludesWill = p1EstateDraft.foreignGrantIncludesWill;
    }
    if ((p1GapIds.has("p1_grant_type") || p2GapIds.has("p2_grant_type")) && p1EstateDraft.grantType && p1EstateDraft.grantType !== "unknown") {
      actions.estate.grantType = p1EstateDraft.grantType;
    }
    if ((p2GapIds.has("p2_ancillary_foreign_grant_issued_date") || p6GapIds.has("p6_foreign_grant_issued_date") || p7GapIds.has("p7_foreign_grant_issued_date") || p26GapIds.has("p26_foreign_grant_issued_date")) && p1EstateDraft.foreignGrantIssuedDate) actions.estate.foreignGrantIssuedDate = p1EstateDraft.foreignGrantIssuedDate;
    if (p45GapIds.has("p45_electronic_will_format") && p1EstateDraft.electronicWillFirstSavedPdf && p1EstateDraft.electronicWillInRepository) {
      const withPdfAxis = applyElectronicWillAxis(
        { ...(estate ?? {}), ...p1EstateDraft } as any,
        "electronicWillFirstSavedPdf",
        p1EstateDraft.electronicWillFirstSavedPdf,
      );
      const resolved = applyElectronicWillAxis(
        withPdfAxis as any,
        "electronicWillInRepository",
        p1EstateDraft.electronicWillInRepository,
      );
      actions.estate = { ...actions.estate, ...resolved };
    }
    if ((p5GapIds.has("p5_testamentary_doc_status") || p5GapIds.has("p5_testamentary_doc_status_valid") || p6GapIds.has("p6_testamentary_doc_status") || p7GapIds.has("p7_testamentary_doc_status"))
      && ["none_found", "found"].includes(p1EstateDraft.testamentaryDocStatus)) {
      actions.estate.testamentaryDocStatus = p1EstateDraft.testamentaryDocStatus;
    }
    if (p5GapIds.has("p5_priority_paragraph") && P5_PRIORITY_OPTIONS.some((option) => option.value === p1EstateDraft.applicantPriorityParagraph)) {
      actions.estate.applicantPriorityParagraph = p1EstateDraft.applicantPriorityParagraph;
    }
    if (p2GapIds.has("p2_ancillary_foreign_grant_certification") && p1EstateDraft.foreignGrantCertifiedByIssuingCourt === "yes") actions.estate.foreignGrantCertifiedByIssuingCourt = "yes";
    if (p2GapIds.has("p2_ancillary_will_certification") && p1EstateDraft.ancillaryWillDocumentsCertifiedByIssuingCourt === "yes") actions.estate.ancillaryWillDocumentsCertifiedByIssuingCourt = "yes";
    if (p2GapIds.has("p2_order_filed_status") && ["filed", "not_yet_filed"].includes(p1EstateDraft.orderFiled)) actions.estate.orderFiled = p1EstateDraft.orderFiled;
    const p4AffidavitLists = [
      ["p4_attestation_affidavits", "attestationAffidavits"],
      ["p4_interlineation_affidavits", "interlineationAffidavits"],
      ["p4_erasure_affidavits", "erasureAffidavits"],
    ] as const;
    for (const [requirementId, column] of p4AffidavitLists) {
      const name = p1EstateDraft[`${requirementId}_name`]?.trim();
      const sworn = p1EstateDraft[`${requirementId}_sworn`]?.trim();
      if (p4GapIds.has(requirementId) && name && sworn) {
        actions.estate[column] = JSON.stringify([{ name, sworn }]);
      }
    }
    const p5PrimaryGap = p5GapIds.has("p5_marriage_like_duration")
      || p5GapIds.has("p5_deponent_name")
      || p5GapIds.has("p5_deponent_address")
      || p5GapIds.has("p5_deponent_occupation");
    if (p5PrimaryGap && p5PrimaryApplicant) {
      const id = String(p5PrimaryApplicant.id ?? "");
      const draft = p1ContactDrafts[id];
      if (id && draft) {
        const update: P1InlineActions["contacts"][number] = { mode: "update", id };
        if (p5GapIds.has("p5_deponent_name") && p1ContactChanged(p5PrimaryApplicant, "name")) update.name = draft.name.trim();
        if (p5GapIds.has("p5_deponent_address") && p1ContactChanged(p5PrimaryApplicant, "residentialAddress")) update.residentialAddress = draft.residentialAddress.trim();
        if (p5GapIds.has("p5_deponent_occupation") && p1ContactChanged(p5PrimaryApplicant, "occupation")) update.occupation = draft.occupation.trim();
        const duration = Number(draft.relationshipDurationMonths);
        if (p5GapIds.has("p5_marriage_like_duration") && p1ContactChanged(p5PrimaryApplicant, "relationshipDurationMonths") && Number.isFinite(duration) && duration >= 0) {
          update.relationshipDurationMonths = duration;
        }
        if (Object.keys(update).length > 2) actions.contacts.push(update);
      }
    }
    if (p5GapIds.has("p5_prior_rights_consent") || p5GapIds.has("p5_prior_rights_inquiry_details")) {
      for (const contact of p5PriorRightContacts) {
        const id = String(contact.id ?? "");
        const draft = p1ContactDrafts[id];
        if (!id || !draft) continue;
        const update: P1InlineActions["contacts"][number] = { mode: "update", id };
        if (p1ContactChanged(contact, "priorityConsent") && ["consented", "renounced", "cannot_locate"].includes(draft.priorityConsent)) {
          update.priorityConsent = draft.priorityConsent;
        }
        if (p1ContactChanged(contact, "priorityConsentInquiryDetails")
          && (draft.priorityConsent === "cannot_locate" || String(contact.priorityConsent) === "cannot_locate")) {
          update.priorityConsentInquiryDetails = draft.priorityConsentInquiryDetails.trim();
        }
        if (Object.keys(update).length > 2) actions.contacts.push(update);
      }
    }
    if (p5GapIds.has("p5_intestate_successors")) {
      if (p5SuccessorDraft.contactId) {
        actions.contacts.push({ mode: "designateIntestateSuccessor", id: p5SuccessorDraft.contactId, role: "intestate_successor", recipientType: "intestate_successor" });
      } else if (p5SuccessorDraft.name.trim()) {
        actions.contacts.push({ mode: "createIntestateSuccessor", name: p5SuccessorDraft.name.trim(), residentialAddress: p5SuccessorDraft.residentialAddress.trim() });
      }
    }
    const ancillaryPrefix = isP6Only ? "p6" : "p7";
    const ancillaryGapIds = isP6Only ? p6GapIds : p7GapIds;
    const ancillaryContactGap = ancillaryGapIds.has(`${ancillaryPrefix}_individual_applicant_residence`)
      || ancillaryGapIds.has(`${ancillaryPrefix}_organization_signatory`)
      || ancillaryGapIds.has(`${ancillaryPrefix}_deponent_name`)
      || ancillaryGapIds.has(`${ancillaryPrefix}_deponent_address`)
      || ancillaryGapIds.has(`${ancillaryPrefix}_deponent_occupation`);
    if ((isP6Only || isP7Only) && ancillaryContactGap) {
      const primaryId = String(p5PrimaryApplicant?.id ?? "");
      for (const contact of p1ApplyingContacts) {
        const id = String(contact.id ?? "");
        const draft = p1ContactDrafts[id];
        if (!id || !draft) continue;
        const update: P1InlineActions["contacts"][number] = { mode: "update", id };
        const isOrganization = String(contact.applicantKind ?? "individual") === "organization";
        if (ancillaryGapIds.has(`${ancillaryPrefix}_individual_applicant_residence`) && !isOrganization) {
          if (p1ContactChanged(contact, "residentialAddress")) {
            update.residentialAddress = draft.residentialAddress.trim();
            update.residenceStreet = draft.residentialAddress.trim();
          }
          if (p1ContactChanged(contact, "residenceCity")) update.residenceCity = draft.residenceCity.trim();
          if (p1ContactChanged(contact, "residenceProvince")) update.residenceProvince = draft.residenceProvince.trim();
          if (p1ContactChanged(contact, "residencePostalCode")) update.residencePostalCode = draft.residencePostalCode.trim();
          if (p1ContactChanged(contact, "residenceCountry")) update.residenceCountry = draft.residenceCountry.trim();
        }
        if (ancillaryGapIds.has(`${ancillaryPrefix}_organization_signatory`) && isOrganization) {
          if (p1ContactChanged(contact, "orgSignatoryName")) update.orgSignatoryName = draft.orgSignatoryName.trim();
          if (isP6Only && p1ContactChanged(contact, "orgSignatoryTitle")) update.orgSignatoryTitle = draft.orgSignatoryTitle.trim();
        }
        if (id === primaryId) {
          if (ancillaryGapIds.has(`${ancillaryPrefix}_deponent_name`) && p1ContactChanged(contact, "name")) update.name = draft.name.trim();
          if (ancillaryGapIds.has(`${ancillaryPrefix}_deponent_address`) && p1ContactChanged(contact, "residentialAddress")) update.residentialAddress = draft.residentialAddress.trim();
          if (ancillaryGapIds.has(`${ancillaryPrefix}_deponent_occupation`) && p1ContactChanged(contact, "occupation")) update.occupation = draft.occupation.trim();
        }
        if (Object.keys(update).length > 2) actions.contacts.push(update);
      }
    }
    const p8DeponentGap = p8GapIds.has("p8_deponent_name")
      || p8GapIds.has("p8_deponent_address")
      || p8GapIds.has("p8_deponent_occupation");
    if (p8DeponentGap) {
      for (const contact of p8CoApplicantContacts) {
        const id = String(contact.id ?? "");
        const draft = p1ContactDrafts[id];
        if (!id || !draft) continue;
        const update: P1InlineActions["contacts"][number] = { mode: "update", id };
        const isOrganization = String(contact.applicantKind ?? "individual") === "organization";
        if (p8GapIds.has("p8_deponent_name")) {
          if (isOrganization && p1ContactChanged(contact, "orgSignatoryName")) update.orgSignatoryName = draft.orgSignatoryName.trim();
          if (!isOrganization && p1ContactChanged(contact, "name")) update.name = draft.name.trim();
        }
        if (p8GapIds.has("p8_deponent_address") && p1ContactChanged(contact, "residentialAddress")) update.residentialAddress = draft.residentialAddress.trim();
        if (p8GapIds.has("p8_deponent_occupation")) {
          if (isOrganization && p1ContactChanged(contact, "orgSignatoryTitle")) update.orgSignatoryTitle = draft.orgSignatoryTitle.trim();
          if (!isOrganization && p1ContactChanged(contact, "occupation")) update.occupation = draft.occupation.trim();
        }
        if (Object.keys(update).length > 2) actions.contacts.push(update);
      }
    }
    const p10DeponentGap = p10GapIds.has("p10_deponent_name")
      || p10GapIds.has("p10_deponent_address")
      || p10GapIds.has("p10_deponent_occupation");
    if (p10DeponentGap && p10Deponent) {
      const id = String(p10Deponent.id ?? "");
      const draft = p1ContactDrafts[id];
      if (id && draft) {
        const update: P1InlineActions["contacts"][number] = { mode: "update", id };
        if (p10GapIds.has("p10_deponent_name") && p1ContactChanged(p10Deponent, "name")) update.name = draft.name.trim();
        if (p10GapIds.has("p10_deponent_address") && p1ContactChanged(p10Deponent, "residentialAddress")) update.residentialAddress = draft.residentialAddress.trim();
        if (p10GapIds.has("p10_deponent_occupation") && p1ContactChanged(p10Deponent, "occupation")) update.occupation = draft.occupation.trim();
        if (Object.keys(update).length > 2) actions.contacts.push(update);
      }
    }
    const p11DeponentGap = p11GapIds.has("p11_applicant_contact")
      || p11GapIds.has("p11_applicant_address")
      || p11GapIds.has("p11_applicant_occupation")
      || p11GapIds.has("p11_org_signatory_name")
      || p11GapIds.has("p11_org_signatory_title");
    if (p11DeponentGap && p10Deponent) {
      const id = String(p10Deponent.id ?? "");
      const draft = p1ContactDrafts[id];
      if (id && draft) {
        const update: P1InlineActions["contacts"][number] = { mode: "update", id };
        if (p11GapIds.has("p11_applicant_contact") && p1ContactChanged(p10Deponent, "name")) update.name = draft.name.trim();
        if (p11GapIds.has("p11_applicant_address") && p1ContactChanged(p10Deponent, "residentialAddress")) update.residentialAddress = draft.residentialAddress.trim();
        if (p11GapIds.has("p11_applicant_occupation") && p1ContactChanged(p10Deponent, "occupation")) update.occupation = draft.occupation.trim();
        if (p11GapIds.has("p11_org_signatory_name") && p1ContactChanged(p10Deponent, "orgSignatoryName")) update.orgSignatoryName = draft.orgSignatoryName.trim();
        if (p11GapIds.has("p11_org_signatory_title") && p1ContactChanged(p10Deponent, "orgSignatoryTitle")) update.orgSignatoryTitle = draft.orgSignatoryTitle.trim();
        if (Object.keys(update).length > 2) actions.contacts.push(update);
      }
    }
    for (const [kind, files] of Object.entries(p1Uploads) as Array<["will" | "foreignGrant" | "codicil", File[]]>) {
      for (const file of files) actions.uploads.push({ kind, file });
    }
    return actions.contacts.length > 0 || actions.uploads.length > 0 || Object.keys(actions.estate).length > 0 ? actions : undefined;
  }

  // Only changed values ride Apply. P16 also permits clearing a recorded
  // alteration field; an untouched blank never becomes an override or a save.
  const changedValues = useMemo(() => {
    const out: Record<string, string | number> = {};
    for (const [column, value] of Object.entries(draft)) {
      if (value === seed[column] || (value === "" && !(showP16AlterationEditor && p16AlterationColumn(column)))) continue;
      const control = INLINE_FIELD_CONTROLS[column as keyof typeof INLINE_FIELD_CONTROLS];
      out[column] = control?.control === "number" ? Number(value) : value;
    }
    for (const key of P8_PRIMARY_AFFIDAVIT_KEYS) {
      if (p8PrimaryDraft[key] !== p8PrimarySeed[key]) out[key] = p8PrimaryDraft[key] ?? "";
    }
    return out;
  }, [draft, seed, showP16AlterationEditor, p8PrimaryDraft, p8PrimarySeed]);
  const checkedDocKeys = useMemo(
    () => Object.entries(docDraft).filter(([, on]) => on).map(([key]) => key),
    [docDraft],
  );

  // Every row-editor descriptor on the current reports, keyed by draft key —
  // the apply payload needs each draft's control kind (currency → cents) and
  // the inventory category rider.
  const rowEditorIndex = useMemo(() => {
    const index = new Map<string, GapEditor>();
    for (const { gap } of allGaps) {
      for (const editor of gap.editors ?? []) {
        if (editor.kind === "inventoryAdd" || !editor.id || !editor.column) continue;
        const key = rowEditorKey(editor);
        if (!index.has(key)) index.set(key, editor);
      }
    }
    return index;
    // allGaps is rebuilt each render from `reports`.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reports]);

  // Only values the user actually typed (non-blank, different from what a
  // confirmed Apply already sent) ride the row-edit payload.
  const changedRowValues = useMemo(() => {
    const out: Record<string, string> = {};
    for (const [key, value] of Object.entries(rowDraft)) {
      if (value === "" || value === (rowSeed[key] ?? "")) continue;
      if (!rowEditorIndex.has(key)) continue; // descriptor gone after a re-check
      out[key] = value;
    }
    return out;
  }, [rowDraft, rowSeed, rowEditorIndex]);

  // The quick-add mini form counts as a change only once it names a real row:
  // category + description are the minimum honest CREATE (value and passage
  // may stay blank — the re-check then reports what is still missing).
  const anyQuickAddOffered = canEditInline
    && allGaps.some(({ gap }) => (gap.editors ?? []).some((editor) => editor.kind === "inventoryAdd"));
  const quickAddReady = anyQuickAddOffered
    && String(addDraft.category || "").trim() !== ""
    && String(addDraft.description || "").trim() !== "";

  const p1Actions = buildP1Actions();
  const hasP1Actions = p1Actions !== undefined;
  // One canonical control per column; existing specialized editors retain
  // ownership. Only the single-form pending path can collect these answers.
  const canonicalColumnsByGap = new Map<string, string[]>();
  const canonicalOwner = new Map<string, string>();
  if (canEditInline && reports.length === 1) {
    if (isP2Only && displayedGaps.some(({ gap }) => gap.requirementId === "p2_order_filed_status")) {
      canonicalOwner.set("orderFiled", "P2:p2_order_filed_status");
    }
    for (const { formCode, gap } of displayedGaps) {
      if (renderP1GapEditor(gap.requirementId) !== null) continue;
      const columns = retainedCanonicalByKey.get(`${formCode}:${gap.requirementId}`)?.columns ?? canonicalFieldsForGap(formCode, gap);
      if (!columns.length) continue;
      const key = `${formCode}:${gap.requirementId}`;
      canonicalColumnsByGap.set(key, columns);
      for (const column of columns) if (!canonicalOwner.has(column)) canonicalOwner.set(column, key);
    }
  }
  // Only an acknowledged CAS snapshot may outrank lagging props. A genuinely
  // newer estate revision always wins; the opening seed is not a saved record.
  const incomingRevision = typeof estate?.revision === "number" ? estate.revision : undefined;
  const useCommitted = canonicalCommitted !== null
    && canonicalCommitted.estateId === String(estate?.id ?? "")
    && (canonicalCommitted.revision === undefined
      ? estate === canonicalCommitted.observedEstate
      : incomingRevision === undefined || incomingRevision <= canonicalCommitted.revision);
  const canonicalDurableRecord = {
    ...canonicalSeed, ...(estate ?? {}), ...(useCommitted ? canonicalCommitted.record : {}),
  };
  const canonicalPendingOverrides = { ...renderOverrides };
  for (const key of Array.from(canonicalSavedKeys)) delete canonicalPendingOverrides[key];
  const canonicalComparisonRecord = { ...canonicalDurableRecord, ...canonicalPendingOverrides };
  const canonicalUpstreamPatch = { ...changedValues, ...(p1Actions?.estate ?? {}) };
  const canonicalBaseRecord = { ...canonicalComparisonRecord, ...canonicalUpstreamPatch };
  // The unchanged shared helper returns its input for an unchanged or ambiguous
  // filing type. Only an actually changed original filing choice derives a medium.
  const coupledFiling = coupleWillFilingTypeFacts(canonicalUpstreamPatch, canonicalDurableRecord);
  const currentFilingMedium = coupledFiling === canonicalUpstreamPatch ? undefined : {
    willType: String(coupledFiling.willType), isElectronicWill: Number(coupledFiling.isElectronicWill),
  };
  // A refreshed row after response loss does not turn an unchanged, explicit
  // original-filing intent back into the raw medium it previously superseded.
  // A newer filing or medium input invalidates this snapshot, never a CAS rule.
  const keepFilingIntent = canonicalFilingIntent !== null
    && canonicalFilingIntent.cycle === canonicalCycleRef.current
    && canonicalFilingIntent.filing === changedValues.willFilingType
    && canonicalFilingIntent.filingVersion === filingInputVersionRef.current
    && canonicalFilingIntent.mediumVersion === (canonicalInputVersionsRef.current.willType ?? 0);
  const canonicalFilingMedium = keepFilingIntent ? canonicalFilingIntent.medium : currentFilingMedium;
  const canonicalOffered = new Set(canonicalOwner.keys());
  const canonicalClearsAppearance = canonicalAppearanceRemovalPending
    || canonicalAppearanceRemoval(canonicalDraft, canonicalComparisonRecord, canonicalOffered);
  const canonicalRecord = canonicalPopupRecord(canonicalBaseRecord, canonicalDraft, canonicalOffered, canonicalFilingMedium);
  latestCanonicalRecordRef.current = canonicalRecord;
  const changedCanonicalValues = canonicalPopupPatch(canonicalDraft, canonicalComparisonRecord, canonicalOffered, canonicalBaseRecord, canonicalUncertainKeys, canonicalFilingMedium, canonicalClearsAppearance);
  const anyCanonicalEditors = canonicalColumnsByGap.size > 0;
  const hasChanges = Object.keys(changedValues).length > 0 || checkedDocKeys.length > 0
    || Object.keys(changedRowValues).length > 0 || quickAddReady || hasP1Actions
    || Object.keys(changedCanonicalValues).length > 0 || canonicalNeedsRecheck;

  // Estate-column/doc editors ride the overrides + optional-persist pipeline;
  // row editors always persist. The save-to-intake checkbox governs ONLY the
  // former, so it renders only when at least one former-kind editor shows.
  const anyEstateEditors = showP16AlterationEditor || (canEditInline && displayedGaps.some(({ gap }) =>
    estateAccessorsFor(gap).some((accessor) =>
      inlineEditableColumn(accessor) !== null || inlineEditableDocKey(accessor) !== null)));
  const anyRowEditors = canEditInline && displayedGaps.some(({ gap }) => (gap.editors ?? []).length > 0);
  // True when at least one rendered gap offers an inline editor.
  const anyP1Editors = isCanonicalCompletionForm && displayedGaps.some(({ gap }) => renderP1GapEditor(gap.requirementId) !== null);
  const anyP8PrimaryEditors = canEditInline && displayedGaps.some(({ formCode, gap }) => formCode === "P8" && gap.requirementId === "p8_primary_affidavit_history");
  const anyEditors = anyEstateEditors || anyRowEditors || anyP1Editors || anyP8PrimaryEditors || anyCanonicalEditors;
  // P45's lock status selects one of two mutually exclusive sworn statements.
  // Unlike an ordinary blank line, it cannot safely be sent on a "Generate
  // anyway" path: the renderer would have to invent one of the alternatives.
  // Keep the correction in the visible inline editor, but do not dispatch a
  // request that can only fail after the dialog closes.
  const p45LockStatusRequired = isP45Only
    && p45GapIds.has("p45_electronic_will_locked")
    && !String(draft.electronicWillLocked ?? seed.electronicWillLocked ?? "").trim();
  // The hard-block description promises "fill … to clear the block" only when
  // a HARD gap itself is editable — editors on soft siblings can't clear an
  // editor-less hard block (2026-08-21 review).
  const anyHardGapEditors = canEditInline && currentDisplayedGaps.some(({ formCode, gap }) =>
    gap.blocker === "hard"
    && ((gap.editors ?? []).length > 0
      || (canonicalColumnsByGap.get(`${formCode}:${gap.requirementId}`) ?? []).some(column => canonicalFieldActive(column, canonicalRecord))
      || estateAccessorsFor(gap).some((accessor) =>
        inlineEditableColumn(accessor) !== null || inlineEditableDocKey(accessor) !== null)));
  // One quick-add card per dialog: several gaps can carry the inventoryAdd
  // descriptor (they share ONE addDraft and one created row), so only the
  // first qualifying gap renders the form — duplicates would double the DOM
  // ids and visually promise two rows.
  const firstQuickAddGapKey = (() => {
    for (const { formCode, gap } of allGaps) {
      if ((gap.editors ?? []).some((editor) => editor.kind === "inventoryAdd")) {
        return `${formCode}:${gap.requirementId}`;
      }
    }
    return null;
  })();

  /**
   * Bank the applied values into the seed so a second Apply sends only what
   * changed SINCE. Without this, values already persisted keep counting as
   * changes and every subsequent apply rewrites them — redundant intake
   * writes and audit-log noise. Only on a confirmed apply: a failed save must
   * leave the values pending, or the button would go dead on data the user
   * was told had been saved and had not.
   */
  /** Group the changed row drafts into persisted-mutation payloads. */
  function buildRowEdits(): PreGenerateRowEdits | undefined {
    const contacts = new Map<string, Record<string, string>>();
    const inventory = new Map<string, Record<string, string | number>>();
    for (const [key, value] of Object.entries(changedRowValues)) {
      const editor = rowEditorIndex.get(key)!;
      const column = editor.column!;
      if (editor.kind === "contact") {
        const data = contacts.get(editor.id!) ?? {};
        data[column] = value;
        contacts.set(editor.id!, data);
      } else {
        const data = inventory.get(editor.id!) ?? {};
        // Currency controls collect dollars; the columns store cents. No
        // category rider: a preflight-time category snapshot could silently
        // revert a row reclassified in another tab mid-dialog — the server's
        // value mirrors read the STORED category for category-less patches
        // (2026-08-21 review).
        data[column] = editor.control?.control === "currency" ? parseCurrencyToCents(value) : value;
        inventory.set(editor.id!, data);
      }
    }
    const createInventory: Array<Record<string, string | number>> = [];
    if (quickAddReady) {
      const category = String(addDraft.category || "");
      const cents = parseCurrencyToCents(addDraft.value || "0");
      if (quickAddIdRef.current === null) quickAddIdRef.current = crypto.randomUUID();
      createInventory.push({
        id: quickAddIdRef.current,
        category,
        description: String(addDraft.description || "").trim(),
        location: String(addDraft.location || "unknown"),
        value: cents,
        valueRecorded: inventoryValueRecordedFromForm({ category, value: addDraft.value }),
        // Explicit answer or blank — never a defaulted "yes" (no-fab). The
        // category-specific sworn value mirrors (dateOfDeathValue /
        // assessedMarketValue) derive from `value` inside inventory.create.
        passesToPersonalRepresentative: String(addDraft.passesToPersonalRepresentative || ""),
      });
    }
    if (contacts.size === 0 && inventory.size === 0 && createInventory.length === 0) return undefined;
    return {
      contacts: Array.from(contacts.entries(), ([id, data]) => ({ id, data })),
      inventory: Array.from(inventory.entries(), ([id, data]) => ({ id, data })),
      createInventory,
    };
  }

  async function handleApply(): Promise<boolean> {
    // Omit the rowEdits argument entirely when nothing collected — existing
    // callers and tests see the exact pre-wave-2 call shape.
    const rowEdits = buildRowEdits();
    const sentRowValues = changedRowValues;
    // P1 completion facts always write to their canonical file records. Leaving
    // them as one-document overrides would make a passed re-check misleading.
    const sentCanonicalValues = changedCanonicalValues;
    const sentCanonicalDraft = canonicalDraft;
    const sentInputVersions = { ...canonicalInputVersionsRef.current };
    const sentFilingVersion = filingInputVersionRef.current;
    const sentEffectiveRecord = canonicalRecord;
    const sentCanonicalKeys = Object.keys(sentCanonicalValues);
    // Offered controls can receive newer input even when this first snapshot
    // contains only a generic filing choice and no separate canonical patch.
    const canonicalAttempt = sentCanonicalKeys.length > 0 || canonicalNeedsRecheck || canonicalOffered.size > 0;
    const cycle = canonicalCycleRef.current;
    if (canonicalFilingMedium && canonicalOffered.has("willType") && typeof changedValues.willFilingType === "string") {
      setCanonicalFilingIntent({ cycle, filing: changedValues.willFilingType, filingVersion: sentFilingVersion,
        mediumVersion: sentInputVersions.willType ?? 0, medium: canonicalFilingMedium });
    }
    let acknowledged = false;
    let rechecked = false;
    const newerCanonicalRows = (): PendingCanonicalGap[] => {
      if (canonicalCycleRef.current !== cycle) return [];
      const latest = latestCouplingChoicesRef.current;
      const newerColumns = new Set(Array.from(canonicalOffered).filter(column => {
        if (typeof latest.canonical[column] !== "string"
          || (canonicalInputVersionsRef.current[column] ?? 0) === (sentInputVersions[column] ?? 0)) return false;
        const effective = column === "willType" ? String(latestCanonicalRecordRef.current.willType ?? "") : latest.canonical[column];
        return !canonicalDraftMatchesRecord(column, effective, sentEffectiveRecord);
      }));
      // A newer filing choice can restore a medium explicitly entered before
      // the old original filing choice temporarily derived a different one.
      const newerFiling = canonicalOffered.has("willType") && typeof latest.filing === "string"
        && filingInputVersionRef.current !== sentFilingVersion && latest.filing !== draft.willFilingType;
      if (newerFiling && typeof latest.canonical.willType === "string") newerColumns.add("willType");
      return displayedGaps.flatMap(({ formCode, gap }) => {
        const key = `${formCode}:${gap.requirementId}`;
        const columns = (canonicalColumnsByGap.get(key) ?? []).filter(column =>
          newerColumns.has(column) && canonicalOwner.get(column) === key);
        const filingOwner = newerFiling && estateAccessorsFor(gap).some(accessor => inlineEditableColumn(accessor) === "willFilingType");
        return columns.length || filingOwner ? [{ estateId: String(estate?.id ?? ""), formCode, gap, columns }] : [];
      });
    };
    const canonicalObserver: CanonicalPopupApplyObserver = {
      onSaved: receipt => {
        if (canonicalCycleRef.current !== cycle || receipt.estateId !== String(estate?.id ?? "")) return;
        acknowledged = true;
        const acknowledgedChoices = latestCouplingChoicesRef.current;
        const acknowledgedInputVersions = { ...canonicalInputVersionsRef.current };
        const acknowledgedFilingVersion = filingInputVersionRef.current;
        const acknowledgedVisibleRecord = latestCanonicalRecordRef.current;
        setCanonicalFilingIntent(current => current && current.filing === receipt.record.willFilingType
          && current.medium.willType === receipt.record.willType
          && current.medium.isElectronicWill === receipt.record.isElectronicWill ? null : current);
        setCanonicalCommitted({ ...receipt, observedEstate: estate });
        setCanonicalSavedKeys(current => new Set([...Array.from(current), ...sentCanonicalKeys]));
        setCanonicalUncertainKeys(new Set());
        setCanonicalNeedsRecheck(true);
        // The upstream filing choice is part of this acknowledged mixed write,
        // not a fresh change on a recheck-only retry. Preserve any newer draft.
        if (Object.prototype.hasOwnProperty.call(changedValues, "willFilingType")
          && receipt.record.willFilingType === changedValues.willFilingType) {
          setSeed(current => ({ ...current, willFilingType: String(changedValues.willFilingType) }));
        }
        const appearanceClearAcknowledged = canonicalClearsAppearance
          && Object.prototype.hasOwnProperty.call(sentCanonicalValues, "willAlterationTypes")
          && Array.from(CANONICAL_APPEARANCE_DETAILS).every(key => sentCanonicalValues[key] === ""
            && receipt.record[key] === "");
        const sameAppearanceIntent = (current: Record<string, string>) =>
          current.willAlterationTypes === sentCanonicalDraft.willAlterationTypes
          && Array.from(CANONICAL_APPEARANCE_DETAILS).every(key => current[key] === sentCanonicalDraft[key]);
        if (appearanceClearAcknowledged && sameAppearanceIntent(latestCouplingChoicesRef.current.canonical)) setCanonicalAppearanceRemovalPending(false);
        // Bank only this exact acknowledged intent. A newer branch or child
        // choice is not part of the old save, even if the child text is equal.
        setCanonicalDraft(current => {
          const next = { ...current };
          for (const key of sentCanonicalKeys) {
            if (appearanceClearAcknowledged && !sameAppearanceIntent(current)
              && (key === "willAlterationTypes" || CANONICAL_APPEARANCE_DETAILS.has(key))) continue;
            const clearedAppearanceChild = appearanceClearAcknowledged && CANONICAL_APPEARANCE_DETAILS.has(key);
            const exactSubmittedInput = current[key] === sentCanonicalDraft[key]
              && (canonicalInputVersionsRef.current[key] ?? 0) === (sentInputVersions[key] ?? 0);
            // A filing choice may have cycled away and back before this ack.
            // Bank its actually displayed, acknowledged medium, but never a
            // newer input that arrived after the acknowledgement was observed.
            const acknowledgedCoupledInput = key === "willType" && canonicalFilingMedium !== undefined
              && acknowledgedChoices.filing === draft.willFilingType
              && current[key] === acknowledgedChoices.canonical[key]
              && (canonicalInputVersionsRef.current[key] ?? 0) === (acknowledgedInputVersions[key] ?? 0)
              && filingInputVersionRef.current === acknowledgedFilingVersion
              && canonicalDraftMatchesRecord(key, String(acknowledgedVisibleRecord.willType ?? ""), receipt.record);
            if ((canonicalOffered.has(key) || clearedAppearanceChild) && typeof current[key] === "string"
              && ((exactSubmittedInput && (canonicalDraftMatchesRecord(key, sentCanonicalDraft[key], receipt.record) || clearedAppearanceChild))
                || acknowledgedCoupledInput)) delete next[key];
          }
          return next;
        });
      },
      onRechecked: () => {
        if (canonicalCycleRef.current !== cycle) return;
        rechecked = true;
        setCanonicalNeedsRecheck(false);
        setCanonicalUncertainKeys(new Set());
        setPendingCanonicalGaps(newerCanonicalRows());
      },
      hasNewerEdits: () => newerCanonicalRows().length > 0,
    };
    const applied = canonicalAttempt
      ? await onApplyInline!(changedValues, isCanonicalCompletionForm ? true : saveToIntake, checkedDocKeys, rowEdits, p1Actions, sentCanonicalValues, canonicalObserver)
      : p1Actions !== undefined
      ? await onApplyInline!(changedValues, true, checkedDocKeys, rowEdits, p1Actions)
      : rowEdits === undefined
        ? await onApplyInline!(changedValues, isCanonicalCompletionForm ? true : saveToIntake, checkedDocKeys)
        : await onApplyInline!(changedValues, isCanonicalCompletionForm ? true : saveToIntake, checkedDocKeys, rowEdits);
    if (canonicalCycleRef.current !== cycle) return false;
    if (applied !== false) {
      // Compatibility for existing callback-only component consumers. The real
      // parent acknowledges at the write boundary with the returned revision.
      if (sentCanonicalKeys.length > 0 && !acknowledged) canonicalObserver.onSaved({
        estateId: String(estate?.id ?? ""), revision: incomingRevision,
        record: { ...canonicalDurableRecord, ...sentCanonicalValues },
      });
      setCanonicalNeedsRecheck(false);
      setCanonicalUncertainKeys(new Set());
      setSeed((current) => ({ ...current, ...draft }));
      setDocDraft({});
      // Bank ONLY what this apply actually sent — a draft whose descriptor
      // vanished mid-edit was dropped from the payload (changedRowValues
      // filters on rowEditorIndex), and banking it would mark the displayed
      // value as already-saved: a reappearing descriptor would then never
      // resend it.
      setRowSeed((current) => ({ ...current, ...sentRowValues }));
      setAddDraft({});
      quickAddIdRef.current = null;
    } else if (canonicalAttempt && !rechecked) {
      setCanonicalNeedsRecheck(true);
      // No acknowledgement is not proof of rollback. Re-submit an explicit
      // correction even when it equals the opening value, rather than silently
      // generating from a possibly committed different answer.
      if (!acknowledged && sentCanonicalKeys.length > 0) setCanonicalUncertainKeys(new Set(sentCanonicalKeys));
    }
    const newerRows = newerCanonicalRows();
    setPendingCanonicalGaps(newerRows);
    // Apply succeeded for its submitted snapshot, but a proceed-driven Apply
    // must not immediately generate while newer explicit input is still pending.
    return applied !== false && newerRows.length === 0;
  }

  // Nick 2026-09-02 (third estate-#18 live audit): "Generate anyway" used to read
  // nothing the user had typed — the inline draft lived only in this component
  // and only "Apply & re-check" sent it, so a treaty/orders answer (or any other
  // inline value) chosen right before the default-styled proceed button was
  // silently discarded and the document rendered from the untouched record.
  // Proceeding now applies unsaved inline changes first (the same persist +
  // re-check path), then continues; a failed save keeps the dialog open with
  // the typed values intact, exactly as an explicit Apply would.
  async function handleProceed(): Promise<void> {
    if (hasChanges && typeof onApplyInline === "function") {
      const applied = await handleApply();
      if (!applied) return;
    }
    onProceed(requiresDraftOptIn || !isReady ? { generateAnyway: true } : undefined);
  }

  function renderDocEditor(docKey: string): React.JSX.Element {
    const doc = REQUIRED_DOCUMENTS.find((d) => d.key === docKey);
    const controlId = `pre-generate-doc-${docKey}`;
    return (
      <div key={`doc:${docKey}`} className="flex items-start gap-2.5 rounded-lg border border-border/70 bg-background/70 p-2.5 shadow-sm" data-testid={`pre-generate-doc-editor-${docKey}`}>
        <Checkbox
          id={controlId}
          className="mt-0.5 shrink-0"
          checked={docDraft[docKey] === true}
          onCheckedChange={(checked) => setDocDraft((d) => ({ ...d, [docKey]: checked === true }))}
          data-testid={controlId}
        />
        <Label htmlFor={controlId} className="cursor-pointer text-xs font-medium leading-relaxed">
          Mark received — {doc?.name ?? docKey}
        </Label>
      </div>
    );
  }

  function renderWesaFollowUpEditors(): React.JSX.Element | null {
    if (draft.spouseStatus !== "separated") return null;
    const reconciliationApplies = draft.reconciliationPrimaryPurpose === "yes";
    return (
      <div
        className="mt-2 space-y-2 rounded-md border border-amber-200/80 bg-amber-50/50 p-2.5 motion-safe:animate-in motion-safe:fade-in motion-safe:slide-in-from-top-1 motion-safe:duration-200 motion-safe:ease-[cubic-bezier(0.23,1,0.32,1)] dark:border-amber-900/60 dark:bg-amber-950/15"
        role="region"
        aria-label="WESA separation details"
        data-testid="pre-generate-wesa-separation-follow-up"
      >
        <p className="text-[10px] font-medium text-amber-900 dark:text-amber-100">Separation and reconciliation details</p>
        {renderEditor("separationDate", INLINE_FIELD_CONTROLS.separationDate!)}
        {renderEditor("reconciliationPrimaryPurpose", INLINE_FIELD_CONTROLS.reconciliationPrimaryPurpose!)}
        {reconciliationApplies && (
          <div
            className="space-y-2 motion-safe:animate-in motion-safe:fade-in motion-safe:slide-in-from-top-1 motion-safe:duration-200 motion-safe:ease-[cubic-bezier(0.23,1,0.32,1)]"
            data-testid="pre-generate-wesa-reconciliation-follow-up"
          >
            {renderEditor("reconciliationResumeDate", INLINE_FIELD_CONTROLS.reconciliationResumeDate!)}
            {renderEditor("reconciliationDurationDays", INLINE_FIELD_CONTROLS.reconciliationDurationDays!)}
          </div>
        )}
        <p className="text-[10px] leading-tight text-muted-foreground">WESA s.2(2.1) recognizes a reconciliation exception only where it began within one year of separation, its primary purpose was reconciliation, and cohabitation totalled at least 90 days.</p>
      </div>
    );
  }

  function renderEditor(column: string, control: InlineFieldControl): React.JSX.Element {
    const value = draft[column] ?? "";
    const setValue = (next: string): void => {
      if (column === "willFilingType") {
        filingInputVersionRef.current += 1;
        const choice: Record<string, unknown> = { willFilingType: next };
        const coupled = coupleWillFilingTypeFacts(choice, canonicalDurableRecord);
        setCanonicalFilingIntent(coupled !== choice && canonicalOffered.has("willType") ? {
          cycle: canonicalCycleRef.current, filing: next, filingVersion: filingInputVersionRef.current,
          mediumVersion: canonicalInputVersionsRef.current.willType ?? 0,
          medium: { willType: String(coupled.willType), isElectronicWill: Number(coupled.isElectronicWill) },
        } : null);
      }
      setDraft((d) => ({ ...d, [column]: next }));
    };
    const controlId = `pre-generate-input-${column}`;
    return (
      <div key={column} className="space-y-1.5" data-testid={`pre-generate-editor-${column}`}>
        <Label htmlFor={controlId} className="text-xs font-medium leading-tight text-foreground">{control.label}</Label>
        {control.control === "select" ? (
          <Select value={value} onValueChange={setValue}>
            <SelectTrigger id={controlId} className="h-10 bg-background text-sm shadow-sm transition-colors hover:border-primary/40 focus-visible:ring-primary/35" data-testid={controlId}>
              <SelectValue placeholder="Select…" />
            </SelectTrigger>
            <SelectContent>
              {(control.options ?? []).map((opt) => (
                <SelectItem key={opt.value} value={opt.value} className="text-xs">{opt.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        ) : control.control === "textarea" ? (
          <Textarea id={controlId} value={value} onChange={(e) => setValue(e.target.value)} rows={2} className="resize-y bg-background text-sm shadow-sm transition-colors hover:border-primary/40 focus-visible:ring-primary/35" data-testid={controlId} />
        ) : (
          <Input
            id={controlId}
            type={control.control === "date" ? "date" : control.control === "number" ? "number" : "text"}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            maxLength={column === "p16AlterationWords" ? P16_ALTERATION_WORDS_MAX_LENGTH : undefined}
            className="h-10 bg-background text-sm shadow-sm transition-colors hover:border-primary/40 focus-visible:ring-primary/35"
            data-testid={controlId}
          />
        )}
        {control.help && <p className="text-[11px] leading-relaxed text-muted-foreground">{control.help}</p>}
      </div>
    );
  }

  /** One persisted row editor (contact/inventory descriptor). */
  function renderRowEditor(editor: GapEditor): React.JSX.Element {
    const key = rowEditorKey(editor);
    const control = editor.control!;
    const value = rowDraft[key] ?? "";
    const setValue = (next: string): void => setRowDraft((d) => ({ ...d, [key]: next }));
    const controlId = `pre-generate-row-input-${editor.kind}-${editor.id}-${editor.column}`;
    return (
      <div key={key} className="space-y-1.5" data-testid={`pre-generate-row-editor-${editor.kind}-${editor.id}-${editor.column}`}>
        <Label htmlFor={controlId} className="text-xs font-medium leading-tight text-foreground">{control.label}</Label>
        {control.control === "select" ? (
          <Select value={value} onValueChange={setValue}>
            <SelectTrigger id={controlId} className="h-10 bg-background text-sm shadow-sm transition-colors hover:border-primary/40 focus-visible:ring-primary/35" data-testid={controlId}>
              <SelectValue placeholder="Select…" />
            </SelectTrigger>
            <SelectContent>
              {(control.options ?? []).map((opt) => (
                <SelectItem key={opt.value} value={opt.value} className="text-xs">{opt.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        ) : control.control === "textarea" ? (
          <Textarea id={controlId} value={value} onChange={(e) => setValue(e.target.value)} rows={2} className="resize-y bg-background text-sm shadow-sm transition-colors hover:border-primary/40 focus-visible:ring-primary/35" data-testid={controlId} />
        ) : control.control === "currency" ? (
          // Keystroke-sanitize with the Inventory tab's own idiom: "$1,234.56"
          // stays "1,234.56" and garbage collapses to "" (an honest blank) —
          // raw "$500" would reach parseCurrencyToCents as NaN → 0 cents and
          // record a fabricated sworn $0.00 (2026-08-21 review, CRITICAL).
          <Input id={controlId} type="text" inputMode="decimal" placeholder="0.00" value={value} onChange={(e) => setValue(formatCurrency(e.target.value))} className="h-10 bg-background text-sm shadow-sm transition-colors hover:border-primary/40 focus-visible:ring-primary/35" data-testid={controlId} />
        ) : (
          <Input
            id={controlId}
            type={control.control === "date" ? "date" : control.control === "number" ? "number" : "text"}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            className="h-10 bg-background text-sm shadow-sm transition-colors hover:border-primary/40 focus-visible:ring-primary/35"
            data-testid={controlId}
          />
        )}
        {control.help && <p className="text-[11px] leading-relaxed text-muted-foreground">{control.help}</p>}
      </div>
    );
  }

  /** The quick-add mini form ("Add first asset") — a real inventory.create on Apply. */
  function renderQuickAdd(): React.JSX.Element {
    const setField = (field: string) => (next: string): void => setAddDraft((d) => ({ ...d, [field]: next }));
    const locationControl = INVENTORY_INLINE_FIELD_CONTROLS.location!;
    const passageControl = INVENTORY_INLINE_FIELD_CONTROLS.passesToPersonalRepresentative!;
    return (
      <div key="inventoryAdd" className="space-y-3 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm" data-testid="pre-generate-inventory-add">
        <div className="flex items-center gap-2">
          <FileCheck2 className="h-4 w-4 text-primary" aria-hidden="true" />
          <p className="text-sm font-semibold">Add first asset</p>
        </div>
        {QUICK_ADD_FIELDS.map((field) => {
          const controlId = `pre-generate-add-${field}`;
          const value = addDraft[field] ?? "";
          if (field === "category" || field === "location" || field === "passesToPersonalRepresentative") {
            const meta = field === "category"
              ? { label: "Category", options: INVENTORY_QUICK_ADD_CATEGORY_OPTIONS }
              : field === "location"
                ? { label: locationControl.label, options: locationControl.options ?? [] }
                : { label: passageControl.label, options: passageControl.options ?? [] };
            return (
              <div key={field} className="space-y-1.5">
                <Label htmlFor={controlId} className="text-xs font-medium">{meta.label}</Label>
                <Select value={value} onValueChange={setField(field)}>
                  <SelectTrigger id={controlId} className="h-10 bg-background text-sm shadow-sm transition-colors hover:border-primary/40 focus-visible:ring-primary/35" data-testid={controlId}>
                    <SelectValue placeholder="Select…" />
                  </SelectTrigger>
                  <SelectContent>
                    {meta.options.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value} className="text-xs">{opt.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            );
          }
          const label = field === "description" ? "Description" : "Value (dollars)";
          return (
            <div key={field} className="space-y-1.5">
              <Label htmlFor={controlId} className="text-xs font-medium">{label}</Label>
              <Input
                id={controlId}
                type="text"
                inputMode={field === "value" ? "decimal" : undefined}
                placeholder={field === "value" ? "0.00" : undefined}
                value={value}
                // Same keystroke sanitation as the row currency editor above.
                onChange={(e) => setField(field)(field === "value" ? formatCurrency(e.target.value) : e.target.value)}
                className="h-10 bg-background text-sm shadow-sm transition-colors hover:border-primary/40 focus-visible:ring-primary/35"
                data-testid={controlId}
              />
            </div>
          );
        })}
        <p className="text-[11px] leading-relaxed text-muted-foreground">
          Creates a real inventory row when you apply. Category and description are required; anything left blank stays honestly unrecorded.
        </p>
      </div>
    );
  }

  function renderP1ContactFields(
    title: string,
    value: ContactDraft,
    onChange: (patch: Partial<ContactDraft>) => void,
    testId: string,
  ): React.JSX.Element {
    return (
      <div className="space-y-3 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm" data-testid={testId}>
        <p className="text-[11px] font-medium">{title}</p>
        <div className="space-y-1">
          <Label className="text-xs">Name</Label>
          <Input value={value.name} onChange={(event) => onChange({ name: event.target.value })} className="h-9 text-xs" />
        </div>
        <div className="space-y-1">
          <Label className="text-xs">Residential address</Label>
          <Textarea value={value.residentialAddress} onChange={(event) => onChange({ residentialAddress: event.target.value })} rows={2} className="text-xs" />
        </div>
        <div className="space-y-1">
          <Label className="text-xs">Occupation (optional)</Label>
          <Input value={value.occupation} onChange={(event) => onChange({ occupation: event.target.value })} className="h-9 text-xs" />
        </div>
        <p className="text-[10px] leading-tight text-muted-foreground">These fields are saved to the estate contact record before the form is re-checked.</p>
      </div>
    );
  }

  function renderP1Upload(
    kind: "will" | "foreignGrant" | "codicil",
    label: string,
    multiple = false,
  ): React.JSX.Element {
    const selected = p1Uploads[kind];
    return (
      <div className="space-y-3 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm" data-testid={`pre-generate-p1-upload-${kind}`}>
        <Label className="text-xs font-medium" htmlFor={`pre-generate-p1-file-${kind}`}>{label}</Label>
        <Input
          id={`pre-generate-p1-file-${kind}`}
          type="file"
          multiple={multiple}
          accept="application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,image/png,image/jpeg,image/tiff"
          className="h-auto cursor-pointer text-xs file:mr-2 file:rounded file:border-0 file:bg-primary/10 file:px-2 file:py-1 file:text-xs file:font-medium file:text-primary"
          onChange={(event) => setP1Uploads((current) => ({ ...current, [kind]: Array.from(event.target.files ?? []) }))}
          data-testid={`pre-generate-p1-file-${kind}`}
        />
        {selected.length > 0 && <p className="text-[10px] text-muted-foreground">Selected: {selected.map((file) => file.name).join(", ")}</p>}
        <p className="text-[10px] leading-tight text-muted-foreground">The file is securely attached to this estate before P1 is re-checked.</p>
      </div>
    );
  }

  function renderP5PrimaryApplicantEditor(): React.JSX.Element | null {
    if (!p5PrimaryApplicant) return null;
    const id = String(p5PrimaryApplicant.id ?? "");
    const draft = p1ContactDrafts[id];
    if (!id || !draft) return null;
    const needsDuration = p5GapIds.has("p5_marriage_like_duration");
    const needsName = p5GapIds.has("p5_deponent_name");
    const needsAddress = p5GapIds.has("p5_deponent_address");
    const needsOccupation = p5GapIds.has("p5_deponent_occupation");
    return (
      <div className="space-y-3 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm" data-testid="pre-generate-p5-primary-applicant">
        <p className="text-[11px] font-medium">Applying deponent: {String(p5PrimaryApplicant.name || "Applicant")}</p>
        {needsDuration && (
          <div className="space-y-1">
            <Label className="text-xs">Marriage-like relationship duration (months)</Label>
            <Input type="number" min="0" value={draft.relationshipDurationMonths} onChange={(event) => setP1ContactDraft(id, { relationshipDurationMonths: event.target.value })} className="h-9 text-xs" data-testid="pre-generate-p5-relationship-duration" />
          </div>
        )}
        {needsName && <div className="space-y-1"><Label className="text-xs">Deponent name</Label><Input value={draft.name} onChange={(event) => setP1ContactDraft(id, { name: event.target.value })} className="h-9 text-xs" data-testid="pre-generate-p5-deponent-name" /></div>}
        {needsAddress && <div className="space-y-1"><Label className="text-xs">Residential address</Label><Textarea value={draft.residentialAddress} onChange={(event) => setP1ContactDraft(id, { residentialAddress: event.target.value })} rows={2} className="text-xs" data-testid="pre-generate-p5-deponent-address" /></div>}
        {needsOccupation && <div className="space-y-1"><Label className="text-xs">Occupation</Label><Input value={draft.occupation} onChange={(event) => setP1ContactDraft(id, { occupation: event.target.value })} className="h-9 text-xs" data-testid="pre-generate-p5-deponent-occupation" /></div>}
        <p className="text-[10px] leading-tight text-muted-foreground">These edits are saved to the applying contact record before P5 is re-checked.</p>
      </div>
    );
  }

  function renderP5PriorRightsEditor(): React.JSX.Element | null {
    if (p5PriorRightContacts.length === 0) return null;
    return (
      <div className="space-y-2" data-testid="pre-generate-p5-prior-rights">
        {p5PriorRightContacts.map((contact) => {
          const id = String(contact.id ?? "");
          const draft = p1ContactDrafts[id];
          if (!id || !draft) return null;
          const showInquiry = draft.priorityConsent === "cannot_locate" || String(contact.priorityConsent) === "cannot_locate";
          return (
            <div key={id} className="space-y-3 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm">
              <p className="text-[11px] font-medium">{String(contact.name || "Prior/equal-right contact")}</p>
              {p5GapIds.has("p5_prior_rights_consent") && (
                <div className="space-y-1">
                  <Label className="text-xs">Consent status</Label>
                  <Select value={draft.priorityConsent || undefined} onValueChange={(priorityConsent) => setP1ContactDraft(id, { priorityConsent })}>
                    <SelectTrigger className="h-9 text-xs" data-testid={`pre-generate-p5-consent-${id}`}><SelectValue placeholder="Select…" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="consented" className="text-xs">Consented</SelectItem>
                      <SelectItem value="renounced" className="text-xs">Renounced</SelectItem>
                      <SelectItem value="cannot_locate" className="text-xs">Cannot be located</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
              {showInquiry && (
                <div className="space-y-1">
                  <Label className="text-xs">Inquiry details</Label>
                  <Textarea value={draft.priorityConsentInquiryDetails} onChange={(event) => setP1ContactDraft(id, { priorityConsentInquiryDetails: event.target.value })} rows={2} className="text-xs" data-testid={`pre-generate-p5-inquiry-${id}`} />
                </div>
              )}
            </div>
          );
        })}
        <p className="text-[10px] leading-tight text-muted-foreground">Consent and inquiry facts are saved only to the relevant contact record before P5 is re-checked.</p>
      </div>
    );
  }

  function renderP5SuccessorEditor(): React.JSX.Element {
    const existingOptions = contacts.filter((contact) => String(contact.id ?? "") && String(contact.id) !== String(p5PrimaryApplicant?.id ?? ""));
    return (
      <div className="space-y-3 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm" data-testid="pre-generate-p5-successor">
        <p className="text-[11px] font-medium">Record an intestate successor</p>
        {existingOptions.length > 0 && (
          <div className="space-y-1">
            <Label className="text-xs">Use an existing contact or add a new one</Label>
            <Select value={p5SuccessorDraft.contactId || "create"} onValueChange={(value) => setP5SuccessorDraft((current) => ({ ...current, contactId: value === "create" ? "" : value }))}>
              <SelectTrigger className="h-9 text-xs" data-testid="pre-generate-p5-successor-select"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="create" className="text-xs">Add a new intestate successor</SelectItem>
                {existingOptions.map((contact) => <SelectItem key={String(contact.id)} value={String(contact.id)} className="text-xs">{String(contact.name || "Unnamed contact")}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        )}
        {!p5SuccessorDraft.contactId && (
          <>
            <div className="space-y-1"><Label className="text-xs">Successor name</Label><Input value={p5SuccessorDraft.name} onChange={(event) => setP5SuccessorDraft((current) => ({ ...current, name: event.target.value }))} className="h-9 text-xs" data-testid="pre-generate-p5-successor-name" /></div>
            <div className="space-y-1"><Label className="text-xs">Residential address (if known)</Label><Textarea value={p5SuccessorDraft.residentialAddress} onChange={(event) => setP5SuccessorDraft((current) => ({ ...current, residentialAddress: event.target.value }))} rows={2} className="text-xs" data-testid="pre-generate-p5-successor-address" /></div>
          </>
        )}
        <p className="text-[10px] leading-tight text-muted-foreground">This creates or designates a canonical Contact; it does not create a document-only recipient.</p>
      </div>
    );
  }

  function renderAncillaryApplicantEditor(formCode: "P6" | "P7", gapIds: Set<string>): React.JSX.Element | null {
    if (p1ApplyingContacts.length === 0) return null;
    const prefix = formCode.toLowerCase();
    const needsResidence = gapIds.has(`${prefix}_individual_applicant_residence`);
    const needsSignatory = gapIds.has(`${prefix}_organization_signatory`);
    const printsSignatoryTitle = formCode === "P6";
    const needsName = gapIds.has(`${prefix}_deponent_name`);
    const needsAddress = gapIds.has(`${prefix}_deponent_address`);
    const needsOccupation = gapIds.has(`${prefix}_deponent_occupation`);
    const primaryId = String(p5PrimaryApplicant?.id ?? "");
    return (
      <div className="space-y-2" data-testid={`pre-generate-${prefix}-applicant-details`}>
        {p1ApplyingContacts.map((contact) => {
          const id = String(contact.id ?? "");
          const draft = p1ContactDrafts[id];
          if (!id || !draft) return null;
          const isOrganization = String(contact.applicantKind ?? "individual") === "organization";
          const isPrimary = id === primaryId;
          return (
            <div key={id} className="space-y-3 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm">
              <p className="text-[11px] font-medium">Applying applicant: {String(contact.name || "Applicant")}</p>
              {needsResidence && !isOrganization && (
                <>
                  <div className="space-y-1"><Label className="text-xs">Residential street address</Label><Textarea value={draft.residentialAddress} onChange={(event) => setP1ContactDraft(id, { residentialAddress: event.target.value })} rows={2} className="text-xs" data-testid={`pre-generate-${prefix}-residence-street-${id}`} /></div>
                  <div className="grid grid-cols-1 gap-2 sm:grid-cols-4">
                    <div className="space-y-1"><Label className="text-xs">City/town</Label><Input value={draft.residenceCity} onChange={(event) => setP1ContactDraft(id, { residenceCity: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-${prefix}-residence-city-${id}`} /></div>
                    <div className="space-y-1"><Label className="text-xs">Province/state</Label><Input value={draft.residenceProvince} onChange={(event) => setP1ContactDraft(id, { residenceProvince: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-${prefix}-residence-province-${id}`} /></div>
                    <div className="space-y-1"><Label className="text-xs">Postal code</Label><Input value={draft.residencePostalCode} onChange={(event) => setP1ContactDraft(id, { residencePostalCode: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-${prefix}-residence-postal-${id}`} /></div>
                    <div className="space-y-1"><Label className="text-xs">Country</Label><Input value={draft.residenceCountry} onChange={(event) => setP1ContactDraft(id, { residenceCountry: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-${prefix}-residence-country-${id}`} /></div>
                  </div>
                </>
              )}
              {needsSignatory && isOrganization && (
                <div className={`grid grid-cols-1 gap-2${printsSignatoryTitle ? " sm:grid-cols-2" : ""}`}>
                  <div className="space-y-1"><Label className="text-xs">Individual signatory name</Label><Input value={draft.orgSignatoryName} onChange={(event) => setP1ContactDraft(id, { orgSignatoryName: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-${prefix}-signatory-name-${id}`} /></div>
                  {printsSignatoryTitle && <div className="space-y-1"><Label className="text-xs">Organizational title</Label><Input value={draft.orgSignatoryTitle} onChange={(event) => setP1ContactDraft(id, { orgSignatoryTitle: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-${prefix}-signatory-title-${id}`} /></div>}
                </div>
              )}
              {isPrimary && needsName && <div className="space-y-1"><Label className="text-xs">Deponent name</Label><Input value={draft.name} onChange={(event) => setP1ContactDraft(id, { name: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-${prefix}-deponent-name-${id}`} /></div>}
              {isPrimary && needsAddress && <div className="space-y-1"><Label className="text-xs">Deponent address</Label><Textarea value={draft.residentialAddress} onChange={(event) => setP1ContactDraft(id, { residentialAddress: event.target.value })} rows={2} className="text-xs" data-testid={`pre-generate-${prefix}-deponent-address-${id}`} /></div>}
              {isPrimary && needsOccupation && <div className="space-y-1"><Label className="text-xs">Occupation</Label><Input value={draft.occupation} onChange={(event) => setP1ContactDraft(id, { occupation: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-${prefix}-deponent-occupation-${id}`} /></div>}
            </div>
          );
        })}
        <p className="text-[10px] leading-tight text-muted-foreground">These edits are saved to the applying contact record before {formCode} is re-checked.</p>
      </div>
    );
  }

  function renderP8CoApplicantEditor(): React.JSX.Element | null {
    if (p8CoApplicantContacts.length === 0) return null;
    const needsName = p8GapIds.has("p8_deponent_name");
    const needsAddress = p8GapIds.has("p8_deponent_address");
    const needsOccupation = p8GapIds.has("p8_deponent_occupation");
    return (
      <div className="space-y-2" data-testid="pre-generate-p8-co-applicants">
        {p8CoApplicantContacts.map((contact) => {
          const id = String(contact.id ?? "");
          const draft = p1ContactDrafts[id];
          if (!id || !draft) return null;
          const isOrganization = String(contact.applicantKind ?? "individual") === "organization";
          return (
            <div key={id} className="space-y-3 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm">
              <p className="text-[11px] font-medium">Co-applicant deponent: {String(contact.name || "Co-applicant")}</p>
              {needsName && !isOrganization && <div className="space-y-1"><Label className="text-xs">Deponent name</Label><Input value={draft.name} onChange={(event) => setP1ContactDraft(id, { name: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-p8-deponent-name-${id}`} /></div>}
              {needsName && isOrganization && <div className="space-y-1"><Label className="text-xs">Signatory name</Label><Input value={draft.orgSignatoryName} onChange={(event) => setP1ContactDraft(id, { orgSignatoryName: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-p8-signatory-name-${id}`} /></div>}
              {needsAddress && <div className="space-y-1"><Label className="text-xs">Deponent address</Label><Textarea value={draft.residentialAddress} onChange={(event) => setP1ContactDraft(id, { residentialAddress: event.target.value })} rows={2} className="text-xs" data-testid={`pre-generate-p8-deponent-address-${id}`} /></div>}
              {needsOccupation && !isOrganization && <div className="space-y-1"><Label className="text-xs">Occupation</Label><Input value={draft.occupation} onChange={(event) => setP1ContactDraft(id, { occupation: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-p8-deponent-occupation-${id}`} /></div>}
              {needsOccupation && isOrganization && <div className="space-y-1"><Label className="text-xs">Signatory title or capacity</Label><Input value={draft.orgSignatoryTitle} onChange={(event) => setP1ContactDraft(id, { orgSignatoryTitle: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-p8-signatory-title-${id}`} /></div>}
            </div>
          );
        })}
        <p className="text-[10px] leading-tight text-muted-foreground">These edits are saved to each co-applicant contact record before P8 is re-checked.</p>
      </div>
    );
  }

  function renderP10DeponentEditor(): React.JSX.Element | null {
    if (!p10Deponent) return null;
    const id = String(p10Deponent.id ?? "");
    const draft = p1ContactDrafts[id];
    if (!id || !draft) return null;
    return (
      <div className="space-y-2" data-testid="pre-generate-p10-deponent">
        <p className="text-[11px] font-medium">Selected deponent: {String(p10Deponent.name || "Applying applicant")}</p>
        {p10GapIds.has("p10_deponent_name") && <div className="space-y-1"><Label className="text-xs">Deponent name</Label><Input value={draft.name} onChange={(event) => setP1ContactDraft(id, { name: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-p10-deponent-name-${id}`} /></div>}
        {p10GapIds.has("p10_deponent_address") && <div className="space-y-1"><Label className="text-xs">Deponent address</Label><Textarea value={draft.residentialAddress} onChange={(event) => setP1ContactDraft(id, { residentialAddress: event.target.value })} rows={2} className="text-xs" data-testid={`pre-generate-p10-deponent-address-${id}`} /></div>}
        {p10GapIds.has("p10_deponent_occupation") && <div className="space-y-1"><Label className="text-xs">Occupation</Label><Input value={draft.occupation} onChange={(event) => setP1ContactDraft(id, { occupation: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-p10-deponent-occupation-${id}`} /></div>}
        <p className="text-[10px] leading-tight text-muted-foreground">These edits are saved to the selected deponent’s contact record before P10 is re-checked.</p>
      </div>
    );
  }

  function renderP11DeponentEditor(): React.JSX.Element | null {
    if (!p10Deponent) return null;
    const id = String(p10Deponent.id ?? "");
    const draft = p1ContactDrafts[id];
    if (!id || !draft) return null;
    const isOrganization = p10Deponent.applicantKind === "organization";
    return (
      <div className="space-y-2" data-testid="pre-generate-p11-deponent">
        <p className="text-[11px] font-medium">Selected deponent: {String(p10Deponent.name || "Applying applicant")}</p>
        {p11GapIds.has("p11_applicant_contact") && <div className="space-y-1"><Label className="text-xs">Deponent name</Label><Input value={draft.name} onChange={(event) => setP1ContactDraft(id, { name: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-p11-deponent-name-${id}`} /></div>}
        {p11GapIds.has("p11_applicant_address") && <div className="space-y-1"><Label className="text-xs">Deponent address</Label><Textarea value={draft.residentialAddress} onChange={(event) => setP1ContactDraft(id, { residentialAddress: event.target.value })} rows={2} className="text-xs" data-testid={`pre-generate-p11-deponent-address-${id}`} /></div>}
        {!isOrganization && p11GapIds.has("p11_applicant_occupation") && <div className="space-y-1"><Label className="text-xs">Occupation</Label><Input value={draft.occupation} onChange={(event) => setP1ContactDraft(id, { occupation: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-p11-deponent-occupation-${id}`} /></div>}
        {isOrganization && p11GapIds.has("p11_org_signatory_name") && <div className="space-y-1"><Label className="text-xs">Signatory name</Label><Input value={draft.orgSignatoryName} onChange={(event) => setP1ContactDraft(id, { orgSignatoryName: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-p11-signatory-name-${id}`} /></div>}
        {isOrganization && p11GapIds.has("p11_org_signatory_title") && <div className="space-y-1"><Label className="text-xs">Signatory title or capacity</Label><Input value={draft.orgSignatoryTitle} onChange={(event) => setP1ContactDraft(id, { orgSignatoryTitle: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-p11-signatory-title-${id}`} /></div>}
        <p className="text-[10px] leading-tight text-muted-foreground">These edits are saved to the selected deponent’s contact record before P11 is re-checked.</p>
      </div>
    );
  }

  function renderP1GapEditor(requirementId: string): React.JSX.Element | null {
    if ((!isP1Only && !isP2Only && !isP3Only && !isP4Only && !isP5Only && !isP6Only && !isP7Only && !isP8Only && !isP9Only && !isP10Only && !isP11Only && !isP26Only && !isP44Only && !isP45Only && !isP46Only && !isVsa532Only && !isPgtInfoOnly) || !canEditInline) return null;
    const gap = allGaps.find((candidate) => candidate.gap.requirementId === requirementId)?.gap;
    const isPredicateGap = gap?.missingFields.length === 0;
    if (isP11Only) {
      const deponentGapIds = ["p11_applicant_contact", "p11_applicant_address", "p11_applicant_occupation", "p11_org_signatory_name", "p11_org_signatory_title"];
      const firstDeponentGap = deponentGapIds.find((id) => p11GapIds.has(id));
      if (deponentGapIds.includes(requirementId)) {
        return requirementId === firstDeponentGap
          ? renderP11DeponentEditor()
          : <p className="text-[10px] text-muted-foreground">Complete the selected deponent contact above; the same saved record resolves this item.</p>;
      }
    }
    if (isP10Only) {
      const deponentGapIds = ["p10_deponent_name", "p10_deponent_address", "p10_deponent_occupation"];
      const firstDeponentGap = deponentGapIds.find((id) => p10GapIds.has(id));
      if (deponentGapIds.includes(requirementId)) {
        return requirementId === firstDeponentGap
          ? renderP10DeponentEditor()
          : <p className="text-[10px] text-muted-foreground">Complete the selected deponent contact above; the same saved record resolves this item.</p>;
      }
    }
    if (isP9Only) {
      if (requirementId === "p9_will_copy_available") {
        return renderP1Upload("will", "Attach the copy of the will delivered with Form P1");
      }
      if (requirementId === "p9_foreign_grant_available") {
        return renderP1Upload("foreignGrant", "Attach the copy of the foreign grant delivered with Form P1");
      }
      if (requirementId === "p9_foreign_grant_will_inclusion") {
        return (
          <div className="space-y-1" data-testid="pre-generate-p9-foreign-grant-will-inclusion">
            <Label className="text-xs">Did the foreign grant include the will?</Label>
            <Select value={p1EstateDraft.foreignGrantIncludesWill || undefined} onValueChange={(foreignGrantIncludesWill) => setP1EstateDraft((current) => ({ ...current, foreignGrantIncludesWill }))}>
              <SelectTrigger className="h-9 text-xs" data-testid="pre-generate-p9-foreign-grant-will-inclusion-select"><SelectValue placeholder="Select…" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="yes" className="text-xs">Yes — the will was included</SelectItem>
                <SelectItem value="no" className="text-xs">No — the will was not included</SelectItem>
              </SelectContent>
            </Select>
          </div>
        );
      }
    }
    if (isP45Only && requirementId === "p45_electronic_will_format") {
      const setElectronicWillAxis = (key: "electronicWillFirstSavedPdf" | "electronicWillInRepository", value: string) => {
        setP1EstateDraft((current) => ({ ...current, ...applyElectronicWillAxis({ ...(estate ?? {}), ...current } as any, key, value) }));
      };
      return (
        <div className="space-y-3 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm" data-testid="pre-generate-p45-electronic-will-format">
          <p className="text-[11px] font-medium">Electronic-will record</p>
          <div className="space-y-1"><Label className="text-xs">Was the original first saved as a PDF?</Label><Select value={p1EstateDraft.electronicWillFirstSavedPdf || undefined} onValueChange={(value) => setElectronicWillAxis("electronicWillFirstSavedPdf", value)}><SelectTrigger className="h-9 text-xs" data-testid="pre-generate-p45-first-saved-pdf"><SelectValue placeholder="Select…" /></SelectTrigger><SelectContent><SelectItem value="yes" className="text-xs">Yes</SelectItem><SelectItem value="no" className="text-xs">No</SelectItem></SelectContent></Select></div>
          <div className="space-y-1"><Label className="text-xs">Is it maintained in a third-party repository?</Label><Select value={p1EstateDraft.electronicWillInRepository || undefined} onValueChange={(value) => setElectronicWillAxis("electronicWillInRepository", value)}><SelectTrigger className="h-9 text-xs" data-testid="pre-generate-p45-in-repository"><SelectValue placeholder="Select…" /></SelectTrigger><SelectContent><SelectItem value="yes" className="text-xs">Yes</SelectItem><SelectItem value="no" className="text-xs">No</SelectItem></SelectContent></Select></div>
          <p className="text-[10px] leading-tight text-muted-foreground">Both answers are saved together with the derived electronic-will format before P45 is re-checked.</p>
        </div>
      );
    }
    if (isVsa532Only && (requirementId === "vsa532_applicant_contact" || requirementId === "vsa532_applicant_postal")) {
      if (!p5PrimaryApplicant) {
        if (requirementId !== "vsa532_applicant_contact") return <p className="text-[10px] text-muted-foreground">Add the applying contact above; the same saved contact resolves the postal-code item.</p>;
        return (
          <div className="space-y-3 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm" data-testid="pre-generate-vsa532-applicant-create">
            {renderP1ContactFields("Add applying applicant", p1ApplicantDraft, (patch) => setP1ApplicantDraft((current) => ({ ...current, ...patch })), "pre-generate-p1-applicant-create")}
            <div className="space-y-1"><Label className="text-xs">Postal address (including postal code)</Label><Textarea value={p1ApplicantDraft.postalAddress} onChange={(event) => setP1ApplicantDraft((current) => ({ ...current, postalAddress: event.target.value }))} rows={2} className="text-xs" data-testid="pre-generate-vsa532-applicant-create-postal" /></div>
          </div>
        );
      }
      const id = String(p5PrimaryApplicant.id ?? "");
      const draft = p1ContactDrafts[id];
      const orderedGapIds = ["vsa532_applicant_contact", "vsa532_applicant_postal"];
      const firstGap = orderedGapIds.find((gapId) => vsa532GapIds.has(gapId));
      if (!id || !draft || requirementId !== firstGap) return <p className="text-[10px] text-muted-foreground">Complete the applying contact above; the same saved record resolves this item.</p>;
      return (
        <div className="space-y-3 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm" data-testid="pre-generate-vsa532-applicant-update">
          <p className="text-[11px] font-medium">Applying contact: {String(p5PrimaryApplicant.name || "Applicant")}</p>
          {vsa532GapIds.has("vsa532_applicant_contact") && <div className="space-y-1"><Label className="text-xs">Applicant name</Label><Input value={draft.name} onChange={(event) => setP1ContactDraft(id, { name: event.target.value })} className="h-9 text-xs" data-testid="pre-generate-vsa532-applicant-name" /></div>}
          {vsa532GapIds.has("vsa532_applicant_postal") && <div className="space-y-1"><Label className="text-xs">Postal address (including postal code)</Label><Textarea value={draft.postalAddress} onChange={(event) => setP1ContactDraft(id, { postalAddress: event.target.value })} rows={2} className="text-xs" data-testid="pre-generate-vsa532-applicant-postal" /></div>}
          <p className="text-[10px] leading-tight text-muted-foreground">These edits are saved to the applying contact record before VSA 532 is re-checked.</p>
        </div>
      );
    }
    if (isPgtInfoOnly && (requirementId === "pgt_info_recipient_names" || requirementId === "pgt_info_recipient_details_reviewed")) {
      const orderedGapIds = ["pgt_info_recipient_names", "pgt_info_recipient_details_reviewed"];
      const firstGap = orderedGapIds.find((gapId) => pgtInfoGapIds.has(gapId));
      if (requirementId !== firstGap) return <p className="text-[10px] text-muted-foreground">Complete the notice-recipient review above; the same saved contact records resolve this item.</p>;
      if (pgtInfoRecipients.length === 0) return <p className="text-[10px] text-muted-foreground">The Rule 25-2 notice-recipient set must be determined in Forms before these contact details can be confirmed.</p>;
      return (
        <div className="space-y-3 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm" data-testid="pre-generate-pgt-info-recipients">
          <p className="text-[11px] font-medium">P1 notice recipients</p>
          {pgtInfoRecipients.map((recipient) => {
            const id = String(recipient.id ?? "");
            const draft = p1ContactDrafts[id];
            if (!id || !draft) return null;
            const needsName = pgtInfoGapIds.has("pgt_info_recipient_names") && !String(recipient.name ?? "").trim();
            const needsReview = pgtInfoGapIds.has("pgt_info_recipient_details_reviewed") && Number(recipient.pgtInfoReviewed) !== 1;
            if (!needsName && !needsReview) return null;
            return (
              <div key={id} className="space-y-1 border-t pt-2 first:border-t-0 first:pt-0">
                <p className="text-[10px] text-muted-foreground">Recipient record</p>
                {needsName && <div className="space-y-1"><Label className="text-xs">Name</Label><Input value={draft.name} onChange={(event) => setP1ContactDraft(id, { name: event.target.value })} className="h-9 text-xs" data-testid={`pre-generate-pgt-info-name-${id}`} /></div>}
                {needsReview && <label className="flex items-start gap-2 text-xs text-foreground"><Checkbox checked={draft.pgtInfoReviewed} onCheckedChange={(checked) => setP1ContactDraft(id, { pgtInfoReviewed: checked === true })} data-testid={`pre-generate-pgt-info-reviewed-${id}`} /><span>I confirmed this person’s most recent known residential, postal, email and fax details.</span></label>}
              </div>
            );
          })}
          <p className="text-[10px] leading-tight text-muted-foreground">Each checked confirmation is saved to that recipient’s canonical contact record before PGT_INFO is re-checked.</p>
        </div>
      );
    }
    if (isP8Only) {
      const deponentGapIds = ["p8_deponent_name", "p8_deponent_address", "p8_deponent_occupation"];
      const firstDeponentGap = deponentGapIds.find((id) => p8GapIds.has(id));
      if (deponentGapIds.includes(requirementId)) {
        return requirementId === firstDeponentGap
          ? renderP8CoApplicantEditor()
          : <p className="text-[10px] text-muted-foreground">Complete the co-applicant contact records above; the same saved records resolve this item.</p>;
      }
    }
    if (isP6Only || isP7Only) {
      const prefix = isP6Only ? "p6" : "p7";
      const ancillaryGapIds = isP6Only ? p6GapIds : p7GapIds;
      const ancillaryForm = isP6Only ? "P6" : "P7";
      const applicantGapIds = [`${prefix}_individual_applicant_residence`, `${prefix}_organization_signatory`, `${prefix}_deponent_name`, `${prefix}_deponent_address`, `${prefix}_deponent_occupation`];
      const firstApplicantGap = applicantGapIds.find((id) => ancillaryGapIds.has(id));
      if (applicantGapIds.includes(requirementId)) {
        return requirementId === firstApplicantGap
          ? renderAncillaryApplicantEditor(ancillaryForm, ancillaryGapIds)
          : <p className="text-[10px] text-muted-foreground">Complete the applying-applicant contact above; the same saved record resolves this item.</p>;
      }
      if (requirementId === `${prefix}_foreign_grant_issued_date`) {
        return <div className="space-y-1" data-testid={`pre-generate-${prefix}-foreign-grant-date`}><Label className="text-xs">Date the foreign grant was issued</Label><Input type="date" value={p1EstateDraft.foreignGrantIssuedDate || ""} onChange={(event) => setP1EstateDraft((current) => ({ ...current, foreignGrantIssuedDate: event.target.value }))} className="h-9 text-xs" data-testid={`pre-generate-${prefix}-foreign-grant-date-input`} /></div>;
      }
      if (requirementId === `${prefix}_testamentary_doc_status`) {
        return (
          <div className="space-y-1" data-testid={`pre-generate-${prefix}-testamentary-status`}>
            <Label className="text-xs">Diligent-search result</Label>
            <Select value={p1EstateDraft.testamentaryDocStatus || undefined} onValueChange={(testamentaryDocStatus) => setP1EstateDraft((current) => ({ ...current, testamentaryDocStatus }))}>
              <SelectTrigger className="h-9 text-xs" data-testid={`pre-generate-${prefix}-testamentary-status-select`}><SelectValue placeholder="Select…" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none_found" className="text-xs">No other testamentary document was found</SelectItem>
                <SelectItem value="found" className="text-xs">One or more other testamentary documents were found</SelectItem>
              </SelectContent>
            </Select>
          </div>
        );
      }
    }
    if (isP26Only && requirementId === "p26_foreign_grant_issued_date") {
      return <div className="space-y-1" data-testid="pre-generate-p26-foreign-grant-date"><Label className="text-xs">Date the foreign grant was issued</Label><Input type="date" value={p1EstateDraft.foreignGrantIssuedDate || ""} onChange={(event) => setP1EstateDraft((current) => ({ ...current, foreignGrantIssuedDate: event.target.value }))} className="h-9 text-xs" data-testid="pre-generate-p26-foreign-grant-date-input" /></div>;
    }
    if (isP5Only) {
      if (requirementId === "p5_priority_paragraph") {
        const selected = p1EstateDraft.applicantPriorityParagraph || "";
        return (
          <fieldset className="space-y-2 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm" data-testid="pre-generate-p5-priority-choice">
            <legend className="px-1 text-xs font-medium">WESA s.130 priority</legend>
            <p className="text-[11px] leading-relaxed text-muted-foreground">Select the one statutory row P5 should cite. This selection is saved to the estate and no automatic inference will replace it.</p>
            <div className="space-y-2">
              {P5_PRIORITY_OPTIONS.map((option) => {
                const id = `pre-generate-p5-priority-${option.value.replace(".", "-")}`;
                const checked = selected === option.value;
                return (
                  <label key={option.value} htmlFor={id} className={`flex cursor-pointer items-start gap-2.5 rounded-lg border px-2.5 py-2 text-xs leading-relaxed transition-colors ${checked ? "border-primary/60 bg-primary/5 text-foreground" : "border-border/70 bg-background hover:border-primary/35"}`}>
                    <Checkbox id={id} checked={checked} onCheckedChange={(next) => setP1EstateDraft((current) => ({ ...current, applicantPriorityParagraph: next === true ? option.value : "" }))} data-testid={id} />
                    <span>{option.label}</span>
                  </label>
                );
              })}
            </div>
          </fieldset>
        );
      }
      const primaryGapIds = ["p5_marriage_like_duration", "p5_deponent_name", "p5_deponent_address", "p5_deponent_occupation"];
      const firstPrimaryGap = primaryGapIds.find((id) => p5GapIds.has(id));
      if (primaryGapIds.includes(requirementId)) {
        return requirementId === firstPrimaryGap
          ? renderP5PrimaryApplicantEditor()
          : <p className="text-[10px] text-muted-foreground">Complete the applying deponent contact above; the same saved record resolves this item.</p>;
      }
      const firstPriorRightsGap = p5GapIds.has("p5_prior_rights_consent") ? "p5_prior_rights_consent" : "p5_prior_rights_inquiry_details";
      if (requirementId === "p5_prior_rights_consent" || requirementId === "p5_prior_rights_inquiry_details") {
        return requirementId === firstPriorRightsGap
          ? renderP5PriorRightsEditor()
          : <p className="text-[10px] text-muted-foreground">Record the inquiry details for the contact above when they cannot be located.</p>;
      }
      if (requirementId === "p5_intestate_successors") return renderP5SuccessorEditor();
      if (requirementId === "p5_testamentary_doc_status" || requirementId === "p5_testamentary_doc_status_valid") {
        const firstTestamentaryGap = p5GapIds.has("p5_testamentary_doc_status") ? "p5_testamentary_doc_status" : "p5_testamentary_doc_status_valid";
        if (requirementId !== firstTestamentaryGap) return <p className="text-[10px] text-muted-foreground">Select the document-search result above; the same saved answer resolves this item.</p>;
        return (
          <div className="space-y-1" data-testid="pre-generate-p5-testamentary-status">
            <Label className="text-xs">Testamentary document search result</Label>
            <Select value={p1EstateDraft.testamentaryDocStatus || undefined} onValueChange={(testamentaryDocStatus) => setP1EstateDraft((current) => ({ ...current, testamentaryDocStatus }))}>
              <SelectTrigger className="h-9 text-xs" data-testid="pre-generate-p5-testamentary-status-select"><SelectValue placeholder="Select…" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none_found" className="text-xs">No testamentary document was found</SelectItem>
                <SelectItem value="found" className="text-xs">One or more testamentary documents were found</SelectItem>
              </SelectContent>
            </Select>
          </div>
        );
      }
    }
    if (requirementId === "p8_co_applicants") {
      return renderP1ContactFields("Add applying co-applicant (name, address, occupation)", p1ApplicantDraft, (patch) => setP1ApplicantDraft((current) => ({ ...current, ...patch })), "pre-generate-p8-co-applicant-create");
    }
    if (requirementId === "p17_renouncer_contact" && isPredicateGap) {
      return renderP1ContactFields("Add renouncing executor (name, address, occupation)", p1ApplicantDraft, (patch) => setP1ApplicantDraft((current) => ({ ...current, ...patch })), "pre-generate-p17-renouncer-create");
    }
    if ((requirementId === "p1_applicant_contact" || requirementId === "p2_applicant_contact" || requirementId === "p3_applicant_contact" || requirementId === "p6_applicant_contact" || requirementId === "p7_applicant_contact" || requirementId === "p44_applicant_contact" || requirementId === "p46_applicant_contact") && isPredicateGap) {
      return renderP1ContactFields("Add applying applicant", p1ApplicantDraft, (patch) => setP1ApplicantDraft((current) => ({ ...current, ...patch })), "pre-generate-p1-applicant-create");
    }
    if ((requirementId === "p1_recipient_list" || requirementId === "p44_recipient_list") && isPredicateGap) {
      return (
        <div className="space-y-3 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm" data-testid="pre-generate-p1-recipient-create">
          <p className="text-[11px] font-medium">Add notice recipient</p>
          <div className="space-y-1">
            <Label className="text-xs">Recipient class</Label>
            <Select value={p1RecipientDraft.recipientType} onValueChange={(recipientType) => setP1RecipientDraft((current) => ({ ...current, recipientType }))}>
              <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="beneficiary" className="text-xs">Beneficiary</SelectItem>
                <SelectItem value="intestate_successor" className="text-xs">Intestate successor</SelectItem>
                <SelectItem value="citor" className="text-xs">Citor</SelectItem>
                <SelectItem value="court_ordered" className="text-xs">Court-ordered recipient</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {renderP1ContactFields("Recipient details", p1RecipientDraft, (patch) => setP1RecipientDraft((current) => ({ ...current, ...patch })), "pre-generate-p1-recipient-details")}
        </div>
      );
    }
    if ((requirementId === "p1_spouse_name" || requirementId === "p1_spouse_address" || requirementId === "p2_spouse_contact" || requirementId === "p2_late_spouse_contact") && isPredicateGap) {
      if (requirementId === "p1_spouse_address" && p1GapIds.has("p1_spouse_name")) {
        return <p className="text-[10px] text-muted-foreground">Complete the spouse contact above; the same saved address resolves this item.</p>;
      }
      if (p1SpouseContacts.length === 0) {
        return renderP1ContactFields(
          requirementId === "p2_late_spouse_contact" ? "Add late spouse (predeceased) contact — name is enough" : requirementId === "p2_spouse_contact" ? "Add spouse contact" : "Add spouse notice contact",
          p1SpouseDraft,
          (patch) => setP1SpouseDraft((current) => ({ ...current, ...patch })),
          "pre-generate-p1-spouse-create",
        );
      }
      return (
        <div className="space-y-2" data-testid="pre-generate-p1-spouse-update">
          {p1SpouseContacts.map((contact) => renderP1ContactFields(
            String(contact.name || "Spouse notice contact"),
            p1ContactDrafts[String(contact.id)] ?? { name: "", residentialAddress: "" },
            (patch) => setP1ContactDraft(String(contact.id), patch),
            `pre-generate-p1-spouse-${contact.id}`,
          ))}
        </div>
      );
    }
    if (requirementId === "p1_applicant_names" || requirementId === "p1_applicant_postal") {
      if (requirementId === "p1_applicant_postal" && p1GapIds.has("p1_applicant_names")) {
        return <p className="text-[10px] text-muted-foreground">Complete the applicant contact above; the same saved address resolves this item.</p>;
      }
      if (p1ApplyingContacts.length === 0) return null;
      return (
        <div className="space-y-2" data-testid="pre-generate-p1-applicant-update">
          {p1ApplyingContacts.map((contact) => renderP1ContactFields(
            String(contact.name || "Applying applicant"),
            p1ContactDrafts[String(contact.id)] ?? { name: "", residentialAddress: "" },
            (patch) => setP1ContactDraft(String(contact.id), patch),
            `pre-generate-p1-applicant-${contact.id}`,
          ))}
        </div>
      );
    }
    if (requirementId === "p1_deceased_other_names" || requirementId === "p11_deceased_aliases") {
      return (
        <div className="space-y-3 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm" data-testid="pre-generate-p1-aliases">
          <p className="text-[11px] font-medium">Other names used by the deceased</p>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
            {(["first", "middle", "last"] as const).map((part) => (
              <div key={part} className="space-y-1">
                <Label className="text-xs">AKA {part === "first" ? "first name" : part === "middle" ? "middle name" : "last name"}</Label>
                <Input value={p1OtherNamesDraft[part]} onChange={(event) => setP1OtherNamesDraft((current) => ({ ...current, [part]: event.target.value }))} className="h-10 bg-background text-sm shadow-sm transition-colors hover:border-primary/40 focus-visible:ring-primary/35" />
              </div>
            ))}
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Additional aliases (one per line)</Label>
            <Textarea value={p1OtherNamesDraft.additional} onChange={(event) => setP1OtherNamesDraft((current) => ({ ...current, additional: event.target.value }))} rows={2} className="text-xs" />
          </div>
        </div>
      );
    }
    if ((requirementId === "p1_grant_type" || requirementId === "p2_grant_type") && isPredicateGap) {
      return (
        <div className="space-y-1" data-testid="pre-generate-p1-grant-type">
          <Label className="text-xs">Type of grant sought</Label>
          <Select value={p1EstateDraft.grantType || "unknown"} onValueChange={(grantType) => setP1EstateDraft((current) => ({ ...current, grantType }))}>
            <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="grant_of_probate" className="text-xs">Grant of Probate</SelectItem>
              <SelectItem value="grant_of_admin_with_will" className="text-xs">Administration with Will Annexed</SelectItem>
              <SelectItem value="grant_of_admin" className="text-xs">Grant of Administration</SelectItem>
              <SelectItem value="ancillary_probate" className="text-xs">Ancillary Grant of Probate</SelectItem>
              <SelectItem value="ancillary_admin_with_will" className="text-xs">Ancillary Grant of Administration with Will Annexed</SelectItem>
              <SelectItem value="ancillary_admin_no_will" className="text-xs">Ancillary Grant of Administration without Will</SelectItem>
              <SelectItem value="resealing" className="text-xs">Resealing</SelectItem>
            </SelectContent>
          </Select>
        </div>
      );
    }
    if (requirementId === "p2_ancillary_foreign_grant_issued_date") {
      return <div className="space-y-1"><Label className="text-xs">Date the foreign grant was issued</Label><Input type="date" value={p1EstateDraft.foreignGrantIssuedDate || ""} onChange={(event) => setP1EstateDraft((current) => ({ ...current, foreignGrantIssuedDate: event.target.value }))} className="h-9 text-xs" /></div>;
    }
    if (requirementId === "p2_ancillary_foreign_grant_certification") {
      return <div className="space-y-1"><Label className="text-xs">Is the foreign-grant copy certified by the issuing court?</Label><Select value={p1EstateDraft.foreignGrantCertifiedByIssuingCourt || undefined} onValueChange={(value) => setP1EstateDraft((current) => ({ ...current, foreignGrantCertifiedByIssuingCourt: value }))}><SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Select…" /></SelectTrigger><SelectContent><SelectItem value="yes" className="text-xs">Yes</SelectItem><SelectItem value="no" className="text-xs">No</SelectItem></SelectContent></Select></div>;
    }
    if (requirementId === "p2_ancillary_will_inclusion") {
      return <div className="space-y-1"><Label className="text-xs">Do the will and codicils form part of the foreign grant?</Label><Select value={p1EstateDraft.foreignGrantIncludesWill || undefined} onValueChange={(value) => setP1EstateDraft((current) => ({ ...current, foreignGrantIncludesWill: value }))}><SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Select…" /></SelectTrigger><SelectContent><SelectItem value="yes" className="text-xs">Yes</SelectItem><SelectItem value="no" className="text-xs">No</SelectItem></SelectContent></Select></div>;
    }
    if (requirementId === "p2_ancillary_will_certification") {
      return <div className="space-y-1"><Label className="text-xs">Are the filed will and codicils certified by the issuing court?</Label><Select value={p1EstateDraft.ancillaryWillDocumentsCertifiedByIssuingCourt || undefined} onValueChange={(value) => setP1EstateDraft((current) => ({ ...current, ancillaryWillDocumentsCertifiedByIssuingCourt: value }))}><SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Select…" /></SelectTrigger><SelectContent><SelectItem value="yes" className="text-xs">Yes</SelectItem><SelectItem value="no" className="text-xs">No</SelectItem></SelectContent></Select></div>;
    }
    if (requirementId === "p2_order_filed_status" && isPredicateGap) {
      return <div className="space-y-1"><Label className="text-xs">Court-order filing status</Label><Select value={p1EstateDraft.orderFiled || undefined} onValueChange={(value) => setP1EstateDraft((current) => ({ ...current, orderFiled: value }))}><SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Select…" /></SelectTrigger><SelectContent><SelectItem value="filed" className="text-xs">Filed</SelectItem><SelectItem value="not_yet_filed" className="text-xs">Being filed with this submission</SelectItem></SelectContent></Select></div>;
    }
    if ((requirementId === "p4_attestation_affidavits" || requirementId === "p4_interlineation_affidavits" || requirementId === "p4_erasure_affidavits") && isP4Only) {
      return (
        <div className="space-y-3 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm" data-testid={`pre-generate-${requirementId}`}>
          <p className="text-[11px] font-medium">Affidavit submitted for filing</p>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            <div className="space-y-1"><Label className="text-xs">Deponent name</Label><Input value={p1EstateDraft[`${requirementId}_name`] || ""} onChange={(event) => setP1EstateDraft((current) => ({ ...current, [`${requirementId}_name`]: event.target.value }))} className="h-9 text-xs" /></div>
            <div className="space-y-1"><Label className="text-xs">Date sworn</Label><Input type="date" value={p1EstateDraft[`${requirementId}_sworn`] || ""} onChange={(event) => setP1EstateDraft((current) => ({ ...current, [`${requirementId}_sworn`]: event.target.value }))} className="h-9 text-xs" /></div>
          </div>
          <p className="text-[10px] leading-tight text-muted-foreground">This saves one complete affidavit entry to the estate record before P4 is re-checked.</p>
        </div>
      );
    }
    if (requirementId === "p1_electronic_will_no_signature_reason") {
      return (
        <div className="space-y-1" data-testid="pre-generate-p1-no-visible-signature">
          <Label className="text-xs">Reason there is no visible signature</Label>
          <Textarea value={p1EstateDraft.noVisibleSignatureReason || ""} onChange={(event) => setP1EstateDraft((current) => ({ ...current, noVisibleSignatureReason: event.target.value }))} rows={2} className="text-xs" />
        </div>
      );
    }
    if (requirementId === "p1_will_copy_upload") return renderP1Upload("will", "Copy of the will", false);
    if (requirementId === "p1_codicil_uploads") return renderP1Upload("codicil", "Copies of recorded codicils", true);
    if (requirementId === "p1_foreign_grant_upload") return renderP1Upload("foreignGrant", "Copy of the foreign grant", false);
    if (requirementId === "p2_ancillary_foreign_grant_upload") return renderP1Upload("foreignGrant", "Certified filing copy of the foreign grant", false);
    if (requirementId === "p2_ancillary_separate_will_upload") return renderP1Upload("will", "Certified filing copy of the will", false);
    if (requirementId === "p2_ancillary_codicil_uploads") return renderP1Upload("codicil", "Certified filing copies of recorded codicils", true);
    if (requirementId === "p1_foreign_grant_will_inclusion") {
      return (
        <div className="space-y-1" data-testid="pre-generate-p1-foreign-will-inclusion">
          <Label className="text-xs">Are the will and any codicils attached to and included in the foreign grant?</Label>
          <Select value={p1EstateDraft.foreignGrantIncludesWill || undefined} onValueChange={(foreignGrantIncludesWill) => setP1EstateDraft((current) => ({ ...current, foreignGrantIncludesWill }))}>
            <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Select…" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="yes" className="text-xs">Yes</SelectItem>
              <SelectItem value="no" className="text-xs">No</SelectItem>
            </SelectContent>
          </Select>
        </div>
      );
    }
    return null;
  }

  function renderP8PrimaryAffidavitEditor(requirementId: string): React.JSX.Element | null {
    if (!canEditInline || requirementId !== "p8_primary_affidavit_history") return null;
    return (
      <div className="space-y-2" data-testid="pre-generate-p8-primary-affidavit-editor">
        <p className="text-[11px] leading-relaxed text-muted-foreground">
          Enter the facts that appear in P8 paragraph 2. These answers are used for this draft and are not saved to Intake.
        </p>
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
          <div className="space-y-1">
            <Label className="text-xs">Primary affidavit form</Label>
            <Select value={p8PrimaryDraft.p8PrimaryAffidavitForm || undefined} onValueChange={(value) => setP8PrimaryDraft((current) => ({ ...current, p8PrimaryAffidavitForm: value }))}>
              <SelectTrigger className="h-9 text-xs" data-testid="pre-generate-p8-primary-form"><SelectValue placeholder="Select form…" /></SelectTrigger>
              <SelectContent>
                {["P3", "P4", "P5", "P6", "P7"].map((form) => <SelectItem key={form} value={form} className="text-xs">Form {form}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Date sworn</Label>
            <Input type="date" value={p8PrimaryDraft.p8PrimaryAffidavitDate || ""} onChange={(event) => setP8PrimaryDraft((current) => ({ ...current, p8PrimaryAffidavitDate: event.target.value }))} className="h-9 text-xs" data-testid="pre-generate-p8-primary-date" />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Primary deponent</Label>
            <Input value={p8PrimaryDraft.p8PrimaryAffidavitDeponentName || ""} onChange={(event) => setP8PrimaryDraft((current) => ({ ...current, p8PrimaryAffidavitDeponentName: event.target.value }))} className="h-9 text-xs" data-testid="pre-generate-p8-primary-deponent" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      {/* Never add a position utility (relative/absolute/sticky) to this className:
          cn() runs tailwind-merge, which treats it as a conflict with the base
          DialogContent "fixed" and DROPS it — the panel then lays out in normal
          flow below the page while the overlay still covers the viewport, so the
          screen dims with no visible dialog. The base "fixed" already anchors the
          absolute inset-0 processing overlay below. */}
      <DialogContent
        className="pre-generate-dialog-interactions z-[60] max-h-[calc(100dvh-1rem)] w-[calc(100%-1rem)] max-w-[calc(100%-1rem)] gap-3 overflow-y-auto border-border/80 bg-background/98 p-3 shadow-2xl sm:max-h-[85vh] sm:max-w-xl sm:gap-4 sm:p-6"
        overlayClassName="z-[60]"
        data-testid="pre-generate-dialog"
      >
        {/* Keep both stages mounted during the handoff so the spinner can fade
            out as the success checkmark fades in, rather than switching abruptly. */}
        {(proceeding || showSuccess) && (
          <div className="absolute inset-0 z-10 rounded-lg bg-background/95 backdrop-blur-sm" data-testid="pre-generate-processing" aria-live="polite" aria-busy={!showSuccess}>
            <div
              className={`pre-generate-stage ${showSuccess ? "pre-generate-stage-exit" : "pre-generate-stage-enter"}`}
              data-testid="pre-generate-loading"
              aria-hidden={showSuccess}
            >
              <Loader2 className="h-10 w-10 animate-spin text-primary" />
              <p className="text-sm font-medium text-muted-foreground animate-pulse">
                {action === "preview" ? "Preparing preview…" : action === "download" ? "Preparing download…" : "Generating document…"}
              </p>
            </div>

            <div
              className={`pre-generate-stage ${showSuccess ? "pre-generate-stage-enter" : "pre-generate-stage-exit"}`}
              data-testid="pre-generate-success"
              aria-hidden={!showSuccess}
            >
              <Tooltip>
                <TooltipTrigger asChild>
                  <span
                    tabIndex={showSuccess ? 0 : -1}
                    role="img"
                    aria-label={action === "preview" ? "Preview ready" : action === "download" ? "Download started" : "Document generated"}
                    data-testid="pre-generate-success-tooltip-trigger"
                    className={`flex h-14 w-14 items-center justify-center rounded-full bg-green-100 outline-none focus-visible:ring-2 focus-visible:ring-green-600 focus-visible:ring-offset-2 dark:bg-green-900/30 dark:focus-visible:ring-green-400 ${showSuccess ? "pre-generate-success-icon" : ""}`}
                  >
                    <CheckCircle2 className="h-8 w-8 text-green-600 dark:text-green-400" />
                  </span>
                </TooltipTrigger>
                <TooltipContent side="bottom" sideOffset={8}>
                  {action === "preview"
                    ? "The document preview is ready to review."
                    : action === "download"
                      ? "Your download has started."
                      : "The document was generated and is ready to review."}
                </TooltipContent>
              </Tooltip>
              <p className="text-sm font-medium text-green-700 dark:text-green-300">
                {action === "preview" ? "Preview ready!" : action === "download" ? "Download started!" : "Document generated!"}
              </p>
            </div>
          </div>
        )}

        <DialogHeader className="space-y-2 border-b border-border/70 pb-3 sm:pb-4">
          <DialogTitle className="text-base leading-snug tracking-tight sm:text-xl sm:leading-tight">
            {/* The na copy (and its "produce it anyway" promise) belongs ONLY to
                the state where the escape button actually renders. A render
                refusal riding beside the na verdict (for example, an invalid
                deponent) is a real block and must be described separately. */}
            {hardBlocked
              ? naOnlyHardBlock ? `${formName} is not applicable` : `${blockedActionLabel} blocked for ${formName}`
              : notApplicable ? `${formName} is not applicable — producing anyway`
              : isReady ? hasPendingCanonicalRows ? `Review unsaved changes for ${formName}` : `Ready to ${actionWord} ${formName}` : `Missing information for ${formName}`}
          </DialogTitle>
          <DialogDescription className="max-w-prose text-sm leading-relaxed text-muted-foreground">
            {hardBlocked
              ? naOnlyHardBlock
                ? "This form is not applicable to the estate as recorded. You can answer the applicability questions and produce it anyway — the draft is yours to review before swearing or filing."
                : `This action is blocked until the listed legal or source-document conditions are resolved.${anyHardGapEditors ? " Fill the fields below and Apply & re-check to clear the block." : ""}`
              : (notApplicable
                  ? "This form is not applicable to the estate as recorded — you chose to produce it anyway, so the verdict rides along as information. "
                  : "") + (isReady
              ? hasPendingCanonicalRows ? "Review the newer edits below before continuing. They were not included in the earlier save." : `All required fields are present. Continue to ${actionWord} the document.`
              : anyEditors
              ? `The following fields are empty. Fill them below and re-check, or ${actionWord} anyway — missing fields will render as blank lines or defaults. Review the document carefully before swearing or filing.`
              : `The following fields are empty. You can ${actionWord} anyway — missing fields will render as blank lines or defaults. Review the document carefully before swearing or filing.`)}
          </DialogDescription>
          {retainedChoices && (
            <div className="rounded-md border border-border/70 bg-muted/20 px-3 py-2 text-xs leading-relaxed text-foreground" data-testid="pre-generate-retained-choices">
              <p>{retainedChoices.length > 0 ? "This uses your earlier attempt's choices listed below and any answers you entered for it." : "This uses your earlier attempt's choices and any answers you entered for it."} Other details recorded on the estate, such as the oath and jurat city, are used as they are now. {retainedPrimaryAffidavit ? "Generating again replaces the current applicant's affidavit (P3 to P7), even if it is newer than this attempt." : "Generating again replaces the current version, even if it is newer than this attempt."}</p>
              {retainedChoices.length > 0 && (
                <dl className="mt-1 grid grid-cols-[auto_1fr] gap-x-3 gap-y-0.5">
                  {retainedChoices.map((choice) => (
                    <React.Fragment key={choice.label}><dt className="text-muted-foreground">{choice.label}</dt><dd>{choice.value}</dd></React.Fragment>
                  ))}
                </dl>
              )}
            </div>
          )}
          {p45LockStatusRequired && (
            <p className="rounded-md border border-primary/25 bg-primary/5 px-3 py-2 text-xs leading-relaxed text-foreground" data-testid="pre-generate-p45-lock-status-required">
              Select whether the electronic will was locked before continuing. Form P45 requires that recorded answer to choose its sworn statement.
            </p>
          )}
        </DialogHeader>

        {(!isReady || hasPendingCanonicalRows || showP16AlterationEditor) && (
          <ul className="max-h-[48dvh] space-y-3 overflow-y-auto py-1 pr-0.5 sm:max-h-96 sm:py-2 sm:pr-1" data-testid="pre-generate-gap-list">
            {showP16AlterationEditor && (
              <li className="space-y-3 rounded-xl border border-border/70 bg-muted/20 p-3 shadow-sm" data-testid="pre-generate-p16-alteration-fields">
                <p className="text-sm font-semibold">Review the alteration</p>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {P16_ALTERATION_COLUMNS.slice(0, 2).map((column) => renderEditor(column, INLINE_FIELD_CONTROLS[column]!))}
                </div>
                {P16_ALTERATION_COLUMNS.slice(2).map((column) => renderEditor(column, INLINE_FIELD_CONTROLS[column]!))}
              </li>
            )}
            {displayedGaps.map(({ formCode, gap }) => {
              const p16GroupHandlesGap = showP16AlterationEditor
                && ["p16_alteration_line", "p16_alteration_description", "p16_presence_confirmed"].includes(gap.requirementId);
              const gapKey = `${formCode}:${gap.requirementId}`;
              const canonicalColumns = canonicalColumnsByGap.get(gapKey) ?? [];
              const ownCanonicalColumns = canonicalColumns.filter(column => canonicalOwner.get(column) === gapKey);
              const editableColumns = canEditInline
                ? estateAccessorsFor(gap)
                    .map((accessor) => inlineEditableColumn(accessor))
                    .filter((column): column is NonNullable<ReturnType<typeof inlineEditableColumn>> => column !== null)
                    .filter((column) => !showP16AlterationEditor || !p16AlterationColumn(column))
                    .filter((column) => !canonicalColumns.includes(column))
                : [];
              const editableDocKeys = canEditInline
                ? gap.missingFields
                    .map((accessor) => inlineEditableDocKey(accessor))
                    .filter((key): key is string => key !== null)
                : [];
              // Row-editor descriptors, grouped per target row for display.
              // P10's bespoke deponent editor already writes the selected
              // contact's occupation. Do not render the descriptor for that
              // exact same field as a second input in the same gap.
              const rowEditors = (canEditInline ? (gap.editors ?? []) : []).filter((editor) => !(
                isP10Only
                && gap.requirementId === "p10_deponent_occupation"
                && editor.kind === "contact"
                && editor.column === "occupation"
                && String(editor.id) === String(p10Deponent?.id ?? "")
              ));
              const rowGroups: Array<{ key: string; rowLabel: string; editors: GapEditor[] }> = [];
              let hasQuickAdd = false;
              for (const editor of rowEditors) {
                if (editor.kind === "inventoryAdd") { hasQuickAdd = true; continue; }
                const groupKey = `${editor.kind}:${editor.id}`;
                const existing = rowGroups.find((group) => group.key === groupKey);
                if (existing) existing.editors.push(editor);
                else rowGroups.push({ key: groupKey, rowLabel: editor.rowLabel, editors: [editor] });
              }
              // A descriptor-backed accessor is editable even though it is not
              // client-mappable — but coverage is judged PER ACCESSOR, never
              // per gap: a mixed requirement keeps its uneditable residue on
              // the "Missing:" line (e.g. secured].description gets an editor
              // while secured].securedAssetId — a deliberate registry
              // exclusion — stays listed, with Go-to as its honest cure).
              const rowEditorColumns = new Set(
                rowEditors
                  .filter((editor) => editor.kind !== "inventoryAdd" && editor.column)
                  .map((editor) => `${editor.kind}:${editor.column}`),
              );
              const rowEditorCovers = (accessor: string): boolean => {
                const match = /^(?:selectedContact\.([A-Za-z_][A-Za-z0-9_]*)|(contacts|inventory)\[[^\]]*\]\.([A-Za-z_][A-Za-z0-9_]*))$/.exec(accessor);
                if (match === null) return false;
                if (match[1] !== undefined || match[2] === "contacts") {
                  return rowEditorColumns.has(`contact:${match[1] ?? match[3]}`);
                }
                // The quick-add form addresses the whole inventory requirement
                // (it is only emitted when every accessor is quick-add-curable).
                if (hasQuickAdd) return true;
                const column = INVENTORY_ACCESSOR_COLUMN_ALIASES[match[3]] ?? match[3];
                return rowEditorColumns.has(`inventory:${column}`);
              };
              const p1Editor = renderP1GapEditor(gap.requirementId);
              const p8PrimaryEditor = renderP8PrimaryAffidavitEditor(gap.requirementId);
              const p1HandlesGap = isCanonicalCompletionForm && p1Editor !== null;
              const isAnyMode = editableColumns.length > 0 && gapMode(formCode, gap.requirementId) === "any";
              // ANY_OF is a registry operator, not an additional missing fact.
              // An editable alternative satisfies an existing any-mode row;
              // do not mislabel its legacy alias as a second unfillable field.
              const nonEditable = gap.missingFields.filter((accessor) => accessor !== "ANY_OF:" && (
                p1HandlesGap || p16GroupHandlesGap || (canEditInline && isAnyMode) ? false : !canEditInline || (inlineEditableColumn(accessor) === null
                  && inlineEditableDocKey(accessor) === null
                  && !rowEditorCovers(accessor) && !canonicalColumns.includes(accessor.replace(/^estate\./, "")))));
              const hasInlineEditor = editableColumns.length > 0 || editableDocKeys.length > 0
                || rowGroups.length > 0 || hasQuickAdd || p1Editor !== null || p8PrimaryEditor !== null || canonicalColumns.length > 0;
              return (
                <li key={`${formCode}:${gap.requirementId}`} className="group rounded-xl border border-border/70 border-l-2 border-l-primary/45 bg-card p-3 shadow-sm transition-[border-color,box-shadow,transform] duration-200 hover:border-primary/30 hover:shadow-md motion-reduce:transition-none" data-testid={`pre-generate-gap-${gap.requirementId}`}>
                  <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between sm:gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start gap-2 text-sm font-semibold leading-snug">
                        <CircleAlert className="mt-0.5 h-4 w-4 shrink-0 text-primary/80" aria-hidden="true" />
                        <span>
                        {gap.label}
                        {retainedCanonicalByKey.has(gapKey) && <span className="ml-2 text-xs font-normal text-muted-foreground">Unsaved edit</span>}
                        {!retainedCanonicalByKey.has(gapKey) && gap.blocker === "hard" && (
                          <span
                            className="ml-2 inline-block rounded border border-destructive/40 bg-destructive/10 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-destructive dark:text-red-300 align-middle"
                            data-testid={`pre-generate-hard-${gap.requirementId}`}
                          >
                            Blocks generation
                          </span>
                        )}
                        </span>
                      </div>
                      <div className="mt-1 pl-6 text-xs leading-relaxed text-muted-foreground">
                        {reports.length > 1 ? `${formCode} · ` : ""}
                        {gap.source}
                      </div>
                      {nonEditable.length > 0 && (
                        <div className="mt-2 rounded-md bg-muted/55 px-2 py-1.5 text-xs leading-relaxed text-muted-foreground" data-testid={`pre-generate-fields-${gap.requirementId}`}>
                          Missing: {nonEditable.join(", ")}
                        </div>
                      )}
                    </div>
                    {!hasInlineEditor && !p16GroupHandlesGap && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-9 shrink-0 self-start whitespace-nowrap border-border/80 bg-background px-2.5 text-xs shadow-sm transition-colors hover:border-primary/40 hover:bg-primary/5 sm:self-auto"
                        onClick={() => onJumpToTab(gap.tab)}
                        data-testid={`pre-generate-jump-${gap.requirementId}`}
                      >
                        Go to {tabLabel(gap.tab)}
                      </Button>
                    )}
                  </div>
                  {hasInlineEditor && (
                    <div className="mt-3 space-y-3 rounded-lg border border-border/70 bg-muted/20 p-2.5 sm:p-3 [&_label]:text-xs [&_label]:font-medium [&_label]:text-foreground [&_input:not([type=file])]:h-10 [&_input:not([type=file])]:bg-background [&_input:not([type=file])]:text-sm [&_textarea]:bg-background [&_textarea]:text-sm [&_[role=combobox]]:h-10 [&_[role=combobox]]:bg-background [&_[role=combobox]]:text-sm">
                      {isAnyMode && (
                        <p className="text-[10px] text-muted-foreground" data-testid={`pre-generate-anyof-${gap.requirementId}`}>
                          Provide any one of these — they are alternatives, not all required.
                        </p>
                      )}
                      {ownCanonicalColumns.map(column => <CanonicalPopupField
                        key={column} column={column} record={canonicalRecord} clearingAppearance={canonicalClearsAppearance}
                        value={column === "willType" && canonicalFilingMedium ? canonicalFieldValue(canonicalRecord, column) : Object.prototype.hasOwnProperty.call(canonicalDraft, column) ? canonicalDraft[column] : canonicalFieldValue(canonicalRecord, column)}
                        disabled={column === "willType" && canonicalFilingMedium !== undefined}
                        description={column === "willType" && canonicalFilingMedium ? "The original filing type selected above also sets the Type of Will." : undefined}
                        onChange={value => {
                          canonicalInputVersionsRef.current[column] = (canonicalInputVersionsRef.current[column] ?? 0) + 1;
                          if (column === "willAlterationTypes") setCanonicalAppearanceRemovalPending(pending =>
                            canonicalAppearanceRemoval({ willAlterationTypes: value }, canonicalBaseRecord, canonicalOffered, pending));
                          setCanonicalDraft(current => ({ ...current, [column]: value }));
                        }}
                      />)}
                      {canonicalColumns.length > 0 && ownCanonicalColumns.length === 0 && (
                        <p className="text-xs text-muted-foreground">Use the same answer elsewhere in this popup for this item.</p>
                      )}
                      {ownCanonicalColumns.length > 0 && ownCanonicalColumns.every(column => !canonicalFieldActive(column, canonicalRecord, canonicalClearsAppearance)) && (
                        <p className="text-xs text-muted-foreground">Apply your changed answer to re-check this item.</p>
                      )}
                      {editableColumns.map((column) => (
                        <React.Fragment key={column}>
                          {renderEditor(column, INLINE_FIELD_CONTROLS[column]!)}
                          {column === "spouseStatus" && renderWesaFollowUpEditors()}
                        </React.Fragment>
                      ))}
                      {editableDocKeys.map((docKey) => renderDocEditor(docKey))}
                      {rowGroups.map((group) => (
                        <div key={group.key} className="space-y-2 rounded-lg border border-border/70 bg-background/70 p-2.5 shadow-sm sm:p-3" data-testid={`pre-generate-row-${group.key}`}>
                          <p className="text-xs font-semibold">{group.rowLabel}</p>
                          {group.editors.map((editor) => renderRowEditor(editor))}
                        </div>
                      ))}
                      {hasQuickAdd && `${formCode}:${gap.requirementId}` === firstQuickAddGapKey && renderQuickAdd()}
                      {p1Editor}
                      {p8PrimaryEditor}
                      {typeof gap.editorsTruncated === "number" && gap.editorsTruncated > 0 && (
                        <p className="text-[10px] text-muted-foreground" data-testid={`pre-generate-truncated-${gap.requirementId}`}>
                          +{gap.editorsTruncated} more — use Go to {tabLabel(gap.tab)}.
                        </p>
                      )}
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )}

        {anyEstateEditors && !isReady && !isCanonicalCompletionForm && (
          <div className="flex items-center gap-2.5 rounded-lg border border-border/70 bg-muted/25 px-3 py-2.5" data-testid="pre-generate-save-row">
            <Checkbox
              id="pre-generate-save-to-intake"
              checked={saveToIntake}
              onCheckedChange={(checked) => setSaveToIntake(checked === true)}
              data-testid="pre-generate-save-to-intake"
            />
            <Label htmlFor="pre-generate-save-to-intake" className="cursor-pointer text-xs font-medium">
              Also save these to the intake
            </Label>
          </div>
        )}
        {isCanonicalCompletionForm && anyEditors && (!isReady || hasPendingCanonicalRows || showP16AlterationEditor) && (
          <p className="rounded-lg border border-border/70 bg-muted/25 px-3 py-2.5 text-[11px] leading-relaxed text-muted-foreground" data-testid="pre-generate-p1-canonical-save-note">
            {isP1Only ? "P1" : isP2Only ? "P2" : isP3Only ? "P3" : isP4Only ? "P4" : isP5Only ? "P5" : isP6Only ? "P6" : isP7Only ? "P7" : isP8Only ? "P8" : isP9Only ? "P9" : isP10Only ? "P10" : isP11Only ? "P11" : isP12Only ? "P12" : isP14Only ? "P14" : isP15Only ? "P15" : isP16Only ? "P16" : isP17Only ? "P17" : isP26Only ? "P26" : isP34Only ? "P34" : isP44Only ? "P44" : isP45Only ? "P45" : isP46Only ? "P46" : isVsa532Only ? "VSA 532" : "PGT_INFO"} corrections are saved to the estate record before the form is re-checked.
          </p>
        )}
        {anyCanonicalEditors && (!isReady || hasPendingCanonicalRows) && (
          <p className="rounded-lg border border-border/70 bg-muted/25 px-3 py-2.5 text-[11px] leading-relaxed text-muted-foreground" data-testid="pre-generate-canonical-save-note">
            These additional Intake answers are saved to the estate record before the form is re-checked. Unanswered fields remain warnings.
          </p>
        )}
        {anyRowEditors && !isReady && (
          <p className="rounded-lg border border-border/70 bg-muted/25 px-3 py-2.5 text-[11px] leading-relaxed text-muted-foreground" data-testid="pre-generate-row-save-note">
            Contact and inventory entries save to the estate record when you apply — the document reads them from the file.
          </p>
        )}

        <DialogFooter className="mt-0 gap-2.5 border-t border-border/70 pt-3 [&>button]:w-full sm:mt-1 sm:gap-3 sm:pt-4 sm:[&>button]:w-auto">
          <Button variant="ghost" className="h-10 px-3 text-muted-foreground hover:bg-muted" onClick={onCancel} data-testid="pre-generate-cancel">
            Cancel
          </Button>
          {anyEditors && (!isReady || hasPendingCanonicalRows || showP16AlterationEditor) && (
            <Button
              variant="secondary"
              className="h-10 border border-border/80 bg-secondary px-3.5 shadow-sm transition-[transform,box-shadow] duration-150 hover:shadow-md active:scale-[0.97]"
              disabled={!hasChanges || applying === true || proceeding === true}
              onClick={() => { void handleApply(); }}
              data-testid="pre-generate-apply"
            >
              {applying === true ? "Checking…" : "Apply & re-check"}
            </Button>
          )}
          {naOnlyHardBlock && typeof onOverrideNotApplicable === "function" ? (
            // Rule 24: a user-initiated single-form action never dead-ends on
            // the not-applicable verdict — this re-routes through the
            // applicability popup, which re-enters with generateAnyway.
            // Addendum 24.1: offered ONLY when the na verdict is the sole hard
            // blocker — if a kept sworn-truth gate (Rule 5/14/15 class) also
            // hard-blocks, the escape would loop (generateAnyway lifts na but
            // not those), so the honest Blocked button stays.
            <Button className="h-10 px-3.5 shadow-sm transition-[transform,box-shadow] duration-150 hover:shadow-md active:scale-[0.97]" onClick={onOverrideNotApplicable} data-testid="pre-generate-override-na">
              Answer &amp; {actionWord} anyway
            </Button>
          ) : (
            <Button
              className="h-10 px-3.5 shadow-sm transition-[transform,box-shadow] duration-150 hover:shadow-md active:scale-[0.97]"
              onClick={() => { void handleProceed(); }}
              disabled={proceeding === true || applying === true || hardBlocked || p45LockStatusRequired}
              data-testid="pre-generate-proceed"
            >
              {hardBlocked ? "Blocked" : p45LockStatusRequired ? "Select lock status to continue" : proceeding === true || applying === true ? `${actionLabel}…` : isReady ? hasChanges ? `Save & ${actionLabel}` : actionLabel : hasChanges ? `Save & ${actionLabel} anyway` : `${actionLabel} anyway`}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Exported for testing.
export const __test = { tabLabel, gapMode };
