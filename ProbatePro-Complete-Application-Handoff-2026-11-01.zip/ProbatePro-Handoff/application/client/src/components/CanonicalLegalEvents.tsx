import React, { useState } from "react";
import type { inferRouterInputs, inferRouterOutputs } from "@trpc/server";
import {
  AlertCircle,
  CheckCircle2,
  Clock3,
  FileCheck2,
  FilePlus2,
  FileText,
  Pencil,
  Plus,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { previewStoredFile } from "@/lib/utils";

import { trpc } from "@/lib/trpc";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  addMonths,
  fmtDateLong,
  parseYmd,
  todayIn,
} from "@shared/date-utils";
import { evaluateP34Citation } from "@shared/types";
import type { AppRouter } from "../../../server/routers";

type RouterInputs = inferRouterInputs<AppRouter>;
type RouterOutputs = inferRouterOutputs<AppRouter>;
type CitationRecord = RouterOutputs["citation"]["list"][number];
type CitationData = Required<RouterInputs["citation"]["create"]["data"]>;
type CitationResponseType = CitationData["responseType"];
type CitationServiceRoute = CitationData["serviceProofRoute"];
type PgtDeliveryRecord = RouterOutputs["pgtDocumentDelivery"]["list"][number];
type GeneratedDocument = RouterOutputs["document"]["list"][number];
type PgtDeliveryData = {
  documentId: string;
  formCode: string;
  documentName: string;
  filedDate: string;
  deliveredDate: string;
  notes: string;
};
type EvidenceKind = RouterInputs["citation"]["uploadEvidence"]["kind"];

type CitationTrackerProps = {
  estateId: string;
  onPreviewP34?: (citationRecordId: string) => void;
  onGenerateP34?: (citationRecordId: string) => void;
  /** Opens the document-details dialog for this specific citation. */
  onOpenP34Details?: (citationRecordId: string, citedName: string) => void;
};

type PgtDocumentDeliveryTrackerProps = {
  estateId: string;
};

type PendingEvidence = {
  file: File;
  kind: EvidenceKind;
};

type EvidenceMetadata = {
  storageKey: string;
  fileName: string;
  mimeType: string;
};

type CitationState = {
  label: string;
  detail: string;
  tone: "neutral" | "waiting" | "complete" | "action" | "incomplete";
  p34Available: boolean;
};

const MAX_EVIDENCE_BYTES = 20 * 1024 * 1024;
const EVIDENCE_ACCEPT = ".pdf,.doc,.docx,.png,.jpg,.jpeg,.tif,.tiff";
const MANUAL_CONTACT = "__manual__";
const EXTERNAL_DOCUMENT = "__external__";

const RESPONSE_OPTIONS: Array<{
  value: CitationResponseType;
  label: string;
  help: string;
}> = [
  {
    value: "no_response",
    label: "No response served",
    help: "No document referred to in Rule 25-11 (4) was served within 14 days.",
  },
  {
    value: "grant_copy",
    label: "Copy of grant served",
    help: "The cited person served a copy of an issued grant.",
  },
  {
    value: "filed_submission",
    label: "Filed submission materials served",
    help: "The cited person served the filed submission and accompanying filed documents.",
  },
  {
    value: "p1_documents",
    label: "Rule 25-2 notice documents served",
    help: "The cited person served the notice documents for an intended probate application.",
  },
  {
    value: "p33_will_apply",
    label: "P33 — will apply",
    help: "The cited person answered that they will obtain the grant within six months or a court-extended period.",
  },
  {
    value: "p33_refuses",
    label: "P33 — refuses to apply",
    help: "The cited person answered that they refuse to apply and are deemed to have renounced.",
  },
];

const EMPTY_CITATION: CitationData = {
  citorContactId: "",
  citorName: "",
  citorAddress: "",
  citorOccupation: "",
  citedContactId: "",
  citedName: "",
  citationStorageKey: "",
  citationFileName: "",
  citationMimeType: "",
  serviceProofRoute: "citor_personal",
  servedDate: "",
  servedTime: "",
  servedCityCountry: "",
  serviceAffidavitDate: "",
  serviceAffidavitDeponentName: "",
  serviceAffidavitStorageKey: "",
  serviceAffidavitFileName: "",
  serviceAffidavitMimeType: "",
  responseType: "no_response",
  responseServedDate: "",
  responseStorageKey: "",
  responseFileName: "",
  responseMimeType: "",
  citedGrantIssuedDate: "",
  extensionUntilDate: "",
};

const EMPTY_PGT_DELIVERY: PgtDeliveryData = {
  documentId: "",
  formCode: "",
  documentName: "",
  filedDate: "",
  deliveredDate: "",
  notes: "",
};

function queryErrorMessage(error: unknown, fallback: string): string {
  if (
    error &&
    typeof error === "object" &&
    "message" in error &&
    typeof error.message === "string"
  ) {
    return error.message;
  }
  return fallback;
}

function legalEvidenceMimeType(file: File): string {
  if (file.type) return file.type.toLowerCase();
  const extension = file.name.split(".").pop()?.toLowerCase();
  return (
    {
      pdf: "application/pdf",
      doc: "application/msword",
      docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      png: "image/png",
      jpg: "image/jpeg",
      jpeg: "image/jpeg",
      tif: "image/tiff",
      tiff: "image/tiff",
    }[extension || ""] || ""
  );
}

function validateEvidenceFile(file: File): string | null {
  if (file.size === 0) return "The selected file is empty.";
  if (file.size > MAX_EVIDENCE_BYTES)
    return "The selected file exceeds the 20 MB limit.";
  if (!legalEvidenceMimeType(file)) {
    return "Upload a PDF, DOC/DOCX, PNG, JPG, or TIFF file.";
  }
  return null;
}

async function fileToBase64(file: File): Promise<string> {
  return await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error(`Unable to read ${file.name}.`));
    reader.onload = () => {
      const value = typeof reader.result === "string" ? reader.result : "";
      const comma = value.indexOf(",");
      if (comma < 0 || !value.slice(comma + 1)) {
        reject(new Error(`Unable to read ${file.name}.`));
        return;
      }
      resolve(value.slice(comma + 1));
    };
    reader.readAsDataURL(file);
  });
}

function responseOption(value: CitationResponseType) {
  return (
    RESPONSE_OPTIONS.find(option => option.value === value) ||
    RESPONSE_OPTIONS[0]
  );
}

function asCitationData(record: CitationRecord): CitationData {
  return {
    citorContactId: record.citorContactId || "",
    citorName: record.citorName || "",
    citorAddress: record.citorAddress || "",
    citorOccupation: record.citorOccupation || "",
    citedContactId: record.citedContactId || "",
    citedName: record.citedName || "",
    citationStorageKey: record.citationStorageKey || "",
    citationFileName: record.citationFileName || "",
    citationMimeType: record.citationMimeType || "",
    serviceProofRoute: (record.serviceProofRoute ||
      "citor_personal") as CitationServiceRoute,
    servedDate: record.servedDate || "",
    servedTime: record.servedTime || "",
    servedCityCountry: record.servedCityCountry || "",
    serviceAffidavitDate: record.serviceAffidavitDate || "",
    serviceAffidavitDeponentName: record.serviceAffidavitDeponentName || "",
    serviceAffidavitStorageKey: record.serviceAffidavitStorageKey || "",
    serviceAffidavitFileName: record.serviceAffidavitFileName || "",
    serviceAffidavitMimeType: record.serviceAffidavitMimeType || "",
    responseType: (record.responseType ||
      "no_response") as CitationResponseType,
    responseServedDate: record.responseServedDate || "",
    responseStorageKey: record.responseStorageKey || "",
    responseFileName: record.responseFileName || "",
    responseMimeType: record.responseMimeType || "",
    citedGrantIssuedDate: record.citedGrantIssuedDate || "",
    extensionUntilDate: record.extensionUntilDate || "",
  };
}

function asPgtDeliveryData(record: PgtDeliveryRecord): PgtDeliveryData {
  return {
    documentId: record.documentId || "",
    formCode: record.formCode || "",
    documentName: record.documentName || "",
    filedDate: record.filedDate || "",
    deliveredDate: record.deliveredDate || "",
    notes: record.notes || "",
  };
}

/**
 * Pre-save check for a linked citor contact. Mirrors the server exactly:
 * citation.create/update canonicalizes the sworn citor address from
 * residentialAddress only (routers.citationContactAddress) and 400s when it is
 * blank — accepting postal/address-for-service here produced a save-time error.
 */
export function citorContactIssue(
  contact:
    | { name?: string | null; residentialAddress?: string | null; occupation?: string | null }
    | undefined
): string | null {
  if (!contact)
    return "Select a citor who belongs to this estate, or enter the citor manually.";
  if (!contact.name?.trim()) return "The selected citor contact needs a name.";
  if (!contact.residentialAddress?.trim())
    return "The selected citor contact needs a residential address.";
  if (!contact.occupation?.trim())
    return "The selected citor contact needs an occupation.";
  return null;
}

export function citationState(
  record: Pick<
    CitationRecord,
    | "servedDate"
    | "responseType"
    | "responseServedDate"
    | "citedGrantIssuedDate"
    | "extensionUntilDate"
    | "citationStorageKey"
    | "citationFileName"
    | "citorName"
    | "citorAddress"
    | "citorOccupation"
    | "citedName"
    | "serviceProofRoute"
    | "servedTime"
    | "servedCityCountry"
    | "serviceAffidavitDate"
    | "serviceAffidavitDeponentName"
    | "serviceAffidavitStorageKey"
    | "serviceAffidavitFileName"
    | "responseStorageKey"
    | "responseFileName"
  >,
  today = todayIn("America/Vancouver")
): CitationState {
  if (
    !record.citationStorageKey ||
    !record.citationFileName ||
    !parseYmd(record.servedDate) ||
    !record.citorName ||
    !record.citorAddress ||
    !record.citorOccupation ||
    !record.citedName
  ) {
    return {
      label: "Record incomplete",
      detail:
        "Complete the party details, upload the citation, and record its personal-service date.",
      tone: "incomplete",
      p34Available: false,
    };
  }
  if (
    record.serviceProofRoute === "citor_personal" &&
    (!record.servedTime || !record.servedCityCountry)
  ) {
    return {
      label: "Service details missing",
      detail:
        "Record the time, city, and country where the citor personally served the citation.",
      tone: "incomplete",
      p34Available: false,
    };
  }
  if (
    record.serviceProofRoute === "supporting_affidavit" &&
    (!record.serviceAffidavitStorageKey ||
      !record.serviceAffidavitFileName ||
      !record.serviceAffidavitDate ||
      !record.serviceAffidavitDeponentName)
  ) {
    return {
      label: "Service proof missing",
      detail:
        "Upload the supporting affidavit of service before preparing P34.",
      tone: "incomplete",
      p34Available: false,
    };
  }
  if (record.citedGrantIssuedDate) {
    return {
      label: "Grant recorded",
      detail: `Grant issued ${fmtDateLong(record.citedGrantIssuedDate)}.`,
      tone: "complete",
      p34Available: false,
    };
  }
  if (record.responseType === "grant_copy") {
    return {
      label: "Grant copy response",
      detail: "The cited person responded with a copy of the grant.",
      tone: "complete",
      p34Available: false,
    };
  }
  if (record.responseType === "p33_refuses") {
    const complete = Boolean(
      record.responseServedDate && record.responseStorageKey && record.responseFileName
    );
    return {
      label: complete ? "Deemed renunciation" : "P33 response incomplete",
      detail: complete
        ? "The P33 refusal branch supports preparing Form P34."
        : "Record the service date and upload the served Form P33 refusal.",
      tone: complete ? "action" : "incomplete",
      p34Available: complete,
    };
  }
  if (
    ["filed_submission", "p1_documents", "p33_will_apply"].includes(record.responseType) &&
    (!record.responseServedDate || !record.responseStorageKey || !record.responseFileName)
  ) {
    return {
      label: "Response evidence incomplete",
      detail: "Record the service date and upload the Rule 25-11 response documents that were served.",
      tone: "incomplete",
      p34Available: false,
    };
  }
  if (record.responseType !== "no_response" && !record.responseServedDate) {
    return {
      label: "Response incomplete",
      detail: "Record the date the response documents were served.",
      tone: "incomplete",
      p34Available: false,
    };
  }
  if (record.responseType === "no_response") {
    if (record.responseServedDate || record.responseStorageKey || record.responseFileName) {
      return {
        label: "Conflicting response evidence",
        detail: "Remove the served-response facts or choose the response that was actually served.",
        tone: "incomplete",
        p34Available: false,
      };
    }
    const evaluation = evaluateP34Citation(record, today);
    const available = evaluation.eligible;
    return {
      label: available ? "14 days elapsed" : "Awaiting 14-day response period",
      detail: evaluation.deadline
        ? available
          ? `The response period ended on ${fmtDateLong(evaluation.deadline)}.`
          : `The response period runs through ${fmtDateLong(evaluation.deadline)}.`
        : evaluation.reason,
      tone: available ? "action" : "waiting",
      p34Available: available,
    };
  }
  const evaluation = evaluateP34Citation(record, today);
  const available = evaluation.eligible;
  return {
    label: available ? "Grant period elapsed" : "Awaiting grant period",
    detail: evaluation.deadline
      ? available
        ? `No grant is recorded after the period ending ${fmtDateLong(evaluation.deadline)}.`
        : `The grant period runs through ${fmtDateLong(evaluation.deadline)}.`
      : evaluation.reason,
    tone: evaluation.status === "invalid" ? "incomplete" : available ? "action" : "waiting",
    p34Available: available,
  };
}

function StatusBadge({ state }: { state: CitationState }) {
  const styles = {
    neutral: "border-slate-200 bg-slate-50 text-slate-700",
    waiting: "border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-800 dark:bg-amber-950/30 dark:text-amber-300",
    complete: "border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-300",
    action: "border-blue-200 bg-blue-50 text-blue-800 dark:border-blue-800 dark:bg-blue-950/30 dark:text-blue-300",
    incomplete: "border-red-200 bg-red-50 text-red-800 dark:border-red-800 dark:bg-red-950/30 dark:text-red-300",
  }[state.tone];
  const Icon =
    state.tone === "complete"
      ? CheckCircle2
      : state.tone === "waiting"
        ? Clock3
        : state.tone === "action"
          ? FileCheck2
          : AlertCircle;
  return (
    <Badge variant="outline" className={styles}>
      <Icon aria-hidden="true" />
      {state.label}
    </Badge>
  );
}

function EvidenceField({
  id,
  label,
  description,
  currentFileName,
  storageKey,
  pending,
  required,
  disabled,
  onSelect,
  onClear,
}: {
  id: string;
  label: string;
  description: string;
  currentFileName: string;
  /** Stored key of the already-uploaded evidence; enables the View button. */
  storageKey?: string;
  pending?: PendingEvidence;
  required?: boolean;
  disabled?: boolean;
  onSelect: (file: File) => void;
  onClear: () => void;
}) {
  const displayName = pending?.file.name || currentFileName;
  return (
    <div className="space-y-2 rounded-lg border bg-muted/20 p-3">
      <div className="space-y-1">
        <Label htmlFor={id}>
          {label}
          {required ? " *" : ""}
        </Label>
        <p id={`${id}-description`} className="text-xs text-muted-foreground">
          {description}
        </p>
      </div>
      {displayName ? (
        <div className="flex flex-wrap items-center justify-between gap-2 rounded-md border bg-background px-3 py-2 text-sm">
          <span className="flex min-w-0 items-center gap-2">
            <FileText
              className="size-4 shrink-0 text-primary"
              aria-hidden="true"
            />
            <span className="truncate">{displayName}</span>
            {pending && <Badge variant="secondary">Ready to upload</Badge>}
          </span>
          <span className="flex items-center gap-1">
            {!pending && storageKey && (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => void previewStoredFile(storageKey)}
              >
                View
              </Button>
            )}
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={onClear}
              disabled={disabled}
            >
              Remove
            </Button>
          </span>
        </div>
      ) : (
        <Input
          id={id}
          type="file"
          accept={EVIDENCE_ACCEPT}
          aria-describedby={`${id}-description`}
          disabled={disabled}
          onChange={event => {
            const file = event.target.files?.[0];
            if (file) onSelect(file);
            event.currentTarget.value = "";
          }}
        />
      )}
    </div>
  );
}

function TrackerLoading() {
  return (
    <div className="space-y-3" aria-label="Loading records">
      <Skeleton className="h-24 w-full" />
      <Skeleton className="h-24 w-full" />
    </div>
  );
}

export function CitationTracker({
  estateId,
  onPreviewP34,
  onGenerateP34,
  onOpenP34Details,
}: CitationTrackerProps) {
  const utils = trpc.useUtils();
  const citationsQuery = trpc.citation.list.useQuery({ estateId });
  const contactsQuery = trpc.contact.list.useQuery({ estateId });
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<CitationData>(EMPTY_CITATION);
  const [pendingEvidence, setPendingEvidence] = useState<
    Partial<Record<EvidenceKind, PendingEvidence>>
  >({});
  const [editorError, setEditorError] = useState("");
  const [deleteRecord, setDeleteRecord] = useState<CitationRecord | null>(null);

  const invalidateConnectedQueries = async () => {
    await Promise.all([
      utils.citation.list.invalidate({ estateId }),
      utils.readiness.check.invalidate({ estateId }),
      utils.readiness.timeline.invalidate({ estateId }),
      utils.deadline.list.invalidate(),
      utils.document.list.invalidate({ estateId }),
      utils.document.preflight.invalidate(),
      utils.document.preflightMany.invalidate(),
    ]);
  };

  const createMutation = trpc.citation.create.useMutation();
  const updateMutation = trpc.citation.update.useMutation();
  const deleteMutation = trpc.citation.delete.useMutation();
  const uploadMutation = trpc.citation.uploadEvidence.useMutation();
  const saving =
    createMutation.isPending ||
    updateMutation.isPending ||
    uploadMutation.isPending;

  const openNew = () => {
    setEditingId(null);
    setDraft({ ...EMPTY_CITATION });
    setPendingEvidence({});
    setEditorError("");
    setEditorOpen(true);
  };

  const openEdit = (record: CitationRecord) => {
    setEditingId(record.id);
    setDraft(asCitationData(record));
    setPendingEvidence({});
    setEditorError("");
    setEditorOpen(true);
  };

  const setField = <K extends keyof CitationData>(
    field: K,
    value: CitationData[K]
  ) => {
    setDraft(current => ({ ...current, [field]: value }));
  };

  const selectEvidence = (kind: EvidenceKind, file: File) => {
    const issue = validateEvidenceFile(file);
    if (issue) {
      setEditorError(issue);
      return;
    }
    setEditorError("");
    setPendingEvidence(current => ({ ...current, [kind]: { file, kind } }));
  };

  const clearEvidence = (kind: EvidenceKind) => {
    setPendingEvidence(current => ({ ...current, [kind]: undefined }));
    if (kind === "citation") {
      setDraft(current => ({
        ...current,
        citationStorageKey: "",
        citationFileName: "",
        citationMimeType: "",
      }));
    } else if (kind === "service_affidavit") {
      setDraft(current => ({
        ...current,
        serviceAffidavitStorageKey: "",
        serviceAffidavitFileName: "",
        serviceAffidavitMimeType: "",
      }));
    } else {
      setDraft(current => ({
        ...current,
        responseStorageKey: "",
        responseFileName: "",
        responseMimeType: "",
      }));
    }
  };

  const validateDraft = (): string | null => {
    if (draft.citorContactId) {
      const citorIssue = citorContactIssue(
        contacts.find(contact => contact.id === draft.citorContactId)
      );
      if (citorIssue) return citorIssue;
    } else {
      if (!draft.citorName.trim()) return "Enter or select the citor's name.";
      if (!draft.citorAddress.trim()) return "Enter the citor's address.";
      if (!draft.citorOccupation.trim()) return "Enter the citor's occupation.";
    }
    if (draft.citedContactId) {
      const selectedCited = contacts.find(
        contact => contact.id === draft.citedContactId
      );
      if (!selectedCited?.name?.trim())
        return "The selected cited-executor contact needs a name.";
    } else if (!draft.citedName.trim()) {
      return "Enter or select the cited executor.";
    }
    if (!parseYmd(draft.servedDate))
      return "Enter the citation's personal-service date.";
    if (draft.servedDate > todayIn("America/Vancouver"))
      return "The personal-service date cannot be in the future.";
    if (draft.serviceProofRoute === "citor_personal") {
      if (!draft.servedTime.trim())
        return "Enter the time of personal service.";
      if (!draft.servedCityCountry.trim())
        return "Enter the city and country of personal service.";
    } else {
      if (!parseYmd(draft.serviceAffidavitDate))
        return "Enter the supporting affidavit's date.";
      if (!draft.serviceAffidavitDeponentName.trim())
        return "Enter the supporting affidavit deponent's name.";
      if (
        !draft.serviceAffidavitStorageKey &&
        !pendingEvidence.service_affidavit
      ) {
        return "Upload the supporting affidavit of service.";
      }
    }
    if (!draft.citationStorageKey && !pendingEvidence.citation)
      return "Upload the served citation.";
    if (
      draft.responseType !== "no_response" &&
      !parseYmd(draft.responseServedDate)
    ) {
      return "Enter the date the response documents were served.";
    }
    if (
      draft.responseServedDate &&
      draft.responseServedDate < draft.servedDate
    ) {
      return "The response service date cannot be before the citation service date.";
    }
    if (
      draft.responseType !== "no_response" &&
      !draft.responseStorageKey &&
      !pendingEvidence.response
    ) {
      return "Upload the Rule 25-11 response documents that were served.";
    }
    if (draft.citedGrantIssuedDate && !parseYmd(draft.citedGrantIssuedDate))
      return "Enter a valid grant-issued date.";
    if (draft.responseType === "grant_copy" && !draft.citedGrantIssuedDate) {
      return "Record the grant-issued date for the grant-copy response branch.";
    }
    if (draft.extensionUntilDate && !parseYmd(draft.extensionUntilDate))
      return "Enter a valid court-extension date.";
    if (
      draft.extensionUntilDate &&
      draft.extensionUntilDate <= addMonths(draft.servedDate, 6)
    ) {
      return "A court-extended period must end after the ordinary six-month grant period.";
    }
    return null;
  };

  const uploadPendingEvidence = async (
    next: CitationData
  ): Promise<CitationData> => {
    let result = { ...next };
    for (const kind of ["citation", "service_affidavit", "response"] as const) {
      const pending = pendingEvidence[kind];
      if (!pending) continue;
      const uploaded = await uploadMutation.mutateAsync({
        estateId,
        citationRecordId: editingId || undefined,
        kind,
        fileBase64: await fileToBase64(pending.file),
        fileName: pending.file.name,
        mimeType: legalEvidenceMimeType(pending.file),
      });
      const metadata: EvidenceMetadata = {
        storageKey: uploaded.key,
        fileName: uploaded.fileName,
        mimeType: uploaded.mimeType,
      };
      if (kind === "citation") {
        result = {
          ...result,
          citationStorageKey: metadata.storageKey,
          citationFileName: metadata.fileName,
          citationMimeType: metadata.mimeType,
        };
      } else if (kind === "service_affidavit") {
        result = {
          ...result,
          serviceAffidavitStorageKey: metadata.storageKey,
          serviceAffidavitFileName: metadata.fileName,
          serviceAffidavitMimeType: metadata.mimeType,
        };
      } else {
        result = {
          ...result,
          responseStorageKey: metadata.storageKey,
          responseFileName: metadata.fileName,
          responseMimeType: metadata.mimeType,
        };
      }
    }
    return result;
  };

  const saveCitation = async () => {
    const issue = validateDraft();
    if (issue) {
      setEditorError(issue);
      return;
    }
    setEditorError("");
    try {
      let payload = await uploadPendingEvidence(draft);
      if (payload.serviceProofRoute === "citor_personal") {
        payload = {
          ...payload,
          serviceAffidavitDate: "",
          serviceAffidavitDeponentName: "",
          serviceAffidavitStorageKey: "",
          serviceAffidavitFileName: "",
          serviceAffidavitMimeType: "",
        };
      } else {
        payload = { ...payload, servedTime: "", servedCityCountry: "" };
      }
      if (payload.responseType === "no_response") {
        payload = {
          ...payload,
          responseServedDate: "",
          responseStorageKey: "",
          responseFileName: "",
          responseMimeType: "",
        };
      }
      if (editingId) {
        await updateMutation.mutateAsync({
          id: editingId,
          estateId,
          data: payload,
        });
      } else {
        await createMutation.mutateAsync({ estateId, data: payload });
      }
      await invalidateConnectedQueries();
      setEditorOpen(false);
      toast.success(
        editingId ? "Citation record updated" : "Citation record added"
      );
    } catch (error) {
      const message = queryErrorMessage(
        error,
        "Unable to save the citation record."
      );
      setEditorError(message);
      toast.error(message);
    }
  };

  const confirmDelete = async () => {
    if (!deleteRecord) return;
    try {
      await deleteMutation.mutateAsync({ id: deleteRecord.id, estateId });
      setDeleteRecord(null);
      await invalidateConnectedQueries();
      toast.success("Citation record deleted");
    } catch (error) {
      const message = queryErrorMessage(
        error,
        "Unable to delete the citation record."
      );
      toast.error(message);
    }
  };

  const queryErrors = [citationsQuery.error, contactsQuery.error].filter(
    Boolean
  );
  const records = citationsQuery.data || [];
  const contacts = contactsQuery.data || [];

  return (
    <Card>
      <CardHeader className="gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="space-y-1.5">
          <CardTitle className="flex items-center gap-2 text-lg">
            <FileText className="size-5 text-primary" aria-hidden="true" />
            Citation tracker
          </CardTitle>
          <CardDescription>
            Keep one Rule 25-11 record for each cited executor. Form P34 is
            available only when the recorded response branch supports deemed
            renunciation.
          </CardDescription>
        </div>
        <Button type="button" size="sm" onClick={openNew}>
          <Plus aria-hidden="true" />
          Add citation
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        {queryErrors.map((error, index) => (
          <Alert key={index} variant="destructive">
            <AlertCircle aria-hidden="true" />
            <AlertTitle>Unable to load citation data</AlertTitle>
            <AlertDescription>
              {queryErrorMessage(error, "Please try again.")}
            </AlertDescription>
          </Alert>
        ))}
        {citationsQuery.error ? null : citationsQuery.isLoading ? (
          <TrackerLoading />
        ) : records.length === 0 ? (
          <div className="rounded-lg border border-dashed px-5 py-8 text-center">
            <FilePlus2
              className="mx-auto mb-3 size-6 text-muted-foreground"
              aria-hidden="true"
            />
            <p className="font-medium">No citations recorded</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Add the served citation and response history for each cited
              executor.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {records.map(record => {
              const state = citationState(record);
              return (
                <article
                  key={record.id}
                  className="rounded-xl border p-4"
                  aria-labelledby={`citation-${record.id}-title`}
                >
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                    <div className="min-w-0 space-y-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3
                          id={`citation-${record.id}-title`}
                          className="font-semibold"
                        >
                          {record.citedName || "Unnamed cited executor"}
                        </h3>
                        <StatusBadge state={state} />
                      </div>
                      <dl className="grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
                        <div>
                          <dt className="inline text-muted-foreground">
                            Citor:{" "}
                          </dt>
                          <dd className="inline">
                            {record.citorName || "Not recorded"}
                          </dd>
                        </div>
                        <div>
                          <dt className="inline text-muted-foreground">
                            Served:{" "}
                          </dt>
                          <dd className="inline">
                            {fmtDateLong(record.servedDate) || "Not recorded"}
                          </dd>
                        </div>
                        <div>
                          <dt className="inline text-muted-foreground">
                            Response:{" "}
                          </dt>
                          <dd className="inline">
                            {
                              responseOption(
                                record.responseType as CitationResponseType
                              ).label
                            }
                          </dd>
                        </div>
                        <div>
                          <dt className="inline text-muted-foreground">
                            Citation file:{" "}
                          </dt>
                          <dd className="inline">
                            {record.citationFileName || "Missing"}
                          </dd>
                        </div>
                      </dl>
                      <p className="text-xs text-muted-foreground">
                        {state.detail}
                      </p>
                    </div>
                    <div className="flex shrink-0 flex-wrap gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => openEdit(record)}
                        aria-label={`Edit citation for ${record.citedName}`}
                      >
                        <Pencil aria-hidden="true" />
                        Edit
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setDeleteRecord(record)}
                        aria-label={`Delete citation for ${record.citedName}`}
                      >
                        <Trash2 aria-hidden="true" />
                        Delete
                      </Button>
                    </div>
                  </div>
                  {state.p34Available && (
                    <div className="mt-4 flex flex-wrap gap-2 border-t pt-3">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => onOpenP34Details ? onOpenP34Details(record.id, record.citedName) : onPreviewP34?.(record.id)}
                      >
                        Preview P34
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        onClick={() => onOpenP34Details ? onOpenP34Details(record.id, record.citedName) : onGenerateP34?.(record.id)}
                      >
                        Generate P34
                      </Button>
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        )}
      </CardContent>

      <Dialog
        open={editorOpen}
        onOpenChange={open => !saving && setEditorOpen(open)}
      >
        <DialogContent className="sm:max-w-3xl">
          <DialogHeader>
            <DialogTitle>
              {editingId ? "Edit citation record" : "Add citation record"}
            </DialogTitle>
            <DialogDescription>
              Record the actual citation, personal service, and the cited
              executor's response. Dates are calendar dates and are not
              converted through a browser timezone.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {editorError && (
              <Alert variant="destructive">
                <AlertCircle aria-hidden="true" />
                <AlertTitle>Cannot save citation</AlertTitle>
                <AlertDescription>{editorError}</AlertDescription>
              </Alert>
            )}

            <section
              className="space-y-3"
              aria-labelledby="citation-parties-heading"
            >
              <h3 id="citation-parties-heading" className="font-semibold">
                People
              </h3>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="citation-citor-contact">Citor *</Label>
                  <Select
                    value={draft.citorContactId || MANUAL_CONTACT}
                    onValueChange={value =>
                      setField(
                        "citorContactId",
                        value === MANUAL_CONTACT ? "" : value
                      )
                    }
                  >
                    <SelectTrigger
                      id="citation-citor-contact"
                      className="w-full"
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={MANUAL_CONTACT}>
                        Enter manually
                      </SelectItem>
                      {contacts.map(contact => (
                        <SelectItem key={contact.id} value={contact.id}>
                          {contact.name || "Unnamed contact"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="citation-cited-contact">
                    Cited executor *
                  </Label>
                  <Select
                    value={draft.citedContactId || MANUAL_CONTACT}
                    onValueChange={value =>
                      setField(
                        "citedContactId",
                        value === MANUAL_CONTACT ? "" : value
                      )
                    }
                  >
                    <SelectTrigger
                      id="citation-cited-contact"
                      className="w-full"
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={MANUAL_CONTACT}>
                        Enter manually
                      </SelectItem>
                      {contacts.map(contact => (
                        <SelectItem key={contact.id} value={contact.id}>
                          {contact.name || "Unnamed contact"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              {!draft.citorContactId && (
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="citation-citor-name">Citor name *</Label>
                    <Input
                      id="citation-citor-name"
                      value={draft.citorName}
                      onChange={event =>
                        setField("citorName", event.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="citation-citor-occupation">
                      Citor occupation *
                    </Label>
                    <Input
                      id="citation-citor-occupation"
                      value={draft.citorOccupation}
                      onChange={event =>
                        setField("citorOccupation", event.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-2 sm:col-span-2">
                    <Label htmlFor="citation-citor-address">
                      Citor residential address *
                    </Label>
                    <Textarea
                      id="citation-citor-address"
                      value={draft.citorAddress}
                      onChange={event =>
                        setField("citorAddress", event.target.value)
                      }
                    />
                  </div>
                </div>
              )}
              {!draft.citedContactId && (
                <div className="space-y-2">
                  <Label htmlFor="citation-cited-name">
                    Cited executor name *
                  </Label>
                  <Input
                    id="citation-cited-name"
                    value={draft.citedName}
                    onChange={event =>
                      setField("citedName", event.target.value)
                    }
                  />
                  <p className="text-xs text-muted-foreground">
                    P34 requires the cited executor's name; their address and
                    occupation are not fields on the prescribed affidavit
                    record.
                  </p>
                </div>
              )}
            </section>

            <section
              className="space-y-3"
              aria-labelledby="citation-service-heading"
            >
              <h3 id="citation-service-heading" className="font-semibold">
                Citation and personal service
              </h3>
              <EvidenceField
                id="citation-file"
                label="Served citation"
                description="Upload the actual citation that will be marked as Exhibit A to Form P34."
                currentFileName={draft.citationFileName}
                storageKey={draft.citationStorageKey}
                pending={pendingEvidence.citation}
                required
                disabled={saving}
                onSelect={file => selectEvidence("citation", file)}
                onClear={() => clearEvidence("citation")}
              />
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="citation-served-date">
                    Date personally served *
                  </Label>
                  <Input
                    id="citation-served-date"
                    type="date"
                    value={draft.servedDate}
                    onChange={event =>
                      setField("servedDate", event.target.value)
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="citation-service-route">
                    Service proof used for P34 *
                  </Label>
                  <Select
                    value={draft.serviceProofRoute}
                    onValueChange={(value: CitationServiceRoute) =>
                      setField("serviceProofRoute", value)
                    }
                  >
                    <SelectTrigger
                      id="citation-service-route"
                      className="w-full"
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="citor_personal">
                        Citor personally served citation
                      </SelectItem>
                      <SelectItem value="supporting_affidavit">
                        Supporting affidavit of service
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              {draft.serviceProofRoute === "citor_personal" ? (
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="citation-served-time">
                      Time of service *
                    </Label>
                    <Input
                      id="citation-served-time"
                      type="time"
                      value={draft.servedTime}
                      onChange={event =>
                        setField("servedTime", event.target.value)
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="citation-served-location">
                      City and country of service *
                    </Label>
                    <Input
                      id="citation-served-location"
                      value={draft.servedCityCountry}
                      onChange={event =>
                        setField("servedCityCountry", event.target.value)
                      }
                      placeholder="Victoria, Canada"
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="citation-service-affidavit-date">
                        Affidavit of service date *
                      </Label>
                      <Input
                        id="citation-service-affidavit-date"
                        type="date"
                        value={draft.serviceAffidavitDate}
                        onChange={event =>
                          setField("serviceAffidavitDate", event.target.value)
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="citation-service-affidavit-deponent">
                        Affidavit deponent *
                      </Label>
                      <Input
                        id="citation-service-affidavit-deponent"
                        value={draft.serviceAffidavitDeponentName}
                        onChange={event =>
                          setField(
                            "serviceAffidavitDeponentName",
                            event.target.value
                          )
                        }
                      />
                    </div>
                  </div>
                  <EvidenceField
                    id="citation-service-affidavit-file"
                    label="Supporting affidavit of service"
                    description="Upload the affidavit that proves personal service of this citation."
                    currentFileName={draft.serviceAffidavitFileName}
                    storageKey={draft.serviceAffidavitStorageKey}
                    pending={pendingEvidence.service_affidavit}
                    required
                    disabled={saving}
                    onSelect={file => selectEvidence("service_affidavit", file)}
                    onClear={() => clearEvidence("service_affidavit")}
                  />
                </div>
              )}
            </section>

            <section
              className="space-y-3"
              aria-labelledby="citation-response-heading"
            >
              <h3 id="citation-response-heading" className="font-semibold">
                Response and grant
              </h3>
              <div className="space-y-2">
                <Label htmlFor="citation-response-type">
                  Response branch *
                </Label>
                <Select
                  value={draft.responseType}
                  onValueChange={(value: CitationResponseType) =>
                    setField("responseType", value)
                  }
                >
                  <SelectTrigger id="citation-response-type" className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {RESPONSE_OPTIONS.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  {responseOption(draft.responseType).help}
                </p>
              </div>
              {draft.responseType !== "no_response" && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="citation-response-date">
                      Date response served *
                    </Label>
                    <Input
                      id="citation-response-date"
                      type="date"
                      value={draft.responseServedDate}
                      onChange={event =>
                        setField("responseServedDate", event.target.value)
                      }
                    />
                  </div>
                  <EvidenceField
                    id="citation-response-file"
                    label={
                      draft.responseType.startsWith("p33_")
                        ? "Served Form P33"
                        : "Response evidence"
                    }
                    description={
                      draft.responseType.startsWith("p33_")
                        ? "Upload the actual Form P33 served by the cited executor. It is required for this branch."
                        : "Upload the grant copy, filed materials, or notice documents that were served. It is required for this response record."
                    }
                    currentFileName={draft.responseFileName}
                    storageKey={draft.responseStorageKey}
                    pending={pendingEvidence.response}
                    required
                    disabled={saving}
                    onSelect={file => selectEvidence("response", file)}
                    onClear={() => clearEvidence("response")}
                  />
                </div>
              )}
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="citation-grant-date">
                    Cited grant issued date
                  </Label>
                  <Input
                    id="citation-grant-date"
                    type="date"
                    value={draft.citedGrantIssuedDate}
                    onChange={event =>
                      setField("citedGrantIssuedDate", event.target.value)
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="citation-extension-date">
                    Court-extended grant deadline
                  </Label>
                  <Input
                    id="citation-extension-date"
                    type="date"
                    value={draft.extensionUntilDate}
                    onChange={event =>
                      setField("extensionUntilDate", event.target.value)
                    }
                  />
                  <p className="text-xs text-muted-foreground">
                    Leave blank unless the court allowed a longer period under
                    Rule 25-11 (5).
                  </p>
                </div>
              </div>
            </section>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setEditorOpen(false)}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button type="button" onClick={saveCitation} disabled={saving}>
              {saving ? "Saving…" : editingId ? "Save changes" : "Add citation"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={Boolean(deleteRecord)}
        onOpenChange={open =>
          !open && !deleteMutation.isPending && setDeleteRecord(null)
        }
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this citation record?</AlertDialogTitle>
            <AlertDialogDescription>
              This removes the tracked service, response, and evidence
              references for {deleteRecord?.citedName || "this cited executor"}.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteMutation.isPending}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {deleteMutation.isPending ? "Deleting…" : "Delete citation"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}

export function PgtDocumentDeliveryTracker({
  estateId,
}: PgtDocumentDeliveryTrackerProps) {
  const utils = trpc.useUtils();
  const deliveriesQuery = trpc.pgtDocumentDelivery.list.useQuery({ estateId });
  const documentsQuery = trpc.document.list.useQuery({ estateId });
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<PgtDeliveryData>(EMPTY_PGT_DELIVERY);
  const [editorError, setEditorError] = useState("");
  const [deleteRecord, setDeleteRecord] = useState<PgtDeliveryRecord | null>(
    null
  );

  const generatedDocuments: GeneratedDocument[] = documentsQuery.data || [];

  const invalidateConnectedQueries = async () => {
    await Promise.all([
      utils.pgtDocumentDelivery.list.invalidate({ estateId }),
      utils.readiness.check.invalidate({ estateId }),
      utils.readiness.timeline.invalidate({ estateId }),
      utils.deadline.list.invalidate(),
      utils.document.list.invalidate({ estateId }),
      utils.document.preflight.invalidate(),
      utils.document.preflightMany.invalidate(),
    ]);
  };

  const upsertMutation = trpc.pgtDocumentDelivery.upsert.useMutation();
  const deleteMutation = trpc.pgtDocumentDelivery.delete.useMutation();

  const openNew = () => {
    setEditingId(null);
    setDraft({ ...EMPTY_PGT_DELIVERY });
    setEditorError("");
    setEditorOpen(true);
  };

  const openEdit = (record: PgtDeliveryRecord) => {
    setEditingId(record.id);
    setDraft(asPgtDeliveryData(record));
    setEditorError("");
    setEditorOpen(true);
  };

  const setField = <K extends keyof PgtDeliveryData>(
    field: K,
    value: PgtDeliveryData[K]
  ) => {
    setDraft(current => ({ ...current, [field]: value }));
  };

  const saveDelivery = async () => {
    if (!draft.documentId && !draft.formCode.trim()) {
      setEditorError(
        "Enter the filed form code or select a generated document."
      );
      return;
    }
    if (!draft.documentId && !draft.documentName.trim()) {
      setEditorError("Enter the filed document name.");
      return;
    }
    if (!parseYmd(draft.filedDate)) {
      setEditorError("Enter the date the document was filed.");
      return;
    }
    if (draft.deliveredDate && !parseYmd(draft.deliveredDate)) {
      setEditorError("Enter a valid delivery date.");
      return;
    }
    if (draft.deliveredDate && draft.deliveredDate < draft.filedDate) {
      setEditorError("The PGT delivery date cannot be before the filed date.");
      return;
    }
    setEditorError("");
    try {
      await upsertMutation.mutateAsync({
        id: editingId || undefined,
        estateId,
        data: draft,
      });
      await invalidateConnectedQueries();
      setEditorOpen(false);
      toast.success(
        editingId ? "PGT delivery record updated" : "PGT delivery record added"
      );
    } catch (error) {
      const message = queryErrorMessage(
        error,
        "Unable to save the PGT delivery record."
      );
      setEditorError(message);
      toast.error(message);
    }
  };

  const confirmDelete = async () => {
    if (!deleteRecord) return;
    try {
      await deleteMutation.mutateAsync({ id: deleteRecord.id, estateId });
      setDeleteRecord(null);
      await invalidateConnectedQueries();
      toast.success("PGT delivery record deleted");
    } catch (error) {
      toast.error(
        queryErrorMessage(error, "Unable to delete the PGT delivery record.")
      );
    }
  };

  const queryErrors = [deliveriesQuery.error, documentsQuery.error].filter(
    Boolean
  );
  const records = deliveriesQuery.data || [];

  return (
    <Card>
      <CardHeader className="gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="space-y-1.5">
          <CardTitle className="flex items-center gap-2 text-lg">
            <FileCheck2 className="size-5 text-primary" aria-hidden="true" />
            Filed copies delivered to the PGT
          </CardTitle>
          <CardDescription>
            Rule 25-3 (11), or Rule 25-6 (9) for resealing, requires an
            applicable filed-document copy to be delivered to the Public
            Guardian and Trustee promptly after filing. “Promptly” is not a
            fixed numeric deadline.
          </CardDescription>
        </div>
        <Button type="button" size="sm" onClick={openNew}>
          <Plus aria-hidden="true" />
          Add filed copy
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        {queryErrors.map((error, index) => (
          <Alert key={index} variant="destructive">
            <AlertCircle aria-hidden="true" />
            <AlertTitle>Unable to load PGT delivery data</AlertTitle>
            <AlertDescription>
              {queryErrorMessage(error, "Please try again.")}
            </AlertDescription>
          </Alert>
        ))}
        {deliveriesQuery.error ? null : deliveriesQuery.isLoading ? (
          <TrackerLoading />
        ) : records.length === 0 ? (
          <div className="rounded-lg border border-dashed px-5 py-8 text-center">
            <FileCheck2
              className="mx-auto mb-3 size-6 text-muted-foreground"
              aria-hidden="true"
            />
            <p className="font-medium">No filed-copy deliveries recorded</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Record each applicable document after it is filed and delivered to
              the PGT.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {records.map(record => {
              const delivered = Boolean(record.deliveredDate);
              return (
                <article
                  key={record.id}
                  className="rounded-xl border p-4"
                  aria-labelledby={`pgt-delivery-${record.id}-title`}
                >
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                    <div className="min-w-0 space-y-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3
                          id={`pgt-delivery-${record.id}-title`}
                          className="font-semibold"
                        >
                          {record.formCode} — {record.documentName}
                        </h3>
                        <Badge
                          variant="outline"
                          className={
                            delivered
                              ? "border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-300"
                              : "border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-800 dark:bg-amber-950/30 dark:text-amber-300"
                          }
                        >
                          {delivered ? (
                            <CheckCircle2 aria-hidden="true" />
                          ) : (
                            <Clock3 aria-hidden="true" />
                          )}
                          {delivered ? "Delivered" : "Delivery not recorded"}
                        </Badge>
                      </div>
                      <dl className="grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
                        <div>
                          <dt className="inline text-muted-foreground">
                            Filed:{" "}
                          </dt>
                          <dd className="inline">
                            {fmtDateLong(record.filedDate) || "Not recorded"}
                          </dd>
                        </div>
                        <div>
                          <dt className="inline text-muted-foreground">
                            Delivered:{" "}
                          </dt>
                          <dd className="inline">
                            {fmtDateLong(record.deliveredDate) ||
                              "Not recorded"}
                          </dd>
                        </div>
                      </dl>
                      {record.notes && (
                        <p className="whitespace-pre-wrap text-sm text-muted-foreground">
                          {record.notes}
                        </p>
                      )}
                    </div>
                    <div className="flex shrink-0 flex-wrap gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => openEdit(record)}
                        aria-label={`Edit PGT delivery for ${record.documentName}`}
                      >
                        <Pencil aria-hidden="true" />
                        Edit
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setDeleteRecord(record)}
                        aria-label={`Delete PGT delivery for ${record.documentName}`}
                      >
                        <Trash2 aria-hidden="true" />
                        Delete
                      </Button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </CardContent>

      <Dialog
        open={editorOpen}
        onOpenChange={open => !upsertMutation.isPending && setEditorOpen(open)}
      >
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingId
                ? "Edit PGT filed-copy delivery"
                : "Add PGT filed-copy delivery"}
            </DialogTitle>
            <DialogDescription>
              Link a generated document so its form code and name are derived by
              the server, or identify an external filed document manually.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-5">
            {editorError && (
              <Alert variant="destructive">
                <AlertCircle aria-hidden="true" />
                <AlertTitle>Cannot save delivery</AlertTitle>
                <AlertDescription>{editorError}</AlertDescription>
              </Alert>
            )}
            <div className="space-y-2">
              <Label htmlFor="pgt-generated-document">Filed document *</Label>
              <Select
                value={draft.documentId || EXTERNAL_DOCUMENT}
                onValueChange={value => {
                  if (value === EXTERNAL_DOCUMENT) {
                    setDraft(current => ({
                      ...current,
                      documentId: "",
                      formCode: "",
                      documentName: "",
                    }));
                  } else {
                    const selected = generatedDocuments.find(
                      document => document.id === value
                    );
                    setDraft(current => ({
                      ...current,
                      documentId: value,
                      formCode: selected?.formCode || "",
                      documentName: selected?.documentName || "",
                    }));
                  }
                }}
              >
                <SelectTrigger id="pgt-generated-document" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={EXTERNAL_DOCUMENT}>
                    External or manually filed document
                  </SelectItem>
                  {generatedDocuments.map(document => (
                    <SelectItem key={document.id} value={document.id}>
                      {document.formCode} — {document.documentName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {draft.documentId && (
                <p className="text-xs text-muted-foreground">
                  The server will preserve the selected generated document's
                  form code and name.
                </p>
              )}
            </div>
            {!draft.documentId && (
              <div className="grid gap-4 sm:grid-cols-[10rem_1fr]">
                <div className="space-y-2">
                  <Label htmlFor="pgt-external-form-code">Form code *</Label>
                  <Input
                    id="pgt-external-form-code"
                    value={draft.formCode}
                    onChange={event => setField("formCode", event.target.value)}
                    placeholder="P2"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pgt-external-document-name">
                    Document name *
                  </Label>
                  <Input
                    id="pgt-external-document-name"
                    value={draft.documentName}
                    onChange={event =>
                      setField("documentName", event.target.value)
                    }
                    placeholder="Submission for estate grant"
                  />
                </div>
              </div>
            )}
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="pgt-filed-date">Date filed *</Label>
                <Input
                  id="pgt-filed-date"
                  type="date"
                  value={draft.filedDate}
                  onChange={event => setField("filedDate", event.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pgt-delivered-date">
                  Date delivered to PGT
                </Label>
                <Input
                  id="pgt-delivered-date"
                  type="date"
                  value={draft.deliveredDate}
                  onChange={event =>
                    setField("deliveredDate", event.target.value)
                  }
                />
                <p className="text-xs text-muted-foreground">
                  Record the actual delivery date; the rule does not create a
                  fixed-number countdown.
                </p>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="pgt-delivery-notes">Notes</Label>
              <Textarea
                id="pgt-delivery-notes"
                value={draft.notes}
                onChange={event => setField("notes", event.target.value)}
                placeholder="Delivery method, confirmation, or follow-up details"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setEditorOpen(false)}
              disabled={upsertMutation.isPending}
            >
              Cancel
            </Button>
            <Button
              type="button"
              onClick={saveDelivery}
              disabled={upsertMutation.isPending}
            >
              {upsertMutation.isPending
                ? "Saving…"
                : editingId
                  ? "Save changes"
                  : "Add filed copy"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={Boolean(deleteRecord)}
        onOpenChange={open =>
          !open && !deleteMutation.isPending && setDeleteRecord(null)
        }
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Delete this PGT delivery record?
            </AlertDialogTitle>
            <AlertDialogDescription>
              This removes the filed and delivered dates for{" "}
              {deleteRecord?.documentName || "this document"}. This action
              cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteMutation.isPending}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {deleteMutation.isPending ? "Deleting…" : "Delete record"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
