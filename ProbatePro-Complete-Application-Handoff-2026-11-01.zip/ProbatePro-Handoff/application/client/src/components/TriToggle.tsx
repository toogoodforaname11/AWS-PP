// client/src/components/TriToggle.tsx
//
// Tri-state (or n-state) toggle for N/A | Yes | No style questions.
// Moved out of EstateDetail.tsx so FormDetailsDialog can reuse it without a
// page → component → page import cycle. Rendering is unchanged.

import * as React from "react";

export function TriToggle({ value, onChange, options = ["na", "yes", "no"], labels }: { value: string; onChange: (v: string) => void; options?: string[]; labels?: string[] }) {
  const displayLabels = labels || options.map(o => o === "na" ? "N/A" : o.charAt(0).toUpperCase() + o.slice(1));
  return (
    <div className="flex rounded-md border border-border overflow-hidden">
      {options.map((opt, i) => (
        <button
          key={opt}
          type="button"
          // Selection is otherwise conveyed by colour and weight alone; aria-pressed
          // is what makes the chosen option legible to assistive technology.
          aria-pressed={value === opt}
          onClick={() => onChange(opt)}
          className={`px-3 py-1.5 text-xs font-medium transition-colors flex-1 text-center outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:relative ${
            value === opt
              ? "bg-slate-700 text-white dark:bg-slate-200 dark:text-slate-900"
              : "bg-background text-muted-foreground hover:bg-muted"
          } ${i > 0 ? "border-l border-border" : ""}`}
        >
          {displayLabels[i]}
        </button>
      ))}
    </div>
  );
}
