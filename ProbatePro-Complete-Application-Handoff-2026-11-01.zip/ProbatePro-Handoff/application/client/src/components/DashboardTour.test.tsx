import React from "react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { DashboardTour } from "./DashboardTour";

afterEach(() => cleanup());

describe("DashboardTour", () => {
  it("moves through the dashboard steps and completes on the final action", () => {
    const onComplete = vi.fn();
    render(
      <>
        <div data-tour="new-estate-action" />
        <DashboardTour open onComplete={onComplete} onDismiss={vi.fn()} />
      </>,
    );
    expect(screen.getByText("Create your first estate file")).toBeTruthy();
    fireEvent.click(screen.getByTestId("dashboard-tour-next"));
    expect(screen.getByText("Find the file you need")).toBeTruthy();
    fireEvent.click(screen.getByTestId("dashboard-tour-next"));
    expect(screen.getByText("Use the dashboard as your control centre")).toBeTruthy();
    fireEvent.click(screen.getByTestId("dashboard-tour-next"));
    expect(onComplete).toHaveBeenCalledTimes(1);
  });

  it("allows the user to exit the tour safely", () => {
    const onDismiss = vi.fn();
    render(<DashboardTour open onComplete={vi.fn()} onDismiss={onDismiss} />);
    fireEvent.click(screen.getByRole("button", { name: "Skip dashboard tour" }));
    expect(onDismiss).toHaveBeenCalledTimes(1);
  });
});
