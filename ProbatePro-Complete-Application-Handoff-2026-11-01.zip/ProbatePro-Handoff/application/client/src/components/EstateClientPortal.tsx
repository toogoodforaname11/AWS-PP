import React from "react";
import { PortalAccessSection } from "@/pages/Settings";
import { ClientIntakeQuestions } from "./ClientIntakeQuestions";
import { ClientIntakeReview } from "./ClientIntakeReview";

export function EstateClientPortal({
  estateId,
  estate,
  hasUnsavedChanges = false,
}: {
  estateId: string;
  estate: any;
  hasUnsavedChanges?: boolean;
}) {
  const [reviewRevision, setReviewRevision] = React.useState(estate.revision);
  React.useEffect(() => setReviewRevision(estate.revision), [estate.revision]);

  return (
    <section
      className="space-y-6"
      aria-labelledby="estate-client-portal-heading"
    >
      <header className="space-y-1">
        <h2
          id="estate-client-portal-heading"
          className="text-lg font-semibold tracking-tight"
        >
          Client Portal
        </h2>
        <p className="max-w-2xl text-sm leading-6 text-muted-foreground">
          Send this estate’s intake link to your client, then review their
          answers here. Apply one field at a time or all submitted details after
          verification.
        </p>
      </header>
      <ClientIntakeQuestions
        estateId={estateId}
        revision={reviewRevision}
        onSaved={setReviewRevision}
      />
      <PortalAccessSection key={estateId} estateId={estateId} />
      <ClientIntakeReview
        key={`${estateId}:review`}
        estateId={estateId}
        revision={reviewRevision}
        currentEstate={estate}
        hasUnsavedChanges={hasUnsavedChanges}
      />
    </section>
  );
}
