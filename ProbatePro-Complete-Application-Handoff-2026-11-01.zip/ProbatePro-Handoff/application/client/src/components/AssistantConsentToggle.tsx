import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuCheckboxItem, DropdownMenuContent, DropdownMenuLabel, DropdownMenuRadioGroup, DropdownMenuRadioItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Label } from "@/components/ui/label";
import { Popover, PopoverAnchor, PopoverContent } from "@/components/ui/popover";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { ASSISTANT_CHIME_TONES, asAssistantChimeTone, clampAssistantChimeVolume, playAssistantChime, primeAssistantChime } from "@/lib/assistantChime";
import { trpc } from "@/lib/trpc";
import { Bot, Check, ShieldCheck, SlidersHorizontal, Sparkles, Volume2 } from "lucide-react";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

type AssistantConsentToggleProps = {
  compact?: boolean;
  showDescription?: boolean;
};

type ResponseStyle = "concise" | "balanced" | "detailed";

const RESPONSE_STYLES: Array<{ value: ResponseStyle; label: string; description: string }> = [
  { value: "concise", label: "Concise", description: "Short, action-first replies" },
  { value: "balanced", label: "Balanced", description: "Clear detail for most tasks" },
  { value: "detailed", label: "Detailed", description: "More context and structure" },
];

function asResponseStyle(value: unknown): ResponseStyle {
  return value === "concise" || value === "detailed" || value === "balanced" ? value : "balanced";
}

export function AssistantConsentToggle({ compact = false, showDescription = true }: AssistantConsentToggleProps) {
  const { data: settings, isLoading } = trpc.settings.get.useQuery();
  const utils = trpc.useUtils();
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [hintOpen, setHintOpen] = useState(false);
  const approvalControlRef = useRef<HTMLDivElement>(null);
  const approved = typeof settings?.aiProcessorApprovedAt === "number" && settings.aiProcessorApprovedAt > 0 && settings.showChatbot !== false;
  const responseStyle = asResponseStyle(settings?.assistantResponseStyle);
  const completionCueEnabled = settings?.assistantCompletionCue === true;
  const completionTone = asAssistantChimeTone(settings?.assistantCompletionTone);
  const completionVolume = clampAssistantChimeVolume(settings?.assistantCompletionVolume);
  const previewContextRef = useRef<AudioContext | null>(null);
  const selectedStyle = useMemo(() => RESPONSE_STYLES.find((style) => style.value === responseStyle)!, [responseStyle]);

  useEffect(() => {
    setHintOpen(!isLoading && !approved && settings?.assistantOnboardingDismissed !== true);
  }, [approved, isLoading, settings?.assistantOnboardingDismissed]);

  const mutation = trpc.settings.update.useMutation({
    onSuccess: (_data, variables) => {
      utils.settings.get.setData(undefined, (current) => current
        ? {
            ...current,
            showChatbot: variables.assistantProcessingApproved === true ? true : variables.assistantProcessingApproved === false ? false : current.showChatbot,
            aiProcessorApprovedAt: variables.assistantProcessingApproved === true ? Date.now() : variables.assistantProcessingApproved === false ? 0 : current.aiProcessorApprovedAt,
            assistantOnboardingDismissed: variables.assistantOnboardingDismissed ?? current.assistantOnboardingDismissed,
            assistantResponseStyle: variables.assistantResponseStyle ?? current.assistantResponseStyle,
            assistantCompletionCue: variables.assistantCompletionCue ?? current.assistantCompletionCue,
            assistantCompletionTone: variables.assistantCompletionTone ?? current.assistantCompletionTone,
            assistantCompletionVolume: variables.assistantCompletionVolume ?? current.assistantCompletionVolume,
          }
        : current);
      void utils.settings.get.invalidate();
      if (variables.assistantProcessingApproved !== undefined) {
        toast.success(variables.assistantProcessingApproved ? "Assistant enabled" : "Assistant disabled and approval withdrawn");
      } else if (variables.assistantResponseStyle) {
        toast.success("Assistant response style saved");
      } else if (variables.assistantCompletionCue !== undefined) {
        toast.success(variables.assistantCompletionCue ? "Assistant completion cue enabled" : "Assistant completion cue muted");
      } else if (variables.assistantCompletionTone || variables.assistantCompletionVolume !== undefined) {
        toast.success("Assistant completion sound saved");
      }
    },
    onError: (error) => toast.error(error.message || "Unable to update assistant approval"),
  });

  const toggle = (next: boolean) => {
    if (next) setConfirmOpen(true);
    else mutation.mutate({ assistantProcessingApproved: false });
  };

  const dismissOnboarding = () => {
    setHintOpen(false);
    mutation.mutate({ assistantOnboardingDismissed: true });
  };

  const closeConfirmation = () => {
    setConfirmOpen(false);
    window.setTimeout(() => {
      approvalControlRef.current?.querySelector<HTMLButtonElement>("[data-testid='assistant-processing-approval-toggle']")?.focus();
    }, 0);
  };

  const handleConfirmOpenChange = (nextOpen: boolean) => {
    if (nextOpen) {
      setConfirmOpen(true);
      return;
    }
    closeConfirmation();
  };

  const updateResponseStyle = (value: string) => {
    const next = asResponseStyle(value);
    if (next !== responseStyle) mutation.mutate({ assistantResponseStyle: next });
  };
  const updateCompletionCue = (next: boolean) => mutation.mutate({ assistantCompletionCue: next });
  const updateCompletionTone = (value: string) => {
    const next = asAssistantChimeTone(value);
    if (next !== completionTone) mutation.mutate({ assistantCompletionTone: next });
  };
  const updateCompletionVolume = (values: number[]) => mutation.mutate({ assistantCompletionVolume: clampAssistantChimeVolume(values[0]) });
  const previewCompletionCue = () => {
    const context = primeAssistantChime(previewContextRef.current);
    if (!context) {
      toast.info("Completion audio is unavailable in this browser");
      return;
    }
    previewContextRef.current = context;
    playAssistantChime(context, completionTone, completionVolume);
  };

  const control = (
    <Switch
      checked={approved}
      disabled={isLoading || mutation.isPending}
      onCheckedChange={toggle}
      aria-label="Enable ProbatePro Assistant and approve AI processing"
      data-testid="assistant-processing-approval-toggle"
      className="sidebar-preference-switch"
    />
  );

  const behaviourMenu = (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          className="flex size-7 shrink-0 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent/70 hover:text-foreground focus:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50"
          aria-label="Assistant response settings"
          title="Assistant response settings"
          disabled={isLoading || mutation.isPending}
          data-testid="assistant-response-style-menu"
        >
          <SlidersHorizontal className="size-3.5" aria-hidden="true" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent side="right" align="end" className="w-72">
        <DropdownMenuLabel className="text-xs">Response style</DropdownMenuLabel>
        <p className="px-2 pb-2 text-[11px] leading-snug text-muted-foreground">Applies to future assistant replies. Safety and legal guardrails remain unchanged.</p>
        <DropdownMenuSeparator />
        <DropdownMenuRadioGroup value={responseStyle} onValueChange={updateResponseStyle}>
          {RESPONSE_STYLES.map((style) => (
            <DropdownMenuRadioItem key={style.value} value={style.value} className="items-start py-2">
              <span className="flex min-w-0 flex-col gap-0.5">
                <span className="text-xs font-medium">{style.label}</span>
                <span className="text-[10px] leading-tight text-muted-foreground">{style.description}</span>
              </span>
            </DropdownMenuRadioItem>
          ))}
        </DropdownMenuRadioGroup>
        <DropdownMenuSeparator />
        <DropdownMenuLabel className="text-xs">Completion cue</DropdownMenuLabel>
        <DropdownMenuCheckboxItem checked={completionCueEnabled} onCheckedChange={updateCompletionCue} className="items-start py-2">
          <span className="flex min-w-0 flex-col gap-0.5">
            <span className="flex items-center gap-1.5 text-xs font-medium"><Volume2 className="size-3" aria-hidden="true" /> Quiet chime</span>
            <span className="text-[10px] leading-tight text-muted-foreground">Play a two-note cue when a reply is ready.</span>
          </span>
        </DropdownMenuCheckboxItem>
        <p className="px-2 pb-1 text-[10px] leading-tight text-muted-foreground">Muted by default. Sound is optional and never replaces the visible completion notice.</p>
        <DropdownMenuSeparator />
        <DropdownMenuLabel className="text-xs">Sound profile</DropdownMenuLabel>
        <DropdownMenuRadioGroup value={completionTone} onValueChange={updateCompletionTone}>
          {ASSISTANT_CHIME_TONES.map((tone) => (
            <DropdownMenuRadioItem key={tone.value} value={tone.value} className="items-start py-1.5">
              <span className="flex min-w-0 flex-col gap-0.5">
                <span className="text-xs font-medium">{tone.label}</span>
                <span className="text-[10px] leading-tight text-muted-foreground">{tone.description}</span>
              </span>
            </DropdownMenuRadioItem>
          ))}
        </DropdownMenuRadioGroup>
        <div className="px-2 pb-2 pt-1.5" onPointerDown={(event) => event.stopPropagation()}>
          <div className="mb-1.5 flex items-center justify-between text-[10px] text-muted-foreground"><span>Volume</span><span>{completionVolume}%</span></div>
          <Slider value={[completionVolume]} min={0} max={100} step={5} aria-label="Assistant completion cue volume" onValueCommit={updateCompletionVolume} />
          <button type="button" className="mt-2 w-full rounded-md border border-border px-2 py-1.5 text-[10px] font-medium text-foreground transition-colors hover:bg-accent" onClick={previewCompletionCue}>
            Preview {completionTone} cue
          </button>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );

  const controlContent = compact ? (
    <div ref={approvalControlRef} className={`assistant-sidebar-control sidebar-preference-control flex items-center gap-1 rounded-lg ${approved ? "assistant-sidebar-control--active" : ""}`} data-enabled={approved ? "true" : "false"} data-testid="sidebar-assistant-approval-control">
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-accent/50">{control}</div>
        </TooltipTrigger>
        <TooltipContent side="right" sideOffset={8}>{approved ? "Assistant enabled" : "Enable assistant"}</TooltipContent>
      </Tooltip>
      {behaviourMenu}
    </div>
  ) : (
    <div ref={approvalControlRef} className={`assistant-sidebar-control sidebar-preference-control flex items-center justify-between gap-3 rounded-lg px-1 py-0.5 ${approved ? "assistant-sidebar-control--active" : ""}`} data-enabled={approved ? "true" : "false"} data-testid="sidebar-assistant-approval-control">
      <div className="flex min-w-0 items-center gap-2">
        <Bot className="h-3.5 w-3.5 shrink-0 text-primary" aria-hidden="true" />
        <div className="min-w-0">
          <Label className="text-[11px] font-medium">Assistant</Label>
          {showDescription && <p className="mt-0.5 text-[10px] leading-tight text-muted-foreground">{approved ? `Enabled · ${selectedStyle.label}` : `Off · ${selectedStyle.label}`}</p>}
        </div>
      </div>
      <div className="relative z-10 flex shrink-0 items-center gap-1">{behaviourMenu}{control}</div>
    </div>
  );

  return (
    <>
      <Popover open={hintOpen}>
        <PopoverAnchor asChild>{controlContent}</PopoverAnchor>
        <PopoverContent side="right" align="end" className="z-[110] w-64 border-primary/20 p-3 shadow-xl" aria-label="Assistant setup tip">
          <div className="flex gap-2.5">
            <span className="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary"><Sparkles className="size-3.5" aria-hidden="true" /></span>
            <div className="min-w-0">
              <p className="text-xs font-semibold">Assistant lives here</p>
              <p className="mt-1 text-[11px] leading-snug text-muted-foreground">Use this sidebar switch to review the processing notice and enable the Assistant.</p>
              <Button type="button" size="sm" variant="ghost" className="mt-2 h-7 px-1.5 text-[11px]" onClick={dismissOnboarding}>Got it <Check className="ml-1 size-3" aria-hidden="true" /></Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>

      <Dialog open={confirmOpen} onOpenChange={handleConfirmOpenChange}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><ShieldCheck className="h-5 w-5 text-primary" />Enable ProbatePro Assistant?</DialogTitle>
            <DialogDescription className="space-y-3 pt-2 text-sm leading-6">
              <span className="block">To answer a request, the Assistant sends your questions, files you choose to provide, and relevant estate details to ProbatePro’s configured third-party enterprise AI processor.</span>
              <span className="block">Your questions, files, and estate information are not used to train AI models.</span>
              <span className="block">Enable it only if you are authorized to approve this processing for your account. You can withdraw approval at any time using this same sidebar control.</span>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button type="button" variant="outline" onClick={closeConfirmation} disabled={mutation.isPending}>Cancel</Button>
            <Button type="button" onClick={() => mutation.mutate({ assistantProcessingApproved: true, assistantOnboardingDismissed: true }, { onSuccess: closeConfirmation })} disabled={mutation.isPending}>
              {mutation.isPending ? "Enabling…" : "Approve and enable"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
