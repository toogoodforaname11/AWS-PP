import { Sparkles } from "lucide-react";
import React from "react";

export type CodicilFacts = {
  documentDate: string | null;
  testatorName: string | null;
  neutralSummary: string | null;
  apparentChanges: string[];
  sourceExcerpts: Array<{ label: string; excerpt: string }>;
};

/**
 * A compact review aid for model-extracted document facts. It deliberately
 * identifies the original document as authoritative and never labels a fact
 * as a legal conclusion.
 */
export function CodicilFactsCard({ details }: { details: CodicilFacts }) {
  const factRows = [
    details.documentDate ? ["Stated date", details.documentDate] : null,
    details.testatorName ? ["Stated name", details.testatorName] : null,
  ].filter((row): row is [string, string] => Boolean(row));
  const hasFacts = factRows.length > 0 || Boolean(details.neutralSummary) || details.apparentChanges.length > 0 || details.sourceExcerpts.length > 0;
  if (!hasFacts) return null;
  return (
    <div className="mt-2 rounded-md border border-violet-500/15 bg-violet-500/[0.035] px-2 py-1.5 text-[10px] leading-relaxed text-foreground" data-testid="codicil-facts-card">
      <div className="mb-1 flex items-center gap-1 font-medium text-violet-700 dark:text-violet-300"><Sparkles className="h-3 w-3" /> AI document facts — review original</div>
      {factRows.map(([label, value]) => <p key={label}><span className="text-muted-foreground">{label}: </span>{value}</p>)}
      {details.neutralSummary && <p className="mt-1 text-muted-foreground">{details.neutralSummary}</p>}
      {details.apparentChanges.length > 0 && <p className="mt-1"><span className="text-muted-foreground">Stated changes: </span>{details.apparentChanges.join("; ")}</p>}
      {details.sourceExcerpts.slice(0, 2).map((source) => <p key={`${source.label}-${source.excerpt}`} className="mt-1 border-l-2 border-violet-500/25 pl-1.5 text-muted-foreground"><span className="font-medium">{source.label}: </span>“{source.excerpt}”</p>)}
    </div>
  );
}
