import React from "react";
import {
  act,
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  mutate: vi.fn(),
  invalidateSubmissions: vi.fn(),
  submitOptions: vi.fn(),
  autocompleteFetch: vi.fn(),
  placeDetailsFetch: vi.fn(),
  customQuestions: vi.fn(),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    useUtils: () => ({
      portal: { clientIntakeSubmissions: { invalidate: mocks.invalidateSubmissions } },
      maps: {
        autocomplete: { fetch: mocks.autocompleteFetch },
        placeDetails: { fetch: mocks.placeDetailsFetch },
      },
    }),
    portal: {
      clientIntakeQuestions: {
        useQuery: () => ({ data: mocks.customQuestions(), isLoading: false, isError: false }),
      },
      submitClientIntake: {
        useMutation: (options: unknown) => {
          mocks.submitOptions(options);
          return { mutate: mocks.mutate, isPending: false };
        },
      },
    },
  },
}));

import { ClientIntakeForm } from "./ClientIntakeForm";

beforeEach(() => {
  vi.clearAllMocks();
  window.localStorage.clear();
  mocks.customQuestions.mockReturnValue({ questions: [] });
});
afterEach(() => vi.useRealTimers());

describe("ClientIntakeForm", () => {
  it("offers a client intake draft to restore after a page refresh", async () => {
    const firstView = render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        draftScope="estate-1:contact-jordan"
        existingSubmissions={[]}
      />
    );

    fireEvent.change(screen.getByLabelText("First name"), {
      target: { value: "Avery" },
    });
    act(() => window.dispatchEvent(new Event("pagehide")));
    firstView.unmount();

    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        draftScope="estate-1:contact-jordan"
        existingSubmissions={[]}
      />
    );

    expect(
      await screen.findByRole("status", { name: "Saved client intake draft" })
    ).toBeTruthy();
    expect(
      (screen.getByLabelText("First name") as HTMLInputElement).value
    ).toBe("");
    fireEvent.click(
      screen.getByRole("button", { name: "Restore saved draft" })
    );
    expect(
      (screen.getByLabelText("First name") as HTMLInputElement).value
    ).toBe("Avery");
    await waitFor(() =>
      expect((document.activeElement as HTMLElement).id).toBe(
        "client-intake-clientName"
      )
    );
    expect(mocks.mutate).not.toHaveBeenCalled();
  });

  it("does not offer a client intake draft from a different portal scope", async () => {
    const firstView = render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        draftScope="estate-1:contact-jordan"
        existingSubmissions={[]}
      />
    );
    fireEvent.change(screen.getByLabelText("First name"), {
      target: { value: "Avery" },
    });
    act(() => window.dispatchEvent(new Event("pagehide")));
    firstView.unmount();

    render(
      <ClientIntakeForm
        contactName="Taylor Reed"
        email="taylor@example.com"
        draftScope="estate-2:contact-taylor"
        existingSubmissions={[]}
      />
    );

    await waitFor(() =>
      expect(
        screen.queryByRole("status", { name: "Saved client intake draft" })
      ).toBeNull()
    );
  });

  it("clears a client intake draft only after the submission succeeds", () => {
    window.localStorage.setItem(
      "estate_draft_client_intake_estate-1:contact-jordan",
      JSON.stringify({
        data: { deceasedFirstName: "Avery" },
        savedAt: Date.now(),
      })
    );
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        draftScope="estate-1:contact-jordan"
        existingSubmissions={[]}
      />
    );

    fireEvent.click(screen.getByRole("button", { name: /send for review/i }));
    const mutationOptions = mocks.submitOptions.mock.calls.at(-1)?.[0] as {
      onSuccess: (result: { id: string; submittedAt: number }) => void;
    };
    act(() =>
      mutationOptions.onSuccess({ id: "submission-1", submittedAt: 1 })
    );

    expect(
      window.localStorage.getItem(
        "estate_draft_client_intake_estate-1:contact-jordan"
      )
    ).toBeNull();
  });

  it("does not save a client intake draft while legal-team questions initialize", () => {
    mocks.customQuestions.mockReturnValue({
      questions: [
        {
          id: "cq_fixture",
          prompt: "Who holds the keys?",
          helpText: "",
          required: false,
        },
      ],
    });
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        draftScope="estate-1:contact-jordan"
        existingSubmissions={[]}
      />
    );

    act(() => window.dispatchEvent(new Event("pagehide")));

    expect(
      window.localStorage.getItem(
        "estate_draft_client_intake_estate-1:contact-jordan"
      )
    ).toBeNull();
  });

  it("keeps a successful portal submission visible in a durable, read-only receipt", () => {
    mocks.customQuestions.mockReturnValue({
      questions: [
        {
          id: "cq_propertyfact1",
          prompt: "Who is currently responsible for the property?",
          helpText: "Include a name if known.",
          required: true,
        },
      ],
    });
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[]}
      />
    );

    const firstName = screen.getByLabelText("First name") as HTMLInputElement;
    const response = screen.getByRole("textbox", {
      name: /Who is currently responsible for the property/i,
    }) as HTMLTextAreaElement;
    fireEvent.change(firstName, { target: { value: "Avery" } });
    fireEvent.change(response, { target: { value: "Jordan Morgan" } });
    fireEvent.click(screen.getByRole("button", { name: /send for review/i }));

    const mutationOptions = mocks.submitOptions.mock.calls.at(-1)?.[0] as {
      onSuccess: (result: { id: string; submittedAt: number }) => void;
    };
    act(() => mutationOptions.onSuccess({ id: "submission-1", submittedAt: 1 }));

    expect(
      screen.getByRole("heading", { name: "Your intake has been sent" })
    ).toBeTruthy();
    const confirmation = screen.getByRole("status", {
      name: "Submission confirmation",
    });
    expect(confirmation.textContent).toMatch(
      /The legal team will review your information/i
    );
    expect(confirmation.textContent).not.toContain("Avery");
    expect(confirmation.textContent).not.toContain("Jordan Morgan");
    const receipt = screen.getByRole("region", {
      name: "Your submitted answers",
    });
    expect(receipt.textContent).toContain("Avery");
    expect(receipt.textContent).toContain("Jordan Morgan");
    expect(receipt.textContent).toContain("jordan@example.com");
    expect(receipt.textContent).toContain(
      "Who is currently responsible for the property?"
    );
    expect(screen.queryByRole("button", { name: /send for review/i })).toBeNull();
    expect(screen.queryByLabelText("First name")).toBeNull();
    expect(screen.queryByDisplayValue("jordan@example.com")).toBeNull();
    expect(mocks.invalidateSubmissions).toHaveBeenCalledTimes(1);
  });

  it("keeps the receipt while a prior revision is refreshing, then returns to the new revision flow", async () => {
    const revisionPayload = {
      deceasedFirstName: "Avery",
      deceasedMiddleNames: "",
      deceasedLastName: "Morgan",
      dateOfBirth: "",
      dateOfDeath: "",
      deceasedAddress: "",
      deceasedResidenceCity: "",
      domicileCity: "",
      willStatus: "will" as const,
      willDate: "",
      willLocation: "",
      clientName: "Jordan Morgan",
      clientEmail: "jordan@example.com",
      clientPhone: "",
      relationshipToDeceased: "",
      clientNotes: "",
    };
    const { rerender } = render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[
          {
            id: "prior-revision",
            status: "revision_requested",
            submittedAt: 1,
            reviewedAt: null,
            reviewNotes: "",
            revisionRequest: "Please confirm the original will location.",
            payload: revisionPayload,
          },
        ]}
      />
    );

    const mutationOptions = mocks.submitOptions.mock.calls.at(-1)?.[0] as {
      onSuccess: (result: { id: string; submittedAt: number }) => void;
    };
    act(() => mutationOptions.onSuccess({ id: "submission-2", submittedAt: 2 }));
    expect(
      screen.getByRole("heading", { name: "Your intake has been sent" })
    ).toBeTruthy();

    rerender(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[
          {
            id: "submission-2",
            status: "revision_requested",
            submittedAt: 2,
            reviewedAt: null,
            reviewNotes: "",
            revisionRequest: "Please confirm the original will location.",
            payload: revisionPayload,
          },
        ]}
      />
    );

    await waitFor(() =>
      expect((screen.getByLabelText("First name") as HTMLInputElement).value).toBe(
        "Avery"
      )
    );
    expect(
      screen.queryByRole("heading", { name: "Your intake has been sent" })
    ).toBeNull();
    expect(
      screen.getByRole("button", { name: /send revised details/i })
    ).toBeTruthy();
  });

  it("shows the saved submitted answers after the portal reloads", () => {
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[
          {
            id: "submission-3",
            status: "submitted",
            submittedAt: 3,
            reviewedAt: null,
            reviewNotes: "",
            revisionRequest: "",
            payload: {
              deceasedFirstName: "Avery",
              deceasedMiddleNames: "",
              deceasedLastName: "Morgan",
              dateOfBirth: "",
              dateOfDeath: "",
              deceasedAddress: "",
              deceasedResidenceCity: "",
              domicileCity: "",
              willStatus: "unknown",
              willDate: "",
              willLocation: "",
              clientName: "Jordan Morgan",
              clientEmail: "jordan@example.com",
              clientPhone: "604-555-0101",
              relationshipToDeceased: "Niece",
              clientNotes: "Please call after 4 p.m.",
            },
          },
        ]}
      />
    );

    const receipt = screen.getByRole("region", {
      name: "Your submitted answers",
    });
    expect(receipt.textContent).toContain("Avery");
    expect(receipt.textContent).toContain("604-555-0101");
    expect(receipt.textContent).toContain("Please call after 4 p.m.");
    expect(screen.queryByRole("button", { name: /send for review/i })).toBeNull();
    expect(screen.queryByLabelText("First name")).toBeNull();
  });

  it("renders lawyer-authored questions, requires marked answers, and submits answer IDs only", () => {
    mocks.customQuestions.mockReturnValue({
      questions: [
        {
          id: "cq_propertyfact1",
          prompt: "Who is currently responsible for the property?",
          helpText: "Include a name if known.",
          required: true,
        },
      ],
    });
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[]}
      />
    );

    expect(screen.getByRole("heading", { name: "Questions from your legal team" })).toBeTruthy();
    const response = screen.getByRole("textbox", {
      name: /Who is currently responsible for the property/i,
    });
    fireEvent.click(screen.getByRole("button", { name: /send for review/i }));
    expect(mocks.mutate).not.toHaveBeenCalled();
    expect(screen.getByText(/A response is required/i)).toBeTruthy();

    fireEvent.change(response, { target: { value: "Jordan Morgan" } });
    fireEvent.click(screen.getByRole("button", { name: /send for review/i }));
    expect(mocks.mutate).toHaveBeenCalledWith(
      expect.objectContaining({
        customQuestionAnswers: [
          { id: "cq_propertyfact1", answer: "Jordan Morgan" },
        ],
      })
    );
  });

  it("submits a self-contained client intake payload through the secure portal procedure", () => {
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[]}
      />
    );
    expect(
      screen.getByText(/Share intake details with your legal team/i)
    ).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: /send for review/i }));
    expect(mocks.mutate).toHaveBeenCalledWith(
      expect.objectContaining({
        clientName: "Jordan Morgan",
        clientEmail: "jordan@example.com",
        willStatus: "unknown",
      })
    );
  });

  it("captures an alternate name in separate parts without parsing the full-name report", () => {
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[]}
      />
    );

    fireEvent.change(screen.getByLabelText("Other names used"), {
      target: { value: "Taylor Jordan Morgan" },
    });
    fireEvent.change(screen.getByLabelText("Other name first name"), {
      target: { value: "Taylor" },
    });
    fireEvent.change(screen.getByLabelText("Other name middle name(s)"), {
      target: { value: "Jordan" },
    });
    fireEvent.change(screen.getByLabelText("Other name last name"), {
      target: { value: "Morgan" },
    });
    fireEvent.click(screen.getByRole("button", { name: /send for review/i }));

    expect(mocks.mutate).toHaveBeenCalledWith(
      expect.objectContaining({
        deceasedAliases: "Taylor Jordan Morgan",
        deceasedAkaFirstName: "Taylor",
        deceasedAkaMiddleName: "Jordan",
        deceasedAkaLastName: "Morgan",
      })
    );
  });

  it("follows the executor intake PDF section sequence and exposes its client-facing fields without collecting a SIN", () => {
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[]}
      />
    );

    const headings = [
      screen.getByRole("heading", { name: "About you" }),
      screen.getByRole("heading", { name: "About the person who died" }),
      screen.getByRole("heading", { name: "Executors" }),
      screen.getByRole("heading", { name: "Family & other persons" }),
      screen.getByRole("heading", { name: "Estate assets and debts" }),
      screen.getByRole("heading", { name: "Documents to gather" }),
    ];
    for (let index = 0; index < headings.length - 1; index += 1) {
      expect(
        headings[index].compareDocumentPosition(headings[index + 1]) &
          Node.DOCUMENT_POSITION_FOLLOWING
      ).toBeTruthy();
    }

    expect(screen.getByLabelText("Your street address")).toBeTruthy();
    expect(screen.getByLabelText("Your occupation")).toBeTruthy();
    expect(screen.getByLabelText("Your date of birth")).toBeTruthy();
    expect(screen.getByLabelText("Other names used")).toBeTruthy();
    expect(screen.getByLabelText("Place of birth")).toBeTruthy();
    expect(screen.getByLabelText("Place of death")).toBeTruthy();
    expect(
      screen.getByText(/Nisga’a citizen or a member of a treaty First Nation/i)
    ).toBeTruthy();
    expect(screen.getByLabelText("Original will")).toBeTruthy();
    expect(screen.queryByLabelText(/SIN|social insurance/i)).toBeNull();
    expect(
      screen.queryByText(/Kevin Kisser|dawsonmullinlaw\.com|778-700-6701/i)
    ).toBeNull();
  });

  it("adds and removes repeatable reports while submitting blank optional values exactly as reported", () => {
    mocks.mutate.mockClear();
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[]}
      />
    );

    fireEvent.click(screen.getByRole("button", { name: "Add executor" }));
    fireEvent.change(screen.getByLabelText("Full name"), {
      target: { value: "Avery Morgan" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Add executor" }));
    expect(screen.getAllByLabelText("Full name")).toHaveLength(2);
    fireEvent.click(
      screen.getAllByRole("button", { name: "Remove executor" })[1]
    );
    expect((screen.getByLabelText("Full name") as HTMLInputElement).value).toBe(
      "Avery Morgan"
    );

    fireEvent.click(screen.getByRole("button", { name: "Add vehicle" }));
    expect(
      screen.getByLabelText("Vehicle details (year, make, model, VIN)")
    ).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: /send for review/i }));

    const payload = mocks.mutate.mock.calls.at(-1)?.[0];
    expect(payload.executors).toEqual([
      expect.objectContaining({
        category: "executor",
        name: "Avery Morgan",
        age: "",
        address: "",
        email: "",
        phone: "",
      }),
    ]);
    expect(payload.estateItems).toEqual([
      {
        category: "vehicle",
        description: "",
        location: "unknown",
        value: "",
        bankAddress: "",
        accountNumber: "",
        accountHolder: "",
        pid: "",
        legalDescription: "",
        registeredOwner: "",
        ownershipDetails: "",
      },
    ]);
  });

  it("collects a client-reported executor status without defaulting it", () => {
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[]}
      />
    );

    fireEvent.click(screen.getByRole("button", { name: "Add executor" }));
    const status = screen.getByLabelText(
      "Executor status, if known"
    ) as HTMLSelectElement;
    expect(status.value).toBe("");

    fireEvent.change(status, { target: { value: "reserved" } });
    fireEvent.click(screen.getByRole("button", { name: /send for review/i }));

    expect(mocks.mutate).toHaveBeenCalledWith(
      expect.objectContaining({
        executors: [
          expect.objectContaining({
            category: "executor",
            executorStatus: "reserved",
          }),
        ],
      })
    );
  });

  it("keeps a client-reported family relationship explicit and ready for lawyer review", () => {
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[]}
      />
    );

    fireEvent.click(screen.getByRole("button", { name: "Add person" }));
    fireEvent.change(screen.getByLabelText("Family member 1 category"), {
      target: { value: "child" },
    });

    const relationship = screen.getByLabelText(
      "Relationship to the deceased, if known"
    ) as HTMLInputElement;
    expect(relationship.value).toBe("child");

    fireEvent.change(screen.getByLabelText("Full name"), {
      target: { value: "Casey Family" },
    });
    fireEvent.click(screen.getByRole("button", { name: /send for review/i }));

    expect(mocks.mutate).toHaveBeenCalledWith(
      expect.objectContaining({
        familyMembers: [
          expect.objectContaining({
            name: "Casey Family",
            category: "child",
            relationship: "child",
          }),
        ],
      })
    );
  });

  it("uses the one last-home-address field and does not re-ask duplicate residence or oath-city details", () => {
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[]}
      />
    );
    expect(
      screen.queryByLabelText("Last city of residence, if different")
    ).toBeNull();
    expect(
      screen.queryByLabelText("Affidavit oath city, if different")
    ).toBeNull();
    expect(screen.queryByTestId("client-intake-location-details")).toBeNull();
    fireEvent.change(screen.getByLabelText("Last home address"), {
      target: { value: "1234 Fort Street, Victoria, BC" },
    });
    fireEvent.click(screen.getByRole("button", { name: /send for review/i }));
    expect(mocks.mutate).toHaveBeenCalledWith(
      expect.objectContaining({
        deceasedAddress: "1234 Fort Street, Victoria, BC",
      })
    );
  });

  it("suggests a complete last home address while retaining a clear manual-entry path", async () => {
    mocks.autocompleteFetch.mockResolvedValue({
      suggestions: [
        {
          placeId: "home-1",
          description: "1450 West Georgia St, Vancouver, BC, Canada",
          mainText: "1450 West Georgia St",
          secondaryText: "Vancouver, BC, Canada",
        },
      ],
    });
    mocks.placeDetailsFetch.mockResolvedValue({
      details: {
        formattedAddress: "1450 West Georgia St, Vancouver, BC V6G 2T8, Canada",
        addressComponents: [
          { long_name: "1450", short_name: "1450", types: ["street_number"] },
          {
            long_name: "West Georgia Street",
            short_name: "W Georgia St",
            types: ["route"],
          },
          {
            long_name: "Vancouver",
            short_name: "Vancouver",
            types: ["locality"],
          },
          {
            long_name: "British Columbia",
            short_name: "BC",
            types: ["administrative_area_level_1"],
          },
          {
            long_name: "V6G 2T8",
            short_name: "V6G 2T8",
            types: ["postal_code"],
          },
          { long_name: "Canada", short_name: "CA", types: ["country"] },
        ],
      },
    });
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[]}
      />
    );
    const address = screen.getByLabelText(
      "Last home address"
    ) as HTMLInputElement;
    fireEvent.change(address, { target: { value: "1450 West" } });
    expect(await screen.findByText("1450 West Georgia St")).toBeTruthy();
    fireEvent.mouseDown(screen.getByText("1450 West Georgia St"));
    await waitFor(() =>
      expect(address.value).toBe(
        "1450 West Georgia St, Vancouver, BC V6G 2T8, Canada"
      )
    );
    expect(screen.queryByText(/For a more accurate record/i)).toBeNull();
    expect(
      (screen.getByLabelText("Last home street address") as HTMLInputElement)
        .value
    ).toBe("1450 West Georgia Street");
    expect(
      (screen.getByLabelText("Last home city") as HTMLInputElement).value
    ).toBe("Vancouver");
    expect(
      (screen.getByLabelText("Last home province or state") as HTMLInputElement)
        .value
    ).toBe("BC");
    expect(
      (screen.getByLabelText("Last home postal code") as HTMLInputElement).value
    ).toBe("V6G 2T8");
    fireEvent.change(address, { target: { value: "Rural route" } });
    expect(screen.getByText(/For a more accurate record/i)).toBeTruthy();
  });

  it("copies a formatted address and reports a clipboard failure without changing the saved value", async () => {
    const originalClipboard = Object.getOwnPropertyDescriptor(
      navigator,
      "clipboard"
    );
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, "clipboard", {
      configurable: true,
      value: { writeText },
    });
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[]}
      />
    );
    const address = screen.getByLabelText(
      "Last home address"
    ) as HTMLInputElement;
    fireEvent.change(address, {
      target: { value: "1450 West Georgia St, Vancouver, BC V6G 2T8, Canada" },
    });
    fireEvent.click(
      screen.getByRole("button", { name: "Copy formatted address" })
    );
    await waitFor(() =>
      expect(writeText).toHaveBeenCalledWith(
        "1450 West Georgia St, Vancouver, BC V6G 2T8, Canada"
      )
    );
    expect(
      screen.getByRole("button", { name: "Copy formatted address" }).textContent
    ).toMatch(/copied/i);
    expect(address.value).toBe(
      "1450 West Georgia St, Vancouver, BC V6G 2T8, Canada"
    );

    writeText.mockRejectedValueOnce(new Error("Denied"));
    fireEvent.click(
      screen.getByRole("button", { name: "Copy formatted address" })
    );
    await waitFor(() =>
      expect(screen.getByText(/Copy unavailable/i)).toBeTruthy()
    );
    if (originalClipboard)
      Object.defineProperty(navigator, "clipboard", originalClipboard);
    else delete (navigator as { clipboard?: Clipboard }).clipboard;
  });

  it("shows a lawyer revision request and prepares the client to send revised details", () => {
    const scrollTo = vi.fn();
    const originalScrollTo = window.scrollTo;
    const originalRequestAnimationFrame = window.requestAnimationFrame;
    window.scrollTo = scrollTo;
    window.requestAnimationFrame = vi.fn((callback: FrameRequestCallback) => {
      callback(0);
      return 1;
    });
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[
          {
            id: "submission-1",
            status: "revision_requested",
            submittedAt: 1,
            reviewedAt: null,
            reviewNotes: "",
            revisionRequest: "Please confirm where the original will is kept.",
            revisionFieldComments: [
              {
                field: "willLocation",
                comment:
                  "Confirm the current location of the original signed will.",
              },
            ],
            payload: {
              deceasedFirstName: "Avery",
              deceasedMiddleNames: "",
              deceasedLastName: "Morgan",
              dateOfBirth: "",
              dateOfDeath: "",
              deceasedAddress: "",
              deceasedResidenceCity: "",
              domicileCity: "",
              willStatus: "will",
              willDate: "",
              willLocation: "",
              clientName: "Jordan Morgan",
              clientEmail: "jordan@example.com",
              clientPhone: "",
              relationshipToDeceased: "",
              clientNotes: "",
            },
          },
        ]}
      />
    );

    expect(
      screen.queryByText(/Please confirm where the original will is kept/i)
    ).toBeNull();
    fireEvent.click(
      screen.getByRole("button", { name: /read requested revisions/i })
    );
    expect(
      screen.getByRole("note", { name: /lawyer requested revisions/i })
        .textContent
    ).toMatch(/Please confirm where the original will is kept/i);
    const target = document.getElementById(
      "client-intake-willLocation"
    ) as HTMLInputElement;
    const boundsSpy = vi
      .spyOn(target, "getBoundingClientRect")
      .mockReturnValue({
        top: 500,
        bottom: 540,
        height: 40,
        left: 0,
        right: 300,
        width: 300,
        x: 0,
        y: 500,
        toJSON: () => ({}),
      });
    const scrollYSpy = vi.spyOn(window, "scrollY", "get").mockReturnValue(120);
    const scrollXSpy = vi.spyOn(window, "scrollX", "get").mockReturnValue(0);
    const viewportSpy = vi
      .spyOn(window, "innerHeight", "get")
      .mockReturnValue(800);
    fireEvent.click(screen.getByRole("button", { name: /jump to field/i }));
    expect(scrollTo).toHaveBeenCalledWith({
      behavior: "smooth",
      left: 0,
      top: 240,
    });
    expect(window.requestAnimationFrame).toHaveBeenCalled();
    fireEvent(window, new Event("scrollend"));
    expect((document.activeElement as HTMLElement).id).toBe(
      "client-intake-willLocation"
    );
    expect(
      document.getElementById("client-intake-willLocation")?.parentElement
        ?.className
    ).toContain("client-intake-field-attention");
    expect(
      document.getElementById("client-intake-willLocation")?.parentElement
        ?.className
    ).toContain("client-intake-field-attention-standard");
    fireEvent.click(
      screen.getByRole("button", { name: /back to requested revisions/i })
    );
    expect(scrollTo).toHaveBeenLastCalledWith({
      behavior: "smooth",
      left: 0,
      top: 120,
    });
    const resolved = screen.getByRole("checkbox", {
      name: /mark as resolved/i,
    });
    expect(resolved.getAttribute("data-state")).toBe("unchecked");
    fireEvent.click(resolved);
    expect(resolved.getAttribute("data-state")).toBe("checked");
    expect(
      window.sessionStorage.getItem("client-intake-resolved:submission-1:1")
    ).toContain("willLocation");
    expect(
      screen.getByRole("button", { name: /send revised details/i })
    ).toBeTruthy();
    expect(
      (screen.getByLabelText("First name") as HTMLInputElement).value
    ).toBe("Avery");
    window.scrollTo = originalScrollTo;
    window.requestAnimationFrame = originalRequestAnimationFrame;
    boundsSpy.mockRestore();
    scrollYSpy.mockRestore();
    scrollXSpy.mockRestore();
    viewportSpy.mockRestore();
  });

  it("uses red post-scroll attention when the targeted field has a validation error", () => {
    vi.useFakeTimers();
    const scrollTo = vi.fn();
    const originalScrollTo = window.scrollTo;
    const originalRequestAnimationFrame = window.requestAnimationFrame;
    window.scrollTo = scrollTo;
    window.requestAnimationFrame = vi.fn((callback: FrameRequestCallback) => {
      callback(0);
      return 1;
    });
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[
          {
            id: "submission-invalid",
            status: "revision_requested",
            submittedAt: 1,
            reviewedAt: null,
            reviewNotes: "",
            revisionRequest: "Please confirm the original will location.",
            revisionFieldComments: [
              {
                field: "willLocation",
                comment: "Confirm where the original signed will is kept.",
              },
            ],
            payload: {
              deceasedFirstName: "",
              deceasedMiddleNames: "",
              deceasedLastName: "",
              dateOfBirth: "",
              dateOfDeath: "",
              deceasedAddress: "",
              deceasedResidenceCity: "",
              domicileCity: "",
              willStatus: "will",
              willDate: "",
              willLocation: "",
              clientName: "Jordan Morgan",
              clientEmail: "jordan@example.com",
              clientPhone: "",
              relationshipToDeceased: "",
              clientNotes: "",
            },
          },
        ]}
      />
    );

    fireEvent.click(
      screen.getByRole("button", { name: /read requested revisions/i })
    );
    const target = document.getElementById(
      "client-intake-willLocation"
    ) as HTMLInputElement;
    target.setAttribute("aria-invalid", "true");
    target.setAttribute(
      "data-validation-message",
      "Enter the location of the original signed will."
    );
    fireEvent.click(screen.getByRole("button", { name: /jump to field/i }));
    fireEvent(window, new Event("scrollend"));
    expect(target.parentElement?.className).toContain(
      "client-intake-field-attention-error"
    );
    expect(target.parentElement?.className).toContain(
      "client-intake-field-attention-error-shake"
    );
    expect(target.parentElement?.className).not.toContain(
      "client-intake-field-attention-standard"
    );
    expect(screen.getByRole("alert").textContent).toMatch(
      /Enter the location of the original signed will/i
    );
    expect(target.getAttribute("aria-describedby")).toBe(
      "client-intake-willLocation-validation-error"
    );
    expect(
      screen.getByRole("button", { name: /1 validation error remaining/i })
        .textContent
    ).toMatch(/1 validation error remaining/i);
    expect(
      screen
        .getByRole("progressbar", { name: /intake completion progress/i })
        .getAttribute("aria-valuenow")
    ).toBe("21");
    fireEvent.change(target, { target: { value: "Law office records room" } });
    expect(screen.queryByRole("alert")).toBeNull();
    expect(target.parentElement?.className).not.toContain(
      "client-intake-field-attention-error"
    );
    expect(target.parentElement?.className).toContain(
      "client-intake-field-recovered"
    );
    expect(target.getAttribute("aria-invalid")).toBeNull();
    expect(
      screen.getByRole("button", { name: /No validation errors remaining/i })
        .textContent
    ).toMatch(/No validation errors remaining/i);
    expect(
      screen
        .getByRole("progressbar", { name: /intake completion progress/i })
        .getAttribute("aria-valuenow")
    ).toBe("29");
    act(() => vi.advanceTimersByTime(1400));
    expect(screen.getByText("Update noted").className).toContain(
      "client-intake-auto-saved"
    );
    act(() => vi.advanceTimersByTime(3300));
    expect(screen.queryByText("Update noted")).toBeNull();
    window.scrollTo = originalScrollTo;
    window.requestAnimationFrame = originalRequestAnimationFrame;
    vi.useRealTimers();
  });

  it("uses the validation summary to move to the next remaining error", () => {
    const scrollTo = vi.fn();
    const originalScrollTo = window.scrollTo;
    const originalRequestAnimationFrame = window.requestAnimationFrame;
    window.scrollTo = scrollTo;
    window.requestAnimationFrame = vi.fn((callback: FrameRequestCallback) => {
      callback(0);
      return 1;
    });
    render(
      <ClientIntakeForm contactName="" email="" existingSubmissions={[]} />
    );

    const summary = screen.getByRole("button", {
      name: /2 validation errors remaining/i,
    });
    expect(
      screen
        .getByRole("progressbar", { name: /intake completion progress/i })
        .getAttribute("aria-valuenow")
    ).toBe("0");
    expect(
      screen.getByRole("button", { name: /send for review/i }).className
    ).not.toContain("client-intake-submit-guidance");
    expect(
      screen
        .getByRole("button", { name: /send for review/i })
        .hasAttribute("disabled")
    ).toBe(true);
    fireEvent.click(summary);
    fireEvent(window, new Event("scrollend"));
    expect((document.activeElement as HTMLElement).id).toBe(
      "client-intake-clientName"
    );
    fireEvent.click(
      screen.getByRole("button", { name: /2 validation errors remaining/i })
    );
    fireEvent(window, new Event("scrollend"));
    expect((document.activeElement as HTMLElement).id).toBe(
      "client-intake-clientEmail"
    );
    window.scrollTo = originalScrollTo;
    window.requestAnimationFrame = originalRequestAnimationFrame;
  });

  it("celebrates a fully completed client intake progress bar", async () => {
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[
          {
            id: "submission-complete",
            status: "revision_requested",
            submittedAt: 1,
            reviewedAt: null,
            reviewNotes: "",
            revisionRequest: "Please review the completed details.",
            payload: {
              deceasedFirstName: "Avery",
              deceasedMiddleNames: "Rae",
              deceasedLastName: "Morgan",
              dateOfBirth: "1940-01-01",
              dateOfDeath: "2025-01-01",
              deceasedAddress: "100 Main Street",
              deceasedResidenceCity: "Victoria",
              domicileCity: "Victoria",
              willStatus: "will",
              willDate: "2020-01-01",
              willLocation: "Law office records room",
              clientName: "Jordan Morgan",
              clientEmail: "jordan@example.com",
              clientPhone: "250-555-0100",
              relationshipToDeceased: "Executor",
              clientNotes: "All known details provided.",
            },
          },
        ]}
      />
    );

    await waitFor(() =>
      expect(
        screen
          .getByRole("progressbar", { name: /intake completion progress/i })
          .getAttribute("aria-valuenow")
      ).toBe("100")
    );
    expect(screen.getAllByText("Intake complete").length).toBeGreaterThan(0);
    expect(
      document.querySelector(".client-intake-completion-celebration")
    ).toBeTruthy();
    expect(
      screen.getByRole("button", { name: /send revised details/i }).className
    ).toContain("client-intake-submit-guidance");
  });

  it("uses an instant scroll for people who prefer reduced motion", () => {
    const scrollTo = vi.fn();
    const originalScrollTo = window.scrollTo;
    const originalMatchMedia = window.matchMedia;
    window.scrollTo = scrollTo;
    Object.defineProperty(window, "matchMedia", {
      configurable: true,
      value: vi.fn(() => ({ matches: true })),
    });
    render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[
          {
            id: "submission-motion",
            status: "revision_requested",
            submittedAt: 1,
            reviewedAt: null,
            reviewNotes: "",
            revisionRequest: "Please check the will location.",
            revisionFieldComments: [
              {
                field: "willLocation",
                comment: "Confirm where the original is held.",
              },
            ],
            payload: {
              deceasedFirstName: "",
              deceasedMiddleNames: "",
              deceasedLastName: "",
              dateOfBirth: "",
              dateOfDeath: "",
              deceasedAddress: "",
              deceasedResidenceCity: "",
              domicileCity: "",
              willStatus: "will",
              willDate: "",
              willLocation: "",
              clientName: "Jordan Morgan",
              clientEmail: "jordan@example.com",
              clientPhone: "",
              relationshipToDeceased: "",
              clientNotes: "",
            },
          },
        ]}
      />
    );

    fireEvent.click(
      screen.getByRole("button", { name: /read requested revisions/i })
    );
    fireEvent.click(screen.getByRole("button", { name: /jump to field/i }));
    expect(scrollTo).toHaveBeenCalledWith(
      expect.objectContaining({ behavior: "auto", left: 0 })
    );
    expect((document.activeElement as HTMLElement).id).toBe(
      "client-intake-willLocation"
    );
    window.scrollTo = originalScrollTo;
    Object.defineProperty(window, "matchMedia", {
      configurable: true,
      value: originalMatchMedia,
    });
  });

  it("scopes resolved markers to the current lawyer revision request", async () => {
    const submission = {
      id: "submission-2",
      status: "revision_requested",
      submittedAt: 1,
      reviewedAt: null,
      reviewNotes: "",
      revisionRequestedAt: 10,
      revisionRequest: "Please verify the original will location.",
      revisionFieldComments: [
        {
          field: "willLocation" as const,
          comment: "Confirm where the signed original is held.",
        },
      ],
      payload: {
        deceasedFirstName: "",
        deceasedMiddleNames: "",
        deceasedLastName: "",
        dateOfBirth: "",
        dateOfDeath: "",
        deceasedAddress: "",
        deceasedResidenceCity: "",
        domicileCity: "",
        willStatus: "will" as const,
        willDate: "",
        willLocation: "",
        clientName: "Jordan Morgan",
        clientEmail: "jordan@example.com",
        clientPhone: "",
        relationshipToDeceased: "",
        clientNotes: "",
      },
    };
    window.sessionStorage.setItem(
      "client-intake-resolved:submission-2:10",
      JSON.stringify(["willLocation"])
    );
    const { rerender } = render(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[submission]}
      />
    );
    fireEvent.click(
      screen.getByRole("button", { name: /read requested revisions/i })
    );
    expect(
      screen
        .getByRole("checkbox", { name: /mark as resolved/i })
        .getAttribute("data-state")
    ).toBe("checked");

    rerender(
      <ClientIntakeForm
        contactName="Jordan Morgan"
        email="jordan@example.com"
        existingSubmissions={[{ ...submission, revisionRequestedAt: 11 }]}
      />
    );
    await waitFor(() =>
      expect(
        screen
          .getByRole("checkbox", { name: /mark as resolved/i })
          .getAttribute("data-state")
      ).toBe("unchecked")
    );
  });
});
