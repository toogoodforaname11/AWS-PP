import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  AddressAutocomplete,
  type AddressComponents,
} from "@/components/AddressAutocomplete";
import { ClientIntakeStatusBadge } from "@/components/ClientIntakeStatusBadge";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { buildClientIntakeSummarySections } from "@/lib/clientIntakeSummary";
import { trpc } from "@/lib/trpc";
import { useLocalDraft } from "@/hooks/useLocalDraft";
import {
  CLIENT_INTAKE_REVISION_FIELD_LABELS,
  type ClientIntakeItem,
  type ClientIntakePayload,
  type ClientIntakePerson,
  type ClientIntakeRevisionField,
} from "@shared/clientIntake";
import {
  Check,
  ClipboardCheck,
  Copy,
  FileCheck2,
  Loader2,
  LocateFixed,
  MessageSquareText,
  ShieldCheck,
} from "lucide-react";
import React, { useEffect, useId, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

type ClientIntakeFormData = ClientIntakePayload;
type LegacyClientIntakePayload = Pick<
  ClientIntakePayload,
  | "deceasedFirstName"
  | "deceasedMiddleNames"
  | "deceasedLastName"
  | "dateOfBirth"
  | "dateOfDeath"
  | "deceasedAddress"
  | "deceasedResidenceCity"
  | "domicileCity"
  | "willStatus"
  | "willDate"
  | "willLocation"
  | "clientName"
  | "clientEmail"
  | "clientPhone"
  | "relationshipToDeceased"
  | "clientNotes"
>;
type ExistingSubmission = {
  id: string;
  status: string;
  submittedAt: number;
  reviewedAt: number | null;
  reviewNotes: string;
  revisionRequest: string;
  revisionRequestedAt?: number | null;
  revisionFieldComments?: Array<{
    field: ClientIntakeRevisionField;
    comment: string;
  }>;
  /** Older portal submissions predate the expanded optional intake fields. */
  payload: Partial<ClientIntakePayload> & LegacyClientIntakePayload;
};

type PersonCategory = ClientIntakePerson["category"];
type ItemCategory = ClientIntakeItem["category"];

const emptyPerson = (
  category: PersonCategory = "other"
): ClientIntakePerson => ({
  name: "",
  relationship: "",
  age: "",
  occupation: "",
  address: "",
  addressStreet: "",
  addressUnit: "",
  addressCity: "",
  addressProvince: "",
  addressPostalCode: "",
  addressCountry: "",
  email: "",
  phone: "",
  executorStatus: "",
  category,
});
const emptyItem = (category: ItemCategory): ClientIntakeItem => ({
  category,
  description: "",
  location: "unknown",
  value: "",
  bankAddress: "",
  accountNumber: "",
  accountHolder: "",
  pid: "",
  legalDescription: "",
  registeredOwner: "",
  ownershipDetails: "",
});
const emptyForm: ClientIntakeFormData = {
  deceasedFirstName: "",
  deceasedMiddleNames: "",
  deceasedLastName: "",
  dateOfBirth: "",
  dateOfDeath: "",
  deceasedAddress: "",
  deceasedResidenceCity: "",
  domicileCity: "",
  deceasedAliases: "",
  deceasedAkaFirstName: "",
  deceasedAkaMiddleName: "",
  deceasedAkaLastName: "",
  deceasedPlaceOfBirth: "",
  placeOfDeath: "",
  addressStreet: "",
  addressUnit: "",
  addressCity: "",
  addressProvince: "",
  addressPostalCode: "",
  addressCountry: "",
  treatyFirstNation: "",
  treatyFirstNationName: "",
  willStatus: "unknown",
  willDate: "",
  willLocation: "",
  clientName: "",
  clientEmail: "",
  clientPhone: "",
  relationshipToDeceased: "",
  clientOccupation: "",
  clientDateOfBirth: "",
  clientAddressStreet: "",
  clientAddressUnit: "",
  clientAddressCity: "",
  clientAddressProvince: "",
  clientAddressPostalCode: "",
  clientAddressCountry: "",
  clientNotes: "",
  executors: [],
  familyMembers: [],
  estateItems: [],
  documentsAvailable: [],
  customQuestions: [],
};

const JUMP_SCROLL_FALLBACK_MS = 650;
const JUMP_RETURN_VISIBILITY_MS = 8000;
const RECOVERY_GLOW_MS = 1400;
const AUTO_SAVED_VISIBILITY_MS = 3300;
// This is intentionally the established, lightweight completion indicator. New optional intake details do not lower it.
const COMPLETION_FIELDS: Array<keyof ClientIntakeFormData> = [
  "deceasedFirstName",
  "deceasedMiddleNames",
  "deceasedLastName",
  "dateOfBirth",
  "dateOfDeath",
  "deceasedAddress",
  "willStatus",
  "willDate",
  "willLocation",
  "clientName",
  "clientEmail",
  "clientPhone",
  "relationshipToDeceased",
  "clientNotes",
];
const documentOptions: Array<{
  value: ClientIntakePayload["documentsAvailable"][number];
  label: string;
}> = [
  { value: "original_will", label: "Original will" },
  { value: "death_certificate", label: "Death certificate" },
  { value: "tax_return", label: "Most recent tax return" },
  { value: "identification", label: "Identification" },
];
const personCategories: Array<{ value: PersonCategory; label: string }> = [
  { value: "spouse", label: "Spouse" },
  { value: "former_spouse", label: "Former spouse" },
  { value: "child", label: "Child" },
  { value: "parent", label: "Parent" },
  { value: "sibling", label: "Sibling" },
  { value: "will_named_person", label: "Person named in the will" },
  { value: "other", label: "Other" },
];

// A family-category choice is the client's reported relationship, not a legal
// role. Keeping the same value in the dedicated relationship field makes that
// report visible to the lawyer's per-field review and preserves it if applied.
const relationshipForFamilyCategory: Partial<Record<PersonCategory, string>> = {
  spouse: "spouse",
  child: "child",
  parent: "parent",
  sibling: "sibling",
};

const JumpReturnContext = React.createContext<{
  activeField: ClientIntakeRevisionField | null;
  onReturn: (() => void) | null;
  errorField: ClientIntakeRevisionField | null;
  errorMessage: string | null;
  recoveredField: ClientIntakeRevisionField | null;
  autoSavedField: ClientIntakeRevisionField | null;
  onFieldEdit: (field: ClientIntakeRevisionField, target?: HTMLElement) => void;
}>({
  activeField: null,
  onReturn: null,
  errorField: null,
  errorMessage: null,
  recoveredField: null,
  autoSavedField: null,
  onFieldEdit: () => undefined,
});

function hasTargetValidationError(target: HTMLElement) {
  if (
    target.getAttribute("aria-invalid") === "true" ||
    target.closest("[data-invalid=true]") ||
    target.closest(".has-error")
  )
    return true;
  return (
    (target instanceof HTMLInputElement ||
      target instanceof HTMLSelectElement ||
      target instanceof HTMLTextAreaElement) &&
    !target.checkValidity()
  );
}

function hasNativeValidationError(target?: HTMLElement) {
  return Boolean(
    target &&
      (target instanceof HTMLInputElement ||
        target instanceof HTMLSelectElement ||
        target instanceof HTMLTextAreaElement) &&
      !target.checkValidity()
  );
}

function validationMessageForTarget(target: HTMLElement) {
  const explicitMessage = target.getAttribute("data-validation-message");
  if (explicitMessage) return explicitMessage;
  const errorId = target.getAttribute("aria-errormessage");
  const linkedMessage = errorId
    ? document.getElementById(errorId)?.textContent?.trim()
    : "";
  if (linkedMessage) return linkedMessage;
  if (
    target instanceof HTMLInputElement ||
    target instanceof HTMLSelectElement ||
    target instanceof HTMLTextAreaElement
  )
    return (
      target.validationMessage ||
      "Please review this field and correct the highlighted value."
    );
  return "Please review this field and correct the highlighted value.";
}

function attentionClasses(highlighted: boolean, hasError: boolean) {
  if (!highlighted) return "";
  return `client-intake-field-attention ${hasError ? "client-intake-field-attention-error client-intake-field-attention-error-shake ring-2 ring-red-500/70 ring-offset-2" : "client-intake-field-attention-standard ring-2 ring-blue-500/70 ring-offset-2"}`;
}

function validationFieldsFor(
  form: ClientIntakeFormData,
  activeErrorField: ClientIntakeRevisionField | null
) {
  const fields: ClientIntakeRevisionField[] = [];
  if (!form.clientName.trim()) fields.push("clientName");
  if (
    !form.clientEmail.trim() ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.clientEmail)
  )
    fields.push("clientEmail");
  if (activeErrorField && !fields.includes(activeErrorField))
    fields.push(activeErrorField);
  return fields;
}

function normalizePerson(
  person: Partial<ClientIntakePerson>,
  fallbackCategory: PersonCategory
) {
  return { ...emptyPerson(fallbackCategory), ...person } as ClientIntakePerson;
}

function normalizeItem(item: Partial<ClientIntakeItem>) {
  return {
    ...emptyItem(item.category || "tangible"),
    ...item,
  } as ClientIntakeItem;
}

function formFromPayload(
  payload: Partial<ClientIntakePayload> | undefined,
  contactName: string,
  email: string
): ClientIntakeFormData {
  return {
    ...emptyForm,
    ...payload,
    clientName: payload?.clientName || contactName,
    clientEmail: payload?.clientEmail || email,
    executors: Array.isArray(payload?.executors)
      ? payload.executors.map(person => normalizePerson(person, "executor"))
      : [],
    familyMembers: Array.isArray(payload?.familyMembers)
      ? payload.familyMembers.map(person => normalizePerson(person, "other"))
      : [],
    estateItems: Array.isArray(payload?.estateItems)
      ? payload.estateItems.map(normalizeItem)
      : [],
    documentsAvailable: Array.isArray(payload?.documentsAvailable)
      ? payload.documentsAvailable
      : [],
  };
}

export function ClientIntakeForm({
  contactName,
  email,
  draftScope = "",
  existingSubmissions,
}: {
  contactName: string;
  email: string;
  /** Opaque authenticated portal scope; never displayed or submitted. */
  draftScope?: string;
  existingSubmissions: ExistingSubmission[];
}) {
  const [form, setForm] = useState<ClientIntakeFormData>(() =>
    formFromPayload(undefined, contactName, email)
  );
  const prefilledRevisionId = useRef<string | null>(null);
  const jumpResetTimer = useRef<number | null>(null);
  const jumpFocusFrame = useRef<number | null>(null);
  const jumpCompletionTimer = useRef<number | null>(null);
  const jumpReturnTimer = useRef<number | null>(null);
  const recoveryResetTimer = useRef<number | null>(null);
  const autoSaveResetTimer = useRef<number | null>(null);
  const scrollEndHandler = useRef<(() => void) | null>(null);
  const utils = trpc.useUtils();
  const {
    data: customQuestionConfig,
    isLoading: isCustomQuestionLoading,
    isError: isCustomQuestionError,
  } = trpc.portal.clientIntakeQuestions.useQuery();
  const [customQuestionErrorId, setCustomQuestionErrorId] = useState<
    string | null
  >(null);
  const [submittedReceipt, setSubmittedReceipt] = useState<{
    id: string;
    payload: ClientIntakePayload;
  } | null>(null);
  const submittedPayload = useRef<ClientIntakePayload | null>(null);
  const submittedConfirmationHeadingRef = useRef<HTMLHeadingElement>(null);
  const focusRestoredDraftRef = useRef(false);
  const [isDraftDirty, setIsDraftDirty] = useState(false);
  const draftKey = `client_intake_${draftScope || "unscoped"}`;
  const { pendingDraft, acceptDraft, dismissDraft, clearDraft } = useLocalDraft(
    {
      key: draftKey,
      data: form,
      isDirty: Boolean(draftScope) && isDraftDirty,
    }
  );
  const submit = trpc.portal.submitClientIntake.useMutation({
    onSuccess: result => {
      setSubmittedReceipt({
        id: result.id,
        payload: submittedPayload.current || form,
      });
      clearDraft();
      setIsDraftDirty(false);
      toast.success(
        "Your information has been sent to the legal team for review."
      );
      void utils.portal.clientIntakeSubmissions.invalidate();
    },
    onError: error =>
      toast.error(
        error.message || "Your intake form could not be sent. Please try again."
      ),
  });
  const latest = useMemo(() => existingSubmissions[0], [existingSubmissions]);
  const receiptSubmission = useMemo(
    () =>
      submittedReceipt
        ? existingSubmissions.find(
            submission => submission.id === submittedReceipt.id
          )
        : null,
    [existingSubmissions, submittedReceipt]
  );
  const submissionStatus = submittedReceipt
    ? receiptSubmission?.status || "submitted"
    : latest?.status || "submitted";
  const showsSubmittedConfirmation =
    Boolean(submittedReceipt) ||
    latest?.status === "submitted" ||
    latest?.status === "approved";
  const submissionIsApproved = submissionStatus === "approved";
  const submittedPayloadForReceipt = useMemo(() => {
    if (submittedReceipt) return submittedReceipt.payload;
    return latest ? formFromPayload(latest.payload, contactName, email) : null;
  }, [contactName, email, latest, submittedReceipt]);
  useEffect(() => {
    if (
      submittedReceipt &&
      latest?.id === submittedReceipt.id &&
      latest.status === "revision_requested"
    )
      setSubmittedReceipt(null);
  }, [latest?.id, latest?.status, submittedReceipt]);
  useEffect(() => {
    if (!showsSubmittedConfirmation) return;
    clearDraft();
    setIsDraftDirty(false);
  }, [clearDraft, showsSubmittedConfirmation]);
  useEffect(() => {
    if (showsSubmittedConfirmation)
      submittedConfirmationHeadingRef.current?.focus();
  }, [showsSubmittedConfirmation]);
  useEffect(() => {
    if (!focusRestoredDraftRef.current) return;
    focusRestoredDraftRef.current = false;
    document.getElementById("client-intake-clientName")?.focus();
  }, [form]);
  useEffect(() => {
    if (
      !latest ||
      latest.status !== "revision_requested" ||
      prefilledRevisionId.current === latest.id
    )
      return;
    prefilledRevisionId.current = latest.id;
    setForm(formFromPayload(latest.payload, contactName, email));
  }, [contactName, email, latest]);

  useEffect(() => {
    if (!customQuestionConfig) return;
    setForm(current => {
      const answersById = new Map(
        current.customQuestions.map(question => [question.id, question.answer])
      );
      return {
        ...current,
        customQuestions: customQuestionConfig.questions.map(question => ({
          ...question,
          answer: answersById.get(question.id) || "",
        })),
      };
    });
  }, [customQuestionConfig]);

  const [jumpedField, setJumpedField] =
    useState<ClientIntakeRevisionField | null>(null);
  const [jumpedFieldHasError, setJumpedFieldHasError] = useState(false);
  const [jumpedFieldErrorMessage, setJumpedFieldErrorMessage] = useState<
    string | null
  >(null);
  const [recoveredField, setRecoveredField] =
    useState<ClientIntakeRevisionField | null>(null);
  const [autoSavedField, setAutoSavedField] =
    useState<ClientIntakeRevisionField | null>(null);
  const [returnField, setReturnField] =
    useState<ClientIntakeRevisionField | null>(null);
  const [jumpOrigin, setJumpOrigin] = useState<{ x: number; y: number } | null>(
    null
  );
  const [resolvedFields, setResolvedFields] = useState<
    Set<ClientIntakeRevisionField>
  >(() => new Set());
  const revisionResolutionKey =
    latest?.status === "revision_requested"
      ? `client-intake-resolved:${latest.id}:${latest.revisionRequestedAt ?? latest.submittedAt}`
      : null;

  useEffect(() => {
    if (!revisionResolutionKey) {
      setResolvedFields(new Set());
      return;
    }
    try {
      const saved = JSON.parse(
        window.sessionStorage.getItem(revisionResolutionKey) || "[]"
      );
      setResolvedFields(
        new Set(
          Array.isArray(saved)
            ? saved.filter(
                (field): field is ClientIntakeRevisionField =>
                  typeof field === "string"
              )
            : []
        )
      );
    } catch {
      setResolvedFields(new Set());
    }
  }, [revisionResolutionKey]);

  useEffect(
    () => () => {
      if (jumpResetTimer.current) window.clearTimeout(jumpResetTimer.current);
      if (jumpFocusFrame.current)
        window.cancelAnimationFrame(jumpFocusFrame.current);
      if (jumpCompletionTimer.current)
        window.clearTimeout(jumpCompletionTimer.current);
      if (jumpReturnTimer.current) window.clearTimeout(jumpReturnTimer.current);
      if (recoveryResetTimer.current)
        window.clearTimeout(recoveryResetTimer.current);
      if (autoSaveResetTimer.current)
        window.clearTimeout(autoSaveResetTimer.current);
      if (scrollEndHandler.current)
        window.removeEventListener("scrollend", scrollEndHandler.current);
    },
    []
  );

  const dismissInvalidGuidanceOnEdit = (
    field: ClientIntakeRevisionField,
    target?: HTMLElement
  ) => {
    if (jumpedField !== field || !jumpedFieldHasError) return;
    if (jumpResetTimer.current) window.clearTimeout(jumpResetTimer.current);
    setJumpedField(null);
    setJumpedFieldHasError(false);
    setJumpedFieldErrorMessage(null);
    if (hasNativeValidationError(target)) return;
    if (recoveryResetTimer.current)
      window.clearTimeout(recoveryResetTimer.current);
    if (autoSaveResetTimer.current)
      window.clearTimeout(autoSaveResetTimer.current);
    setAutoSavedField(null);
    setRecoveredField(field);
    recoveryResetTimer.current = window.setTimeout(() => {
      setRecoveredField(null);
      recoveryResetTimer.current = null;
      setAutoSavedField(field);
      autoSaveResetTimer.current = window.setTimeout(() => {
        setAutoSavedField(null);
        autoSaveResetTimer.current = null;
      }, AUTO_SAVED_VISIBILITY_MS);
    }, RECOVERY_GLOW_MS);
  };

  const set = <K extends keyof ClientIntakeFormData>(
    key: K,
    value: ClientIntakeFormData[K]
  ) => {
    setIsDraftDirty(true);
    setForm(current => ({ ...current, [key]: value }));
  };
  const updatePerson = (
    collection: "executors" | "familyMembers",
    index: number,
    key: keyof ClientIntakePerson,
    value: string
  ) => {
    setIsDraftDirty(true);
    setForm(current => ({
      ...current,
      [collection]: current[collection].map((person, personIndex) =>
        personIndex === index
          ? (() => {
              const next = { ...person, [key]: value };
              if (key === "category" && collection === "familyMembers") {
                const priorRelationship = relationshipForFamilyCategory[person.category];
                const nextRelationship = relationshipForFamilyCategory[value as PersonCategory];
                if (!person.relationship || person.relationship === priorRelationship)
                  next.relationship = nextRelationship || "";
              }
              return next;
            })()
          : person
      ),
    }));
  };
  const removePerson = (
    collection: "executors" | "familyMembers",
    index: number
  ) => {
    setIsDraftDirty(true);
    setForm(current => ({
      ...current,
      [collection]: current[collection].filter(
        (_, personIndex) => personIndex !== index
      ),
    }));
  };
  const addPerson = (collection: "executors" | "familyMembers") => {
    setIsDraftDirty(true);
    setForm(current => ({
      ...current,
      [collection]: [
        ...current[collection],
        emptyPerson(collection === "executors" ? "executor" : "other"),
      ],
    }));
  };
  const updateItem = (
    index: number,
    key: keyof ClientIntakeItem,
    value: string
  ) => {
    setIsDraftDirty(true);
    setForm(current => ({
      ...current,
      estateItems: current.estateItems.map((item, itemIndex) =>
        itemIndex === index ? { ...item, [key]: value } : item
      ),
    }));
  };
  const addItem = (category: ItemCategory) => {
    setIsDraftDirty(true);
    setForm(current => ({
      ...current,
      estateItems: [...current.estateItems, emptyItem(category)],
    }));
  };
  const removeItem = (index: number) => {
    setIsDraftDirty(true);
    setForm(current => ({
      ...current,
      estateItems: current.estateItems.filter(
        (_, itemIndex) => itemIndex !== index
      ),
    }));
  };
  const setDocumentAvailable = (
    document: ClientIntakePayload["documentsAvailable"][number],
    checked: boolean
  ) => {
    setIsDraftDirty(true);
    setForm(current => ({
      ...current,
      documentsAvailable: checked
        ? Array.from(new Set([...current.documentsAvailable, document]))
        : current.documentsAvailable.filter(value => value !== document),
    }));
  };
  const setCustomQuestionAnswer = (id: string, answer: string) => {
    setIsDraftDirty(true);
    setForm(current => ({
      ...current,
      customQuestions: current.customQuestions.map(question =>
        question.id === id ? { ...question, answer } : question
      ),
    }));
    if (customQuestionErrorId === id) setCustomQuestionErrorId(null);
  };
  const submitForReview = () => {
    const unansweredRequired = form.customQuestions.find(
      question => question.required && !question.answer.trim()
    );
    if (unansweredRequired) {
      setCustomQuestionErrorId(unansweredRequired.id);
      document
        .getElementById(`client-intake-custom-${unansweredRequired.id}`)
        ?.focus();
      return;
    }
    setCustomQuestionErrorId(null);
    const { customQuestions, ...formAnswers } = form;
    submittedPayload.current = form;
    submit.mutate({
      ...formAnswers,
      customQuestionAnswers: customQuestions.map(question => ({
        id: question.id,
        answer: question.answer,
      })),
    });
  };

  const jumpToField = (
    field: ClientIntakeRevisionField,
    forceValidationError = false
  ) => {
    const targetField =
      field === "deceasedResidenceCity" || field === "domicileCity"
        ? "deceasedAddress"
        : field;
    const target = document.getElementById(
      `client-intake-${targetField}`
    ) as HTMLElement | null;
    if (!target) {
      toast.error(
        "That field is not available in the current form state. Review the related section and try again."
      );
      return;
    }
    const reduceMotion = window.matchMedia?.(
      "(prefers-reduced-motion: reduce)"
    )?.matches;
    const finishJump = () => {
      if (jumpCompletionTimer.current)
        window.clearTimeout(jumpCompletionTimer.current);
      jumpCompletionTimer.current = null;
      if (scrollEndHandler.current)
        window.removeEventListener("scrollend", scrollEndHandler.current);
      scrollEndHandler.current = null;
      target.focus({ preventScroll: true });
      setJumpedField(field);
      const targetHasError =
        forceValidationError || hasTargetValidationError(target);
      setJumpedFieldHasError(targetHasError);
      setJumpedFieldErrorMessage(
        targetHasError ? validationMessageForTarget(target) : null
      );
      setReturnField(field);
      if (jumpResetTimer.current) window.clearTimeout(jumpResetTimer.current);
      jumpResetTimer.current = window.setTimeout(() => {
        setJumpedField(null);
        setJumpedFieldHasError(false);
        setJumpedFieldErrorMessage(null);
      }, 1800);
      if (jumpReturnTimer.current) window.clearTimeout(jumpReturnTimer.current);
      jumpReturnTimer.current = window.setTimeout(() => {
        setJumpOrigin(null);
        setReturnField(null);
        jumpReturnTimer.current = null;
      }, JUMP_RETURN_VISIBILITY_MS);
    };
    if (jumpFocusFrame.current)
      window.cancelAnimationFrame(jumpFocusFrame.current);
    if (jumpCompletionTimer.current)
      window.clearTimeout(jumpCompletionTimer.current);
    if (scrollEndHandler.current)
      window.removeEventListener("scrollend", scrollEndHandler.current);
    if (jumpReturnTimer.current) window.clearTimeout(jumpReturnTimer.current);
    setJumpedField(null);
    setJumpedFieldHasError(false);
    setJumpedFieldErrorMessage(null);
    setAutoSavedField(null);
    setJumpOrigin({ x: window.scrollX, y: window.scrollY });
    const bounds = target.getBoundingClientRect();
    const centeredTop = Math.max(
      0,
      window.scrollY +
        bounds.top -
        Math.max(0, (window.innerHeight - bounds.height) / 2)
    );
    window.scrollTo({
      left: window.scrollX,
      top: centeredTop,
      behavior: reduceMotion ? "auto" : "smooth",
    });
    if (reduceMotion) {
      finishJump();
      return;
    }
    scrollEndHandler.current = finishJump;
    window.addEventListener("scrollend", finishJump, { once: true });
    if (typeof window.requestAnimationFrame !== "function") {
      finishJump();
    } else {
      jumpFocusFrame.current = window.requestAnimationFrame(() => {
        jumpFocusFrame.current = null;
        jumpCompletionTimer.current = window.setTimeout(
          finishJump,
          JUMP_SCROLL_FALLBACK_MS
        );
      });
    }
  };

  const returnToJumpOrigin = () => {
    if (!jumpOrigin) return;
    const reduceMotion = window.matchMedia?.(
      "(prefers-reduced-motion: reduce)"
    )?.matches;
    if (jumpReturnTimer.current) window.clearTimeout(jumpReturnTimer.current);
    setJumpedField(null);
    setJumpedFieldHasError(false);
    setJumpedFieldErrorMessage(null);
    setAutoSavedField(null);
    setReturnField(null);
    setJumpOrigin(null);
    window.scrollTo({
      left: jumpOrigin.x,
      top: jumpOrigin.y,
      behavior: reduceMotion ? "auto" : "smooth",
    });
  };

  const revisionFieldComments = latest?.revisionFieldComments || [];
  const remainingValidationFields = useMemo(
    () => validationFieldsFor(form, jumpedFieldHasError ? jumpedField : null),
    [form, jumpedField, jumpedFieldHasError]
  );
  const remainingValidationErrors = remainingValidationFields.length;
  const completionPercent = useMemo(() => {
    const completedFields = COMPLETION_FIELDS.filter(field =>
      field === "willStatus"
        ? form.willStatus !== "unknown"
        : Boolean((form[field] as string).trim())
    );
    return Math.round(
      (completedFields.length / COMPLETION_FIELDS.length) * 100
    );
  }, [form]);
  const jumpToNextValidationError = () => {
    if (remainingValidationFields.length === 0) return;
    const currentIndex = jumpedField
      ? remainingValidationFields.indexOf(jumpedField)
      : -1;
    jumpToField(
      remainingValidationFields[
        (currentIndex + 1 + remainingValidationFields.length) %
          remainingValidationFields.length
      ],
      true
    );
  };
  const setFieldResolved = (
    field: ClientIntakeRevisionField,
    resolved: boolean
  ) => {
    setResolvedFields(current => {
      const next = new Set(current);
      if (resolved) next.add(field);
      else next.delete(field);
      if (revisionResolutionKey)
        window.sessionStorage.setItem(
          revisionResolutionKey,
          JSON.stringify(Array.from(next))
        );
      return next;
    });
  };
  const setDeceasedAddressFromAutocomplete = (
    components: AddressComponents
  ) => {
    setIsDraftDirty(true);
    setForm(current => ({
      ...current,
      deceasedAddress: components.fullAddress || current.deceasedAddress,
      addressStreet: components.street || current.addressStreet,
      addressUnit: components.unit || current.addressUnit,
      addressCity: components.city || current.addressCity,
      addressProvince: components.province || current.addressProvince,
      addressPostalCode: components.postalCode || current.addressPostalCode,
      addressCountry: components.country || current.addressCountry,
      deceasedResidenceCity: components.city || current.deceasedResidenceCity,
    }));
    dismissInvalidGuidanceOnEdit("deceasedAddress");
  };
  const restoreDraft = () => {
    const draft = acceptDraft();
    if (!draft) return;
    const draftAnswers = new Map(
      (Array.isArray(draft.customQuestions) ? draft.customQuestions : []).map(
        question => [question.id, question.answer]
      )
    );
    setForm(current => ({
      ...formFromPayload(draft, contactName, email),
      customQuestions: current.customQuestions.map(question => ({
        ...question,
        answer: draftAnswers.get(question.id) || "",
      })),
    }));
    focusRestoredDraftRef.current = true;
    setIsDraftDirty(true);
  };

  if (showsSubmittedConfirmation) {
    return (
      <SubmittedIntakeConfirmation
        headingRef={submittedConfirmationHeadingRef}
        isApproved={submissionIsApproved}
        payload={submittedPayloadForReceipt || form}
        status={submissionStatus}
      />
    );
  }

  return (
    <JumpReturnContext.Provider
      value={{
        activeField: returnField,
        onReturn: jumpOrigin ? returnToJumpOrigin : null,
        errorField: jumpedFieldHasError ? jumpedField : null,
        errorMessage: jumpedFieldErrorMessage,
        recoveredField,
        autoSavedField,
        onFieldEdit: dismissInvalidGuidanceOnEdit,
      }}
    >
      <Card className="border-primary/20 shadow-sm">
        <CardHeader className="gap-2">
          <div className="flex items-start gap-3">
            <div className="rounded-xl bg-primary/10 p-2.5 text-primary">
              <ClipboardCheck className="h-5 w-5" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <CardTitle className="text-base">
                Share intake details with your legal team
              </CardTitle>
              <CardDescription className="mt-1">
                Your answers are saved for review. They are not added to the
                estate file until a lawyer verifies and approves them.
              </CardDescription>
            </div>
          </div>
          {draftScope && pendingDraft && (
            <section
              aria-labelledby="client-intake-draft-heading"
              className="flex flex-col gap-3 rounded-lg border border-primary/20 bg-primary/[0.04] px-3 py-3 sm:flex-row sm:items-center sm:justify-between"
            >
              <div className="min-w-0">
                <p
                  id="client-intake-draft-heading"
                  role="status"
                  aria-live="polite"
                  aria-label="Saved client intake draft"
                  className="text-sm font-medium text-foreground"
                >
                  A saved draft is available
                </p>
                <p className="mt-0.5 text-xs leading-5 text-muted-foreground">
                  It is stored on this device until you send the intake or
                  discard it.
                </p>
              </div>
              <div className="flex shrink-0 flex-wrap gap-2">
                <Button type="button" size="sm" onClick={restoreDraft}>
                  Restore saved draft
                </Button>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={dismissDraft}
                >
                  Discard saved draft
                </Button>
              </div>
            </section>
          )}
          {latest && (
            <div className="rounded-lg bg-muted/70 px-3 py-2 text-xs text-muted-foreground">
              <div className="flex flex-wrap items-center gap-2">
                <ClientIntakeStatusBadge status={latest.status} />
                <p className="text-sm text-foreground/85">
                  {latest.status === "approved"
                    ? "Your latest submission has been reviewed and approved."
                    : latest.status === "revision_requested"
                      ? "The legal team requested revisions. Read the request below, then update the prefilled form and send it again."
                      : "Your latest submission is waiting for lawyer review."}
                </p>
              </div>
              {latest.status === "revision_requested" &&
                (latest.revisionRequest ||
                  revisionFieldComments.length > 0) && (
                  <Collapsible className="mt-3 border-t border-border/70 pt-3">
                    <CollapsibleTrigger className="group flex w-full items-center justify-between gap-3 rounded-md text-left text-sm font-medium text-primary outline-none transition-colors hover:text-primary/80 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
                      <span className="flex items-center gap-2">
                        <MessageSquareText
                          className="h-4 w-4"
                          aria-hidden="true"
                        />
                        Read requested revisions
                      </span>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="pt-3">
                      <div
                        role="note"
                        aria-label="Lawyer requested revisions"
                        className="rounded-md border border-amber-500/20 bg-amber-500/5 p-3 text-sm text-foreground/90"
                      >
                        <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                          Requested revisions
                        </p>
                        {latest.revisionRequest && (
                          <p className="whitespace-pre-wrap leading-6">
                            {latest.revisionRequest}
                          </p>
                        )}
                        {revisionFieldComments.length > 0 && (
                          <div
                            className={`${latest.revisionRequest ? "mt-3 border-t border-amber-500/15 pt-3" : ""} space-y-2`}
                          >
                            {revisionFieldComments.map(({ field, comment }) => (
                              <div
                                key={field}
                                className={`flex flex-col gap-2 rounded-md bg-background/60 p-2.5 transition-opacity sm:flex-row sm:items-start sm:justify-between ${resolvedFields.has(field) ? "opacity-75" : ""}`}
                              >
                                <div className="min-w-0">
                                  <p className="text-xs font-semibold text-muted-foreground">
                                    {CLIENT_INTAKE_REVISION_FIELD_LABELS[field]}
                                  </p>
                                  <p className="mt-1 whitespace-pre-wrap leading-6">
                                    {comment}
                                  </p>
                                  <label className="mt-2 flex w-fit cursor-pointer items-center gap-2 text-xs font-medium text-muted-foreground">
                                    <Checkbox
                                      checked={resolvedFields.has(field)}
                                      onCheckedChange={checked =>
                                        setFieldResolved(
                                          field,
                                          checked === true
                                        )
                                      }
                                    />
                                    <span>Mark as resolved</span>
                                    <span
                                      className="sr-only"
                                      aria-live="polite"
                                    >
                                      {resolvedFields.has(field)
                                        ? "Marked as resolved"
                                        : "Not marked as resolved"}
                                    </span>
                                  </label>
                                </div>
                                <Button
                                  type="button"
                                  size="sm"
                                  variant="outline"
                                  onClick={() => jumpToField(field)}
                                  className="shrink-0"
                                >
                                  <LocateFixed
                                    className="mr-1.5 h-3.5 w-3.5"
                                    aria-hidden="true"
                                  />
                                  Jump to field
                                </Button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                )}
            </div>
          )}
        </CardHeader>
        <CardContent className="space-y-7">
          <IntakeCompletionProgress completionPercent={completionPercent} />
          <ValidationSummaryBadge
            remainingValidationErrors={remainingValidationErrors}
            onJumpToNext={jumpToNextValidationError}
          />

          <section className="space-y-4" aria-labelledby="about-you-heading">
            <SectionHeading
              id="about-you-heading"
              title="About you"
              description="Please enter the contact details you would like the legal team to use."
            />
            <div className="grid gap-4 md:grid-cols-2">
              <Field
                field="clientName"
                highlighted={jumpedField === "clientName"}
                attentionError={jumpedFieldHasError}
                label="Your name"
              >
                <Input
                  value={form.clientName}
                  onChange={event => set("clientName", event.target.value)}
                  autoComplete="name"
                />
              </Field>
              <Field
                field="clientOccupation"
                highlighted={jumpedField === "clientOccupation"}
                attentionError={jumpedFieldHasError}
                label="Your occupation"
              >
                <Input
                  value={form.clientOccupation}
                  onChange={event =>
                    set("clientOccupation", event.target.value)
                  }
                  autoComplete="organization-title"
                />
              </Field>
              <Field
                field="clientDateOfBirth"
                highlighted={jumpedField === "clientDateOfBirth"}
                attentionError={jumpedFieldHasError}
                label="Your date of birth"
              >
                <Input
                  type="date"
                  value={form.clientDateOfBirth}
                  onChange={event =>
                    set("clientDateOfBirth", event.target.value)
                  }
                  autoComplete="bday"
                />
              </Field>
              <Field
                field="clientEmail"
                highlighted={jumpedField === "clientEmail"}
                attentionError={jumpedFieldHasError}
                label="Your email"
              >
                <Input
                  type="email"
                  value={form.clientEmail}
                  onChange={event => set("clientEmail", event.target.value)}
                  autoComplete="email"
                />
              </Field>
              <Field
                field="clientPhone"
                highlighted={jumpedField === "clientPhone"}
                attentionError={jumpedFieldHasError}
                label="Your phone"
              >
                <Input
                  value={form.clientPhone}
                  onChange={event => set("clientPhone", event.target.value)}
                  autoComplete="tel"
                />
              </Field>
              <Field
                field="relationshipToDeceased"
                highlighted={jumpedField === "relationshipToDeceased"}
                attentionError={jumpedFieldHasError}
                label="Relationship to the deceased"
              >
                <Input
                  value={form.relationshipToDeceased}
                  onChange={event =>
                    set("relationshipToDeceased", event.target.value)
                  }
                />
              </Field>
            </div>
            <fieldset className="space-y-4 rounded-lg border border-border/70 p-4">
              <legend className="px-1 text-sm font-medium">Your address</legend>
              <div className="grid gap-4 md:grid-cols-2">
                <Field
                  field="clientAddressStreet"
                  highlighted={jumpedField === "clientAddressStreet"}
                  attentionError={jumpedFieldHasError}
                  label="Your street address"
                >
                  <Input
                    value={form.clientAddressStreet}
                    onChange={event =>
                      set("clientAddressStreet", event.target.value)
                    }
                    autoComplete="address-line1"
                  />
                </Field>
                <Field
                  field="clientAddressUnit"
                  highlighted={jumpedField === "clientAddressUnit"}
                  attentionError={jumpedFieldHasError}
                  label="Your unit or suite"
                >
                  <Input
                    value={form.clientAddressUnit}
                    onChange={event =>
                      set("clientAddressUnit", event.target.value)
                    }
                    autoComplete="address-line2"
                  />
                </Field>
                <Field
                  field="clientAddressCity"
                  highlighted={jumpedField === "clientAddressCity"}
                  attentionError={jumpedFieldHasError}
                  label="Your city"
                >
                  <Input
                    value={form.clientAddressCity}
                    onChange={event =>
                      set("clientAddressCity", event.target.value)
                    }
                    autoComplete="address-level2"
                  />
                </Field>
                <Field
                  field="clientAddressProvince"
                  highlighted={jumpedField === "clientAddressProvince"}
                  attentionError={jumpedFieldHasError}
                  label="Your province or state"
                >
                  <Input
                    value={form.clientAddressProvince}
                    onChange={event =>
                      set("clientAddressProvince", event.target.value)
                    }
                    autoComplete="address-level1"
                  />
                </Field>
                <Field
                  field="clientAddressPostalCode"
                  highlighted={jumpedField === "clientAddressPostalCode"}
                  attentionError={jumpedFieldHasError}
                  label="Your postal code"
                >
                  <Input
                    value={form.clientAddressPostalCode}
                    onChange={event =>
                      set("clientAddressPostalCode", event.target.value)
                    }
                    autoComplete="postal-code"
                  />
                </Field>
                <Field
                  field="clientAddressCountry"
                  highlighted={jumpedField === "clientAddressCountry"}
                  attentionError={jumpedFieldHasError}
                  label="Your country"
                >
                  <Input
                    value={form.clientAddressCountry}
                    onChange={event =>
                      set("clientAddressCountry", event.target.value)
                    }
                    autoComplete="country-name"
                  />
                </Field>
              </div>
            </fieldset>
            <Field
              field="clientNotes"
              highlighted={jumpedField === "clientNotes"}
              attentionError={jumpedFieldHasError}
              label="Anything else the legal team should know"
            >
              <Textarea
                value={form.clientNotes}
                onChange={event => set("clientNotes", event.target.value)}
                rows={4}
                maxLength={4000}
              />
            </Field>
          </section>

          <section
            className="space-y-4 border-t pt-6"
            aria-labelledby="deceased-heading"
          >
            <SectionHeading
              id="deceased-heading"
              title="About the person who died"
              description="Please enter names exactly as shown on key records, if known."
            />
            <div className="grid gap-4 md:grid-cols-3">
              <Field
                field="deceasedFirstName"
                highlighted={jumpedField === "deceasedFirstName"}
                attentionError={jumpedFieldHasError}
                label="First name"
              >
                <Input
                  value={form.deceasedFirstName}
                  onChange={event =>
                    set("deceasedFirstName", event.target.value)
                  }
                  autoComplete="off"
                />
              </Field>
              <Field
                field="deceasedMiddleNames"
                highlighted={jumpedField === "deceasedMiddleNames"}
                attentionError={jumpedFieldHasError}
                label="Middle name(s)"
              >
                <Input
                  value={form.deceasedMiddleNames}
                  onChange={event =>
                    set("deceasedMiddleNames", event.target.value)
                  }
                  autoComplete="off"
                />
              </Field>
              <Field
                field="deceasedLastName"
                highlighted={jumpedField === "deceasedLastName"}
                attentionError={jumpedFieldHasError}
                label="Last name"
              >
                <Input
                  value={form.deceasedLastName}
                  onChange={event =>
                    set("deceasedLastName", event.target.value)
                  }
                  autoComplete="off"
                />
              </Field>
            </div>
            <fieldset className="space-y-3 rounded-lg border border-border/70 p-4">
              <legend className="px-1 text-sm font-medium">
                Other name details (optional)
              </legend>
              <p className="text-xs leading-5 text-muted-foreground">
                If one other name is known, enter each part separately. You can
                list any additional full-name-only aliases below.
              </p>
              <div className="grid gap-4 md:grid-cols-3">
                <Field
                  field="deceasedAkaFirstName"
                  highlighted={jumpedField === "deceasedAkaFirstName"}
                  attentionError={jumpedFieldHasError}
                  label="Other name first name"
                >
                  <Input
                    value={form.deceasedAkaFirstName}
                    onChange={event =>
                      set("deceasedAkaFirstName", event.target.value)
                    }
                    autoComplete="off"
                  />
                </Field>
                <Field
                  field="deceasedAkaMiddleName"
                  highlighted={jumpedField === "deceasedAkaMiddleName"}
                  attentionError={jumpedFieldHasError}
                  label="Other name middle name(s)"
                >
                  <Input
                    value={form.deceasedAkaMiddleName}
                    onChange={event =>
                      set("deceasedAkaMiddleName", event.target.value)
                    }
                    autoComplete="off"
                  />
                </Field>
                <Field
                  field="deceasedAkaLastName"
                  highlighted={jumpedField === "deceasedAkaLastName"}
                  attentionError={jumpedFieldHasError}
                  label="Other name last name"
                >
                  <Input
                    value={form.deceasedAkaLastName}
                    onChange={event =>
                      set("deceasedAkaLastName", event.target.value)
                    }
                    autoComplete="off"
                  />
                </Field>
              </div>
              <Field
                field="deceasedAliases"
                highlighted={jumpedField === "deceasedAliases"}
                attentionError={jumpedFieldHasError}
                label="Other names used"
              >
                <Input
                  value={form.deceasedAliases}
                  onChange={event => set("deceasedAliases", event.target.value)}
                />
              </Field>
            </fieldset>
            <div className="grid gap-4 md:grid-cols-3">
              <Field
                field="deceasedPlaceOfBirth"
                highlighted={jumpedField === "deceasedPlaceOfBirth"}
                attentionError={jumpedFieldHasError}
                label="Place of birth"
              >
                <Input
                  value={form.deceasedPlaceOfBirth}
                  onChange={event =>
                    set("deceasedPlaceOfBirth", event.target.value)
                  }
                />
              </Field>
              <Field
                field="dateOfBirth"
                highlighted={jumpedField === "dateOfBirth"}
                attentionError={jumpedFieldHasError}
                label="Date of birth"
              >
                <Input
                  type="date"
                  value={form.dateOfBirth}
                  onChange={event => set("dateOfBirth", event.target.value)}
                />
              </Field>
              <Field
                field="dateOfDeath"
                highlighted={jumpedField === "dateOfDeath"}
                attentionError={jumpedFieldHasError}
                label="Date of death"
              >
                <Input
                  type="date"
                  value={form.dateOfDeath}
                  onChange={event => set("dateOfDeath", event.target.value)}
                />
              </Field>
              <Field
                field="placeOfDeath"
                highlighted={jumpedField === "placeOfDeath"}
                attentionError={jumpedFieldHasError}
                label="Place of death"
              >
                <Input
                  value={form.placeOfDeath}
                  onChange={event => set("placeOfDeath", event.target.value)}
                />
              </Field>
            </div>
            <fieldset className="space-y-4 rounded-lg border border-border/70 p-4">
              <legend className="px-1 text-sm font-medium">
                Last home address
              </legend>
              <ClientAddressField
                value={form.deceasedAddress}
                onChange={value => set("deceasedAddress", value)}
                onSelect={setDeceasedAddressFromAutocomplete}
                highlighted={jumpedField === "deceasedAddress"}
                attentionError={jumpedFieldHasError}
              />
              <p className="text-xs leading-relaxed text-muted-foreground">
                Search for the last home address above, or enter it manually.
                Add or adjust the address details below only if needed.
              </p>
              <div className="grid gap-4 md:grid-cols-2">
                <Field
                  field="addressStreet"
                  highlighted={jumpedField === "addressStreet"}
                  attentionError={jumpedFieldHasError}
                  label="Last home street address"
                >
                  <Input
                    value={form.addressStreet}
                    onChange={event => set("addressStreet", event.target.value)}
                    autoComplete="address-line1"
                  />
                </Field>
                <Field
                  field="addressUnit"
                  highlighted={jumpedField === "addressUnit"}
                  attentionError={jumpedFieldHasError}
                  label="Last home unit or suite"
                >
                  <Input
                    value={form.addressUnit}
                    onChange={event => set("addressUnit", event.target.value)}
                    autoComplete="address-line2"
                  />
                </Field>
                <Field
                  field="addressCity"
                  highlighted={jumpedField === "addressCity"}
                  attentionError={jumpedFieldHasError}
                  label="Last home city"
                >
                  <Input
                    value={form.addressCity}
                    onChange={event => set("addressCity", event.target.value)}
                    autoComplete="address-level2"
                  />
                </Field>
                <Field
                  field="addressProvince"
                  highlighted={jumpedField === "addressProvince"}
                  attentionError={jumpedFieldHasError}
                  label="Last home province or state"
                >
                  <Input
                    value={form.addressProvince}
                    onChange={event =>
                      set("addressProvince", event.target.value)
                    }
                    autoComplete="address-level1"
                  />
                </Field>
                <Field
                  field="addressPostalCode"
                  highlighted={jumpedField === "addressPostalCode"}
                  attentionError={jumpedFieldHasError}
                  label="Last home postal code"
                >
                  <Input
                    value={form.addressPostalCode}
                    onChange={event =>
                      set("addressPostalCode", event.target.value)
                    }
                    autoComplete="postal-code"
                  />
                </Field>
                <Field
                  field="addressCountry"
                  highlighted={jumpedField === "addressCountry"}
                  attentionError={jumpedFieldHasError}
                  label="Last home country"
                >
                  <Input
                    value={form.addressCountry}
                    onChange={event =>
                      set("addressCountry", event.target.value)
                    }
                    autoComplete="country-name"
                  />
                </Field>
              </div>
            </fieldset>
            <fieldset className="space-y-3">
              <legend className="text-sm font-medium">
                Did the deceased have a valid will?
              </legend>
              <RadioGroup
                id="client-intake-willStatus"
                tabIndex={-1}
                value={form.willStatus}
                onValueChange={value => {
                  set(
                    "willStatus",
                    value as ClientIntakeFormData["willStatus"]
                  );
                  dismissInvalidGuidanceOnEdit("willStatus");
                }}
                className={`scroll-mt-24 grid gap-2 rounded-md sm:grid-cols-3 ${attentionClasses(jumpedField === "willStatus", jumpedFieldHasError)}`}
              >
                <Choice
                  value="will"
                  label="Yes, a will exists"
                  selected={form.willStatus}
                />
                <Choice
                  value="no_will"
                  label="No will is known"
                  selected={form.willStatus}
                />
                <Choice
                  value="unknown"
                  label="I am not sure"
                  selected={form.willStatus}
                />
              </RadioGroup>
              {jumpedField === "willStatus" &&
                jumpedFieldHasError &&
                jumpedFieldErrorMessage && (
                  <ValidationHint
                    id="client-intake-willStatus-validation-error"
                    message={jumpedFieldErrorMessage}
                  />
                )}
              <JumpBackControl field="willStatus" />
            </fieldset>
            {form.willStatus === "will" && (
              <div className="grid gap-4 md:grid-cols-2">
                <Field
                  field="willDate"
                  highlighted={jumpedField === "willDate"}
                  attentionError={jumpedFieldHasError}
                  label="Date on the will, if known"
                >
                  <Input
                    type="date"
                    value={form.willDate}
                    onChange={event => set("willDate", event.target.value)}
                  />
                </Field>
                <Field
                  field="willLocation"
                  highlighted={jumpedField === "willLocation"}
                  attentionError={jumpedFieldHasError}
                  label="Where the original will is kept"
                >
                  <Input
                    value={form.willLocation}
                    onChange={event => set("willLocation", event.target.value)}
                  />
                </Field>
              </div>
            )}
            <fieldset className="space-y-3">
              <legend className="text-sm font-medium">
                Was the deceased a Nisga’a citizen or a member of a treaty First
                Nation?
              </legend>
              <RadioGroup
                id="client-intake-treatyFirstNation"
                tabIndex={-1}
                value={form.treatyFirstNation}
                onValueChange={value =>
                  set(
                    "treatyFirstNation",
                    value as ClientIntakeFormData["treatyFirstNation"]
                  )
                }
                className="grid gap-2 sm:grid-cols-2"
              >
                <Choice
                  value="no"
                  label="No"
                  selected={form.treatyFirstNation}
                />
                <Choice
                  value="nisga"
                  label="Nisga’a citizen"
                  selected={form.treatyFirstNation}
                />
                <Choice
                  value="yes"
                  label="Member of another treaty First Nation"
                  selected={form.treatyFirstNation}
                />
                <Choice
                  value=""
                  label="I am not sure"
                  selected={form.treatyFirstNation}
                />
              </RadioGroup>
              {(form.treatyFirstNation === "yes" ||
                form.treatyFirstNation === "nisga") && (
                <Field
                  field="treatyFirstNationName"
                  highlighted={jumpedField === "treatyFirstNationName"}
                  attentionError={jumpedFieldHasError}
                  label="First Nation name, if known"
                >
                  <Input
                    value={form.treatyFirstNationName}
                    onChange={event =>
                      set("treatyFirstNationName", event.target.value)
                    }
                  />
                </Field>
              )}
            </fieldset>
          </section>

          <PeopleSection
            id="client-intake-executors"
            title="Executors"
            description="Add each executor named in the will, if known."
            people={form.executors}
            type="executor"
            onAdd={() => addPerson("executors")}
            onRemove={index => removePerson("executors", index)}
            onUpdate={(index, key, value) =>
              updatePerson("executors", index, key, value)
            }
          />
          <PeopleSection
            id="client-intake-familyMembers"
            title="Family & other persons"
            description="Add people separately so the legal team can review each report. A category records the client’s reported relationship; it does not assign a legal role."
            people={form.familyMembers}
            type="family"
            onAdd={() => addPerson("familyMembers")}
            onRemove={index => removePerson("familyMembers", index)}
            onUpdate={(index, key, value) =>
              updatePerson("familyMembers", index, key, value)
            }
          />
          <EstateItemsSection
            items={form.estateItems}
            onAdd={addItem}
            onRemove={removeItem}
            onUpdate={updateItem}
          />

          <section
            id="client-intake-documentsAvailable"
            tabIndex={-1}
            className="space-y-4 border-t pt-6"
            aria-labelledby="documents-heading"
          >
            <SectionHeading
              id="documents-heading"
              title="Documents to gather"
              description="Please gather any documents you have. This portal checklist does not upload documents."
            />
            <div className="grid gap-3 sm:grid-cols-2">
              {documentOptions.map(document => {
                const id = `client-intake-document-${document.value}`;
                return (
                  <label
                    key={document.value}
                    htmlFor={id}
                    className="flex min-h-10 cursor-pointer items-center gap-3 rounded-md border border-border/70 px-3 py-2 text-sm hover:bg-muted/40"
                  >
                    <Checkbox
                      id={id}
                      checked={form.documentsAvailable.includes(document.value)}
                      onCheckedChange={checked =>
                        setDocumentAvailable(document.value, checked === true)
                      }
                    />
                    <span>{document.label}</span>
                  </label>
                );
              })}
            </div>
          </section>

          {(isCustomQuestionLoading || isCustomQuestionError || form.customQuestions.length > 0) && (
            <section
              className="space-y-4 border-t pt-6"
              aria-labelledby="custom-questions-heading"
            >
              <SectionHeading
                id="custom-questions-heading"
                title="Questions from your legal team"
                description="Please answer the case-specific questions below. Your answers are sent for lawyer review."
              />
              {isCustomQuestionLoading && (
                <p className="text-sm text-muted-foreground" role="status">
                  Loading case-specific questions…
                </p>
              )}
              {isCustomQuestionError && (
                <p className="rounded-md border border-destructive/25 bg-destructive/5 px-3 py-2 text-sm text-destructive" role="alert">
                  Case-specific questions could not be loaded. Refresh this page before sending your intake.
                </p>
              )}
              {!isCustomQuestionLoading && !isCustomQuestionError && form.customQuestions.map(question => {
                const inputId = `client-intake-custom-${question.id}`;
                const errorId = `${inputId}-error`;
                const helpId = `${inputId}-help`;
                const hasError = customQuestionErrorId === question.id;
                return (
                  <div key={question.id} className="space-y-2 rounded-lg border border-border/70 bg-muted/[0.18] p-4">
                    <Label htmlFor={inputId} className="text-sm font-medium leading-5">
                      {question.prompt}
                      {question.required && <span className="ml-1 text-destructive">(required)</span>}
                    </Label>
                    {question.helpText && <p id={helpId} className="text-xs leading-5 text-muted-foreground">{question.helpText}</p>}
                    <Textarea
                      id={inputId}
                      value={question.answer}
                      onChange={event => setCustomQuestionAnswer(question.id, event.target.value)}
                      aria-required={question.required || undefined}
                      aria-invalid={hasError || undefined}
                      aria-describedby={[question.helpText ? helpId : "", hasError ? errorId : ""].filter(Boolean).join(" ") || undefined}
                      rows={4}
                      maxLength={4000}
                      className={hasError ? "border-destructive focus-visible:ring-destructive" : ""}
                    />
                    {hasError && <p id={errorId} className="text-sm text-destructive" role="alert">A response is required before you can send this form.</p>}
                  </div>
                );
              })}
            </section>
          )}

          <div className="flex flex-col gap-3 border-t pt-5 sm:flex-row sm:items-center sm:justify-between">
            <p className="flex items-start gap-2 text-xs text-muted-foreground">
              <ShieldCheck
                className="mt-0.5 h-4 w-4 shrink-0 text-primary"
                aria-hidden="true"
              />
              Submission does not replace legal advice or create a court filing.
            </p>
            <Button
              onClick={submitForReview}
              disabled={
                submit.isPending || isCustomQuestionLoading || isCustomQuestionError || !form.clientName || !form.clientEmail
              }
              className={`sm:min-w-44 ${completionPercent === 100 && !submit.isPending ? "client-intake-submit-guidance" : ""}`}
            >
              {submit.isPending ? (
                <>
                  <Loader2
                    className="mr-2 h-4 w-4 animate-spin"
                    aria-hidden="true"
                  />
                  Sending…
                </>
              ) : (
                <>
                  <FileCheck2 className="mr-2 h-4 w-4" aria-hidden="true" />
                  {latest?.status === "revision_requested"
                    ? "Send revised details"
                    : "Send for review"}
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </JumpReturnContext.Provider>
  );
}

function SubmittedIntakeConfirmation({
  headingRef,
  isApproved,
  payload,
  status,
}: {
  headingRef: React.RefObject<HTMLHeadingElement | null>;
  isApproved: boolean;
  payload: ClientIntakePayload;
  status: string;
}) {
  const sections = buildClientIntakeSummarySections(payload);
  return (
    <Card className="border-emerald-500/25 bg-gradient-to-b from-emerald-500/[0.07] to-card shadow-sm">
      <CardContent className="space-y-6 p-6 sm:p-8">
        <div
          role="status"
          aria-live="polite"
          aria-label="Submission confirmation"
          className="flex flex-col items-start gap-5"
        >
          <div className="flex size-12 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
            <Check className="size-6" aria-hidden="true" />
          </div>
          <div className="max-w-xl space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <ClientIntakeStatusBadge status={status} />
              <span className="text-xs font-medium text-muted-foreground">
                Client intake
              </span>
            </div>
            <h2
              ref={headingRef}
              tabIndex={-1}
              className="scroll-mt-24 text-xl font-semibold tracking-tight outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-4"
            >
              {isApproved ? "Your intake has been reviewed" : "Your intake has been sent"}
            </h2>
            <p className="text-sm leading-6 text-muted-foreground">
              {isApproved
                ? "The legal team has completed its review of the selected details."
                : "The legal team will review your information before adding anything to the estate file."}
            </p>
          </div>
        </div>
        {!isApproved && (
          <div className="flex max-w-xl items-start gap-3 rounded-lg border border-border/70 bg-background/70 p-4 text-sm leading-6 text-muted-foreground">
            <MessageSquareText
              className="mt-0.5 size-4 shrink-0 text-primary"
              aria-hidden="true"
            />
            <p>
              If the legal team needs any changes, a request will appear on this
              page with guidance about what to update.
            </p>
          </div>
        )}
        <section
          aria-labelledby="submitted-answer-heading"
          className="rounded-xl border border-border/70 bg-background/70 p-4 sm:p-5"
        >
          <div className="space-y-1">
            <h3
              id="submitted-answer-heading"
              className="text-base font-semibold tracking-tight"
            >
              Your submitted answers
            </h3>
            <p className="text-sm leading-6 text-muted-foreground">
              This is the read-only record sent with this submission.
            </p>
          </div>
          <div className="mt-5 space-y-5">
            {sections.map(section => (
              <div key={section.title} className="space-y-3">
                <h4 className="text-sm font-semibold text-foreground">
                  {section.title}
                </h4>
                <dl className="grid gap-3 sm:grid-cols-2">
                  {section.rows.map(row => (
                    <div
                      key={`${section.title}-${row.label}`}
                      className="min-w-0 rounded-lg border border-border/60 bg-card/80 px-3 py-2.5"
                    >
                      <dt className="text-xs font-medium text-muted-foreground">
                        {row.label}
                      </dt>
                      <dd className="mt-1 whitespace-pre-wrap break-words text-sm leading-5 text-foreground">
                        {row.value}
                      </dd>
                    </div>
                  ))}
                </dl>
              </div>
            ))}
          </div>
        </section>
      </CardContent>
    </Card>
  );
}

function SectionHeading({
  id,
  title,
  description,
}: {
  id: string;
  title: string;
  description: string;
}) {
  return (
    <div>
      <h3 id={id} className="text-sm font-semibold">
        {title}
      </h3>
      <p className="text-xs text-muted-foreground">{description}</p>
    </div>
  );
}

function PeopleSection({
  id,
  title,
  description,
  people,
  type,
  onAdd,
  onRemove,
  onUpdate,
}: {
  id: string;
  title: string;
  description: string;
  people: ClientIntakePerson[];
  type: "executor" | "family";
  onAdd: () => void;
  onRemove: (index: number) => void;
  onUpdate: (
    index: number,
    key: keyof ClientIntakePerson,
    value: string
  ) => void;
}) {
  const singular = type === "executor" ? "executor" : "person";
  return (
    <section
      id={id}
      tabIndex={-1}
      className="space-y-4 border-t pt-6"
      aria-labelledby={`${id}-heading`}
    >
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <SectionHeading
          id={`${id}-heading`}
          title={title}
          description={description}
        />
        <Button type="button" variant="outline" onClick={onAdd}>
          Add {singular}
        </Button>
      </div>
      {people.length === 0 ? (
        <p className="rounded-md border border-dashed border-border px-3 py-3 text-sm text-muted-foreground">
          No {type === "executor" ? "executors" : "people"} added yet.
        </p>
      ) : (
        <div className="space-y-4">
          {people.map((person, index) => (
            <PersonCard
              key={`${type}-${index}`}
              person={person}
              index={index}
              type={type}
              onRemove={() => onRemove(index)}
              onUpdate={(key, value) => onUpdate(index, key, value)}
            />
          ))}
        </div>
      )}
    </section>
  );
}

function PersonCard({
  person,
  index,
  type,
  onRemove,
  onUpdate,
}: {
  person: ClientIntakePerson;
  index: number;
  type: "executor" | "family";
  onRemove: () => void;
  onUpdate: (key: keyof ClientIntakePerson, value: string) => void;
}) {
  const name =
    type === "executor" ? `Executor ${index + 1}` : `Person ${index + 1}`;
  return (
    <fieldset className="space-y-4 rounded-lg border border-border/70 p-4">
      <legend className="px-1 text-sm font-medium">{name}</legend>
      <div className="flex justify-end">
        <Button type="button" variant="ghost" size="sm" onClick={onRemove}>
          Remove {type === "executor" ? "executor" : "person"}
        </Button>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {type === "family" && (
          <NativeField
            id={`client-intake-family-${index}-category`}
            label="Category"
          >
            <select
              id={`client-intake-family-${index}-category`}
              aria-label={`Family member ${index + 1} category`}
              className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-xs outline-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50"
              value={person.category}
              onChange={event => onUpdate("category", event.target.value)}
            >
              {personCategories.map(category => (
                <option key={category.value} value={category.value}>
                  {category.label}
                </option>
              ))}
            </select>
          </NativeField>
        )}
        <NativeField
          id={`client-intake-${type}-${index}-name`}
          label="Full name"
        >
          <Input
            id={`client-intake-${type}-${index}-name`}
            value={person.name}
            onChange={event => onUpdate("name", event.target.value)}
            autoComplete="name"
          />
        </NativeField>
        <NativeField
          id={`client-intake-${type}-${index}-age`}
          label="Age, if known"
        >
          <Input
            id={`client-intake-${type}-${index}-age`}
            value={person.age}
            onChange={event => onUpdate("age", event.target.value)}
            inputMode="numeric"
            maxLength={3}
          />
        </NativeField>
        <NativeField id={`client-intake-${type}-${index}-email`} label="Email">
          <Input
            id={`client-intake-${type}-${index}-email`}
            type="email"
            value={person.email}
            onChange={event => onUpdate("email", event.target.value)}
            autoComplete="email"
          />
        </NativeField>
        <NativeField id={`client-intake-${type}-${index}-phone`} label="Phone">
          <Input
            id={`client-intake-${type}-${index}-phone`}
            value={person.phone}
            onChange={event => onUpdate("phone", event.target.value)}
            autoComplete="tel"
          />
        </NativeField>
        {!!person.address && ![
          person.addressStreet,
          person.addressUnit,
          person.addressCity,
          person.addressProvince,
          person.addressPostalCode,
          person.addressCountry,
        ].some(Boolean) && (
          <NativeField
            id={`client-intake-${type}-${index}-address`}
            label="Residential address (from an earlier report)"
          >
            <Input
              id={`client-intake-${type}-${index}-address`}
              value={person.address}
              onChange={event => onUpdate("address", event.target.value)}
              autoComplete="street-address"
            />
          </NativeField>
        )}
        <NativeField
          id={`client-intake-${type}-${index}-address-street`}
          label="Residential street address"
        >
          <Input
            id={`client-intake-${type}-${index}-address-street`}
            value={person.addressStreet}
            onChange={event => onUpdate("addressStreet", event.target.value)}
            autoComplete="address-line1"
          />
        </NativeField>
        <NativeField
          id={`client-intake-${type}-${index}-address-unit`}
          label="Unit or suite, if any"
        >
          <Input
            id={`client-intake-${type}-${index}-address-unit`}
            value={person.addressUnit}
            onChange={event => onUpdate("addressUnit", event.target.value)}
            autoComplete="address-line2"
          />
        </NativeField>
        <NativeField
          id={`client-intake-${type}-${index}-address-city`}
          label="City or town"
        >
          <Input
            id={`client-intake-${type}-${index}-address-city`}
            value={person.addressCity}
            onChange={event => onUpdate("addressCity", event.target.value)}
            autoComplete="address-level2"
          />
        </NativeField>
        <NativeField
          id={`client-intake-${type}-${index}-address-province`}
          label="Province or state"
        >
          <Input
            id={`client-intake-${type}-${index}-address-province`}
            value={person.addressProvince}
            onChange={event => onUpdate("addressProvince", event.target.value)}
            autoComplete="address-level1"
          />
        </NativeField>
        <NativeField
          id={`client-intake-${type}-${index}-address-postal-code`}
          label="Postal or ZIP code"
        >
          <Input
            id={`client-intake-${type}-${index}-address-postal-code`}
            value={person.addressPostalCode}
            onChange={event => onUpdate("addressPostalCode", event.target.value)}
            autoComplete="postal-code"
          />
        </NativeField>
        <NativeField
          id={`client-intake-${type}-${index}-address-country`}
          label="Country"
        >
          <Input
            id={`client-intake-${type}-${index}-address-country`}
            value={person.addressCountry}
            onChange={event => onUpdate("addressCountry", event.target.value)}
            autoComplete="country-name"
          />
        </NativeField>
        <NativeField
          id={`client-intake-${type}-${index}-relationship`}
          label="Relationship to the deceased, if known"
        >
          <Input
            id={`client-intake-${type}-${index}-relationship`}
            value={person.relationship}
            onChange={event => onUpdate("relationship", event.target.value)}
            placeholder={type === "family" ? "e.g., child" : "e.g., sibling"}
          />
        </NativeField>
        {type === "executor" && (
          <NativeField
            id={`client-intake-executor-${index}-status`}
            label="Executor status, if known"
          >
            <select
              id={`client-intake-executor-${index}-status`}
              className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-xs outline-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50"
              value={person.executorStatus}
              onChange={event => onUpdate("executorStatus", event.target.value)}
            >
              <option value="">Not known — leave for the legal team</option>
              <option value="applying">Plans to apply for the grant</option>
              <option value="reserved">Will not join this application (right reserved)</option>
              <option value="renounced">Has renounced</option>
              <option value="unable">Unable to act</option>
              <option value="deceased">Has died</option>
            </select>
            <p className="text-xs leading-5 text-muted-foreground">
              Report only what you know. The legal team reviews this before it is used in the estate file.
            </p>
          </NativeField>
        )}
        <NativeField
          id={`client-intake-${type}-${index}-occupation`}
          label="Occupation, if known"
        >
          <Input
            id={`client-intake-${type}-${index}-occupation`}
            value={person.occupation}
            onChange={event => onUpdate("occupation", event.target.value)}
          />
        </NativeField>
      </div>
    </fieldset>
  );
}

function EstateItemsSection({
  items,
  onAdd,
  onRemove,
  onUpdate,
}: {
  items: ClientIntakeItem[];
  onAdd: (category: ItemCategory) => void;
  onRemove: (index: number) => void;
  onUpdate: (index: number, key: keyof ClientIntakeItem, value: string) => void;
}) {
  const addButtons: Array<{ category: ItemCategory; label: string }> = [
    { category: "real_property", label: "Add real property" },
    { category: "vehicle", label: "Add vehicle" },
    { category: "financial", label: "Add financial account or investment" },
    { category: "tangible", label: "Add other asset" },
    { category: "liability", label: "Add estate debt" },
  ];
  return (
    <section
      id="client-intake-estateItems"
      tabIndex={-1}
      className="space-y-4 border-t pt-6"
      aria-labelledby="estate-items-heading"
    >
      <SectionHeading
        id="estate-items-heading"
        title="Estate assets and debts"
        description="Add each item separately. Approximate value is optional; leave it blank if unknown rather than entering zero."
      />
      <div className="flex flex-wrap gap-2">
        {addButtons.map(button => (
          <Button
            key={button.category}
            type="button"
            variant="outline"
            onClick={() => onAdd(button.category)}
          >
            {button.label}
          </Button>
        ))}
      </div>
      {items.length === 0 ? (
        <p className="rounded-md border border-dashed border-border px-3 py-3 text-sm text-muted-foreground">
          No estate assets or debts added yet.
        </p>
      ) : (
        <div className="space-y-4">
          {items.map((item, index) => (
            <EstateItemCard
              key={`${item.category}-${index}`}
              item={item}
              index={index}
              onRemove={() => onRemove(index)}
              onUpdate={(key, value) => onUpdate(index, key, value)}
            />
          ))}
        </div>
      )}
    </section>
  );
}

function EstateItemCard({
  item,
  index,
  onRemove,
  onUpdate,
}: {
  item: ClientIntakeItem;
  index: number;
  onRemove: () => void;
  onUpdate: (key: keyof ClientIntakeItem, value: string) => void;
}) {
  const title =
    item.category === "real_property"
      ? "Real property"
      : item.category === "vehicle"
        ? "Vehicle"
        : item.category === "financial"
          ? "Financial account or investment"
          : item.category === "liability"
            ? "Estate debt"
            : "Other asset";
  const prefix = `client-intake-item-${index}`;
  return (
    <fieldset className="space-y-4 rounded-lg border border-border/70 p-4">
      <legend className="px-1 text-sm font-medium">
        {title} {index + 1}
      </legend>
      <div className="flex justify-end">
        <Button type="button" variant="ghost" size="sm" onClick={onRemove}>
          Remove {title.toLowerCase()}
        </Button>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <NativeField
          id={`${prefix}-description`}
          label={
            item.category === "vehicle"
              ? "Vehicle details (year, make, model, VIN)"
              : item.category === "liability"
                ? "Creditor and debt details"
                : "Description"
          }
        >
          <Textarea
            id={`${prefix}-description`}
            value={item.description}
            onChange={event => onUpdate("description", event.target.value)}
            rows={2}
            maxLength={700}
          />
        </NativeField>
        <NativeField
          id={`${prefix}-value`}
          label="Approximate value at date of death (optional)"
        >
          <Input
            id={`${prefix}-value`}
            value={item.value}
            onChange={event => onUpdate("value", event.target.value)}
            inputMode="decimal"
            placeholder="Leave blank if unknown"
          />
        </NativeField>
        <NativeField id={`${prefix}-location`} label="Location">
          <select
            id={`${prefix}-location`}
            className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-xs outline-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50"
            value={item.location}
            onChange={event => onUpdate("location", event.target.value)}
          >
            <option value="unknown">Unknown</option>
            <option value="in_bc">In British Columbia</option>
            <option value="outside_bc">Outside British Columbia</option>
          </select>
        </NativeField>
      </div>
      {item.category === "financial" && (
        <div className="grid gap-4 border-t pt-4 md:grid-cols-3">
          <NativeField
            id={`${prefix}-bank-address`}
            label="Bank or institution branch address"
          >
            <Input
              id={`${prefix}-bank-address`}
              value={item.bankAddress}
              onChange={event => onUpdate("bankAddress", event.target.value)}
              autoComplete="street-address"
            />
          </NativeField>
          <NativeField id={`${prefix}-account-number`} label="Account number">
            <Input
              id={`${prefix}-account-number`}
              value={item.accountNumber}
              onChange={event => onUpdate("accountNumber", event.target.value)}
            />
          </NativeField>
          <NativeField id={`${prefix}-account-holder`} label="Account holder">
            <Input
              id={`${prefix}-account-holder`}
              value={item.accountHolder}
              onChange={event => onUpdate("accountHolder", event.target.value)}
            />
          </NativeField>
        </div>
      )}
      {item.category === "real_property" && (
        <div className="grid gap-4 border-t pt-4 md:grid-cols-2">
          <NativeField id={`${prefix}-pid`} label="PID, if known">
            <Input
              id={`${prefix}-pid`}
              value={item.pid}
              onChange={event => onUpdate("pid", event.target.value)}
            />
          </NativeField>
          <NativeField
            id={`${prefix}-registered-owner`}
            label="Registered owner"
          >
            <Input
              id={`${prefix}-registered-owner`}
              value={item.registeredOwner}
              onChange={event =>
                onUpdate("registeredOwner", event.target.value)
              }
            />
          </NativeField>
          <NativeField
            id={`${prefix}-legal-description`}
            label="Legal description, if known"
          >
            <Textarea
              id={`${prefix}-legal-description`}
              value={item.legalDescription}
              onChange={event =>
                onUpdate("legalDescription", event.target.value)
              }
              rows={2}
              maxLength={1000}
            />
          </NativeField>
          <NativeField
            id={`${prefix}-ownership-details`}
            label="Ownership details, if known"
          >
            <Textarea
              id={`${prefix}-ownership-details`}
              value={item.ownershipDetails}
              onChange={event =>
                onUpdate("ownershipDetails", event.target.value)
              }
              rows={2}
              maxLength={1000}
            />
          </NativeField>
        </div>
      )}
    </fieldset>
  );
}

function NativeField({
  id,
  label,
  children,
}: {
  id: string;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id} className="text-xs">
        {label}
      </Label>
      {children}
    </div>
  );
}

function Field({
  field,
  highlighted = false,
  attentionError = false,
  label,
  children,
}: {
  field: ClientIntakeRevisionField;
  highlighted?: boolean;
  attentionError?: boolean;
  label: string;
  children: React.ReactNode;
}) {
  const jumpReturn = React.useContext(JumpReturnContext);
  const fallbackId = useId();
  const id = field ? `client-intake-${field}` : fallbackId;
  const errorId = `${id}-validation-error`;
  const errorMessage =
    highlighted && attentionError && jumpReturn.errorField === field
      ? jumpReturn.errorMessage
      : null;
  const control = React.isValidElement(children)
    ? React.cloneElement(
        children as React.ReactElement<{
          id?: string;
          "aria-invalid"?: boolean;
          "aria-describedby"?: string;
          onChange?: (
            event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
          ) => void;
        }>,
        {
          id,
          "aria-invalid": attentionError || undefined,
          "aria-describedby": errorMessage ? errorId : undefined,
          onChange: (
            event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
          ) => {
            (
              children.props as {
                onChange?: (
                  changeEvent: React.ChangeEvent<
                    HTMLInputElement | HTMLTextAreaElement
                  >
                ) => void;
              }
            ).onChange?.(event);
            jumpReturn.onFieldEdit(field, event.currentTarget);
          },
        }
      )
    : children;
  return (
    <div
      className={`scroll-mt-24 space-y-1.5 rounded-md transition-shadow ${attentionClasses(highlighted, attentionError)} ${jumpReturn.recoveredField === field ? "client-intake-field-recovered ring-2 ring-emerald-500/60 ring-offset-2" : ""}`}
    >
      <Label htmlFor={id} className="text-xs">
        {label}
      </Label>
      {control}
      {errorMessage && <ValidationHint id={errorId} message={errorMessage} />}
      {jumpReturn.recoveredField === field && (
        <span className="sr-only" aria-live="polite">
          Field corrected
        </span>
      )}
      {jumpReturn.autoSavedField === field && (
        <span
          role="status"
          className="client-intake-auto-saved inline-flex w-fit items-center gap-1 text-xs font-medium text-emerald-700 dark:text-emerald-300"
        >
          <FileCheck2 className="h-3.5 w-3.5" aria-hidden="true" />
          Update noted
        </span>
      )}
      <JumpBackControl field={field} />
    </div>
  );
}

function addressGuidance(value: string) {
  const address = value.trim();
  if (!address)
    return "Start typing to see address suggestions, or enter a complete address manually.";
  if (!/\d/.test(address) || !address.includes(","))
    return "For a more accurate record, include the street number and city or town if known. You can still submit a partial or international address for review.";
  return null;
}

function ClientAddressField({
  value,
  onChange,
  onSelect,
  highlighted,
  attentionError,
}: {
  value: string;
  onChange: (value: string) => void;
  onSelect: (components: AddressComponents) => void;
  highlighted: boolean;
  attentionError: boolean;
}) {
  const field: ClientIntakeRevisionField = "deceasedAddress";
  const jumpReturn = React.useContext(JumpReturnContext);
  const id = `client-intake-${field}`;
  const errorId = `${id}-validation-error`;
  const helpId = `${id}-address-guidance`;
  const errorMessage =
    highlighted && attentionError && jumpReturn.errorField === field
      ? jumpReturn.errorMessage
      : null;
  const guidance = addressGuidance(value);
  const [copyState, setCopyState] = useState<"idle" | "copied" | "failed">(
    "idle"
  );
  const copyFormattedAddress = async () => {
    try {
      if (!navigator.clipboard?.writeText)
        throw new Error("Clipboard unavailable");
      await navigator.clipboard.writeText(value);
      setCopyState("copied");
    } catch {
      setCopyState("failed");
    }
    window.setTimeout(() => setCopyState("idle"), 2200);
  };
  return (
    <div
      className={`scroll-mt-24 space-y-1.5 rounded-md transition-shadow ${attentionClasses(highlighted, attentionError)} ${jumpReturn.recoveredField === field ? "client-intake-field-recovered ring-2 ring-emerald-500/60 ring-offset-2" : ""}`}
    >
      <Label htmlFor={id} className="text-xs">
        Last home address
      </Label>
      <AddressAutocomplete
        value={value}
        onChange={onChange}
        onSelect={onSelect}
        onInputEdit={(_value, target) => jumpReturn.onFieldEdit(field, target)}
        inputId={id}
        ariaInvalid={attentionError}
        ariaDescribedBy={errorMessage ? errorId : guidance ? helpId : undefined}
        placeholder="Start typing an address…"
      />
      {errorMessage ? (
        <ValidationHint id={errorId} message={errorMessage} />
      ) : guidance ? (
        <p id={helpId} role="status" className="text-xs text-muted-foreground">
          {guidance}
        </p>
      ) : (
        <div className="flex flex-wrap items-center gap-2">
          <span
            role="status"
            className="text-xs text-emerald-700 dark:text-emerald-300"
          >
            Formatted address ready
          </span>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="h-7 gap-1.5 px-2 text-xs"
            onClick={() => {
              void copyFormattedAddress();
            }}
            aria-label="Copy formatted address"
          >
            {copyState === "copied" ? (
              <Check className="h-3.5 w-3.5" aria-hidden="true" />
            ) : (
              <Copy className="h-3.5 w-3.5" aria-hidden="true" />
            )}
            {copyState === "copied" ? "Copied" : "Copy address"}
          </Button>
          {copyState === "failed" && (
            <span role="status" className="text-xs text-destructive">
              Copy unavailable. Select the address and copy it manually.
            </span>
          )}
        </div>
      )}
      {jumpReturn.recoveredField === field && (
        <span className="sr-only" aria-live="polite">
          Field corrected
        </span>
      )}
      {jumpReturn.autoSavedField === field && (
        <span
          role="status"
          className="client-intake-auto-saved inline-flex w-fit items-center gap-1 text-xs font-medium text-emerald-700 dark:text-emerald-300"
        >
          <FileCheck2 className="h-3.5 w-3.5" aria-hidden="true" />
          Update noted
        </span>
      )}
      <JumpBackControl field={field} />
    </div>
  );
}

function ValidationHint({ id, message }: { id: string; message: string }) {
  return (
    <p
      id={id}
      role="alert"
      className="client-intake-validation-message text-xs font-medium text-red-700 dark:text-red-300"
    >
      {message}
    </p>
  );
}

function IntakeCompletionProgress({
  completionPercent,
}: {
  completionPercent: number;
}) {
  const isComplete = completionPercent === 100;
  return (
    <div
      className={`space-y-1.5 ${isComplete ? "client-intake-completion-celebration" : ""}`}
      aria-label="Intake completion"
    >
      <div className="flex items-center justify-between gap-3 text-xs">
        <span
          className={`font-medium ${isComplete ? "text-emerald-700 dark:text-emerald-300" : "text-muted-foreground"}`}
        >
          {isComplete ? "Intake complete" : "Form completion"}
        </span>
        <span
          className={`font-semibold ${isComplete ? "text-emerald-700 dark:text-emerald-300" : "text-foreground"}`}
        >
          {completionPercent}%
        </span>
      </div>
      <div
        className="h-1.5 overflow-hidden rounded-full bg-muted"
        role="progressbar"
        aria-label="Intake completion progress"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={completionPercent}
      >
        <div
          className={`h-full rounded-full transition-[width,background-color,box-shadow] duration-300 ease-out ${isComplete ? "bg-emerald-500" : "bg-primary"}`}
          style={{ width: `${completionPercent}%` }}
        />
      </div>
      {isComplete && (
        <span role="status" className="sr-only">
          Intake complete
        </span>
      )}
    </div>
  );
}

function ValidationSummaryBadge({
  remainingValidationErrors,
  onJumpToNext,
}: {
  remainingValidationErrors: number;
  onJumpToNext: () => void;
}) {
  const hasErrors = remainingValidationErrors > 0;
  return (
    <div className="sticky top-3 z-10 flex justify-end pointer-events-none">
      <button
        type="button"
        onClick={onJumpToNext}
        disabled={!hasErrors}
        aria-label={
          hasErrors
            ? `${remainingValidationErrors} validation ${remainingValidationErrors === 1 ? "error" : "errors"} remaining. Jump to next error`
            : "No validation errors remaining"
        }
        className={`pointer-events-auto inline-flex max-w-full items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-semibold shadow-sm backdrop-blur transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${hasErrors ? "cursor-pointer border-red-500/25 bg-red-500/10 text-red-800 hover:bg-red-500/15 dark:text-red-200" : "cursor-default border-emerald-500/25 bg-emerald-500/10 text-emerald-800 dark:text-emerald-200"}`}
      >
        {hasErrors
          ? `${remainingValidationErrors} validation ${remainingValidationErrors === 1 ? "error" : "errors"} remaining`
          : "No validation errors remaining"}
      </button>
    </div>
  );
}

function JumpBackControl({ field }: { field: ClientIntakeRevisionField }) {
  const jumpReturn = React.useContext(JumpReturnContext);
  if (jumpReturn.activeField !== field || !jumpReturn.onReturn) return null;
  return (
    <Button
      type="button"
      size="sm"
      variant="outline"
      onClick={jumpReturn.onReturn}
      className="mt-2 h-8 w-fit border-amber-500/30 bg-amber-500/5 px-2.5 text-xs text-amber-900 shadow-sm transition-colors hover:bg-amber-500/10 dark:text-amber-200"
    >
      Back to requested revisions
    </Button>
  );
}

function Choice({
  value,
  label,
  selected,
}: {
  value: string;
  label: string;
  selected: string;
}) {
  return (
    <label
      className={`flex min-h-10 cursor-pointer items-center gap-2 rounded-lg border px-3 py-2.5 text-sm transition-colors ${selected === value ? "border-primary bg-primary/5" : "hover:bg-muted/50"}`}
    >
      <RadioGroupItem value={value} />
      {label}
    </label>
  );
}
