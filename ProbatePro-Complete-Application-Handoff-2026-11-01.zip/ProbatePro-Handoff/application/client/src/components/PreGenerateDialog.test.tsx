import React from "react";
import { afterEach, describe, it, expect, vi } from "vitest";
import { act, render, screen, fireEvent, cleanup, waitFor } from "@testing-library/react";
import { PreGenerateDialog } from "./PreGenerateDialog";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "./ui/dialog";
import type { FormGapReport } from "@shared/formRequirements";

function makeReport(gaps: FormGapReport["gaps"] = []): FormGapReport {
  return { formCode: "P1", ok: gaps.length === 0, gaps };
}

afterEach(() => {
  cleanup();
  vi.useRealTimers();
  vi.unstubAllGlobals();
});

describe("<PreGenerateDialog />", () => {
  it("stacks its overlay and content above a source dialog during animated handoff", () => {
    render(
      <>
        <Dialog open={true} onOpenChange={() => {}}>
          <DialogContent data-testid="source-dialog">
            <DialogTitle>Form details</DialogTitle>
            <DialogDescription>Review form details before generation.</DialogDescription>
          </DialogContent>
        </Dialog>
        <PreGenerateDialog
          open={true}
          onOpenChange={() => {}}
          formName="P1 Notice"
          reports={[makeReport([])]}
          onProceed={() => {}}
          onJumpToTab={() => {}}
          onCancel={() => {}}
        />
      </>,
    );

    const content = screen.getByTestId("pre-generate-dialog");
    const source = screen.getByTestId("source-dialog");
    const overlays = Array.from(document.querySelectorAll('[data-slot="dialog-overlay"]'));
    const overlay = overlays.find((candidate) => candidate.className.includes("z-[60]"));
    expect(source.className).toContain("z-50");
    expect(content.className).toContain("z-[60]");
    expect(overlay?.className).toContain("z-[60]");
    expect(overlays).toHaveLength(2);
  });

  // Regression: a position utility in this dialog's className is merged by
  // tailwind-merge against the base DialogContent "fixed" and silently REMOVES
  // it. The panel then lays out in normal flow below the page while the overlay
  // still covers the viewport — the reported "screen just dims, no dialog".
  it("keeps position:fixed on its content so the panel is not laid out below the page", () => {
    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="P1 Notice"
        reports={[makeReport([])]}
        onProceed={() => {}}
        onJumpToTab={() => {}}
        onCancel={() => {}}
      />,
    );
    const classes = screen.getByTestId("pre-generate-dialog").className.split(/\s+/);
    expect(classes).toContain("fixed");
    expect(classes).not.toContain("relative");
    expect(classes).not.toContain("absolute");
    expect(classes).not.toContain("static");
    expect(classes).not.toContain("sticky");
  });

  it("renders the 'ready' state when all reports are ok", () => {
    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="P1 Notice"
        reports={[makeReport([])]}
        onProceed={() => {}}
        onJumpToTab={() => {}}
        onCancel={() => {}}
      />,
    );
    expect(screen.getByText(/Ready to generate P1 Notice/i)).toBeTruthy();
    expect(screen.getByTestId("pre-generate-proceed").textContent).toMatch(/^Generate$/);
  });

  it("renders each gap with its source and a Go-to-tab button", () => {
    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="P1 Notice"
        reports={[
          makeReport([
            {
              requirementId: "p1_deceased_last_name",
              label: "Deceased's last name",
              missingFields: ["estate.deceasedLastName"],
              tab: "intake",
              source: "SCCR Rule 25-2(3)(b)(i)",
            },
          ]),
        ]}
        onProceed={() => {}}
        onJumpToTab={() => {}}
        onCancel={() => {}}
      />,
    );
    expect(screen.getByText("Deceased's last name")).toBeTruthy();
    expect(screen.getByText(/SCCR Rule 25-2\(3\)\(b\)\(i\)/)).toBeTruthy();
    expect(screen.getByTestId("pre-generate-jump-p1_deceased_last_name")).toBeTruthy();
  });

  it("calls onJumpToTab with the gap's tab when the jump button is clicked", () => {
    const onJumpToTab = vi.fn();
    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="P2"
        reports={[
          { formCode: "P2", ok: false, gaps: [
            {
              requirementId: "p2_x",
              label: "X",
              missingFields: [],
              tab: "contacts",
              source: "SCCR Rule 25-2(2)(a)",
            },
          ] },
        ]}
        onProceed={() => {}}
        onJumpToTab={onJumpToTab}
        onCancel={() => {}}
      />,
    );
    fireEvent.click(screen.getByTestId("pre-generate-jump-p2_x"));
    expect(onJumpToTab).toHaveBeenCalledWith("contacts");
  });

  it("disables the Proceed button while proceeding=true", () => {
    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="P1"
        reports={[makeReport([])]}
        onProceed={() => {}}
        onJumpToTab={() => {}}
        onCancel={() => {}}
        proceeding={true}
      />,
    );
    const btn = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
    expect(btn.disabled).toBe(true);
  });

  it("sends a non-content applicability hard row through explicit draft intent", () => {
    const onProceed = vi.fn();
    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="P11"
        reports={[{
          formCode: "P11",
          ok: false,
          hardBlocked: true,
          notApplicable: true,
          gaps: [{
            requirementId: "p11_applicability",
            label: "P11 does not apply",
            missingFields: [],
            tab: "forms",
            source: "SCCR Rule 25-3(8)",
            blocker: "hard",
          }],
        }]}
        onProceed={onProceed}
        onJumpToTab={() => {}}
        onCancel={() => {}}
      />,
    );
    const button = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
    expect(button.disabled).toBe(false);
    expect(button.textContent).toBe("Generate");
    fireEvent.click(button);
    expect(onProceed).toHaveBeenCalledWith({ generateAnyway: true });
    expect(screen.queryByText("P11 is not applicable")).toBeNull();
  });

  it("hides a P2 source-document workflow block from the content-only popup", () => {
    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="P2 Submission for Estate Grant"
        reports={[{
          formCode: "P2",
          ok: false,
          hardBlocked: true,
          gaps: [{
            requirementId: "p2_ancillary_filing_attachments",
            label: "Upload the certified foreign grant.",
            missingFields: [],
            tab: "intake",
            source: "SCCR Rule 25-3(3)",
            blocker: "hard",
          }],
        }]}
        onProceed={() => {}}
        onJumpToTab={() => {}}
        onCancel={() => {}}
      />,
    );

    expect(screen.queryByTestId("pre-generate-gap-p2_ancillary_filing_attachments")).toBeNull();
    const proceed = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
    expect(proceed.disabled).toBe(false);
    expect(proceed.textContent).toBe("Generate");
  });

  it("uses action-specific preview copy and shows the actual missing accessors", () => {
    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="P17"
        action="preview"
        reports={[makeReport([{
          requirementId: "p17_reason",
          label: "Renunciation reason",
          missingFields: ["targetContact.renunciationReason"],
          tab: "contacts",
          source: "Form P17 template",
        }])]}
        onProceed={() => {}}
        onJumpToTab={() => {}}
        onCancel={() => {}}
      />,
    );
    expect(screen.getByTestId("pre-generate-proceed").textContent).toBe("Preview anyway");
    expect(screen.getByText(/targetContact\.renunciationReason/)).toBeTruthy();
  });

  // Layout regression: a long gap must not clip the "Go to <tab>" button or force a
  // horizontal scrollbar. jsdom can't measure pixels, so assert the non-clipping contract
  // structurally — the text column shrinks (min-w-0) and the button holds its full label
  // (shrink-0 + whitespace-nowrap). Guards against re-dropping min-w-0 from the flex row.
  it("keeps the full 'Go to Documents' label on a long gap without clipping the button", () => {
    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="P2 Submission for Estate Grant"
        reports={[
          makeReport([
            {
              requirementId: "p2_documents_gap",
              label: "Supporting documents for the estate grant submission",
              missingFields: [
                "documents.willOriginal",
                "documents.deathCertificate",
                "documents.affidavitOfAssetsAndLiabilities",
              ],
              tab: "documents",
              source: "SCCR Rule 25-3(2)",
            },
          ]),
        ]}
        onProceed={() => {}}
        onJumpToTab={() => {}}
        onCancel={() => {}}
      />,
    );
    const button = screen.getByTestId("pre-generate-jump-p2_documents_gap");
    expect(button.textContent).toContain("Go to Documents");
    expect(button.className).toContain("shrink-0");
    expect(button.className).toContain("whitespace-nowrap");
    // The text column must be allowed to shrink so the row never overflows the dialog width.
    expect((button.previousElementSibling as HTMLElement).className).toContain("min-w-0");
  });
});

describe("hard-gap badge (UI-004)", () => {
  it("hides P8 historic-affidavit mechanics from the content-only popup", () => {
    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="P8"
        reports={[{
          formCode: "P8",
          ok: false,
          gaps: [
            {
              requirementId: "p8_primary_affidavit_ambiguous",
              label: "Primary applicant affidavit is ambiguous",
              missingFields: [],
              tab: "forms",
              source: "SCCR Rule 25-3 (2) (c)",
              blocker: "hard",
            },
            {
              requirementId: "p8_primary_affidavit_history",
              label: "Primary applicant affidavit history",
              missingFields: [],
              tab: "forms",
              source: "SCCR Rule 25-3 (2) (c)",
              blocker: "soft",
            },
          ],
        }]}
        onProceed={() => {}}
        onJumpToTab={() => {}}
        onCancel={() => {}}
      />,
    );
    expect(screen.queryByTestId("pre-generate-hard-p8_primary_affidavit_ambiguous")).toBeNull();
    expect(screen.queryByTestId("pre-generate-hard-p8_primary_affidavit_history")).toBeNull();
    expect((screen.getByTestId("pre-generate-proceed") as HTMLButtonElement).disabled).toBe(false);
  });
});

describe("gap-dialog copy (audit C-10)", () => {
  it("does not promise '[not provided]' rendering — warns about blanks/defaults and review before swearing", () => {
    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="P9 Affidavit"
        reports={[
          makeReport([
            { requirementId: "p9_at_least_one_delivery", label: "At least one delivery record", missingFields: [], tab: "forms", source: "SCCR Rule 25-2(1.1)" },
          ]),
        ]}
        onProceed={() => {}}
        onJumpToTab={() => {}}
        onCancel={() => {}}
      />,
    );
    expect(screen.queryByText(/\[not provided\]/)).toBeNull();
    expect(screen.getByText(/render as blank lines or defaults/i)).toBeTruthy();
    expect(screen.getByText(/before swearing or filing/i)).toBeTruthy();
  });
});

/**
 * Inline-fill tests (Rule 22 addendum). The dialog's copy has promised "you
 * can fill them now" since PROMPT 40; these pin the machinery that makes that
 * true — and the boundaries that keep it safe. Radix Select's dropdown needs
 * pointer-capture APIs jsdom lacks, so select interaction is not driven here;
 * option sets are pinned in shared/inlineFieldControls.test.ts and the server
 * enum guard in shared/formOverrides.test.ts drops out-of-set tokens anyway.
 */
function renderInline(reports: FormGapReport[], props: Record<string, unknown> = {}) {
  const handlers = {
    onOpenChange: vi.fn(),
    onProceed: vi.fn(),
    onJumpToTab: vi.fn(),
    onCancel: vi.fn(),
    onApplyInline: vi.fn(),
  };
  render(
    <PreGenerateDialog
      open
      formName="P1 — Notice"
      reports={reports}
      estate={{ deceasedFirstName: "", deceasedLastName: "North", addressStreet: "", deceasedPostOfficeBox: "", oathType: "", registry: "" }}
      inlineEditingEnabled
      {...handlers}
      {...props}
    />,
  );
  return handlers;
}

function gapReport(formCode: string, gaps: FormGapReport["gaps"], extra: Partial<FormGapReport> = {}): FormGapReport {
  return { formCode, ok: gaps.length === 0, gaps, ...extra } as FormGapReport;
}

describe("inline editors for registered blank estate columns", () => {
  it("renders typed editors seeded from the estate and sends ONLY typed values on Apply & re-check", () => {
    const handlers = renderInline([gapReport("P1", [{
      requirementId: "p1_deceased_name",
      label: "Deceased's full name",
      missingFields: ["estate.deceasedFirstName", "estate.deceasedLastName"],
      tab: "intake",
      source: "SCCR Rule 25-2(3)(a)",
    }])]);

    const first = screen.getByTestId("pre-generate-input-deceasedFirstName") as HTMLInputElement;
    const last = screen.getByTestId("pre-generate-input-deceasedLastName") as HTMLInputElement;
    expect(first.value).toBe("");
    expect(last.value).toBe("North"); // seeded from the estate row

    fireEvent.change(first, { target: { value: "Jane" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    // Only the CHANGED column rides — the seeded, untouched surname does not.
    // Third arg (Rule 24): the checked doc-receipt keys — none here.
    expect(handlers.onApplyInline).toHaveBeenCalledWith({ deceasedFirstName: "Jane" }, true, []);
  });

  // Nick 2026-09-02 (third estate-#18 live audit): an inline answer chosen right
  // before "Generate anyway" used to be discarded — the draft lived only in the
  // dialog and only Apply read it. Proceeding now applies unsaved changes first.
  it("Generate anyway applies unsaved inline values first, then proceeds", async () => {
    const handlers = renderInline([gapReport("P2", [{
      requirementId: "p2_treaty_first_nation_answer",
      label: "Nisga'a / treaty first nation answer",
      missingFields: ["estate.deceasedFirstName"],
      tab: "intake",
      source: "Form P2 Part 1",
    }])]);
    fireEvent.change(screen.getByTestId("pre-generate-input-deceasedFirstName"), { target: { value: "Jane" } });
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(handlers.onProceed).toHaveBeenCalledTimes(1));
    expect(handlers.onApplyInline).toHaveBeenCalledWith({ deceasedFirstName: "Jane" }, true, []);
    // The apply ran BEFORE the proceed — the typed value reaches the record first.
    expect(handlers.onApplyInline.mock.invocationCallOrder[0]).toBeLessThan(handlers.onProceed.mock.invocationCallOrder[0]);
  });

  it("Generate anyway stays put when the inline save fails (typed values are never silently dropped)", async () => {
    const failingApply = vi.fn().mockResolvedValue(false);
    const handlers = renderInline([gapReport("P2", [{
      requirementId: "p2_treaty_first_nation_answer",
      label: "Nisga'a / treaty first nation answer",
      missingFields: ["estate.deceasedFirstName"],
      tab: "intake",
      source: "Form P2 Part 1",
    }])], { onApplyInline: failingApply });
    fireEvent.change(screen.getByTestId("pre-generate-input-deceasedFirstName"), { target: { value: "Jane" } });
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(failingApply).toHaveBeenCalledTimes(1));
    await new Promise((resolve) => setTimeout(resolve, 20));
    expect(handlers.onProceed).not.toHaveBeenCalled();
    expect((screen.getByTestId("pre-generate-input-deceasedFirstName") as HTMLInputElement).value).toBe("Jane");
  });

  // Loop-3 review C1: a row whose missingFields are ALL equality assertions
  // (the P11 sworn-fact rows) must fall back to its GAP_EDIT_HINTS column —
  // otherwise the dialog can only "jump to tab" and the fact is never collected.
  it("renders the hinted inline editor for an equality-assertion row (P11 sworn facts)", () => {
    renderInline([gapReport("P11", [
      { requirementId: "p11_not_domiciled_in_bc", label: "Record whether the deceased was domiciled in British Columbia at death", missingFields: ["estate.deceasedDomiciledInBC=yes", "estate.deceasedDomiciledInBC=no"], tab: "forms", source: "SCCR Rule 25-3(8)(a)" },
      { requirementId: "p11_foreign_administration", label: "Disposition of all property outside British Columbia, if any", missingFields: ["estate.foreignAdministrationConfirmed=yes", "estate.foreignAdministrationConfirmed=foreign_pr", "estate.foreignAdministrationConfirmed=foreign_law", "estate.foreignAdministrationConfirmed=none_outside"], tab: "forms", source: "SCCR Rule 25-3(8)(b)" },
      { requirementId: "p11_diligent_search", label: "Diligent search and inquiry within British Columbia confirmed", missingFields: ["estate.p11DiligentSearchConfirmed=yes"], tab: "forms", source: "Form P11 paragraph 4" },
      { requirementId: "p11_jurat_city", label: "City where the affidavit will be sworn", missingFields: ["estate.juratCity"], tab: "forms", source: "Form P11 face (jurat)" },
    ])], { formName: "P11 — Affidavit of Assets and Liabilities for Non-Domiciled Estate Grant", estate: { deceasedDomiciledInBC: "", foreignAdministrationConfirmed: "", p11DiligentSearchConfirmed: "", juratCity: "" } });
    expect(screen.getByTestId("pre-generate-editor-deceasedDomiciledInBC")).toBeTruthy();
    expect(screen.getByTestId("pre-generate-editor-foreignAdministrationConfirmed")).toBeTruthy();
    expect(screen.getByTestId("pre-generate-editor-p11DiligentSearchConfirmed")).toBeTruthy();
    expect(screen.getByTestId("pre-generate-editor-juratCity")).toBeTruthy();
    // The assertion accessor itself never becomes an editor.
    expect(screen.queryByTestId("pre-generate-editor-deceasedDomiciledInBC=no")).toBeNull();
  });

  it("hides P3 Rule 25-3(6) completion mechanics and offers the explicit draft route", () => {
    const handlers = renderInline([gapReport("P3", [{
      requirementId: "p3_rule_25_3_6_belief_last_bc_will_unconfirmed",
      label: "Record the applicant's belief that this is the last will dealing with BC property before swearing Form P3",
      missingFields: [],
      tab: "intake",
      source: "SCCR Rule 25-3(2)(b) + Rule 25-3(6); Form P3",
    }])], { formName: "P3 — Short-form affidavit", estate: { beliefLastBcWill: "" } });

    expect(screen.queryByTestId("pre-generate-editor-beliefLastBcWill")).toBeNull();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    expect(handlers.onProceed).toHaveBeenCalledWith({ generateAnyway: true });
  });

  // Nick 2026-09-02 (fourth estate-#18 live audit): the P16 ¶2 presence row is
  // a manual-confirm sentinel (missingFields: []); its hint now renders the
  // Intake yes/no select in place of the "Go to Intake" dead end.
  it("renders the hinted presence select for the P16 manual-confirm row", () => {
    renderInline([gapReport("P16", [
      { requirementId: "p16_presence_confirmed", label: "Confirm the P16 deponent was present when the will was signed", missingFields: [], tab: "intake", source: "SCCR Rule 25-3(20)(a)/(21)(a); Form P16 ¶2" },
    ])], { formName: "P16 — Affidavit of Interlineation, Erasure, Obliteration or Other Alteration", estate: { p16DeponentPresentAtSigning: "" } });
    expect(screen.getByTestId("pre-generate-editor-p16DeponentPresentAtSigning")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-jump-p16_presence_confirmed")).toBeNull();
  });

  it("Generate anyway with nothing typed proceeds directly (no apply round trip)", () => {
    const handlers = renderInline([gapReport("P2", [{
      requirementId: "p2_treaty_first_nation_answer",
      label: "Nisga'a / treaty first nation answer",
      missingFields: ["estate.deceasedFirstName"],
      tab: "intake",
      source: "Form P2 Part 1",
    }])]);
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    expect(handlers.onProceed).toHaveBeenCalledTimes(1);
    expect(handlers.onApplyInline).not.toHaveBeenCalled();
  });

  it("disables Apply & re-check until something was actually typed", () => {
    renderInline([gapReport("P1", [{
      requirementId: "p1_deceased_name",
      label: "Deceased's full name",
      missingFields: ["estate.deceasedFirstName"],
      tab: "intake",
      source: "SCCR Rule 25-2(3)(a)",
    }])]);
    expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(true);
  });

  it("keeps P1 corrections canonical and creates a complete applying contact without a Contacts detour", async () => {
    const handlers = renderInline([gapReport("P1", [{
      requirementId: "p1_applicant_contact",
      label: "At least one applying applicant contact",
      missingFields: [],
      tab: "contacts",
      source: "SCCR Rule 25-2(3)(b)",
    }])], { contacts: [] });

    expect(screen.queryByTestId("pre-generate-jump-p1_applicant_contact")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();

    const editor = screen.getByTestId("pre-generate-p1-applicant-create");
    const inputs = editor.querySelectorAll("input");
    const address = editor.querySelector("textarea")!;
    fireEvent.change(inputs[0], { target: { value: "Alex Applicant" } });
    fireEvent.change(address, { target: { value: "100 Main Street, Victoria, BC" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      {
        estate: {},
        contacts: [{ mode: "createApplicant", name: "Alex Applicant", residentialAddress: "100 Main Street, Victoria, BC" }],
        uploads: [],
      },
    ));
  });

  it("renders an enum column as a select (combobox), never a text box", () => {
    renderInline([gapReport("P4", [{
      requirementId: "p4_oath_type",
      label: "Oath type",
      missingFields: ["estate.oathType"],
      tab: "forms",
      source: "Form P4 jurat",
    }])]);
    const editor = screen.getByTestId("pre-generate-editor-oathType");
    expect(editor.querySelector('[role="combobox"]')).not.toBeNull();
    expect(editor.querySelector('input[type="text"]')).toBeNull();
  });

  it("uses civil marital status as the starting value for a popup-only WESA determination and records it only on Apply", () => {
    const handlers = renderInline([gapReport("P10", [{
      requirementId: "p10_wesa_spouse_status",
      label: "WESA spouse determination for the P10 intestacy distribution",
      missingFields: ["estate.spouseStatus"],
      tab: "forms",
      source: "WESA s.2",
    }])], { estate: { maritalStatus: "married", spouseStatus: "" } });

    expect(screen.getByTestId("pre-generate-editor-spouseStatus").textContent).toContain("Married and cohabiting");
    expect(screen.getByText(/Suggested from civil marital status/i)).toBeTruthy();
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    expect(handlers.onApplyInline).toHaveBeenCalledWith({ spouseStatus: "married" }, true, []);
  });

  it("creates a canonical spouse Contact for a missing P2 schedule person instead of writing an estate-level spouse name", async () => {
    const handlers = renderInline([gapReport("P2", [{
      requirementId: "p2_spouse_contact",
      label: "Current spouse or common-law partner Contact for Form P2 Schedule §2(a)",
      missingFields: [],
      tab: "forms",
      source: "Form P2, Part 4 Schedule §2(a)",
    }])]);

    const editor = screen.getByTestId("pre-generate-p1-spouse-create");
    fireEvent.change(editor.querySelector("input")!, { target: { value: "Morgan Survivor" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      {
        estate: {},
        contacts: [{ mode: "createSpouse", name: "Morgan Survivor", residentialAddress: "" }],
        uploads: [],
      },
    ));
  });

  it("smoothly reveals the separation follow-up controls beneath a separated WESA determination", async () => {
    renderInline([gapReport("P2", [{
      requirementId: "p2_wesa_spouse_status",
      label: "WESA spouse determination for the Form P2 Schedule",
      missingFields: ["estate.spouseStatus"],
      tab: "forms",
      source: "WESA s.2",
    }])], { estate: { maritalStatus: "married", spouseStatus: "separated" } });

    const followUp = await screen.findByTestId("pre-generate-wesa-separation-follow-up");
    expect(followUp.getAttribute("role")).toBe("region");
    expect(followUp.getAttribute("aria-label")).toBe("WESA separation details");
    expect(followUp.className).toContain("motion-safe:animate-in");
    expect(followUp.className).toContain("motion-safe:fade-in");
    expect(followUp.className).toContain("motion-safe:slide-in-from-top-1");
    expect(screen.getByTestId("pre-generate-input-separationDate")).toBeTruthy();
    expect(screen.getByTestId("pre-generate-input-reconciliationPrimaryPurpose")).toBeTruthy();
  });

  it("limits the P1 popup to values consumed by the P1 output while retaining Generate Anyway", () => {
    const handlers = renderInline([gapReport("P1", [
      { requirementId: "p1_registry", label: "Court registry where the application will be filed", missingFields: ["estate.registry"], tab: "intake", source: "Form P1 template" },
      { requirementId: "p1_recipient_list", label: "Rule 25-2 notice recipient", missingFields: [], tab: "contacts", source: "SCCR Rule 25-2(2)" },
      { requirementId: "p1_wesa_spouse_status", label: "WESA spouse determination for spouse notice review", missingFields: ["estate.spouseStatus"], tab: "forms", source: "WESA s.2" },
      { requirementId: "p1_electronic_will_no_signature_reason", label: "Reason there is no visible signature", missingFields: ["estate.noVisibleSignatureReason"], tab: "intake", source: "SCCR Rule 25-2(3)(h)" },
      { requirementId: "p1_will_copy_upload", label: "Copy of the will uploaded for delivery with Form P1", missingFields: ["estate.willStorageKey"], tab: "intake", source: "SCCR Rule 25-2(1.1)" },
    ])]);

    expect(screen.getByTestId("pre-generate-gap-p1_registry")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-gap-p1_recipient_list")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p1_wesa_spouse_status")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p1_electronic_will_no_signature_reason")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p1_will_copy_upload")).toBeNull();

    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    expect(handlers.onProceed).toHaveBeenCalledTimes(1);
  });

  it("limits the P2 popup to values consumed by the P2 output while retaining Generate Anyway", () => {
    const handlers = renderInline([gapReport("P2", [
      { requirementId: "p2_treaty_first_nation_answer", label: "Nisg̱a'a citizen, treaty first nation member, or neither", missingFields: ["estate.treatyFirstNation"], tab: "intake", source: "Form P2 Part 1" },
      { requirementId: "p2_vsa_certificate_received", label: "VSA wills-notice search certificate received", missingFields: ["requiredDocuments[docKey=wills_notice_result].received"], tab: "readiness", source: "SCCR Rule 25-3(2)(d)" },
      { requirementId: "p2_vsa_all_names_searched", label: "Names covered by the VSA wills-notice search", missingFields: ["estate.vsaNamesSearched"], tab: "intake", source: "WESA s.77" },
      { requirementId: "p2_applicant_id_source", label: "Government identification for the affidavit deponent received", missingFields: ["requiredDocuments[docKey=applicant_id].received"], tab: "readiness", source: "Affidavit commissioning source document" },
      { requirementId: "p2_notice_wait_elapsed", label: "Earliest application date reached", missingFields: [], tab: "forms", source: "SCCR Rule 25-2(2.1)" },
      { requirementId: "p2_ancillary_foreign_grant_certification", label: "Confirm the foreign-grant copy is certified", missingFields: [], tab: "intake", source: "SCCR Rule 25-3(2)(j)" },
    ])]);

    expect(screen.getByTestId("pre-generate-gap-p2_treaty_first_nation_answer")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-gap-p2_vsa_certificate_received")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p2_vsa_all_names_searched")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p2_applicant_id_source")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p2_notice_wait_elapsed")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p2_ancillary_foreign_grant_certification")).toBeNull();

    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    expect(handlers.onProceed).toHaveBeenCalledTimes(1);
  });

  it("limits the P3 popup to values consumed by the P3 output while retaining Generate Anyway", () => {
    const handlers = renderInline([gapReport("P3", [
      { requirementId: "p3_oath_type", label: "Oath type (sworn or affirmed)", missingFields: ["estate.oathType"], tab: "forms", source: "Form P3 template (jurat)" },
      { requirementId: "p3_will_date", label: "Date of will", missingFields: ["estate.willDate"], tab: "intake", source: "SCCR Rule 25-3(2)(b)" },
      { requirementId: "p3_vsa_certificate_received", label: "VSA wills-notice search certificate received", missingFields: ["requiredDocuments[docKey=wills_notice_result].received"], tab: "readiness", source: "SCCR Rule 25-3(2)(d)" },
      { requirementId: "p3_original_will_source", label: "Original will received", missingFields: ["requiredDocuments[docKey=original_will].received"], tab: "readiness", source: "SCCR Rule 25-3(3)(a)" },
    ])]);

    expect(screen.getByTestId("pre-generate-gap-p3_oath_type")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-gap-p3_will_date")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p3_vsa_certificate_received")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p3_original_will_source")).toBeNull();

    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    expect(handlers.onProceed).toHaveBeenCalledTimes(1);
  });

  it("limits the P4 popup to values consumed by the P4 output while retaining Generate Anyway", () => {
    const handlers = renderInline([gapReport("P4", [
      { requirementId: "p4_oath_type", label: "Oath type (sworn or affirmed)", missingFields: ["estate.oathType"], tab: "forms", source: "Form P4 template (jurat)" },
      { requirementId: "p4_vsa_certificate_received", label: "VSA wills-notice search certificate received", missingFields: ["requiredDocuments[docKey=wills_notice_result].received"], tab: "readiness", source: "SCCR Rule 25-3(2)(d)" },
      { requirementId: "p4_wesa_s58_order", label: "Sealed WESA s.58 order and order date", missingFields: ["estate.wesaS58OrderDate", "estate.wesaS58OrderFilePath"], tab: "intake", source: "WESA s.58" },
      { requirementId: "p4_rule_25_3_6_orders_affecting_will_unconfirmed", label: "Record whether a court order affects the will", missingFields: [], tab: "intake", source: "SCCR Rule 25-3(6)" },
    ])]);

    expect(screen.getByTestId("pre-generate-gap-p4_oath_type")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-gap-p4_vsa_certificate_received")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p4_wesa_s58_order")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p4_rule_25_3_6_orders_affecting_will_unconfirmed")).toBeNull();

    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    expect(handlers.onProceed).toHaveBeenCalledTimes(1);
  });

  it("limits the P5 popup to values consumed by the P5 output while retaining Generate Anyway", () => {
    const handlers = renderInline([gapReport("P5", [
      { requirementId: "p5_other_grants_status", label: "Other-grants/application status", missingFields: ["estate.otherGrantsStatus"], tab: "intake", source: "Form P5 §6" },
      { requirementId: "p5_prior_rights_consent", label: "Prior/equal-right contacts' consent recorded", missingFields: [], tab: "contacts", source: "WESA s.130" },
      { requirementId: "p5_prior_rights_inquiry_details", label: "Details of inquiries made when contacts cannot be located", missingFields: [], tab: "contacts", source: "WESA s.130" },
      { requirementId: "p5_wesa_spouse_status", label: "WESA s.2 spouse determination", missingFields: ["estate.spouseStatus"], tab: "forms", source: "WESA s.2" },
    ])]);

    expect(screen.getByTestId("pre-generate-gap-p5_other_grants_status")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-gap-p5_prior_rights_consent")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p5_prior_rights_inquiry_details")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p5_wesa_spouse_status")).toBeNull();

    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    expect(handlers.onProceed).toHaveBeenCalledTimes(1);
  });

  it("limits the P6 popup to values consumed by the P6 output while retaining Generate Anyway", () => {
    const handlers = renderInline([gapReport("P6", [
      { requirementId: "p6_vsa_certificate_result", label: "Wills-notice search certificate result", missingFields: ["estate.vsaCertificateResult"], tab: "intake", source: "Form P6 paragraph 6" },
      { requirementId: "p6_foreign_grant_issued_date", label: "Date the foreign grant was issued", missingFields: ["estate.foreignGrantIssuedDate"], tab: "intake", source: "SCCR Rule 25-3(3)(b)" },
      { requirementId: "p6_foreign_grant_issuing_court", label: "Foreign grant issuing court", missingFields: ["estate.foreignGrantIssuingCourt"], tab: "intake", source: "SCCR Rule 25-3(3)(b)" },
      { requirementId: "p6_will_date", label: "Date of will", missingFields: ["estate.willDate"], tab: "intake", source: "SCCR Rule 25-3(2)(b)" },
      { requirementId: "p6_vsa_certificate_received", label: "VSA certificate received", missingFields: ["requiredDocuments[docKey=wills_notice_result].received"], tab: "readiness", source: "SCCR Rule 25-3(2)(d)" },
    ])]);

    expect(screen.getByTestId("pre-generate-gap-p6_vsa_certificate_result")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-gap-p6_foreign_grant_issued_date")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p6_foreign_grant_issuing_court")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p6_will_date")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p6_vsa_certificate_received")).toBeNull();

    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    expect(handlers.onProceed).toHaveBeenCalledTimes(1);
  });

  it("limits the P7 popup to values consumed by the P7 output while retaining Generate Anyway", () => {
    const handlers = renderInline([gapReport("P7", [
      { requirementId: "p7_foreign_grant_issuing_court", label: "Foreign grant issuing court", missingFields: ["estate.foreignGrantIssuingCourt"], tab: "intake", source: "Form P7 paragraph 1" },
      { requirementId: "p7_foreign_grant_grantees", label: "People named in the foreign grant", missingFields: ["estate.foreignGrantGranteeNames"], tab: "intake", source: "Form P7 paragraph 3" },
      { requirementId: "p7_wills_notice_found_omits_para6", label: "Wills notice found", missingFields: [], tab: "intake", source: "Form P7 paragraph 6" },
      { requirementId: "p7_vsa_certificate_received", label: "VSA certificate received", missingFields: ["requiredDocuments[docKey=wills_notice_result].received"], tab: "readiness", source: "SCCR Rule 25-3(2)(d)" },
    ])]);

    expect(screen.getByTestId("pre-generate-gap-p7_foreign_grant_issuing_court")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-gap-p7_foreign_grant_grantees")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p7_wills_notice_found_omits_para6")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p7_vsa_certificate_received")).toBeNull();

    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    expect(handlers.onProceed).toHaveBeenCalledTimes(1);
  });

  it.each([
    ["P1", "p1_registry", "p1_applicability"],
    ["P2", "p2_treaty_first_nation_answer", "p2_applicability"],
    ["P3", "p3_oath_type", "p3_applicability"],
    ["P4", "p4_oath_type", "p4_applicability"],
    ["P5", "p5_other_grants_status", "p5_applicability"],
    ["P6", "p6_vsa_certificate_result", "p6_applicability"],
    ["P7", "p7_foreign_grant_issuing_court", "p7_applicability"],
    ["P8", "p8_deponent_name", "p8_applicability"],
    ["P9", "p9_deponent_name", "p9_applicability"],
    ["P10", "p10_wesa_spouse_status", "p10_applicability"],
  ])("keeps %s non-content hard gates out of the popup and forwards explicit draft intent", (formCode, renderedId, hiddenId) => {
    const handlers = renderInline([gapReport(formCode, [
      { requirementId: renderedId, label: "Rendered answer", missingFields: ["estate.example"], tab: "forms", source: "Form face" },
      { requirementId: hiddenId, label: "Availability / workflow", missingFields: [], tab: "readiness", source: "Workflow", blocker: "hard" },
    ], { hardBlocked: true, notApplicable: true })]);

    expect(screen.getByTestId(`pre-generate-gap-${renderedId}`)).toBeTruthy();
    expect(screen.queryByTestId(`pre-generate-gap-${hiddenId}`)).toBeNull();
    expect((screen.getByTestId("pre-generate-proceed") as HTMLButtonElement).disabled).toBe(false);

    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    expect(handlers.onProceed).toHaveBeenCalledWith({ generateAnyway: true });
  });

  it("keeps P1–P10 non-content fields out of a mixed P2 and P9 package popup", () => {
    const handlers = renderInline([
      gapReport("P2", [
        { requirementId: "p2_treaty_first_nation_answer", label: "P2 treaty election", missingFields: ["estate.treatyFirstNation"], tab: "intake", source: "Form P2 Part 1" },
        { requirementId: "p2_vsa_certificate_received", label: "VSA certificate received", missingFields: ["requiredDocuments[docKey=wills_notice_result].received"], tab: "readiness", source: "SCCR Rule 25-3(2)(d)" },
        { requirementId: "p2_notice_circle_confirmed", label: "Notice circle confirmed", missingFields: ["estate.noticeContactsComplete"], tab: "intake", source: "SCCR Rule 25-2(2)" },
      ]),
      gapReport("P9", [
        { requirementId: "p9_delivery_methods_and_dates", label: "P9 delivery method and date", missingFields: [], tab: "forms", source: "Form P9 section 2" },
        { requirementId: "p9_dispensation_order", label: "Dispensation order record", missingFields: ["deliveries[dispensedByOrder=1].dispensationOrderDate"], tab: "forms", source: "SCCR Rule 25-2(14)(b)" },
      ]),
    ]);

    expect(screen.getByTestId("pre-generate-gap-p2_treaty_first_nation_answer")).toBeTruthy();
    expect(screen.getByTestId("pre-generate-gap-p9_delivery_methods_and_dates")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-gap-p2_vsa_certificate_received")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p2_notice_circle_confirmed")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p9_dispensation_order")).toBeNull();

    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    expect(handlers.onProceed).toHaveBeenCalledWith({ generateAnyway: true });
  });

  it("does not show P7's organization-title input because that title does not print on P7", async () => {
    renderInline([gapReport("P7", [{
      requirementId: "p7_organization_signatory",
      label: "Organization signatory",
      missingFields: ["contacts[role~applicant].orgSignatoryName"],
      tab: "contacts",
      source: "Form P7 affidavit preamble",
    }])], {
      contacts: [{ id: "p7-organization", name: "Example Trust", role: "applicant", applicantKind: "organization", orgSignatoryName: "", orgSignatoryTitle: "" }],
    });

    expect(await screen.findByTestId("pre-generate-p7-signatory-name-p7-organization")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-p7-signatory-title-p7-organization")).toBeNull();
  });
});

describe("what must NOT get an inline editor", () => {
  it("an equality accessor renders no input and keeps the jump button", () => {
    renderInline([gapReport("P10", [{
      requirementId: "p10_domicile_assertion",
      label: "Deceased not domiciled in BC",
      missingFields: ["estate.deceasedDomiciledInBC=no"],
      tab: "intake",
      source: "Rule 25-3(5)",
    }])]);
    expect(screen.queryByTestId("pre-generate-editor-deceasedDomiciledInBC")).toBeNull();
    expect(screen.getByTestId("pre-generate-jump-p10_domicile_assertion")).toBeTruthy();
    expect(screen.getByTestId("pre-generate-fields-p10_domicile_assertion").textContent)
      .toContain("estate.deceasedDomiciledInBC=no");
    expect(screen.queryByTestId("pre-generate-apply")).toBeNull();
  });

  it("non-estate namespaces and unregistered columns keep the legacy row", () => {
    // testamentaryDocStatus is the Rule 24 exclusion: deliberately absent from
    // the registry (two conditional Intake editors; P7 ¶5 matches only
    // none_found/found), so it must keep the jump-to-tab row.
    renderInline([gapReport("P1", [{
      requirementId: "p1_applicant_contact",
      label: "Applicant contact",
      missingFields: ["contacts[role~applicant].name", "estate.testamentaryDocStatus"],
      tab: "contacts",
      source: "SCCR Rule 25-2(3)(b)",
    }])]);
    expect(screen.queryByTestId("pre-generate-editor-testamentaryDocStatus")).toBeNull();
    const missing = screen.getByTestId("pre-generate-fields-p1_applicant_contact").textContent;
    expect(missing).toContain("contacts[role~applicant].name");
    expect(missing).toContain("estate.testamentaryDocStatus");
  });

  it("lets the P8 popup answer the primary affidavit reference directly", async () => {
    const handlers = renderInline([gapReport("P8", [{
      requirementId: "p8_primary_affidavit_history",
      label: "Generate and retain exactly one primary applicant affidavit before Form P8",
      missingFields: [],
      tab: "forms",
      source: "Form P8 paragraph 2; SCCR Rule 25-3(2)(b)-(c)",
    }])]);
    expect(screen.getByTestId("pre-generate-p8-primary-affidavit-editor")).toBeTruthy();
    fireEvent.click(screen.getByTestId("pre-generate-p8-primary-form"));
    fireEvent.click(screen.getByText("Form P3"));
    fireEvent.change(screen.getByTestId("pre-generate-p8-primary-date"), { target: { value: "2026-10-10" } });
    fireEvent.change(screen.getByTestId("pre-generate-p8-primary-deponent"), { target: { value: "Primary Applicant" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalled());
  });

  it("package/bulk runs (inlineEditingEnabled=false) render the legacy dialog untouched", () => {
    renderInline([gapReport("P1", [{
      requirementId: "p1_deceased_name",
      label: "Deceased's full name",
      missingFields: ["estate.deceasedFirstName"],
      tab: "intake",
      source: "SCCR Rule 25-2(3)(a)",
    }])], { inlineEditingEnabled: false });
    expect(screen.queryByTestId("pre-generate-editor-deceasedFirstName")).toBeNull();
    expect(screen.queryByTestId("pre-generate-apply")).toBeNull();
    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-fields-p1_deceased_name").textContent)
      .toContain("estate.deceasedFirstName");
  });
});

describe("mode:any OR-sets", () => {
  it("labels a real any-mode requirement as alternatives and only edits registered members", () => {
    // p1_deceased_last_residence is mode:"any" in FORM_REQUIREMENTS —
    // missingFields carries the whole OR-set. deceasedAddress is a legacy
    // column with no registry entry; the other two are editable.
    renderInline([gapReport("P1", [{
      requirementId: "p1_deceased_last_residence",
      label: "Deceased's last usual residential address",
      missingFields: ["estate.deceasedAddress", "estate.addressStreet", "estate.deceasedPostOfficeBox"],
      tab: "intake",
      source: "SCCR Rule 25-2(3)(a)",
    }])]);
    expect(screen.getByTestId("pre-generate-anyof-p1_deceased_last_residence").textContent)
      .toContain("any one of these");
    expect(screen.getByTestId("pre-generate-editor-addressStreet")).toBeTruthy();
    expect(screen.getByTestId("pre-generate-editor-deceasedPostOfficeBox")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-editor-deceasedAddress")).toBeNull();
  });

  it("an all-mode gap gets no alternatives note", () => {
    renderInline([gapReport("P1", [{
      requirementId: "p1_deceased_name",
      label: "Deceased's full name",
      missingFields: ["estate.deceasedFirstName"],
      tab: "intake",
      source: "SCCR Rule 25-2(3)(a)",
    }])]);
    expect(screen.queryByTestId("pre-generate-anyof-p1_deceased_name")).toBeNull();
  });
});

describe("canonical form-local persistence", () => {

  it("persists a P4 direct editor to the canonical estate record before re-check", () => {
    const handlers = renderInline([gapReport("P4", [{
      requirementId: "p4_deceased_name",
      label: "Deceased's full name",
      missingFields: ["estate.deceasedFirstName"],
      tab: "intake",
      source: "SCCR Rule 25-3(2)(b)",
    }])]);

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P4 corrections");

    fireEvent.change(screen.getByTestId("pre-generate-input-deceasedFirstName"), { target: { value: "Jane" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    expect(handlers.onApplyInline).toHaveBeenCalledWith({ deceasedFirstName: "Jane" }, true, []);
  });

  it("persists a P5 direct editor to the canonical estate record before re-check", () => {
    const handlers = renderInline([gapReport("P5", [{
      requirementId: "p5_other_grant_description",
      label: "P5 §6: issued grant description",
      missingFields: ["estate.otherGrantsDescription"],
      tab: "intake",
      source: "SCCR Rule 25-3(2)(b)",
    }])]);

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P5 corrections");

    fireEvent.change(screen.getByTestId("pre-generate-input-otherGrantsDescription"), {
      target: { value: "Ontario probate grant dated 2025-01-10" },
    });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    expect(handlers.onApplyInline).toHaveBeenCalledWith({ otherGrantsDescription: "Ontario probate grant dated 2025-01-10" }, true, []);
  });

  it("asks for and persists the explicit P5 paragraph (c) without deriving it from contact facts", async () => {
    const handlers = renderInline([gapReport("P5", [{
      requirementId: "p5_priority_paragraph",
      label: "Choose the applicable WESA s.130 priority paragraph for P5 section 2",
      missingFields: [],
      tab: "forms",
      source: "WESA s.130; Form P5 section 2",
    }])]);

    expect(screen.getByTestId("pre-generate-p5-priority-choice").textContent).toContain("(c) a person nominated by a child");
    fireEvent.click(screen.getByTestId("pre-generate-p5-priority-c"));
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      { estate: { applicantPriorityParagraph: "c" }, contacts: [], uploads: [] },
    ));
  });

  it("persists a P5 deponent correction to the canonical applying contact before re-check", async () => {
    const handlers = renderInline([gapReport("P5", [{
      requirementId: "p5_deponent_occupation",
      label: "Deponent's occupation (affidavit preamble)",
      missingFields: [],
      tab: "contacts",
      source: "Form P5 face (deponent preamble)",
    }])], {
      contacts: [{ id: "applicant-1", name: "Alex Applicant", role: "applicant", executorStatus: "applying", occupation: "" }],
    });

    expect(screen.queryByTestId("pre-generate-jump-p5_deponent_occupation")).toBeNull();
    fireEvent.change(screen.getByTestId("pre-generate-p5-deponent-occupation"), { target: { value: "Teacher" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      {
        estate: {},
        contacts: [{ mode: "update", id: "applicant-1", occupation: "Teacher" }],
        uploads: [],
      },
    ));
  });

  it("hides the P5 intestate-successor workflow from the content-only popup", () => {
    const handlers = renderInline([gapReport("P5", [{
      requirementId: "p5_intestate_successors",
      label: "At least one intestate successor listed in Contacts",
      missingFields: ["ANY_OF:", "contacts[recipientType=spouse].name", "contacts[recipientType=child].name", "contacts[recipientType=intestate_successor].name"],
      tab: "contacts",
      source: "WESA Part 3 Div 1",
    }])], {
      contacts: [{ id: "applicant-1", name: "Alex Applicant", role: "applicant", executorStatus: "applying" }],
    });

    expect(screen.queryByTestId("pre-generate-gap-p5_intestate_successors")).toBeNull();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    expect(handlers.onProceed).toHaveBeenCalledWith({ generateAnyway: true });
  });

  it("keeps the P5 automatic PGT trigger as a truthful workflow gate", () => {
    renderInline([gapReport("P5", [{
      requirementId: "p5_pgt_auto_required",
      label: "PGT notification is required because a recipient is a minor or mentally incapable",
      missingFields: [],
      tab: "intake",
      source: "SCCR Rule 25-2(8)(b) + Rule 25-2(11); Form P5 paragraph 3",
    }])]);

    expect(screen.queryByTestId("pre-generate-editor-notifyPGT")).toBeNull();
    expect(screen.getByTestId("pre-generate-jump-p5_pgt_auto_required").textContent).toContain("Go to Intake");
  });

  it("persists a P6 applying-applicant residence correction to the canonical contact before re-check", async () => {
    const handlers = renderInline([gapReport("P6", [{
      requirementId: "p6_individual_applicant_residence",
      label: "Every individual applying applicant needs a residential street address and ordinary-residence city, province/state and country",
      missingFields: [],
      tab: "contacts",
      source: "Form P6 preamble and paragraph 2",
    }])], {
      contacts: [{ id: "applicant-6", name: "Alex Applicant", role: "applicant", executorStatus: "applying", applicantKind: "individual", residentialAddress: "10 Main Street", residenceCity: "", residenceProvince: "BC", residenceCountry: "Canada" }],
    });

    expect(screen.queryByTestId("pre-generate-jump-p6_individual_applicant_residence")).toBeNull();
    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P6 corrections");
    fireEvent.change(screen.getByTestId("pre-generate-p6-residence-city-applicant-6"), { target: { value: "Victoria" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      {
        estate: {},
        contacts: [{ mode: "update", id: "applicant-6", residenceCity: "Victoria" }],
        uploads: [],
      },
    ));
  });

  it("keeps the P6 automatic PGT trigger as a truthful workflow gate", () => {
    renderInline([gapReport("P6", [{
      requirementId: "p6_pgt_auto_required",
      label: "PGT notification is required because a recipient is a minor or mentally incapable",
      missingFields: [],
      tab: "intake",
      source: "SCCR Rule 25-2(8)(b) + Rule 25-2(11); Form P6 paragraph 4",
    }])]);

    expect(screen.queryByTestId("pre-generate-editor-notifyPGT")).toBeNull();
    expect(screen.getByTestId("pre-generate-jump-p6_pgt_auto_required").textContent).toContain("Go to Intake");
  });

  it("persists a P7 applying-applicant residence correction to the canonical contact before re-check", async () => {
    const handlers = renderInline([gapReport("P7", [{
      requirementId: "p7_individual_applicant_residence",
      label: "Every individual applying applicant needs a residential street address and ordinary-residence city, province/state and country",
      missingFields: [],
      tab: "contacts",
      source: "Form P7 preamble and paragraph 2",
    }])], {
      contacts: [{ id: "applicant-7", name: "Alex Applicant", role: "applicant", executorStatus: "applying", applicantKind: "individual", residentialAddress: "10 Main Street", residenceCity: "", residenceProvince: "BC", residenceCountry: "Canada" }],
    });

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P7 corrections");
    fireEvent.change(screen.getByTestId("pre-generate-p7-residence-city-applicant-7"), { target: { value: "Victoria" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      {
        estate: {},
        contacts: [{ mode: "update", id: "applicant-7", residenceCity: "Victoria" }],
        uploads: [],
      },
    ));
  });

  it("persists the P7 foreign-grant date from its local editor to the canonical estate before re-check", async () => {
    const handlers = renderInline([gapReport("P7", [{
      requirementId: "p7_foreign_grant_issued_date",
      label: "Date the foreign grant was issued",
      missingFields: ["estate.foreignGrantIssuedDate"],
      tab: "intake",
      source: "SCCR Rule 25-3(3)(c)",
    }])]);

    fireEvent.change(screen.getByTestId("pre-generate-p7-foreign-grant-date-input"), { target: { value: "2026-01-15" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      { estate: { foreignGrantIssuedDate: "2026-01-15" }, contacts: [], uploads: [] },
    ));
  });

  it("keeps P7’s automatic PGT requirement while hiding the non-input wills-notice advisory", () => {
    renderInline([gapReport("P7", [
      {
        requirementId: "p7_wills_notice_found_omits_para6",
        label: "The wills-notice search found a notice",
        missingFields: [],
        tab: "intake",
        source: "Form P7 paragraph 6",
      },
      {
        requirementId: "p7_pgt_auto_required",
        label: "PGT notification is required because a recipient is a minor or mentally incapable",
        missingFields: [],
        tab: "intake",
        source: "SCCR Rule 25-2(8)(b) + Rule 25-2(11); Form P7 paragraph 4",
      },
    ])]);

    expect(screen.queryByTestId("pre-generate-editor-notifyPGT")).toBeNull();
    expect(screen.queryByTestId("pre-generate-jump-p7_wills_notice_found_omits_para6")).toBeNull();
    expect(screen.getByTestId("pre-generate-jump-p7_pgt_auto_required").textContent).toContain("Go to Intake");
  });

  it("persists a P8 co-applicant occupation correction only to the co-applicant resolved from the retained primary affidavit", async () => {
    const handlers = renderInline([gapReport("P8", [{
      requirementId: "p8_deponent_occupation",
      label: "Co-applicant deponent occupation",
      missingFields: [],
      tab: "contacts",
      source: "Form P8 face (deponent preamble); SCCR Rule 25-3 (2)(c)",
    }])], {
      documents: [{ formCode: "P3", deponentId: "primary-8" }],
      contacts: [
        { id: "primary-8", name: "Primary Applicant", role: "applicant", executorStatus: "applying", occupation: "Lawyer" },
        { id: "co-applicant-8", name: "Co Applicant", role: "applicant", executorStatus: "applying", occupation: "" },
      ],
    });

    expect(screen.getByTestId("pre-generate-p8-co-applicants").textContent).toContain("Co Applicant");
    expect(screen.queryByTestId("pre-generate-p8-deponent-occupation-primary-8")).toBeNull();
    fireEvent.change(screen.getByTestId("pre-generate-p8-deponent-occupation-co-applicant-8"), { target: { value: "Accountant" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      {
        estate: {},
        contacts: [{ mode: "update", id: "co-applicant-8", occupation: "Accountant" }],
        uploads: [],
      },
    ));
  });

  it("persists P8 organization signatory fields that the affidavit actually prints", async () => {
    const handlers = renderInline([gapReport("P8", [
      { requirementId: "p8_deponent_name", label: "Co-applicant deponent name", missingFields: [], tab: "contacts", source: "Form P8 face (deponent preamble)" },
      { requirementId: "p8_deponent_occupation", label: "Co-applicant deponent occupation", missingFields: [], tab: "contacts", source: "Form P8 face (deponent preamble)" },
    ])], {
      documents: [{ formCode: "P3", deponentId: "primary-8" }],
      contacts: [
        { id: "primary-8", name: "Primary Applicant", role: "applicant", executorStatus: "applying", occupation: "Lawyer" },
        { id: "co-applicant-org", name: "Executor Trust Co.", role: "applicant", executorStatus: "applying", applicantKind: "organization", orgSignatoryName: "", orgSignatoryTitle: "" },
      ],
    });

    expect(screen.queryByTestId("pre-generate-p8-deponent-name-co-applicant-org")).toBeNull();
    expect(screen.queryByTestId("pre-generate-p8-deponent-occupation-co-applicant-org")).toBeNull();
    fireEvent.change(screen.getByTestId("pre-generate-p8-signatory-name-co-applicant-org"), { target: { value: "Pat Lee" } });
    fireEvent.change(screen.getByTestId("pre-generate-p8-signatory-title-co-applicant-org"), { target: { value: "Trust Officer" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      {
        estate: {},
        contacts: [{ mode: "update", id: "co-applicant-org", orgSignatoryName: "Pat Lee", orgSignatoryTitle: "Trust Officer" }],
        uploads: [],
      },
    ));
  });

  it("keeps the P8 retained-primary-affidavit reference while hiding co-applicant availability workflow", () => {
    renderInline([gapReport("P8", [
      {
        requirementId: "p8_primary_affidavit_history",
        label: "Generate and retain exactly one primary applicant affidavit before Form P8",
        missingFields: [],
        tab: "forms",
        source: "Form P8 paragraph 2; SCCR Rule 25-3(2)(b)-(c)",
      },
      {
        requirementId: "p8_co_applicants",
        label: "At least 2 applying executor/applicant contacts",
        missingFields: [],
        tab: "contacts",
        source: "SCCR Rule 25-3(2)(c)",
      },
    ])]);

    expect(screen.getByTestId("pre-generate-p8-primary-affidavit-editor")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-gap-p8_co_applicants")).toBeNull();
    expect(screen.queryByTestId("pre-generate-p8-co-applicant-create")).toBeNull();
  });

  it("hides P9's will-copy receipt because the receipt does not affect the sworn P9 output", () => {
    renderInline([gapReport("P9", [{
      requirementId: "p9_will_copy_available",
      label: "Copy of the will that was delivered with Form P1 remains attached to the estate file",
      missingFields: ["estate.willStorageKey"],
      tab: "intake",
      source: "SCCR Rule 25-2(1.1)(a)(ii)/(iii); Form P9 section 2",
    }])]);

    expect(screen.queryByTestId("pre-generate-gap-p9_will_copy_available")).toBeNull();
    expect(screen.queryByTestId("pre-generate-p1-file-will")).toBeNull();
  });

  it("keeps only P9 values that affect its sworn output", () => {
    renderInline([gapReport("P9", [
      { requirementId: "p9_delivery_methods_and_dates", label: "Every non-dispensed delivery record has a method and date", missingFields: [], tab: "forms", source: "Form P9 template + SCCR Rule 25-2(5)" },
      { requirementId: "p9_electronic_ack_date", label: "Written acknowledgement date for every electronic delivery", missingFields: ["deliveries[deliveryMethod=electronic].ackDate"], tab: "forms", source: "SCCR Rule 25-2(7)(a)" },
      { requirementId: "p9_dispensation_order", label: "Sealed court order date and file for every dispensed recipient", missingFields: ["deliveries[dispensedByOrder=1].dispensationOrderDate"], tab: "forms", source: "SCCR Rule 25-2(14)(b)" },
      { requirementId: "p9_pgt_delivery_record", label: "Delivery record for the Public Guardian and Trustee", missingFields: [], tab: "forms", source: "Form P9 section 4" },
      { requirementId: "p9_substitute_receiver_names", label: "Name the guardian or committee who received delivery", missingFields: [], tab: "contacts", source: "Form P9 sections 2-3" },
    ])]);

    expect(screen.getByTestId("pre-generate-jump-p9_delivery_methods_and_dates").textContent).toContain("Go to Forms");
    expect(screen.getByTestId("pre-generate-jump-p9_electronic_ack_date").textContent).toContain("Go to Forms");
    expect(screen.queryByTestId("pre-generate-gap-p9_dispensation_order")).toBeNull();
    expect(screen.getByTestId("pre-generate-jump-p9_pgt_delivery_record").textContent).toContain("Go to Forms");
    expect(screen.getByTestId("pre-generate-jump-p9_substitute_receiver_names").textContent).toContain("Go to Contacts");
  });

  it("hides P10's non-editable foreign-grant scope advisory while retaining Exhibit A facts", () => {
    renderInline([gapReport("P10", [
      { requirementId: "p10_asset_descriptions", label: "Every asset row has a description", missingFields: ["inventory[all,category!=liability].description"], tab: "inventory", source: "Form P10 Exhibit A" },
      { requirementId: "p10_part3_foreign_grant_scope", label: "Another grant is recorded as issued", missingFields: [], tab: "inventory", source: "Form P10 Exhibit A Part III" },
    ])]);

    expect(screen.getByTestId("pre-generate-gap-p10_asset_descriptions")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-gap-p10_part3_foreign_grant_scope")).toBeNull();
  });

  it("persists a P10 selected-deponent occupation correction to that canonical contact before re-check", async () => {
    const handlers = renderInline([gapReport("P10", [{
      requirementId: "p10_deponent_occupation",
      label: "Deponent's occupation (affidavit preamble)",
      missingFields: [],
      tab: "contacts",
      source: "Form P10 face (deponent preamble)",
      editors: [{
        kind: "contact",
        id: "p10-deponent",
        rowLabel: "Alex Applicant",
        column: "occupation",
        control: { control: "text", label: "Occupation" },
        currentValue: "",
      }],
    }])], {
      selectedContactId: "p10-deponent",
      contacts: [{ id: "p10-deponent", name: "Alex Applicant", role: "applicant", executorStatus: "applying", occupation: "" }],
    });

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P10 corrections");
    expect(screen.queryByTestId("pre-generate-row-contact:p10-deponent")).toBeNull();
    expect(screen.queryByTestId("pre-generate-row-input-contact-p10-deponent-occupation")).toBeNull();
    fireEvent.change(screen.getByTestId("pre-generate-p10-deponent-occupation-p10-deponent"), { target: { value: "Accountant" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      {
        estate: {},
        contacts: [{ mode: "update", id: "p10-deponent", occupation: "Accountant" }],
        uploads: [],
      },
    ));
  });

  it("keeps P10 deponent selection, signature timing, distribution, valuation, and secured-debt facts as truthful workflow gates", () => {
    renderInline([gapReport("P10", [
      { requirementId: "p10_deponent_is_applicant", label: "Form P10 deponent is an applying applicant", missingFields: [], tab: "forms", source: "SCCR Rule 25-3(2)(g)" },
      { requirementId: "p10_signature_date", label: "Date the deponent swears or affirms Form P10", missingFields: ["renderContext.signatureDate"], tab: "forms", source: "Form P10 face (jurat)" },
      { requirementId: "p10_beneficiary_shares", label: "P10 supplementary distribution shares reconcile to the net estate value", missingFields: [], tab: "forms", source: "P10 Distribution section" },
      { requirementId: "p10_inventory_values", label: "Every inventory item has a recorded value-at-death basis — real-property FMV may be pending, but P10 remains incomplete until it is recorded", missingFields: ["inventory[all].probateValue"], tab: "inventory", source: "Form P10 paragraphs 3(b), 4(b) and Exhibits A and B" },
      { requirementId: "p10_secured_liability_asset_valid", label: "Each secured liability is linked to an existing Exhibit A property item", missingFields: [], tab: "inventory", source: "Form P10 paragraph 3(c)" },
    ])]);

    expect(screen.getByTestId("pre-generate-jump-p10_deponent_is_applicant").textContent).toContain("Go to Forms");
    expect(screen.getByTestId("pre-generate-jump-p10_signature_date").textContent).toContain("Go to Forms");
    expect(screen.getByTestId("pre-generate-jump-p10_beneficiary_shares").textContent).toContain("Go to Forms");
    expect(screen.getByTestId("pre-generate-jump-p10_inventory_values").textContent).toContain("Go to Inventory");
    expect(screen.getByTestId("pre-generate-jump-p10_secured_liability_asset_valid").textContent).toContain("Go to Inventory");
  });

  it("persists a P11 organization signatory correction to the selected canonical contact before re-check", async () => {
    const handlers = renderInline([gapReport("P11", [{
      requirementId: "p11_org_signatory_title",
      label: "Title or capacity of the organization applicant's signatory",
      missingFields: ["selectedContact.orgSignatoryTitle"],
      tab: "contacts",
      source: "Form P11 face (deponent preamble)",
    }])], {
      selectedContactId: "p11-org",
      contacts: [{ id: "p11-org", name: "Example Trust Co.", role: "applicant", executorStatus: "applying", applicantKind: "organization", orgSignatoryName: "Jamie Smith", orgSignatoryTitle: "" }],
    });

    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P11 corrections");
    fireEvent.change(screen.getByTestId("pre-generate-p11-signatory-title-p11-org"), { target: { value: "Authorized Officer" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      {
        estate: {},
        contacts: [{ mode: "update", id: "p11-org", orgSignatoryTitle: "Authorized Officer" }],
        uploads: [],
      },
    ));
  });

  it("keeps P11 deponent selection and affidavit timing while hiding secured-link validation", () => {
    renderInline([gapReport("P11", [
      { requirementId: "p11_deponent_selected", label: "Form P11 deponent selected", missingFields: ["renderContext.selectedContactId"], tab: "forms", source: "Form P11 face (deponent preamble)" },
      { requirementId: "p11_signature_date", label: "Date the Form P11 affidavit will be sworn or affirmed", missingFields: ["renderContext.signatureDate"], tab: "forms", source: "Form P11 face (jurat)" },
      { requirementId: "p11_secured_liability_asset_valid", label: "Each secured liability is linked to an existing property item", missingFields: [], tab: "inventory", source: "Form P11 paragraph 5(c)" },
      { requirementId: "p11_secured_link_requires_status", label: "Every liability linked to a charged asset is classified as a secured debt", missingFields: [], tab: "inventory", source: "Form P11 paragraph 5(c)" },
    ])]);

    expect(screen.getByTestId("pre-generate-jump-p11_deponent_selected").textContent).toContain("Go to Forms");
    expect(screen.getByTestId("pre-generate-jump-p11_signature_date").textContent).toContain("Go to Forms");
    expect(screen.queryByTestId("pre-generate-gap-p11_secured_liability_asset_valid")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p11_secured_link_requires_status")).toBeNull();
  });

  it("hides P11's non-rendered domicile-jurisdiction record while retaining its printed domicile election", () => {
    renderInline([gapReport("P11", [
      { requirementId: "p11_not_ordinarily_resident_in_bc", label: "Record whether the deceased was ordinarily resident in British Columbia at death", missingFields: ["estate.deceasedOrdinarilyResidentInBC"], tab: "forms", source: "Form P11 paragraph 2" },
      { requirementId: "p11_domicile_jurisdiction", label: "Deceased's domicile jurisdiction at death", missingFields: ["estate.deceasedDomicileJurisdiction"], tab: "forms", source: "SCCR Rule 25-3(8)(a)" },
    ])]);

    expect(screen.getByTestId("pre-generate-gap-p11_not_ordinarily_resident_in_bc")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-gap-p11_domicile_jurisdiction")).toBeNull();
  });

  it("persists a P12 translator correction to canonical estate data before re-check", async () => {
    const handlers = renderInline([gapReport("P12", [{
      requirementId: "p12_translator_name",
      label: "Translator's full name",
      missingFields: ["estate.translatorName"],
      tab: "intake",
      source: "SCCR Rule 25-3(2)(h)",
    }])]);

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P12 corrections");
    fireEvent.change(screen.getByTestId("pre-generate-input-translatorName"), { target: { value: "Alexandra Chen" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith({ translatorName: "Alexandra Chen" }, true, []));
  });

  it("persists a P14 direct estate correction canonically before re-check while retaining supplemental evidence gates", async () => {
    const handlers = renderInline([gapReport("P14", [{
      requirementId: "p14_deceased_name",
      label: "Deceased's name (style of cause)",
      missingFields: ["estate.deceasedFirstName", "estate.deceasedLastName"],
      tab: "intake",
      source: "Form P14 template",
    }])]);

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P14 corrections");
    fireEvent.change(screen.getByTestId("pre-generate-input-deceasedFirstName"), { target: { value: "Jordan" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith({ deceasedFirstName: "Jordan" }, true, []));
  });

  it("persists a P15 direct estate correction canonically before re-check while retaining supplemental evidence gates", async () => {
    const handlers = renderInline([gapReport("P15", [{
      requirementId: "p15_deceased_name",
      label: "Deceased's name (style of cause)",
      missingFields: ["estate.deceasedFirstName", "estate.deceasedLastName"],
      tab: "intake",
      source: "Form P15 template",
    }])]);

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P15 corrections");
    fireEvent.change(screen.getByTestId("pre-generate-input-deceasedFirstName"), { target: { value: "Morgan" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith({ deceasedFirstName: "Morgan" }, true, []));
  });

  it("persists a P16 direct estate correction canonically before re-check", async () => {
    const handlers = renderInline([gapReport("P16", [{
      requirementId: "p16_deceased_name",
      label: "Deceased's name (style of cause)",
      missingFields: ["estate.deceasedFirstName", "estate.deceasedLastName"],
      tab: "intake",
      source: "Form P16 template",
    }])]);

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P16 corrections");
    fireEvent.change(screen.getByTestId("pre-generate-input-deceasedFirstName"), { target: { value: "Casey" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith({ deceasedFirstName: "Casey" }, true, []));
  });

  it("keeps P16 signature timing a jump-only gate; the personal-knowledge confirmation is collected in place (Nick 2026-09-02, loop 4)", () => {
    renderInline([gapReport("P16", [
      { requirementId: "p16_signature_date", label: "Date the deponent swears or affirms Form P16", missingFields: ["renderContext.signatureDate"], tab: "forms", source: "Form P16 template (jurat)" },
      { requirementId: "p16_presence_confirmed", label: "Confirm the P16 deponent was present when the will was signed", missingFields: [], tab: "intake", source: "SCCR Rule 25-3(20)(a)/(21)(a); Form P16 ¶2" },
    ])], { estate: { p16DeponentPresentAtSigning: "" } });

    expect(screen.getByTestId("pre-generate-jump-p16_signature_date").textContent).toContain("Go to Forms");
    // The "Go to Intake" dead end is gone: the ¶2 sworn fact is a yes/no select
    // here; the row itself stays warn-only and an explicit "no" keeps warning
    // (P15PLUS-004 — the gate's truthfulness lives in the requirement row).
    expect(screen.queryByTestId("pre-generate-jump-p16_presence_confirmed")).toBeNull();
    expect(screen.getByTestId("pre-generate-editor-p16DeponentPresentAtSigning")).toBeTruthy();
  });

  it("reviews populated P16 facts separately and saves only the user's corrected page, line, and actual words", async () => {
    const handlers = renderInline([gapReport("P16", [], { ok: true })], { estate: {
      p16AlterationPage: "Page 1", p16AlterationLine: "Page 1, line 12",
      p16AlterationType: "interlineation", p16AlterationWords: "cottage words, presence yes",
      p16DeponentPresentAtSigning: "yes",
    } });
    expect(screen.getByTestId("pre-generate-p16-alteration-fields")).toBeTruthy();
    expect(screen.getByLabelText("Page")).toHaveProperty("value", "Page 1");
    expect(screen.getByLabelText("Line")).toHaveProperty("value", "Page 1, line 12");
    expect(screen.getByLabelText("Exact words added or affected (quoted on P16 ¶1)")).toHaveProperty("value", "cottage words, presence yes");
    expect(screen.getByTestId("pre-generate-input-p16DeponentPresentAtSigning").textContent).toBe("Yes");
    fireEvent.change(screen.getByLabelText("Page"), { target: { value: "1" } });
    fireEvent.change(screen.getByLabelText("Line"), { target: { value: "12" } });
    fireEvent.change(screen.getByLabelText("Exact words added or affected (quoted on P16 ¶1)"), { target: { value: "my interest in Lot 7" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith({
      p16AlterationPage: "1", p16AlterationLine: "12", p16AlterationWords: "my interest in Lot 7",
    }, true, []));
  });

  it("lets P16 clear incorrectly recorded words without changing its separate presence answer", async () => {
    const handlers = renderInline([gapReport("P16", [])], { estate: {
      p16AlterationPage: "1", p16AlterationLine: "12", p16AlterationType: "interlineation",
      p16AlterationWords: "cottage words, presence yes", p16DeponentPresentAtSigning: "yes",
    } });
    fireEvent.change(screen.getByTestId("pre-generate-input-p16AlterationWords"), { target: { value: "" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith({ p16AlterationWords: "" }, true, []));
    expect(screen.getByTestId("pre-generate-input-p16DeponentPresentAtSigning").textContent).toBe("Yes");
  });

  it("keeps one P16 words editor when a missing-words warning and a presence warning are both shown", () => {
    renderInline([gapReport("P16", [
      { requirementId: "p16_alteration_description", label: "Exact words missing", missingFields: [], tab: "intake", source: "Form P16 paragraph 1" },
      { requirementId: "p16_presence_confirmed", label: "Confirm presence", missingFields: [], tab: "intake", source: "Form P16 paragraph 2" },
    ])]);
    expect(screen.getAllByTestId("pre-generate-input-p16AlterationWords")).toHaveLength(1);
    expect(screen.getAllByTestId("pre-generate-input-p16DeponentPresentAtSigning")).toHaveLength(1);
    const alterationPair = screen.getByTestId("pre-generate-input-p16AlterationPage").closest("div.grid");
    expect(alterationPair?.className).toContain("grid-cols-1");
    expect(alterationPair?.className).toContain("sm:grid-cols-2");
    expect(screen.queryByTestId("pre-generate-jump-p16_alteration_description")).toBeNull();
  });

  it("persists a P17 direct estate correction canonically before re-check", async () => {
    const handlers = renderInline([gapReport("P17", [{
      requirementId: "p17_deceased_name",
      label: "Deceased's name (style of cause)",
      missingFields: ["estate.deceasedFirstName", "estate.deceasedLastName"],
      tab: "intake",
      source: "Form P17 template",
    }])]);

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P17 corrections");
    fireEvent.change(screen.getByTestId("pre-generate-input-deceasedFirstName"), { target: { value: "Riley" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith({ deceasedFirstName: "Riley" }, true, []));
  });

  it("persists the P26 foreign-grant date from its local editor to the canonical estate before re-check", async () => {
    const handlers = renderInline([gapReport("P26", [{
      requirementId: "p26_foreign_grant_issued_date",
      label: "Date the foreign grant was issued",
      missingFields: ["estate.foreignGrantIssuedDate"],
      tab: "intake",
      source: "Form P26 paragraph 1",
    }])]);

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P26 corrections");
    fireEvent.change(screen.getByTestId("pre-generate-p26-foreign-grant-date-input"), { target: { value: "2026-02-14" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      { estate: { foreignGrantIssuedDate: "2026-02-14" }, contacts: [], uploads: [] },
    ));
  });

  it("persists a P34 direct estate correction while hiding mixed citation evidence tracking", async () => {
    const handlers = renderInline([gapReport("P34", [
      {
        requirementId: "p34_deceased_name",
        label: "Deceased's name (style of cause)",
        missingFields: ["estate.deceasedFirstName", "estate.deceasedLastName"],
        tab: "intake",
        source: "Form P34 template",
      },
      {
        requirementId: "p34_service_date_and_route",
        label: "Personal-service date and a supported proof-of-service route",
        missingFields: [],
        tab: "forms",
        source: "SCCR Rule 25-11(1) and (4); Form P34 paragraph 2",
      },
    ])]);

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P34 corrections");
    expect(screen.queryByTestId("pre-generate-gap-p34_service_date_and_route")).toBeNull();
    fireEvent.change(screen.getByTestId("pre-generate-input-deceasedFirstName"), { target: { value: "Morgan" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith({ deceasedFirstName: "Morgan" }, true, []));
  });

  it("creates P44's withdrawing applicant as a canonical contact before re-check", async () => {
    const handlers = renderInline([gapReport("P44", [{
      requirementId: "p44_applicant_contact",
      label: "Applying applicant contact (withdrawing applicant)",
      missingFields: [],
      tab: "contacts",
      source: "SCCR Rule 25-3.2(1)",
    }])]);

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P44 corrections");
    const applicantEditor = screen.getByTestId("pre-generate-p1-applicant-create");
    const applicantName = applicantEditor.querySelector("input");
    const applicantAddress = applicantEditor.querySelector("textarea");
    if (!applicantName || !applicantAddress) throw new Error("P44 applicant editor controls are unavailable");
    fireEvent.change(applicantName, { target: { value: "Alex Applicant" } });
    fireEvent.change(applicantAddress, { target: { value: "10 Cedar Street" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      { estate: {}, contacts: [{ mode: "createApplicant", name: "Alex Applicant", residentialAddress: "10 Cedar Street" }], uploads: [] },
    ));
  });

  it("keeps P44 signature timing while hiding prior-filing workflow history", () => {
    renderInline([gapReport("P44", [
      {
        requirementId: "p44_application_filed",
        label: "Application filing recorded",
        missingFields: ["estate.p2FiledDate"],
        tab: "intake",
        source: "SCCR Rule 25-3.2(1)",
      },
      {
        requirementId: "p44_signature_date",
        label: "Date the applicant or lawyer signs Form P44",
        missingFields: ["renderContext.signatureDate"],
        tab: "forms",
        source: "Form P44",
      },
    ])]);

    expect(screen.queryByTestId("pre-generate-editor-p2FiledDate")).toBeNull();
    expect(screen.queryByTestId("pre-generate-gap-p44_application_filed")).toBeNull();
    expect(screen.getByTestId("pre-generate-jump-p44_signature_date").textContent).toContain("Go to Forms");
  });

  it("hides P45's electronic-will workflow axes because they do not populate P45", () => {
    renderInline([gapReport("P45", [{
      requirementId: "p45_electronic_will_format",
      label: "Answer the electronic-will questions",
      missingFields: ["estate.electronicWillFirstSavedPdf", "estate.electronicWillInRepository"],
      tab: "intake",
      source: "SCCR Rule 25-3(3)(a.1)",
    }])]);

    expect(screen.queryByTestId("pre-generate-gap-p45_electronic_will_format")).toBeNull();
    expect(screen.queryByTestId("pre-generate-p45-electronic-will-format")).toBeNull();
  });

  it("requires P45's sworn lock-status selection before a Generate anyway request can leave the dialog", () => {
    const onProceed = vi.fn();
    renderInline([gapReport("P45", [{
      requirementId: "p45_electronic_will_locked",
      label: "Whether the electronic will was locked",
      missingFields: ["estate.electronicWillLocked"],
      tab: "intake",
      source: "SCCR Rule 25-3(3)(a.1)",
    }])], { onProceed });

    expect(screen.getByTestId("pre-generate-p45-lock-status-required").textContent)
      .toContain("Select whether the electronic will was locked");
    const proceed = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
    expect(proceed.disabled).toBe(true);
    expect(proceed.textContent).toBe("Select lock status to continue");
    fireEvent.click(proceed);
    expect(onProceed).not.toHaveBeenCalled();
  });

  it("keeps P45's jurat date as a truthful workflow gate", () => {
    renderInline([gapReport("P45", [{
      requirementId: "p45_signature_date",
      label: "Date the deponent swears or affirms Form P45",
      missingFields: ["renderContext.signatureDate"],
      tab: "forms",
      source: "Form P45 template (jurat)",
    }])]);

    expect(screen.getByTestId("pre-generate-jump-p45_signature_date").textContent).toContain("Go to Forms");
  });

  it("creates P46's primary applying applicant as a canonical contact before re-check", async () => {
    const handlers = renderInline([gapReport("P46", [{
      requirementId: "p46_applicant_contact",
      label: "Named primary applying applicant (recipient of the demand)",
      missingFields: [],
      tab: "contacts",
      source: "Form P46 face; SCCR Rule 25-2(1.1)",
    }])]);

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P46 corrections");
    const applicantEditor = screen.getByTestId("pre-generate-p1-applicant-create");
    const applicantName = applicantEditor.querySelector("input");
    const applicantAddress = applicantEditor.querySelector("textarea");
    if (!applicantName || !applicantAddress) throw new Error("P46 applicant editor controls are unavailable");
    fireEvent.change(applicantName, { target: { value: "Drew Demand Recipient" } });
    fireEvent.change(applicantAddress, { target: { value: "12 Walnut Avenue" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      { estate: {}, contacts: [{ mode: "createApplicant", name: "Drew Demand Recipient", residentialAddress: "12 Walnut Avenue" }], uploads: [] },
    ));
  });

  it("keeps P46 demandant selection, demandant address, and signature date as workflow gates", () => {
    renderInline([gapReport("P46", [
      {
        requirementId: "p46_demandant",
        label: "Selected notice recipient demanding the electronic will",
        missingFields: ["selectedDelivery.recipientName", "selectedDelivery.isNoticeRecipient"],
        tab: "forms",
        source: "Form P46 face; SCCR Rule 25-2(1.1)",
      },
      {
        requirementId: "p46_demandant_address",
        label: "Selected notice recipient's address",
        missingFields: ["selectedDelivery.recipientAddress"],
        tab: "forms",
        source: "Form P46 face",
      },
      {
        requirementId: "p46_demand_date",
        label: "Date the notice recipient signs Form P46",
        missingFields: ["renderContext.signatureDate"],
        tab: "forms",
        source: "Form P46 face",
      },
    ])]);

    expect(screen.getByTestId("pre-generate-jump-p46_demandant").textContent).toContain("Go to Forms");
    expect(screen.getByTestId("pre-generate-jump-p46_demandant_address").textContent).toContain("Go to Forms");
    expect(screen.getByTestId("pre-generate-jump-p46_demand_date").textContent).toContain("Go to Forms");
  });

  it("persists VSA 532 applicant postal-address corrections to the canonical primary contact before re-check", async () => {
    const handlers = renderInline([gapReport("VSA532", [
      {
        requirementId: "vsa532_applicant_contact",
        label: "Applying contact name",
        missingFields: ["primaryApplicant.fullName"],
        tab: "contacts",
        source: "Form VSA 532 template",
      },
      {
        requirementId: "vsa532_applicant_postal",
        label: "Applying contact postal code",
        missingFields: ["primaryApplicant.postalCode"],
        tab: "contacts",
        source: "Form VSA 532 template",
      },
    ])], {
      contacts: [{ id: "vsa-applicant", name: "Casey Applicant", role: "applicant", executorStatus: "applying", postalAddress: "" }],
    });

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("VSA 532 corrections");
    fireEvent.change(screen.getByTestId("pre-generate-vsa532-applicant-postal"), { target: { value: "55 Coast Road, Victoria, BC V8V 1A1" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      { estate: {}, contacts: [{ mode: "update", id: "vsa-applicant", postalAddress: "55 Coast Road, Victoria, BC V8V 1A1" }], uploads: [] },
    ));
  });

  it("persists PGT_INFO recipient name and explicit detail-review confirmation canonically before re-check", async () => {
    const handlers = renderInline([gapReport("PGT_INFO", [
      {
        requirementId: "pgt_info_recipient_names",
        label: "Every P1 notice recipient has a name",
        missingFields: [],
        tab: "contacts",
        source: "SCCR Rule 25-2(13)(a)",
      },
      {
        requirementId: "pgt_info_recipient_details_reviewed",
        label: "Confirm the most recent known residential, postal, e-mail and fax details for every listed person",
        missingFields: [],
        tab: "contacts",
        source: "SCCR Rule 25-2(13)(b)(i)-(iv)",
      },
    ])], {
      contacts: [{ id: "pgt-recipient", name: "", role: "beneficiary", recipientType: "beneficiary", pgtInfoReviewed: 0 }],
    });

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("PGT_INFO corrections");
    fireEvent.change(screen.getByTestId("pre-generate-pgt-info-name-pgt-recipient"), { target: { value: "Robin Recipient" } });
    fireEvent.click(screen.getByTestId("pre-generate-pgt-info-reviewed-pgt-recipient"));
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      { estate: {}, contacts: [{ mode: "update", id: "pgt-recipient", name: "Robin Recipient", pgtInfoReviewed: true }], uploads: [] },
    ));
  });
});

// RULES.md Rule 24 (Nick, 2026-08-17): inline doc receipts + the na escape hatch.
describe("Rule 24 — inline required-document receipts", () => {
  it("renders a Mark-received checkbox for a requiredDocuments accessor and rides Apply's third argument", () => {
    const handlers = renderInline([gapReport("P3", [{
      requirementId: "p3_death_certificate_source",
      label: "Death certificate received",
      missingFields: ["requiredDocuments[docKey=death_certificate].received"],
      tab: "readiness",
      source: "SCCR Rule 25-3(2)",
    }])]);

    const box = screen.getByTestId("pre-generate-doc-death_certificate");
    expect(box.getAttribute("data-state")).toBe("unchecked");
    // A doc-only gap must still offer Apply once the box is ticked.
    expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(true);
    fireEvent.click(box);
    expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    expect(handlers.onApplyInline).toHaveBeenCalledWith({}, true, ["death_certificate"]);
  });
});

describe("Rule 24 — the not-applicable hard block is never a dead end on single forms", () => {
  const naBlockedReport = () => gapReport("P13", [{
    requirementId: "p13_applicability",
    label: "P13 is not applicable",
    missingFields: [],
    tab: "intake",
    source: "formStatus()",
    blocker: "hard",
  } as any], { hardBlocked: true, notApplicable: true } as any);

  it("offers Answer & generate anyway when the parent supplies the override handler", () => {
    const onOverrideNotApplicable = vi.fn();
    renderInline([naBlockedReport()], { onOverrideNotApplicable });
    const btn = screen.getByTestId("pre-generate-override-na");
    expect(btn.textContent).toMatch(/Answer & generate anyway/);
    expect(screen.queryByTestId("pre-generate-proceed")).toBeNull();
    fireEvent.click(btn);
    expect(onOverrideNotApplicable).toHaveBeenCalledTimes(1);
  });

  it("keeps the disabled Blocked button when no handler is supplied (package/bulk shape)", () => {
    renderInline([naBlockedReport()]);
    expect(screen.queryByTestId("pre-generate-override-na")).toBeNull();
    const proceed = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
    expect(proceed.disabled).toBe(true);
    expect(proceed.textContent).toBe("Blocked");
  });

  it("titles a soft not-applicable report truthfully (produced via generate-anyway)", () => {
    renderInline([gapReport("P13", [], { notApplicable: true } as any)]);
    expect(screen.getByText(/P1 — Notice is not applicable — producing anyway/)).toBeTruthy();
  });

  it("does not let a hidden P2 filing workflow gap block a not-applicable draft", () => {
    const onOverrideNotApplicable = vi.fn();
    renderInline([gapReport("P2", [
      {
        requirementId: "p2_applicability",
        label: "P2 is not applicable",
        missingFields: [],
        tab: "intake",
        source: "formStatus()",
        blocker: "hard",
      } as any,
      {
        requirementId: "p2_ancillary_filing_attachments",
        label: "Certified filing copies incomplete",
        missingFields: [],
        tab: "intake",
        source: "SCCR Rule 25-3(3)",
        blocker: "hard",
      } as any,
    ], { hardBlocked: true, notApplicable: true } as any)], { onOverrideNotApplicable });
    expect(screen.queryByTestId("pre-generate-override-na")).toBeNull();
    const proceed = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
    expect(proceed.disabled).toBe(false);
    expect(proceed.textContent).toBe("Generate");
  });
});

describe("the proceed button is untouched by inline fill", () => {
  it("still offers Generate anyway on soft gaps with editors present", () => {
    const handlers = renderInline([gapReport("P1", [{
      requirementId: "p1_deceased_name",
      label: "Deceased's full name",
      missingFields: ["estate.deceasedFirstName"],
      tab: "intake",
      source: "SCCR Rule 25-2(3)(a)",
    }])]);
    const proceed = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
    expect(proceed.textContent).toContain("anyway");
    expect(proceed.disabled).toBe(false);
    fireEvent.click(proceed);
    expect(handlers.onProceed).toHaveBeenCalled();
  });
});

describe("re-check shrinks the list in place", () => {
  it("a cleared gap disappears on report refresh while the dialog stays open", () => {
    const gapA = {
      requirementId: "p1_deceased_name",
      label: "Deceased's full name",
      missingFields: ["estate.deceasedFirstName"],
      tab: "intake" as const,
      source: "SCCR Rule 25-2(3)(a)",
    };
    const gapB = {
      requirementId: "p1_registry",
      label: "Court registry",
      missingFields: ["estate.registry"],
      tab: "intake" as const,
      source: "SCCR Rule 25-2(3)(e)",
    };
    const handlers = {
      onOpenChange: vi.fn(), onProceed: vi.fn(), onJumpToTab: vi.fn(), onCancel: vi.fn(), onApplyInline: vi.fn(),
    };
    const estate = { deceasedFirstName: "", registry: "" };
    const { rerender } = render(
      <PreGenerateDialog open formName="P1 — Notice" reports={[gapReport("P1", [gapA, gapB])]}
        estate={estate} inlineEditingEnabled {...handlers} />,
    );
    expect(screen.getByTestId("pre-generate-editor-deceasedFirstName")).toBeTruthy();
    expect(screen.getByTestId("pre-generate-gap-p1_registry")).toBeTruthy();

    // Parent re-ran the gap check with the typed value merged into overrides;
    // the name gap cleared, the registry gap remains, dialog never closed.
    rerender(
      <PreGenerateDialog open formName="P1 — Notice" reports={[gapReport("P1", [gapB])]}
        estate={estate} inlineEditingEnabled {...handlers} />,
    );
    expect(screen.queryByTestId("pre-generate-gap-p1_deceased_name")).toBeNull();
    expect(screen.getByTestId("pre-generate-gap-p1_registry")).toBeTruthy();
    cleanup();
  });

  it("crossfades the loading stage into the success stage instead of replacing it abruptly", async () => {
    const handlers = { onOpenChange: vi.fn(), onProceed: vi.fn(), onJumpToTab: vi.fn(), onCancel: vi.fn() };
    const { rerender } = render(
      <PreGenerateDialog open formName="P1 — Notice" reports={[makeReport([])]} proceeding {...handlers} />,
    );

    const loading = screen.getByTestId("pre-generate-loading");
    const success = screen.getByTestId("pre-generate-success");
    expect(loading.className).toContain("pre-generate-stage-enter");
    expect(success.className).toContain("pre-generate-stage-exit");

    rerender(
      <PreGenerateDialog open formName="P1 — Notice" reports={[makeReport([])]} succeeded {...handlers} />,
    );

    await waitFor(() => {
      expect(screen.getByTestId("pre-generate-loading").className).toContain("pre-generate-stage-exit");
      expect(screen.getByTestId("pre-generate-success").className).toContain("pre-generate-stage-enter");
    });
    expect(screen.getByTestId("pre-generate-success").querySelector(".pre-generate-success-icon")).toBeTruthy();
    cleanup();
  });

  it("provides action-specific context when the success checkmark receives focus", async () => {
    const handlers = { onOpenChange: vi.fn(), onProceed: vi.fn(), onJumpToTab: vi.fn(), onCancel: vi.fn() };
    // Radix Tooltip measures its content. Browsers provide ResizeObserver, but
    // jsdom does not, so supply the narrow no-op contract this test needs.
    vi.stubGlobal("ResizeObserver", class {
      observe() {}
      unobserve() {}
      disconnect() {}
    });
    try {
      render(
        <PreGenerateDialog open formName="P1 — Notice" reports={[makeReport([])]} succeeded {...handlers} />,
      );

      const trigger = await screen.findByTestId("pre-generate-success-tooltip-trigger");
      fireEvent.focus(trigger);
      expect(trigger.getAttribute("aria-label")).toBe("Document generated");
      await waitFor(() => {
        expect(
          screen.getAllByRole("tooltip").some((tooltip) =>
            tooltip.textContent?.includes("The document was generated and is ready to review.")),
        ).toBe(true);
      });
    } finally {
      cleanup();
      vi.unstubAllGlobals();
    }
  });

  it("keeps the success state visible for three seconds before closing the dialog", async () => {
    const onCancel = vi.fn();
    vi.useFakeTimers();
    vi.stubGlobal("ResizeObserver", class {
      observe() {}
      unobserve() {}
      disconnect() {}
    });
    try {
      render(
        <PreGenerateDialog
          open
          formName="P1 — Notice"
          reports={[makeReport([])]}
          succeeded
          onOpenChange={() => {}}
          onProceed={() => {}}
          onJumpToTab={() => {}}
          onCancel={onCancel}
        />,
      );

      await act(async () => {
        await vi.advanceTimersByTimeAsync(2999);
      });
      expect(onCancel).not.toHaveBeenCalled();

      await act(async () => {
        await vi.advanceTimersByTimeAsync(1);
      });
      expect(onCancel).toHaveBeenCalledTimes(1);
    } finally {
      cleanup();
      vi.useRealTimers();
      vi.unstubAllGlobals();
    }
  });
});

/**
 * Inline-fill wave 2 (Nick 2026-08-21): server-resolved GapEditor descriptors
 * render per-row contact/inventory editors whose values PERSIST on Apply (the
 * optional 4th onApplyInline argument), the quick-add mini form collects a
 * real inventory.create, and GAP_EDIT_HINTS expands predicate-only
 * confirmation gaps into their audited estate-column editors.
 *
 * Unlike the earlier inline tests, two of these DO drive a Radix Select: the
 * pointer-capture APIs jsdom lacks are stubbed per-test exactly the way
 * EstateDetail.inline-fill.test.tsx stubs them, which is enough for the
 * click-trigger → click-option idiom that file already relies on.
 */
function stubPointerPrereqs(): void {
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
}

/** One-contact-row gap (occupation text editor for row c1 "Jane Doe"). */
function contactRowGapReport(extra: Record<string, unknown> = {}): FormGapReport {
  return gapReport("P1", [{
    requirementId: "p1_contact_row",
    label: "Applicant occupation",
    missingFields: [],
    tab: "contacts",
    source: "Test requirement",
    editors: [{
      kind: "contact", id: "c1", rowLabel: "Jane Doe", column: "occupation",
      control: { control: "text", label: "Occupation" }, currentValue: "",
    }],
    ...extra,
  } as any]);
}

describe("row editors (inline-fill wave 2)", () => {
  it("renders a contact row group and sends the typed value as the 4th Apply argument", () => {
    const handlers = renderInline([contactRowGapReport()]);

    const group = screen.getByTestId("pre-generate-row-contact:c1");
    expect(group.textContent).toContain("Jane Doe");
    expect(screen.getByTestId("pre-generate-row-editor-contact-c1-occupation")).toBeTruthy();

    fireEvent.change(screen.getByTestId("pre-generate-row-input-contact-c1-occupation"), { target: { value: "Retired" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    expect(handlers.onApplyInline).toHaveBeenCalledWith({}, true, [], {
      contacts: [{ id: "c1", data: { occupation: "Retired" } }],
      inventory: [],
      createInventory: [],
    });
  });

  it("renders editors on a HARD gap: Apply arms after a selection while Proceed stays Blocked", async () => {
    stubPointerPrereqs();
    renderInline([gapReport("P10", [{
      requirementId: "p10_asset_passage",
      label: "Asset passage unanswered",
      missingFields: [],
      tab: "inventory",
      source: "SCCR Rule 25-3(2)",
      blocker: "hard",
      editors: [{
        kind: "inventory", id: "i1", rowLabel: "TD chequing",
        column: "passesToPersonalRepresentative",
        control: {
          control: "select", label: "Passes to the personal representative?",
          options: [{ value: "yes", label: "Yes" }, { value: "no", label: "No" }],
        },
        currentValue: "",
        category: "financial",
      }],
    }], { hardBlocked: true })]);

    // The hard-block description now names the cure when editors exist.
    expect(screen.getByText(/Fill the fields below and Apply & re-check to clear the block\./)).toBeTruthy();
    expect(screen.getByTestId("pre-generate-row-inventory:i1").textContent).toContain("TD chequing");

    const proceed = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
    expect(proceed.textContent).toBe("Blocked");
    expect(proceed.disabled).toBe(true);

    expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(true);
    fireEvent.click(screen.getByTestId("pre-generate-row-input-inventory-i1-passesToPersonalRepresentative"));
    fireEvent.click(await screen.findByText("Yes"));
    expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(false);

    // Selecting armed Apply but did NOT unlock Proceed — the hard block stands.
    const proceedAfter = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
    expect(proceedAfter.disabled).toBe(true);
    expect(proceedAfter.textContent).toBe("Blocked");
  });

  it("converts a currency row draft to cents WITHOUT a category rider (server reads stored category)", () => {
    const handlers = renderInline([gapReport("P10", [{
      requirementId: "p10_asset_value",
      label: "Asset value",
      missingFields: [],
      tab: "inventory",
      source: "SCCR Rule 25-3(2)",
      editors: [{
        kind: "inventory", id: "i2", rowLabel: "Household effects", column: "value",
        control: { control: "currency", label: "Value (dollars)" }, currentValue: "",
        category: "tangible",
      }],
    }])]);

    fireEvent.change(screen.getByTestId("pre-generate-row-input-inventory-i2-value"), { target: { value: "1,234.56" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    // 2026-08-21 review: no category rider — a preflight-time category
    // snapshot could revert a row reclassified in another tab mid-dialog;
    // inventory.update's value mirrors read the STORED category instead.
    expect(handlers.onApplyInline).toHaveBeenCalledWith({}, true, [], {
      contacts: [],
      inventory: [{ id: "i2", data: { value: 123456 } }],
      createInventory: [],
    });
  });

  it("keystroke-sanitizes currency input: '$500' records 50000 cents, never a fabricated $0", () => {
    const handlers = renderInline([gapReport("P10", [{
      requirementId: "p10_asset_value",
      label: "Asset value",
      missingFields: [],
      tab: "inventory",
      source: "SCCR Rule 25-3(2)",
      editors: [{
        kind: "inventory", id: "i2", rowLabel: "Household effects", column: "value",
        control: { control: "currency", label: "Value (dollars)" }, currentValue: "",
      }],
    }])]);

    const input = screen.getByTestId("pre-generate-row-input-inventory-i2-value") as HTMLInputElement;
    fireEvent.change(input, { target: { value: "$500" } });
    // formatCurrency strips the "$" in place — the user sees the cleaned value.
    expect(input.value).toBe("500");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    expect(handlers.onApplyInline).toHaveBeenCalledWith({}, true, [], {
      contacts: [],
      inventory: [{ id: "i2", data: { value: 50000 } }],
      createInventory: [],
    });
  });

  it("renders ONE quick-add card when several gaps carry the inventoryAdd descriptor", () => {
    renderInline([gapReport("P10", [
      {
        requirementId: "p10_at_least_one_asset", label: "At least one asset", missingFields: [],
        tab: "inventory", source: "s", editors: [{ kind: "inventoryAdd", rowLabel: "Add first asset" }],
      },
      {
        requirementId: "p10_passes_to_personal_representative", label: "Passage", missingFields: [],
        tab: "inventory", source: "s", blocker: "hard",
        editors: [{ kind: "inventoryAdd", rowLabel: "Add first asset" }],
      },
    ])]);
    // Several gaps can carry the descriptor but they share ONE addDraft and
    // one created row — a single card renders (first qualifying gap).
    expect(screen.getAllByTestId("pre-generate-inventory-add")).toHaveLength(1);
  });

  it("pure-garbage currency input collapses to an honest blank — Apply stays disarmed", () => {
    renderInline([gapReport("P10", [{
      requirementId: "p10_asset_value",
      label: "Asset value",
      missingFields: [],
      tab: "inventory",
      source: "SCCR Rule 25-3(2)",
      editors: [{
        kind: "inventory", id: "i2", rowLabel: "Household effects", column: "value",
        control: { control: "currency", label: "Value (dollars)" }, currentValue: "",
      }],
    }])]);

    const input = screen.getByTestId("pre-generate-row-input-inventory-i2-value") as HTMLInputElement;
    fireEvent.change(input, { target: { value: "abc" } });
    expect(input.value).toBe("");
    expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(true);
  });

  it("a mixed requirement keeps its uneditable residue on the Missing: line (per-accessor coverage)", () => {
    // secured].description gets a row editor; secured].securedAssetId is a
    // deliberate registry exclusion — it must STAY listed with Go-to as its
    // honest cure, never blanket-suppressed by the sibling editor.
    renderInline([gapReport("P10", [{
      requirementId: "p10_secured_liability_details",
      label: "Secured liability details",
      missingFields: [
        "inventory[all,category=liability,securityStatus=secured].description",
        "inventory[all,category=liability,securityStatus=secured].securedAssetId",
      ],
      tab: "inventory",
      source: "SCCR Rule 25-3(2)",
      editors: [{
        kind: "inventory", id: "l1", rowLabel: "Mortgage", column: "description",
        control: { control: "text", label: "Description" }, currentValue: "", category: "liability",
      }],
    }])]);
    const missing = screen.getByTestId("pre-generate-fields-p10_secured_liability_details");
    expect(missing.textContent).toContain("securedAssetId");
    expect(missing.textContent).not.toContain("].description");
  });

  it("a draft whose descriptor vanished mid-edit is NOT banked — a reappearing descriptor resends it", async () => {
    const editorGap = (withDescriptionEditor: boolean) => gapReport("P10", [{
      requirementId: "p10_row_facts",
      label: "Row facts",
      missingFields: [],
      tab: "inventory",
      source: "s",
      editors: [
        { kind: "contact" as const, id: "c1", rowLabel: "Jane", column: "occupation", control: { control: "text" as const, label: "Occupation" }, currentValue: "" },
        ...(withDescriptionEditor ? [{ kind: "inventory" as const, id: "i1", rowLabel: "TD", column: "description", control: { control: "text" as const, label: "Description" }, currentValue: "" }] : []),
      ],
    }]);
    const handlers = {
      onOpenChange: vi.fn(), onProceed: vi.fn(), onJumpToTab: vi.fn(), onCancel: vi.fn(), onApplyInline: vi.fn(),
    };
    const dialog = (reports: FormGapReport[]) => (
      <PreGenerateDialog open formName="P10" reports={reports} estate={{}} inlineEditingEnabled {...handlers} />
    );
    const { rerender } = render(dialog([editorGap(true)]));

    fireEvent.change(screen.getByTestId("pre-generate-row-input-contact-c1-occupation"), { target: { value: "Retired" } });
    fireEvent.change(screen.getByTestId("pre-generate-row-input-inventory-i1-description"), { target: { value: "TD chequing" } });

    // The description descriptor vanishes mid-edit (a re-check shrank the
    // report) — the apply sends only the contact value.
    rerender(dialog([editorGap(false)]));
    await act(async () => { fireEvent.click(screen.getByTestId("pre-generate-apply")); });
    expect(handlers.onApplyInline).toHaveBeenLastCalledWith({}, true, [], {
      contacts: [{ id: "c1", data: { occupation: "Retired" } }],
      inventory: [],
      createInventory: [],
    });

    // The descriptor reappears: the typed-but-never-sent description must
    // still count as a change and ride the next apply; the banked occupation
    // must NOT be resent.
    rerender(dialog([editorGap(true)]));
    await act(async () => { fireEvent.click(screen.getByTestId("pre-generate-apply")); });
    expect(handlers.onApplyInline).toHaveBeenLastCalledWith({}, true, [], {
      contacts: [],
      inventory: [{ id: "i1", data: { description: "TD chequing" } }],
      createInventory: [],
    });
  });

  it("quick-add arms Apply only once category+description exist and sends a complete createInventory row", async () => {
    stubPointerPrereqs();
    const handlers = renderInline([gapReport("P10", [{
      requirementId: "p10_at_least_one_asset",
      label: "At least one asset",
      missingFields: [],
      tab: "inventory",
      source: "SCCR Rule 25-3(2)",
      editors: [{ kind: "inventoryAdd", rowLabel: "Add first asset" }],
    }])]);

    expect(screen.getByTestId("pre-generate-inventory-add")).toBeTruthy();
    expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(true);

    // Category alone is not an honest CREATE…
    fireEvent.click(screen.getByTestId("pre-generate-add-category"));
    fireEvent.click(await screen.findByText("Financial Assets"));
    expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(true);

    // …category + description is.
    fireEvent.change(screen.getByTestId("pre-generate-add-description"), { target: { value: "TD account" } });
    expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(false);

    fireEvent.change(screen.getByTestId("pre-generate-add-value"), { target: { value: "100.00" } });
    fireEvent.click(screen.getByTestId("pre-generate-add-passesToPersonalRepresentative"));
    fireEvent.click(await screen.findByText("Yes"));
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    expect(handlers.onApplyInline).toHaveBeenCalledWith({}, true, [], {
      contacts: [],
      inventory: [],
      createInventory: [{
        // Idempotency id, stable across retries of the same draft (2026-08-21
        // goal loop) — the server replays it to the committed row.
        id: expect.stringMatching(/^[0-9a-f-]{36}$/),
        category: "financial",
        description: "TD account",
        location: "unknown",
        value: 10000,
        valueRecorded: 1,
        passesToPersonalRepresentative: "yes",
      }],
    });
  });

  it("expands a P4 GAP_EDIT_HINTS predicate-only gap into a canonical estate editor with no Missing line", () => {
    renderInline([gapReport("P4", [{
      requirementId: "p4_rule_25_3_6_execution_issues_unconfirmed",
      label: "Record whether any issue respecting execution of the will exists",
      missingFields: [],
      tab: "intake",
      source: "SCCR Rule 25-3(6)",
    }])]);

    const editor = screen.getByTestId("pre-generate-editor-executionIssues");
    expect(editor.querySelector('[role="combobox"]')).not.toBeNull();
    expect(screen.queryByTestId("pre-generate-fields-p4_rule_25_3_6_execution_issues_unconfirmed")).toBeNull();
    // P4's audited direct editor now persists to the canonical estate record
    // before re-check rather than becoming a document-only override.
    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-p1-canonical-save-note").textContent).toContain("P4 corrections");
    expect(screen.queryByTestId("pre-generate-row-save-note")).toBeNull();
  });

  it("row-only editors hide the save-to-intake checkbox and show the row-save caption instead", () => {
    renderInline([contactRowGapReport()]);

    expect(screen.queryByTestId("pre-generate-save-to-intake")).toBeNull();
    expect(screen.getByTestId("pre-generate-row-save-note")).toBeTruthy();
  });

  it("shows the '+N more' truncation note when the server capped a gap's editors", () => {
    renderInline([contactRowGapReport({ editorsTruncated: 5 })]);

    expect(screen.getByTestId("pre-generate-truncated-p1_contact_row").textContent).toContain("+5 more");
  });

  it("a confirmed apply banks the row value — a second Apply with nothing new typed is disabled", async () => {
    const onApplyInline = vi.fn().mockResolvedValue(true);
    renderInline([contactRowGapReport()], { onApplyInline });

    fireEvent.change(screen.getByTestId("pre-generate-row-input-contact-c1-occupation"), { target: { value: "Retired" } });
    expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    expect(onApplyInline).toHaveBeenCalledTimes(1);

    // The resolved-true apply banked the draft into the row seed — nothing is
    // "changed since", so a second Apply would only rewrite persisted rows.
    await act(async () => {});
    expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(true);
  });

  it("a FAILED apply (resolves false) keeps the typed row value pending — Apply stays armed and resends it", async () => {
    const onApplyInline = vi.fn().mockResolvedValue(false);
    renderInline([contactRowGapReport()], { onApplyInline });

    fireEvent.change(screen.getByTestId("pre-generate-row-input-contact-c1-occupation"), { target: { value: "Retired" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    expect(onApplyInline).toHaveBeenCalledTimes(1);
    await act(async () => {});

    // Not banked: the value still counts as pending, and a retry re-sends it.
    expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    expect(onApplyInline).toHaveBeenCalledTimes(2);
    expect(onApplyInline).toHaveBeenLastCalledWith({}, true, [], {
      contacts: [{ id: "c1", data: { occupation: "Retired" } }],
      inventory: [],
      createInventory: [],
    });
  });

  it("quick-add mints ONE idempotency id per draft — stable across failed-apply retries, fresh after a confirmed apply", async () => {
    // 2026-08-21 goal loop (F2): the id is what lets the server resolve a
    // replayed create to the already-committed row. It must therefore be the
    // SAME uuid on every retry of one draft (a failed apply keeps the draft
    // pending) and a NEW uuid once a confirmed apply clears the draft — a
    // reused id would swallow the next, genuinely different asset.
    stubPointerPrereqs();
    const quickAddGap = gapReport("P10", [{
      requirementId: "p10_at_least_one_asset",
      label: "At least one asset",
      missingFields: [],
      tab: "inventory",
      source: "SCCR Rule 25-3(2)",
      editors: [{ kind: "inventoryAdd", rowLabel: "Add first asset" }],
    }]);
    const onApplyInline = vi.fn()
      .mockResolvedValueOnce(false) // retry 1: create committed, re-check failed
      .mockResolvedValueOnce(false) // retry 2: still failing
      .mockResolvedValue(true);     // confirmed apply
    renderInline([quickAddGap], { onApplyInline });

    // The second draft picks a DIFFERENT category: the category Select's
    // controlled value becomes undefined after the reset, so Radix falls back
    // to its internal state (still the old value) and re-selecting the SAME
    // option fires no onValueChange in jsdom. A different option always fires.
    const fillDraft = async (categoryLabel: string, description: string) => {
      fireEvent.click(screen.getByTestId("pre-generate-add-category"));
      // Target the dropdown OPTION — the trigger can echo a previous
      // selection's text, which findAllByText would list first.
      const option = (await screen.findAllByText(categoryLabel))
        .find((el) => el.closest('[role="option"]') !== null)!;
      expect(option).toBeTruthy();
      fireEvent.click(option);
      fireEvent.change(screen.getByTestId("pre-generate-add-description"), { target: { value: description } });
    };
    const sentId = (call: number): string =>
      onApplyInline.mock.calls[call][3].createInventory[0].id;

    await fillDraft("Financial Assets", "TD account");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await act(async () => {});
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await act(async () => {});

    expect(onApplyInline).toHaveBeenCalledTimes(2);
    expect(sentId(0)).toMatch(/^[0-9a-f-]{36}$/);
    expect(sentId(1)).toBe(sentId(0)); // the retry replays the SAME id

    // Third apply is CONFIRMED (resolves true) → the draft and its id reset.
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await act(async () => {});
    expect(sentId(2)).toBe(sentId(0));

    // A fresh draft after the confirmed apply mints a DIFFERENT id.
    await fillDraft("Real Property", "Victoria land");
    expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await act(async () => {});
    expect(onApplyInline).toHaveBeenCalledTimes(4);
    expect(sentId(3)).toMatch(/^[0-9a-f-]{36}$/);
    expect(sentId(3)).not.toBe(sentId(0));
  });
});

describe("Nick 2026-09-02 estate-#18 re-audit — P2 answers and the late spouse are collectable inline", () => {
  it("renders the registered selects for the treaty and orders answers on their P2 gaps", () => {
    renderInline([gapReport("P2", [
      { requirementId: "p2_treaty_first_nation_answer", label: "Nisg̱a'a / treaty / neither", missingFields: ["estate.treatyFirstNation"], tab: "intake", source: "Form P2 Part 1" },
      { requirementId: "p2_orders_answer", label: "Orders affecting the will", missingFields: ["estate.ordersAffectingWill"], tab: "intake", source: "Form P2 Part 3 section 5" },
    ])]);
    expect(screen.getByTestId("pre-generate-editor-treatyFirstNation")).toBeTruthy();
    expect(screen.getByTestId("pre-generate-editor-ordersAffectingWill")).toBeTruthy();
  });

  it("the late-spouse gap offers the spouse creator and the action carries the predeceased flag", async () => {
    const handlers = renderInline([gapReport("P2", [{
      requirementId: "p2_late_spouse_contact",
      label: "Late spouse's name for Form P2 Schedule §2(a)",
      missingFields: [],
      tab: "contacts",
      source: "Form P2 Part 4 Schedule §2(a)",
    }])]);
    expect(screen.getByTestId("pre-generate-p1-spouse-create")).toBeTruthy();
    // The creator's inputs carry no per-field testids; the first input is Name.
    const creator = screen.getByTestId("pre-generate-p1-spouse-create");
    fireEvent.change(creator.querySelector("input")!, { target: { value: "Gerald Voss-Hartley" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(handlers.onApplyInline).toHaveBeenCalledWith(
      {}, true, [], undefined,
      { estate: {}, contacts: [{ mode: "createSpouse", name: "Gerald Voss-Hartley", residentialAddress: "", isPredeceased: 1 }], uploads: [] },
    ));
  });
});


describe("remaining-form content-only popup filtering", () => {
  const nonContentCases = [
    ["P11", "p11_will_status_required"],
    ["P12", "p12_will_language_check"],
    ["P14", "p14_supplemental_provenance"],
    ["P15", "p15_applicability"],
    ["P16", "p16_presence_confirmed"],
    ["P17", "p17_grant_type_required"],
    ["P26", "p26_has_supplemental_disclosure"],
    ["P34", "p34_citation_exhibit"],
    ["P44", "p44_application_filed"],
    ["P45", "p45_repo_address"],
    ["P46", "p46_grant_will_consistency"],
    ["VSA532", "vsa532_applicability"],
    ["PGT_INFO", "pgt_info_notify_pgt_flag"],
  ] as const;

  it("removes one audited non-content completion row from every remaining form", () => {
    const onProceed = vi.fn();
    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="Remaining form package"
        reports={nonContentCases.map(([formCode, requirementId]) => ({
          formCode,
          ok: false,
          hardBlocked: true,
          gaps: [{
            requirementId,
            label: `${formCode} operational record`,
            missingFields: [],
            tab: "intake" as const,
            source: "Operational requirement",
            blocker: "hard" as const,
          }],
        }))}
        onProceed={onProceed}
        onJumpToTab={() => {}}
        onCancel={() => {}}
      />,
    );

    for (const [, requirementId] of nonContentCases) {
      expect(screen.queryByTestId(`pre-generate-gap-${requirementId}`)).toBeNull();
    }
    const proceed = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
    expect(proceed.disabled).toBe(false);
    fireEvent.click(proceed);
    expect(onProceed).toHaveBeenCalledWith({ generateAnyway: true });
  });

  it("retains a direct P45 official alternative while hiding P45 workflow axes", () => {
    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="P45 Affidavit of Electronic Will"
        reports={[{
          formCode: "P45",
          ok: false,
          hardBlocked: true,
          gaps: [
            {
              requirementId: "p45_electronic_will_locked",
              label: "Electronic will lock status",
              missingFields: ["estate.electronicWillLocked"],
              tab: "intake",
              source: "Form P45 paragraph 2",
              blocker: "hard",
            },
            {
              requirementId: "p45_electronic_will_format",
              label: "Electronic-will record",
              missingFields: ["estate.electronicWillFirstSavedPdf"],
              tab: "intake",
              source: "Electronic-will workflow",
              blocker: "hard",
            },
          ],
        }]}
        onProceed={() => {}}
        onJumpToTab={() => {}}
        onCancel={() => {}}
      />,
    );

    expect(screen.getByTestId("pre-generate-gap-p45_electronic_will_locked")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-gap-p45_electronic_will_format")).toBeNull();
    expect(screen.queryByTestId("pre-generate-p45-electronic-will-format")).toBeNull();
  });

  it("retains PGT review confirmation but hides committee readiness administration", () => {
    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="PGT information"
        reports={[{
          formCode: "PGT_INFO",
          ok: false,
          gaps: [
            {
              requirementId: "pgt_info_recipient_details_reviewed",
              label: "Recipient details reviewed",
              missingFields: [],
              tab: "contacts",
              source: "PGT information form",
            },
            {
              requirementId: "readiness:committee_contact-1",
              label: "Committee record incomplete",
              missingFields: [],
              tab: "contacts",
              source: "Delivery readiness",
              blocker: "hard",
            },
          ],
        }]}
        onProceed={() => {}}
        onJumpToTab={() => {}}
        onCancel={() => {}}
      />,
    );

    expect(screen.getByTestId("pre-generate-gap-pgt_info_recipient_details_reviewed")).toBeTruthy();
    expect(screen.queryByTestId("pre-generate-gap-readiness:committee_contact-1")).toBeNull();
  });
});
