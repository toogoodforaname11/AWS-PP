import { render, screen } from "@testing-library/react";
import React from "react";
import { describe, expect, it } from "vitest";
import { CodicilFactsCard } from "./CodicilExtractionFacts";

describe("CodicilFactsCard", () => {
  it("renders source-grounded document facts with an explicit original-document review reminder", () => {
    render(<CodicilFactsCard details={{
      documentDate: "2025-01-11",
      testatorName: "Alex Morgan",
      neutralSummary: "The document identifies itself as a codicil.",
      apparentChanges: ["It states an amendment to an executor appointment."],
      sourceExcerpts: [{ label: "Stated date", excerpt: "Dated January 11, 2025" }],
    }} />);
    expect(screen.getByTestId("codicil-facts-card").textContent).toContain("AI document facts — review original");
    expect(screen.getByText("Alex Morgan")).toBeTruthy();
    expect(screen.getByText(/Dated January 11, 2025/)).toBeTruthy();
  });

  it("does not show an empty card when the document contains no verified extractable facts", () => {
    const { container } = render(<CodicilFactsCard details={{ documentDate: null, testatorName: null, neutralSummary: null, apparentChanges: [], sourceExcerpts: [] }} />);
    expect(container.firstChild).toBeNull();
  });
});
