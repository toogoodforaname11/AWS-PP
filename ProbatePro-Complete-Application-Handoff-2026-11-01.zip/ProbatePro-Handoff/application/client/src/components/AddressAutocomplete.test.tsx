/**
 * AddressAutocomplete wiring tests (UAT A4, 2026-07-12).
 *
 * The component fetches suggestions through the server's maps proxy
 * (trpc maps.autocomplete / maps.placeDetails) — the old client-side Google
 * Maps JS loader depended on a VITE_ build-time key that no deployment sets,
 * so autocomplete silently never worked. These tests drive the real component
 * through the trpc boundary: type → suggestions → select → parsed components
 * delivered to onSelect.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";
import React from "react";
import { render, screen, fireEvent, waitFor, act } from "@testing-library/react";

const mocks = vi.hoisted(() => ({
  autocompleteFetch: vi.fn(),
  placeDetailsFetch: vi.fn(),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    useUtils: () => ({
      maps: {
        autocomplete: { fetch: mocks.autocompleteFetch },
        placeDetails: { fetch: mocks.placeDetailsFetch },
      },
    }),
  },
}));

import { AddressAutocomplete } from "./AddressAutocomplete";

const SUGGESTION = {
  placeId: "place-1",
  description: "1450 West Georgia St, Vancouver, BC, Canada",
  mainText: "1450 West Georgia St",
  secondaryText: "Vancouver, BC, Canada",
};

const DETAILS = {
  details: {
    formattedAddress: "1450 West Georgia St, Vancouver, BC V6G 2T8, Canada",
    addressComponents: [
      { long_name: "1450", short_name: "1450", types: ["street_number"] },
      { long_name: "West Georgia Street", short_name: "W Georgia St", types: ["route"] },
      { long_name: "Vancouver", short_name: "Vancouver", types: ["locality", "political"] },
      { long_name: "British Columbia", short_name: "BC", types: ["administrative_area_level_1", "political"] },
      { long_name: "V6G 2T8", short_name: "V6G 2T8", types: ["postal_code"] },
      { long_name: "Canada", short_name: "CA", types: ["country", "political"] },
    ],
  },
};

function Harness({ onSelect }: { onSelect?: (c: any) => void }) {
  const [value, setValue] = React.useState("");
  return <AddressAutocomplete value={value} onChange={setValue} onSelect={onSelect} placeholder="addr" />;
}

describe("AddressAutocomplete (server-proxied suggestions)", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("fetches suggestions through trpc after typing and shows them", async () => {
    mocks.autocompleteFetch.mockResolvedValue({ suggestions: [SUGGESTION] });
    render(<Harness />);

    fireEvent.change(screen.getByPlaceholderText("addr"), { target: { value: "1450 West" } });

    await waitFor(() => {
      expect(mocks.autocompleteFetch).toHaveBeenCalledWith({ input: "1450 West" });
    }, { timeout: 2000 });
    await waitFor(() => {
      expect(screen.getByText("1450 West Georgia St")).toBeTruthy();
    });
  });

  it("selecting a suggestion fetches details and delivers parsed components to onSelect", async () => {
    mocks.autocompleteFetch.mockResolvedValue({ suggestions: [SUGGESTION] });
    mocks.placeDetailsFetch.mockResolvedValue(DETAILS);
    const onSelect = vi.fn();
    render(<Harness onSelect={onSelect} />);

    fireEvent.change(screen.getByPlaceholderText("addr"), { target: { value: "1450 West" } });
    await waitFor(() => expect(screen.getByText("1450 West Georgia St")).toBeTruthy(), { timeout: 2000 });

    fireEvent.mouseDown(screen.getByText("1450 West Georgia St"));

    await waitFor(() => {
      expect(mocks.placeDetailsFetch).toHaveBeenCalledWith({ placeId: "place-1" });
      expect(onSelect).toHaveBeenCalledWith(expect.objectContaining({
        street: "1450 West Georgia Street",
        city: "Vancouver",
        province: "BC",
        postalCode: "V6G 2T8",
        country: "Canada",
        fullAddress: "1450 West Georgia St, Vancouver, BC V6G 2T8, Canada",
      }));
    }, { timeout: 2000 });
    // The visible input keeps the street main text
    expect((screen.getByPlaceholderText("addr") as HTMLInputElement).value).toBe("1450 West Georgia St");
  });

  it("degrades gracefully when the suggestion fetch fails (manual typing still works)", async () => {
    mocks.autocompleteFetch.mockRejectedValue(new Error("proxy unavailable"));
    render(<Harness />);

    const input = screen.getByPlaceholderText("addr") as HTMLInputElement;
    fireEvent.change(input, { target: { value: "123 Manual Street" } });

    await waitFor(() => expect(mocks.autocompleteFetch).toHaveBeenCalled(), { timeout: 2000 });
    // No suggestion list, no crash; typed value preserved
    expect(input.value).toBe("123 Manual Street");
    expect(screen.queryByRole("button")).toBeNull();
  });

  it("does not search for fewer than 3 characters", async () => {
    render(<Harness />);
    await act(async () => {
      fireEvent.change(screen.getByPlaceholderText("addr"), { target: { value: "12" } });
      await new Promise(r => setTimeout(r, 450));
    });
    expect(mocks.autocompleteFetch).not.toHaveBeenCalled();
  });
});
