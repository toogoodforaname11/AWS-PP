/**
 * DO-NOT-SHIP finding #16: P8 candidates must exclude the ranked primary,
 * independent of contact-array order.  This preserves the current N-1 applicant
 * set and does not resolve the separate AWAITING-NICK lawyer-primary question.
 */
import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  estateUpdate: vi.fn(),
  estateUpdateAsync: vi.fn().mockResolvedValue({ success: true }),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    estate: {
      update: {
        useMutation: () => ({
          mutate: mocks.estateUpdate,
          mutateAsync: mocks.estateUpdateAsync,
          isPending: false,
        }),
      },
    },
    document: {
      preflight: { useQuery: () => ({ data: { formCode: "P8", ok: true, gaps: [] } }) },
    },
    delivery: {
      list: { useQuery: () => ({ data: [] }) },
      getRecipients: { useQuery: () => ({ data: [] }) },
      upsert: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
      delete: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
      bulkCreate: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
    },
    settings: { get: { useQuery: () => ({ data: { lawyerName: "Settings Lawyer" } }) } },
    useUtils: () => ({
      estate: { get: { invalidate: vi.fn() } },
      readiness: { check: { invalidate: vi.fn() } },
      document: { preflight: { invalidate: vi.fn() } },
      delivery: { list: { invalidate: vi.fn(), setData: vi.fn() } },
    }),
  },
}));

import { FormDetailsDialog } from "./FormDetailsDialog";

const outOfOrderApplyingContacts = [
  { id: "coapp-first", name: "Co Applicant First", role: "applicant,executor", executorStatus: "applying", executorRank: "alternate" },
  { id: "ranked-primary", name: "Ranked Primary", role: "applicant,executor", executorStatus: "applying", executorRank: "primary" },
  { id: "coapp-third", name: "Co Applicant Third", role: "applicant,executor", executorStatus: "applying", executorRank: "alternate" },
  { id: "renounced", name: "Renounced", role: "executor", executorStatus: "renounced", executorRank: "alternate" },
];

describe("P8 ranked-primary resolver", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("defaults to a genuine co-applicant when the ranked primary is not first", async () => {
    const onGenerate = vi.fn();
    render(
      <FormDetailsDialog
        open={true}
        onOpenChange={() => {}}
        formCode="P8"
        formName="Affidavit in Support of Application for Estate Grant"
        estateId="estate-p8-order"
        estate={{ id: "estate-p8-order", oathType: "affirmed" } as any}
        contacts={outOfOrderApplyingContacts as any}
        signatoryType="executor"
        onSignatoryTypeChange={() => {}}
        signatureDate="2026-07-13"
        onSignatureDateChange={() => {}}
        onGenerate={onGenerate}
        onPreview={() => {}}
        onCancel={() => {}}
      />,
    );

    await waitFor(() => expect(screen.getByTestId("form-details-generate")).toBeTruthy());
    fireEvent.click(screen.getByTestId("form-details-generate"));

    await waitFor(() => {
      expect(onGenerate).toHaveBeenCalledWith({ deponentId: "coapp-first" });
    });
    expect(onGenerate).not.toHaveBeenCalledWith({ deponentId: "ranked-primary" });
    expect(onGenerate).not.toHaveBeenCalledWith({ deponentId: "renounced" });
  });
});
