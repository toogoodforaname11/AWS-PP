import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { PreGenerateDialog, type PreGenerateDialogProps } from "./PreGenerateDialog";
import type { FormGap } from "../../../shared/formRequirements";

const baseEstate = {
  id: "popup-fictional-estate", revision: 3, willStatus: "unknown", hasWill: 1,
  willType: "physical", willFilingType: "physical_original", deceasedFirstName: "",
};
function gap(id: string, field: string, label = field): FormGap {
  return { requirementId: id, label, missingFields: [`estate.${field}`], tab: "intake", source: "Existing Intake fact" };
}
function mount(formCode: string, gaps: FormGap[], extras: Partial<PreGenerateDialogProps> = {}) {
  const onApplyInline = vi.fn().mockResolvedValue(true);
  const onProceed = vi.fn();
  const onJumpToTab = vi.fn();
  const props = {
    open: true, formName: formCode, reports: [{ formCode, ok: false, gaps }],
    onOpenChange: vi.fn(), onCancel: vi.fn(), onJumpToTab, onProceed, onApplyInline,
    estate: baseEstate, contacts: [], inlineEditingEnabled: true, ...extras,
  } satisfies PreGenerateDialogProps;
  const view = render(<PreGenerateDialog {...props} />);
  return { ...view, onApplyInline: props.onApplyInline as ReturnType<typeof vi.fn>, onProceed, onJumpToTab };
}
const input = (column: string) => screen.getByTestId(`pre-generate-canonical-${column}`);
async function choose(column: string, label: string) {
  fireEvent.click(input(column));
  fireEvent.click(await screen.findByRole("option", { name: label }));
}
function canonicalPayload(handler: ReturnType<typeof vi.fn>) {
  expect(handler).toHaveBeenCalledTimes(1);
  return handler.mock.calls[0][5];
}
beforeEach(() => {
  cleanup();
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
});
afterEach(cleanup);

describe("single-form canonical missing fields", () => {
  it("collects an explicit P5 no-will answer and applies both canonical axes before proceeding", async () => {
    const h = mount("P5", [gap("p5_will_status_required", "willStatus")]);
    expect(screen.queryByTestId("pre-generate-jump-p5_will_status_required")).toBeNull();
    await choose("willStatus", "No will");
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(h.onProceed).toHaveBeenCalledTimes(1));
    expect(canonicalPayload(h.onApplyInline)).toEqual({ willStatus: "no_will", hasWill: 0 });
    expect(h.onApplyInline.mock.calls[0][0]).toEqual({});
    expect(h.onApplyInline.mock.invocationCallOrder[0]).toBeLessThan(h.onProceed.mock.invocationCallOrder[0]);
    expect(h.onJumpToTab).not.toHaveBeenCalled();
  });

  it("leaves unknown will status unconfirmed and still permits a warned draft with nothing typed", () => {
    const h = mount("P5", [gap("p5_will_status_required", "willStatus")]);
    expect(input("willStatus").textContent).toContain("Not confirmed");
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    expect(h.onApplyInline).not.toHaveBeenCalled();
    expect(h.onProceed).toHaveBeenCalledWith({ generateAnyway: true });
  });

  const textCases = [
    ["P2", "p2_referenced_documents", "referencedDocumentNames", { referencedDocuments: "filed" }],
    ["P2", "p2_referenced_documents_cannot_obtain", "referencedDocumentsCannotObtainReason", { referencedDocuments: "cannot_be_obtained" }],
    ["P2", "p2_referenced_documents_not_testamentary", "referencedDocumentsNotTestamentary", { referencedDocuments: "not_testamentary" }],
    ["P2", "p2_treaty_first_nation_name", "treatyFirstNationName", {}],
    ["P4", "p4_appearance_other_specify", "appearanceIssueOther", { willAlterationTypes: "appearance", appearanceIssueTypes: "other" }],
    ["P4", "p4_military_will_description", "militaryWillDescription", { isMilitaryWill: "yes" }],
    ["P4", "p4_foreign_will_affidavit_name", "foreignWillAffidavitName", { foreignWillStatus: "foreign_non_compliant" }],
    ["P4", "p4_electronic_original_unavailable_reason", "electronicOriginalUnavailableReason", { electronicWillFormat: "original_unavailable", electronicOriginalUnavailableKnowledge: "first_hand" }],
  ] as const;
  for (const [form, id, column, initial] of textCases) {
    it(`${form} ${column}: retains text and saves it through the canonical channel, not a fake override`, async () => {
      const h = mount(form, [gap(id, column)], { estate: { ...baseEstate, ...initial } });
      expect(screen.queryByTestId(`pre-generate-jump-${id}`)).toBeNull();
      fireEvent.change(input(column), { target: { value: "Fictional detail entered in this popup" } });
      fireEvent.click(screen.getByTestId("pre-generate-apply"));
      await waitFor(() => expect(h.onApplyInline).toHaveBeenCalledTimes(1));
      expect(canonicalPayload(h.onApplyInline)).toEqual({ [column]: "Fictional detail entered in this popup" });
      expect(h.onApplyInline.mock.calls[0][0]).toEqual({});
      await waitFor(() => expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(true));
    });
  }

  it("uses a date control for the existing foreign-will supporting affidavit date", async () => {
    const h = mount("P4", [gap("p4_foreign_will_affidavit_date", "foreignWillAffidavitDate")], { estate: { ...baseEstate, foreignWillStatus: "foreign_non_compliant" } });
    expect(input("foreignWillAffidavitDate").getAttribute("type")).toBe("date");
    fireEvent.change(input("foreignWillAffidavitDate"), { target: { value: "2026-10-15" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.onApplyInline).toHaveBeenCalledTimes(1));
    expect(canonicalPayload(h.onApplyInline)).toEqual({ foreignWillAffidavitDate: "2026-10-15" });
  });

  it("collects the missing order-filing choice within the mixed-field P2 row", async () => {
    const h = mount("P2", [{ ...gap("p2_orders_affecting_will", "orderFiled"), missingFields: ["estate.orderDescription", "estate.orderDate", "estate.orderFiled"] }]);
    await choose("orderFiled", "Filed");
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(h.onProceed).toHaveBeenCalledTimes(1));
    expect(canonicalPayload(h.onApplyInline)).toEqual({ orderFiled: "filed" });
  });

  it("uses the existing interlineation treatment choices without inventing a default", async () => {
    const h = mount("P4", [gap("p4_interlineation_treatment", "interlineationTreatment")], { estate: { ...baseEstate, willAlterationTypes: "interlineations" } });
    await choose("interlineationTreatment", "Authenticated by re-execution or a codicil");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.onApplyInline).toHaveBeenCalledTimes(1));
    expect(canonicalPayload(h.onApplyInline)).toEqual({ interlineationTreatment: "authenticated" });
  });

  it("collects multiple erasure treatments with the canonical comma-separated format", async () => {
    const h = mount("P4", [gap("p4_erasure_treatments", "erasureTreatments")], { estate: { ...baseEstate, willAlterationTypes: "erasures", erasureStatus: "words_erased" } });
    const group = input("erasureTreatments");
    fireEvent.click(within(group).getByRole("checkbox", { name: "Made in compliance with WESA Div. 1 Part 4" }));
    fireEvent.click(within(group).getByRole("checkbox", { name: "No information as to intentions" }));
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.onApplyInline).toHaveBeenCalledTimes(1));
    expect(canonicalPayload(h.onApplyInline)).toEqual({ erasureTreatments: "compliant,no_information" });
  });

  it("special circumstances does not infer None and None remains exclusive", async () => {
    const h = mount("P4", [gap("p4_special_circumstances", "specialCircumstances")]);
    const group = input("specialCircumstances");
    expect(within(group).getAllByRole("checkbox").every(el => el.getAttribute("data-state") === "unchecked")).toBe(true);
    fireEvent.click(within(group).getByRole("checkbox", { name: "The will-maker was blind" }));
    fireEvent.click(within(group).getByRole("checkbox", { name: "None" }));
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(h.onApplyInline).toHaveBeenCalledTimes(1));
    expect(canonicalPayload(h.onApplyInline)).toEqual({ specialCircumstances: "none" });
  });

  it("allows an affidavit name/date to be entered without assuming sworn facts", async () => {
    const h = mount("P4", [gap("p4_will_copy_affidavit", "willCopyAffidavit")], { estate: { ...baseEstate, willFilingType: "copy", willCopyKnowledge: "affidavit" } });
    const group = input("willCopyAffidavit");
    const name = within(group).getByLabelText("Affidavit of (name)") as HTMLInputElement;
    const date = within(group).getByLabelText("Date sworn") as HTMLInputElement;
    expect(name.value).toBe(""); expect(date.value).toBe("");
    fireEvent.change(name, { target: { value: "Fictional Deponent" } });
    fireEvent.change(date, { target: { value: "2026-10-12" } });
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(h.onProceed).toHaveBeenCalledTimes(1));
    expect(canonicalPayload(h.onApplyInline)).toEqual({ willCopyAffidavit: '[{"name":"Fictional Deponent","sworn":"2026-10-12"}]' });
  });

  it("keeps typed canonical answers after a refused save and never proceeds on that failure", async () => {
    const apply = vi.fn().mockResolvedValueOnce(false).mockResolvedValueOnce(true);
    const h = mount("P5", [gap("p5_will_status_required", "willStatus")], { onApplyInline: apply });
    await choose("willStatus", "No will");
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(apply).toHaveBeenCalledTimes(1));
    expect(h.onProceed).not.toHaveBeenCalled();
    expect(input("willStatus").textContent).toContain("No will");
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(h.onProceed).toHaveBeenCalledTimes(1));
    expect(apply).toHaveBeenCalledTimes(2);
    expect(apply.mock.calls[1][5]).toEqual({ willStatus: "no_will", hasWill: 0 });
  });

  it("hides and excludes a stale erasure-treatment draft after the user selects entirely effaced", async () => {
    const h = mount("P4", [gap("p4_erasure_status", "erasureStatus"), gap("p4_erasure_treatments", "erasureTreatments")], { estate: { ...baseEstate, willAlterationTypes: "erasures", erasureStatus: "words_erased" } });
    fireEvent.click(within(input("erasureTreatments")).getByRole("checkbox", { name: "Made in compliance with WESA Div. 1 Part 4" }));
    await choose("erasureStatus", "Entirely effaced — cannot be ascertained");
    expect(screen.queryByTestId("pre-generate-canonical-erasureTreatments")).toBeNull();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(h.onProceed).toHaveBeenCalledTimes(1));
    expect(canonicalPayload(h.onApplyInline)).toEqual({ erasureStatus: "effaced" });
  });

  it("does not turn unknown or server-managed paths into editable properties", () => {
    mount("P5", [gap("p5_unknown_server_field", "ownerId"), gap("p5_unknown_constructor", "constructor")]);
    expect(screen.queryByTestId("pre-generate-canonical-ownerId")).toBeNull();
    expect(screen.queryByTestId("pre-generate-canonical-constructor")).toBeNull();
  });

  it("keeps the specifically retained bulk/package inline-edit restriction", () => {
    const h = mount("P5", [gap("p5_will_status_required", "willStatus")], { inlineEditingEnabled: false });
    expect(screen.queryByTestId("pre-generate-canonical-willStatus")).toBeNull();
    expect(screen.getByTestId("pre-generate-jump-p5_will_status_required")).toBeTruthy();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    expect(h.onApplyInline).not.toHaveBeenCalled();
  });
});
