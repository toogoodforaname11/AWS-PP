import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Cookie } from "lucide-react";

const CONSENT_KEY = "cookie-consent-accepted";

// Analytics loads only after explicit consent, and only when the endpoint is
// configured — an unset env var must not emit a literal %VITE_…% request.
function loadAnalytics() {
  const endpoint = import.meta.env.VITE_ANALYTICS_ENDPOINT;
  const websiteId = import.meta.env.VITE_ANALYTICS_WEBSITE_ID;
  if (!endpoint || !websiteId) return;
  if (document.querySelector("script[data-website-id]")) return;
  const script = document.createElement("script");
  script.defer = true;
  script.src = `${endpoint}/umami`;
  script.dataset.websiteId = websiteId;
  document.body.appendChild(script);
}

export function CookieConsent() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Only show if user hasn't already responded
    const consent = localStorage.getItem(CONSENT_KEY);
    if (!consent) {
      // Small delay so it doesn't flash on page load
      const timer = setTimeout(() => setVisible(true), 1000);
      return () => clearTimeout(timer);
    }
    if (consent === "accepted") loadAnalytics();
  }, []);

  const accept = () => {
    localStorage.setItem(CONSENT_KEY, "accepted");
    setVisible(false);
    loadAnalytics();
  };

  const decline = () => {
    localStorage.setItem(CONSENT_KEY, "declined");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-[9999] p-4 animate-in slide-in-from-bottom-4 duration-500"
      style={{ animationTimingFunction: "cubic-bezier(0.23, 1, 0.32, 1)" }}
    >
      <div className="max-w-lg mx-auto bg-card border border-border rounded-xl shadow-lg p-4 flex flex-col sm:flex-row items-start sm:items-center gap-3">
        <div className="flex items-start gap-3 flex-1">
          <Cookie className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
          <p className="text-sm text-muted-foreground leading-relaxed">
            We use essential cookies to keep you signed in and analytics cookies to improve our service.{" "}
            <a href="/privacy" className="text-foreground underline underline-offset-2 hover:no-underline">
              Privacy Policy
            </a>
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
          <Button variant="ghost" size="sm" onClick={decline} className="text-xs h-8 px-3">
            Decline
          </Button>
          <Button size="sm" onClick={accept} className="text-xs h-8 px-3">
            Accept
          </Button>
        </div>
      </div>
    </div>
  );
}
