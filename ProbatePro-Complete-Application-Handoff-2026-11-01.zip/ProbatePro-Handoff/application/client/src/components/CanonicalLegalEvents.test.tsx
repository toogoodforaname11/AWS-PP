import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  citations: [] as any[],
}));

vi.mock("@/lib/trpc", () => {
  const mutation = () => ({ isPending: false, mutateAsync: vi.fn() });
  const invalidate = vi.fn();
  return {
    trpc: {
      useUtils: () => ({
        citation: { list: { invalidate } },
        pgtDocumentDelivery: { list: { invalidate } },
        readiness: { check: { invalidate }, timeline: { invalidate } },
        deadline: { list: { invalidate } },
        document: { list: { invalidate }, preflight: { invalidate }, preflightMany: { invalidate } },
      }),
      citation: {
        list: { useQuery: () => ({ data: mocks.citations, isLoading: false, error: null }) },
        create: { useMutation: mutation },
        update: { useMutation: mutation },
        delete: { useMutation: mutation },
        uploadEvidence: { useMutation: mutation },
      },
      contact: {
        list: { useQuery: () => ({ data: [], isLoading: false, error: null }) },
      },
      pgtDocumentDelivery: {
        list: { useQuery: () => ({ data: [], isLoading: false, error: null }) },
        upsert: { useMutation: mutation },
        delete: { useMutation: mutation },
      },
      document: {
        list: { useQuery: () => ({ data: [], isLoading: false, error: null }) },
      },
    },
  };
});

import {
  CitationTracker,
  PgtDocumentDeliveryTracker,
  citationState,
  citorContactIssue,
} from "./CanonicalLegalEvents";

function record(
  overrides: Partial<Parameters<typeof citationState>[0]> = {}
): Parameters<typeof citationState>[0] {
  return {
    servedDate: "2026-01-15",
    responseType: "no_response",
    responseServedDate: "",
    responseStorageKey: "",
    responseFileName: "",
    citedGrantIssuedDate: "",
    extensionUntilDate: "",
    citationStorageKey: "citation.pdf",
    citationFileName: "citation.pdf",
    citorName: "Alex Citor",
    citorAddress: "100 Main Street",
    citorOccupation: "Teacher",
    citedName: "Evan Executor",
    serviceProofRoute: "citor_personal",
    servedTime: "10:30",
    servedCityCountry: "Victoria, Canada",
    serviceAffidavitDate: "",
    serviceAffidavitDeponentName: "",
    serviceAffidavitStorageKey: "",
    serviceAffidavitFileName: "",
    ...overrides,
  };
}

describe("citationState", () => {
  it("keeps a no-response citation unavailable until at least 14 days have elapsed", () => {
    expect(citationState(record(), "2026-01-28")).toMatchObject({
      label: "Awaiting 14-day response period",
      p34Available: false,
    });
    expect(citationState(record(), "2026-01-30")).toMatchObject({
      label: "14 days elapsed",
      p34Available: true,
    });
  });

  it("requires the served P33 evidence before treating a refusal as deemed renunciation", () => {
    expect(
      citationState(
        record({
          responseType: "p33_refuses",
          responseServedDate: "2026-01-20",
        }),
        "2026-01-20"
      )
    ).toMatchObject({
      label: "P33 response incomplete",
      p34Available: false,
    });
    expect(
      citationState(
        record({
          responseType: "p33_refuses",
          responseServedDate: "2026-01-20",
          responseStorageKey: "answer-p33.pdf",
          responseFileName: "answer-p33.pdf",
        }),
        "2026-01-20"
      )
    ).toMatchObject({
      label: "Deemed renunciation",
      p34Available: true,
    });
  });

  it("honours a court extension before making the six-month branch actionable", () => {
    const extended = record({
      responseType: "p33_will_apply",
      responseServedDate: "2026-01-20",
      responseStorageKey: "answer-p33.pdf",
      responseFileName: "answer-p33.pdf",
      extensionUntilDate: "2026-09-30",
    });
    expect(citationState(extended, "2026-09-30")).toMatchObject({
      label: "Awaiting grant period",
      p34Available: false,
    });
    expect(citationState(extended, "2026-10-02")).toMatchObject({
      label: "Grant period elapsed",
      p34Available: true,
    });
  });

  it("does not offer P34 after a grant has been recorded", () => {
    expect(
      citationState(
        record({ citedGrantIssuedDate: "2026-03-01" }),
        "2026-10-01"
      )
    ).toMatchObject({
      label: "Grant recorded",
      p34Available: false,
    });
  });

  it("requires the selected supporting affidavit evidence", () => {
    expect(
      citationState(
        record({ serviceProofRoute: "supporting_affidavit" }),
        "2026-02-01"
      )
    ).toMatchObject({
      label: "Service proof missing",
      p34Available: false,
    });
  });
});

describe("citorContactIssue", () => {
  // Issue #21: the server canonicalizes the sworn citor address from
  // residentialAddress only (routers.citationContactAddress) and 400s
  // otherwise — the client check must match, not accept postal or
  // address-for-service substitutes.
  it("requires a residential address, matching the server's canonicalization", () => {
    expect(
      citorContactIssue({
        name: "Alex Citor",
        residentialAddress: "",
        occupation: "Teacher",
      })
    ).toBe("The selected citor contact needs a residential address.");
    expect(
      citorContactIssue({
        name: "Alex Citor",
        residentialAddress: "",
        postalAddress: "PO Box 100, Victoria, BC",
        addressForService: "c/o Firm LLP, Vancouver, BC",
        occupation: "Teacher",
      } as any)
    ).toBe("The selected citor contact needs a residential address.");
    expect(
      citorContactIssue({
        name: "Alex Citor",
        residentialAddress: "100 Main Street, Victoria, BC",
        occupation: "Teacher",
      })
    ).toBeNull();
  });

  it("still requires the contact itself, a name, and an occupation", () => {
    expect(citorContactIssue(undefined)).toBe(
      "Select a citor who belongs to this estate, or enter the citor manually."
    );
    expect(
      citorContactIssue({ name: "", residentialAddress: "100 Main Street", occupation: "Teacher" })
    ).toBe("The selected citor contact needs a name.");
    expect(
      citorContactIssue({ name: "Alex Citor", residentialAddress: "100 Main Street", occupation: "" })
    ).toBe("The selected citor contact needs an occupation.");
  });
});

describe("canonical legal-event trackers", () => {
  it("opens the citation editor without exposing storage-key fields", () => {
    render(
      <CitationTracker
        estateId="estate-1"
        onPreviewP34={() => {}}
        onGenerateP34={() => {}}
      />
    );

    fireEvent.click(screen.getByRole("button", { name: "Add citation" }));

    expect(screen.getByRole("dialog")).toBeTruthy();
    expect(
      screen.getByRole("heading", { name: "Add citation record" })
    ).toBeTruthy();
    expect(screen.getByLabelText("Served citation *")).toBeTruthy();
    expect(screen.queryByLabelText(/storage key/i)).toBeNull();
  });

  it("opens the PGT editor and explains the prompt-delivery rule without inventing a countdown", () => {
    render(<PgtDocumentDeliveryTracker estateId="estate-1" />);

    expect(
      screen.getByText(/“Promptly” is not a fixed numeric deadline/i)
    ).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Add filed copy" }));

    expect(screen.getByRole("dialog")).toBeTruthy();
    expect(screen.getByLabelText("Date filed *")).toBeTruthy();
    expect(screen.getByLabelText("Date delivered to PGT")).toBeTruthy();
  });

  it("routes an eligible P34 citation to the document-details handoff before preview or generation", () => {
    mocks.citations = [{ id: "citation-1", ...record() }];
    const onOpenP34Details = vi.fn();

    try {
      render(
        <CitationTracker
          estateId="estate-1"
          onOpenP34Details={onOpenP34Details}
        />,
      );

      fireEvent.click(screen.getByRole("button", { name: "Generate P34" }));
      expect(onOpenP34Details).toHaveBeenCalledWith("citation-1", "Evan Executor");
    } finally {
      mocks.citations = [];
    }
  });
});
