import { AlertTriangle, Bot, CheckCircle2, FileWarning, Loader2, Minus, TrendingDown, TrendingUp } from "lucide-react";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";

type FailureSource = "chatbot" | "document_generation";
type FailureStatus = "open" | "resolved";
type DetailLogSource = "all" | FailureSource;
type FailureReport = {
  id: string;
  source: FailureSource;
  operation: string;
  errorCode: string;
  userId?: number | null;
  estateId: string;
  formCode: string;
  reportStatus: FailureStatus;
  occurredAt: Date | number | string;
  reporterName?: string | null;
  reporterEmail?: string | null;
};
type FailureTrendPoint = { day: number; source: FailureSource; count: number };
const DAY_MS = 86_400_000;
const DETAIL_LOG_PAGE_SIZE = 8;

function formatDate(value: Date | number | string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : date.toLocaleString();
}
function readable(value: string) {
  return value.replace(/_/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}
function localDateBoundary(value: string, endExclusive = false) {
  if (!value) return undefined;
  const [year, month, day] = value.split("-").map(Number);
  const boundary = new Date(year, month - 1, day);
  if (endExclusive) boundary.setDate(boundary.getDate() + 1);
  return boundary.getTime();
}
function utcDateInput(day: number) {
  return new Date(day * DAY_MS).toISOString().slice(0, 10);
}

function buildSevenDayTrend(points: FailureTrendPoint[]) {
  const today = Math.floor(Date.now() / DAY_MS) * DAY_MS;
  const days = Array.from({ length: 7 }, (_, index) => {
    const timestamp = today - (6 - index) * DAY_MS;
    return { timestamp, day: Math.floor(timestamp / DAY_MS), label: new Date(timestamp).toLocaleDateString(undefined, { month: "short", day: "numeric", timeZone: "UTC" }), chatbot: 0, documentGeneration: 0 };
  });
  const byDay = new Map(days.map((item) => [item.day, item]));
  points.forEach((point) => {
    const item = byDay.get(Number(point.day));
    if (!item) return;
    if (point.source === "chatbot") item.chatbot += Number(point.count);
    if (point.source === "document_generation") item.documentGeneration += Number(point.count);
  });
  return days;
}

function FailureFrequencyChart({ points, selectedDay, onSelectDay }: { points: FailureTrendPoint[]; selectedDay: number | null; onSelectDay: (day: number | null) => void }) {
  const trend = buildSevenDayTrend(points);
  const maxValue = Math.max(0, ...trend.flatMap((day) => [day.chatbot, day.documentGeneration]));
  const [activeDay, setActiveDay] = useState<number | null>(null);
  if (maxValue === 0) return <p className="rounded-lg border border-dashed border-border/70 px-3 py-6 text-sm text-muted-foreground">No chatbot or document-generation failures have been recorded in the last seven days.</p>;
  const width = 720; const height = 168; const padding = { top: 14, right: 18, bottom: 28, left: 28 };
  const chartWidth = width - padding.left - padding.right; const chartHeight = height - padding.top - padding.bottom;
  const groupWidth = chartWidth / trend.length; const barWidth = Math.min(26, groupWidth * 0.28);
  const y = (value: number) => padding.top + chartHeight - (value / maxValue) * chartHeight;
  const active = activeDay === null ? null : trend[activeDay];
  const tooltipLeft = activeDay === null ? 50 : Math.min(88, Math.max(12, (activeDay / (trend.length - 1)) * 100));
  const tooltipId = "failure-frequency-tooltip";
  return <div className="admin-failure-chart space-y-3"><div className="flex flex-wrap gap-x-4 gap-y-2 text-xs text-muted-foreground"><span className="inline-flex items-center gap-1.5"><i className="h-2 w-2 rounded-sm bg-sky-600" /> Chatbot</span><span className="inline-flex items-center gap-1.5"><i className="h-2 w-2 rounded-sm bg-amber-500" /> Document generation</span><span className="ml-auto">{trend[0]?.label}–{trend[trend.length - 1]?.label}</span></div><div className="relative"><svg role="group" aria-label="7-day chatbot and document-generation failure frequency" className="h-44 w-full overflow-visible" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none"><line x1={padding.left} y1={padding.top + chartHeight} x2={width - padding.right} y2={padding.top + chartHeight} stroke="currentColor" opacity="0.18" /><line x1={padding.left} y1={padding.top + chartHeight / 2} x2={width - padding.right} y2={padding.top + chartHeight / 2} stroke="currentColor" opacity="0.1" strokeDasharray="4 4" />{trend.map((day, index) => { const center = padding.left + groupWidth * index + groupWidth / 2; const chatY = y(day.chatbot); const documentY = y(day.documentGeneration); const isSelected = selectedDay === day.day; const selectDay = () => onSelectDay(isSelected ? null : day.day); return <g key={day.timestamp}><rect className="admin-failure-chart-bar" x={center - barWidth - 2} y={chatY} width={barWidth} height={padding.top + chartHeight - chatY} rx="3" fill="oklch(0.6 0.13 235)" /><rect className="admin-failure-chart-bar" x={center + 2} y={documentY} width={barWidth} height={padding.top + chartHeight - documentY} rx="3" fill="oklch(0.72 0.16 72)" /><rect className={`admin-failure-chart-hitbox${isSelected ? " admin-failure-chart-hitbox-selected" : ""}`} x={center - groupWidth / 2} y={padding.top} width={groupWidth} height={chartHeight} fill="transparent" tabIndex={0} role="button" aria-pressed={isSelected} aria-describedby={activeDay === index ? tooltipId : undefined} aria-label={`${day.label}: ${day.chatbot} chatbot failures, ${day.documentGeneration} document-generation failures, ${day.chatbot + day.documentGeneration} total. ${isSelected ? "Selected to filter detailed log." : "Select to filter detailed log."}`} onClick={selectDay} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); selectDay(); } }} onPointerEnter={() => setActiveDay(index)} onPointerLeave={() => setActiveDay(null)} onFocus={() => setActiveDay(index)} onBlur={() => setActiveDay(null)} /><text x={center} y={height - 7} textAnchor="middle" fontSize="10" fill="currentColor" opacity="0.65">{day.label}</text></g>; })}</svg>{active && <div id={tooltipId} role="tooltip" className="admin-failure-chart-tooltip pointer-events-none absolute top-2 z-10" style={{ left: `${tooltipLeft}%` }}><p>{active.label}</p><dl><div><dt>Chatbot</dt><dd>{active.chatbot}</dd></div><div><dt>Document generation</dt><dd>{active.documentGeneration}</dd></div><div><dt>Total</dt><dd>{active.chatbot + active.documentGeneration}</dd></div></dl></div>}</div><p className="sr-only">{trend.map((day) => `${day.label}: ${day.chatbot} chatbot failures, ${day.documentGeneration} document-generation failures, ${day.chatbot + day.documentGeneration} total`).join(". ")}</p></div>;
}

function safeOperationalDetail(report: FailureReport) {
  if (report.source === "chatbot") {
    if (report.errorCode === "provider_failure") return "The assistant provider did not complete the requested chat turn.";
    if (report.errorCode === "request_timeout") return "The assistant request exceeded its allowed processing time.";
    return "The assistant did not complete the requested operational step.";
  }
  if (report.errorCode === "render_failure") return "The document-rendering operation did not complete.";
  if (report.errorCode === "storage_failure") return "The generated document could not be stored securely.";
  return "The document-generation operation ended unexpectedly.";
}
function safeClipboardDetail(report: FailureReport) {
  return [
    "Failure report",
    `Source: ${report.source === "chatbot" ? "Chatbot" : "Document generation"}`,
    `Code: ${readable(report.errorCode)}`,
    `Operational detail: ${safeOperationalDetail(report)}`,
    `Operation: ${readable(report.operation)}`,
    `Recorded: ${formatDate(report.occurredAt)}`,
    report.formCode ? `Form: ${report.formCode}` : null,
    report.estateId ? "Context: Estate-linked" : null,
  ].filter(Boolean).join("\n");
}

function FailureDetailLog({ reports, total, page, source, search, searchPending, startDate, endDate, selectedChartDate, isLoading, onPageChange, onSourceChange, onSearchChange, onDateChange, onClearChartDate }: { reports: FailureReport[]; total: number; page: number; source: DetailLogSource; search: string; searchPending: boolean; startDate: string; endDate: string; selectedChartDate: string | null; isLoading: boolean; onPageChange: (page: number) => void; onSourceChange: (source: DetailLogSource) => void; onSearchChange: (search: string) => void; onDateChange: (range: { startDate: string; endDate: string }) => void; onClearChartDate: () => void }) {
  const pageCount = Math.max(1, Math.ceil(total / DETAIL_LOG_PAGE_SIZE));
  const first = total === 0 ? 0 : (page - 1) * DETAIL_LOG_PAGE_SIZE + 1;
  const last = Math.min(page * DETAIL_LOG_PAGE_SIZE, total);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const copyDetails = async (report: FailureReport) => {
    try {
      if (!navigator.clipboard?.writeText) throw new Error("Clipboard unavailable");
      await navigator.clipboard.writeText(safeClipboardDetail(report));
      setCopiedId(report.id);
      toast.success("Safe failure details copied");
      window.setTimeout(() => setCopiedId((current) => current === report.id ? null : current), 2_000);
    } catch {
      toast.error("Could not copy failure details. Please try again.");
    }
  };
  return <details data-testid="failure-detail-log" className="group rounded-xl border border-border/65 bg-background/25">
    <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-3 py-3 text-sm font-medium marker:content-none sm:px-4">
      <span>Detailed operational log</span>
      <span className="flex items-center gap-2 text-xs text-muted-foreground">
        {isLoading ? <span role="status" aria-label="Loading detailed failure log" className="inline-flex items-center gap-1"><Loader2 className="h-3.5 w-3.5 animate-spin" /> Loading</span> : <Badge variant="secondary">{total}</Badge>}
        <span className="transition-transform duration-200 group-open:rotate-180" aria-hidden="true">⌄</span>
      </span>
    </summary>
    <div className="border-t border-border/60 px-3 py-3 sm:px-4">
      <div className="mb-3 grid gap-3 xl:grid-cols-[minmax(0,1fr)_12rem_12rem_11rem_11rem] xl:items-end">
        <p className="text-xs text-muted-foreground">Shows the recorded source, safe operational detail, code, operation, and time. Raw exception text, form values, chat content, document content, credentials, and stack traces are never retained.</p>
        <div className="w-full sm:w-52">
          <Label htmlFor="failure-detail-source-filter" className="text-xs">Log source</Label>
          <Select value={source} onValueChange={(value: DetailLogSource) => onSourceChange(value)}>
            <SelectTrigger id="failure-detail-source-filter" aria-label="Filter detailed failure log by source"><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="all">All sources</SelectItem><SelectItem value="chatbot">Chatbot</SelectItem><SelectItem value="document_generation">Document generation</SelectItem></SelectContent>
          </Select>
        </div>
        <div><Label htmlFor="failure-detail-search" className="text-xs">Search log</Label><input id="failure-detail-search" aria-label="Search detailed failure log" type="search" value={search} onChange={(event) => onSearchChange(event.target.value)} placeholder="Code, operation, form…" className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" />{searchPending ? <p role="status" className="mt-1 text-[11px] text-muted-foreground">Searching…</p> : null}</div>
        <div><Label htmlFor="failure-detail-start-date" className="text-xs">From date</Label><input id="failure-detail-start-date" aria-label="Failure detail log from date" type="date" value={startDate} max={endDate || undefined} onChange={(event) => onDateChange({ startDate: event.target.value, endDate })} className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" /></div>
        <div><Label htmlFor="failure-detail-end-date" className="text-xs">To date</Label><input id="failure-detail-end-date" aria-label="Failure detail log to date" type="date" value={endDate} min={startDate || undefined} onChange={(event) => onDateChange({ startDate, endDate: event.target.value })} className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm" /></div>
        {(startDate || endDate) && <Button type="button" variant="ghost" size="sm" className="justify-self-start xl:col-start-5" onClick={() => selectedChartDate ? onClearChartDate() : onDateChange({ startDate: "", endDate: "" })}>{selectedChartDate ? "Clear chart date" : "Clear dates"}</Button>}
      </div>
      {selectedChartDate && <div className="mb-3 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-sky-500/30 bg-sky-500/10 px-3 py-2 text-xs"><span>Chart day selected: <strong>{selectedChartDate}</strong>. The log is filtered to this exact UTC day.</span><Button type="button" size="sm" variant="ghost" aria-label="Clear chart date selection" onClick={onClearChartDate}>Clear selection</Button></div>}
      {isLoading ? <div role="status" className="flex items-center gap-2 rounded-lg border border-dashed border-border/70 px-3 py-4 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading detailed failure records…</div> : reports.length === 0 ? <p className="rounded-lg border border-dashed border-border/70 px-3 py-4 text-sm text-muted-foreground">No failure records match the selected log source or date range.</p> : <>
        <ol className="space-y-2">{reports.map((report) => <li key={report.id} className="rounded-lg border border-border/60 bg-background/35 p-3"><div className="flex flex-wrap items-start justify-between gap-2"><div><p className="font-medium">{report.source === "chatbot" ? "Chatbot" : "Document generation"} · {readable(report.errorCode)}</p><p className="mt-1 text-sm text-muted-foreground">{safeOperationalDetail(report)}</p></div><div className="flex items-center gap-2"><Badge variant={report.reportStatus === "open" ? "destructive" : "secondary"}>{readable(report.reportStatus)}</Badge><Button type="button" size="sm" variant="outline" aria-label={`Copy safe details for ${report.source === "chatbot" ? "Chatbot" : "Document generation"} ${readable(report.errorCode)}`} onClick={() => { void copyDetails(report); }}>{copiedId === report.id ? "Copied" : "Copy details"}</Button></div></div><dl className="mt-3 grid gap-x-4 gap-y-1 text-xs text-muted-foreground sm:grid-cols-2"><div><dt className="inline font-medium text-foreground">Operation: </dt><dd className="inline">{readable(report.operation)}</dd></div><div><dt className="inline font-medium text-foreground">Recorded: </dt><dd className="inline">{formatDate(report.occurredAt)}</dd></div>{report.formCode ? <div><dt className="inline font-medium text-foreground">Form: </dt><dd className="inline">{report.formCode}</dd></div> : null}{report.estateId ? <div><dt className="inline font-medium text-foreground">Context: </dt><dd className="inline">Estate-linked</dd></div> : null}</dl></li>)}</ol>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-border/60 pt-3"><p aria-live="polite" className="text-xs text-muted-foreground">Showing {first}–{last} of {total} records</p><div className="flex items-center gap-2"><Button type="button" size="sm" variant="outline" aria-label="Previous failure detail page" disabled={page === 1} onClick={(event) => { event.preventDefault(); onPageChange(page - 1); }}>Previous</Button><span className="text-xs tabular-nums text-muted-foreground">Page {page} of {pageCount}</span><Button type="button" size="sm" variant="outline" aria-label="Next failure detail page" disabled={page === pageCount} onClick={(event) => { event.preventDefault(); onPageChange(page + 1); }}>Next</Button></div></div>
      </>}
    </div>
  </details>;
}

export function AdminFailureReports() {
  const [source, setSource] = useState<"all" | FailureSource>("all");
  const [status, setStatus] = useState<"all" | FailureStatus>("open");
  const [detailPage, setDetailPage] = useState(1);
  const [detailSource, setDetailSource] = useState<DetailLogSource>("all");
  const [detailSearchInput, setDetailSearchInput] = useState("");
  const [detailSearch, setDetailSearch] = useState("");
  const [detailStartDate, setDetailStartDate] = useState("");
  const [detailEndDate, setDetailEndDate] = useState("");
  const [selectedChartDay, setSelectedChartDay] = useState<number | null>(null);
  const priorManualDateRange = useRef<{ startDate: string; endDate: string } | null>(null);
  const failuresQuery = trpc.failureReports.list.useQuery(undefined, { refetchInterval: 15_000, refetchOnWindowFocus: true });
  const summaryQuery = trpc.failureReports.summary.useQuery(undefined, { refetchInterval: 15_000, refetchOnWindowFocus: true });
  const trendQuery = trpc.failureReports.trend.useQuery(undefined, { refetchInterval: 15_000, refetchOnWindowFocus: true });
  const selectedChartStartAt = selectedChartDay === null ? undefined : selectedChartDay * DAY_MS;
  const selectedChartEndExclusive = selectedChartDay === null ? undefined : (selectedChartDay + 1) * DAY_MS;
  const detailPageQuery = trpc.failureReports.detailPage.useQuery({ source: detailSource === "all" ? undefined : detailSource, search: detailSearch.trim() || undefined, startAt: selectedChartStartAt ?? localDateBoundary(detailStartDate), endExclusive: selectedChartEndExclusive ?? localDateBoundary(detailEndDate, true), page: detailPage, pageSize: DETAIL_LOG_PAGE_SIZE }, { refetchInterval: 15_000, refetchOnWindowFocus: true });
  const resolveMutation = trpc.failureReports.resolve.useMutation({
    onSuccess: () => { void failuresQuery.refetch(); void detailPageQuery.refetch(); toast.success("Failure report marked resolved"); },
    onError: () => toast.error("Could not update this failure report. Please try again."),
  });
  const reports = useMemo(() => ((failuresQuery.data ?? []) as FailureReport[]).filter((report) =>
    (source === "all" || report.source === source) && (status === "all" || report.reportStatus === status),
  ), [failuresQuery.data, source, status]);
  const detailTotal = Number(detailPageQuery.data?.total ?? 0);
  const detailPageCount = Math.max(1, Math.ceil(detailTotal / DETAIL_LOG_PAGE_SIZE));
  const safeDetailPage = Math.min(detailPage, detailPageCount);
  useEffect(() => { const timeout = window.setTimeout(() => setDetailSearch(detailSearchInput), 250); return () => window.clearTimeout(timeout); }, [detailSearchInput]);
  useEffect(() => { setDetailPage(1); }, [detailSource, detailSearch, detailStartDate, detailEndDate]);
  useEffect(() => { if (safeDetailPage !== detailPage) setDetailPage(safeDetailPage); }, [detailPage, safeDetailPage]);

  const summary = summaryQuery.data ?? { total: 0, mostFrequentErrorCode: null, mostFrequentCount: 0, currentPeriodCount: 0, priorPeriodCount: 0 };
  const trendDelta = summary.currentPeriodCount - summary.priorPeriodCount;
  const trendDirection = summary.priorPeriodCount === 0 ? "baseline" : trendDelta > 0 ? "up" : trendDelta < 0 ? "down" : "flat";
  const TrendIcon = trendDirection === "up" ? TrendingUp : trendDirection === "down" ? TrendingDown : Minus;
  const trendLabel = trendDirection === "baseline" ? "No prior 7-day baseline" : trendDirection === "up" ? `${trendDelta} more than prior 7 days` : trendDirection === "down" ? `${Math.abs(trendDelta)} fewer than prior 7 days` : "Unchanged from prior 7 days";
  const selectChartDay = (day: number | null) => {
    setSelectedChartDay(day);
    if (day === null) {
      const priorRange = priorManualDateRange.current ?? { startDate: "", endDate: "" };
      setDetailStartDate(priorRange.startDate);
      setDetailEndDate(priorRange.endDate);
      priorManualDateRange.current = null;
      return;
    }
    if (selectedChartDay === null) priorManualDateRange.current = { startDate: detailStartDate, endDate: detailEndDate };
    const date = utcDateInput(day);
    setDetailStartDate(date);
    setDetailEndDate(date);
  };
  return <Card className="admin-glass-panel"><CardHeader><div className="flex flex-wrap items-start justify-between gap-3"><div><CardTitle className="flex items-center gap-2"><AlertTriangle className="h-5 w-5 text-amber-600" /> Failures & crash reports</CardTitle><CardDescription>Automatic operational signals from document generation and the assistant. Reports do not retain form values, chat messages, exception text, stack traces, or document content.</CardDescription></div><Badge variant="secondary" className="admin-glass-badge">{reports.length} shown</Badge></div></CardHeader><CardContent className="space-y-5"><section aria-label="Failure report summary" className="admin-failure-summary-card"><div><p>Total failure records</p><strong>{summaryQuery.isLoading ? "—" : summary.total}</strong><span>Recorded operational signals</span>{!summaryQuery.isLoading && <span className={`admin-failure-trend admin-failure-trend-${trendDirection}`}><TrendIcon aria-hidden="true" /> {trendLabel}</span>}</div><div><p>Most frequent category</p><strong>{summaryQuery.isLoading ? "Loading…" : summary.mostFrequentErrorCode ? readable(summary.mostFrequentErrorCode) : "No category yet"}</strong><span>{summary.mostFrequentErrorCode ? `${summary.mostFrequentCount} record${summary.mostFrequentCount === 1 ? "" : "s"}` : "New signals will appear here"}</span></div></section><section aria-labelledby="failure-frequency-heading" className="rounded-xl border border-border/65 bg-background/30 p-3 sm:p-4"><h3 id="failure-frequency-heading" className="text-sm font-semibold">Failure frequency · last 7 days</h3><p className="mt-1 text-xs text-muted-foreground">Select a day to filter the detailed log to that exact UTC date.</p><div className="mt-4">{trendQuery.isLoading ? <div role="status" className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading failure frequency…</div> : <FailureFrequencyChart points={(trendQuery.data ?? []) as FailureTrendPoint[]} selectedDay={selectedChartDay} onSelectDay={selectChartDay} />}</div></section><FailureDetailLog reports={(detailPageQuery.data?.items ?? []) as FailureReport[]} total={detailTotal} page={safeDetailPage} source={detailSource} search={detailSearchInput} searchPending={detailSearchInput !== detailSearch} startDate={detailStartDate} endDate={detailEndDate} selectedChartDate={selectedChartDay === null ? null : utcDateInput(selectedChartDay)} isLoading={detailPageQuery.isLoading} onPageChange={(page) => setDetailPage(Math.max(1, Math.min(page, detailPageCount)))} onSourceChange={setDetailSource} onSearchChange={setDetailSearchInput} onDateChange={({ startDate, endDate }) => { setSelectedChartDay(null); setDetailStartDate(startDate); setDetailEndDate(endDate); }} onClearChartDate={() => selectChartDay(null)} /><div className="grid gap-3 sm:grid-cols-2"><div><Label htmlFor="failure-source-filter" className="text-xs">Source</Label><Select value={source} onValueChange={(value: "all" | FailureSource) => setSource(value)}><SelectTrigger id="failure-source-filter"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All sources</SelectItem><SelectItem value="chatbot">Chatbot</SelectItem><SelectItem value="document_generation">Document generation</SelectItem></SelectContent></Select></div><div><Label htmlFor="failure-status-filter" className="text-xs">State</Label><Select value={status} onValueChange={(value: "all" | FailureStatus) => setStatus(value)}><SelectTrigger id="failure-status-filter"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All states</SelectItem><SelectItem value="open">Open</SelectItem><SelectItem value="resolved">Resolved</SelectItem></SelectContent></Select></div></div>{failuresQuery.isLoading ? <div role="status" className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading failure reports…</div> : reports.length === 0 ? <div className="rounded-xl border border-dashed border-border/70 px-4 py-8 text-center"><CheckCircle2 className="mx-auto h-6 w-6 text-emerald-600" /><p className="mt-2 font-medium">No failure reports in this view</p><p className="mt-1 text-sm text-muted-foreground">New unexpected document-generation and assistant failures will appear here automatically.</p></div> : <div className="space-y-3">{reports.map((report) => <div key={report.id} className="admin-glass-row rounded-xl p-3"><div className="flex flex-wrap items-start justify-between gap-3"><div className="min-w-0"><p className="flex flex-wrap items-center gap-2 font-medium">{report.source === "chatbot" ? <Bot className="h-4 w-4 text-sky-600" /> : <FileWarning className="h-4 w-4 text-amber-600" />}{report.source === "chatbot" ? "Chatbot" : "Document generation"} <span className="text-muted-foreground">·</span> {readable(report.errorCode)}</p><p className="mt-1 break-words text-xs text-muted-foreground">{formatDate(report.occurredAt)} · {report.reporterEmail || report.reporterName || (report.userId ? `User #${report.userId}` : "User no longer available")}{report.formCode ? ` · Form ${report.formCode}` : ""}{report.estateId ? " · Estate-linked" : ""}</p><p className="mt-2 text-xs text-muted-foreground">Operation: {readable(report.operation)}. Sensitive inputs and diagnostic text are deliberately not stored in this queue.</p></div><Badge variant={report.reportStatus === "open" ? "destructive" : "secondary"}>{report.reportStatus === "open" ? "Open" : "Resolved"}</Badge></div>{report.reportStatus === "open" && <div className="mt-3"><Button type="button" size="sm" variant="outline" disabled={resolveMutation.isPending} onClick={() => resolveMutation.mutate({ id: report.id })}>{resolveMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle2 className="mr-2 h-4 w-4" />} Mark resolved</Button></div>}</div>)}</div>}</CardContent></Card>;
}
