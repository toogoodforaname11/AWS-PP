// client/src/components/FormDetailsDialog.tsx
//
// Per-form "details" dialog shown when the user clicks Generate or Preview on
// forms P1–P11 in the Forms tab. Modeled on PreGenerateDialog: rendered ONCE in
// FormsTab and driven by parent state. The dialog confirms the form-specific
// inputs that print on the document, pre-filled from existing data.
//
// Data rules (see decisions/adr referenced in the repo brain):
// - Oath type and P2's certified-copy requests persist immediately via the
//   loose-passthrough estate.update. Electronic-will status is captured once in
//   Intake because it is a Type of Will fact, not a P9 election.
// - signatoryType / signatureDate stay generate-call params (no builder reads a
//   persisted date column) — they are lifted state shared with the Generation
//   Options card and are never persisted.
// - Deponent selection is dialog-local and returned to the caller as
//   selectedContactId (P3–P7, P9–P11, P14–P16, P26, P45) or deponentId (P8), which
//   document.generate/preview already accept.
// - P9's recipient checklist edits REAL deliveries-table rows (the rows the P9
//   builder prints) via the same delivery.* endpoints DeliveriesCard uses.
//   Checking a recipient creates a row; unchecking deletes it — never a
//   cosmetic flag (adr-no-fabricated-sworn-facts).

import * as React from "react";
import { useEffect, useMemo, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";
import { deliveryMethodLabel } from "@/lib/labels";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { TriToggle } from "@/components/TriToggle";
import { Send, ChevronDown, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { contactHasRole, p8ApplyingCoApplicants, p9DeliveryProofIssue } from "@shared/types";
import { SETTINGS_LAWYER_DEPONENT_ID, LAWYER_DEPONENT_FORMS } from "@shared/const";
import { todayIn } from "@shared/date-utils";

// ─── Per-form field config ───────────────────────────────────────────
//
// Discriminated by `kind`; each kind renders exactly one way. Scopes:
// signatory/date = generate params (lifted state); oath = estate column
// (persist-on-change); deponent = dialog-local generate param;
// deliveries = the P9 composite (real delivery rows).

export type FormDetailsField =
  | { kind: "signatory" }
  | { kind: "date" }
  | { kind: "affidavitOrdinal" }
  | { kind: "oath" }
  | { kind: "deponent"; param: "selectedContactId" | "deponentId"; applicantsOnly?: boolean }
  | { kind: "certifiedCopies" }
  | { kind: "persistedText"; column: string; label: string; placeholder?: string; description?: string }
  | { kind: "persistedSelect"; column: string; label: string; options: readonly { value: string; label: string }[]; description?: string }
  | { kind: "persistedCheckboxGroup"; column: string; legend: string; options: readonly { value: string; label: string }[]; description?: string }
  | { kind: "deliveries" };

const ESTATE_JURAT_CITY_FIELD: FormDetailsField = {
  kind: "persistedText",
  column: "domicileCity",
  label: "Jurat city",
  placeholder: "Defaults to your firm's city",
  description: "The British Columbia city where this affidavit will be sworn or affirmed. It is never taken from the deceased's residential address.",
};

const P10_P11_ELIGIBILITY_FIELDS: readonly FormDetailsField[] = [
  {
    kind: "persistedSelect",
    column: "deceasedDomiciledInBC",
    label: "Was the deceased domiciled in British Columbia at the time of death?",
    options: [
      { value: "unknown", label: "Not yet determined" },
      { value: "yes", label: "Yes" },
      { value: "no", label: "No" },
    ],
  },
  {
    kind: "persistedSelect",
    column: "deceasedOrdinarilyResidentInBC",
    label: "Was the deceased ordinarily resident in British Columbia at the time of death?",
    options: [
      { value: "unknown", label: "Not yet determined" },
      { value: "yes", label: "Yes" },
      { value: "no", label: "No" },
    ],
    description: "This is a legal determination for the P10/P11 choice; it is not inferred from the deceased's last residential address.",
  },
  {
    kind: "persistedSelect",
    column: "foreignAdministrationConfirmed",
    label: "Administration of all property outside British Columbia",
    options: [
      { value: "unknown", label: "Not yet confirmed" },
      { value: "none_outside", label: "The deceased had no property outside British Columbia" },
      { value: "foreign_pr", label: "All outside-B.C. property is, was, or will be administered by a foreign personal representative" },
      { value: "foreign_law", label: "All outside-B.C. property is, was, or will be otherwise administered under the law of a foreign jurisdiction" },
      { value: "no", label: "No — the Rule 25-3 (8) condition is not met" },
    ],
  },
];

// Form P2's face asks each request separately. The authorization request is
// intentionally absent because P2 always selects the Form P10/P11 filing
// election above it; asking for authorization copies would contradict that
// selected official alternative.
const P2_CERTIFIED_COPY_FIELDS = [
  { column: "certifiedCopies", label: "Estate grant" },
  { column: "certifiedCopiesP10", label: "Affidavit of assets and liabilities for domiciled estate grant" },
  { column: "certifiedCopiesP11", label: "Affidavit of assets and liabilities for non-domiciled estate grant" },
] as const;

function p2CertifiedCopyQuantity(value: unknown): number {
  const parsed = Number.parseInt(String(value ?? ""), 10);
  if (!Number.isFinite(parsed)) return 0;
  return Math.min(20, Math.max(0, parsed));
}

function isP2CertifiedCopyColumn(column: string): boolean {
  return P2_CERTIFIED_COPY_FIELDS.some((field) => field.column === column);
}

const AFFIDAVIT_FIELDS: readonly FormDetailsField[] = [
  { kind: "deponent", param: "selectedContactId" },
  { kind: "oath" },
  { kind: "date" },
  { kind: "affidavitOrdinal" },
  ESTATE_JURAT_CITY_FIELD,
];

// Rules 15/18 (Nick DO-NOT-SHIP resolution, 2026-08-04): every prescribed
// affidavit whose face says "I am an applicant" is applicants-only. P16 and P45
// remain fact-witness affidavits; P9 keeps its legitimate lawyer default.
const APPLICANT_AFFIDAVIT_FIELDS: readonly FormDetailsField[] = [
  { kind: "deponent", param: "selectedContactId", applicantsOnly: true },
  { kind: "oath" },
  { kind: "date" },
  { kind: "affidavitOrdinal" },
  ESTATE_JURAT_CITY_FIELD,
];

// WESA s.130 rows are intentionally a saved practitioner election for P5.
// Contact roles, consent facts, and nominee flags provide useful context but
// must never silently select the legal ground sworn in paragraph 2.
const P5_WESA_S130_PRIORITY_OPTIONS = [
  { value: "a", label: "(a) the spouse of the deceased person or a person nominated by the spouse" },
  { value: "b", label: "(b) a child of the deceased person having the consent of a majority of the children of the deceased person" },
  { value: "c", label: "(c) a person nominated by a child of the deceased person if that person has the consent of a majority of the deceased person's children" },
  { value: "d", label: "(d) a child of the deceased person not having the consent of a majority of the deceased person's children" },
  { value: "e", label: "(e) an intestate successor other than the spouse or child of the deceased person, having the consent of the intestate successors representing a majority in interest of the estate, including the intestate successor who applies for a grant of administration" },
  { value: "e.1", label: "(e.1) a person, other than the spouse or child of the deceased person, nominated by an intestate successor of the deceased person if that person has the consent of the intestate successors representing a majority in interest of the estate, including the intestate successor who nominated the person to apply for a grant of administration" },
  { value: "f", label: "(f) an intestate successor other than the spouse or child of the deceased person, not having the consent of the intestate successors representing a majority in interest of the estate, including the intestate successor who applies for a grant of administration" },
  { value: "f.1", label: "(f.1) in the case of a deceased person whose estate would pass to the government and would be subject to the Escheat Act, a person nominated by the government" },
  { value: "g", label: "(g) any other person the court considers appropriate to appoint, including, without limitation, and subject to the Public Guardian and Trustee's consent, the Public Guardian and Trustee" },
] as const;

const P5_AFFIDAVIT_FIELDS: readonly FormDetailsField[] = [
  ...APPLICANT_AFFIDAVIT_FIELDS,
  {
    kind: "persistedCheckboxGroup",
    column: "applicantPriorityParagraph",
    legend: "WESA s.130 priority for P5 section 2",
    options: P5_WESA_S130_PRIORITY_OPTIONS,
    description: "Select one statutory row. This saved choice is the sole source for the paragraph cited in P5; no automatic inference replaces it.",
  },
];

// Forms without an entry keep their existing one-click flow untouched.
export const FORM_DETAILS: Record<string, readonly FormDetailsField[]> = {
  // Signed (not sworn) forms — signatory drives the service-address block.
  P1: [{ kind: "signatory" }, { kind: "date" }],
  P2: [{ kind: "signatory" }, { kind: "date" }, { kind: "certifiedCopies" }],
  // P34 is sworn by the citor. Its actual signature date is document-facing
  // and must be selected for the specific citation, never inherited silently.
  P34: [{ kind: "date" }, { kind: "affidavitOrdinal" }],
  // P44's official signature block selects either the applicant or lawyer for applicant(s).
  P44: [{ kind: "signatory" }, { kind: "date" }],
  // A Form P46 demand is signed by the demandant. Its actual signature date is
  // document-facing, so collect it at generation rather than inherit the Forms
  // tab's last-used date.
  P46: [{ kind: "date" }],
  // Affidavits — deponent + oath + date. signatoryType is not read by these
  // builders (the router forces "executor"), so no signatory control here.
  // P3–P7 are applicants-only (Rule 15, 2026-08-04).
  P3: APPLICANT_AFFIDAVIT_FIELDS,
  P4: APPLICANT_AFFIDAVIT_FIELDS,
  P5: P5_AFFIDAVIT_FIELDS,
  P6: APPLICANT_AFFIDAVIT_FIELDS,
  P7: APPLICANT_AFFIDAVIT_FIELDS,
  P8: [{ kind: "deponent", param: "deponentId" }, { kind: "oath" }, { kind: "date" }, { kind: "affidavitOrdinal" }, ESTATE_JURAT_CITY_FIELD],
  P9: [
    { kind: "deponent", param: "selectedContactId" },
    { kind: "oath" },
    { kind: "date" },
    { kind: "affidavitOrdinal" },
    ESTATE_JURAT_CITY_FIELD,
    { kind: "deliveries" },
  ],
  // P12's deponent is the translator (Rule 4) — no deponent/oath control; the
  // jurat city is the translator's own oath city (Nick 2026-09-01 directive),
  // never the applicant oath-city chain.
  P12: [
    { kind: "date" },
    { kind: "affidavitOrdinal" },
    // Nick 2026-09-02 (third estate-#18 live audit): the preamble's address and
    // occupation slots were typed "in the P12 details" and printed blank — this
    // dialog offered neither; Intake hid them behind willLanguage === "other".
    {
      kind: "persistedText",
      column: "translatorAddress",
      label: "Translator's address",
      placeholder: "e.g. 88 Linden Avenue, Victoria, BC V8V 4E2",
      description: "Prints in the P12 preamble (\"I, [name], of [address], [occupation]\"). Blank prints the face's fill line.",
    },
    {
      kind: "persistedText",
      column: "translatorOccupation",
      label: "Translator's occupation",
      placeholder: "e.g. certified translator",
      description: "Prints in the P12 preamble. Blank prints the face's fill line.",
    },
    {
      kind: "persistedText",
      column: "p12JuratCity",
      label: "Translator's jurat city (override)",
      placeholder: "e.g. Victoria",
      description: "British Columbia city where the translator will swear or affirm this affidavit. Leave blank to use the law firm office city from Settings.",
    },
  ],
  // Their prescribed faces also say the deponent is an applicant (Rule 18).
  P10: [...APPLICANT_AFFIDAVIT_FIELDS, ...P10_P11_ELIGIBILITY_FIELDS],
  P14: APPLICANT_AFFIDAVIT_FIELDS,
  P15: APPLICANT_AFFIDAVIT_FIELDS,
  P26: APPLICANT_AFFIDAVIT_FIELDS,
  // P16 is sworn by the fact witness who was present at the will signing.
  P16: AFFIDAVIT_FIELDS,
  // P45 is sworn by the fact witness addressing the electronic will.
  P45: AFFIDAVIT_FIELDS,
  P11: [
    { kind: "deponent", param: "selectedContactId", applicantsOnly: true },
    { kind: "oath" },
    { kind: "date" },
    { kind: "affidavitOrdinal" },
    {
      kind: "persistedText",
      column: "juratCity",
      label: "Jurat city (override)",
      placeholder: "e.g. Vancouver",
      description: "British Columbia city where this affidavit will be sworn or affirmed. Leave blank to use the law firm office city from Settings.",
    },
    {
      kind: "persistedText",
      column: "deceasedDomicileJurisdiction",
      label: "Deceased's domicile jurisdiction at death",
      placeholder: "e.g. State of Washington, United States",
      description: "Required for P11. This is not inferred from the deceased's last residential address.",
    },
    {
      kind: "persistedSelect",
      column: "p11DiligentSearchConfirmed",
      label: "Has the applicant made a diligent search and inquiry for the deceased's property and liabilities within British Columbia?",
      options: [
        { value: "unknown", label: "Not yet confirmed" },
        { value: "yes", label: "Yes" },
        { value: "no", label: "No" },
      ],
    },
    ...P10_P11_ELIGIBILITY_FIELDS,
  ],
};

// Deponent candidate pool: the Settings lawyer (when lawyerName is set), lawyer
// contacts, then applying executors/applicants. The lawyer swears affidavits by
// default under the lawyer-signing practice model.
function deponentCandidates(contacts: any[], settingsLawyerName?: string): { applicants: any[]; lawyers: any[] } {
  const applying = p8ApplyingCoApplicants(contacts || []);
  const applicants = applying.primary ? [applying.primary, ...applying.coApplicants] : applying.coApplicants;
  const contactLawyers = (contacts || []).filter(
    (c) => contactHasRole(c, "lawyer")
  );
  const settingsLawyer = settingsLawyerName
    ? [{ id: SETTINGS_LAWYER_DEPONENT_ID, name: settingsLawyerName, role: "lawyer" }]
    : [];
  return { applicants, lawyers: [...settingsLawyer, ...contactLawyers] };
}

// Default deponent. Nick ruling C (2026-07-22): the lawyer is the default ONLY
// for forms that legitimately default to the lawyer (P9 delivery, prefersLawyer
// = true). Other affidavits default to the primary applicant. Applicant-only
// forms pass a lawyers-less pool, while P16/P45 keep the lawyer selectable as a
// fact witness without making that person the default.
function defaultDeponentId(pool: { applicants: any[]; lawyers: any[] }, prefersLawyer: boolean): string {
  if (prefersLawyer && pool.lawyers.length > 0) {
    return pool.lawyers[0].id || "";
  }
  const primary = pool.applicants.find((c) => c.executorRank === "primary");
  return (primary || pool.applicants[0])?.id || "";
}

function methodLabel(m: string): string {
  return deliveryMethodLabel(m) || m;
}

// Input that commits on BLUR, never per keystroke. Browsers fire input events
// with value "" while a date segment is mid-edit; committing those would blank
// a sworn delivery/ack date on the real row (and the resulting isPending
// disable would interrupt typing). Local draft + blur-commit avoids both.
function BlurCommitInput({ value, onCommit, onDraftChange, className, title, testId, type = "date", max, placeholder }: { value: string; onCommit: (v: string) => void; onDraftChange?: (v: string) => void; className?: string; title?: string; testId?: string; type?: string; max?: string; placeholder?: string }) {
  const [draft, setDraft] = useState(value);
  const dirtyRef = useRef(false);
  useEffect(() => { setDraft(value); }, [value]);
  return (
    <Input
      type={type}
      max={max}
      placeholder={placeholder}
      className={className}
      title={title}
      value={draft}
      onChange={(e) => { dirtyRef.current = true; setDraft(e.target.value); onDraftChange?.(e.target.value); }}
      onBlur={() => { if (dirtyRef.current) { dirtyRef.current = false; onCommit(draft); } }}
      data-testid={testId}
    />
  );
}

// ─── P9 recipient checklist (the one composite) ─────────────────────
//
// One row per Rule 25-2(2) recipient (delivery.getRecipients) joined to the
// deliveries table by contactId, plus any manual rows. Checked = a real
// deliveries row exists. All edits go through delivery.upsert/delete/bulkCreate
// exactly like DeliveriesCard — the popup is that card surfaced at generate time.

export function P9DeliveryChecklist({ estateId, estate, contacts, enabled, onPendingChange, beforeContinueRef }: { estateId: string; estate: any; contacts: any[]; enabled: boolean; onPendingChange?: (pending: boolean) => void; beforeContinueRef: React.RefObject<(() => Promise<boolean>) | null> }) {
  const deliveriesQuery = trpc.delivery.list.useQuery({ estateId }, { enabled });
  const recipientsQuery = trpc.delivery.getRecipients.useQuery({ estateId }, { enabled });
  const deliveries = deliveriesQuery.data;
  const recipients = recipientsQuery.data;
  // Unknown is not empty: while either list is loading or failed, an unchecked
  // row would invite a second sworn delivery for a recipient the server already
  // holds, and "no recipients" would read as legal advice. Fail closed instead.
  const recordsFailed = Boolean(deliveriesQuery.isError || recipientsQuery.isError);
  const recordsUnavailable = enabled && (recordsFailed || deliveries === undefined || recipients === undefined);
  const utils = trpc.useUtils();
  const [draftRows, setDraftRows] = useState<Record<string, any>>({});
  // Drafts include focused, unblurred inputs. Generate must save these exact
  // values and wait for the server before handing off to preflight.
  const editedRowsRef = useRef<Record<string, any>>({});
  const [, refreshEditedRows] = useState(0);
  const writesRef = useRef(new Set<Promise<unknown>>());
  // Per-row in-flight write plus the staged row it is saving, so a newer edit
  // chains behind it instead of being dropped and an identical re-blur de-dups.
  const rowWritesRef = useRef(new Map<string, { write: Promise<unknown>; row: any }>());
  const [writeCount, setWriteCount] = useState(0);
  // Two error channels: a failed delivery write stays visible (and blocks
  // Generate) until a later write succeeds; the continue-gate message is
  // recomputed on every Generate. Refs mirror state for the async gate.
  const [writeError, setWriteErrorState] = useState("");
  const writeErrorRef = useRef("");
  const setWriteError = (message: string) => { writeErrorRef.current = message; setWriteErrorState(message); };
  const [gateError, setGateError] = useState("");
  const deliveryError = gateError || writeError;

  const invalidate = () => {
    void utils.delivery.list.invalidate({ estateId });
    void utils.readiness.check.invalidate({ estateId });
    void utils.readiness.timeline.invalidate({ estateId });
    void utils.deadline.list.invalidate();
    void utils.document.preflight.invalidate();
    void utils.document.preflightMany.invalidate();
  };
  // Publish rows only after a successful write. Local drafts retain edits
  // across failed saves, so an optimistic row can never count as delivery proof.
  const upsertMutation = trpc.delivery.upsert.useMutation({
    onSuccess: (data, input) => {
      // Prefer the server's row (timestamps, normalized paths) over the
      // mutation input; an unknown list stays unknown until the refetch lands.
      const saved = data && typeof data === "object" ? { ...input, ...(data as Record<string, unknown>) } : input;
      utils.delivery.list.setData({ estateId }, (old: any) => {
        if (!old) return old;
        const idx = old.findIndex((r: any) => r.id === input.id);
        if (idx === -1) return [...old, saved];
        const next = [...old];
        next[idx] = { ...next[idx], ...saved };
        return next;
      });
      setWriteError("");
      const contactId = input.contactId;
      if (contactId) {
        setDraftRows((old) => {
          const next = { ...old };
          delete next[contactId];
          return next;
        });
      }
    },
    onError: (error) => {
      setWriteError(error.message || "Delivery could not be saved");
      toast.error(error.message || "Delivery could not be saved");
    },
    onSettled: invalidate,
  });
  const deleteMutation = trpc.delivery.delete.useMutation({
    onMutate: (input) => {
      utils.delivery.list.setData({ estateId }, (old: any) => old?.filter((r: any) => r.id !== input.id));
    },
    onSuccess: () => setWriteError(""),
    onSettled: invalidate,
    onError: (error) => { setWriteError(error.message); toast.error(error.message); },
  });
  const bulkCreateMutation = trpc.delivery.bulkCreate.useMutation({
    onSuccess: () => { setWriteError(""); invalidate(); },
    onError: (error) => { setWriteError(error.message); toast.error(error.message); },
  });

  const trackWrite = <T,>(write: Promise<T>): Promise<T> => {
    writesRef.current.add(write);
    setWriteCount(writesRef.current.size);
    void write.finally(() => {
      writesRef.current.delete(write);
      setWriteCount(writesRef.current.size);
    }).catch(() => undefined);
    return write;
  };

  // Bulk records feed sworn P9 delivery dates + the 21-day clock, so the user
  // must record the date rather than accepting an invented default.
  const [bulkDeliveryDate, setBulkDeliveryDate] = useState("");
  const today = todayIn("America/Vancouver");

  // Surface in-flight delivery writes so the dialog can hold Generate/Preview
  // until the rows the builder will read are committed.
  const deliveriesPending = writeCount > 0 || upsertMutation.isPending || deleteMutation.isPending || bulkCreateMutation.isPending;
  useEffect(() => { onPendingChange?.(deliveriesPending); }, [deliveriesPending, onPendingChange]);

  const byContactId = new Map((deliveries || []).filter((d) => d.contactId).map((d) => [d.contactId, d]));
  const recipientRows = (recipients || []).map((r) => {
    const row = byContactId.get(r.contactId) || draftRows[r.contactId];
    return { recipient: r, delivery: row ? editedRowsRef.current[row.id] || row : undefined };
  });
  const recipientContactIds = new Set((recipients || []).map((r) => r.contactId));
  const manualRows = (deliveries || []).filter((d) => !d.contactId || !recipientContactIds.has(d.contactId)).map((d) => editedRowsRef.current[d.id] || d);
  const unrecordedCount = recipientRows.filter((row) => !row.delivery).length;

  const contactById = new Map((contacts || []).map((c) => [c.id, c]));

  // Re-upsert the full existing row with one field changed, mirroring
  // DeliveriesCard's handleSave payload (clears method-dependent fields).
  const stageRow = (d: any, patch: Partial<Record<string, any>>) => {
    const current = editedRowsRef.current[d.id];
    const next = { ...d, ...current, ...patch };
    if (current && Object.entries(next).every(([key, value]) => current[key] === value)) return current;
    editedRowsRef.current[d.id] = next;
    refreshEditedRows((version) => version + 1);
    return next;
  };
  const saveRow = (d: any, patch: Partial<Record<string, any>>): Promise<unknown> | undefined => {
    const next = stageRow(d, patch);
    setGateError("");
    if (next._draft && (!next.deliveryMethod || !next.deliveryDate)) {
      setDraftRows((old) => ({ ...old, [next.contactId]: next }));
      return;
    }
    if (!["ordinary_mail", "personal", "electronic"].includes(next.deliveryMethod)) {
      toast.error("Select an official Form P9 delivery method before saving.");
      return;
    }
    const pending = rowWritesRef.current.get(d.id);
    // The same staged values are already saving (a re-blur) — reuse that write.
    if (pending && pending.row === next) return pending.write;
    const start = () => upsertMutation.mutateAsync({
      id: d.id,
      estateId,
      contactId: next.contactId || "",
      recipientName: next.recipientName,
      recipientAddress: next.recipientAddress || "",
      deliveryMethod: next.deliveryMethod as "ordinary_mail" | "personal" | "electronic",
      deliveryDate: next.deliveryDate || "",
      trackingNumber: next.deliveryMethod === "registered_mail" ? next.trackingNumber || "" : "",
      emailAddress: next.deliveryMethod === "electronic" ? next.emailAddress || "" : "",
      ackDate: next.deliveryMethod === "electronic" ? next.ackDate || "" : "",
      dispensedByOrder: next.dispensedByOrder || 0,
      dispensationOrderDate: next.dispensationOrderDate || "",
      dispensationOrderFilePath: next.dispensationOrderFilePath || "",
      dispensationOrderRegistryFileNumber: next.dispensationOrderRegistryFileNumber || "",
    }).then((result) => {
      if (editedRowsRef.current[d.id] === next) delete editedRowsRef.current[d.id];
      return result;
    });
    // A newer edit chains behind the in-flight write (success or failure) so
    // its values reach the server in order instead of being silently dropped.
    const write: Promise<unknown> = trackWrite((pending ? pending.write.then(start, start) : start()).finally(() => {
      if (rowWritesRef.current.get(d.id)?.write === write) rowWritesRef.current.delete(d.id);
    }));
    rowWritesRef.current.set(d.id, { write, row: next });
    return write;
  };

  const commitRow = (d: any, patch: Partial<Record<string, any>>) => {
    void saveRow(d, patch)?.catch(() => undefined);
  };

  const continueGate = async (): Promise<boolean> => {
    if (recordsUnavailable) {
      setGateError(recordsFailed
        ? "Delivery records could not be loaded. Retry before continuing."
        : "Delivery records are still loading. Wait a moment and try again.");
      return false;
    }
    let savedDeliveries: any[];
    try {
      await Promise.all(Array.from(writesRef.current));
      for (const draft of Object.values(editedRowsRef.current)) {
        if (!draft.deliveryMethod || !draft.deliveryDate) {
          // Keep an incomplete selected row local: the preflight warning and its
          // explicit Generate Anyway action decide whether to create a blank P9
          // draft. Persisting or printing a partial delivery would swear facts
          // that have not been recorded.
          setGateError("Delivery proof is incomplete. Continue to review the warning and generate a blank draft, or finish the recipient method and date first.");
          return true;
        }
        const write = saveRow(draft, {});
        if (!write) {
          // saveRow refused the row (a method the P9 face has no box for).
          setGateError("Choose ordinary mail, personal or electronic delivery for each selected recipient before continuing.");
          return false;
        }
        await write;
      }
      // This fetch also rejects when delivery proof cannot be checked. A stale
      // cached or optimistic row must never permit an empty oath to proceed.
      await utils.delivery.list.invalidate({ estateId });
      savedDeliveries = await utils.delivery.list.fetch({ estateId });
    } catch (error) {
      setGateError(error instanceof Error ? error.message : "Unable to verify saved deliveries. Try again.");
      return false;
    }
    // Pure check outside the catch: a programming error here must surface as
    // one, not be reported to the lawyer as a delivery-record problem.
    const issue = p9DeliveryProofIssue(estate, contacts, savedDeliveries);
    setGateError(issue || "");
    // Proof gaps are warn-and-override conditions for an explicitly requested
    // single P9 draft; a failed write remains a true retryable error.
    return !writeErrorRef.current;
  };
  useEffect(() => {
    beforeContinueRef.current = continueGate;
    return () => { if (beforeContinueRef.current === continueGate) beforeContinueRef.current = null; };
  });

  const createRow = (r: { contactId: string; name: string; address: string; email: string }) => {
    const draft = {
      id: `del_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      estateId,
      contactId: r.contactId,
      recipientName: r.name,
      recipientAddress: r.address || "",
      deliveryMethod: "",
      deliveryDate: "",
      trackingNumber: "",
      emailAddress: r.email || "",
      ackDate: "",
      dispensedByOrder: 0,
      dispensationOrderDate: "",
      dispensationOrderFilePath: "",
      dispensationOrderRegistryFileNumber: "",
      _draft: true,
    };
    editedRowsRef.current[draft.id] = draft;
    setDraftRows((old) => ({ ...old, [r.contactId]: draft }));
  };

  const renderRow = (key: string, name: string, contactId: string | undefined, delivery: any, recipient?: { contactId: string; name: string; address: string; email: string }) => {
    const contact = contactId ? contactById.get(contactId) : undefined;
    const dispensed = delivery?.dispensedByOrder === 1;
    const wontPrint = delivery && (delivery.deliveryMethod === "registered_mail" || dispensed);
    const pending = upsertMutation.isPending || deleteMutation.isPending;
    const checked = !!delivery;
    return (
      <div key={key} className="flex items-center gap-2 py-1.5 px-2 border rounded-md flex-wrap" data-testid={`p9-recipient-row-${contactId || key}`}>
        <Checkbox
          id={`p9-served-${key}`}
          checked={checked}
          disabled={dispensed || pending || (!delivery && !recipient)}
          onCheckedChange={(v) => {
            if (v && recipient) createRow(recipient);
            else if (!v && delivery?._draft) setDraftRows((old) => {
              const next = { ...old };
              delete editedRowsRef.current[delivery.id];
              if (contactId) delete next[contactId];
              return next;
            });
            else if (!v && delivery) {
              delete editedRowsRef.current[delivery.id];
              void trackWrite(deleteMutation.mutateAsync({ id: delivery.id, estateId })).catch(() => undefined);
            }
          }}
          data-testid={`p9-served-${contactId || key}`}
        />
        <Label htmlFor={`p9-served-${key}`} className="text-xs truncate flex-1 cursor-pointer">{name || "Unnamed"}</Label>
        {contact?.isMinor ? <Badge variant="secondary" className="text-[10px] px-1 py-0 h-4">Minor</Badge> : null}
        {contact?.recipientType === "pgt" ? (
          <Badge variant="secondary" className="text-[10px] px-1 py-0 h-4" title="Prints in section 4 (PGT delivery), not section 2.">PGT</Badge>
        ) : null}
        {dispensed ? <Badge variant="secondary" className="text-[10px] px-1 py-0 h-4">Dispensed</Badge> : null}
        {wontPrint ? (
          <Badge variant="outline" className="text-[10px] px-1 py-0 h-4 text-amber-700 dark:text-amber-300 border-amber-300 dark:border-amber-800" title="The P9 face has boxes only for ordinary mail, personal and electronic delivery. Registered-mail and dispensed records do not print in section 2.">
            Won't print
          </Badge>
        ) : null}
        {checked && !dispensed && (
          <>
            <Select value={delivery.deliveryMethod || ""} onValueChange={(v) => commitRow(delivery, { deliveryMethod: v })} disabled={pending}>
              <SelectTrigger data-testid={`p9-method-${contactId || key}`} className="h-7 w-32 text-xs shrink-0"><SelectValue placeholder="Select method" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ordinary_mail">Ordinary Mail</SelectItem>
                <SelectItem value="personal">Personal Delivery</SelectItem>
                <SelectItem value="electronic">Electronic (Email/Fax)</SelectItem>
              </SelectContent>
            </Select>
            <BlurCommitInput
              className="h-7 w-32 text-xs shrink-0"
              value={delivery.deliveryDate || ""}
              onDraftChange={(v) => stageRow(delivery, { deliveryDate: v })}
              onCommit={(v) => commitRow(delivery, { deliveryDate: v })}
              title="Delivery date"
              max={today}
              testId={`p9-date-${contactId || key}`}
            />
            {delivery.deliveryMethod === "electronic" && (
              <>
                <BlurCommitInput
                  type="email"
                  placeholder="recipient@example.com"
                  className="h-7 w-40 text-xs shrink-0"
                  value={delivery.emailAddress || ""}
                  onDraftChange={(v) => stageRow(delivery, { emailAddress: v })}
                  onCommit={(v) => commitRow(delivery, { emailAddress: v })}
                  title="Email the notice was sent to"
                  testId={`p9-email-${contactId || key}`}
                />
                <BlurCommitInput
                  className="h-7 w-32 text-xs shrink-0"
                  value={delivery.ackDate || ""}
                  onDraftChange={(v) => stageRow(delivery, { ackDate: v })}
                  onCommit={(v) => commitRow(delivery, { ackDate: v })}
                  title="Written acknowledgement date"
                  max={today}
                  testId={`p9-ack-${contactId || key}`}
                />
              </>
            )}
          </>
        )}
      </div>
    );
  };

  // E-ack print gate: both §2 acknowledgement sentences print only when EVERY
  // printed electronic row has an ackDate (buildP9's allAcked gate). Mirror the
  // builder's printable filter exactly: dispensed rows AND PGT rows are excluded
  // (PGT deliveries print in §4, which has no acknowledgement clause).
  const electronicRows = (deliveries || []).filter((d) =>
    d.deliveryMethod === "electronic" &&
    d.dispensedByOrder !== 1 &&
    (d.contactId ? contactById.get(d.contactId)?.recipientType !== "pgt" : true));
  const missingAck = electronicRows.filter((d) => !d.ackDate).length;

  const noRecipients = recipientRows.length === 0 && manualRows.length === 0;
  const proofIssue = p9DeliveryProofIssue(estate, contacts, deliveries || []);

  return (
    <div className="space-y-1.5" data-testid="p9-delivery-checklist">
      <div className="flex items-center justify-between">
        <Label className="text-xs font-medium text-muted-foreground">Recipients served with the P1 notice</Label>
        {unrecordedCount > 0 && (
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="default" size="sm" className="h-7 text-xs" disabled={bulkCreateMutation.isPending}>
                <Send className="h-3 w-3 mr-1" />
                {bulkCreateMutation.isPending ? "Creating..." : `Mark All Delivered (${unrecordedCount})`}
                <ChevronDown className="h-3 w-3 ml-1 opacity-60" />
              </Button>
            </PopoverTrigger>
            <PopoverContent align="end" className="w-56 p-2">
              <p className="text-[10px] text-muted-foreground font-medium mb-1 px-1">Delivery date (sworn on P9; starts the 21-day clock):</p>
              <Input
                type="date"
                className="h-7 text-xs mb-2"
                value={bulkDeliveryDate}
                max={today}
                onChange={(e) => setBulkDeliveryDate(e.target.value)}
                data-testid="p9-bulk-delivery-date"
              />
              <p className="text-[10px] text-muted-foreground font-medium mb-1.5 px-1">Delivery method:</p>
              {/* No registered mail here — the P9 face has no box for it, so
                  bulk-creating such rows would swear deliveries that never print. */}
              {([
                { value: "ordinary_mail", label: "Ordinary Mail" },
                { value: "personal", label: "Personal Delivery" },
              ] as const).map((method) => (
                <button
                  key={method.value}
                  type="button"
                  className="w-full text-left text-xs px-2 py-1.5 rounded hover:bg-accent transition-colors disabled:opacity-50"
                  disabled={!bulkDeliveryDate}
                  onClick={() => { void trackWrite(bulkCreateMutation.mutateAsync({ estateId, deliveryMethod: method.value, deliveryDate: bulkDeliveryDate })).catch(() => undefined); }}
                >
                  {method.label}
                </button>
              ))}
            </PopoverContent>
          </Popover>
        )}
      </div>

      {recordsUnavailable ? (
        recordsFailed ? (
          <p className="flex items-center gap-2 text-xs text-destructive py-2" role="alert" data-testid="p9-delivery-unavailable">
            <span>Delivery records could not be loaded. Retry before recording deliveries — existing records are not shown.</span>
            <Button type="button" variant="outline" size="sm" className="h-6 text-xs shrink-0" data-testid="p9-delivery-retry" onClick={() => { void deliveriesQuery.refetch?.(); void recipientsQuery.refetch?.(); }}>Retry</Button>
          </p>
        ) : (
          <p className="text-xs text-muted-foreground py-2" role="status" data-testid="p9-delivery-loading">Loading delivery records…</p>
        )
      ) : noRecipients ? (
        <p className="text-xs text-amber-700 dark:text-amber-300 py-2" data-testid="p9-no-recipients">No P1 recipients or delivery records are recorded. If no one is entitled to notice, use the no-affidavit-of-delivery option in P2. Otherwise, add the actual notice recipients in Contacts and record their deliveries here. Do not record delivery to the sole applicant just to generate P9.</p>
      ) : (
        <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
          {recipientRows.map(({ recipient, delivery }) => renderRow(recipient.contactId, recipient.name, recipient.contactId, delivery, recipient))}
          {manualRows.map((d) => renderRow(d.id, d.recipientName, d.contactId || undefined, d))}
        </div>
      )}

      {!recordsUnavailable && !noRecipients && <p className="text-[11px] text-muted-foreground">Select each actual recipient and enter the method and delivery date. At least one complete delivery is required before generating P9.</p>}
      {!recordsUnavailable && !noRecipients && proofIssue && !deliveryError && <p className="text-xs text-amber-700 dark:text-amber-300" role="status" data-testid="p9-delivery-required">{proofIssue}</p>}
      {deliveryError && <p className="text-xs text-destructive" role="alert" data-testid="p9-delivery-error">{deliveryError}</p>}

      {recipientRows.some(({ delivery }) => delivery?.dispensedByOrder === 1) || manualRows.some((d) => d.dispensedByOrder === 1) ? (
        <p className="text-[10px] text-muted-foreground">Edit dispensation details in the P9 — Delivery Records card below the forms list.</p>
      ) : null}

      {electronicRows.length > 0 && (
        missingAck === 0 ? (
          <p className="text-[10px] text-muted-foreground" data-testid="p9-ack-status-ok">
            All electronic recipients have written acknowledgements — both acknowledgement boxes will be checked.
          </p>
        ) : (
          <p className="flex items-start gap-1 text-[10px] text-amber-700 dark:text-amber-300 leading-tight" role="status" aria-live="polite" data-testid="p9-ack-status-missing">
            <AlertTriangle className="h-3 w-3 shrink-0 mt-px" aria-hidden="true" />
            <span>{missingAck} electronic recipient{missingAck === 1 ? " has" : "s have"} no acknowledgement date — the acknowledgement boxes remain unticked. Rule 25-2 (6)–(7) and the Form P9 section 2 instruction: without written acknowledgement there is no delivery — re-deliver by mail or personal delivery.</span>
          </p>
        )
      )}
    </div>
  );
}

// ─── The dialog ──────────────────────────────────────────────────────

export interface FormDetailsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  formCode: string;
  formName: string;
  estateId: string;
  estate: any;
  contacts: any[];
  /** Lifted generate params — shared with the Generation Options card. */
  signatoryType: string;
  onSignatoryTypeChange: (v: string) => void;
  signatureDate: string;
  onSignatureDateChange: (v: string) => void;
  /** Pre-selects the deponent (P8 per-co-applicant rows). */
  initialDeponentId?: string;
  /** The retained primary affidavit's deponent — P8 candidates exclude this
   *  applicant, not the ranked primary (Rule 15, 2026-08-04). Null/undefined
   *  when no primary affidavit has been generated yet (predictive pool). */
  primaryAffidavitDeponentId?: string | null;
  /** Called with document-local deponent and affidavit-number params; caller runs preflight + generate. */
  onGenerate: (extra: { selectedContactId?: string; deponentId?: string; affidavitOrdinal?: string }) => void | Promise<void>;
  /** Called with document-local deponent and affidavit-number params; caller opens the preview modal. */
  onPreview: (extra: { selectedContactId?: string; deponentId?: string; affidavitOrdinal?: string }) => void | Promise<void>;
  onCancel: () => void;
  /** Disables the Generate button while the mutation is in flight. */
  generating?: boolean;
}

export function FormDetailsDialog(props: FormDetailsDialogProps): React.JSX.Element {
  const {
    open, onOpenChange, formCode, formName, estateId, estate, contacts,
    signatoryType, onSignatoryTypeChange, signatureDate, onSignatureDateChange,
    initialDeponentId, primaryAffidavitDeponentId, onGenerate, onPreview, onCancel, generating,
  } = props;

  const fields = FORM_DETAILS[formCode] || [];
  const utils = trpc.useUtils();
  const updateEstateMutation = trpc.estate.update.useMutation({
    onSuccess: () => {
      void utils.estate.get.invalidate({ id: estateId });
      void utils.readiness.check.invalidate({ estateId });
      void utils.readiness.timeline.invalidate({ estateId });
      void utils.deadline.list.invalidate();
      void utils.document.preflight.invalidate();
      void utils.document.preflightMany.invalidate();
    },
    onError: (err) => {
      toast.error(`Failed to save form details: ${err.message}`);
    },
  });

  // Every estate.update increments a compare-and-swap revision. Serialize this
  // dialog's writes and feed each returned revision into the next operation;
  // otherwise two quick edits both submit the opening revision and the second
  // is rejected while its control still appears saved.
  const revisionRef = useRef<number>(Math.max(1, Number(estate?.revision) || 1));
  const writeQueueRef = useRef<Promise<void>>(Promise.resolve());
  const queuedWriteCountRef = useRef(0);
  const [queuedWrites, setQueuedWrites] = useState(0);
  useEffect(() => {
    const incoming = Number(estate?.revision);
    if (Number.isInteger(incoming) && incoming > revisionRef.current) revisionRef.current = incoming;
  }, [estate?.revision, estateId]);

  const enqueueEstatePatch = (data: Record<string, unknown>): Promise<void> => {
    queuedWriteCountRef.current += 1;
    setQueuedWrites((count) => count + 1);
    const operation = writeQueueRef.current.then(async () => {
      const result = await updateEstateMutation.mutateAsync({
        id: estateId,
        expectedRevision: revisionRef.current,
        data,
      });
      const nextRevision = Number(result?.revision);
      revisionRef.current = Number.isInteger(nextRevision) && nextRevision > revisionRef.current
        ? nextRevision
        : revisionRef.current + 1;
    });
    writeQueueRef.current = operation.then(() => undefined, () => undefined);
    return operation.finally(() => {
      queuedWriteCountRef.current = Math.max(0, queuedWriteCountRef.current - 1);
      setQueuedWrites((count) => Math.max(0, count - 1));
    });
  };

  // P8 candidates = applying applicants other than the applicant who swore the
  // retained primary affidavit (Rule 15, 2026-08-04) — the ranked primary is only
  // the prediction before one exists — mirroring the Forms-tab P8 rows. Every
  // applicantsOnly config excludes lawyer-only and non-applying contacts.
  const deponentField = fields.find((f): f is Extract<FormDetailsField, { kind: "deponent" }> => f.kind === "deponent");
  const isP8 = fields.some((f) => f.kind === "deponent" && f.param === "deponentId");
  // Only forms in LAWYER_DEPONENT_FORMS (P9 delivery) default to the lawyer.
  // Other affidavits default to the applicant. Applicant-only forms exclude the
  // lawyer; P16/P45 keep the lawyer selectable as a fact witness.
  const prefersLawyer = LAWYER_DEPONENT_FORMS.includes(formCode);
  // The Settings lawyer is a deponent candidate without needing a contact row
  // (Nick ruling G3, 2026-07-12) — only fetched when this dialog offers a deponent.
  const { data: firmSettings, isLoading: firmSettingsLoading } = trpc.settings.get.useQuery(undefined, { enabled: !!deponentField });
  // Show a subtle loading skeleton while firmSettings is being fetched (the
  // lawyer name determines the default deponent, so the dropdown is incomplete
  // until it resolves).
  const deponentLoading = !!deponentField && !deponentField.applicantsOnly && !isP8 && firmSettingsLoading;
  const settingsLawyerName = deponentField && !deponentField.applicantsOnly && !isP8 ? (firmSettings as any)?.lawyerName || "" : "";
  const pool = useMemo(() => deponentCandidates(contacts || [], settingsLawyerName), [contacts, settingsLawyerName]);
  // Combined candidates: applicants, with the lawyer as a selectable alternative.
  const candidates = useMemo(() => {
    // Rule 15: with a retained primary affidavit, exclude its ACTUAL deponent
    // (blocked → empty pool when that deponent is not an applying applicant);
    // without one, the ranked-primary prediction stands.
    if (isP8) return p8ApplyingCoApplicants(pool.applicants, primaryAffidavitDeponentId ?? undefined).coApplicants;
    if (deponentField?.applicantsOnly) return pool.applicants;
    // A grant file without an applying applicant is not ready to generate these
    // affidavits. P9 is the sole form that may proceed with only its delivery
    // deponent; P16/P45 otherwise keep a lawyer selectable alongside the applicant.
    if (!prefersLawyer && pool.applicants.length === 0) return pool.applicants;
    // P16/P45 are FACT-WITNESS affidavits (Rules 8b/18 boundary): the deponent
    // may be any recorded person with personal knowledge — a subscribing
    // witness, not necessarily the applicant (Nick 2026-09-01 directive, P16).
    // Every other contact joins the pool after the lawyer/applicant defaults.
    if (formCode === "P16" || formCode === "P45") {
      const listed = new Set([...pool.lawyers, ...pool.applicants].map((c) => String(c.id)));
      const witnesses = (contacts || []).filter((c) => c?.id && !listed.has(String(c.id)) && String(c.name || "").trim());
      return [...pool.lawyers, ...pool.applicants, ...witnesses];
    }
    // Lawyer first, then applicants — lawyer is a selectable alternative
    return [...pool.lawyers, ...pool.applicants];
  }, [pool, isP8, deponentField?.applicantsOnly, prefersLawyer, primaryAffidavitDeponentId, formCode, contacts]);

  const [deponentId, setDeponentId] = useState<string>("");
  const deponentSessionRef = useRef<{ estateId: string; formCode: string; initialDeponentId?: string } | null>(null);
  // Track whether the user has manually changed the deponent in this dialog
  // session — prevents auto-switching away from a deliberate choice when
  // firmSettings loads asynchronously.
  const [userChoseDeponent, setUserChoseDeponent] = useState(false);
  // Reset the manual-choice flag when the dialog opens/closes or form changes.
  useEffect(() => { if (!open) setUserChoseDeponent(false); }, [open, formCode]);
  // (Re)apply the default whenever the current selection is empty or invalid —
  // this also covers contacts loading after the dialog opened. When the
  // Settings lawyer loads (settingsLawyerName goes from "" to a real name),
  // re-select the lawyer UNLESS the user already made a manual choice.
  useEffect(() => {
    if (!open) {
      deponentSessionRef.current = null;
      return;
    }
    const previousSession = deponentSessionRef.current;
    const newP8Row = isP8 && (!previousSession
      || previousSession.estateId !== estateId
      || previousSession.formCode !== formCode
      || previousSession.initialDeponentId !== initialDeponentId);
    deponentSessionRef.current = { estateId, formCode, initialDeponentId };
    const valid = deponentId && candidates.some((c) => c.id === deponentId);
    if (!valid || newP8Row) {
      // A stale saved selection that is no longer a candidate (e.g. a lawyer
      // selection on an applicants-only affidavit) must not stick —
      // honour initialDeponentId only when the pool actually offers it.
      const validInitialId = initialDeponentId && candidates.some((c) => c.id === initialDeponentId)
        ? initialDeponentId
        : "";
      if (isP8) {
        setDeponentId(validInitialId || candidates[0]?.id || "");
        return;
      }
      const defaultPool = deponentField?.applicantsOnly ? { applicants: pool.applicants, lawyers: [] } : pool;
      setDeponentId(validInitialId || defaultDeponentId(defaultPool, prefersLawyer));
      return;
    }
    // If the user hasn't manually chosen and a lawyer just became available
    // (firmSettings loaded), switch to the lawyer default — but ONLY for forms
    // that default to the lawyer (P9). Applicant-sworn affidavits stay on the
    // applicant default (Nick ruling C, 2026-07-22).
    if (!userChoseDeponent && !isP8 && !deponentField?.applicantsOnly && prefersLawyer && pool.lawyers.length > 0) {
      const lawyerId = pool.lawyers[0].id || "";
      if (lawyerId && deponentId !== lawyerId) {
        setDeponentId(lawyerId);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, estateId, formCode, initialDeponentId, candidates, pool, isP8, deponentField?.applicantsOnly, prefersLawyer]);
  const deponentExtra = (): { selectedContactId?: string; deponentId?: string } => {
    if (!deponentField) return {};
    if (isP8) {
      // The primary applicant is never a fallback P8 deponent. Revalidate at
      // the click as well as in the selection effect, because contacts may
      // change while this dialog is open.
      const candidate = candidates.find((contact) => contact.id === deponentId)
        ?? candidates.find((contact) => contact.id === initialDeponentId)
        ?? candidates[0];
      return candidate?.id ? { deponentId: candidate.id } : {};
    }
    // Always resolve a value — fall back to the computed default so the server
    // never has to guess. Under Nick ruling C the default is the applicant for
    // applicant-sworn forms (prefersLawyer=false); only P9 falls back to the lawyer.
    const resolvedId = deponentId || defaultDeponentId(
      deponentField.applicantsOnly ? { applicants: pool.applicants, lawyers: [] } : pool,
      prefersLawyer
    );
    if (!resolvedId) return {};
    return deponentField.param === "deponentId" ? { deponentId: resolvedId } : { selectedContactId: resolvedId };
  };
  const hasAffidavitOrdinal = fields.some((field) => field.kind === "affidavitOrdinal");
  const [affidavitOrdinal, setAffidavitOrdinal] = useState("");
  useEffect(() => {
    if (open) setAffidavitOrdinal("");
  }, [open, estateId, formCode, initialDeponentId]);
  const detailsExtra = (): { selectedContactId?: string; deponentId?: string; affidavitOrdinal?: string } => {
    const ordinal = affidavitOrdinal.trim();
    return {
      ...deponentExtra(),
      ...(hasAffidavitOrdinal && ordinal ? { affidavitOrdinal: ordinal } : {}),
    };
  };

  // Hold Generate/Preview while any persisted write is in flight — the builders
  // read the DB, so generating mid-save could render the pre-edit value.
  const [deliveriesPending, setDeliveriesPending] = useState(false);
  const beforeDeliveryContinueRef = useRef<(() => Promise<boolean>) | null>(null);
  const [handoffPending, setHandoffPending] = useState(false);
  const handoffAttemptRef = useRef(0);
  const invalidateHandoff = (): void => {
    handoffAttemptRef.current += 1;
    setHandoffPending(false);
  };
  useEffect(() => {
    handoffAttemptRef.current += 1;
    setHandoffPending(false);
    return () => { handoffAttemptRef.current += 1; };
  }, [open, estateId, formCode, initialDeponentId]);
  const busy = queuedWrites > 0 || updateEstateMutation.isPending || deliveriesPending || handoffPending;

  // Persisted form-detail fields (below) commit on blur or selection, but a user can click
  // Generate/Preview right after typing without tabbing away first (K7) — the
  // estate column would then persist after (or race) generation, so the
  // builder renders the stale pre-edit value. Track dirty keystrokes here and
  // flush them through the same mutation before invoking the caller. Stays
  // fully synchronous when nothing is dirty, so the existing one-click forms
  // (and already-blurred fields) are unaffected.
  const [pendingPersisted, setPendingPersistedState] = useState<Record<string, string | number>>({});
  // Mirrored in a ref so a keystroke typed while flushThenRun awaits the P9
  // delivery check is still seen as dirty by that same in-flight call.
  const pendingPersistedRef = useRef<Record<string, string | number>>({});
  const setPendingPersisted = (update: Record<string, string | number> | ((prev: Record<string, string | number>) => Record<string, string | number>)): void => {
    const next = typeof update === "function" ? update(pendingPersistedRef.current) : update;
    pendingPersistedRef.current = next;
    setPendingPersistedState(next);
  };
  const savingPersistedRef = useRef<Record<string, string | number>>({});
  useEffect(() => {
    if (!open) return;
    setPendingPersisted({});
  }, [open, formCode, estateId]);

  const dirtyPersisted = (): Record<string, string | number> | null => {
    const dirty: Record<string, string | number> = {};
    for (const [column, raw] of Object.entries(pendingPersistedRef.current)) {
      const value = isP2CertifiedCopyColumn(column)
        ? p2CertifiedCopyQuantity(raw)
        : typeof raw === "number" ? raw : raw.trim();
      const current = estate?.[column];
      const unchanged = typeof value === "number"
        ? value === p2CertifiedCopyQuantity(current)
        : value === String(current ?? "");
      if (!unchanged && savingPersistedRef.current[column] !== value) dirty[column] = value;
    }
    return Object.keys(dirty).length > 0 ? dirty : null;
  };

  const commitPersisted = (column: string, rawValue: string | number): void => {
    const value = isP2CertifiedCopyColumn(column)
      ? p2CertifiedCopyQuantity(rawValue)
      : typeof rawValue === "number" ? rawValue : rawValue.trim();
    setPendingPersisted((prev) => ({ ...prev, [column]: value }));
    const current = estate?.[column];
    const unchanged = typeof value === "number"
      ? value === p2CertifiedCopyQuantity(current)
      : value === String(current ?? "");
    if (unchanged || savingPersistedRef.current[column] === value) return;
    savingPersistedRef.current[column] = value;
    void enqueueEstatePatch({ [column]: value }).then(() => {
      setPendingPersisted((prev) => {
        if (String(prev[column] ?? "").trim() !== String(value).trim()) return prev;
        const { [column]: _committed, ...rest } = prev;
        return rest;
      });
      if (savingPersistedRef.current[column] === value) delete savingPersistedRef.current[column];
    }).catch(() => {
      if (savingPersistedRef.current[column] === value) delete savingPersistedRef.current[column];
    });
  };

  const flushThenRun = async (action: (extra: { selectedContactId?: string; deponentId?: string; affidavitOrdinal?: string }) => void | Promise<void>) => {
    const attempt = ++handoffAttemptRef.current;
    const extra = detailsExtra();
    const runAction = (): void => {
      const reportFailure = (error: unknown): void => {
        toast.error(error instanceof Error ? error.message : "Unable to continue generating the form. Try again.");
      };
      // Keep the parent's dialog handoff detached, but observe its rejection
      // so a failed handoff cannot disappear without a user-visible error.
      try { void Promise.resolve(action(extra)).catch(reportFailure); }
      catch (error) { reportFailure(error); }
    };
    let dirty: Record<string, string | number> | null = null;
    setHandoffPending(true);
    try {
      if (formCode === "P9") {
        const deliveryReady = await beforeDeliveryContinueRef.current?.();
        if (!deliveryReady || handoffAttemptRef.current !== attempt) return;
      }
      // Read dirty keystrokes AFTER the P9 await so anything typed during the
      // delivery check still flushes before the builder reads the estate.
      dirty = dirtyPersisted();
      if (!dirty) {
        if (queuedWriteCountRef.current > 0) await writeQueueRef.current;
        if (handoffAttemptRef.current !== attempt) return;
        // Fire the parent's handler but do NOT await it — the parent closes this
        // dialog and opens the next one. Awaiting would keep this dialog mounted
        // with its Radix overlay competing against the new dialog's overlay,
        // causing a pointer-events deadlock (body pointer-events:none).
        runAction();
        return;
      }
      const flushed = dirty;
      for (const [column, value] of Object.entries(flushed)) savingPersistedRef.current[column] = value;
      await enqueueEstatePatch(flushed);
      setPendingPersisted((prev) => {
        const next = { ...prev };
        for (const key of Object.keys(flushed)) {
          if (String(next[key] ?? "").trim() === String(flushed[key]).trim()) delete next[key];
          if (savingPersistedRef.current[key] === flushed[key]) delete savingPersistedRef.current[key];
        }
        return next;
      });
      if (handoffAttemptRef.current !== attempt) return;
      runAction();
    } catch (err) {
      // The mutation's onError already shows the save failure. Release the
      // failed values so retry actually saves them instead of treating them
      // as an in-flight write and generating against the old estate record.
      for (const [column, value] of Object.entries(dirty ?? {})) {
        if (savingPersistedRef.current[column] === value) delete savingPersistedRef.current[column];
      }
      console.error("[FormDetailsDialog] flush failed:", err);
    } finally {
      if (handoffAttemptRef.current === attempt) setHandoffPending(false);
    }
  };

  // P8 opens per co-applicant — name the deponent in the title so the user
  // knows which affidavit they are confirming.
  const selectedDeponent = candidates.find((c) => c.id === deponentId);
  const selectedDeponentName = deponentField?.param === "deponentId"
    ? selectedDeponent?.name
    : undefined;
  const selectedIsLawyer = selectedDeponent ? contactHasRole(selectedDeponent, "lawyer") : false;
  // P15PLUS-004 (Nick ruling 2026-07-26, warn-only per Rule 8c): P16 ¶2 swears
  // "I was present when the will was signed" first-person — surface the
  // unconfirmed-presence state on the deponent picker.
  const warnP16Presence = formCode === "P16" && String((estate as any)?.p16DeponentPresentAtSigning || "") !== "yes";

  // Advisory only — the PreGenerateDialog downstream owns the authoritative gap list.
  // A failed check (e.g. the single-form P8 BAD_REQUEST) must not render as a
  // clean form: surface it, and do not retry a deterministic 400 four times.
  const { data: preflight, isError: preflightUnavailable } = trpc.document.preflight.useQuery(
    {
      estateId,
      formCode,
      signatureDate,
      selectedContactId: isP8 ? deponentExtra().deponentId : deponentField?.param === "selectedContactId" ? deponentId : undefined,
      ...(formCode === "P5" ? { generateAnyway: true } : {}),
    },
    { enabled: open && fields.length > 0, retry: false }
  );
  const gapCount = preflight && !preflight.ok ? preflight.gaps.length : 0;
  // Only a hard (applicability) gap is "required" — every soft gap is warn-only
  // under Rule 24 and the Contacts/Intake editors mark it optional. Calling all
  // of them "required fields" contradicted the form card (Nick 2026-09-02).
  const hardGapCount = preflight && !preflight.ok ? preflight.gaps.filter((g) => g.blocker === "hard").length : 0;

  const persistedFields = fields.filter((f): f is Extract<FormDetailsField, { kind: "persistedText" | "persistedSelect" | "persistedCheckboxGroup" }> => f.kind === "persistedText" || f.kind === "persistedSelect" || f.kind === "persistedCheckboxGroup");
  const hasDeliveries = fields.some((f) => f.kind === "deliveries");
  const hasOath = fields.some((f) => f.kind === "oath");
  const hasSignatory = fields.some((f) => f.kind === "signatory");
  const hasCertifiedCopies = fields.some((f) => f.kind === "certifiedCopies");
  const hasPersisted = hasOath || persistedFields.length > 0 || hasCertifiedCopies;
  const hasPriorityCheckboxGroup = persistedFields.some((f) => f.kind === "persistedCheckboxGroup");

  const isP9 = hasDeliveries;
  // Count top-row fields to determine grid columns
  const topRowFieldCount = (deponentField ? 1 : 0) + (hasSignatory ? 1 : 0) + (hasOath ? 1 : 0) + 1; // +1 for date (always present)
  const topRowGridClass = topRowFieldCount === 2
    ? "grid grid-cols-1 sm:grid-cols-2 gap-3"
    : topRowFieldCount === 3 && deponentField
      ? "grid grid-cols-1 sm:grid-cols-[2fr_1fr_1fr] gap-3"
      : "grid grid-cols-1 sm:grid-cols-3 gap-3";

  return (
    <Dialog open={open} onOpenChange={(nextOpen) => { if (!nextOpen) invalidateHandoff(); onOpenChange(nextOpen); }}>
      <DialogContent className={`max-h-[85vh] ${(isP9 || hasPriorityCheckboxGroup) ? "sm:max-w-2xl flex flex-col" : deponentField ? "sm:max-w-2xl" : "sm:max-w-xl"}`} data-testid="form-details-dialog">
        <DialogHeader>
          <DialogTitle>{formCode} — {formName}{selectedDeponentName ? ` — ${selectedDeponentName}` : ""}</DialogTitle>
          <DialogDescription>
            Confirm the details that print on this form.{hasPersisted ? " Changes save automatically." : ""}
          </DialogDescription>
        </DialogHeader>

        <div className={`space-y-4 ${(isP9 || hasPriorityCheckboxGroup) ? "overflow-y-auto flex-1 min-h-0 pr-1" : ""}`}>
          {/* Top row: the scalar details controls the form uses */}
          <div className={topRowGridClass}>
            {deponentField && (
              <div className="space-y-1 min-w-0 sm:col-span-1">
                <Label className="text-xs">{deponentField.param === "deponentId" ? "Co-applicant deponent" : "Deponent"}</Label>
                {deponentLoading ? (
                  <Skeleton className="h-9 w-full rounded-md" data-testid="form-details-deponent-skeleton" />
                ) : candidates.length === 0 ? (
                  <p className="flex items-start gap-1 text-[10px] text-amber-700 dark:text-amber-300 leading-tight animate-in fade-in duration-200" role="status" aria-live="polite" data-testid="form-details-no-deponent">
                    <AlertTriangle className="h-3 w-3 shrink-0 mt-px" aria-hidden="true" />
                    <span>{isP8
                      ? "No eligible co-applicant is recorded for P8. Add another applying applicant in Contacts before generating their supporting affidavit."
                      : "No applying applicant/executor recorded — this affidavit must be sworn by the applicant; it renders blank until you add one in Contacts."}</span>
                  </p>
                ) : candidates.length === 1 ? (
                  <p className="text-xs text-muted-foreground pt-1.5 animate-in fade-in duration-200" data-testid="form-details-single-deponent" title={candidates[0].name || "Unnamed"}>{candidates[0].name || "Unnamed"}</p>
                ) : (
                  <div className="animate-in fade-in duration-200">
                    <Select value={deponentId} onValueChange={(v) => { setUserChoseDeponent(true); setDeponentId(v); }}>
                      <SelectTrigger className="h-9 w-full" data-testid="form-details-deponent" title={selectedDeponent ? `${selectedDeponent.name || "Unnamed"}${contactHasRole(selectedDeponent, "lawyer") ? " (Lawyer)" : " (Applicant)"}` : ""}><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {candidates.map((c) => (
                          <SelectItem key={c.id} value={c.id}>
                            {c.name || "Unnamed"}{contactHasRole(c, "lawyer") ? " (Lawyer)" : " (Applicant)"}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
                <p className="text-[10px] text-muted-foreground leading-tight">{selectedIsLawyer ? "The lawyer who swears or affirms this affidavit." : "The applicant who swears or affirms this affidavit."}</p>
                {warnP16Presence && (
                  <p className="flex items-start gap-1 text-[10px] text-amber-700 dark:text-amber-300 leading-tight animate-in fade-in duration-200" role="status" aria-live="polite" data-testid="form-details-p16-presence-warning">
                    <AlertTriangle className="h-3 w-3 shrink-0 mt-px" aria-hidden="true" />
                    <span>P16 ¶2 swears "I was present when the will was signed." Confirm the chosen deponent was actually present (Rule 25-3(20)(a)/(21)(a) requires personal knowledge) — record it in Intake under Will alterations before swearing or filing.</span>
                  </p>
                )}
              </div>
            )}
            {hasSignatory && (
              <div className="space-y-1">
                <Label className="text-xs">Signatory</Label>
                <Select value={signatoryType} onValueChange={onSignatoryTypeChange}>
                  <SelectTrigger className="h-9 w-full" data-testid="form-details-signatory"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="executor">Executor (applicant)</SelectItem>
                    <SelectItem value="lawyer">Lawyer</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-[10px] text-muted-foreground leading-tight">Sets the address for service on the form.</p>
              </div>
            )}
            {hasOath && (
              <div className="space-y-1" role="group" aria-label="Oath">
                <Label className="text-xs">Oath</Label>
                {deponentLoading ? (
                  <Skeleton className="h-9 w-full rounded-md" data-testid="form-details-oath-skeleton" />
                ) : (
                  <div className="animate-in fade-in duration-200">
                    <TriToggle
                      value={estate?.oathType || "affirmed"}
                      onChange={(v) => { void enqueueEstatePatch({ oathType: v }).catch(() => undefined); }}
                      options={["affirmed", "sworn"]}
                      labels={["Affirmed", "Sworn"]}
                    />
                  </div>
                )}
                <p className="text-[10px] text-muted-foreground leading-tight">Sets the oath wording on all of this estate's affidavits: the opening statement ("I … AFFIRM THAT:"), the exhibit stamps, and the "AFFIRMED/SWORN BEFORE ME" signing block.</p>
              </div>
            )}
            <div className="space-y-1">
              <Label className="text-xs" htmlFor="form-details-date">{hasOath ? "Affidavit date" : "Signature date"}</Label>
              {deponentLoading ? (
                <Skeleton className="h-9 w-full rounded-md" data-testid="form-details-date-skeleton" />
              ) : (
                <Input
                  id="form-details-date"
                  type="date"
                  value={signatureDate}
                  onChange={(e) => onSignatureDateChange(e.target.value)}
                  className="h-9 animate-in fade-in duration-200"
                  data-testid="form-details-date"
                />
              )}
            </div>
            {hasAffidavitOrdinal && (
              <div className="space-y-1">
                <Label className="text-xs" htmlFor="form-details-affidavit-ordinal">Affidavit number (override)</Label>
                <Input
                  id="form-details-affidavit-ordinal"
                  inputMode="numeric"
                  value={affidavitOrdinal}
                  onChange={(event) => setAffidavitOrdinal(event.target.value)}
                  placeholder="Automatic"
                  className="h-9 animate-in fade-in duration-200"
                  data-testid="form-details-affidavit-ordinal"
                />
                <p className="text-[10px] text-muted-foreground leading-tight">Leave blank to count earlier affidavits for this deponent. Enter a positive number to use it for this document only.</p>
              </div>
            )}
          </div>

          {persistedFields.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {persistedFields.map((f) => (
                <div key={f.column} className={f.kind === "persistedCheckboxGroup" ? "space-y-1 sm:col-span-2" : "space-y-1"}>
                  {f.kind !== "persistedCheckboxGroup" && <Label className="text-xs" htmlFor={`form-details-${f.column}`}>{f.label}</Label>}
                  {f.kind === "persistedCheckboxGroup" ? (() => {
                    const selected = String(pendingPersisted[f.column] ?? estate?.[f.column] ?? "");
                    return (
                      <fieldset className="space-y-2 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm" data-testid={`form-details-${f.column}`}>
                        <legend className="px-1 text-xs font-medium">{f.legend}</legend>
                        {f.description && <p className="text-[11px] leading-relaxed text-muted-foreground">{f.description}</p>}
                        <div className="space-y-2">
                          {f.options.map((option) => {
                            const id = `form-details-${f.column}-${option.value.replace(".", "-")}`;
                            const checked = selected === option.value;
                            return (
                              <label key={option.value} htmlFor={id} className={`flex cursor-pointer items-start gap-2.5 rounded-lg border px-2.5 py-2 text-xs leading-relaxed transition-colors ${checked ? "border-primary/60 bg-primary/5 text-foreground" : "border-border/70 bg-background hover:border-primary/35"}`}>
                                <Checkbox
                                  id={id}
                                  checked={checked}
                                  onCheckedChange={(next) => commitPersisted(f.column, next === true ? option.value : "")}
                                  data-testid={id}
                                />
                                <span>{option.label}</span>
                              </label>
                            );
                          })}
                        </div>
                      </fieldset>
                    );
                  })() : f.kind === "persistedSelect" ? (
                    <Select value={String(pendingPersisted[f.column] ?? estate?.[f.column] ?? "unknown")} onValueChange={(value) => commitPersisted(f.column, value)}>
                      <SelectTrigger id={`form-details-${f.column}`} className="h-9" data-testid={`form-details-${f.column}`}><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {f.options.map((option) => <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  ) : (
                    <Input
                      id={`form-details-${f.column}`}
                      value={String(pendingPersisted[f.column] ?? estate?.[f.column] ?? "")}
                      placeholder={f.placeholder}
                      onChange={(e) => setPendingPersisted((prev) => ({ ...prev, [f.column]: e.target.value }))}
                      onBlur={(e) => commitPersisted(f.column, e.target.value)}
                      className="h-9"
                      data-testid={`form-details-${f.column}`}
                    />
                  )}
                  {f.kind !== "persistedCheckboxGroup" && f.description && <p className="text-[10px] text-muted-foreground leading-tight">{f.description}</p>}
                </div>
              ))}
            </div>
          )}

          {hasCertifiedCopies && (
            <fieldset className="space-y-2 rounded-xl border border-border/70 bg-background/70 p-3 shadow-sm" data-testid="form-details-certified-copies">
              <legend className="px-1 text-xs font-medium">Certified copies requested</legend>
              <p className="text-[11px] leading-relaxed text-muted-foreground">Select each official P2 request you need and enter its quantity. Unselected requests do not print.</p>
              <div className="space-y-2">
                {P2_CERTIFIED_COPY_FIELDS.map((field) => {
                  const rawRequested = pendingPersisted[field.column] ?? estate?.[field.column];
                  const hasPendingQuantity = Object.prototype.hasOwnProperty.call(pendingPersisted, field.column);
                  const requested = p2CertifiedCopyQuantity(rawRequested);
                  const checked = requested > 0;
                  const requestId = `form-details-${field.column}-request`;
                  return (
                    <div key={field.column} className="flex items-center gap-3 rounded-lg border border-border/70 bg-background px-2.5 py-2">
                      <Checkbox
                        id={requestId}
                        checked={checked}
                        onCheckedChange={(next) => commitPersisted(field.column, next === true ? Math.max(1, requested) : 0)}
                        data-testid={requestId}
                      />
                      <Label htmlFor={requestId} className="min-w-0 flex-1 cursor-pointer text-xs leading-snug">{field.label}</Label>
                      <div className="flex shrink-0 items-center gap-1.5">
                        <Label htmlFor={`form-details-${field.column}`} className="text-[10px] text-muted-foreground">Copies</Label>
                        <Input
                          id={`form-details-${field.column}`}
                          type="number"
                          inputMode="numeric"
                          min={1}
                          max={20}
                          disabled={!checked && !hasPendingQuantity}
                          value={checked ? requested : hasPendingQuantity && requested !== 0 ? String(rawRequested) : ""}
                          onChange={(event) => setPendingPersisted((previous) => ({ ...previous, [field.column]: event.target.value }))}
                          onBlur={(event) => commitPersisted(field.column, p2CertifiedCopyQuantity(event.target.value))}
                          className="h-8 w-16 text-right text-xs"
                          data-testid={`form-details-${field.column}`}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </fieldset>
          )}

          {formCode === "P9" && (
            <p className="text-[10px] leading-tight text-muted-foreground" data-testid="form-details-electronic-will-source">
              Electronic-will wording follows the Type of Will recorded in Intake.
            </p>
          )}

          {hasDeliveries && (
            <P9DeliveryChecklist estateId={estateId} estate={estate} contacts={contacts || []} enabled={open} onPendingChange={setDeliveriesPending} beforeContinueRef={beforeDeliveryContinueRef} />
          )}
        </div>

        {preflightUnavailable && (
          <p className="text-[10px] text-amber-700 dark:text-amber-300" role="status" aria-live="polite" data-testid="form-details-preflight-unavailable">
            Requirements could not be checked — Generate will re-check.
          </p>
        )}
        {gapCount > 0 && (
          <p className="text-[10px] text-muted-foreground" role="status" aria-live="polite" data-testid="form-details-gap-note">
            {gapCount} item{gapCount === 1 ? "" : "s"} to complete — you'll be prompted before generating{hardGapCount > 0 ? ` (${hardGapCount} required)` : " (none blocks generation)"}.
          </p>
        )}

        <DialogFooter className="gap-2">
          <Button variant="ghost" onClick={() => { invalidateHandoff(); onCancel(); }} data-testid="form-details-cancel">Cancel</Button>
          <Button variant="outline" onClick={() => { void flushThenRun(onPreview); }} disabled={busy} data-testid="form-details-preview">{handoffPending ? "Checking…" : "Preview"}</Button>
          <Button onClick={() => { void flushThenRun(onGenerate); }} disabled={generating === true || busy} data-testid="form-details-generate">
            {handoffPending ? "Checking…" : busy ? "Saving…" : "Generate"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Exported for testing.
export const __test = { deponentCandidates, defaultDeponentId, methodLabel };
