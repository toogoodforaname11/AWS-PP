import React from "react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { AdminFailureReports } from "./AdminFailureReports";

const mocks = vi.hoisted(() => ({
  reports: [] as Array<Record<string, unknown>>,
  detailItems: [] as Array<Record<string, unknown>>,
  trend: [] as Array<Record<string, unknown>>,
  summary: { total: 0, mostFrequentErrorCode: null as string | null, mostFrequentCount: 0, currentPeriodCount: 0, priorPeriodCount: 0 },
  lastDetailQuery: null as { startAt?: number; endExclusive?: number } | null,
  isLoading: false,
  resolve: vi.fn(),
  refetch: vi.fn(),
  toast: vi.fn(),
  clipboard: vi.fn(),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    failureReports: {
      list: { useQuery: () => ({ data: mocks.reports, isLoading: mocks.isLoading, refetch: mocks.refetch }) },
      summary: { useQuery: () => ({ data: mocks.summary, isLoading: mocks.isLoading, refetch: mocks.refetch }) },
      detailPage: {
        useQuery: (input: { page: number; source?: string; status?: string; startAt?: number; endExclusive?: number; search?: string }) => {
          mocks.lastDetailQuery = input;
          const matching = mocks.detailItems.filter((item) => {
            const occurredAt = Number(item.occurredAt);
            const searchable = [item.source, item.errorCode, item.operation, item.formCode].filter(Boolean).join(" ").toLowerCase();
            return (!input.source || item.source === input.source)
              && (!input.status || item.reportStatus === input.status)
              && (input.startAt === undefined || occurredAt >= input.startAt)
              && (input.endExclusive === undefined || occurredAt < input.endExclusive)
              && (!input.search || searchable.includes(input.search.toLowerCase()));
          });
          return { data: { items: matching.slice((input.page - 1) * 8, input.page * 8), total: matching.length }, isLoading: mocks.isLoading, refetch: mocks.refetch };
        },
      },
      trend: { useQuery: () => ({ data: mocks.trend, isLoading: false, refetch: mocks.refetch }) },
      resolve: { useMutation: (options: any) => ({ mutate: (input: unknown) => { mocks.resolve(input); options?.onSuccess?.({ success: true }); }, isPending: false }) },
    },
  },
}));
vi.mock("sonner", () => ({ toast: { success: mocks.toast, error: mocks.toast } }));
Object.assign(navigator, { clipboard: { writeText: mocks.clipboard } });

afterEach(() => {
  mocks.reports = []; mocks.detailItems = []; mocks.trend = [];
  mocks.summary = { total: 0, mostFrequentErrorCode: null, mostFrequentCount: 0, currentPeriodCount: 0, priorPeriodCount: 0 }; mocks.lastDetailQuery = null;
  mocks.isLoading = false; mocks.resolve.mockReset(); mocks.refetch.mockReset(); mocks.toast.mockReset(); mocks.clipboard.mockReset();
});

describe("AdminFailureReports", () => {
  it("presents a structured all-clear operations view with the detailed log collapsed", () => {
    render(<AdminFailureReports />);
    expect(screen.getByText("Failures & crash reports")).toBeTruthy();
    expect(screen.getByText("Failure frequency · last 7 days")).toBeTruthy();
    expect(screen.getByText("No failure reports in this view")).toBeTruthy();
    expect(screen.getByLabelText("Failure report summary").textContent).toContain("No prior 7-day baseline");
    expect((screen.getByTestId("failure-detail-log") as HTMLDetailsElement).open).toBe(false);
  });

  it("shows total records and the most frequent bounded category in the summary card", () => {
    mocks.summary = { total: 7, mostFrequentErrorCode: "provider_failure", mostFrequentCount: 4, currentPeriodCount: 5, priorPeriodCount: 2 };
    render(<AdminFailureReports />);
    const summary = screen.getByLabelText("Failure report summary");
    expect(summary.textContent).toContain("Total failure records7");
    expect(summary.textContent).toContain("Most frequent categoryProvider Failure4 records");
    expect(summary.textContent).toContain("3 more than prior 7 days");
  });

  it("distinguishes decreasing and unchanged comparison windows", () => {
    mocks.summary = { total: 8, mostFrequentErrorCode: "render_failure", mostFrequentCount: 4, currentPeriodCount: 2, priorPeriodCount: 5 };
    const { rerender } = render(<AdminFailureReports />);
    expect(screen.getByLabelText("Failure report summary").textContent).toContain("3 fewer than prior 7 days");
    mocks.summary = { total: 8, mostFrequentErrorCode: "render_failure", mostFrequentCount: 4, currentPeriodCount: 4, priorPeriodCount: 4 };
    rerender(<AdminFailureReports />);
    expect(screen.getByLabelText("Failure report summary").textContent).toContain("Unchanged from prior 7 days");
  });

  it("shows a truthful detail-log loading indicator before failure records resolve", () => {
    mocks.isLoading = true;
    render(<AdminFailureReports />);
    const detailLog = screen.getByTestId("failure-detail-log") as HTMLDetailsElement;
    expect(detailLog.open).toBe(false);
    expect(screen.getByRole("status", { name: "Loading detailed failure log" })).toBeTruthy();
    expect(screen.queryByText("No failure records match the current source and state filters.")).toBeNull();
  });

  it("renders bounded document/chatbot failure metadata, filters by source, searches safe fields, and resolves an open report", async () => {
    mocks.reports = [
      { id: "doc", source: "document_generation", operation: "download_form", errorCode: "render_failure", userId: 8, reporterEmail: "lawyer@example.test", estateId: "opaque-estate", formCode: "P2", reportStatus: "open", occurredAt: Date.now() },
      { id: "chat", source: "chatbot", operation: "chat_turn", errorCode: "provider_failure", userId: 8, reporterEmail: "lawyer@example.test", estateId: "", formCode: "", reportStatus: "resolved", occurredAt: Date.now() },
    ];
    mocks.summary = { total: 10, mostFrequentErrorCode: "render_failure", mostFrequentCount: 9, currentPeriodCount: 3, priorPeriodCount: 4 };
    mocks.detailItems = Array.from({ length: 10 }, (_, index) => index === 9 ? { ...mocks.reports[1], occurredAt: new Date(2026, 7, 26).getTime() } : { ...mocks.reports[0], id: `doc-${index}`, occurredAt: new Date(2026, 7, 20).getTime() });
    const today = Math.floor(Date.now() / 86_400_000);
    mocks.trend = [{ day: today, source: "chatbot", count: 2 }, { day: today, source: "document_generation", count: 1 }];
    render(<AdminFailureReports />);
    expect(screen.getByRole("group", { name: /7-day chatbot and document-generation failure frequency/i })).toBeTruthy();
    const chartDay = screen.getByLabelText(/2 chatbot failures, 1 document-generation failures/i);
    fireEvent.focus(chartDay);
    expect(screen.getByRole("tooltip").textContent).toContain("Chatbot2");
    expect(screen.getByRole("tooltip").textContent).toContain("Document generation1");
    expect(screen.getByRole("tooltip").textContent).toContain("Total3");
    fireEvent.blur(chartDay);
    const detailLog = screen.getByTestId("failure-detail-log") as HTMLDetailsElement;
    fireEvent.change(screen.getByLabelText("Failure detail log from date"), { target: { value: "2026-08-20" } });
    fireEvent.change(screen.getByLabelText("Failure detail log to date"), { target: { value: "2026-08-21" } });
    fireEvent.click(chartDay);
    const selectedDate = new Date(today * 86_400_000).toISOString().slice(0, 10);
    expect(chartDay.getAttribute("aria-pressed")).toBe("true");
    expect(detailLog.textContent).toContain(`Chart day selected: ${selectedDate}. The log is filtered to this exact UTC day.`);
    expect((screen.getByLabelText("Failure detail log from date") as HTMLInputElement).value).toBe(selectedDate);
    expect((screen.getByLabelText("Failure detail log to date") as HTMLInputElement).value).toBe(selectedDate);
    expect(mocks.lastDetailQuery).toMatchObject({ startAt: today * 86_400_000, endExclusive: (today + 1) * 86_400_000 });
    fireEvent.click(screen.getByRole("button", { name: "Clear chart date selection" }));
    expect(chartDay.getAttribute("aria-pressed")).toBe("false");
    expect((screen.getByLabelText("Failure detail log from date") as HTMLInputElement).value).toBe("2026-08-20");
    expect((screen.getByLabelText("Failure detail log to date") as HTMLInputElement).value).toBe("2026-08-21");
    fireEvent.click(screen.getByRole("button", { name: "Clear dates" }));
    fireEvent.click(screen.getByText("Detailed operational log"));
    expect(detailLog.open).toBe(true);
    expect(screen.getByText("Showing 1–8 of 10 records")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Next failure detail page" }));
    expect(screen.getByText("Showing 9–10 of 10 records")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Previous failure detail page" }));
    expect(screen.getByText("Showing 1–8 of 10 records")).toBeTruthy();
    fireEvent.click(within(detailLog).getByLabelText("Filter detailed failure log by source"));
    fireEvent.click(screen.getByRole("option", { name: "Chatbot" }));
    expect(within(detailLog).getByText("Showing 1–1 of 1 records")).toBeTruthy();
    expect(within(detailLog).queryAllByText(/document generation.*render failure/i).length).toBe(0);
    fireEvent.change(within(detailLog).getByLabelText("Failure detail log from date"), { target: { value: "2026-08-26" } });
    fireEvent.change(within(detailLog).getByLabelText("Failure detail log to date"), { target: { value: "2026-08-26" } });
    fireEvent.click(within(detailLog).getByRole("button", { name: "Clear dates" }));
    fireEvent.change(within(detailLog).getByLabelText("Search detailed failure log"), { target: { value: "provider" } });
    expect(within(detailLog).getByText("Searching…")).toBeTruthy();
    await new Promise((resolve) => setTimeout(resolve, 300));
    mocks.clipboard.mockResolvedValue(undefined);
    fireEvent.click(within(detailLog).getByRole("button", { name: /copy safe details for chatbot provider failure/i }));
    await waitFor(() => expect(within(detailLog).getByText("Copied")).toBeTruthy());
    expect(mocks.clipboard).toHaveBeenCalledWith(expect.stringContaining("Operational detail: The assistant provider did not complete the requested chat turn."));
    expect(mocks.clipboard.mock.calls[0]?.[0]).not.toContain("lawyer@example.test");
    expect(screen.queryByText("Generation failed for SIN 123-456-789")).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "Mark resolved" }));
    expect(mocks.resolve).toHaveBeenCalledWith({ id: "doc" });
  });
});
