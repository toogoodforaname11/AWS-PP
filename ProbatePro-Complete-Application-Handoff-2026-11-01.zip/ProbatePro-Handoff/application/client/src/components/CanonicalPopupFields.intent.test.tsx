import React, { useState } from "react";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { checkFormRequirements } from "../../../shared/formRequirements";
import { coupleWillFilingTypeFacts } from "../../../shared/types";
import { PreGenerateDialog } from "./PreGenerateDialog";

function gate() {
  let release!: () => void;
  const promise = new Promise<void>(resolve => { release = resolve; });
  return { promise, release };
}
function mount(options: { waitSave?: Promise<void>; waitRecheck?: Promise<void>; loseFirstResponse?: boolean; failFirstRecheck?: boolean } = {}) {
  const initial: any = { id: "fictional-input-intent", revision: 1, hasWill: 1, willStatus: "will",
    grantType: "grant_of_probate", willType: "", isElectronicWill: 0, willFilingType: "", deceasedLastName: "" };
  const inspect = (estate: any) => checkFormRequirements("P4", { estate, contacts: [], inventory: [], requiredDocuments: [], requiredCatalog: [] });
  let stored = initial;
  const writes: any[] = [], newerAtRecheck: boolean[] = [];
  const apply = vi.fn();
  function Fixture() {
    const [estate, setEstate] = useState(initial);
    const [report, setReport] = useState(inspect(initial));
    apply.mockImplementation(async (...args: any[]) => {
      if (options.waitSave) await options.waitSave;
      const values = args[0] ?? {}, canonical = args[5] ?? {}, observer = args[6];
      const patch = coupleWillFilingTypeFacts({ ...coupleWillFilingTypeFacts(values), ...canonical }, stored);
      if (Object.keys(patch).length) {
        writes.push(patch);
        stored = { ...stored, ...patch, revision: stored.revision + 1 };
        setEstate(stored);
        if (options.loseFirstResponse && writes.length === 1) return false;
        if (Object.keys(canonical).length) observer?.onSaved({ estateId: stored.id, revision: stored.revision, record: stored });
      }
      if (options.waitRecheck) await options.waitRecheck;
      if (options.failFirstRecheck && writes.length === 1) return false;
      newerAtRecheck.push(observer?.hasNewerEdits?.() === true);
      observer?.onRechecked();
      setReport(inspect(stored));
      return true;
    });
    return <PreGenerateDialog open formName="P4" reports={[report]} estate={estate} contacts={[]}
      inlineEditingEnabled onApplyInline={apply} onProceed={vi.fn()} onOpenChange={vi.fn()} onCancel={vi.fn()} onJumpToTab={vi.fn()} />;
  }
  render(<Fixture />);
  return { apply, writes, newerAtRecheck, stored: () => stored };
}
async function choose(id: string, label: string) {
  fireEvent.click(screen.getByTestId(id));
  fireEvent.click(await screen.findByRole("option", { name: label }));
}
async function mixedOriginal() {
  await choose("pre-generate-canonical-willType", "Physical");
  await choose("pre-generate-input-willFilingType", "The electronic original.");
}
const applyButton = () => screen.getByTestId("pre-generate-apply");
const medium = () => screen.getByTestId("pre-generate-canonical-willType") as HTMLButtonElement;
beforeEach(() => {
  cleanup();
  for (const [key, value] of Object.entries({ hasPointerCapture: (): boolean => false, setPointerCapture: (): void => {}, releasePointerCapture: (): void => {}, scrollIntoView: (): void => {} })) Object.defineProperty(Element.prototype, key, { value, configurable: true });
});
afterEach(cleanup);

describe("effective canonical input identity across acknowledgement boundaries", () => {
  it("supplies newer-input protection when the first submission changes only the generic filing value", async () => {
    const save = gate(); const h = mount({ waitSave: save.promise });
    await choose("pre-generate-input-willFilingType", "The electronic original.");
    fireEvent.click(applyButton());
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(1));
    expect(h.apply.mock.calls[0][5] ?? {}).toEqual({});
    await choose("pre-generate-input-willFilingType", "A copy (original lost/destroyed).");
    await choose("pre-generate-canonical-willType", "Physical");
    await act(async () => { save.release(); });
    expect(h.newerAtRecheck).toEqual([true]);
    expect(medium().textContent).toContain("Physical");
    fireEvent.click(applyButton());
    await waitFor(() => expect(h.writes).toHaveLength(2));
    expect(h.stored()).toMatchObject({ willType: "physical", isElectronicWill: 0, willFilingType: "copy" });
  });

  it("recognizes a genuinely newer post-acknowledgement correction that equals the old raw pre-coupling draft", async () => {
    const recheck = gate(); const h = mount({ waitRecheck: recheck.promise });
    await mixedOriginal(); fireEvent.click(applyButton());
    await waitFor(() => expect(h.writes).toHaveLength(1));
    await waitFor(() => expect(medium().disabled).toBe(false));
    expect(medium().textContent).toContain("Electronic");
    await choose("pre-generate-canonical-willType", "Physical");
    await act(async () => { recheck.release(); });
    expect(h.newerAtRecheck).toEqual([true]);
    expect(medium().textContent).toContain("Physical");
    fireEvent.click(applyButton());
    await waitFor(() => expect(h.writes).toHaveLength(2));
    expect(h.stored()).toMatchObject({ willType: "physical", isElectronicWill: 0 });
  });

  it("does not resurrect the pre-coupling medium on an unchanged retry after a committed write loses its acknowledgement", async () => {
    const h = mount({ loseFirstResponse: true });
    await mixedOriginal(); fireEvent.click(applyButton());
    await waitFor(() => expect(h.writes).toHaveLength(1));
    expect(h.stored()).toMatchObject({ willType: "electronic", isElectronicWill: 1, willFilingType: "electronic_original" });
    await act(async () => { await Promise.resolve(); });
    fireEvent.click(applyButton());
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(2));
    expect(h.stored()).toMatchObject({ willType: "electronic", isElectronicWill: 1, willFilingType: "electronic_original" });
    expect(h.writes.every(patch => patch.willType !== "physical")).toBe(true);
  });

  it("permits an explicit new Copy intent after an uncertain original write, rather than pinning the older submitted medium", async () => {
    const h = mount({ loseFirstResponse: true });
    await mixedOriginal(); fireEvent.click(applyButton());
    await waitFor(() => expect(h.writes).toHaveLength(1));
    await choose("pre-generate-input-willFilingType", "A copy (original lost/destroyed).");
    expect(medium().textContent).toContain("Physical");
    fireEvent.click(applyButton());
    await waitFor(() => expect(h.writes).toHaveLength(2));
    expect(h.stored()).toMatchObject({ willType: "physical", isElectronicWill: 0, willFilingType: "copy" });
  });

  it("does not treat a post-acknowledgement edit restored to the effective saved answer as pending different facts", async () => {
    const recheck = gate(); const h = mount({ waitRecheck: recheck.promise });
    await mixedOriginal(); fireEvent.click(applyButton());
    await waitFor(() => expect(h.writes).toHaveLength(1));
    await waitFor(() => expect(medium().disabled).toBe(false));
    await choose("pre-generate-canonical-willType", "Physical");
    await choose("pre-generate-canonical-willType", "Electronic");
    await act(async () => { recheck.release(); });
    expect(h.newerAtRecheck).toEqual([false]);
    expect(h.writes).toHaveLength(1);
    expect(h.stored().willType).toBe("electronic");
  });

  it.each([false, true])("keeps the effective original intent after an in-flight Copy-to-original cycle (lost acknowledgement: %s)", async (lost) => {
    const save = gate();
    const h = mount({ waitSave: save.promise, loseFirstResponse: lost, failFirstRecheck: !lost });
    await mixedOriginal(); fireEvent.click(applyButton());
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(1));
    await choose("pre-generate-input-willFilingType", "A copy (original lost/destroyed).");
    await choose("pre-generate-input-willFilingType", "The electronic original.");
    expect(medium().textContent).toContain("Electronic");
    await act(async () => { save.release(); });
    expect(h.stored().willType).toBe("electronic");
    expect(medium().textContent).toContain("Electronic");
    fireEvent.click(applyButton());
    await waitFor(() => expect(h.apply).toHaveBeenCalledTimes(2));
    expect(h.stored().willType).toBe("electronic");
    expect(h.writes.every(patch => patch.willType !== "physical")).toBe(true);
  });
});
