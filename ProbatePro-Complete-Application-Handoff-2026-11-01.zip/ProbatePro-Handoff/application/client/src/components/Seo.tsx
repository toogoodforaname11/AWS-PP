import { useEffect } from "react";

export const PUBLIC_SITE_ORIGIN = "https://probate-pro.com";
export const DEFAULT_OG_IMAGE = `${PUBLIC_SITE_ORIGIN}/manus-storage/og-image_0e2b3000.png`;

type StructuredData = Record<string, unknown>;

type SeoProps = {
  title: string;
  description: string;
  path: string;
  index: boolean;
  structuredData?: StructuredData;
};

function canonicalUrl(path: string) {
  const url = new URL(path, PUBLIC_SITE_ORIGIN);
  return `${PUBLIC_SITE_ORIGIN}${url.pathname === "/" ? "/" : url.pathname.replace(/\/$/, "")}`;
}

function upsertMeta(attribute: "name" | "property", key: string, content: string) {
  const selector = `meta[${attribute}="${key}"]`;
  let node = document.head.querySelector(selector) as HTMLMetaElement | null;
  if (!node) {
    node = document.createElement("meta");
    node.setAttribute(attribute, key);
    document.head.appendChild(node);
  }
  node.dataset.probateproSeo = `${attribute}:${key}`;
  node.content = content;
}

function upsertCanonical(href: string) {
  let node = document.head.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
  if (!node) {
    node = document.createElement("link");
    node.rel = "canonical";
    document.head.appendChild(node);
  }
  node.dataset.probateproSeo = "canonical";
  node.href = href;
}

function upsertStructuredData(structuredData?: StructuredData) {
  const selector = 'script[type="application/ld+json"][data-probatepro-seo="structured-data"]';
  const current = document.head.querySelector(selector) as HTMLScriptElement | null;

  if (!structuredData) {
    current?.remove();
    return;
  }

  const node = current ?? document.createElement("script");
  node.type = "application/ld+json";
  node.dataset.probateproSeo = "structured-data";
  node.textContent = JSON.stringify(structuredData).replace(/</g, "\\u003c");
  if (!current) document.head.appendChild(node);
}

/**
 * Updates only the document head. Public pages opt into indexability; account
 * routes explicitly opt out so estate data and workspace controls are never SEO content.
 */
export function Seo({ title, description, path, index, structuredData }: SeoProps) {
  useEffect(() => {
    const canonical = canonicalUrl(path);
    document.title = title;
    upsertMeta("name", "description", description);
    upsertMeta("name", "robots", index ? "index, follow" : "noindex, nofollow");
    upsertMeta("property", "og:type", "website");
    upsertMeta("property", "og:title", title);
    upsertMeta("property", "og:description", description);
    upsertMeta("property", "og:url", canonical);
    upsertMeta("property", "og:site_name", "ProbatePro");
    upsertMeta("property", "og:image", DEFAULT_OG_IMAGE);
    upsertMeta("name", "twitter:card", "summary_large_image");
    upsertMeta("name", "twitter:title", title);
    upsertMeta("name", "twitter:description", description);
    upsertMeta("name", "twitter:image", DEFAULT_OG_IMAGE);
    upsertCanonical(canonical);
    upsertStructuredData(structuredData);
  }, [description, index, path, structuredData, title]);

  return null;
}
