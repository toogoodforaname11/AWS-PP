import React from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen } from "@testing-library/react";

const mocks = vi.hoisted(() => ({
  query: vi.fn(),
  update: vi.fn(),
  invalidate: vi.fn(),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    useUtils: () => ({
      clientIntake: { questions: { invalidate: mocks.invalidate } },
    }),
    clientIntake: {
      questions: {
        useQuery: (input: unknown) => {
          mocks.query(input);
          return {
            data: {
              revision: 7,
              questions: [
                {
                  id: "cq_propertyfact1",
                  prompt: "Who has keys to the property?",
                  helpText: "",
                  required: false,
                },
              ],
            },
            isLoading: false,
            isError: false,
          };
        },
      },
      updateQuestions: {
        useMutation: () => ({ mutate: mocks.update, isPending: false }),
      },
    },
  },
}));

import { ClientIntakeQuestions } from "./ClientIntakeQuestions";

beforeEach(() => vi.clearAllMocks());

describe("ClientIntakeQuestions", () => {
  it("keeps authoring scoped to the estate and saves a required case-specific question", () => {
    render(<ClientIntakeQuestions estateId="estate-1" revision={7} />);
    expect(mocks.query).toHaveBeenCalledWith({ estateId: "estate-1" });
    expect(
      (screen.getByLabelText("Question 1") as HTMLTextAreaElement).value
    ).toBe("Who has keys to the property?");

    fireEvent.click(screen.getByRole("button", { name: /add question/i }));
    fireEvent.change(screen.getByLabelText("Question 2"), {
      target: { value: "Has the property been insured since the death?" },
    });
    fireEvent.click(
      screen.getAllByRole("checkbox", {
        name: "Client must answer this question",
      })[1]
    );
    fireEvent.click(screen.getByRole("button", { name: /save questions/i }));

    expect(mocks.update).toHaveBeenCalledWith({
      estateId: "estate-1",
      expectedRevision: 7,
      questions: [
        {
          id: "cq_propertyfact1",
          prompt: "Who has keys to the property?",
          helpText: "",
          required: false,
        },
        expect.objectContaining({
          prompt: "Has the property been insured since the death?",
          helpText: "",
          required: true,
        }),
      ],
    });
  });
});
