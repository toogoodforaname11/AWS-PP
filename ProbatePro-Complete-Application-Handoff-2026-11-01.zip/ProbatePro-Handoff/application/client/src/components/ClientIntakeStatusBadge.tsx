import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Clock3, MessageSquareMore } from "lucide-react";
import React from "react";

const STATUS_CONFIG = {
  submitted: {
    label: "Under Review",
    detail: "Your legal team is reviewing the details you sent.",
    icon: Clock3,
    className: "border-sky-500/30 bg-sky-500/10 text-sky-800 dark:text-sky-200",
  },
  revision_requested: {
    label: "Pending Revision",
    detail: "Your legal team requested updated details from you.",
    icon: MessageSquareMore,
    className: "border-amber-500/30 bg-amber-500/10 text-amber-900 dark:text-amber-200",
  },
  approved: {
    label: "Approved",
    detail: "Your legal team approved the selected details.",
    icon: CheckCircle2,
    className: "border-emerald-500/30 bg-emerald-500/10 text-emerald-900 dark:text-emerald-200",
  },
} as const;

export type ClientIntakeStatus = keyof typeof STATUS_CONFIG;

export function getClientIntakeStatus(status: string): ClientIntakeStatus {
  return status === "revision_requested" || status === "approved" ? status : "submitted";
}

export function ClientIntakeStatusBadge({ status }: { status: string }) {
  const config = STATUS_CONFIG[getClientIntakeStatus(status)];
  const Icon = config.icon;
  return <Badge variant="outline" aria-label={`Intake status: ${config.label}`} className={`gap-1.5 px-2 py-1 text-xs font-medium ${config.className}`}>
    <Icon className="h-3.5 w-3.5" aria-hidden="true" />
    {config.label}
  </Badge>;
}

export function getClientIntakeStatusDetail(status: string) {
  return STATUS_CONFIG[getClientIntakeStatus(status)].detail;
}
