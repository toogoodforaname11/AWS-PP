import * as React from "react";
import { useState, useRef, useCallback } from "react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { trpc } from "@/lib/trpc";

// Suggestions come from the server's maps proxy (trpc maps.autocomplete /
// maps.placeDetails). The previous implementation loaded the Google Maps JS
// SDK client-side with a VITE_ build-time key that was never set in any
// deployment, so autocomplete silently never worked; the server's Forge
// credentials (the same pair storage uses) are the ones that actually exist.

interface Suggestion {
  placeId: string;
  description: string;
  mainText: string;
  secondaryText: string;
}

export interface AddressComponents {
  street: string;
  unit: string;
  city: string;
  province: string;
  postalCode: string;
  country: string;
  fullAddress: string;
}

interface AddressAutocompleteProps {
  value: string;
  onChange: (value: string) => void;
  onSelect?: (components: AddressComponents) => void;
  onInputEdit?: (value: string, target: HTMLInputElement) => void;
  inputId?: string;
  ariaInvalid?: boolean;
  ariaDescribedBy?: string;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
}

export function AddressAutocomplete({
  value,
  onChange,
  onSelect,
  onInputEdit,
  inputId,
  ariaInvalid,
  ariaDescribedBy,
  placeholder = "Enter street address (e.g. 1450 West Georgia St)",
  className,
  disabled,
}: AddressAutocompleteProps) {
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(-1);
  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const suppressNextSearch = useRef(false);
  // Monotonic sequence so a slow older response can never clobber a newer one
  const searchSeq = useRef(0);
  const utils = trpc.useUtils();

  // Close suggestions on outside click
  React.useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const searchPlaces = useCallback(async (query: string) => {
    if (query.length < 3) {
      setSuggestions([]);
      return;
    }
    const seq = ++searchSeq.current;
    setIsLoading(true);
    try {
      const { suggestions: results } = await utils.maps.autocomplete.fetch({ input: query });
      if (seq !== searchSeq.current) return; // stale response
      setSuggestions(results);
      setShowSuggestions(results.length > 0);
    } catch {
      if (seq === searchSeq.current) setSuggestions([]);
    } finally {
      if (seq === searchSeq.current) setIsLoading(false);
    }
  }, [utils]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    onChange(val);
    onInputEdit?.(val, e.currentTarget);

    if (suppressNextSearch.current) {
      suppressNextSearch.current = false;
      return;
    }

    // Debounce the search
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    debounceTimer.current = setTimeout(() => {
      void searchPlaces(val);
    }, 300);
  };

  const handleSelect = async (suggestion: Suggestion) => {
    suppressNextSearch.current = true;
    searchSeq.current++; // cancel any in-flight search
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    onChange(suggestion.mainText);
    setShowSuggestions(false);
    setSuggestions([]);
    setHighlightedIndex(-1);

    if (!onSelect) return;
    try {
      const { details } = await utils.maps.placeDetails.fetch({ placeId: suggestion.placeId });
      if (details?.addressComponents) {
        const components = parseAddressComponents(details.addressComponents);
        components.fullAddress = details.formattedAddress || suggestion.description;
        onSelect(components);
      }
    } catch {
      // The street text is already in the field; remaining fields stay manual
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!showSuggestions || suggestions.length === 0) return;

    if (e.key === "ArrowDown") {
      e.preventDefault();
      setHighlightedIndex((prev) => (prev < suggestions.length - 1 ? prev + 1 : 0));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setHighlightedIndex((prev) => (prev > 0 ? prev - 1 : suggestions.length - 1));
    } else if (e.key === "Enter" && highlightedIndex >= 0) {
      e.preventDefault();
      void handleSelect(suggestions[highlightedIndex]);
    } else if (e.key === "Escape") {
      setShowSuggestions(false);
    }
  };

  // On blur, if the user typed a full address with commas but never selected a suggestion,
  // attempt to parse it into components so city/province/postal get populated.
  const handleBlur = () => {
    setShowSuggestions(false);
    if (!onSelect || !value || value.trim().length < 5) return;
    // Only attempt parse if value contains a comma (suggests full address typed)
    if (!value.includes(",")) return;
    const parts = value.split(",").map(s => s.trim()).filter(Boolean);
    if (parts.length >= 2) {
      // Heuristic: "street, city, province postalCode" or "street, city, province, postalCode"
      const street = parts[0];
      const city = parts[1] || "";
      let province = "";
      let postalCode = "";
      if (parts.length >= 3) {
        // parts[2] might be "BC V6G 2T8" or just "BC"
        const provPostal = parts[2].match(/^([A-Za-z]{2})\s+([A-Z]\d[A-Z]\s*\d[A-Z]\d)$/);
        if (provPostal) {
          province = provPostal[1].toUpperCase();
          postalCode = provPostal[2];
        } else {
          province = parts[2];
        }
      }
      if (parts.length >= 4) {
        // parts[3] is likely postal code
        const pc = parts[3].replace(/\s+/g, " ").trim();
        if (/^[A-Z]\d[A-Z]\s*\d[A-Z]\d$/i.test(pc)) postalCode = pc;
      }
      // Only fire onSelect if we parsed something beyond just the street
      if (city) {
        onSelect({
          street,
          unit: "",
          city,
          province,
          postalCode,
          country: province ? "Canada" : "",
          fullAddress: value,
        });
        // Update the displayed value to just the street portion
        onChange(street);
      }
    }
  };

  return (
    <div ref={containerRef} className="relative">
      <Input
        ref={inputRef}
        id={inputId}
        type="text"
        value={value}
        onChange={handleInputChange}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
        onFocus={() => {
          if (suggestions.length > 0) setShowSuggestions(true);
        }}
        placeholder={placeholder}
        className={cn("h-9", className)}
        disabled={disabled}
        aria-invalid={ariaInvalid || undefined}
        aria-describedby={ariaDescribedBy}
        autoComplete="off"
      />
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute z-50 top-full left-0 right-0 mt-1 bg-popover border border-border rounded-md shadow-md overflow-hidden">
          {suggestions.map((s, i) => (
            <button
              key={s.placeId}
              type="button"
              className={cn(
                "w-full text-left px-3 py-2 text-sm transition-colors hover:bg-accent",
                i === highlightedIndex && "bg-accent"
              )}
              onMouseDown={(e) => {
                e.preventDefault(); // Prevent blur before click
                void handleSelect(s);
              }}
              onMouseEnter={() => setHighlightedIndex(i)}
            >
              <span className="font-medium">{s.mainText}</span>
              <span className="text-muted-foreground text-xs ml-1">{s.secondaryText}</span>
            </button>
          ))}
          {isLoading && (
            <div className="px-3 py-2 text-xs text-muted-foreground">Searching...</div>
          )}
        </div>
      )}
    </div>
  );
}

function parseAddressComponents(
  components: Array<{ long_name: string; short_name: string; types: string[] }>
): AddressComponents {
  const result: AddressComponents = {
    street: "",
    unit: "",
    city: "",
    province: "",
    postalCode: "",
    country: "",
    fullAddress: "",
  };

  let streetNumber = "";
  let route = "";

  for (const comp of components) {
    const types = comp.types;
    if (types.includes("street_number")) {
      streetNumber = comp.long_name;
    } else if (types.includes("route")) {
      route = comp.long_name;
    } else if (types.includes("subpremise")) {
      result.unit = comp.long_name;
    } else if (types.includes("locality")) {
      result.city = comp.long_name;
    } else if (types.includes("administrative_area_level_1")) {
      result.province = comp.short_name; // e.g. "BC"
    } else if (types.includes("postal_code")) {
      result.postalCode = comp.long_name;
    } else if (types.includes("country")) {
      result.country = comp.long_name;
    }
  }

  result.street = [streetNumber, route].filter(Boolean).join(" ");
  return result;
}
