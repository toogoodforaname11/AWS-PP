import { afterEach, describe, expect, it, vi } from "vitest";
import { exportConversation, streamChat } from "./botClient";

const originalCreateObjectURL = Object.getOwnPropertyDescriptor(URL, "createObjectURL");
const originalRevokeObjectURL = Object.getOwnPropertyDescriptor(URL, "revokeObjectURL");

afterEach(() => {
  vi.useRealTimers();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  if (originalCreateObjectURL) Object.defineProperty(URL, "createObjectURL", originalCreateObjectURL);
  else Reflect.deleteProperty(URL, "createObjectURL");
  if (originalRevokeObjectURL) Object.defineProperty(URL, "revokeObjectURL", originalRevokeObjectURL);
  else Reflect.deleteProperty(URL, "revokeObjectURL");
});

describe("exportConversation", () => {
  it("defers object-URL revocation so Firefox can accept the download", async () => {
    vi.useFakeTimers();
    const fakeBlob = new Blob(["# transcript"]);
    const fakeResponse = {
      ok: true,
      status: 200,
      headers: new Headers(),
      blob: async () => fakeBlob,
    } as unknown as Response;
    vi.stubGlobal("fetch", vi.fn(async () => fakeResponse));
    const createObjectURL = vi.fn(() => "blob:chat-export");
    const revokeObjectURL = vi.fn();
    Object.defineProperty(URL, "createObjectURL", { configurable: true, value: createObjectURL });
    Object.defineProperty(URL, "revokeObjectURL", { configurable: true, value: revokeObjectURL });
    vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(() => undefined);

    await exportConversation("conversation-12345678");
    expect(createObjectURL).toHaveBeenCalledTimes(1);
    expect(revokeObjectURL).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(999);
    expect(revokeObjectURL).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(1);
    expect(revokeObjectURL).toHaveBeenCalledWith("blob:chat-export");
  });
});

describe("streamChat", () => {
  it("processes a terminal event even when the NDJSON stream closes without a final newline", async () => {
    const body = new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(new TextEncoder().encode('{"type":"done","conversationId":"c1","messageId":"m1"}'));
        controller.close();
      },
    });
    vi.stubGlobal("fetch", vi.fn(async () => new Response(body, { status: 200 })));
    const events: unknown[] = [];

    await streamChat(
      { content: "hi", context: { path: "/", estateId: null, tab: null }, attachments: [] },
      (event) => events.push(event),
      new AbortController().signal,
    );

    expect(events).toEqual([{ type: "done", conversationId: "c1", messageId: "m1" }]);
  });

  it("classifies a temporary assistant service outage as retryable rather than unavailable", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response("", { status: 503 })));
    const events: unknown[] = [];

    await streamChat(
      { content: "hi", context: { path: "/", estateId: null, tab: null }, attachments: [] },
      (event) => events.push(event),
      new AbortController().signal,
    );

    expect(events).toEqual([
      expect.objectContaining({ type: "error", retryable: true, message: expect.stringContaining("reconnecting") }),
    ]);
  });
});
