import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import React, { useRef } from "react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { copyText, useCopyCodeBlocks } from "./useCopyCodeBlocks";

function CopyFixture() {
  const ref = useRef<HTMLDivElement>(null);
  useCopyCodeBlocks(ref);
  return <div ref={ref} className="kairo-md"><pre><code>const answer = 42;</code></pre></div>;
}

const originalClipboard = Object.getOwnPropertyDescriptor(navigator, "clipboard");
const originalExecCommand = Object.getOwnPropertyDescriptor(document, "execCommand");

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
  if (originalClipboard) Object.defineProperty(navigator, "clipboard", originalClipboard);
  else Reflect.deleteProperty(navigator, "clipboard");
  if (originalExecCommand) Object.defineProperty(document, "execCommand", originalExecCommand);
  else Reflect.deleteProperty(document, "execCommand");
});

describe("copyText", () => {
  it("reports success only after the Clipboard API resolves", async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    expect(await copyText("abc", { writeText })).toBe(true);
    expect(writeText).toHaveBeenCalledWith("abc");
  });

  it("uses and honors the legacy fallback after Clipboard API rejection", async () => {
    const execCommand = vi.fn().mockReturnValue(true);
    Object.defineProperty(document, "execCommand", { configurable: true, value: execCommand });
    expect(await copyText("abc", { writeText: vi.fn().mockRejectedValue(new Error("denied")) }, document)).toBe(true);
    expect(execCommand).toHaveBeenCalledWith("copy");
    expect(document.querySelector("textarea")).toBeNull();
  });

  it("returns false and removes the fallback element when copying fails", async () => {
    Object.defineProperty(document, "execCommand", { configurable: true, value: vi.fn().mockReturnValue(false) });
    expect(await copyText("abc", null, document)).toBe(false);
    expect(document.querySelector("textarea")).toBeNull();
  });

  it("preserves the copy result when the prior focus target can no longer be focused", async () => {
    const prior = document.createElement("button");
    document.body.appendChild(prior);
    prior.focus();
    vi.spyOn(prior, "focus").mockImplementation(() => { throw new Error("detached"); });
    Object.defineProperty(document, "execCommand", { configurable: true, value: vi.fn().mockReturnValue(true) });

    await expect(copyText("abc", null, document)).resolves.toBe(true);
    expect(document.querySelector("textarea")).toBeNull();
    prior.remove();
  });
});

describe("useCopyCodeBlocks", () => {
  it("injects a keyboard-labelled button and shows a truthful failure state", async () => {
    Object.defineProperty(navigator, "clipboard", {
      configurable: true,
      value: { writeText: vi.fn().mockRejectedValue(new Error("denied")) },
    });
    Object.defineProperty(document, "execCommand", { configurable: true, value: vi.fn().mockReturnValue(false) });

    render(<CopyFixture />);
    const button = await screen.findByRole("button", { name: "Copy code to clipboard" });
    expect(button.getAttribute("aria-live")).toBe("polite");
    button.focus();
    expect(document.activeElement).toBe(button);
    fireEvent.click(button);

    await waitFor(() => expect(button.textContent).toBe("Copy failed"));
    expect(document.activeElement).toBe(button);
    expect(button.classList.contains("kairo-copy-btn--error")).toBe(true);
    expect(button.getAttribute("aria-label")).toContain("Copy failed");
  });

  it("keeps one observer across rerenders and disconnects it on unmount", () => {
    const observe = vi.fn();
    const disconnect = vi.fn();
    const MutationObserverMock = vi.fn(function () {
      return { observe, disconnect, takeRecords: () => [] };
    });
    vi.stubGlobal("MutationObserver", MutationObserverMock);

    const view = render(<CopyFixture />);
    view.rerender(<CopyFixture />);
    view.rerender(<CopyFixture />);

    expect(MutationObserverMock).toHaveBeenCalledTimes(1);
    expect(observe).toHaveBeenCalledTimes(1);
    view.unmount();
    expect(disconnect).toHaveBeenCalledTimes(1);
  });
});
