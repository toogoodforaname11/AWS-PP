/**
 * Kairo-inspired chatbot widget shell.
 * Features:
 *  - Holographic wireframe orb FAB (canvas-based animation)
 *  - Typing text animation below the orb ("Have a question?", "Ask me anything.")
 *  - Lazy-loaded ChatPanel with dark theme
 *  - Error boundary renders null on crash (never takes down the app)
 */
import React, { Component, Suspense, lazy, useCallback, useEffect, useRef, useState } from "react";
import { X } from "lucide-react";
import { probeSession, type SessionProbe } from "./botClient";

const ChatPanel = lazy(() =>
  import("./ChatPanel").then((m) => ({ default: m.ChatPanel })),
);

class NullBoundary extends Component<{ children: React.ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch() {}
  render() {
    return this.state.failed ? null : this.props.children;
  }
}

/* ─── Holographic Orb Canvas ─── */
function HolographicOrb({ size = 120 }: { size?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // Simplified icosphere wireframe
    const phi = (1 + Math.sqrt(5)) / 2;
    let verts = [
      [-1, phi, 0], [1, phi, 0], [-1, -phi, 0], [1, -phi, 0],
      [0, -1, phi], [0, 1, phi], [0, -1, -phi], [0, 1, -phi],
      [phi, 0, -1], [phi, 0, 1], [-phi, 0, -1], [-phi, 0, 1],
    ].map((p) => {
      const l = Math.sqrt(p[0] ** 2 + p[1] ** 2 + p[2] ** 2);
      return [p[0] / l, p[1] / l, p[2] / l];
    });

    const faces = [
      [0,11,5],[0,5,1],[0,1,7],[0,7,10],[0,10,11],[1,5,9],[5,11,4],[11,10,2],
      [10,7,6],[7,1,8],[3,9,4],[3,4,2],[3,2,6],[3,6,8],[3,8,9],[4,9,5],
      [2,4,11],[6,2,10],[8,6,7],[9,8,1],
    ];

    // Subdivide twice for smoother sphere
    function subdivide(vs: number[][], fs: number[][]): { v: number[][]; f: number[][] } {
      const mc: Record<string, number> = {};
      const getMid = (a: number, b: number) => {
        const k = Math.min(a, b) + "_" + Math.max(a, b);
        if (mc[k] !== undefined) return mc[k];
        const va = vs[a], vb = vs[b];
        const mx = (va[0] + vb[0]) / 2, my = (va[1] + vb[1]) / 2, mz = (va[2] + vb[2]) / 2;
        const l = Math.sqrt(mx * mx + my * my + mz * mz);
        vs.push([mx / l, my / l, mz / l]);
        mc[k] = vs.length - 1;
        return mc[k];
      };
      const nf: number[][] = [];
      for (const t of fs) {
        const ab = getMid(t[0], t[1]), bc = getMid(t[1], t[2]), ca = getMid(t[2], t[0]);
        nf.push([t[0], ab, ca], [t[1], bc, ab], [t[2], ca, bc], [ab, bc, ca]);
      }
      return { v: vs, f: nf };
    }

    let { v, f } = subdivide([...verts], [...faces]);
    ({ v, f } = subdivide(v, f));

    // Extract edges
    const edgeSet = new Set<string>();
    const edges: [number, number][] = [];
    for (const t of f) {
      const pairs: [number, number][] = [[t[0], t[1]], [t[1], t[2]], [t[2], t[0]]];
      for (const [a, b] of pairs) {
        const k = Math.min(a, b) + "_" + Math.max(a, b);
        if (!edgeSet.has(k)) {
          edgeSet.add(k);
          edges.push([a, b]);
        }
      }
    }

    function draw() {
      const t = performance.now() / 1000;
      const W = size, H = size, mx = W / 2, my = H / 2;
      const R = size * 0.36;

      ctx.clearRect(0, 0, W, H);

      // Rotation
      const ry = t * 0.3;
      const rx = 0.22 + Math.sin(t * 0.018) * 0.025;
      const cry = Math.cos(ry), sry = Math.sin(ry);
      const crx = Math.cos(rx), srx = Math.sin(rx);

      // Pulse
      const pulse = 1 + Math.sin(t * 0.3 * Math.PI * 2) * 0.025;

      // Project vertices
      const projected = v.map((vert) => {
        const [vx, vy, vz] = vert;
        // Y rotation
        const bx = vx * cry - vz * sry;
        const bz = vx * sry + vz * cry;
        // X rotation
        const by2 = vy * crx - bz * srx;
        const bz2 = vy * srx + bz * crx;
        const sc = 1 / (1 + bz2 * 0.08);
        return { x: mx + bx * R * pulse * sc, y: my + by2 * R * pulse * sc, z: bz2 };
      });

      // Core glow
      ctx.save();
      ctx.globalCompositeOperation = "screen";
      const g0 = ctx.createRadialGradient(mx, my, 0, mx, my, R * 0.95);
      g0.addColorStop(0, "rgba(140,215,255,0.3)");
      g0.addColorStop(0.3, "rgba(70,155,240,0.15)");
      g0.addColorStop(0.6, "rgba(45,120,225,0.08)");
      g0.addColorStop(1, "rgba(20,60,150,0)");
      ctx.fillStyle = g0;
      ctx.beginPath();
      ctx.arc(mx, my, R * 0.95, 0, Math.PI * 2);
      ctx.fill();

      const g1 = ctx.createRadialGradient(mx, my, 0, mx, my, R * 0.5);
      g1.addColorStop(0, "rgba(200,240,255,0.4)");
      g1.addColorStop(0.4, "rgba(90,175,242,0.15)");
      g1.addColorStop(1, "rgba(40,110,210,0)");
      ctx.fillStyle = g1;
      ctx.beginPath();
      ctx.arc(mx, my, R * 0.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Draw wireframe edges
      ctx.save();
      ctx.lineCap = "round";
      for (const [a, b] of edges) {
        const pa = projected[a], pb = projected[b];
        const avgZ = (pa.z + pb.z) / 2;
        const depth = (avgZ + 1) / 2; // 0 = back, 1 = front
        const alpha = 0.05 + depth * 0.55;
        const hue = ((depth * 0.6 + t * 0.03) % 1) * 360;
        ctx.strokeStyle = `hsla(${200 + hue * 0.15}, 80%, ${55 + depth * 25}%, ${alpha})`;
        ctx.lineWidth = 0.15 + depth * 0.35;
        ctx.beginPath();
        ctx.moveTo(pa.x, pa.y);
        ctx.lineTo(pb.x, pb.y);
        ctx.stroke();
      }
      ctx.restore();

      // Ripple
      const period = 3.2;
      const phase = (t % period) / period;
      const rr = R + phase * 8;
      const ra = Math.max(0, 0.12 * (1 - phase));
      ctx.save();
      ctx.beginPath();
      ctx.arc(mx, my, rr, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(100,180,255,${ra})`;
      ctx.lineWidth = 0.5 * (1 - phase * 0.3);
      ctx.stroke();
      ctx.restore();

      animRef.current = requestAnimationFrame(draw);
    }

    animRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(animRef.current);
  }, [size]);

  return (
    <canvas
      ref={canvasRef}
      style={{ width: size, height: size, display: "block" }}
    />
  );
}

/* ─── Typing Text Animation ─── */
function TypingText() {
  const phrases = ["Hello...", "Have a question?", "Ask me anything."];
  const [text, setText] = useState("");
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (dismissed) return;
    let pi = 0, ci = 0, deleting = false, timer: ReturnType<typeof setTimeout>;
    const tySpd = 60, delSpd = 35;
    const pauses = [700, 1000, 2200];

    function tick() {
      const phrase = phrases[pi];
      if (!deleting) {
        ci++;
        setText(phrase.slice(0, ci));
        if (ci >= phrase.length) {
          timer = setTimeout(() => { deleting = true; tick(); }, pauses[pi]);
          return;
        }
        timer = setTimeout(tick, tySpd);
      } else {
        ci--;
        setText(phrase.slice(0, ci));
        if (ci <= 0) {
          deleting = false;
          pi = (pi + 1) % phrases.length;
          timer = setTimeout(tick, 300);
          return;
        }
        timer = setTimeout(tick, delSpd);
      }
    }

    timer = setTimeout(tick, 800);
    return () => clearTimeout(timer);
  }, [dismissed]);

  if (dismissed) return null;

  return (
    <div className="kairo-type">
      <span>{text}<span className="kairo-cursor">_</span></span>
      <button
        type="button"
        className="kairo-type-x"
        aria-label="Dismiss assistant hint"
        onClick={(e) => {
          e.stopPropagation();
          setDismissed(true);
        }}
      />
    </div>
  );
}

/* ─── Main Widget ─── */
function ChatbotWidgetInner() {
  const [probe, setProbe] = useState<SessionProbe | null>(null);
  const [open, setOpen] = useState<boolean>(() => {
    try {
      return localStorage.getItem("chatbot_open") === "1";
    } catch {
      return false;
    }
  });
  const [everOpened, setEverOpened] = useState(open);
  const [unread, setUnread] = useState(0);
  const [hovered, setHovered] = useState(false);
  const openRef = useRef(open);
  openRef.current = open;
  const probeRef = useRef<SessionProbe | null>(null);

  useEffect(() => {
    let cancelled = false;
    const probeKey = (p: SessionProbe | null) =>
      p ? (p.status === "ok" ? `ok:${p.name}` : p.status) : "none";
    const doProbe = () =>
      probeSession()
        .then((p) => {
          if (cancelled) return;
          setProbe((prev) => {
            const next =
              openRef.current && prev?.status === "ok" && p.status === "offline"
                ? prev
                : probeKey(prev) === probeKey(p)
                  ? prev
                  : p;
            probeRef.current = next;
            return next;
          });
        })
        .catch(() => {});
    const idle = (cb: () => void) =>
      "requestIdleCallback" in window
        ? (window as any).requestIdleCallback(cb, { timeout: 4000 })
        : setTimeout(cb, 1500);
    idle(() => void doProbe());
    const interval = setInterval(() => {
      if (probeRef.current?.status !== "ok") void doProbe();
    }, 20_000);
    const onFocus = () => void doProbe();
    window.addEventListener("focus", onFocus);
    return () => {
      cancelled = true;
      clearInterval(interval);
      window.removeEventListener("focus", onFocus);
    };
  }, []);

  const setOpenPersisted = useCallback((next: boolean) => {
    setOpen(next);
    if (next) {
      setEverOpened(true);
      setUnread(0);
    }
    try {
      localStorage.setItem("chatbot_open", next ? "1" : "0");
    } catch {}
  }, []);

  const onAssistantDone = useCallback(() => {
    if (!openRef.current) setUnread((n) => n + 1);
  }, []);

  if (!probe || probe.status === "offline") return null;

  return (
    <>
      {everOpened && (
        <Suspense fallback={null}>
          <ChatPanel
            open={open}
            probe={probe}
            onClose={() => setOpenPersisted(false)}
            onAssistantDone={onAssistantDone}
          />
        </Suspense>
      )}
      {!open && (
        <div className="kairo-root">
          <button
            type="button"
            className="kairo-orb-btn"
            onClick={() => setOpenPersisted(true)}
            onMouseEnter={() => setHovered(true)}
            onMouseLeave={() => setHovered(false)}
            aria-label="Open ProbatePro Assistant"
            title="ProbatePro Assistant"
          >
            <HolographicOrb size={120} />
            {unread > 0 && (
              <span className="absolute -right-1 -top-1 flex size-5 items-center justify-center rounded-full bg-[var(--kairo-accent)] text-[10px] font-bold text-white shadow-lg">
                {unread > 9 ? "9+" : unread}
              </span>
            )}
          </button>
          <TypingText />
        </div>
      )}
    </>
  );
}

/* ─── Unavailable Banner ─── */
function UnavailableBanner() {
  const [dismissed, setDismissed] = useState(false);
  if (dismissed) return null;
  return (
    <div className="kairo-unavailable-banner" role="status" aria-live="polite">
      <div className="kairo-unavailable-icon">
        <svg viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-5 h-5">
          <circle cx="10" cy="10" r="9" stroke="currentColor" strokeWidth="1.5" />
          <path d="M10 6v5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
          <circle cx="10" cy="14" r="1" fill="currentColor" />
        </svg>
      </div>
      <div className="kairo-unavailable-text">
        <span className="kairo-unavailable-title">Assistant unavailable</span>
        <span className="kairo-unavailable-desc">AI features are pending privacy and processor approval. The assistant will appear here once enabled.</span>
      </div>
      <button
        type="button"
        className="kairo-unavailable-dismiss"
        aria-label="Dismiss assistant unavailable notice"
        onClick={() => setDismissed(true)}
      >
        <X size={14} />
      </button>
    </div>
  );
}

export function ChatbotWidget({ enabled, visible = true }: { enabled?: boolean; visible?: boolean }) {
  // The user can hide the assistant in Settings. This remains separate from
  // the processor-approval gate below, so re-enabling always restores the
  // correct approved/unavailable state.
  if (!visible) return null;
  // Loading and failed feature-flag requests are unknown, not an affirmative
  // processor-disabled state. Stay silent until the server answers.
  if (enabled === undefined) return null;
  if (!enabled) {
    return (
      <NullBoundary>
        <UnavailableBanner />
      </NullBoundary>
    );
  }
  return (
    <NullBoundary>
      <ChatbotWidgetInner />
    </NullBoundary>
  );
}
