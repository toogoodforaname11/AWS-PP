import { act, renderHook } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { createConversation, fetchPendingProposals } from "./botClient";
import { useChat } from "./useChat";

const mocks = vi.hoisted(() => ({ streamChat: vi.fn(), toastInfo: vi.fn() }));

vi.mock("sonner", () => ({ toast: { info: mocks.toastInfo, success: vi.fn(), error: vi.fn() } }));

vi.mock("./botClient", () => ({
  createConversation: vi.fn(),
  fetchConversation: vi.fn(),
  fetchLatestConversation: vi.fn(),
  fetchPendingProposals: vi.fn(),
  streamChat: mocks.streamChat,
}));

describe("useChat completion lifecycle", () => {
  beforeEach(() => vi.clearAllMocks());

  it("counts a reply only after the server confirms a persisted done event", async () => {
    mocks.streamChat.mockImplementation(async (_body, onEvent) => {
      onEvent({ type: "conversation", conversationId: "c1" });
      onEvent({ type: "text_delta", text: "hello" });
      onEvent({ type: "done", conversationId: "c1", messageId: "m1" });
    });
    const onAssistantDone = vi.fn();
    const { result } = renderHook(() => useChat(() => ({ path: "/", estateId: null, tab: null }), onAssistantDone));
    await act(async () => { await result.current.send("hi"); });
    expect(onAssistantDone).toHaveBeenCalledTimes(1);
    expect(result.current.lastRequestOutcome?.kind).toBe("completed");
    expect(result.current.processingTrail.map((entry) => entry.label)).toEqual(["Request received", "Reply recorded"]);
  });

  it("removes provisional internal tool text when the server starts a structured tool action", async () => {
    mocks.streamChat.mockImplementation(async (_body, onEvent) => {
      onEvent({ type: "conversation", conversationId: "c1" });
      onEvent({ type: "text_delta", text: "cite[]functions.search_product_help:turn 0" });
      onEvent({ type: "text_replace", text: "" });
      onEvent({ type: "text_delta", text: "The template is in Settings." });
      onEvent({ type: "done", conversationId: "c1", messageId: "m1" });
    });
    const { result } = renderHook(() => useChat(() => ({ path: "/", estateId: null, tab: null }), vi.fn()));

    await act(async () => { await result.current.send("where is the template?"); });

    expect(result.current.messages.at(-1)?.content).toBe("The template is in Settings.");
    expect(result.current.messages.some((message) => message.content.includes("functions.search_product_help"))).toBe(false);
  });

  it("keeps a canonical profile-completion request local to the chat session and respects dismissal", async () => {
    mocks.streamChat.mockImplementation(async (_body, onEvent) => {
      onEvent({ type: "conversation", conversationId: "c1" });
      onEvent({
        type: "profile_completion",
        profile: {
          lawyerName: "Test",
          firmName: "",
          firmAddress: "",
          firmPhone: "",
          firmEmail: "test@probate-pro.com",
        },
        missingFields: ["firmName"],
      });
      onEvent({ type: "done", conversationId: "c1", messageId: "m1" });
    });
    const { result } = renderHook(() => useChat(() => ({ path: "/", estateId: null, tab: null }), vi.fn()));

    await act(async () => { await result.current.send("help me"); });
    expect(result.current.profileCompletion).toMatchObject({
      profile: { lawyerName: "Test", firmEmail: "test@probate-pro.com", firmName: "" },
      missingFields: ["firmName"],
    });
    expect(result.current.messages.some((message) => message.content.includes("test@probate-pro.com"))).toBe(false);

    act(() => result.current.dismissProfileCompletion());
    expect(result.current.profileCompletion).toBeNull();

    await act(async () => { await result.current.send("continue"); });
    expect(result.current.profileCompletion).toBeNull();
  });

  it("omits a null conversation ID on the first turn so the strict edge schema creates one", async () => {
    mocks.streamChat.mockResolvedValue(undefined);
    const { result } = renderHook(() => useChat(() => ({ path: "/", estateId: null, tab: null }), vi.fn()));

    await act(async () => { await result.current.send("first message"); });

    expect(mocks.streamChat).toHaveBeenCalledWith(
      expect.objectContaining({ conversationId: undefined, content: "first message" }),
      expect.any(Function),
      expect.any(AbortSignal),
    );
  });

  it("does not count an error response as an unread assistant reply", async () => {
    mocks.streamChat.mockImplementation(async (_body, onEvent) => {
      onEvent({ type: "conversation", conversationId: "c1" });
      onEvent({ type: "error", message: "backend failed" });
    });
    const onAssistantDone = vi.fn();
    const { result } = renderHook(() => useChat(() => ({ path: "/", estateId: null, tab: null }), onAssistantDone));
    await act(async () => { await result.current.send("hi"); });
    expect(onAssistantDone).not.toHaveBeenCalled();
  });

  it("surfaces a retryable failure when a stream ends without a done or error event", async () => {
    mocks.streamChat.mockImplementation(async (_body, onEvent) => {
      onEvent({ type: "conversation", conversationId: "c1" });
      onEvent({ type: "text_delta", text: "Partial answer" });
      // Simulate EOF after a proxy drops the terminal NDJSON event.
    });
    const onAssistantDone = vi.fn();
    const { result } = renderHook(() => useChat(() => ({ path: "/", estateId: null, tab: null }), onAssistantDone));
    await act(async () => { await result.current.send("hi"); });

    expect(result.current.lastError).toBe("The assistant response ended before it was saved. Please try again.");
    expect(result.current.messages.at(-1)?.content).toContain("Partial answer");
    expect(result.current.messages.at(-1)?.content).toContain("Please try again");
    expect(onAssistantDone).not.toHaveBeenCalled();
  });

  it("reuses the same idempotency key when the user retries a failed turn", async () => {
    mocks.streamChat.mockImplementation(async (_body, onEvent) => {
      onEvent({ type: "conversation", conversationId: "c1" });
      onEvent({ type: "error", message: "temporary failure" });
    });
    const { result } = renderHook(() => useChat(() => ({ path: "/", estateId: null, tab: null }), vi.fn()));
    await act(async () => { await result.current.send("keep this turn"); });
    const firstRequestId = (mocks.streamChat.mock.calls[0]?.[0] as { requestId?: string }).requestId;

    await act(async () => { result.current.retry(); });
    const secondRequestId = (mocks.streamChat.mock.calls[1]?.[0] as { requestId?: string }).requestId;

    expect(firstRequestId).toEqual(expect.any(String));
    expect(secondRequestId).toBe(firstRequestId);
  });

  it("automatically retries one retryable no-output failure using the same request key", async () => {
    vi.useFakeTimers();
    mocks.streamChat
      .mockImplementationOnce(async (_body, onEvent) => {
        onEvent({ type: "conversation", conversationId: "c1" });
        onEvent({ type: "error", message: "temporary outage", retryable: true, retryAfterMs: 300 });
      })
      .mockImplementationOnce(async (_body, onEvent) => {
        onEvent({ type: "conversation", conversationId: "c1" });
        onEvent({ type: "text_delta", text: "Recovered." });
        onEvent({ type: "done", conversationId: "c1", messageId: "m1" });
      });
    const { result } = renderHook(() => useChat(() => ({ path: "/", estateId: null, tab: null }), vi.fn()));

    await act(async () => { await result.current.send("recover this request"); });
    const requestId = (mocks.streamChat.mock.calls[0]?.[0] as { requestId?: string }).requestId;
    await act(async () => { await vi.advanceTimersByTimeAsync(300); });

    expect(mocks.streamChat).toHaveBeenCalledTimes(2);
    expect((mocks.streamChat.mock.calls[1]?.[0] as { requestId?: string }).requestId).toBe(requestId);
    expect(result.current.messages.at(-1)?.content).toBe("Recovered.");
    expect(result.current.messages.filter((message) => message.role === "user")).toHaveLength(1);
  });

  it("does not count a user-stopped stream as an unread assistant reply", async () => {
    mocks.streamChat.mockImplementation((_body, _onEvent, signal: AbortSignal) =>
      new Promise<void>((_resolve, reject) => {
        signal.addEventListener("abort", () => reject(new DOMException("aborted", "AbortError")), { once: true });
      }),
    );
    const onAssistantDone = vi.fn();
    const { result } = renderHook(() => useChat(() => ({ path: "/", estateId: null, tab: null }), onAssistantDone));
    let pending!: Promise<void>;
    act(() => { pending = result.current.send("hi"); });
    act(() => result.current.stop());
    await act(async () => { await pending; });
    expect(onAssistantDone).not.toHaveBeenCalled();
    expect(result.current.lastRequestOutcome?.kind).toBe("stopped");
    expect(result.current.processingTrail.at(-1)?.label).toBe("Request stopped");
    expect(result.current.messages.at(-1)).toMatchObject({ role: "system", content: "Request cancelled" });
  });

  it("cancels a scheduled automatic retry and clears the active retry state", async () => {
    vi.useFakeTimers();
    mocks.streamChat.mockImplementation(async (_body, onEvent) => {
      onEvent({ type: "conversation", conversationId: "c1" });
      onEvent({ type: "error", message: "temporary outage", retryable: true, retryAfterMs: 300 });
    });
    const { result } = renderHook(() => useChat(() => ({ path: "/", estateId: null, tab: null }), vi.fn()));

    try {
      await act(async () => { await result.current.send("cancel the retry"); });
      expect(result.current.isLoading).toBe(true);
      expect(result.current.isRetrying).toBe(true);

      act(() => result.current.stop());
      await act(async () => { await vi.advanceTimersByTimeAsync(300); });

      expect(mocks.streamChat).toHaveBeenCalledTimes(1);
      expect(result.current.isLoading).toBe(false);
      expect(result.current.isRetrying).toBe(false);
      expect(result.current.lastRequestOutcome?.kind).toBe("stopped");
    } finally {
      vi.useRealTimers();
    }
  });

  it("records only received stream phases in the per-request processing trail", async () => {
    mocks.streamChat.mockImplementation(async (_body, onEvent) => {
      onEvent({ type: "conversation", conversationId: "c1" });
      onEvent({ type: "tool_start", name: "get_readiness", label: "Checking readiness" });
      onEvent({ type: "tool_done", name: "get_readiness", ok: true });
      onEvent({ type: "done", conversationId: "c1", messageId: "m1" });
    });
    const { result } = renderHook(() => useChat(() => ({ path: "/", estateId: "e1", tab: null }), vi.fn()));
    await act(async () => { await result.current.send("What is missing?"); });
    expect(result.current.processingTrail.map((entry) => entry.label)).toEqual([
      "Request received",
      "Checking readiness",
      "Assistant step complete",
      "Reply recorded",
    ]);
  });

  it("clears the typing state when a conversation switch aborts an in-flight send", async () => {
    // Deleting the open conversation calls newChat() -> invalidate(), which
    // aborts the stream and bumps the epoch. The aborted send's finally then
    // sees a newer epoch and declines to clean up — but no newer SEND exists to
    // take ownership, so isLoading stayed true forever: dots spinning with the
    // composer disabled (it is disabled={isLoading}), i.e. a bricked widget.
    mocks.streamChat.mockImplementation((_body: unknown, _onEvent: unknown, signal: AbortSignal) =>
      new Promise<void>((_resolve, reject) => {
        signal.addEventListener("abort", () => reject(new DOMException("aborted", "AbortError")), { once: true });
      }),
    );
    vi.mocked(createConversation).mockResolvedValue({ id: "c2" });
    const { result } = renderHook(() => useChat(() => ({ path: "/", estateId: null, tab: null }), vi.fn()));

    let pending!: Promise<void>;
    act(() => { pending = result.current.send("hi"); });
    expect(result.current.isLoading).toBe(true);

    await act(async () => { await result.current.newChat(); });
    await act(async () => { await pending; });

    expect(result.current.isLoading).toBe(false);
    expect(result.current.toolStatus).toBeNull();
    expect(result.current.processingTrail).toEqual([]);
  });

  it("records an applied proposal in the transcript, not only on the card", async () => {
    // A successful Apply used to leave only a small "Applied" badge on a card
    // inside a scrolling tray, so it could produce nothing visible on screen —
    // and the assistant, which never learns the outcome, would then deny it.
    const { result } = renderHook(() => useChat(() => ({ path: "/", estateId: "e1", tab: null }), vi.fn()));

    act(() => {
      result.current.updateProposal("p1", "applied", "✅ Applied — now saved on the estate: Former residence city.");
    });

    expect(result.current.messages.at(-1)).toMatchObject({
      role: "assistant",
      content: expect.stringContaining("Former residence city"),
    });
  });

  it("does not put a rejected or failed proposal in the transcript", async () => {
    const { result } = renderHook(() => useChat(() => ({ path: "/", estateId: "e1", tab: null }), vi.fn()));

    act(() => {
      result.current.updateProposal("p1", "failed", "Apply didn't complete — refresh the estate.");
      result.current.updateProposal("p2", "dismissed");
    });

    // Failure text belongs on the card, which shows it in context with a retry.
    expect(result.current.messages).toHaveLength(0);
  });
});

describe("useChat cross-page persistence (Nick 2026-08-03)", () => {
  beforeEach(() => vi.clearAllMocks());

  it("keeps the conversation and transcript when navigating estate ↔ global", async () => {
    // THE reported bug: "the chat bot resets when switching tabs". Navigation
    // must never swap the thread; the same conversationId rides every send.
    mocks.streamChat.mockImplementation(async (_body, onEvent) => {
      onEvent({ type: "conversation", conversationId: "c-estate" });
      onEvent({ type: "text_delta", text: "noted" });
      onEvent({ type: "done", conversationId: "c-estate", messageId: "m1" });
    });
    let context = { path: "/estate/12", estateId: "12", tab: null };
    const { result } = renderHook(() => useChat(() => context, vi.fn()));
    await act(async () => { await result.current.send("about this estate"); });

    context = { path: "/deadlines", estateId: null, tab: null }; // user navigates
    await act(async () => { await result.current.send("follow-up"); });

    expect(mocks.streamChat).toHaveBeenLastCalledWith(
      expect.objectContaining({ conversationId: "c-estate", content: "follow-up" }),
      expect.any(Function),
      expect.any(AbortSignal),
    );
    // Both turns and both replies still on screen — nothing reset.
    expect(result.current.messages).toHaveLength(4);
  });

  it("starts estate B's own thread when an estate A conversation continues from estate B", async () => {
    // Mirrors the server's scope guard (the one remaining fork case): estate
    // B's turns must not render underneath — or be filed into — estate A's
    // conversation.
    mocks.streamChat.mockImplementation(async (body: { conversationId?: string }, onEvent) => {
      onEvent({ type: "conversation", conversationId: body.conversationId ?? "c-fresh" });
      onEvent({ type: "done", conversationId: body.conversationId ?? "c-fresh", messageId: "m" });
    });
    let context = { path: "/estate/12", estateId: "12", tab: null };
    const { result } = renderHook(() => useChat(() => context, vi.fn()));
    await act(async () => { await result.current.send("estate A talk"); });

    context = { path: "/estate/99", estateId: "99", tab: null };
    await act(async () => { await result.current.send("estate B talk"); });

    expect(mocks.streamChat).toHaveBeenLastCalledWith(
      expect.objectContaining({ conversationId: undefined, content: "estate B talk" }),
      expect.any(Function),
      expect.any(AbortSignal),
    );
    expect(result.current.messages.filter((m) => m.role === "user").map((m) => m.content))
      .toEqual(["estate B talk"]);
    // A toast should inform the user a new conversation was started
    expect(mocks.toastInfo).toHaveBeenCalledWith("Started a new conversation for this estate");
  });

  it("merges pending proposals without duplicating cards already on screen", async () => {
    vi.mocked(fetchPendingProposals).mockResolvedValue([
      { proposalId: "p1", estateId: "e1", kind: "intake", diff: { kind: "intake", estateId: "e1", estateName: "E", rows: [] } },
    ]);
    const { result } = renderHook(() => useChat(() => ({ path: "/estate/e1", estateId: "e1", tab: null }), vi.fn()));
    await act(async () => { await result.current.hydratePendingProposals("e1"); });
    await act(async () => { await result.current.hydratePendingProposals("e1"); });
    expect(result.current.proposals).toHaveLength(1);
    expect(result.current.proposals[0]).toMatchObject({ proposalId: "p1", status: "pending", hydrated: true });
  });
});
