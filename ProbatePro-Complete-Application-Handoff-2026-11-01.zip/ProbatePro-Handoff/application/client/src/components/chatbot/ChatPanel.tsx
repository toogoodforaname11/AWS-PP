/**
 * Chat panel — Kairo-inspired dark theme design.
 * Dark navy background (#0A0E1A), gradient header, blue user bubbles,
 * dark slate bot bubbles, a filing-trace request presence state, and a pill input
 * with gradient send.
 */
import React, { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { useIsMobile } from "@/hooks/useMobile";
import { cn } from "@/lib/utils";
import { trpc } from "@/lib/trpc";
import { ChevronDown, Clock, Download, FileCheck2, FileUp, Loader2, MessageSquare, Paperclip, Plus, RefreshCw, Send, Square, ThumbsDown, ThumbsUp, Trash2, X } from "lucide-react";
import { Streamdown, defaultRehypePlugins } from "streamdown";
import { useCopyCodeBlocks } from "./useCopyCodeBlocks";
import { usePageContext } from "./usePageContext";
import { useChat } from "./useChat";
import { useFileDrop } from "./useFileDrop";
import { ProposalCard } from "./ProposalCard";
import { asAssistantChimeTone, clampAssistantChimeVolume, playAssistantChime, primeAssistantChime } from "@/lib/assistantChime";
import {
  clearAllConversations,
  deleteConversationRequest,
  exportConversation,
  fetchFeedback,
  listConversations,
  removeFeedbackRequest,
  submitFeedback,
  type ConversationSummary,
  type ProfileCompletionFields,
  type SessionProbe,
} from "./botClient";

/**
 * Openers. Two rules, both learned from shipping ones that broke them:
 *
 * 1. A chip must be answerable IN ONE TURN by a read-only tool — a question the
 *    assistant answers, never a task it has to negotiate. `propose_intake_updates`
 *    requires a `source` per field ("which dropped file states it"), so with no
 *    attachments in the conversation it can only reply by asking which fields you
 *    want and where they come from. Offering it as a click-opener guarantees a
 *    question back instead of an answer. Dropping a will onto the panel already
 *    starts that flow, and the empty-state line + attach button say so.
 * 2. Split by scope: every estate prompt resolves to a tool that requires an
 *    estateId, so offering one on the dashboard invites "I can't do that without
 *    an open estate" — the assistant declining work the chip just promised.
 *
 * Estate → get_estate_snapshot / get_readiness / compute_distribution.
 * Global → the only tools taking no estateId: list_estates, get_deadlines,
 * search_product_help.
 */
const ESTATE_PROMPTS = [
  "Summarize this estate file",
  "What's still missing before filing?",
  "Who inherits, and what share?",
];
const GLOBAL_PROMPTS = [
  "Show me my estate files",
  "What deadlines are coming up?",
  "What can you help me with?",
];

// Defense in depth: omit Streamdown's raw-HTML plugin entirely. The sanitizer
// also escapes prose and strips Markdown images, but the renderer itself should
// never reinterpret assistant-controlled HTML if that preprocessing regresses.
const CHATBOT_REHYPE_PLUGINS = [defaultRehypePlugins.sanitize, defaultRehypePlugins.harden];
// Even if a future sanitizer change misses an image syntax variant, the live
// renderer has no image component and therefore cannot auto-fetch an attacker URL.
const CHATBOT_MARKDOWN_COMPONENTS = { img: () => null };

const TOOL_PHASE_COPY: Record<string, { label: string; detail: string }> = {
  get_readiness: { label: "Tracing filing readiness", detail: "Checking recorded filing conditions" },
  compute_distribution: { label: "Reconciling recorded distribution", detail: "Checking the recorded shares and values" },
  get_estate_snapshot: { label: "Reading the estate record", detail: "Reviewing the relevant recorded details" },
  list_estates: { label: "Reviewing estate files", detail: "Checking the available file records" },
  get_deadlines: { label: "Reviewing upcoming deadlines", detail: "Checking the recorded deadline calendar" },
  search_product_help: { label: "Searching ProbatePro guidance", detail: "Reviewing the product guidance index" },
};

/* ─── Request Presence (Kairo filing-trace style) ─── */
function KairoRequestPresence({
  toolStatus,
  isRetrying,
  retryStep,
}: {
  toolStatus?: { name: string; label: string; running: boolean } | null;
  isRetrying: boolean;
  retryStep?: string;
}) {
  const showTool = toolStatus?.running;
  const phase = showTool && toolStatus ? TOOL_PHASE_COPY[toolStatus.name] ?? { label: toolStatus.label, detail: "Working with the authorized request context" } : null;
  const [visibleRetryStep, setVisibleRetryStep] = useState(retryStep);
  const [retryStepLeaving, setRetryStepLeaving] = useState(false);

  useEffect(() => {
    if (!isRetrying || !retryStep || retryStep === visibleRetryStep) return;
    setRetryStepLeaving(true);
    const transition = window.setTimeout(() => {
      setVisibleRetryStep(retryStep);
      setRetryStepLeaving(false);
    }, 130);
    return () => window.clearTimeout(transition);
  }, [isRetrying, retryStep, visibleRetryStep]);

  const currentRetryStep = visibleRetryStep ?? retryStep ?? "Preparing the saved request for reconnection.";
  const label = isRetrying ? "Reconnecting your request" : phase?.label ?? "Reading your request";
  const detail = isRetrying
    ? "Trying once more — your message will not be sent twice."
    : phase?.detail ?? "Preparing a grounded response";
  return (
    <div
      className="kairo-bot animate-kairo-slide-in"
      role="status"
      aria-live="polite"
      aria-label={isRetrying ? "Assistant is reconnecting your request. Your message will not be sent twice." : showTool ? `${toolStatus.label}. Assistant is working.` : "Assistant is preparing a grounded response"}
    >
      <BotAvatar />
      <div
        className={cn("kairo-bb kairo-request-presence", showTool && "kairo-request-presence--tool", isRetrying && "kairo-request-presence--retry")}
        data-testid={isRetrying ? "assistant-retry-presence" : showTool ? "assistant-tool-presence" : "assistant-request-presence"}
      >
        <span className={cn("kairo-presence-trace", isRetrying && "kairo-presence-trace--retry")} aria-hidden="true">
          <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path className="kairo-trace-path" d="M6 7.5H17.5L25.5 15.5V25H10.5" />
            <path className="kairo-trace-document" d="M10.5 11H16.5M10.5 15H19.5M10.5 19H16" />
            <circle className="kairo-trace-node" cx="7" cy="25" r="2.25" />
          </svg>
        </span>
        <span className="min-w-0 flex-1">
          <span className="kairo-presence-kicker">ProbatePro Assistant</span>
          <span className="kairo-presence-label">{label}</span>
          <span className="kairo-presence-detail">{detail}</span>
          {isRetrying && (
            <span className="kairo-presence-step" data-testid="assistant-retry-step">
              <span>Current step</span>
              <span className={cn("kairo-presence-step-message", retryStepLeaving && "kairo-presence-step-message--leaving")}>{currentRetryStep}</span>
            </span>
          )}
        </span>
        <span className="kairo-presence-tally" aria-hidden="true"><i /><i /><i /></span>
      </div>
    </div>
  );
}

/* ─── Bot Avatar ─── */
function BotAvatar() {
  return (
    <div className="kairo-av">
      <svg viewBox="2 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-[15px] h-[15px]">
        <line x1="12" y1="1" x2="12" y2="4" stroke="#e2e8f0" strokeWidth="1.5" strokeLinecap="round" />
        <circle cx="12" cy="1.5" r="1.2" fill="#e2e8f0" />
        <rect x="3" y="4" width="18" height="14" rx="4" fill="#e2e8f0" />
        <circle cx="8.5" cy="10.5" r="2" fill="#0A0E1A" />
        <circle cx="15.5" cy="10.5" r="2" fill="#0A0E1A" />
        <path d="M9 14.5 Q12 16.5 15 14.5" stroke="#0A0E1A" strokeWidth="1.2" strokeLinecap="round" fill="none" />
      </svg>
    </div>
  );
}

function InlineProfileCompletionCard({
  profile,
  missingFields,
  onDismiss,
  onSaved,
}: {
  profile: ProfileCompletionFields;
  missingFields: Array<"lawyerName" | "firmName" | "firmEmail">;
  onDismiss: () => void;
  onSaved: () => void;
}) {
  const utils = trpc.useUtils();
  const [values, setValues] = useState<ProfileCompletionFields>(profile);
  const [firmNameError, setFirmNameError] = useState("");
  const [saveError, setSaveError] = useState("");
  const [saved, setSaved] = useState(false);
  const firmNameMissing = missingFields.includes("firmName");
  const updateMutation = trpc.settings.update.useMutation({
    onSuccess: async () => {
      setSaveError("");
      setSaved(true);
      await utils.settings.get.invalidate();
    },
    onError: (error) => setSaveError(error.message || "We could not save your profile. Please try again."),
  });

  useEffect(() => {
    if (!saved) return;
    const timeout = window.setTimeout(onSaved, 850);
    return () => window.clearTimeout(timeout);
  }, [onSaved, saved]);

  const updateValue = (field: keyof ProfileCompletionFields, value: string) => {
    setValues((current) => ({ ...current, [field]: value }));
    if (field === "firmName" && value.trim()) setFirmNameError("");
    if (saveError) setSaveError("");
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const firmName = values.firmName.trim();
    if (!firmName) {
      setFirmNameError("Enter your firm name to complete your professional profile.");
      return;
    }
    if (updateMutation.isPending) return;
    updateMutation.mutate({
      lawyerName: values.lawyerName.trim(),
      firmName,
      firmAddress: values.firmAddress.trim(),
      firmPhone: values.firmPhone.trim(),
      firmEmail: values.firmEmail.trim(),
    });
  };

  if (saved) {
    return (
      <div className="kairo-bot animate-kairo-slide-in" role="status" aria-live="polite">
        <BotAvatar />
        <div className="kairo-bb min-w-0 max-w-full border border-emerald-400/25 bg-emerald-500/10 text-slate-100">
          <div className="flex items-center gap-2 text-sm"><FileCheck2 className="size-4 shrink-0 text-emerald-300" aria-hidden="true" /> Professional profile saved.</div>
        </div>
      </div>
    );
  }

  return (
    <div className="kairo-bot animate-kairo-slide-in">
      <BotAvatar />
      <section className="kairo-bb min-w-0 max-w-full border border-sky-300/20 bg-slate-900/80 p-3 text-slate-100 shadow-none sm:p-4" aria-labelledby="chat-profile-completion-title">
        <div className="mb-3 min-w-0">
          <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-sky-200">Professional profile</p>
          <h3 id="chat-profile-completion-title" className="mt-1 text-sm font-semibold text-white">{firmNameMissing ? "Add your firm name to keep your documents accurate" : "Complete your professional profile"}</h3>
          <p className="mt-1 text-xs leading-5 text-slate-300">Your signed-in name and email are prefilled when available. You can add or revise the remaining details now.</p>
        </div>
        <form className="grid min-w-0 gap-3" onSubmit={handleSubmit} noValidate>
          <div className="grid min-w-0 gap-3 sm:grid-cols-2">
            <ProfileInput label="Your name" name="lawyerName" autoComplete="name" value={values.lawyerName} onChange={updateValue} />
            <ProfileInput label="Firm name" name="firmName" autoComplete="organization" value={values.firmName} onChange={updateValue} required={firmNameMissing} error={firmNameError} />
          </div>
          <ProfileInput label="Firm address" name="firmAddress" autoComplete="street-address" value={values.firmAddress} onChange={updateValue} />
          <div className="grid min-w-0 gap-3 sm:grid-cols-2">
            <ProfileInput label="Firm phone" name="firmPhone" autoComplete="tel" inputMode="tel" value={values.firmPhone} onChange={updateValue} />
            <ProfileInput label="Firm email" name="firmEmail" autoComplete="email" inputMode="email" value={values.firmEmail} onChange={updateValue} />
          </div>
          {saveError && <p role="alert" className="text-xs leading-5 text-rose-200">{saveError}</p>}
          <div className="flex flex-col-reverse gap-2 pt-1 sm:flex-row sm:items-center sm:justify-between">
            <button type="button" className="min-h-9 rounded-md px-2 text-left text-xs text-slate-300 underline-offset-4 transition-colors hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-300 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-900" onClick={onDismiss}>Not now</button>
            <button type="submit" className="inline-flex min-h-9 w-full items-center justify-center gap-2 rounded-md bg-sky-400 px-3 text-sm font-semibold text-slate-950 transition-colors hover:bg-sky-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-200 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-900 disabled:cursor-not-allowed disabled:opacity-70 sm:w-auto" disabled={updateMutation.isPending}>
              {updateMutation.isPending ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : null}
              {updateMutation.isPending ? "Saving profile" : "Save profile"}
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}

function ProfileInput({
  label,
  name,
  value,
  onChange,
  required = false,
  error,
  autoComplete,
  inputMode,
}: {
  label: string;
  name: keyof ProfileCompletionFields;
  value: string;
  onChange: (field: keyof ProfileCompletionFields, value: string) => void;
  required?: boolean;
  error?: string;
  autoComplete: string;
  inputMode?: React.HTMLAttributes<HTMLInputElement>["inputMode"];
}) {
  const inputId = `chat-profile-${name}`;
  const errorId = `${inputId}-error`;
  return (
    <div className="grid min-w-0 gap-1">
      <label htmlFor={inputId} className="text-xs font-medium text-slate-200">{label}{required ? <span aria-hidden="true"> *</span> : null}</label>
      <input id={inputId} name={name} className="min-h-10 w-full min-w-0 rounded-md border border-slate-600 bg-slate-950/65 px-3 text-sm text-white outline-none placeholder:text-slate-500 focus:border-sky-300 focus:ring-2 focus:ring-sky-300/45" value={value} onChange={(event) => onChange(name, event.target.value)} autoComplete={autoComplete} inputMode={inputMode} aria-invalid={Boolean(error)} aria-describedby={error ? errorId : undefined} aria-required={required || undefined} />
      {error ? <p id={errorId} role="alert" className="text-xs leading-5 text-rose-200">{error}</p> : null}
    </div>
  );
}

function ProcessingTrail({ entries, isLoading }: { entries: ReturnType<typeof useChat>["processingTrail"]; isLoading: boolean }) {
  const [open, setOpen] = useState(isLoading);
  const latest = entries.at(-1);
  if (!latest) return null;
  return (
    <div className="kairo-processing-trail">
      <button type="button" className="kairo-processing-trail-trigger" onClick={() => setOpen((value) => !value)} aria-expanded={open}>
        <span className="kairo-processing-trail-glyph" aria-hidden="true"><FileCheck2 className="size-3" /></span>
        <span className="min-w-0 flex-1 text-left"><b>Filing trace</b><em>{entries.length} {entries.length === 1 ? "recorded step" : "recorded steps"}</em></span>
        <ChevronDown className={cn("size-3 transition-transform", open && "rotate-180")} aria-hidden="true" />
      </button>
      {open && (
        <ol className="kairo-processing-trail-list" aria-label="Assistant processing steps">
          {entries.map((entry) => (
            <li key={entry.id} className={`kairo-processing-trail-item kairo-processing-trail-item--${entry.kind}`}>
              <span aria-hidden="true" />
              <div><b>{entry.label}</b><p>{entry.detail}</p></div>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}

export function ChatPanel({
  open,
  probe,
  onClose,
  onAssistantDone,
}: {
  open: boolean;
  probe: SessionProbe;
  onClose: () => void;
  onAssistantDone: () => void;
}) {
  const isMobile = useIsMobile();
  const [, setLocation] = useLocation();
  const pageContext = usePageContext();
  const contextRef = useRef(pageContext);
  contextRef.current = pageContext;
  const getContext = useCallback(() => contextRef.current, []);

  const chat = useChat(getContext, onAssistantDone);
  const { data: assistantSettings } = trpc.settings.get.useQuery();
  const completionCueEnabled = assistantSettings?.assistantCompletionCue === true;
  const completionTone = asAssistantChimeTone(assistantSettings?.assistantCompletionTone);
  const completionVolume = clampAssistantChimeVolume(assistantSettings?.assistantCompletionVolume);
  const chimeContextRef = useRef<AudioContext | null>(null);
  const outcomeIdRef = useRef<number | null>(null);
  const [completionAcknowledgement, setCompletionAcknowledgement] = useState<"completed" | "stopped" | null>(null);
  const files = useFileDrop();
  const bodyRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const [inputValue, setInputValue] = useState("");
  const panelRef = useRef<HTMLDivElement>(null);
  const followsLatestRef = useRef(true);
  const [showReturnToLatest, setShowReturnToLatest] = useState(false);

  const syncMobileViewport = useCallback(() => {
    if (!open || !isMobile) return;
    const viewport = window.visualViewport;
    const visibleHeight = viewport?.height ?? window.innerHeight;
    const offsetTop = viewport?.offsetTop ?? 0;
    panelRef.current?.style.setProperty("--kairo-mobile-visible-height", `${Math.round(visibleHeight)}px`);
    panelRef.current?.style.setProperty("--kairo-mobile-viewport-top", `${Math.round(offsetTop)}px`);
    requestAnimationFrame(() => {
      if (bodyRef.current && followsLatestRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
    });
  }, [isMobile, open]);

  useEffect(() => {
    if (!open || !isMobile) return;
    const viewport = window.visualViewport;
    // The visual viewport is the usable rectangle above a mobile keyboard. Keep
    // the panel bound to it rather than the larger layout viewport.
    syncMobileViewport();
    viewport?.addEventListener("resize", syncMobileViewport);
    viewport?.addEventListener("scroll", syncMobileViewport);
    window.addEventListener("resize", syncMobileViewport);
    return () => {
      viewport?.removeEventListener("resize", syncMobileViewport);
      viewport?.removeEventListener("scroll", syncMobileViewport);
      window.removeEventListener("resize", syncMobileViewport);
    };
  }, [open, isMobile, syncMobileViewport]);

  useEffect(() => {
    if (!open || !isMobile) return;
    const { body, documentElement } = document;
    const previous = {
      bodyOverflow: body.style.overflow,
      bodyPosition: body.style.position,
      bodyTop: body.style.top,
      bodyWidth: body.style.width,
      htmlOverflow: documentElement.style.overflow,
    };
    const scrollY = window.scrollY;
    body.style.overflow = "hidden";
    body.style.position = "fixed";
    body.style.top = `-${scrollY}px`;
    body.style.width = "100%";
    documentElement.style.overflow = "hidden";
    return () => {
      body.style.overflow = previous.bodyOverflow;
      body.style.position = previous.bodyPosition;
      body.style.top = previous.bodyTop;
      body.style.width = previous.bodyWidth;
      documentElement.style.overflow = previous.htmlOverflow;
      if (scrollY) window.scrollTo({ top: scrollY, left: 0, behavior: "auto" });
    };
  }, [open, isMobile]);

  const primeCompletionCue = useCallback(() => {
    if (!completionCueEnabled || typeof window === "undefined") return;
    const context = primeAssistantChime(chimeContextRef.current);
    if (!context) return;
    chimeContextRef.current = context;
  }, [completionCueEnabled]);

  useEffect(() => () => {
    void chimeContextRef.current?.close().catch(() => {});
  }, []);

  useEffect(() => {
    const outcome = chat.lastRequestOutcome;
    if (!outcome || outcome.id === outcomeIdRef.current) return;
    outcomeIdRef.current = outcome.id;
    setCompletionAcknowledgement(outcome.kind);
    if (outcome.kind === "completed" && completionCueEnabled) playAssistantChime(chimeContextRef.current, completionTone, completionVolume);
    const timeout = window.setTimeout(() => setCompletionAcknowledgement(null), outcome.kind === "completed" ? 2400 : 1800);
    return () => window.clearTimeout(timeout);
  }, [chat.lastRequestOutcome, completionCueEnabled, completionTone, completionVolume]);

  // Feedback state: map of messageId -> "up" | "down"
  const [feedback, setFeedback] = useState<Record<string, "up" | "down">>({});
  // Thumbs-down comment state
  const [commentingMsgId, setCommentingMsgId] = useState<string | null>(null);
  const [commentText, setCommentText] = useState("");
  // UI-005: messageId whose last feedback request failed — the thumb was set
  // optimistically, so a failure must revert it and say so, not lie "recorded".
  const [feedbackErrorMsgId, setFeedbackErrorMsgId] = useState<string | null>(null);
  // Load feedback when conversation changes
  useEffect(() => {
    const convId = chat.getConversationId();
    if (!convId) { setFeedback({}); return; }
    const result = fetchFeedback(convId);
    if (result && typeof result.then === "function") {
      void result.then((items) => {
        const map: Record<string, "up" | "down"> = {};
        for (const item of items) map[item.messageId] = item.rating;
        setFeedback(map);
      }).catch(() => {});
    }
  }, [chat.messages.length, chat.getConversationId]);

  const handleFeedback = useCallback(async (messageId: string, rating: "up" | "down") => {
    const convId = chat.getConversationId();
    if (!convId || !messageId) return;
    const current = feedback[messageId];
    setFeedbackErrorMsgId(null);
    // Restores the pre-click thumb state after a failed request (UI-005): the
    // update below is optimistic, and a swallowed failure left a thumb lit for
    // feedback that was never recorded.
    const revert = () => {
      setFeedback((prev) => {
        const next = { ...prev };
        if (current) next[messageId] = current;
        else delete next[messageId];
        return next;
      });
      setCommentingMsgId((id) => (id === messageId ? null : id));
      setFeedbackErrorMsgId(messageId);
    };
    if (current === rating) {
      // Toggle off
      setFeedback((prev) => { const next = { ...prev }; delete next[messageId]; return next; });
      setCommentingMsgId(null);
      setCommentText("");
      if (!(await removeFeedbackRequest(messageId))) revert();
    } else {
      // Set or change
      setFeedback((prev) => ({ ...prev, [messageId]: rating }));
      if (rating === "down") {
        // Show comment input for thumbs down
        setCommentingMsgId(messageId);
        setCommentText("");
      } else {
        setCommentingMsgId(null);
        setCommentText("");
      }
      if (!(await submitFeedback(messageId, convId, rating))) revert();
    }
  }, [chat, feedback]);

  const handleSubmitComment = useCallback(async (messageId: string) => {
    const convId = chat.getConversationId();
    if (!convId || !messageId || !commentText.trim()) return;
    setFeedbackErrorMsgId(null);
    if (!(await submitFeedback(messageId, convId, "down", commentText.trim()))) {
      // Keep the box (and the typed comment) open — closing it would read as
      // "recorded" when nothing was (UI-005).
      setFeedbackErrorMsgId(messageId);
      return;
    }
    setCommentingMsgId(null);
    setCommentText("");
  }, [chat, commentText]);

  // History
  const [historyOpen, setHistoryOpen] = useState(false);
  const [history, setHistory] = useState<ConversationSummary[]>([]);
  const [historyActionError, setHistoryActionError] = useState("");
  const refreshHistory = useCallback(async () => {
    setHistoryActionError("");
    try {
      setHistory(await listConversations());
    } catch {
      setHistoryActionError("Couldn't load conversation history — please try again.");
    }
  }, []);
  const toggleHistory = useCallback(() => {
    setHistoryOpen((prev) => {
      if (!prev) void refreshHistory();
      return !prev;
    });
  }, [refreshHistory]);
  const handleDeleteConversation = useCallback(
    async (id: string) => {
      const ok = await deleteConversationRequest(id);
      if (!ok) {
        setHistoryActionError("Couldn't delete this conversation — please try again.");
        return;
      }
      setHistoryActionError("");
      setHistory((prev) => prev.filter((c) => c.id !== id));
      if (chat.isCurrentConversation(id)) void chat.newChat();
    },
    [chat],
  );
  const handleExportConversation = useCallback(async () => {
    const id = chat.getConversationId();
    if (!id) return;
    setHistoryActionError("");
    try {
      await exportConversation(id);
    } catch (err) {
      // Surface the HTTP status (botClient throws Error("export <status>")):
      // a bare banner hid a deterministic 404 (stale server build without the
      // export route) behind "please try again" — undiagnosable from the UI.
      const detail = err instanceof Error && /\d/.test(err.message) ? ` (${err.message.replace(/^export\s*/, "error ")})` : "";
      setHistoryActionError(`Couldn't export this conversation${detail} — please try again.`);
    }
  }, [chat]);
  const handleClearAllConversations = useCallback(async () => {
    if (!window.confirm("Delete all assistant conversations for your account? This cannot be undone.")) return;
    setHistoryActionError("");
    const ok = await clearAllConversations();
    if (!ok) {
      setHistoryActionError("Couldn't clear conversation history — please try again.");
      return;
    }
    setHistory([]);
    setHistoryOpen(false);
    await chat.resume();
  }, [chat]);

  // The conversation follows the user across the app (Nick 2026-08-03): no
  // resume-on-navigation, no resume-on-mount — a fresh page load starts blank
  // (past conversations stay one click away in History), and switching
  // pages/tabs never swaps the transcript. The one fork case (continuing an
  // estate conversation from a different estate's page) is handled at send
  // time in useChat, mirroring the server's scope guard.
  // What navigation DOES do: surface any still-pending write proposals for the
  // estate now in view, so an Apply/Reject card is never invisible (no-orphan
  // guarantee, finding #4). Merge-only; a re-visit is a no-op.
  useEffect(() => {
    if (!open || !pageContext.estateId) return;
    void chat.hydratePendingProposals(pageContext.estateId);
  }, [open, pageContext.estateId, chat]);

  const updateFollowsLatest = useCallback(() => {
    const body = bodyRef.current;
    if (!body) return;
    followsLatestRef.current = body.scrollHeight - body.scrollTop - body.clientHeight < 48;
    setShowReturnToLatest(!followsLatestRef.current);
  }, []);

  const scrollToLatest = useCallback((behavior: ScrollBehavior) => {
    const body = bodyRef.current;
    if (!body) return;
    if (typeof body.scrollTo === "function") {
      body.scrollTo({ top: body.scrollHeight, behavior });
    } else {
      body.scrollTop = body.scrollHeight;
    }
  }, []);

  const returnToLatest = useCallback(() => {
    followsLatestRef.current = true;
    setShowReturnToLatest(false);
    const reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    scrollToLatest(reducedMotion ? "auto" : "smooth");
  }, [scrollToLatest]);

  // Follow a just-sent or received message only while the reader is already at
  // the latest content. This keeps a user who scrolled up to review advice in
  // control of their position.
  useEffect(() => {
    if (!open || !followsLatestRef.current) return;
    const reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    scrollToLatest(reducedMotion ? "auto" : "smooth");
  }, [chat.messages, chat.isLoading, open, scrollToLatest]);

  // Inject copy buttons into code blocks
  useCopyCodeBlocks(bodyRef);

  // Focus input when opened
  useEffect(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 300);
    }
  }, [open]);

  useLayoutEffect(() => {
    const composer = inputRef.current;
    if (!composer) return;
    const maximumHeight = isMobile ? 104 : 128;
    composer.style.height = "0px";
    const nextHeight = Math.min(composer.scrollHeight, maximumHeight);
    composer.style.height = `${Math.max(40, nextHeight)}px`;
    composer.style.overflowY = composer.scrollHeight > maximumHeight ? "auto" : "hidden";
  }, [inputValue, isMobile, open]);

  const handleSend = () => {
    const content = inputValue.trim();
    if (!content || chat.isLoading) return;
    if (files.hasSizeError) return;
    const attachments = files.staged.map(({ name, mime, dataBase64 }) => ({
      name,
      mime,
      dataBase64,
    }));
    files.clearStaged();
    setInputValue("");
    primeCompletionCue();
    void chat.send(content, attachments);
  };

  const handleComposerAction = () => {
    if (chat.isLoading) {
      chat.stop();
      return;
    }
    handleSend();
  };

  const handleSuggest = (prompt: string) => {
    setInputValue("");
    primeCompletionCue();
    void chat.send(prompt, []);
  };

  return (
    <>
      {open && isMobile && <div className="kairo-mobile-backdrop" aria-hidden="true" />}
      <div
        ref={panelRef}
        className={cn(
          "kairo-window",
          open && "visible",
          isMobile && "kairo-window-mobile",
        )}
        role="dialog"
        aria-modal={isMobile || undefined}
        aria-label="ProbatePro Assistant"
        onKeyDown={(e) => {
          if (e.key === "Escape" && !e.defaultPrevented) {
            e.stopPropagation();
            onClose();
          }
        }}
        {...files.dropHandlers}
      >
      {/* ─── Header ─── */}
      <div className="kairo-hd">
        <div className="kairo-hd-av-wrap">
          <BotAvatar />
        </div>
        <div className="kairo-hd-txt">
          <div className="kairo-hd-nm">ProbatePro</div>
          <div className="kairo-hd-lb">Estate Assistant</div>
        </div>
        <div className="kairo-hd-acts">
          <button
            type="button"
            className="kairo-hd-btn"
            onClick={toggleHistory}
            title="History"
            aria-label="Open conversation history"
          >
            <Clock className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            className="kairo-hd-btn"
            onClick={() => void handleExportConversation()}
            title="Export current conversation"
            aria-label="Export current conversation"
            disabled={!chat.getConversationId()}
          >
            <Download className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            className="kairo-hd-btn"
            onClick={() => void handleClearAllConversations()}
            title="Clear all conversation history"
            aria-label="Clear all conversation history"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            className="kairo-hd-btn"
            onClick={() => {
              setHistoryOpen(false);
              void chat.newChat();
            }}
            title="New chat"
            aria-label="Start a new conversation"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
          <button type="button" className="kairo-hd-btn" onClick={onClose} title="Close" aria-label="Close assistant">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* ─── History Dropdown ─── */}
      {historyOpen && (
        <div className="kairo-history-dropdown">
          {/* Sticky + bg-inherit: the outer dropdown is the scroller, so a
              static title row (and its close button) scrolled out of reach. */}
          <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[var(--kairo-hairline)] bg-inherit px-3 py-2">
            <span className="text-xs font-medium text-[var(--kairo-text)]">Conversation History</span>
            <button
              type="button"
              className="kairo-hd-btn !w-6 !h-6"
              onClick={() => setHistoryOpen(false)}
              title="Close history"
              aria-label="Close conversation history"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          {history.length === 0 ? (
            <div className="px-3 py-4 text-center text-[11px] text-[var(--kairo-text-muted)]">
              No past conversations.
            </div>
          ) : (
            <div className="max-h-[300px] overflow-y-auto">
              {history.map((c) => (
                <div key={c.id} className="kairo-history-item group">
                  <button
                    type="button"
                    className="min-w-0 flex-1 text-left"
                    onClick={() => {
                      setHistoryOpen(false);
                      void chat.loadConversation(c.id);
                    }}
                  >
                    <div className="truncate text-xs text-[var(--kairo-text)]">{c.title || "Untitled chat"}</div>
                    <div className="text-[10px] text-[var(--kairo-text-muted)]">
                      {c.scope.startsWith("estate:") ? "Estate" : "General"} ·{" "}
                      {new Date(c.updated_at).toLocaleDateString()}
                    </div>
                  </button>
                  <button
                    type="button"
                    className="shrink-0 rounded p-1 text-[var(--kairo-text-muted)] opacity-0 hover:text-red-600 dark:hover:text-red-300 group-hover:opacity-100 focus:opacity-100"
                    onClick={() => void handleDeleteConversation(c.id)}
                    aria-label="Delete conversation"
                  >
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {probe.status === "unauthorized" ? (
        <div className="flex flex-1 items-center justify-center p-6 text-center text-sm text-[var(--kairo-text-muted)]">
          Session expired — please sign in again.
        </div>
      ) : (
        <>
          {/* Load error */}
          {chat.loadError && (
            <div className="border-b border-[var(--kairo-hairline)] bg-[var(--kairo-surface)] px-3 py-1.5 text-[11px] text-[var(--kairo-warn)]">
              Couldn't load history — the assistant may be offline.
            </div>
          )}
          {historyActionError && (
            <div role="alert" className="border-b border-[var(--kairo-hairline)] bg-[var(--kairo-surface)] px-3 py-1.5 text-[11px] text-[var(--kairo-warn)]">
              {historyActionError}
            </div>
          )}

          {/* Proposals */}
          {chat.proposals.length > 0 && (
            <div className="max-h-56 space-y-2 overflow-y-auto border-b border-[var(--kairo-hairline)] bg-[var(--kairo-surface-sunken)] p-2">
              {chat.proposals.map((p) => (
                <ProposalCard
                  key={p.proposalId}
                  proposal={p}
                  onResolved={chat.updateProposal}
                  onClose={chat.dismissProposalCard}
                />
              ))}
            </div>
          )}

          {/* Nav chips */}
          {chat.navChips.length > 0 && (
            <div className="flex flex-wrap gap-1.5 border-b border-[var(--kairo-hairline)] p-2">
              {chat.navChips.map((chip) => (
                <button
                  type="button"
                  key={chip.path}
                  className="kairo-ch"
                  onClick={() => {
                    setLocation(chip.path);
                    chat.dismissNavChip(chip.path);
                  }}
                >
                  {chip.label}
                </button>
              ))}
            </div>
          )}

          {/* Attachments */}
          {(files.staged.length > 0 || files.dropError) && (
            <div className="border-b border-[var(--kairo-hairline)] p-2">
              <div className="flex flex-wrap gap-1.5">
                {files.staged.map((f) => (
                  <span
                    key={f.id}
                    className="flex items-center gap-1 rounded-full border border-[var(--kairo-accent-border)] bg-[var(--kairo-chip-bg)] px-2 py-0.5 text-[11px] text-[var(--kairo-text-soft)]"
                  >
                    <Paperclip className="size-3" />
                    <span className="max-w-32 truncate">{f.name}</span>
                    <button
                      type="button"
                      className="text-[var(--kairo-text-muted)] hover:text-[var(--kairo-text)]"
                      onClick={() => files.removeStaged(f.id)}
                      aria-label={`Remove attachment ${f.name}`}
                    >
                      <X className="size-3" />
                    </button>
                  </span>
                ))}
              </div>
              {files.dropError && (
                <div className="mt-1 text-[11px] text-[var(--kairo-warn)]">{files.dropError}</div>
              )}
            </div>
          )}

          {/* ─── Message Body ─── */}
          <div className="kairo-body" ref={bodyRef} onScroll={updateFollowsLatest}>
            {chat.messages.length === 0 && !chat.isLoading ? (
              /* Empty state */
              <div className="kairo-empty">
                <div className="kairo-empty-t">How can I help?</div>
                <div className="kairo-empty-s">
                  Ask about your estates, deadlines, or<br />drop documents to fill the intake.
                </div>
                {/* AI-processor notice (Privacy Policy §4) — plain text, not a button:
                    the opener tests assert on button roles only. */}
                <p className="kairo-empty-s mt-3 max-w-[280px] mx-auto opacity-80">
                  The assistant sends your messages, dropped files, and relevant estate
                  data to a third-party AI provider to generate responses. Responses can
                  be inaccurate — verify before relying on them.{" "}
                  <a href="/privacy" target="_blank" rel="noopener noreferrer" className="underline">
                    Privacy Policy
                  </a>
                </p>
                <div className="mt-4 flex flex-wrap justify-center gap-2 relative z-10">
                  {(pageContext.estateId ? ESTATE_PROMPTS : GLOBAL_PROMPTS).map((p) => (
                    <button
                      type="button"
                      key={p}
                      className="kairo-ch"
                      onClick={() => handleSuggest(p)}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <>
                {chat.messages.map((msg, i) =>
                  msg.role === "user" ? (
                    <div key={msg.id || i} className="kairo-usr animate-kairo-slide-in">
                      <div className="kairo-ub">{msg.content}</div>
                    </div>
                  ) : msg.role === "system" ? (
                    <div key={msg.id || i} className="kairo-system-message animate-kairo-slide-in" role="status" aria-label={msg.content}>
                      <span aria-hidden="true">—</span>
                      <span>{msg.content}</span>
                    </div>
                  ) : (
                    <div key={msg.id || i} className="kairo-bot animate-kairo-slide-in">
                      <BotAvatar />
                      <div className="kairo-bb kairo-md">
                        <Streamdown controls={false} rehypePlugins={CHATBOT_REHYPE_PLUGINS} components={CHATBOT_MARKDOWN_COMPONENTS}>{msg.content}</Streamdown>
                      </div>
                      {/* Thumbs up/down feedback */}
                      {msg.id && !chat.isLoading && (
                        <div className="kairo-feedback-wrap">
                          <div className="kairo-feedback">
                            <button
                              type="button"
                              className={cn("kairo-fb-btn", feedback[msg.id] === "up" && "kairo-fb-active")}
                              onClick={() => void handleFeedback(msg.id!, "up")}
                              aria-label="Thumbs up"
                              title="Good response"
                            >
                              <ThumbsUp className="size-3" />
                            </button>
                            <button
                              type="button"
                              className={cn("kairo-fb-btn", feedback[msg.id] === "down" && "kairo-fb-active-down")}
                              onClick={() => void handleFeedback(msg.id!, "down")}
                              aria-label="Thumbs down"
                              title="Poor response"
                            >
                              <ThumbsDown className="size-3" />
                            </button>
                          </div>
                          {/* Thumbs-down comment input */}
                          {commentingMsgId === msg.id && (
                            <div className="kairo-fb-comment">
                              <input
                                type="text"
                                className="kairo-fb-comment-input"
                                placeholder="What went wrong?"
                                value={commentText}
                                onChange={(e) => setCommentText(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === "Enter" && !e.shiftKey) {
                                    e.preventDefault();
                                    void handleSubmitComment(msg.id!);
                                  }
                                }}
                                maxLength={500}
                                autoFocus
                              />
                              <button
                                type="button"
                                className="kairo-fb-comment-send"
                                onClick={() => void handleSubmitComment(msg.id!)}
                                disabled={!commentText.trim()}
                                aria-label="Submit feedback"
                              >
                                <Send className="size-3" />
                              </button>
                            </div>
                          )}
                          {feedbackErrorMsgId === msg.id && (
                            <div role="alert" className="mt-1 text-[11px] text-[var(--kairo-warn)]">
                              Couldn't save your feedback — please try again.
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  ),
                )}
                {chat.profileCompletion && (
                  <InlineProfileCompletionCard
                    profile={chat.profileCompletion.profile}
                    missingFields={chat.profileCompletion.missingFields}
                    onDismiss={chat.dismissProfileCompletion}
                    onSaved={chat.completeProfileCompletion}
                  />
                )}
                {/* Error card with retry */}
                {chat.lastError && !chat.isLoading && (
                  <div className="kairo-error-card animate-kairo-slide-in">
                    <div className="kairo-error-msg">
                      <span className="kairo-error-icon">⚠️</span>
                      <span>{chat.lastError}</span>
                    </div>
                    <button
                      type="button"
                      className="kairo-retry-btn"
                      onClick={() => chat.retry()}
                      disabled={chat.isRetrying}
                    >
                      {chat.isRetrying ? (
                        <Loader2 className="size-3 animate-spin" />
                      ) : (
                        <RefreshCw className="size-3" />
                      )}
                      {chat.isRetrying ? "Retrying..." : "Retry"}
                    </button>
                  </div>
                )}
                {chat.isLoading && (
                  <KairoRequestPresence
                    toolStatus={chat.toolStatus}
                    isRetrying={chat.isRetrying}
                    retryStep={chat.isRetrying ? chat.processingTrail.at(-1)?.detail : undefined}
                  />
                )}
                {chat.processingTrail.length > 0 && <ProcessingTrail entries={chat.processingTrail} isLoading={chat.isLoading} />}
                {completionAcknowledgement && !chat.isLoading && (
                  <div className={cn("kairo-request-outcome animate-kairo-slide-in", completionAcknowledgement === "completed" ? "kairo-request-outcome--complete" : "kairo-request-outcome--stopped")} role="status">
                    <span className="kairo-request-outcome-mark" aria-hidden="true">{completionAcknowledgement === "completed" ? "✓" : "—"}</span>
                    <span>{completionAcknowledgement === "completed" ? "Reply ready" : "Request stopped"}</span>
                  </div>
                )}
              </>
            )}
            {showReturnToLatest && (
              <button
                type="button"
                className="kairo-return-latest"
                onClick={returnToLatest}
                aria-label="Return to latest message"
                title="Return to latest message"
              >
                <MessageSquare className="size-4" aria-hidden="true" />
              </button>
            )}
          </div>

          {/* ─── Footer Input ─── */}
          <div className="kairo-ft">
            <label className="kairo-attach-btn" title="Attach files">
              <FileUp className="w-4 h-4" />
              <span className="sr-only">Attach files</span>
              <input
                type="file"
                multiple
                className="hidden"
                accept=".pdf,.docx,.txt,.md,.csv,.json,.png,.jpg,.jpeg,.gif,.webp"
                onChange={(e) => {
                  if (e.target.files?.length) void files.addFiles(Array.from(e.target.files));
                  e.target.value = "";
                }}
              />
            </label>
            <textarea
              ref={inputRef}
              className="kairo-input"
              placeholder="Type your message..."
              aria-label="Message to ProbatePro Assistant"
              aria-describedby="kairo-composer-help"
              rows={1}
              enterKeyHint="send"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onFocus={() => {
                // iOS can report focus before its keyboard-driven viewport resize.
                // Sync immediately and once after that resize to keep the composer
                // above the keyboard without a jump or a stale bottom gap.
                syncMobileViewport();
                window.setTimeout(syncMobileViewport, 180);
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              disabled={chat.isLoading}
            />
            <span id="kairo-composer-help" className="sr-only">Press Enter to send. Press Shift and Enter for a new line.</span>
            <button
              type="button"
              className={cn("kairo-sb", chat.isLoading && "kairo-sb--cancel")}
              onClick={handleComposerAction}
              disabled={!chat.isLoading && !inputValue.trim()}
              aria-label={chat.isLoading ? "Cancel request" : "Send message"}
              title={chat.isLoading ? "Cancel request" : "Send message"}
            >
              {chat.isLoading ? <Square className="size-[15px] fill-white stroke-white" aria-hidden="true" /> : (
                <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-[17px] h-[17px] stroke-white" aria-hidden="true">
                  <line x1="22" y1="2" x2="11" y2="13" />
                  <polygon points="22 2 15 22 11 13 2 9 22 2" />
                </svg>
              )}
            </button>
          </div>

          {/* Compact attribution — processor disclosure remains available in the empty-state notice and Privacy page. */}
          <div className="kairo-br">
            <a href="https://kairo.chat" target="_blank" rel="noopener noreferrer" className="kairo-br-powered">Powered by <span className="kairo-br-name">Kairo</span></a>
            <a href="/privacy" target="_blank" rel="noopener noreferrer" className="kairo-br-privacy">Privacy</a>
          </div>
        </>
      )}

      {/* Drop overlay */}
      {files.dragActive && (
        <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center border-2 border-dashed border-[var(--kairo-accent)] bg-[var(--kairo-panel-veil)]">
          <span className="text-sm font-medium text-[var(--kairo-text)]">Drop files here</span>
        </div>
      )}
      </div>
    </>
  );
}
