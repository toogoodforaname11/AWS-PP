/**
 * Reactive page context for the chatbot: which page, which estate, which tab.
 * URL is the app's only cross-component page-state channel — EstateDetail keeps
 * its active tab in ?tab= (EstateDetail.tsx:435-473), so this is read-only and
 * free of any coupling to app component state.
 */
import { useLocation, useSearch } from "wouter";
import type { PageContextPayload } from "./botClient";

export function usePageContext(): PageContextPayload {
  const [location] = useLocation();
  const search = useSearch();
  const match = /^\/estate\/([^/]+)/.exec(location);
  const estateId = match?.[1] ?? null;
  const tab = estateId
    ? (new URLSearchParams(search).get("tab") ?? "intake") // EstateDetail defaults to "intake"
    : null;
  return { path: location, estateId, tab };
}
