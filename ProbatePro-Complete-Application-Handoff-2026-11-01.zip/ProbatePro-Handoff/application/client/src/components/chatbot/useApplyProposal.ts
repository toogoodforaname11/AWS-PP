/**
 * Apply/Reject for bot proposals — the legally sensitive piece.
 *
 * DIRTY-INTAKE GUARD: IntakeTab mirrors the whole estate row into local state
 * and full-spread autosaves it on unmount (EstateDetail.tsx:751, :839-852), so
 * a bot write landing during unsaved edits would be silently reverted. Before
 * applying an intake proposal we check the localStorage draft key useLocalDraft
 * writes ("estate_draft_" + "intake_" + estateId, useLocalDraft.ts DRAFT_PREFIX)
 * and block Apply while it exists.
 * ponytail: edits younger than the draft debounce (~1s) have no key yet — known
 * sub-second window; the fix would be a postMessage handshake with frozen app code.
 *
 * INVALIDATION: mirrors the exact query-key set estate.update's own onSuccess
 * invalidates (EstateDetail.tsx:758-774) so a clean IntakeTab re-seeds via its
 * not-dirty effect (:822-826) and the applied values appear in place.
 */
import { useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { applyProposalRequest, dismissProposalRequest } from "./botClient";

export function intakeDraftKey(estateId: string): string {
  return `estate_draft_intake_${estateId}`;
}

export function hasDirtyIntakeDraft(estateId: string): boolean {
  try {
    return localStorage.getItem(intakeDraftKey(estateId)) !== null;
  } catch {
    return false;
  }
}

export type ApplyResult =
  /** `note` is the bot service's summary of what landed, for the transcript. */
  | { outcome: "applied"; note?: string }
  | { outcome: "blocked_dirty" }
  | { outcome: "blocked_saving" }
  | { outcome: "failed"; message: string };

export function useApplyProposal() {
  const utils = trpc.useUtils();

  const apply = useCallback(
    async (proposalId: string, estateId: string, kind: string): Promise<ApplyResult> => {
      if (kind === "intake") {
        // Still-editing case: the draft key exists while the user has unsaved edits.
        if (hasDirtyIntakeDraft(estateId)) return { outcome: "blocked_dirty" };
        // Autosave-race case (Kimi #2): IntakeTab's unmount autosave fires
        // estate.update and clears the draft key SYNCHRONOUSLY before the mutation
        // resolves (EstateDetail.tsx:847-848), so the draft-key check above can read
        // "clean" while a stale full-row write is still in flight — and it can land
        // AFTER the bot's write, silently clobbering it. Block while ANY estate.update
        // is in flight (exact-key, app-wide); the caller waits out the backoff and
        // retries. Combined with the server-side drift guard, both orderings are safe.
        if (utils.estate.update.isMutating() > 0) return { outcome: "blocked_saving" };
      }

      const result = await applyProposalRequest(proposalId);

      // Invalidate the app queries even on FAILURE (ChatGPT #6): a partial or
      // ambiguous apply may have landed some contact/inventory rows (the app's
      // bulk paths are non-transactional) or the estate.update, so the visible
      // app must reflect what actually persisted rather than stay stale.
      // Source of truth for this list: EstateDetail.tsx:758-774 (estate.update onSuccess).
      // Best-effort: a refetch error must never swallow the apply outcome below.
      try {
        await Promise.all([
          utils.readiness.check.invalidate({ estateId }),
          utils.readiness.timeline.invalidate({ estateId }),
          utils.deadline.list.invalidate(),
          utils.estate.list.invalidate(),
          utils.delivery.getRecipients.invalidate({ estateId }),
          utils.document.preflight.invalidate(),
          utils.document.preflightMany.invalidate(),
        ]);
        utils.estate.get.invalidate({ id: estateId });
        if (kind === "contacts") {
          utils.contact.list.invalidate({ estateId });
          utils.distribution.compute.invalidate({ estateId });
          utils.activity.list.invalidate({ estateId });
        } else if (kind === "inventory") {
          utils.inventory.list.invalidate({ estateId });
          utils.inventory.totals.invalidate({ estateId });
          utils.distribution.compute.invalidate({ estateId });
          utils.activity.list.invalidate({ estateId });
        }
      } catch {
        /* invalidation is best-effort */
      }

      if (!result.ok) {
        // Never assert "nothing changed" (finding #2) — a lost response can hide
        // a write that landed. Prefer the server's specific message; the generic
        // fallback tells the user to verify rather than claiming certainty.
        return {
          outcome: "failed",
          message: result.message || "Apply didn't complete — refresh the estate to confirm its current state.",
        };
      }
      return { outcome: "applied", note: result.applied };
    },
    [utils],
  );

  const dismiss = useCallback(
    (proposalId: string): Promise<boolean> => dismissProposalRequest(proposalId),
    [],
  );

  return { apply, dismiss };
}
