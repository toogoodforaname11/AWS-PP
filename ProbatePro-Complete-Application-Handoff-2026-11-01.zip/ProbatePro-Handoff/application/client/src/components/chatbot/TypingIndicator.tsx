/**
 * Animated typing indicator — three bouncing dots that convey
 * "the assistant is thinking" without the generic spinner look.
 */
export function TypingIndicator() {
  return (
    <div className="flex items-center gap-1 px-1 py-1" aria-label="Assistant is typing">
      <span className="typing-dot size-[6px] rounded-full bg-muted-foreground/60" />
      <span className="typing-dot size-[6px] rounded-full bg-muted-foreground/60 [animation-delay:150ms]" />
      <span className="typing-dot size-[6px] rounded-full bg-muted-foreground/60 [animation-delay:300ms]" />
    </div>
  );
}
