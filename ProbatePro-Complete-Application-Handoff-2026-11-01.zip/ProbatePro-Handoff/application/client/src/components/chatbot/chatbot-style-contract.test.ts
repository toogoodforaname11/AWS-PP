import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";

describe("chatbot overlay contract", () => {
  it("keeps every Kairo layer below the app's z-50 modal/dropdown layer", () => {
    const css = readFileSync(join(process.cwd(), "client/src/index.css"), "utf8");
    const kairoBlocks = css.match(/\.kairo-[^{]+\{[^}]*\}/gs) ?? [];
    const layerValues = kairoBlocks.flatMap((block) =>
      [...block.matchAll(/z-index:\s*(-?\d+)/g)].map((match) => Number(match[1])),
    );

    expect(layerValues.length).toBeGreaterThan(0);
    expect(Math.max(...layerValues)).toBeLessThan(50);
    expect(css).not.toMatch(/z-index:\s*9999+/);
  });

  it("keeps the closed assistant launcher docked on the right", () => {
    const css = readFileSync(join(process.cwd(), "client/src/index.css"), "utf8");
    const desktopRoot = css.match(/\.kairo-root\s*\{[^}]*\}/)?.[0] ?? "";
    const mobileRoot = css.match(/@media \(max-width: 767px\)\s*\{[\s\S]*?\.kairo-root\s*\{[^}]*\}/)?.[0] ?? "";
    const tabletRoot = css.match(/@media \(min-width: 481px\) and \(max-width: 767px\)\s*\{[\s\S]*?\.kairo-root\s*\{[^}]*\}/)?.[0] ?? "";
    const narrowMobileRoot = css.match(/@media \(max-width: 480px\)\s*\{[\s\S]*?\.kairo-root\s*\{[^}]*\}/)?.[0] ?? "";
    const assistantHint = css.match(/\.kairo-type\s*\{[^}]*\}/)?.[0] ?? "";

    // The dock stays on the right, but begins at the viewport edge so a
    // standard 32px row action remains directly above the launcher after the
    // browser scrolls it into view.
    expect(desktopRoot).toContain("bottom: 0;");
    expect(desktopRoot).toContain("right: 20px;");
    expect(desktopRoot).toContain("left: auto;");
    expect(mobileRoot).toContain("right: 14px;");
    expect(mobileRoot).toContain("left: auto;");
    expect(tabletRoot).toContain("bottom: -8px;");
    expect(narrowMobileRoot).toContain("bottom: 0;");
    expect(narrowMobileRoot).toContain("right: 14px;");
    expect(narrowMobileRoot).toContain("left: auto;");
    expect(assistantHint).toContain("right: 0;");
    expect(assistantHint).toContain("left: auto;");
  });

  it("keeps the feedback controls on their own row instead of narrowing bot bubbles", () => {
    // .kairo-bot lays out [avatar][bubble][feedback]. Without BOTH halves below,
    // the feedback wrap is a third item on that row and steals the bubble's
    // width — its margin-left then reads as intentional indentation, so the bug
    // looks like a style choice.
    const css = readFileSync(join(process.cwd(), "client/src/index.css"), "utf8");
    const botRow = css.match(/\.kairo-bot\s*\{[^}]*\}/)?.[0] ?? "";
    const feedbackWrap = css.match(/\.kairo-feedback-wrap\s*\{[^}]*\}/)?.[0] ?? "";

    expect(botRow).toMatch(/flex-wrap:\s*wrap/);
    expect(feedbackWrap).toMatch(/flex:\s*0\s+0\s+100%/);
  });

  it("uses an opaque mobile modal veil instead of revealing the page behind a keyboard-shortened panel", () => {
    const css = readFileSync(join(process.cwd(), "client/src/index.css"), "utf8");
    const backdropBlocks = [...css.matchAll(/\.kairo-mobile-backdrop\s*\{[^}]*\}/g)].map((match) => match[0]);
    const backdrop = backdropBlocks.at(-1) ?? "";
    const mobileWindow = css.match(/\.kairo-window-mobile\s*\{[^}]*isolation:\s*isolate[^}]*\}/)?.[0] ?? "";

    expect(backdrop).toContain("background: var(--kairo-panel);");
    expect(backdrop).toMatch(/opacity:\s*1/);
    expect(backdrop).toContain("backdrop-filter: none;");
    expect(mobileWindow).toContain("background: var(--kairo-panel);");
  });

  it("keeps reconnecting motion theme-aligned and limited to users who allow animation", () => {
    const css = readFileSync(join(process.cwd(), "client/src/index.css"), "utf8");

    expect(css).toContain(".kairo-request-presence--retry");
    expect(css).toContain(".kairo-presence-trace--retry");
    expect(css).toContain("@keyframes kairo-retry-sweep");
    expect(css).toMatch(/@media \(prefers-reduced-motion: no-preference\)[\s\S]*?\.kairo-request-presence--retry::before\s*\{\s*animation:\s*kairo-retry-sweep/);
    expect(css).toMatch(/\.kairo-presence-trace--retry svg\s*\{\s*animation:\s*kairo-retry-orbit/);
  });

  it("fades live processing-step changes only when motion is allowed", () => {
    const css = readFileSync(join(process.cwd(), "client/src/index.css"), "utf8");

    expect(css).toContain(".kairo-presence-step-message");
    expect(css).toContain(".kairo-presence-step-message--leaving");
    expect(css).toMatch(/@media \(prefers-reduced-motion: no-preference\)[\s\S]*?\.kairo-presence-step-message\s*\{\s*transition:\s*opacity/);
    expect(css).toMatch(/\.kairo-presence-step-message--leaving\s*\{\s*opacity:\s*0/);
  });

  it("distinguishes cancellation system messages with subdued italic type in both themes", () => {
    const css = readFileSync(join(process.cwd(), "client/src/index.css"), "utf8");

    expect(css).toMatch(/\.kairo-system-message\s*\{[\s\S]*?color:\s*rgba\(183, 193, 210, 0\.82\)[\s\S]*?font-style:\s*italic/);
    expect(css).toContain("html:not(.dark) .kairo-system-message { color: oklch(0.52 0.02 258); }");
  });

  it("scopes every light-theme rule so the dark design cannot be touched", () => {
    // Nick: "the current design for the chatbot is fine for the dark theme
    // DO NOT CHANGE IT IN DARK THEME." The only structural guarantee of that is
    // that no rule in the light section can match when `.dark` is on <html>.
    const css = readFileSync(join(process.cwd(), "client/src/index.css"), "utf8");
    const start = css.indexOf("CHATBOT — LIGHT THEME");
    expect(start).toBeGreaterThan(-1);

    const selectors = [...css.slice(start).matchAll(/^([^\s@{}][^{}]*?)\{/gm)].map((m) =>
      m[1].replace(/\s+/g, " ").trim(),
    );
    expect(selectors.length).toBeGreaterThan(30);

    // The sole legitimate exception is the shared token block, which must
    // declare the DARK defaults for both themes to inherit from.
    const tokenBlock = ".kairo-window, .kairo-root";
    const unscoped = selectors.filter((s) => !s.includes("html:not(.dark)") && s !== tokenBlock);
    expect(unscoped).toEqual([]);
  });

  it("keeps the shared tokens byte-identical to the dark literals they replaced", () => {
    // These colours used to be hardcoded in ChatPanel.tsx as Tailwind arbitrary
    // values. Routing them through variables is only safe while the dark value
    // is exactly what was there before — otherwise the dark design shifts.
    const css = readFileSync(join(process.cwd(), "client/src/index.css"), "utf8");
    for (const [name, literal] of [
      ["--kairo-panel", "#0A0E1A"],
      ["--kairo-surface", "#1a2538"],
      ["--kairo-surface-sunken", "#0f1520"],
      ["--kairo-chip-bg", "#111927"],
      ["--kairo-text", "#e2e8f0"],
      ["--kairo-text-soft", "#cbd5e1"],
      ["--kairo-text-muted", "#94a3b8"],
      ["--kairo-accent", "#3b82f6"],
    ]) {
      expect(css, `${name} must default to the dark literal ${literal}`).toContain(
        `${name}: ${literal};`,
      );
    }
  });
});
