import { useEffect } from "react";

type ClipboardWriter = { writeText: (text: string) => Promise<void> };

/** Copy through the modern API, then a legacy fallback whose boolean result is honored. */
export async function copyText(
  text: string,
  clipboard: ClipboardWriter | null = typeof navigator !== "undefined" ? navigator.clipboard ?? null : null,
  doc: Document = document,
): Promise<boolean> {
  if (clipboard) {
    try {
      await clipboard.writeText(text);
      return true;
    } catch {
      // Continue to the fallback; a denied Clipboard API is common in embedded contexts.
    }
  }

  const ta = doc.createElement("textarea");
  const previousFocus = doc.activeElement as HTMLElement | null;
  ta.value = text;
  ta.style.position = "fixed";
  ta.style.opacity = "0";
  ta.setAttribute("aria-hidden", "true");
  try {
    doc.body.appendChild(ta);
    ta.focus();
    ta.select();
    return typeof doc.execCommand === "function" && doc.execCommand("copy") === true;
  } catch {
    return false;
  } finally {
    ta.remove();
    try {
      previousFocus?.focus();
    } catch {
      // The activating element may have been removed while the async copy ran.
      // Copy success/failure must remain truthful even when focus cannot return.
    }
  }
}

/**
 * Observes a container ref for `<pre>` elements and injects a "Copy" button
 * into each one. When clicked, the button reports either confirmed success or
 * an actionable failure without pretending the clipboard write succeeded.
 */
export function useCopyCodeBlocks(containerRef: React.RefObject<HTMLElement | null>) {
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const injectButtons = () => {
      const pres = container.querySelectorAll<HTMLPreElement>("pre");
      pres.forEach((pre) => {
        // Skip if already has a copy button
        if (pre.querySelector(".kairo-copy-btn")) return;

        // Make pre position relative for absolute button positioning
        pre.style.position = "relative";

        const btn = document.createElement("button");
        btn.className = "kairo-copy-btn";
        btn.textContent = "Copy";
        btn.type = "button";
        btn.setAttribute("aria-label", "Copy code to clipboard");
        btn.setAttribute("aria-live", "polite");
        btn.addEventListener("click", async () => {
          const code = pre.querySelector("code")?.textContent
            ?? Array.from(pre.childNodes).filter((node) => node !== btn).map((node) => node.textContent ?? "").join("");
          const copied = await copyText(code);
          btn.textContent = copied ? "Copied!" : "Copy failed";
          btn.setAttribute("aria-label", copied ? "Code copied to clipboard" : "Copy failed; try selecting the code manually");
          btn.classList.toggle("kairo-copy-btn--ok", copied);
          btn.classList.toggle("kairo-copy-btn--error", !copied);
          window.setTimeout(() => {
            btn.textContent = "Copy";
            btn.setAttribute("aria-label", "Copy code to clipboard");
            btn.classList.remove("kairo-copy-btn--ok", "kairo-copy-btn--error");
          }, 1800);
        });

        pre.appendChild(btn);
      });
    };

    // Run immediately for existing pre elements
    injectButtons();

    // Observe for new pre elements added by Streamdown
    const observer = new MutationObserver(() => injectButtons());
    observer.observe(container, { childList: true, subtree: true });

    return () => observer.disconnect();
  }, [containerRef]);
}
