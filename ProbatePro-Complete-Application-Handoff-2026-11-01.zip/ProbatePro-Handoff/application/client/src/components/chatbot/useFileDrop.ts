/**
 * File + FOLDER drag-and-drop for the chat panel.
 *
 * Folder traversal is net-new for this app (nothing else uses
 * webkitGetAsEntry). Two known Chrome gotchas handled: readEntries() returns at
 * most 100 entries per call (must loop), and hidden/system files are skipped.
 * Caps mirror the bot service (chatbot/src/extract.ts): 8 files, 15 MB/file,
 * 20 MB total.
 */
import { useCallback, useRef, useState } from "react";
import type { OutgoingAttachment } from "./botClient";

export const MAX_FILES = 8;
export const MAX_FILE_BYTES = 15 * 1024 * 1024;
export const MAX_TOTAL_BYTES = 20 * 1024 * 1024;
const MAX_DEPTH = 5;

const ACCEPTED = /\.(pdf|docx|txt|md|csv|json|png|jpe?g|gif|webp)$/i;
const SKIP_NAMES = /^(\.|thumbs\.db$|desktop\.ini$)/i;

export type StagedFile = {
  id: string;
  name: string;
  mime: string;
  size: number;
  dataBase64: string;
};

function readEntriesAll(reader: any): Promise<any[]> {
  // Chrome caps each readEntries() call at 100 entries — loop until empty.
  return new Promise((resolve) => {
    const all: any[] = [];
    const step = () =>
      reader.readEntries(
        (batch: any[]) => {
          if (!batch.length) return resolve(all);
          all.push(...batch);
          step();
        },
        () => resolve(all),
      );
    step();
  });
}

async function collectFiles(items: DataTransferItemList): Promise<File[]> {
  const files: File[] = [];

  async function walk(entry: any, depth: number): Promise<void> {
    if (!entry || depth > MAX_DEPTH || files.length >= MAX_FILES * 3) return;
    if (SKIP_NAMES.test(entry.name)) return;
    if (entry.isFile) {
      const file = await new Promise<File | null>((resolve) =>
        entry.file(resolve, () => resolve(null)),
      );
      if (file) files.push(file);
    } else if (entry.isDirectory) {
      const entries = await readEntriesAll(entry.createReader());
      for (const child of entries) await walk(child, depth + 1);
    }
  }

  const entries: any[] = [];
  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    const entry = (item as any).webkitGetAsEntry?.();
    if (entry) entries.push(entry);
  }
  if (entries.length) {
    for (const entry of entries) await walk(entry, 0);
  }
  return files;
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || "");
      resolve(result.slice(result.indexOf(",") + 1)); // strip data: prefix
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

export function useFileDrop() {
  const [staged, setStaged] = useState<StagedFile[]>([]);
  const [dragActive, setDragActive] = useState(false);
  const [dropError, setDropError] = useState<string | null>(null);
  const dragCounter = useRef(0);
  // Synchronous mirror of `staged` so overlapping drops cap against live state
  // (a setState updater must be pure — no side effects, no stale cap).
  const stagedRef = useRef<StagedFile[]>([]);
  const idRef = useRef(0);

  const addFiles = useCallback(async (incoming: File[]) => {
    setDropError(null);
    const rejected: string[] = [];
    const eligible: File[] = [];
    for (const file of incoming) {
      if (!ACCEPTED.test(file.name)) rejected.push(`${file.name} (type)`);
      else if (file.size > MAX_FILE_BYTES) rejected.push(`${file.name} (>15 MB)`);
      else eligible.push(file);
    }
    // Convert first (async, no setState involved)…
    const converted: StagedFile[] = [];
    for (const file of eligible) {
      try {
        converted.push({
          id: `f${idRef.current++}`,
          name: file.name,
          mime: file.type || "application/octet-stream",
          size: file.size,
          dataBase64: await fileToBase64(file),
        });
      } catch {
        rejected.push(`${file.name} (read failed)`);
      }
    }
    // …then one pure update against the live mirror, with the cap applied here.
    const combined = [...stagedRef.current, ...converted];
    const next = combined.slice(0, MAX_FILES);
    if (combined.length > next.length) {
      rejected.push(`${combined.length - next.length} more (max ${MAX_FILES} files)`);
    }
    stagedRef.current = next;
    setStaged(next);
    const total = next.reduce((sum, f) => sum + f.size, 0);
    if (total > MAX_TOTAL_BYTES) {
      rejected.push("total over 20 MB — remove some before sending");
    }
    if (rejected.length) setDropError(`Skipped: ${rejected.join(", ")}`);
  }, []);

  const onDrop = useCallback(
    async (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      dragCounter.current = 0;
      setDragActive(false);
      const items = e.dataTransfer?.items;
      let files: File[] = [];
      if (items?.length && (items[0] as any).webkitGetAsEntry) {
        files = await collectFiles(items); // folders traversed here
      }
      if (!files.length && e.dataTransfer?.files?.length) {
        files = Array.from(e.dataTransfer.files);
      }
      if (files.length) await addFiles(files);
    },
    [addFiles],
  );

  const onDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    dragCounter.current++;
    setDragActive(true);
  }, []);
  const onDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    dragCounter.current = Math.max(0, dragCounter.current - 1);
    if (dragCounter.current === 0) setDragActive(false);
  }, []);
  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
  }, []);

  const removeStaged = useCallback((id: string) => {
    stagedRef.current = stagedRef.current.filter((f) => f.id !== id);
    setStaged(stagedRef.current);
    setDropError(null);
  }, []);
  const clearStaged = useCallback(() => {
    stagedRef.current = [];
    setStaged([]);
    setDropError(null);
  }, []);

  const hasSizeError = staged.reduce((s, f) => s + f.size, 0) > MAX_TOTAL_BYTES;

  return {
    staged,
    dragActive,
    dropError,
    hasSizeError,
    addFiles,
    removeStaged,
    clearStaged,
    dropHandlers: { onDrop, onDragEnter, onDragLeave, onDragOver },
  };
}
