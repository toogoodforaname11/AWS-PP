/**
 * Apply/Reject is the legally sensitive path — the only way bot-drafted values
 * reach an estate — and it had no test at all. These cover what a user sees
 * after clicking, which is exactly what was reported broken: a click that
 * appeared to do nothing.
 */
import { act, fireEvent, render, screen, waitFor } from "@testing-library/react";
import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ProposalCard } from "./ProposalCard";
import type { ProposalCardState } from "./useChat";

const mocks = vi.hoisted(() => ({
  apply: vi.fn(),
  dismiss: vi.fn(),
  hasDirtyIntakeDraft: vi.fn(() => false),
  toastSuccess: vi.fn(),
}));

vi.mock("sonner", () => ({ toast: { success: mocks.toastSuccess } }));
vi.mock("./useApplyProposal", () => ({
  useApplyProposal: () => ({ apply: mocks.apply, dismiss: mocks.dismiss }),
  hasDirtyIntakeDraft: mocks.hasDirtyIntakeDraft,
}));

const proposal = (over: Partial<ProposalCardState> = {}): ProposalCardState => ({
  proposalId: "p1",
  estateId: "e1",
  kind: "intake",
  status: "pending",
  diff: {
    kind: "intake",
    estateId: "e1",
    estateName: "Alice B. Carter",
    rows: [
      {
        key: "deceasedResidenceCity",
        label: "Former residence city",
        oldValue: "",
        newValue: "Victoria",
        source: "Form P1 p.1",
      },
    ],
  },
  ...over,
});

describe("ProposalCard Apply", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.hasDirtyIntakeDraft.mockReturnValue(false);
  });
  afterEach(() => vi.useRealTimers());

  it("confirms a successful apply visibly and passes the server's summary up", async () => {
    // The "Applied" badge lives in a scrolling tray and can be entirely
    // off-screen, so a successful write could otherwise leave nothing on screen.
    mocks.apply.mockResolvedValue({
      outcome: "applied",
      note: "✅ Applied — now saved on the estate: Former residence city.",
    });
    const onResolved = vi.fn();
    render(<ProposalCard proposal={proposal()} onResolved={onResolved} />);

    fireEvent.click(screen.getByRole("button", { name: /Apply/ }));

    await waitFor(() => expect(onResolved).toHaveBeenCalled());
    expect(mocks.toastSuccess).toHaveBeenCalled();
    // The note must reach useChat so it lands in the transcript, not just a badge.
    expect(onResolved).toHaveBeenCalledWith(
      "p1",
      "applied",
      expect.stringContaining("Former residence city"),
    );
  });

  it("explains the wait instead of spinning silently while an Intake save settles", async () => {
    // handleApply clears `blocked` and sets `settling`, so a banner gated on
    // `blocked` alone was unreachable: the user got a disabled, spinning Apply
    // button for six seconds with no stated reason.
    vi.useFakeTimers();
    mocks.apply.mockResolvedValue({ outcome: "blocked_saving" });
    render(<ProposalCard proposal={proposal()} onResolved={vi.fn()} />);

    await act(async () => {
      fireEvent.click(screen.getByRole("button", { name: /Apply/ }));
    });

    expect(screen.getByText(/Waiting for your Intake edits to finish saving/i)).toBeTruthy();
  });

  it("tells the user why Apply is refused while they have unsaved Intake edits", async () => {
    mocks.apply.mockResolvedValue({ outcome: "blocked_dirty" });
    render(<ProposalCard proposal={proposal()} onResolved={vi.fn()} />);

    fireEvent.click(screen.getByRole("button", { name: /Apply/ }));

    await waitFor(() =>
      expect(screen.getByText(/unsaved Intake edits/i)).toBeTruthy(),
    );
  });

  it("can be dismissed once resolved, but offers no close while still pending", async () => {
    // An applied card had no close control, so it stayed expanded above the
    // transcript for the entire session, permanently eating panel height.
    vi.useFakeTimers();
    const onClose = vi.fn();
    const { rerender } = render(
      <ProposalCard proposal={proposal()} onResolved={vi.fn()} onClose={onClose} />,
    );
    // Pending: closing it would strand a decision the user has not made.
    expect(screen.queryByRole("button", { name: "Dismiss this proposal card" })).toBeNull();

    rerender(
      <ProposalCard proposal={proposal({ status: "applied" })} onResolved={vi.fn()} onClose={onClose} />,
    );
    fireEvent.click(screen.getByRole("button", { name: "Dismiss this proposal card" }));
    // The close callback fires after the fade-out animation (220ms)
    expect(onClose).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(220);
    expect(onClose).toHaveBeenCalledWith("p1");
    vi.useRealTimers();
  });

  it("surfaces a failed apply rather than reporting success", async () => {
    mocks.apply.mockResolvedValue({ outcome: "failed", message: "Apply didn't complete." });
    const onResolved = vi.fn();
    render(<ProposalCard proposal={proposal()} onResolved={onResolved} />);

    fireEvent.click(screen.getByRole("button", { name: /Apply/ }));

    await waitFor(() =>
      expect(onResolved).toHaveBeenCalledWith("p1", "failed", "Apply didn't complete."),
    );
    expect(mocks.toastSuccess).not.toHaveBeenCalled();
  });
});

describe("ProposalCard hydration animation", () => {
  it("uses the hydrate entrance class when proposal.hydrated is true", () => {
    const { container } = render(
      <ProposalCard proposal={proposal({ hydrated: true })} onResolved={vi.fn()} />,
    );
    const card = container.firstElementChild as HTMLElement;
    expect(card.className).toContain("kairo-proposal-hydrate");
    expect(card.className).not.toContain("kairo-proposal-enter");
  });

  it("uses the normal entrance class when proposal.hydrated is absent", () => {
    const { container } = render(
      <ProposalCard proposal={proposal()} onResolved={vi.fn()} />,
    );
    const card = container.firstElementChild as HTMLElement;
    expect(card.className).toContain("kairo-proposal-enter");
    expect(card.className).not.toContain("kairo-proposal-hydrate");
  });
});
