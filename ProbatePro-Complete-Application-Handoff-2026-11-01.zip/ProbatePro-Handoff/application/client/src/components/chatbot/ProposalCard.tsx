/**
 * Renders one bot proposal as a reviewable diff card with Apply / Reject.
 * Every row shows old → new plus its provenance ("from will.pdf p.1") so the
 * user reviews evidence, not just values — sworn-document doctrine.
 */
// React must be in scope: vitest.config.ts registers no React plugin, so tests
// compile JSX with esbuild's classic transform (React.createElement). Without
// this import the component cannot be rendered in a test at all — which is why
// the Apply path went untested. Matches ChatPanel.tsx.
import React, { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Check, Loader2, X } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ProposalCardState } from "./useChat";
import { useApplyProposal, hasDirtyIntakeDraft } from "./useApplyProposal";
import type { DiffRow } from "./botClient";

const KIND_LABELS: Record<string, string> = {
  intake: "Intake update",
  contact_updates: "Contact change",
  contacts: "New contacts",
  inventory: "New inventory items",
};

function DiffRows({ rows }: { rows: DiffRow[] }) {
  return (
    <div className="space-y-1">
      {rows.map((row, i) => (
        <div key={`${row.key}-${i}`} className="text-xs leading-snug">
          <span className="font-medium">{row.label}:</span>{" "}
          {row.oldValue && row.oldValue !== "—" ? (
            <span className="line-through text-[var(--kairo-text-muted)] mr-1">{row.oldValue}</span>
          ) : null}
          <span className="text-[var(--kairo-text)] font-medium">{row.newValue || "—"}</span>
          <span className="ml-1 text-[10px] text-[var(--kairo-text-muted)] italic">({row.source})</span>
        </div>
      ))}
    </div>
  );
}

export function ProposalCard({
  proposal,
  onResolved,
  onClose,
}: {
  proposal: ProposalCardState;
  onResolved: (proposalId: string, status: "applied" | "dismissed" | "failed", message?: string) => void;
  /** Remove a RESOLVED card from the tray. Absent while it is still pending. */
  onClose?: (proposalId: string) => void;
}) {
  const { apply, dismiss } = useApplyProposal();
  const [busy, setBusy] = useState(false);
  const [blocked, setBlocked] = useState(false);
  const [blockedReason, setBlockedReason] = useState<"dirty" | "saving">("dirty");
  const [settling, setSettling] = useState(false);
  const [exiting, setExiting] = useState(false);
  const exitTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Cleanup exit timer on unmount
  useEffect(() => () => { if (exitTimerRef.current) clearTimeout(exitTimerRef.current); }, []);

  const handleClose = useCallback(() => {
    if (!onClose) return;
    setExiting(true);
    exitTimerRef.current = setTimeout(() => {
      onClose(proposal.proposalId);
    }, 220); // matches animation duration
  }, [onClose, proposal.proposalId]);

  // When the intake draft key just disappeared, IntakeTab's unmount autosave may
  // still be in flight (main.tsx retries 5xx with ~1.5s+3s backoff), and that
  // stale full-row snapshot would clobber a bot write that landed first. Hold
  // Apply for a settle window past that backoff before re-enabling.
  const SETTLE_MS = 6000;
  const recheck = () => {
    if (hasDirtyIntakeDraft(proposal.estateId)) {
      setBlocked(true);
      return;
    }
    setSettling(true);
    setTimeout(() => {
      setSettling(false);
      setBlocked(hasDirtyIntakeDraft(proposal.estateId));
    }, SETTLE_MS);
  };

  const { diff } = proposal;
  const groups = diff.groups?.length ? diff.groups : diff.rows.length ? [diff.rows] : [];

  const handleApply = async (attempt = 0) => {
    setBusy(true);
    setBlocked(false);
    const result = await apply(proposal.proposalId, proposal.estateId, proposal.kind);
    setBusy(false);
    if (result.outcome === "applied") {
      // The card's "Applied" badge sits in a scrolling tray and can be entirely
      // off-screen, so a successful write could leave nothing visible. Toast it
      // the way the app toasts its own Intake saves.
      toast.success("Estate updated by the assistant");
      onResolved(proposal.proposalId, "applied", result.note);
    }
    else if (result.outcome === "blocked_dirty") {
      setBlockedReason("dirty");
      setBlocked(true);
    } else if (result.outcome === "blocked_saving") {
      // An Intake autosave is in flight (finding #2). Wait out its retry/backoff,
      // then retry once automatically so the user doesn't have to re-click. If it
      // is STILL saving after the window, fall back to the manual banner.
      if (attempt < 1) {
        setSettling(true);
        setTimeout(() => {
          setSettling(false);
          void handleApply(attempt + 1);
        }, SETTLE_MS);
      } else {
        setBlockedReason("saving");
        setBlocked(true);
      }
    } else onResolved(proposal.proposalId, "failed", result.message);
  };

  const handleReject = async () => {
    setBusy(true);
    const ok = await dismiss(proposal.proposalId);
    setBusy(false);
    // Only show "Rejected" on a CONFIRMED dismissal (ChatGPT #8): a 409 (it was
    // just applied elsewhere) or a network failure must not fake success.
    if (ok) onResolved(proposal.proposalId, "dismissed");
    else
      onResolved(
        proposal.proposalId,
        "failed",
        "Couldn't reject — it may have just been applied. Refresh the estate to check.",
      );
  };

  return (
    <div
      className={cn(
        "rounded-lg border border-[var(--kairo-hairline)] bg-[var(--kairo-surface)] p-3 text-[var(--kairo-text)] shadow-sm",
        proposal.hydrated ? "kairo-proposal-hydrate" : "kairo-proposal-enter",
        exiting && "kairo-proposal-exit",
        proposal.status === "applied" && "border-emerald-500/50",
        proposal.status === "failed" && "border-destructive/50",
      )}
    >
      <div className="mb-2 flex items-center justify-between gap-2">
        <div className="min-w-0">
          <div className="text-xs font-semibold">
            {KIND_LABELS[proposal.kind] ?? proposal.kind} — {diff.estateName}
          </div>
          <div className="text-[10px] text-[var(--kairo-text-muted)]">Review each value, then Apply.</div>
        </div>
        {proposal.status === "applied" && (
          <span className="flex shrink-0 items-center gap-1 text-xs text-emerald-700 dark:text-emerald-300">
            <Check className="size-3.5" /> Applied
          </span>
        )}
        {proposal.status === "dismissed" && (
          <span className="shrink-0 text-xs text-[var(--kairo-text-muted)]">Rejected</span>
        )}
        {proposal.status === "failed" && (
          <span className="shrink-0 text-xs text-destructive">Failed</span>
        )}
        {/* Once resolved the card is a receipt, not a control. Without this it
            stayed expanded above the transcript for the whole session. */}
        {proposal.status !== "pending" && onClose && (
          <button
            type="button"
            className="shrink-0 rounded p-1 text-[var(--kairo-text-muted)] hover:text-[var(--kairo-text)]"
            onClick={handleClose}
            aria-label="Dismiss this proposal card"
            title="Close"
          >
            <X className="size-3.5" />
          </button>
        )}
      </div>

      <div className="max-h-48 space-y-2 overflow-y-auto pr-1">
        {groups.map((rows, i) => (
          <div key={i} className={cn(groups.length > 1 && "rounded border border-[var(--kairo-hairline)] p-2")}>
            <DiffRows rows={rows} />
          </div>
        ))}
      </div>

      {/* Legally-consequential-fields notice (finding #5): roles, relationships,
          and minor/predeceased flags drive statutory determinations the app
          derives — the lawyer confirms them, the bot only transcribes. */}
      {proposal.kind === "contacts" && proposal.status === "pending" && (
        <div className="mt-2 text-[10px] leading-snug text-[var(--kairo-text-muted)]">
          Role, relationship, and minor/predeceased flags drive Rule 25 notices, PGT involvement,
          and distribution. Verify each in the Contacts tab after applying.
        </div>
      )}

      {(blocked || settling) && (
        <div className="mt-2 flex items-start gap-1.5 rounded border border-amber-500/40 bg-amber-500/10 p-2 text-[11px] leading-snug">
          <AlertTriangle className="mt-0.5 size-3.5 shrink-0 text-amber-600" />
          <div>
            {settling ? (
              <>Waiting for your Intake edits to finish saving…</>
            ) : blockedReason === "saving" ? (
              <>
                Your Intake edits are still saving. Wait a moment, then
                <Button
                  variant="link"
                  size="sm"
                  className="h-auto p-0 pl-1 text-[11px]"
                  onClick={() => void handleApply()}
                >
                  try again
                </Button>
                .
              </>
            ) : (
              <>
                You have unsaved Intake edits on this estate. Switch off the Intake tab (your edits
                auto-save) and try again.
                <Button
                  variant="link"
                  size="sm"
                  className="h-auto p-0 pl-1 text-[11px]"
                  onClick={recheck}
                >
                  Re-check
                </Button>
              </>
            )}
          </div>
        </div>
      )}

      {proposal.status === "failed" && proposal.message && (
        <div className="mt-2 text-[11px] text-destructive">{proposal.message}</div>
      )}

      {proposal.status === "pending" && (
        <div className="mt-2 flex gap-2">
          <Button
            size="sm"
            className="h-7 text-xs"
            onClick={() => void handleApply()}
            disabled={busy || settling}
          >
            {busy || settling ? (
              <Loader2 className="size-3 animate-spin" />
            ) : (
              <Check className="size-3" />
            )}
            Apply
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-7 text-xs"
            onClick={handleReject}
            disabled={busy}
          >
            <X className="size-3" /> Reject
          </Button>
        </div>
      )}
    </div>
  );
}
