import { fireEvent, render, screen } from "@testing-library/react";
import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ChatbotWidget } from "./ChatbotWidget";

const mocks = vi.hoisted(() => ({ probeSession: vi.fn() }));

vi.mock("./botClient", () => ({ probeSession: mocks.probeSession }));

describe("ChatbotWidget accessibility", () => {
  beforeEach(() => {
    localStorage.clear();
    mocks.probeSession.mockResolvedValue({ status: "ok", name: "Test User" });
    vi.stubGlobal("requestAnimationFrame", vi.fn(() => 1));
    vi.stubGlobal("cancelAnimationFrame", vi.fn());
    Object.defineProperty(window, "requestIdleCallback", {
      configurable: true,
      value: (callback: () => void) => { callback(); return 1; },
    });
    vi.spyOn(HTMLCanvasElement.prototype, "getContext").mockReturnValue({
      setTransform: vi.fn(),
    } as unknown as CanvasRenderingContext2D);
  });

  afterEach(() => {
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
    Reflect.deleteProperty(window, "requestIdleCallback");
  });

  it("labels both the launcher and the independently clickable hint dismiss control", async () => {
    render(<ChatbotWidget enabled />);
    expect(await screen.findByRole("button", { name: "Open ProbatePro Assistant" })).toBeTruthy();
    const dismiss = screen.getByRole("button", { name: "Dismiss assistant hint" });
    fireEvent.click(dismiss);
    expect(screen.queryByRole("button", { name: "Dismiss assistant hint" })).toBeNull();
  });

  it("shows unavailable banner when processor approval is disabled", () => {
    render(<ChatbotWidget enabled={false} />);
    expect(mocks.probeSession).not.toHaveBeenCalled();
    expect(screen.queryByRole("button", { name: "Open ProbatePro Assistant" })).toBeNull();
    expect(screen.getByText("Assistant unavailable")).toBeTruthy();
    expect(screen.getByText(/AI features are pending privacy/)).toBeTruthy();
    expect(screen.getByRole("status")).toBeTruthy();
  });

  it("stays silent while the feature decision is unresolved", () => {
    render(<ChatbotWidget enabled={undefined} />);
    expect(screen.queryByText("Assistant unavailable")).toBeNull();
    expect(mocks.probeSession).not.toHaveBeenCalled();
  });

  it("renders no assistant UI when the user preference hides the chatbot", () => {
    render(<ChatbotWidget enabled={false} visible={false} />);
    expect(screen.queryByText("Assistant unavailable")).toBeNull();
    expect(screen.queryByRole("button", { name: "Open ProbatePro Assistant" })).toBeNull();
    expect(mocks.probeSession).not.toHaveBeenCalled();
  });

  it("dismisses the unavailable banner when close button is clicked", () => {
    render(<ChatbotWidget enabled={false} />);
    expect(screen.getByText("Assistant unavailable")).toBeTruthy();
    const dismiss = screen.getByRole("button", { name: "Dismiss assistant unavailable notice" });
    fireEvent.click(dismiss);
    expect(screen.queryByText("Assistant unavailable")).toBeNull();
  });
});
