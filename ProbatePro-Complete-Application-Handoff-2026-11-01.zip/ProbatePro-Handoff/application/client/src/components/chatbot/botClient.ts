/**
 * HTTP client for the chatbot mounted at /chatbot (the service also retains an
 * optional loopback-only standalone development mode).
 *
 * ADDITIVE MODULE — imports nothing that mutates app state. Auth is the app's
 * own session JWT, acquired per-request the exact way main.tsx's Bearer
 * fallback does (sessionStorage "manus-cookie" mirror, main.tsx:50-63), plus
 * credentials:"include" so the httpOnly cookie rides along on same-host dev
 * setups (RFC 6265: cookies are host-scoped, ports ignored). The token is never
 * cached in module or React state.
 */
import { COOKIE_NAME } from "@shared/const";

export const BOT_BASE: string =
  (import.meta as any).env?.VITE_CHATBOT_URL ??
  `${window.location.origin}/chatbot`;

function readToken(): string | null {
  try {
    const raw = sessionStorage.getItem("manus-cookie");
    if (!raw) return null;
    const prefix = `${COOKIE_NAME}=`;
    const pair = raw.split(";").find((s) => s.trim().startsWith(prefix));
    return pair?.trim().slice(prefix.length) || null;
  } catch {
    return null;
  }
}

/** Adopt a rotated session exactly as main.tsx:73-78 does. */
function adoptRotation(value: string | null): void {
  if (!value) return;
  try {
    sessionStorage.setItem("manus-cookie", value);
  } catch {
    // sessionStorage unavailable — cookie-only session keeps rotating on its own
  }
}

function baseHeaders(): Record<string, string> {
  const headers: Record<string, string> = { "X-App-Origin": window.location.origin };
  const token = readToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  return headers;
}

async function botFetch(path: string, init?: RequestInit): Promise<Response> {
  const res = await fetch(`${BOT_BASE}${path}`, {
    ...init,
    headers: { ...baseHeaders(), ...(init?.headers as Record<string, string> | undefined) },
    credentials: "include",
  });
  adoptRotation(res.headers.get("X-Rotated-Session"));
  return res;
}

// ── Types mirrored from chatbot/src (kept in sync by hand — no build coupling) ──

export type DiffRow = { key: string; label: string; oldValue: string; newValue: string; source: string };
export type ProposalDiff = {
  kind: "intake" | "contacts" | "inventory" | "contact_updates";
  estateId: string;
  estateName: string;
  rows: DiffRow[];
  groups?: DiffRow[][];
};

export type ProfileCompletionFields = {
  lawyerName: string;
  firmName: string;
  firmAddress: string;
  firmPhone: string;
  firmEmail: string;
};
export type ProfileCompletionField = "lawyerName" | "firmName" | "firmEmail";

export type BotStreamEvent =
  | { type: "conversation"; conversationId: string }
  | { type: "profile_completion"; profile: ProfileCompletionFields; missingFields: ProfileCompletionField[] }
  | { type: "text_delta"; text: string }
  | { type: "text_replace"; text: string }
  | { type: "tool_start"; name: string; label: string }
  | { type: "tool_done"; name: string; ok: boolean }
  | { type: "proposal"; proposalId: string; kind: string; estateId: string; diff: ProposalDiff }
  | { type: "navigate"; path: string; label: string }
  | { type: "session_rotated"; value: string }
  | { type: "done"; conversationId: string; messageId: string }
  | { type: "error"; message: string; retryable?: boolean; retryAfterMs?: number };

export type PageContextPayload = { path: string; estateId: string | null; tab: string | null };
export type OutgoingAttachment = { name: string; mime: string; dataBase64: string };

// ── REST surface ─────────────────────────────────────────────────────────────

export type SessionProbe = { status: "ok"; name: string } | { status: "unauthorized" } | { status: "offline" };

export async function probeSession(): Promise<SessionProbe> {
  try {
    const res = await botFetch("/api/session");
    if (res.status === 401) return { status: "unauthorized" };
    if (!res.ok) return { status: "offline" };
    const body = await res.json();
    return { status: "ok", name: body.name ?? "" };
  } catch {
    return { status: "offline" };
  }
}

export async function fetchLatestConversation(scope: string): Promise<{
  conversation: { id: string; scope: string } | null;
  messages: Array<{ id: string; role: "user" | "assistant"; text: string }>;
}> {
  const res = await botFetch(`/api/conversations/latest?scope=${encodeURIComponent(scope)}`);
  // THROW on a real bot error (finding #7): a 500/restart must not masquerade as
  // "no history" and let the caller wipe the view. A genuinely-empty scope is a
  // 200 with { conversation: null }.
  if (!res.ok) throw new Error(`latest ${res.status}`);
  return res.json();
}

export async function createConversation(scope: string): Promise<{ id: string } | null> {
  const res = await botFetch("/api/conversations", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ scope }),
  });
  return res.ok ? res.json() : null;
}

export type ConversationSummary = {
  id: string;
  scope: string;
  title: string | null;
  updated_at: number;
};

/** Recent conversations for the History list (finding #6c). */
export async function listConversations(): Promise<ConversationSummary[]> {
  const res = await botFetch("/api/conversations");
  if (!res.ok) throw new Error(`conversations ${res.status}`);
  return res.json();
}

/** Load one conversation's messages to switch to it. */
export async function fetchConversation(id: string): Promise<{
  conversation: { id: string; scope: string } | null;
  messages: Array<{ id: string; role: "user" | "assistant"; text: string }>;
}> {
  const res = await botFetch(`/api/conversations/${encodeURIComponent(id)}`);
  // 404 = the conversation is genuinely gone (deleted; stale History row) — treat
  // as "not found". Any other non-OK is a bot error → throw so the caller shows an
  // error instead of silently clearing the view (finding #7).
  if (res.status === 404) return { conversation: null, messages: [] };
  if (!res.ok) throw new Error(`conversation ${res.status}`);
  return res.json();
}

/** Delete a conversation and its proposals (the user-facing privacy control). */
export async function deleteConversationRequest(id: string): Promise<boolean> {
  const res = await botFetch(`/api/conversations/${encodeURIComponent(id)}`, {
    method: "DELETE",
  }).catch(() => null);
  return !!res && res.ok;
}

export async function applyProposalRequest(
  proposalId: string,
): Promise<{ ok: boolean; invalidate?: string[]; message?: string; applied?: string }> {
  try {
    const res = await botFetch(`/api/proposals/${encodeURIComponent(proposalId)}/apply`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: "{}",
    });
    const body = await res.json().catch(() => ({}));
    return res.ok
      ? // `applied` is the server's own summary of what landed. Reusing it keeps
        // one source of truth for that wording across two independently-built
        // trees, instead of the widget re-deriving it from the diff.
        { ok: true, invalidate: body.invalidate, applied: body.applied }
      : { ok: false, message: body.message };
  } catch {
    // Bot unreachable AFTER the request left the browser — the write may or may
    // not have landed (finding #2). Never claim "nothing changed"; tell the user
    // the outcome is unconfirmed so they verify before retrying.
    return {
      ok: false,
      message: "Couldn't confirm the change — the assistant was unreachable. Refresh the estate to check before retrying.",
    };
  }
}

/** Pending proposals for the current scope, to re-hydrate cards after reload (finding #4). */
export async function fetchPendingProposals(estateId?: string): Promise<
  Array<{ proposalId: string; estateId: string; kind: string; diff: ProposalDiff; status: "pending" }>
> {
  const qs = estateId ? `?estateId=${encodeURIComponent(estateId)}` : "";
  const res = await botFetch(`/api/proposals${qs}`);
  // THROW on a bot error (finding #7) so pending Apply cards aren't silently
  // dropped from the tray while they sit pending in the bot's DB.
  if (!res.ok) throw new Error(`proposals ${res.status}`);
  return res.json().catch(() => []);
}

export async function dismissProposalRequest(proposalId: string): Promise<boolean> {
  try {
    const res = await botFetch(`/api/proposals/${proposalId}/dismiss`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: "{}",
    });
    // Only a confirmed 2xx is a real dismissal (ChatGPT #8): a 409 (already
    // applying/applied) or a network failure must NOT show "Rejected".
    return res.ok;
  } catch {
    return false;
  }
}

// ── NDJSON chat stream ───────────────────────────────────────────────────────

/** Delete ALL conversations for the current user ("Clear History"). */
export async function clearAllConversations(): Promise<boolean> {
  const res = await botFetch("/api/conversations", { method: "DELETE" }).catch(() => null);
  return !!res && res.ok;
}

/** Download the current conversation as a Markdown file. */
export async function exportConversation(id: string): Promise<void> {
  const res = await botFetch(`/api/conversations/${encodeURIComponent(id)}/export`);
  if (!res.ok) throw new Error(`export ${res.status}`);
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `chat-export-${id.slice(0, 8)}.md`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  // Firefox can cancel the download if the object URL is revoked in the same
  // task as click(). Release it after the browser has accepted the download.
  window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
}

export async function streamChat(
  body: {
    conversationId?: string;
    requestId?: string;
    content: string;
    context: PageContextPayload;
    attachments: OutgoingAttachment[];
  },
  onEvent: (event: BotStreamEvent) => void,
  signal: AbortSignal,
): Promise<void> {
  const res = await botFetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal,
  });
  adoptRotation(res.headers.get("X-Rotated-Session"));

  if (res.status === 401) {
    onEvent({ type: "error", message: "Your session has expired — please sign in again." });
    return;
  }
  if (res.status === 413) {
    const err = await res.json().catch(() => ({}));
    onEvent({ type: "error", message: err.message || "Files too large." });
    return;
  }
  if (!res.ok || !res.body) {
    const retryAfterSeconds = Number(res.headers.get("retry-after"));
    const retryAfterMs = Number.isFinite(retryAfterSeconds)
      ? Math.min(15_000, Math.max(500, retryAfterSeconds * 1_000))
      : 750;
    if (res.status === 403) {
      onEvent({ type: "error", message: "Assistant access needs to be enabled in your account settings." });
    } else if (res.status === 429) {
      onEvent({ type: "error", message: "The assistant is busy with another request. It will retry once.", retryable: true, retryAfterMs });
    } else if (res.status === 503 || res.status === 504) {
      onEvent({ type: "error", message: "The assistant service is reconnecting. It will retry once.", retryable: true, retryAfterMs });
    } else {
      onEvent({ type: "error", message: "The assistant could not start this request. Please retry.", retryable: res.status >= 500, retryAfterMs });
    }
    return;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  const emitLine = (raw: string) => {
    const line = raw.trim();
    if (!line) return;
    try {
      const event = JSON.parse(line) as BotStreamEvent;
      if (event.type === "session_rotated") adoptRotation(event.value);
      else onEvent(event);
    } catch {
      // A malformed terminal line cannot safely be interpreted as a completed
      // turn. The hook detects the missing `done` event and offers retry.
    }
  };
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let newline = buffer.indexOf("\n");
    while (newline >= 0) {
      const line = buffer.slice(0, newline).trim();
      buffer = buffer.slice(newline + 1);
      newline = buffer.indexOf("\n");
      emitLine(line);
    }
  }
  // A proxy may close a valid NDJSON stream without the optional final newline.
  // Process that last event so a persisted `done` cannot be mistaken for an
  // incomplete response solely because of transport framing.
  buffer += decoder.decode();
  emitLine(buffer);
}

// ── Feedback ─────────────────────────────────────────────────────────────────
export async function submitFeedback(
  messageId: string,
  conversationId: string,
  rating: "up" | "down",
  comment = "",
): Promise<boolean> {
  const res = await botFetch("/api/feedback", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messageId, conversationId, rating, comment }),
  }).catch(() => null);
  return !!res && res.ok;
}

export async function removeFeedbackRequest(messageId: string): Promise<boolean> {
  const res = await botFetch(`/api/feedback/${encodeURIComponent(messageId)}`, {
    method: "DELETE",
  }).catch(() => null);
  return !!res && res.ok;
}

export async function fetchFeedback(
  conversationId: string,
): Promise<Array<{ messageId: string; rating: "up" | "down"; comment: string }>> {
  const res = await botFetch(`/api/feedback/${encodeURIComponent(conversationId)}`).catch(
    () => null,
  );
  if (!res || !res.ok) return [];
  const data = await res.json();
  return data.feedback ?? [];
}
