import { act, fireEvent, render, screen, waitFor } from "@testing-library/react";
import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ChatPanel } from "./ChatPanel";

const mocks = vi.hoisted(() => ({
  exportConversation: vi.fn(),
  clearAllConversations: vi.fn(),
  listConversations: vi.fn(),
  deleteConversationRequest: vi.fn(),
  fetchFeedback: vi.fn(),
  submitFeedback: vi.fn(),
  removeFeedbackRequest: vi.fn(),
  send: vi.fn(),
  stop: vi.fn(),
  resume: vi.fn(),
  newChat: vi.fn(),
  hydratePendingProposals: vi.fn(),
  streamdownProps: vi.fn(),
  isLoading: false,
  isRetrying: false,
  toolStatus: null as { name: string; label: string; running: boolean } | null,
  messages: [] as Array<{ role: string; content: string; id?: string }>,
  estateId: null as string | null,
  completionCueEnabled: false,
  lastRequestOutcome: null as { kind: "completed" | "stopped"; id: number } | null,
  processingTrail: [] as Array<{ id: number; kind: "request" | "tool" | "tool_complete" | "completed" | "stopped"; label: string; detail: string }>,
  profileCompletion: null as null | { profile: { lawyerName: string; firmName: string; firmAddress: string; firmPhone: string; firmEmail: string }; missingFields: Array<"lawyerName" | "firmName" | "firmEmail"> },
  dismissProfileCompletion: vi.fn(),
  completeProfileCompletion: vi.fn(),
  saveProfile: vi.fn(),
  invalidateSettings: vi.fn(),
  profileSaving: false,
  mobile: false,
}));
const elementScrollToDescriptor = Object.getOwnPropertyDescriptor(HTMLElement.prototype, "scrollTo");
const visualViewportDescriptor = Object.getOwnPropertyDescriptor(window, "visualViewport");

vi.mock("streamdown", () => ({
  Streamdown: (props: {
    children: React.ReactNode;
    components?: { img?: (imageProps: Record<string, unknown>) => React.ReactNode };
    rehypePlugins?: unknown[];
  }) => {
    mocks.streamdownProps(props);
    return <>{props.children}{props.components?.img?.({ src: "https://attacker.invalid/tracker" })}</>;
  },
  defaultRehypePlugins: { harden: "harden", sanitize: "sanitize" },
}));
vi.mock("wouter", () => ({ useLocation: () => ["/", vi.fn()] }));
vi.mock("@/hooks/useMobile", () => ({ useIsMobile: () => mocks.mobile }));
vi.mock("./usePageContext", () => ({ usePageContext: () => ({ path: "/", estateId: mocks.estateId, tab: null }) }));
vi.mock("./useCopyCodeBlocks", () => ({ useCopyCodeBlocks: vi.fn() }));
vi.mock("./useFileDrop", () => ({
  useFileDrop: () => ({
    staged: [],
    dropError: "",
    dragActive: false,
    hasSizeError: false,
    dropHandlers: {},
    clearStaged: vi.fn(),
    removeStaged: vi.fn(),
    addFiles: vi.fn(),
  }),
}));
vi.mock("./useChat", () => ({
  useChat: () => ({
    messages: mocks.messages,
    proposals: [],
    profileCompletion: mocks.profileCompletion,
    navChips: [],
    toolStatus: mocks.toolStatus,
    isLoading: mocks.isLoading,
    isRetrying: mocks.isRetrying,
    lastRequestOutcome: mocks.lastRequestOutcome,
    processingTrail: mocks.processingTrail,
    loadError: false,
    lastError: null,
    send: mocks.send,
    stop: mocks.stop,
    retry: vi.fn(),
    resume: mocks.resume,
    newChat: mocks.newChat,
    loadConversation: vi.fn(),
    isCurrentConversation: () => false,
    getConversationId: () => "conversation-1234",
    updateProposal: vi.fn(),
    dismissProfileCompletion: mocks.dismissProfileCompletion,
    completeProfileCompletion: mocks.completeProfileCompletion,
    dismissNavChip: vi.fn(),
    hydratePendingProposals: mocks.hydratePendingProposals,
  }),
}));
vi.mock("@/lib/trpc", () => ({
  trpc: {
    settings: {
      get: { useQuery: () => ({ data: { assistantCompletionCue: mocks.completionCueEnabled } }) },
      update: {
        useMutation: (options: { onSuccess?: () => void; onError?: (error: Error) => void }) => ({
          isPending: mocks.profileSaving,
          mutate: (input: unknown) => mocks.saveProfile(input, options),
        }),
      },
    },
    useUtils: () => ({ settings: { get: { invalidate: mocks.invalidateSettings } } }),
  },
}));
vi.mock("./botClient", () => ({
  exportConversation: mocks.exportConversation,
  clearAllConversations: mocks.clearAllConversations,
  listConversations: mocks.listConversations,
  deleteConversationRequest: mocks.deleteConversationRequest,
  fetchFeedback: mocks.fetchFeedback,
  submitFeedback: mocks.submitFeedback,
  removeFeedbackRequest: mocks.removeFeedbackRequest,
}));

describe("ChatPanel conversation actions", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.exportConversation.mockResolvedValue(undefined);
    mocks.clearAllConversations.mockResolvedValue(true);
    mocks.listConversations.mockResolvedValue([]);
    mocks.fetchFeedback.mockResolvedValue([]);
    mocks.submitFeedback.mockResolvedValue(true);
    mocks.removeFeedbackRequest.mockResolvedValue(true);
    mocks.send.mockReset();
    mocks.resume.mockResolvedValue(undefined);
    mocks.isLoading = false;
    mocks.isRetrying = false;
    mocks.toolStatus = null;
    mocks.completionCueEnabled = false;
    mocks.lastRequestOutcome = null;
    mocks.processingTrail = [];
    mocks.messages = [{ role: "assistant", content: "A saved answer", id: "msg-1" }];
    mocks.profileCompletion = null;
    mocks.dismissProfileCompletion.mockReset();
    mocks.completeProfileCompletion.mockReset();
    mocks.saveProfile.mockReset();
    mocks.invalidateSettings.mockReset();
    mocks.profileSaving = false;
    mocks.estateId = null;
    mocks.mobile = false;
    vi.spyOn(window, "confirm").mockReturnValue(true);
  });

  afterEach(() => {
    vi.restoreAllMocks();
    if (elementScrollToDescriptor) Object.defineProperty(HTMLElement.prototype, "scrollTo", elementScrollToDescriptor);
    else delete (HTMLElement.prototype as HTMLElement & { scrollTo?: Element["scrollTo"] }).scrollTo;
    if (visualViewportDescriptor) Object.defineProperty(window, "visualViewport", visualViewportDescriptor);
    else delete (window as Window & { visualViewport?: VisualViewport }).visualViewport;
  });

  it("wires the current-conversation export into the visible header", async () => {
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: "Export current conversation" }));
    await waitFor(() => expect(mocks.exportConversation).toHaveBeenCalledWith("conversation-1234"));
  });

  it("renders an accessible profile-completion card with verified prefill and field-level firm-name validation", () => {
    mocks.profileCompletion = {
      profile: { lawyerName: "Test", firmName: "", firmAddress: "", firmPhone: "", firmEmail: "test@probate-pro.com" },
      missingFields: ["firmName"],
    };
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);

    expect(screen.getByRole("heading", { name: "Add your firm name to keep your documents accurate" })).toBeTruthy();
    expect((screen.getByLabelText("Your name") as HTMLInputElement).value).toBe("Test");
    expect((screen.getByLabelText("Firm email") as HTMLInputElement).value).toBe("test@probate-pro.com");
    expect(screen.getByLabelText("Firm name *").getAttribute("autocomplete")).toBe("organization");

    fireEvent.click(screen.getByRole("button", { name: "Save profile" }));
    expect(screen.getByRole("alert").textContent).toContain("Enter your firm name");
    expect(screen.getByLabelText("Firm name *").getAttribute("aria-invalid")).toBe("true");
    expect(mocks.saveProfile).not.toHaveBeenCalled();
  });

  it("saves the inline profile through the canonical mutation, invalidates settings, and preserves input on a recoverable error", async () => {
    mocks.profileCompletion = {
      profile: { lawyerName: "Test", firmName: "", firmAddress: "123 Main Street", firmPhone: "604-555-0100", firmEmail: "test@probate-pro.com" },
      missingFields: ["firmName"],
    };
    mocks.saveProfile.mockImplementation((_input, options) => options.onError?.(new Error("Connection interrupted")));
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);

    fireEvent.change(screen.getByLabelText("Firm name *"), { target: { value: "  Example Law LLP  " } });
    fireEvent.click(screen.getByRole("button", { name: "Save profile" }));
    await waitFor(() => expect(screen.getByRole("alert").textContent).toContain("Connection interrupted"));
    expect((screen.getByLabelText("Firm name *") as HTMLInputElement).value).toBe("  Example Law LLP  ");

    mocks.saveProfile.mockImplementation((_input, options) => options.onSuccess?.());
    fireEvent.click(screen.getByRole("button", { name: "Save profile" }));
    await waitFor(() => expect(mocks.saveProfile).toHaveBeenLastCalledWith({
      lawyerName: "Test",
      firmName: "Example Law LLP",
      firmAddress: "123 Main Street",
      firmPhone: "604-555-0100",
      firmEmail: "test@probate-pro.com",
    }, expect.any(Object)));
    await waitFor(() => expect(mocks.invalidateSettings).toHaveBeenCalledTimes(1));
    expect(screen.getByText("Professional profile saved.")).toBeTruthy();
  });

  it("disables the profile save action while the canonical mutation is in flight", () => {
    mocks.profileCompletion = {
      profile: { lawyerName: "Test", firmName: "Example Law LLP", firmAddress: "", firmPhone: "", firmEmail: "test@probate-pro.com" },
      missingFields: ["lawyerName", "firmEmail"],
    };
    mocks.profileSaving = true;
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);

    const saveButton = screen.getByRole("button", { name: "Saving profile" }) as HTMLButtonElement;
    expect(saveButton.disabled).toBe(true);
    fireEvent.click(saveButton);
    expect(mocks.saveProfile).not.toHaveBeenCalled();
  });

  it("confirms, clears every conversation, and reloads an actually-empty scope", async () => {
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: "Clear all conversation history" }));
    await waitFor(() => expect(mocks.clearAllConversations).toHaveBeenCalledTimes(1));
    expect(window.confirm).toHaveBeenCalled();
    await waitFor(() => expect(mocks.resume).toHaveBeenCalledTimes(1));
    expect(mocks.newChat).not.toHaveBeenCalled();
  });

  it("never resumes on mount or navigation — it only surfaces the estate's pending proposals", async () => {
    // THE reported bug: switching pages replaced the transcript with the new
    // scope's latest conversation. The panel must not call resume() outside the
    // explicit clear-all flow; an estate page instead hydrates pending cards.
    mocks.estateId = "e9";
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    await waitFor(() => expect(mocks.hydratePendingProposals).toHaveBeenCalledWith("e9"));
    expect(mocks.resume).not.toHaveBeenCalled();
  });

  it("does not clear history when the user rejects the confirmation", async () => {
    vi.mocked(window.confirm).mockReturnValue(false);
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: "Clear all conversation history" }));
    expect(mocks.clearAllConversations).not.toHaveBeenCalled();
  });

  it("opens the history panel and closes it from its own close button", async () => {
    // The close control shipped invisible in light theme (white-on-white reuse
    // of the header button class) — jsdom can't see paint, but this at least
    // locks the control's existence and its handler.
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: "Open conversation history" }));
    expect(screen.getByText("Conversation History")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Close conversation history" }));
    expect(screen.queryByText("Conversation History")).toBeNull();
  });

  it("keeps the composer and attachment control keyboard-labelled", () => {
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    expect(screen.getByRole("textbox", { name: "Message to ProbatePro Assistant" })).toBeTruthy();
    expect(screen.getByText("Attach files")).toBeTruthy();
    expect(screen.getByRole("button", { name: "Send message" })).toBeTruthy();
  });

  it("grows the mobile composer for a longer message, sends with Enter, and retains Shift+Enter for a new line", () => {
    mocks.mobile = true;
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    const composer = screen.getByRole("textbox", { name: "Message to ProbatePro Assistant" }) as HTMLTextAreaElement;
    expect(composer.tagName).toBe("TEXTAREA");
    Object.defineProperty(composer, "scrollHeight", { configurable: true, value: 96 });
    fireEvent.change(composer, { target: { value: "A longer message that wraps across multiple lines." } });
    expect(composer.style.height).toBe("96px");
    fireEvent.keyDown(composer, { key: "Enter", shiftKey: true });
    expect(mocks.send).not.toHaveBeenCalled();
    fireEvent.keyDown(composer, { key: "Enter" });
    expect(mocks.send).toHaveBeenCalledWith("A longer message that wraps across multiple lines.", []);
  });

  it("keeps the mobile dialog bound to the visual viewport when the composer receives focus", () => {
    mocks.mobile = true;
    const listeners = new Map<string, EventListener>();
    const viewport = {
      height: 488,
      offsetTop: 18,
      addEventListener: (name: string, listener: EventListener) => listeners.set(name, listener),
      removeEventListener: (name: string) => listeners.delete(name),
    } as unknown as VisualViewport;
    Object.defineProperty(window, "visualViewport", { configurable: true, value: viewport });

    const { container } = render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    const panel = container.querySelector(".kairo-window-mobile") as HTMLDivElement;
    const composer = screen.getByRole("textbox", { name: "Message to ProbatePro Assistant" });
    expect(panel.style.getPropertyValue("--kairo-mobile-visible-height")).toBe("488px");
    expect(panel.style.getPropertyValue("--kairo-mobile-viewport-top")).toBe("18px");

    (viewport as { height: number; offsetTop: number }).height = 422;
    (viewport as { height: number; offsetTop: number }).offsetTop = 0;
    fireEvent.focus(composer);
    expect(panel.style.getPropertyValue("--kairo-mobile-visible-height")).toBe("422px");
    expect(panel.style.getPropertyValue("--kairo-mobile-viewport-top")).toBe("0px");
    expect(document.querySelector(".kairo-mobile-backdrop")).toBeTruthy();
  });

  it("smoothly follows newly received messages when reading the latest content", () => {
    const scrollTo = vi.fn();
    Object.defineProperty(HTMLElement.prototype, "scrollTo", { configurable: true, value: scrollTo });
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    expect(scrollTo).toHaveBeenCalledWith(expect.objectContaining({ behavior: "smooth" }));
  });

  it("does not pull a reader back down after they scroll away from the latest message", () => {
    const scrollTo = vi.fn();
    Object.defineProperty(HTMLElement.prototype, "scrollTo", { configurable: true, value: scrollTo });
    const { rerender } = render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    const body = document.querySelector(".kairo-body") as HTMLDivElement;
    Object.defineProperties(body, {
      scrollHeight: { configurable: true, value: 800 },
      clientHeight: { configurable: true, value: 200 },
      scrollTop: { configurable: true, value: 0, writable: true },
    });
    fireEvent.scroll(body);
    scrollTo.mockClear();
    mocks.messages = [...mocks.messages, { role: "assistant", content: "A newer answer", id: "msg-2" }];
    rerender(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    expect(scrollTo).not.toHaveBeenCalled();
  });

  it("shows a compact return-to-latest control after scrolling up and smoothly returns to the newest message", () => {
    const scrollTo = vi.fn();
    Object.defineProperty(HTMLElement.prototype, "scrollTo", { configurable: true, value: scrollTo });
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    const body = document.querySelector(".kairo-body") as HTMLDivElement;
    Object.defineProperties(body, {
      scrollHeight: { configurable: true, value: 800 },
      clientHeight: { configurable: true, value: 200 },
      scrollTop: { configurable: true, value: 0, writable: true },
    });
    fireEvent.scroll(body);
    const control = screen.getByRole("button", { name: "Return to latest message" });
    expect(control.className).toContain("kairo-return-latest");
    scrollTo.mockClear();
    fireEvent.click(control);
    expect(scrollTo).toHaveBeenCalledWith({ top: 800, behavior: "smooth" });
    expect(screen.queryByRole("button", { name: "Return to latest message" })).toBeNull();
  });

  it("uses a modal mobile viewport shell and restores the page scroll state when closed", () => {
    mocks.mobile = true;
    const requestFrame = vi.spyOn(window, "requestAnimationFrame").mockImplementation((callback) => {
      callback(0);
      return 1;
    });
    const { unmount } = render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    const dialog = screen.getByRole("dialog", { name: "ProbatePro Assistant" });
    expect(dialog.getAttribute("aria-modal")).toBe("true");
    expect(dialog.className).toContain("kairo-window-mobile");
    expect(dialog.style.getPropertyValue("--kairo-mobile-visible-height")).toBeTruthy();
    expect(document.body.style.position).toBe("fixed");
    expect(document.documentElement.style.overflow).toBe("hidden");
    expect(document.querySelector(".kairo-mobile-backdrop")).toBeTruthy();
    unmount();
    expect(document.body.style.position).toBe("");
    expect(document.documentElement.style.overflow).toBe("");
    requestFrame.mockRestore();
  });

  it("sizes the mobile panel to the visible viewport above the keyboard", () => {
    mocks.mobile = true;
    const visualViewportDescriptor = Object.getOwnPropertyDescriptor(window, "visualViewport");
    const innerHeightDescriptor = Object.getOwnPropertyDescriptor(window, "innerHeight");
    Object.defineProperty(window, "innerHeight", { configurable: true, value: 812 });
    Object.defineProperty(window, "visualViewport", {
      configurable: true,
      value: { height: 420, offsetTop: 0, addEventListener: vi.fn(), removeEventListener: vi.fn() },
    });
    const requestFrame = vi.spyOn(window, "requestAnimationFrame").mockImplementation((callback) => {
      callback(0);
      return 1;
    });

    const { unmount } = render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    const dialog = screen.getByRole("dialog", { name: "ProbatePro Assistant" });
    expect(dialog.style.getPropertyValue("--kairo-mobile-visible-height")).toBe("420px");
    expect(dialog.style.getPropertyValue("--kairo-mobile-viewport-top")).toBe("0px");
    unmount();
    requestFrame.mockRestore();
    if (innerHeightDescriptor) Object.defineProperty(window, "innerHeight", innerHeightDescriptor);
    if (visualViewportDescriptor) Object.defineProperty(window, "visualViewport", visualViewportDescriptor);
    else delete (window as Window & { visualViewport?: VisualViewport }).visualViewport;
  });

  it("uses only the hardened renderer plugins and suppresses model-controlled images", () => {
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    const props = mocks.streamdownProps.mock.calls[0]?.[0];
    expect(props?.rehypePlugins).toEqual(["sanitize", "harden"]);
    expect(props?.components?.img?.({ src: "https://attacker.invalid/tracker" })).toBeNull();
    expect(screen.queryByRole("img")).toBeNull();
  });

  it("announces the branded request-presence state to assistive technology", () => {
    mocks.isLoading = true;
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    expect(screen.getByRole("status", { name: "Assistant is preparing a grounded response" })).toBeTruthy();
    expect(screen.getByTestId("assistant-request-presence")).toBeTruthy();
    expect(screen.getByText("Reading your request")).toBeTruthy();
    expect(screen.queryByText("Assistant is typing")).toBeNull();
  });

  it("keeps the grounded request presence while showing the active tool label", () => {
    mocks.isLoading = true;
    mocks.toolStatus = { name: "compute_distribution", label: "Checking recorded distribution", running: true };
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    expect(screen.getByRole("status", { name: "Checking recorded distribution. Assistant is working." })).toBeTruthy();
    expect(screen.getByTestId("assistant-tool-presence")).toBeTruthy();
    expect(screen.getByText("Reconciling recorded distribution")).toBeTruthy();
  });

  it("visibly announces the automatic reconnecting state without suggesting a duplicate message", () => {
    mocks.isLoading = true;
    mocks.isRetrying = true;
    mocks.processingTrail = [{ id: 41, kind: "request", label: "Reconnecting assistant", detail: "Retrying this request once without duplicating your conversation." }];
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    expect(screen.getByRole("status", { name: "Assistant is reconnecting your request. Your message will not be sent twice." })).toBeTruthy();
    expect(screen.getByTestId("assistant-retry-presence")).toBeTruthy();
    expect(screen.getByText("Reconnecting your request")).toBeTruthy();
    expect(screen.getByText("Trying once more — your message will not be sent twice.")).toBeTruthy();
    const retryStep = screen.getByTestId("assistant-retry-step");
    expect(retryStep.textContent).toContain("Current step");
    expect(retryStep.textContent).toContain("Retrying this request once without duplicating your conversation.");
  });

  it("fades the live retry step before replacing it with the next processing stage", () => {
    vi.useFakeTimers();
    mocks.isLoading = true;
    mocks.isRetrying = true;
    mocks.processingTrail = [{ id: 51, kind: "request", label: "Reconnecting assistant", detail: "Preparing the saved request for reconnection." }];

    try {
      const { rerender } = render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
      expect(screen.getByTestId("assistant-retry-step").textContent).toContain("Preparing the saved request for reconnection.");

      mocks.processingTrail = [{ id: 52, kind: "request", label: "Reconnecting assistant", detail: "Retrying this request once without duplicating your conversation." }];
      rerender(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);

      const transitioningMessage = screen.getByTestId("assistant-retry-step").lastElementChild;
      expect(transitioningMessage?.className).toContain("kairo-presence-step-message--leaving");
      expect(transitioningMessage?.textContent).toContain("Preparing the saved request for reconnection.");

      act(() => vi.advanceTimersByTime(130));

      const settledMessage = screen.getByTestId("assistant-retry-step").lastElementChild;
      expect(settledMessage?.className).not.toContain("kairo-presence-step-message--leaving");
      expect(settledMessage?.textContent).toContain("Retrying this request once without duplicating your conversation.");
    } finally {
      vi.useRealTimers();
    }
  });

  it("titles the header with a single-line subtitle and no liveness badge", () => {
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    expect(screen.getByText("Estate Assistant")).toBeTruthy();
    expect(screen.queryByText("Online")).toBeNull();
  });

  it("shows the AI-processor notice in the empty state and a compact Kairo footer", () => {
    // Launch-blocker disclosure (chatbot/README.md residual #2): the widget
    // must tell the user their content goes to a third-party AI provider.
    mocks.messages = [];
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    expect(screen.getByText(/sends your messages, dropped files, and relevant estate\s*data to a third-party AI provider/)).toBeTruthy();
    expect(screen.getByRole("link", { name: "Privacy Policy" })).toBeTruthy();
    expect(screen.getByRole("link", { name: "Powered by Kairo" }).getAttribute("href")).toBe("https://kairo.chat");
    expect(screen.getByRole("link", { name: "Privacy" }).getAttribute("href")).toBe("/privacy");
  });

  it("keeps the processor disclosure visible after a conversation starts", () => {
    mocks.messages = [{ id: "m1", role: "user", content: "Hello" }];
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    expect(screen.queryByText(/sends your messages, dropped files/)).toBeNull();
    expect(screen.getByRole("link", { name: "Powered by Kairo" }).getAttribute("href")).toBe("https://kairo.chat");
    expect(screen.getByRole("link", { name: "Privacy" }).getAttribute("href")).toBe("/privacy");
  });

  it("suggests only globally-answerable openers when no estate is open", () => {
    // The dashboard case. Every estate-scoped prompt needs an estateId, so
    // offering one here guarantees the assistant answers that it cannot do the
    // thing it just offered.
    mocks.messages = [];
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    expect(screen.getByRole("button", { name: "What deadlines are coming up?" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "Show me my estate files" })).toBeTruthy();
    expect(screen.queryByRole("button", { name: "Summarize this estate file" })).toBeNull();
    expect(screen.queryByRole("button", { name: "Who inherits, and what share?" })).toBeNull();
  });

  it("suggests estate openers that a read-only tool answers in one turn", () => {
    // Every chip here must resolve to get_estate_snapshot / get_readiness /
    // compute_distribution. Nothing that needs the user to supply something
    // first — a propose_* tool requires per-field source provenance, so as an
    // opener it can only reply by asking which fields and from where.
    mocks.messages = [];
    mocks.estateId = "estate-1";
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    expect(screen.getByRole("button", { name: "Summarize this estate file" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "What's still missing before filing?" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "Who inherits, and what share?" })).toBeTruthy();
    expect(screen.queryByRole("button", { name: /intake/i })).toBeNull();
    expect(screen.queryByRole("button", { name: "Show me my estate files" })).toBeNull();
  });

  it("shows the tool-specific filing-trace state when a tool is running", () => {
    mocks.isLoading = true;
    mocks.toolStatus = { name: "compute_distribution", label: "Computing distribution", running: true };
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    expect(screen.getByRole("status", { name: "Computing distribution. Assistant is working." })).toBeTruthy();
    expect(screen.getByTestId("assistant-tool-presence")).toBeTruthy();
    expect(screen.getByText("Reconciling recorded distribution")).toBeTruthy();
  });

  it("shows the grounded request-presence state when loading without a tool status", () => {
    mocks.isLoading = true;
    mocks.toolStatus = null;
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    expect(screen.getByRole("status", { name: "Assistant is preparing a grounded response" })).toBeTruthy();
    expect(screen.getByTestId("assistant-request-presence")).toBeTruthy();
    expect(screen.queryByText(/Computing/)).toBeNull();
  });

  it("turns the composer send button into a square cancel action while a tool is running", () => {
    mocks.isLoading = true;
    mocks.toolStatus = { name: "get_readiness", label: "Checking readiness", running: true };
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    const cancelButton = screen.getByRole("button", { name: "Cancel request" });
    expect(cancelButton.className).toContain("kairo-sb--cancel");
    expect(cancelButton.querySelector("svg")).toBeTruthy();
    expect(screen.queryByRole("button", { name: "Stop assistant response" })).toBeNull();
    fireEvent.click(cancelButton);
    expect(mocks.stop).toHaveBeenCalledTimes(1);
  });

  it("renders a cancellation system entry in the visible chat history", () => {
    mocks.messages = [{ role: "system", content: "Request cancelled" }];
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    expect(screen.getByRole("status", { name: "Request cancelled" })).toBeTruthy();
  });

  it("briefly acknowledges a completed or stopped request without presenting an error", async () => {
    mocks.lastRequestOutcome = { kind: "completed", id: 101 };
    const { rerender } = render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    await waitFor(() => expect(screen.getByText("Reply ready")).toBeTruthy());

    mocks.lastRequestOutcome = { kind: "stopped", id: 102 };
    rerender(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    await waitFor(() => expect(screen.getByText("Request stopped")).toBeTruthy());
  });

  it("keeps actual request steps in a collapsible filing trace", () => {
    mocks.processingTrail = [
      { id: 1, kind: "request", label: "Request received", detail: "Preparing the grounded response context." },
      { id: 2, kind: "tool", label: "Checking readiness", detail: "Running an authorized Assistant step." },
      { id: 3, kind: "completed", label: "Reply recorded", detail: "The Assistant reply is ready in this conversation." },
    ];
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    expect(screen.getByText("Filing trace")).toBeTruthy();
    expect(screen.queryByRole("list", { name: "Assistant processing steps" })).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: /filing trace/i }));
    expect(screen.getByRole("list", { name: "Assistant processing steps" })).toBeTruthy();
    expect(screen.getByText("Checking readiness")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: /filing trace/i }));
    expect(screen.queryByRole("list", { name: "Assistant processing steps" })).toBeNull();
  });

  // UI-005: the thumbs are optimistic — a failed request must revert the thumb
  // and say so inline, never leave a lit thumb for feedback that was not saved.
  it("reverts the thumb and shows an inline error when feedback fails to save", async () => {
    mocks.submitFeedback.mockResolvedValue(false);
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: "Thumbs up" }));
    await waitFor(() => expect(screen.getByText(/Couldn't save your feedback/)).toBeTruthy());
    expect(screen.getByRole("button", { name: "Thumbs up" }).className).not.toContain("kairo-fb-active");
  });

  it("restores a recorded rating when removing it fails", async () => {
    mocks.fetchFeedback.mockResolvedValue([{ messageId: "msg-1", rating: "up", comment: "" }]);
    mocks.removeFeedbackRequest.mockResolvedValue(false);
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    const thumbsUp = () => screen.getByRole("button", { name: "Thumbs up" });
    await waitFor(() => expect(thumbsUp().className).toContain("kairo-fb-active"));
    fireEvent.click(thumbsUp()); // toggle off — the DELETE fails
    await waitFor(() => expect(screen.getByText(/Couldn't save your feedback/)).toBeTruthy());
    expect(thumbsUp().className).toContain("kairo-fb-active"); // still recorded
  });

  it("keeps the comment box (and the typed comment) open when the comment fails to record", async () => {
    mocks.submitFeedback
      .mockResolvedValueOnce(true) // the thumbs-down rating itself records
      .mockResolvedValueOnce(false); // the follow-up comment does not
    render(<ChatPanel open probe={{ status: "ok", name: "Test" }} onClose={vi.fn()} onAssistantDone={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: "Thumbs down" }));
    const input = await waitFor(() => screen.getByPlaceholderText("What went wrong?"));
    fireEvent.change(input, { target: { value: "wrong estate" } });
    fireEvent.click(screen.getByRole("button", { name: "Submit feedback" }));
    await waitFor(() => expect(screen.getByText(/Couldn't save your feedback/)).toBeTruthy());
    // Closing the box would read as "recorded" — it must stay open with the text.
    expect((screen.getByPlaceholderText("What went wrong?") as HTMLInputElement).value).toBe("wrong estate");
  });
});
