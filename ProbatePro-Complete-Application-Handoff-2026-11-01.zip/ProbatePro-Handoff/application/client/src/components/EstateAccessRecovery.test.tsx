import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { EstateAccessRecovery } from "./EstateAccessRecovery";

describe("EstateAccessRecovery", () => {
  it("explains unavailable estate access and returns the user to Estate Files", () => {
    const onBack = vi.fn();
    render(<EstateAccessRecovery onBack={onBack} />);

    expect(screen.getByText("Estate workspace unavailable")).toBeTruthy();
    fireEvent.click(screen.getByTestId("estate-access-recovery-back"));
    expect(onBack).toHaveBeenCalledTimes(1);
  });
});
