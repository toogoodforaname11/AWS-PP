import { getLoginUrlAsync, showLoginStartError } from "@/const";
import { clearFallbackSession } from "@/lib/fallbackSession";
import { trpc } from "@/lib/trpc";
import { TRPCClientError } from "@trpc/client";
import { useCallback, useEffect, useMemo, useRef } from "react";

type UseAuthOptions = {
  redirectOnUnauthenticated?: boolean;
  returnPath?: string;
};

export function useAuth(options?: UseAuthOptions) {
  const { redirectOnUnauthenticated = false, returnPath = "/" } =
    options ?? {};
  const utils = trpc.useUtils();
  const redirectingRef = useRef(false);

  const meQuery = trpc.auth.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      utils.auth.me.setData(undefined, null);
    },
  });

  const logout = useCallback(async () => {
    try {
      await logoutMutation.mutateAsync();
    } catch (error: unknown) {
      if (
        error instanceof TRPCClientError &&
        error.data?.code === "UNAUTHORIZED"
      ) {
        // Already logged out — proceed with cleanup
      } else {
        // Network or server error — still clear client state and redirect.
        // The server cookie may or may not have been cleared, but clearing
        // client-side tokens and forcing a full reload is the safest recovery:
        // if the cookie persists, the user will land back on the dashboard
        // (still logged in) which is acceptable — they can retry.
        console.error("[Logout] Server error, forcing client cleanup:", error);
      }
    }
    // Clear all client-side auth state before reload; an in-flight download sees the session end.
    clearFallbackSession();
    try {
      localStorage.removeItem("manus-runtime-user-info");
    } catch {}
    // Hard reload to ensure clean state — avoids race conditions where
    // the browser hasn't processed the Set-Cookie deletion yet and a
    // refetch would re-authenticate with the stale cookie.
    window.location.href = "/";
  }, [logoutMutation]);

  const state = useMemo(() => {
    localStorage.setItem(
      "manus-runtime-user-info",
      JSON.stringify(meQuery.data)
    );
    return {
      user: meQuery.data ?? null,
      loading: meQuery.isLoading || logoutMutation.isPending,
      error: meQuery.error ?? logoutMutation.error ?? null,
      isAuthenticated: Boolean(meQuery.data),
    };
  }, [
    meQuery.data,
    meQuery.error,
    meQuery.isLoading,
    logoutMutation.error,
    logoutMutation.isPending,
  ]);

  useEffect(() => {
    if (!redirectOnUnauthenticated) return;
    if (meQuery.isLoading || logoutMutation.isPending) return;
    if (state.user) return;
    if (typeof window === "undefined") return;
    if (redirectingRef.current) return;

    // H-1 Fix: Use async login URL to ensure CSRF nonce cookie is set
    redirectingRef.current = true;
    getLoginUrlAsync(returnPath).then((url) => {
      window.location.href = url;
    }).catch((error) => {
      // Do not strand an unauthenticated user in an in-progress redirect state.
      // The retry remains CSRF-protected because it always requests fresh state.
      console.error("[Auth] Automatic login start failed:", error);
      redirectingRef.current = false;
      showLoginStartError(returnPath);
    });
  }, [
    redirectOnUnauthenticated,
    returnPath,
    logoutMutation.isPending,
    meQuery.isLoading,
    state.user,
  ]);

  return {
    ...state,
    refresh: () => meQuery.refetch(),
    logout,
  };
}
