import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import HowItWorks, { guideScrollBehavior, scrollToGuideSection } from "./HowItWorks";

describe("HowItWorks", () => {
  it("keeps the authenticated product guide out of search results", () => {
    render(<HowItWorks />);

    expect(document.title).toBe("How It Works | ProbatePro");
    expect(document.head.querySelector('meta[name="robots"]')?.getAttribute("content")).toBe("noindex, nofollow");
    expect(document.head.querySelector('link[rel="canonical"]')?.getAttribute("href")).toBe("https://probate-pro.com/how-it-works");
  });

  it("explains the client approval boundary, Assistant consent, Executor Portal, Settings, forms, and FAQ content", () => {
    render(<HowItWorks />);

    expect(screen.getByRole("heading", { name: "How ProbatePro works" })).toBeTruthy();
    expect(screen.getByText(/lawyer reviews each submitted fact/i)).toBeTruthy();
    expect(screen.getByText(/Assistant is optional, consent-gated/i)).toBeTruthy();
    expect(screen.getByRole("button", { name: "What does the Assistant do?" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "Where do I manage Executor Portal access?" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "How do Executor Portal search and status filters work?" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "What can I configure in Settings?" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "How are court forms chosen and generated?" })).toBeTruthy();
    expect(screen.getByRole("navigation", { name: "Guide sections" }).querySelector('a[href="#assistant"]')).toBeTruthy();
    expect(document.getElementById("workflow")).toBeTruthy();
    expect(document.getElementById("assistant")).toBeTruthy();
    expect(document.getElementById("forms")).toBeTruthy();
    expect(document.getElementById("documents")).toBeTruthy();
    expect(document.getElementById("faq")).toBeTruthy();
  });

  it("uses instant scroll when reduced motion is preferred", () => {
    expect(guideScrollBehavior(false)).toBe("smooth");
    expect(guideScrollBehavior(true)).toBe("auto");
  });

  it("opens and closes FAQ answers with the dedicated motion-safe content hook", () => {
    render(<HowItWorks />);
    const question = screen.getByRole("button", { name: "What can I configure in Settings?" });
    fireEvent.click(question);
    expect(question.getAttribute("aria-expanded")).toBe("true");
    expect(document.querySelector("[data-state='open'] .faq-accordion-content")).toBeTruthy();
    fireEvent.click(question);
    expect(question.getAttribute("aria-expanded")).toBe("false");
  });

  it("smoothly scrolls to an anchored guide section and transfers focus", () => {
    const target = document.createElement("section");
    const scrollIntoView = vi.fn();
    target.id = "anchor-test";
    Object.assign(target, { scrollIntoView });
    target.tabIndex = -1;
    document.body.appendChild(target);

    scrollToGuideSection("anchor-test");

    expect(scrollIntoView).toHaveBeenCalledWith({ behavior: "smooth", block: "start" });
    expect(document.activeElement).toBe(target);
    target.remove();
  });

  it("adds a history entry and scrolls when a user selects an in-page destination", () => {
    render(<HowItWorks />);
    const target = document.getElementById("assistant")!;
    const scrollIntoView = vi.fn();
    const pushState = vi.spyOn(window.history, "pushState");
    Object.assign(target, { scrollIntoView });

    fireEvent.click(screen.getByRole("link", { name: "Assistant" }));

    expect(pushState).toHaveBeenCalledWith(null, "", "#assistant");
    expect(scrollIntoView).toHaveBeenCalledWith({ behavior: "smooth", block: "start" });
    expect(document.activeElement).toBe(target);
    pushState.mockRestore();
  });
});
