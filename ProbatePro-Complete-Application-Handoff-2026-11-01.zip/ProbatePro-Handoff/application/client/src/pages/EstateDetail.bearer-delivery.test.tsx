/**
 * Task 9: generated-document deliveries for a cookie-blocked session that holds the supported
 * Preview Bearer fallback (sessionStorage "manus-cookie" = "app_session_id=<token>").
 *
 * Every caller must send ONE same-origin fetch carrying Authorization (never a header-less native
 * form), keep the native urlencoded envelope (the preview keeps its JSON one), hand a validated
 * attachment to the browser, and show its existing success toast only after that handoff. A refusal
 * shows only its sentence; the recovery buttons are explicit, fresh activations. Fictional data only.
 */
import React from "react";
import JSZip from "jszip";
import { fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { browserResponse } from "@/lib/browserResponse.testkit";

vi.setConfig({ testTimeout: 45000 });
(globalThis as any).React = React;
vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn(), loading: vi.fn(), dismiss: vi.fn() }) }));
import { toast } from "sonner";

const TOKEN = "fictional.bearer.task9-caller";
const DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;

const state = vi.hoisted(() => ({
  estate: {} as any,
  contacts: [] as any[],
  documents: [] as any[],
  generateCalls: [] as any[],
  bulkCalls: [] as Array<{ key: string; input: any }>,
  generateResponse: {} as any,
}));

vi.mock("@/lib/trpc", () => {
  const BULK: Record<string, string> = {
    "document.generateAllLetters": "letters",
    "document.generatePackage": "package",
    "document.generateAllP8": "p8_all",
  };
  const queryData = (key: string): any => {
    if (key === "contact.list") return state.contacts;
    if (key === "document.list") return state.documents;
    if (key === "document.preview") return { sections: [] };
    if (key === "settings.get") return { lawyerName: "Firm Lawyer", firmCity: "Victoria" };
    return ["document.versions", "document.retainedFiles", "document.getLetterRecipients", "citation.list", "delivery.list", "delivery.getRecipients"].includes(key) ? [] : undefined;
  };
  const mutation = (key: string, options?: any) => {
    const mutateAsync = async (input: any) => {
      try {
        let result: any = { revision: 2 };
        if (key === "document.generate") {
          state.generateCalls.push(input);
          result = state.generateResponse;
        }
        if (BULK[key]) {
          state.bulkCalls.push({ key, input });
          const fields: Record<string, string> = { type: BULK[key], estateId: input.estateId };
          if (input.signatoryType) fields.signatoryType = input.signatoryType;
          if (input.signatureDate) fields.signatureDate = input.signatureDate;
          result = { delivery: { method: "POST", action: "/api/download/export", fields }, count: 2 };
        }
        // Match TanStack: onSuccess is awaited; a throw there rejects mutateAsync and runs onError.
        await options?.onSuccess?.(result, input, undefined);
        return result;
      } catch (error) {
        await options?.onError?.(error, input, undefined);
        throw error;
      }
    };
    return { mutateAsync, mutate: (input: any) => { void mutateAsync(input).catch(() => undefined); }, isPending: false };
  };
  const utils = (path: string[]): any => new Proxy({}, {
    get(_target, property: string): any {
      if (["invalidate", "cancel", "setData"].includes(property)) return () => undefined;
      if (property === "getData") return () => state.estate;
      if (property === "fetch") return async (input: any) => {
        const key = path.join(".");
        if (key === "estate.get") return state.estate;
        // A clean preflight: these tests are about delivery, not the gap engine.
        if (key === "document.preflight") return { formCode: input.formCode, ok: true, gaps: [] };
        if (key === "document.preflightMany") return (input.formCodes as string[]).map((formCode) => ({ formCode, ok: true, gaps: [] }));
        return [];
      };
      return utils([...path, property]);
    },
  });
  const node = (path: string[]): any => new Proxy({}, {
    get(_target, property: string): any {
      if (property === "useQuery") return () => ({ data: queryData(path.join(".")), isLoading: false, error: null });
      if (property === "useMutation") return (options: any) => mutation(path.join("."), options);
      if (property === "useUtils") return () => utils([]);
      return node([...path, property]);
    },
  });
  return { trpc: node([]) };
});

const jordan = {
  id: "jordan", name: "Jordan Ellis Calder-Quay", role: "applicant,executor", executorStatus: "applying",
  executorRank: "primary", applicantKind: "individual", occupation: "Teacher", relationship: "child",
  residentialAddress: "10 Main Street, Victoria, BC", residenceStreet: "10 Main Street",
  residenceCity: "Victoria", residenceProvince: "BC", residenceCountry: "Canada",
};
const avery = { ...jordan, id: "avery", name: "Avery Calder-Quay", executorRank: "alternate", occupation: "Engineer" };
const riley = { ...jordan, id: "riley", name: "Riley Calder-Quay", executorRank: "alternate", occupation: "Nurse" };
const beneficiary = { id: "bene-1", name: "Sam Beneficiary", role: "beneficiary", relationship: "child", address: "1 Fictional Way, Victoria, BC" };
const p8Delivery = {
  method: "POST",
  action: "/api/download/form",
  fields: { estateId: "estate-19", formCode: "P8", documentId: "doc_p8_1", signatoryType: "lawyer", signatureDate: "2026-09-06", deponentId: "avery", selectedContactId: "avery" },
};

let docxBytes: Uint8Array;
let zipBytes: Uint8Array;
const fetchSpy = vi.fn<(input: RequestInfo | URL, init?: RequestInit) => Promise<Response>>();
const nativeSubmits: string[] = [];
const anchorClicks: Array<{ href: string; download: string }> = [];
const blobs: Blob[] = [];

function attachment(bytes: Uint8Array, type: string, filename: string): Response {
  return browserResponse(bytes, {
    status: 200,
    headers: { "content-type": type, "content-disposition": `attachment; filename="${filename}"`, "content-length": String(bytes.length) },
  });
}
function refusal(status: number, error: string): Response {
  return browserResponse(JSON.stringify({ error }), { status, headers: { "content-type": "application/json; charset=utf-8" } });
}
function call(index: number): { url: string; init: RequestInit } {
  const [url, init] = fetchSpy.mock.calls[index] as [string, RequestInit];
  return { url, init };
}
function postedFields(init: RequestInit): Record<string, string> {
  return Object.fromEntries(new URLSearchParams(String(init.body)));
}

beforeAll(async () => {
  docxBytes = await new JSZip().file("word/document.xml", "<w:document/>").generateAsync({ type: "uint8array" });
  zipBytes = await new JSZip().file("letter.docx", docxBytes).generateAsync({ type: "uint8array" });
});

beforeEach(() => {
  vi.clearAllMocks();
  state.estate = {
    id: "estate-19", revision: 1, deceasedFirstName: "Helen Rose", deceasedLastName: "Calder-Quay",
    grantType: "grant_of_probate", willStatus: "will", hasWill: 1, registry: "Victoria",
    deceasedDomiciledInBC: "yes", deceasedOrdinarilyResidentInBC: "yes", oathType: "affirmed", domicileCity: "Victoria",
  };
  state.contacts = [jordan, avery];
  state.documents = [{ id: "primary", formCode: "P3", deponentId: "jordan", deponentName: jordan.name, signatureDate: "2026-09-05" }];
  state.generateCalls = [];
  state.bulkCalls = [];
  state.generateResponse = { id: "doc_p8_1", delivery: p8Delivery, filename: "P8_Avery_Calder-Quay.docx", format: "docx" };
  nativeSubmits.length = 0;
  anchorClicks.length = 0;
  blobs.length = 0;
  fetchSpy.mockReset();
  vi.stubGlobal("fetch", fetchSpy);
  sessionStorage.setItem("manus-cookie", `app_session_id=${TOKEN}`);
  vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) {
    nativeSubmits.push(this.getAttribute("action") ?? "");
  });
  vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(function (this: HTMLAnchorElement) {
    anchorClicks.push({ href: this.href, download: this.download });
  });
  Object.defineProperty(URL, "createObjectURL", {
    configurable: true, writable: true,
    value: vi.fn((blob: Blob) => { blobs.push(blob); return `blob:http://localhost/task9-${blobs.length}`; }),
  });
  Object.defineProperty(URL, "revokeObjectURL", { configurable: true, writable: true, value: vi.fn() });
});

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  sessionStorage.clear();
  delete (URL as any).createObjectURL;
  delete (URL as any).revokeObjectURL;
});

async function mountForms() {
  const { FormsTab } = await import("./EstateDetail");
  render(<FormsTab estateId="estate-19" estate={state.estate} onNavigateToTab={vi.fn()} />);
}

async function generateP8ForAvery() {
  await mountForms();
  fireEvent.click(within(screen.getByTestId("form-row-P8")).getAllByRole("button", { name: "Generate" })[0]);
  fireEvent.click(await screen.findByTestId("form-details-generate"));
}

function expectBearerFormFetch(index: number, fields: Record<string, string>, action = "/api/download/form") {
  const { url, init } = call(index);
  expect(url).toBe(action);
  expect(init).toMatchObject({ method: "POST", credentials: "include", redirect: "manual" });
  expect(init.headers).toEqual({ "Content-Type": "application/x-www-form-urlencoded", Authorization: `Bearer ${TOKEN}` });
  expect(postedFields(init)).toEqual({ ...fields, attemptId: expect.stringMatching(UUID_V4) });
  expect(String(init.body)).not.toContain(TOKEN);
  expect(url).not.toContain(TOKEN);
}

describe("Task 9: Bearer-fallback deliveries from the Forms tab", () => {
  it("a single-form auto-download sends one Bearer fetch, hands off the DOCX, and only then shows its handoff toast", async () => {
    fetchSpy.mockResolvedValueOnce(attachment(docxBytes, DOCX, "P8_Avery_Calder-Quay_1.docx"));
    await generateP8ForAvery();

    await waitFor(() => expect(anchorClicks).toHaveLength(1));
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    expectBearerFormFetch(0, p8Delivery.fields);
    expect(nativeSubmits).toEqual([]);
    expect(anchorClicks[0]).toEqual({ href: "blob:http://localhost/task9-1", download: "P8_Avery_Calder-Quay_1.docx" });
    expect(new Uint8Array(await blobs[0].arrayBuffer())).toEqual(docxBytes);
    expect(blobs[0].type).toBe(DOCX);
    expect(toast.loading).toHaveBeenCalledWith("Form generated — preparing the download…");
    await waitFor(() => expect(toast.success).toHaveBeenCalledWith("Form generated — download started."));
    expect(toast.success).toHaveBeenCalledTimes(1);
    expect(toast.error).not.toHaveBeenCalled();
    expect(screen.getByTestId("p8-download-recovery").textContent).toMatch(/Form P8 is ready/i);
  });

  it("a refused Bearer delivery shows only its sentence, keeps the recovery, and the explicit retry is a fresh activation", async () => {
    fetchSpy
      .mockResolvedValueOnce(refusal(401, "Authentication required"))
      .mockResolvedValueOnce(attachment(docxBytes, DOCX, "P8_Avery_Calder-Quay_1.docx"));
    await generateP8ForAvery();

    await waitFor(() => expect(toast.error).toHaveBeenCalledWith("Authentication required"));
    expect(toast.success).not.toHaveBeenCalled();
    expect(anchorClicks).toEqual([]);
    expect(nativeSubmits).toEqual([]);
    const retry = await screen.findByTestId("p8-download-retry") as HTMLButtonElement;
    // Task 13: the button stays disabled while its own delivery is in flight, then a 401 keeps it usable.
    await waitFor(() => expect(retry.disabled).toBe(false));
    fireEvent.click(retry);

    await waitFor(() => expect(anchorClicks).toHaveLength(1));
    expect(fetchSpy).toHaveBeenCalledTimes(2);
    expectBearerFormFetch(1, p8Delivery.fields);
    expect(postedFields(call(1).init).attemptId).not.toBe(postedFields(call(0).init).attemptId);
    expect(state.generateCalls).toHaveLength(1);
    // Button retries keep no success toast of their own; the refusal toast stays the only error.
    expect(toast.success).not.toHaveBeenCalled();
    expect(toast.error).toHaveBeenCalledTimes(1);
    expect(nativeSubmits).toEqual([]);
  });

  it("the generic recovery button re-delivers a non-P8 form with a fresh Bearer activation", async () => {
    const p3Delivery = { method: "POST", action: "/api/download/form", fields: { estateId: "estate-19", formCode: "P3", documentId: "doc_p3_1", signatoryType: "executor", signatureDate: "2026-09-06" } };
    state.documents = [];
    state.generateResponse = { id: "doc_p3_1", delivery: p3Delivery, filename: "P3_Calder-Quay.docx", format: "docx" };
    fetchSpy
      .mockResolvedValueOnce(attachment(docxBytes, DOCX, "P3_Calder-Quay_1.docx"))
      .mockResolvedValueOnce(attachment(docxBytes, DOCX, "P3_Calder-Quay_1.docx"));
    await mountForms();
    fireEvent.click(screen.getByTestId("form-generate-P3"));
    const details = await screen.findByTestId("form-details-generate").catch(() => null);
    if (details) fireEvent.click(details);

    await waitFor(() => expect(anchorClicks).toHaveLength(1));
    expectBearerFormFetch(0, p3Delivery.fields);
    const retry = await screen.findByTestId("document-generation-download-retry") as HTMLButtonElement;
    await waitFor(() => expect(retry.disabled).toBe(false));
    fireEvent.click(retry);
    await waitFor(() => expect(anchorClicks).toHaveLength(2));
    expectBearerFormFetch(1, p3Delivery.fields);
    expect(postedFields(call(1).init).attemptId).not.toBe(postedFields(call(0).init).attemptId);
    expect(state.generateCalls).toHaveLength(1);
    expect(nativeSubmits).toEqual([]);
  });

  it.each([
    ["Generate all letters", "letters", "Generated letters — download started."],
    ["Generate Grant Package (ZIP)", "package", "Grant package generated — download started."],
    ["Generate All P8 (2)", "p8_all", "Generated 2 P8 affidavits — download started."],
  ])("%s sends one Bearer export fetch and hands off the ZIP before its toast", async (label, type, successText) => {
    state.contacts = [jordan, avery, riley, beneficiary];
    state.documents = [];
    fetchSpy.mockResolvedValueOnce(attachment(zipBytes, "application/zip", `Bulk_${type}_Calder-Quay_1.zip`));
    await mountForms();
    fireEvent.click(await screen.findByRole("button", { name: label }));

    await waitFor(() => expect(anchorClicks).toHaveLength(1));
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    const { url, init } = call(0);
    expect(url).toBe("/api/download/export");
    expect(init.headers).toEqual({ "Content-Type": "application/x-www-form-urlencoded", Authorization: `Bearer ${TOKEN}` });
    expect(postedFields(init)).toMatchObject({ type, estateId: "estate-19", attemptId: expect.stringMatching(UUID_V4) });
    expect(anchorClicks[0].download).toBe(`Bulk_${type}_Calder-Quay_1.zip`);
    await waitFor(() => expect(toast.success).toHaveBeenCalledWith(successText));
    expect(toast.error).not.toHaveBeenCalled();
    expect(nativeSubmits).toEqual([]);
  });
});

describe("Task 9: the preview modal's DOCX download with the Bearer fallback", () => {
  async function renderPreview(runWithPreflight: (...args: any[]) => unknown) {
    const { FormPreviewModal } = await import("./EstateDetail");
    render(<FormPreviewModal
      estateId="estate-19" formCode="P8" formName="Affidavit in Support of Application for Estate Grant"
      signatoryType="executor" signatureDate="2026-09-06" deponentId="avery"
      open={true} onOpenChange={vi.fn()} runWithPreflight={runWithPreflight as any}
    />);
  }

  it("keeps its JSON request, adds the fallback Authorization header, and hands off the DOCX", async () => {
    fetchSpy.mockResolvedValueOnce(attachment(docxBytes, DOCX, "P8_Avery_Calder-Quay_1.docx"));
    let outcome: Promise<string> | null = null;
    await renderPreview(async (_codes: string[], _name: string, doMutate: () => unknown) => {
      outcome = Promise.resolve(doMutate()).then(() => "resolved", () => "rejected");
      return true;
    });
    fireEvent.click(screen.getByTestId("preview-download-docx"));

    await waitFor(() => expect(outcome).not.toBeNull());
    await expect(outcome!).resolves.toBe("resolved");
    const { url, init } = call(0);
    expect(url).toBe("/api/download/form");
    expect(init).toMatchObject({ method: "POST", credentials: "include", redirect: "manual" });
    expect(init.headers).toEqual({ "Content-Type": "application/json", Authorization: `Bearer ${TOKEN}` });
    expect(JSON.parse(String(init.body))).toEqual({ ...p8Delivery.fields, attemptId: expect.stringMatching(UUID_V4) });
    expect(anchorClicks).toEqual([{ href: "blob:http://localhost/task9-1", download: "P8_Avery_Calder-Quay_1.docx" }]);
    expect(toast.success).toHaveBeenCalledWith("DOCX download started.");
    expect(nativeSubmits).toEqual([]);
  });

  it("names a ZIP as a ZIP (Task 13: never an unconditional DOCX claim)", async () => {
    fetchSpy.mockResolvedValueOnce(attachment(zipBytes, "application/zip", "P34_Calder-Quay_with_evidence_1.zip"));
    let outcome: Promise<string> | null = null;
    await renderPreview(async (_codes: string[], _name: string, doMutate: () => unknown) => {
      outcome = Promise.resolve(doMutate()).then(() => "resolved", () => "rejected");
      return true;
    });
    fireEvent.click(screen.getByTestId("preview-download-docx"));

    await waitFor(() => expect(outcome).not.toBeNull());
    await expect(outcome!).resolves.toBe("resolved");
    expect(anchorClicks).toEqual([{ href: "blob:http://localhost/task9-1", download: "P34_Calder-Quay_with_evidence_1.zip" }]);
    expect(toast.success).toHaveBeenCalledWith("ZIP download started.");
    expect(toast.success).not.toHaveBeenCalledWith("DOCX download started.");
  });

  it("a refused preview download shows the sentence, saves nothing, and rejects to the preflight path", async () => {
    fetchSpy.mockResolvedValueOnce(refusal(409, "This download link is out of date. Generate the document again."));
    let outcome: Promise<string> | null = null;
    await renderPreview(async (_codes: string[], _name: string, doMutate: () => unknown) => {
      outcome = Promise.resolve(doMutate()).then(() => "resolved", () => "rejected");
      return true;
    });
    fireEvent.click(screen.getByTestId("preview-download-docx"));

    await waitFor(() => expect(outcome).not.toBeNull());
    await expect(outcome!).resolves.toBe("rejected");
    expect(toast.error).toHaveBeenCalledWith("This download link is out of date. Generate the document again.");
    expect(toast.success).not.toHaveBeenCalled();
    expect(anchorClicks).toEqual([]);
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    expect((call(0).init.headers as Record<string, string>).Authorization).toBe(`Bearer ${TOKEN}`);
  });
});
