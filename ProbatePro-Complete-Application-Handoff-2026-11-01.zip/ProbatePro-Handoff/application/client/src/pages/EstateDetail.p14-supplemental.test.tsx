import React from "react";
import { act, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { createXlsxWorkbook, XLSX_MIME_TYPE } from "@/lib/xlsxWorkbook";

// Heavy jsdom file: each test imports EstateDetail (a very large module) inside the
// test body. Same ceiling as the sibling audit specs.
vi.setConfig({ testTimeout: 45000 }); // 2026-08-21: jsdom EstateDetail suites breached 15-20s under full-suite worker contention (flake class, memory probatepro-test-flakiness) — headroom, not speed, keeps the gate reproducible

// tsconfig sets jsx:"preserve", so esbuild under vitest emits the classic
// React.createElement transform; vitest.config.ts has no react() plugin to supply the
// automatic runtime the app gets from vite.config.ts. IntakeTab renders ui/collapsible,
// which annotates React.ComponentProps without importing React — fine in the app, but
// undefined here. ponytail: harness gap, not a product bug — drop this line once
// vitest.config.ts sets esbuild.jsx:"automatic" (out of scope for this change).
(globalThis as any).React = React;

const mocks = vi.hoisted(() => ({
  items: [] as any[],
  contacts: [] as any[],
  totals: undefined as any,
  inventoryCreate: vi.fn(),
  inventoryUpdate: vi.fn(),
  inventoryDelete: vi.fn(),
  inventoryBulkCreate: vi.fn(),
  estateUpdate: vi.fn(),
}));

vi.mock("sonner", () => ({
  toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }),
}));

vi.mock("@/lib/trpc", () => {
  const idleMutation = () => ({ mutate: vi.fn(), mutateAsync: vi.fn(async () => ({})), isPending: false });
  const invalidator = () => ({ invalidate: vi.fn() });
  return {
    trpc: {
      inventory: {
        list: { useQuery: () => ({ data: mocks.items, isLoading: false }) },
        totals: { useQuery: () => ({ data: mocks.totals }) },
        create: { useMutation: () => ({ mutate: mocks.inventoryCreate, isPending: false }) },
        update: {
          useMutation: () => ({
            mutate: mocks.inventoryUpdate,
            mutateAsync: vi.fn(async (x: any) => { mocks.inventoryUpdate(x); return x; }),
            isPending: false,
          }),
        },
        delete: { useMutation: () => ({ mutate: mocks.inventoryDelete, isPending: false }) },
        reorder: { useMutation: idleMutation },
        bulkCreate: { useMutation: () => ({ mutate: mocks.inventoryBulkCreate, isPending: false }) },
      },
      contact: {
        list: { useQuery: () => ({ data: mocks.contacts }) },
        create: { useMutation: idleMutation },
      },
      settings: { get: { useQuery: () => ({ data: { formFocusedIntake: false } }) } },
      notes: { pinned: { useQuery: () => ({ data: [] }) } },
      estate: {
        update: { useMutation: () => ({ mutate: mocks.estateUpdate, isPending: false, isSuccess: false }) },
        uploadWill: { useMutation: idleMutation },
        deleteWill: { useMutation: idleMutation },
        uploadCodicil: { useMutation: idleMutation },
        deleteCodicil: { useMutation: idleMutation },
        reorderCodicils: { useMutation: idleMutation },
        updateCodicilDate: { useMutation: idleMutation },
        uploadForeignGrant: { useMutation: idleMutation },
        deleteForeignGrant: { useMutation: idleMutation },
        uploadLegalEvidence: { useMutation: idleMutation },
        clearLegalEvidence: { useMutation: idleMutation },
      },
      useUtils: () => ({
        inventory: { list: invalidator(), totals: invalidator() },
        distribution: { compute: invalidator() },
        readiness: { check: invalidator(), timeline: invalidator() },
        deadline: { list: invalidator() },
        delivery: { getRecipients: invalidator() },
        estate: { get: invalidator(), list: invalidator() },
        document: { preflight: invalidator(), preflightMany: invalidator() },
      }),
    },
  };
});

const ESTATE_BASE = { id: "estate-1", p10FiledDate: "", p11FiledDate: "" };

function item(o: Partial<Record<string, any>> = {}) {
  return {
    id: "item-1", estateId: "estate-1", category: "financial", description: "TD Chequing",
    location: "in_bc", value: 1000_00, valueRecorded: 1, passesToPersonalRepresentative: "yes", supplementalStatus: "", supplementalFiledDate: "",
    ...o,
  };
}

async function components() {
  const estateDetail = await import("./EstateDetail");
  const { TooltipProvider } = await import("@/components/ui/tooltip");
  return { ...estateDetail, TooltipProvider };
}

beforeEach(() => {
  mocks.items = [];
  mocks.contacts = [];
  mocks.totals = undefined;
  mocks.inventoryCreate.mockReset();
  mocks.inventoryUpdate.mockReset();
  mocks.inventoryDelete.mockReset();
  mocks.inventoryBulkCreate.mockReset();
  mocks.estateUpdate.mockReset();
  // Radix pointer interactions need these in jsdom.
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
  window.localStorage.clear();
});

describe("Probate Fee Act s. 1 ordinary-residence gate", () => {
  it("shows no exact basis or fee while ordinary residence is not determined", async () => {
    mocks.totals = {
      grossAssetsCents: 530_000_00,
      liabilitiesCents: 0,
      netCents: 530_000_00,
      feeBasisStatus: "ordinary_residence_required",
      ordinarilyResidentInBc: null,
      fee: null,
    };
    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={ESTATE_BASE} />
      </TooltipProvider>,
    );

    expect(screen.getByTestId("probate-fee-basis-value").textContent).toBe("Pending");
    expect(screen.getByTestId("probate-fee-value").textContent).toBe("Pending");
    expect(screen.getByTestId("probate-fee-residence-required").textContent).toContain(
      "Record whether the deceased was ordinarily resident in British Columbia immediately before death",
    );
  });

  it("labels the exact worldwide-intangibles basis after an explicit Yes answer", async () => {
    mocks.totals = {
      grossAssetsCents: 530_000_00,
      liabilitiesCents: 0,
      netCents: 530_000_00,
      feeBasisStatus: "known",
      ordinarilyResidentInBc: true,
      fee: {
        grossCents: 530_000_00,
        exempt: false,
        band1Cents: 15_000,
        band2Cents: 7_350_000,
        probateFeeCents: 7_365_000,
        filingFeeCents: 20_000,
        totalCents: 7_385_000,
      },
    };
    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={ESTATE_BASE} />
      </TooltipProvider>,
    );

    expect(screen.getByTestId("probate-fee-basis-value").textContent).not.toBe("Pending");
    expect(screen.getByText(/intangible personal property wherever situated/)).toBeTruthy();
  });
});

describe("Rule 25-3(9) supplemental provenance — inventory item form", () => {
  it("hides the provenance control until an earlier affidavit has actually been filed", async () => {
    const { InventoryFormFields, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryFormFields item={item()} setItem={vi.fn()} allItems={[]} supplementalAvailable={false} />
      </TooltipProvider>,
    );
    expect(screen.queryByTestId("inventory-supplemental-status")).toBeNull();
  });

  it("offers the three provenance options in plain legal English once P10 is filed", async () => {
    const { InventoryFormFields, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryFormFields item={item()} setItem={vi.fn()} allItems={[]} supplementalAvailable />
      </TooltipProvider>,
    );
    const select = screen.getByTestId("inventory-supplemental-status") as HTMLSelectElement;
    // Unset default — an unrecorded item is sworn on no supplemental (fails closed).
    expect(select.value).toBe("");
    expect([...select.options].map((o) => o.value)).toEqual(
      ["", "original", "not_disclosed", "inaccurately_disclosed"],
    );
    expect([...select.options].map((o) => o.textContent)).toEqual([
      "Not yet recorded",
      "Disclosed in the earlier affidavit",
      "Not disclosed in the earlier affidavit",
      "Disclosed inaccurately in the earlier affidavit",
    ]);
  });
});

describe("Rule 25-3(9) supplemental provenance — persistence (markDirty/whitelist class)", () => {
  // The create payload is an explicit field whitelist. If supplementalStatus is not
  // added to it, the select renders and the value is SILENTLY DROPPED on save.
  it("sends the recorded provenance to inventory.create", async () => {
    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={{ ...ESTATE_BASE, p10FiledDate: "2026-01-01" }} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getAllByRole("button", { name: /Add Item/ })[0]);
    const dialog = await screen.findByRole("dialog");
    fireEvent.change(within(dialog).getByTestId("inventory-supplemental-status"), {
      target: { value: "not_disclosed" },
    });
    fireEvent.click(within(dialog).getByRole("button", { name: "Add Item" }));

    expect(mocks.inventoryCreate).toHaveBeenCalledWith(
      expect.objectContaining({ estateId: "estate-1", supplementalStatus: "not_disclosed" }),
    );
  });

  it("defaults to the unset status on create when the user records nothing", async () => {
    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={{ ...ESTATE_BASE, p11FiledDate: "2026-01-01" }} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getAllByRole("button", { name: /Add Item/ })[0]);
    const dialog = await screen.findByRole("dialog");
    fireEvent.click(within(dialog).getByRole("button", { name: "Add Item" }));

    expect(mocks.inventoryCreate).toHaveBeenCalledWith(
      expect.objectContaining({ supplementalStatus: "" }),
    );
  });

  // The edit dialog spreads editingItem into the update payload, so the only place
  // the edit path could drop provenance is the row->form hydration.
  it("round-trips provenance through the edit-form hydration", async () => {
    const { hydrateInventoryItemForEdit } = await import("@/lib/inventoryValue");
    expect(hydrateInventoryItemForEdit(item({
      supplementalStatus: "inaccurately_disclosed",
      supplementalFiledDate: "2026-03-02",
    }))).toEqual(expect.objectContaining({
      supplementalStatus: "inaccurately_disclosed",
      supplementalFiledDate: "2026-03-02",
    }));
  });
});

describe("Rule 25-3(9) lineage — marking a supplemental as filed", () => {
  it("stays hidden when no item is pending disclosure on a supplemental", async () => {
    const { InventoryTab, TooltipProvider } = await components();
    mocks.items = [item({ supplementalStatus: "original" })];
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={{ ...ESTATE_BASE, p10FiledDate: "2026-01-01" }} />
      </TooltipProvider>,
    );
    expect(screen.queryByTestId("mark-supplemental-filed")).toBeNull();
  });

  it("records the filing date on exactly the items the supplemental disclosed", async () => {
    const { InventoryTab, TooltipProvider } = await components();
    mocks.items = [
      item({ id: "undisclosed", supplementalStatus: "not_disclosed" }),
      item({ id: "misstated", supplementalStatus: "inaccurately_disclosed" }),
      // Correctly disclosed earlier — never on a supplemental.
      item({ id: "original", supplementalStatus: "original" }),
      // Unresolved — fails closed, on no supplemental.
      item({ id: "unresolved", supplementalStatus: "" }),
      // Already carried by an earlier filed supplemental — must not be re-dated.
      item({ id: "already-filed", supplementalStatus: "not_disclosed", supplementalFiledDate: "2026-02-01" }),
    ];
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={{ ...ESTATE_BASE, p10FiledDate: "2026-01-01" }} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByTestId("mark-supplemental-filed"));
    const dialog = await screen.findByRole("dialog");
    fireEvent.change(within(dialog).getByTestId("supplemental-filed-date"), {
      target: { value: "2026-08-01" },
    });
    await act(async () => {
      fireEvent.click(within(dialog).getByRole("button", { name: "Record filing date" }));
    });

    await vi.waitFor(() => expect(mocks.inventoryUpdate).toHaveBeenCalledTimes(2));
    expect(mocks.inventoryUpdate.mock.calls.map((c) => c[0].id).sort()).toEqual(["misstated", "undisclosed"]);
    for (const call of mocks.inventoryUpdate.mock.calls) {
      expect(call[0]).toEqual(expect.objectContaining({
        estateId: "estate-1",
        data: { supplementalFiledDate: "2026-08-01" },
      }));
    }
  });

  it("will not record an empty filing date", async () => {
    const { InventoryTab, TooltipProvider } = await components();
    mocks.items = [item({ supplementalStatus: "not_disclosed" })];
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={{ ...ESTATE_BASE, p10FiledDate: "2026-01-01" }} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByTestId("mark-supplemental-filed"));
    const dialog = await screen.findByRole("dialog");
    const submit = within(dialog).getByRole("button", { name: "Record filing date" }) as HTMLButtonElement;
    expect(submit.disabled).toBe(true);
    fireEvent.click(submit);
    expect(mocks.inventoryUpdate).not.toHaveBeenCalled();
  });
});

describe("P10/P11 filed dates — Intake persistence (markDirty class)", () => {
  it("sends an edited P10/P11 filed date to estate.update", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const { unmount } = render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE }} />
      </TooltipProvider>,
    );

    fireEvent.change(screen.getByLabelText("P10 Filed Date"), { target: { value: "2026-05-01" } });
    fireEvent.change(screen.getByLabelText("P11 Filed Date"), { target: { value: "2026-05-02" } });
    // Intake persists on unmount (tab switch).
    unmount();

    expect(mocks.estateUpdate).toHaveBeenCalledWith(expect.objectContaining({
      id: "estate-1",
      data: expect.objectContaining({ p10FiledDate: "2026-05-01", p11FiledDate: "2026-05-02" }),
    }));
  });

  // The recurring silent-drop bug: an input that renders but never marks the field
  // dirty is clobbered by the next server resync before it is ever saved. Remove
  // markDirty() from field() and this test fails.
  it("keeps a typed filed date across a server resync (does not silently drop it)", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const { rerender } = render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE }} />
      </TooltipProvider>,
    );

    fireEvent.change(screen.getByLabelText("P10 Filed Date"), { target: { value: "2026-05-01" } });
    // A refetch delivers a new estate object that does not yet carry the edit.
    rerender(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE }} />
      </TooltipProvider>,
    );

    expect((screen.getByLabelText("P10 Filed Date") as HTMLInputElement).value).toBe("2026-05-01");
  });
});

describe("Rule 25-6(7) resealing — provenance controls unlock without a P10/P11 (2026-07-17 sweep F17)", () => {
  // A resealing estate files its affidavit of assets and liabilities FOR
  // RESEALING with the application itself (Rule 25-6(2)(g)) — it never has a
  // p10FiledDate/p11FiledDate, so the provenance CONTROLS key on the grant
  // type (recording provenance starts while the application is assembled).
  // Note: since 2026-07-26 (P15PLUS-002) formStatus("P26") itself additionally
  // gates on the recorded p25FiledDate — the FORM is gated, the control is not.
  it("unlocks the provenance control on a resealing estate with no filed P10/P11", async () => {
    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={{ ...ESTATE_BASE, grantType: "resealing" }} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getAllByRole("button", { name: /Add Item/ })[0]);
    const dialog = await screen.findByRole("dialog");
    expect(within(dialog).getByTestId("inventory-supplemental-status")).toBeTruthy();
  });

  it("stays locked on an estate-grant lineage with no filed P10/P11 (fail-closed)", async () => {
    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={{ ...ESTATE_BASE, grantType: "grant_of_probate" }} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getAllByRole("button", { name: /Add Item/ })[0]);
    const dialog = await screen.findByRole("dialog");
    expect(within(dialog).queryByTestId("inventory-supplemental-status")).toBeNull();
  });
});

describe("same-bank financial account entry", () => {
  it("keeps only bank-level facts and prompts for a distinct account", async () => {
    mocks.items = [item({
      description: "RBC Day to Day Banking VIP 05920-5002878 — closing balance",
      location: "in_bc",
      subcategory: "chequing",
      bankAddress: "1715 COMMERCIAL DR, VANCOUVER, BC",
      accountHolder: "Hector Nicolson",
      accountNumber: "05920-5002878",
      accruedInterest: 4500,
      dateOfDeathValue: 500000,
    })];
    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={ESTATE_BASE} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByRole("button", { name: "Add a distinct account at this bank" }));
    const dialog = await screen.findByRole("dialog");

    expect(within(dialog).getByRole("heading", { name: "Add Account 2" })).toBeTruthy();
    expect(dialog.className).toContain("sm:max-w-4xl");
    expect(dialog.className).toContain("rounded-2xl");
    expect(dialog.className).toContain("shadow-");
    expect(within(dialog).queryByText("Category")).toBeNull();
    const review = within(dialog).getByTestId("inventory-bank-account-review");
    expect(review.textContent).toContain("Review saved accounts");
    expect(review.textContent).toContain("1");
    expect(review.textContent).not.toContain("Chequing · ••••2878");
    fireEvent.click(within(review).getByRole("button", { name: /View/i }));
    expect(review.querySelector(".bank-account-review-content")?.getAttribute("data-state")).toBe("open");
    expect(review.textContent).toContain("Chequing · ••••2878");
    expect((within(dialog).getByTestId("inventory-bank-address") as HTMLInputElement).value).toBe("1715 COMMERCIAL DR, VANCOUVER, BC");
    expect((within(dialog).getByTestId("inventory-description") as HTMLInputElement).value).toBe("");
    expect((within(dialog).getByTestId("inventory-account-holder") as HTMLInputElement).value).toBe("");
    expect((within(dialog).getByTestId("inventory-account-number") as HTMLInputElement).value).toBe("");
    expect(within(dialog).getByTestId("inventory-account-type").textContent).toContain("Select type");
    expect(within(dialog).getByTestId("inventory-account-type").hasAttribute("disabled")).toBe(false);
    expect(within(dialog).getByText("Account 2 number")).toBeTruthy();
  });

  it("blocks a duplicate account number until a distinct number is entered", async () => {
    mocks.items = [item({ bankAddress: "1715 COMMERCIAL DR", accountNumber: "05920-5002878" })];
    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={ESTATE_BASE} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByRole("button", { name: "Add a distinct account at this bank" }));
    const dialog = await screen.findByRole("dialog");
    const number = within(dialog).getByTestId("inventory-account-number");
    fireEvent.change(number, { target: { value: "05920 5002878" } });

    expect(number.getAttribute("aria-invalid")).toBe("true");
    expect(within(dialog).getByRole("alert").textContent).toContain("already recorded");
    expect(within(dialog).getByRole("button", { name: "Add Item" }).hasAttribute("disabled")).toBe(true);
    expect(within(dialog).getByRole("button", { name: /Save Account 2 & add Account 3/i }).hasAttribute("disabled")).toBe(true);

    fireEvent.change(number, { target: { value: "05920-5002879" } });
    expect(within(dialog).queryByRole("alert")).toBeNull();
    expect(within(dialog).getByRole("button", { name: "Add Item" }).hasAttribute("disabled")).toBe(false);
  });

  it("shows real-time account number format feedback before the duplicate check", async () => {
    mocks.items = [item({ bankAddress: "1715 COMMERCIAL DR", accountNumber: "05920-5002878" })];
    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={ESTATE_BASE} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByRole("button", { name: "Add a distinct account at this bank" }));
    const dialog = await screen.findByRole("dialog");
    const number = within(dialog).getByTestId("inventory-account-number");

    fireEvent.change(number, { target: { value: "12!" } });
    expect(number.getAttribute("aria-invalid")).toBe("true");
    expect(within(dialog).getByText("Use at least 4 letters or numbers. Spaces and hyphens are allowed.")).toBeTruthy();
    expect(within(dialog).getByRole("button", { name: "Add Item" }).hasAttribute("disabled")).toBe(true);

    fireEvent.change(number, { target: { value: "05920-5002879" } });
    expect(number.getAttribute("aria-invalid")).toBeNull();
    expect(within(dialog).getByTestId("inventory-account-number-valid")).toBeTruthy();
    expect(within(dialog).getByRole("button", { name: "Add Item" }).hasAttribute("disabled")).toBe(false);
  });

  it("offers the safe account-delete confirmation from account editing", async () => {
    mocks.items = [item({ id: "account-1", accountNumber: "05920-5002878" })];
    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={ESTATE_BASE} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByRole("button", { name: "Edit inventory item" }));
    const editDialog = await screen.findByRole("dialog");
    expect(within(editDialog).getByRole("button", { name: "Delete account" })).toBeTruthy();

    fireEvent.click(within(editDialog).getByRole("button", { name: "Delete account" }));
    const confirmation = await screen.findByRole("alertdialog");
    expect(within(confirmation).getByText("Delete this item?")).toBeTruthy();
    expect(within(confirmation).getByText(/Acct #05920-5002878/)).toBeTruthy();
    expect(within(confirmation).getByRole("button", { name: "Delete" })).toBeTruthy();
  });

  it("keeps the next same-bank form distinct after saving the current account", async () => {
    const { InventoryTab, TooltipProvider } = await components();
    mocks.inventoryCreate.mockImplementation((_payload: unknown, options?: { onSuccess?: () => void }) => options?.onSuccess?.());
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={ESTATE_BASE} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByRole("button", { name: /Add Item/ }));
    const dialog = await screen.findByRole("dialog");
    const category = within(dialog).getByText("Not yet classified");
    fireEvent.click(category);
    fireEvent.click(await screen.findByRole("option", { name: "Financial Assets" }));
    fireEvent.change(within(dialog).getByTestId("inventory-description"), { target: { value: "RBC chequing" } });
    fireEvent.change(within(dialog).getByTestId("inventory-bank-address"), { target: { value: "1715 COMMERCIAL DR" } });
    fireEvent.change(within(dialog).getByTestId("inventory-account-holder"), { target: { value: "Hector Nicolson" } });
    fireEvent.change(within(dialog).getByTestId("inventory-account-number"), { target: { value: "05920-5002878" } });
    fireEvent.click(within(dialog).getByRole("button", { name: /Save & add a distinct account/i }));

    const nextDialog = await screen.findByRole("dialog");
    expect(within(nextDialog).getByRole("heading", { name: "Add Account 2" })).toBeTruthy();
    const review = within(nextDialog).getByTestId("inventory-bank-account-review");
    fireEvent.click(within(review).getByRole("button", { name: /View/i }));
    expect(review.textContent).toContain("Account · ••••2878");
    expect((within(nextDialog).getByTestId("inventory-bank-address") as HTMLInputElement).value).toBe("1715 COMMERCIAL DR");
    expect((within(nextDialog).getByTestId("inventory-description") as HTMLInputElement).value).toBe("");
    expect((within(nextDialog).getByTestId("inventory-account-holder") as HTMLInputElement).value).toBe("");
    expect((within(nextDialog).getByTestId("inventory-account-number") as HTMLInputElement).value).toBe("");
    expect(mocks.inventoryCreate).toHaveBeenCalledWith(expect.objectContaining({
      description: "RBC chequing",
      accountHolder: "Hector Nicolson",
      accountNumber: "05920-5002878",
      bankAddress: "1715 COMMERCIAL DR",
    }), expect.anything());
  });

  it("keeps a blank-description additional account beneath the bank it came from", async () => {
    mocks.items = [
      item({
        id: "account-1",
        description: "RBC Day to Day Banking VIP 05920-5002878 — closing balance",
        bankAddress: "1715 COMMERCIAL DR, VANCOUVER, BC",
        accountNumber: "05920-5002878",
      }),
      item({
        id: "account-2",
        description: "",
        bankAddress: "1715 COMMERCIAL DR, VANCOUVER, BC",
        accountNumber: "0001-2345",
      }),
    ];
    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={ESTATE_BASE} />
      </TooltipProvider>,
    );

    expect(screen.getAllByText("RBC Day to Day Banking VIP 05920-5002878 — closing balance").length).toBeGreaterThan(0);
    expect(screen.getByText("Account 2")).toBeTruthy();
    expect(screen.queryByText("Unknown Institution")).toBeNull();
  });
});

describe("Excel inventory import", () => {
  it("offers an Excel template and accepts only modern Excel workbooks", async () => {
    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={ESTATE_BASE} />
      </TooltipProvider>,
    );

    expect(screen.getByRole("button", { name: "Excel template" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "Import Excel" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "Download template" })).toBeTruthy();
    expect(screen.queryByText("Import CSV")).toBeNull();
    const input = screen.getByLabelText("Import Excel inventory workbook") as HTMLInputElement;
    expect(input.accept).toContain(".xlsx");
    expect(input.accept).not.toContain(".csv");
  });

  it("stages a real Excel workbook for review before importing it", async () => {
    const workbook = await createXlsxWorkbook({
      sheetName: "Inventory",
      headers: ["category", "description", "location", "value", "passes_to_personal_representative", "account_number"],
      rows: [{
        category: "financial",
        description: "RBC, chequing account",
        location: "in_bc",
        value: 1025.5,
        passes_to_personal_representative: "yes",
        account_number: "05920-5002878",
      }],
    });
    const file = new File([workbook], "inventory.xlsx", { type: XLSX_MIME_TYPE });

    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={ESTATE_BASE} />
      </TooltipProvider>,
    );

    fireEvent.change(screen.getByLabelText("Import Excel inventory workbook"), { target: { files: [file] } });

    await waitFor(() => {
      expect(screen.getByTestId("inventory-excel-preview")).toBeTruthy();
    });
    expect((screen.getByLabelText("Row 1 description") as HTMLInputElement).value).toBe("RBC, chequing account");
    expect((screen.getByLabelText("Row 1 account number") as HTMLInputElement).value).toBe("05920-5002878");
    expect(mocks.inventoryBulkCreate).not.toHaveBeenCalled();

    fireEvent.click(screen.getByRole("button", { name: "Import 1 item" }));
    expect(mocks.inventoryBulkCreate).toHaveBeenCalledWith(expect.objectContaining({
      estateId: "estate-1",
      items: [expect.objectContaining({
        description: "RBC, chequing account",
        value: 102_550,
        accountNumber: "05920-5002878",
      })],
    }));
    expect(mocks.inventoryBulkCreate.mock.calls[0]?.[0]?.items?.[0]).not.toHaveProperty("valueInput");
  });

  it("lets a user discard a staged workbook without adding any inventory records", async () => {
    const workbook = await createXlsxWorkbook({
      sheetName: "Inventory",
      headers: ["category", "description", "location", "value"],
      rows: [{ category: "financial", description: "Draft chequing", location: "in_bc", value: 75 }],
    });
    const file = new File([workbook], "do-not-import.xlsx", { type: XLSX_MIME_TYPE });
    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={ESTATE_BASE} />
      </TooltipProvider>,
    );

    fireEvent.change(screen.getByLabelText("Import Excel inventory workbook"), { target: { files: [file] } });
    await waitFor(() => expect(screen.getByTestId("inventory-excel-preview")).toBeTruthy());

    fireEvent.click(screen.getByRole("button", { name: "Discard import" }));

    expect(screen.queryByTestId("inventory-excel-preview")).toBeNull();
    expect(mocks.inventoryBulkCreate).not.toHaveBeenCalled();
    expect(screen.getByText("Drop an Excel workbook here")).toBeTruthy();
  });

  it("flags malformed preview rows and lets users repair cells before import", async () => {
    const workbook = await createXlsxWorkbook({
      sheetName: "Inventory",
      headers: ["category", "description", "location", "value", "account_number"],
      rows: [{
        category: "miscellaneous",
        description: "",
        location: "somewhere",
        value: "not a number",
        account_number: "12",
      }],
    });
    const file = new File([workbook], "needs-review.xlsx", { type: XLSX_MIME_TYPE });
    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={ESTATE_BASE} />
      </TooltipProvider>,
    );

    fireEvent.change(screen.getByLabelText("Import Excel inventory workbook"), { target: { files: [file] } });
    await waitFor(() => expect(screen.getByTestId("inventory-excel-preview-errors")).toBeTruthy());

    const importButton = screen.getByRole("button", { name: "Import 1 item" });
    expect((importButton as HTMLButtonElement).disabled).toBe(true);
    expect(screen.getByLabelText("Row 1 type").getAttribute("aria-invalid")).toBe("true");
    expect(screen.getByLabelText("Row 1 description").getAttribute("aria-invalid")).toBe("true");
    expect(screen.getByLabelText("Row 1 location").getAttribute("aria-invalid")).toBe("true");
    expect(screen.getByLabelText("Row 1 value").getAttribute("aria-invalid")).toBe("true");
    expect(screen.getByLabelText("Row 1 account number").getAttribute("aria-invalid")).toBe("true");

    fireEvent.change(screen.getByLabelText("Row 1 type"), { target: { value: "tangible" } });
    fireEvent.change(screen.getByLabelText("Row 1 description"), { target: { value: "Artwork" } });
    fireEvent.change(screen.getByLabelText("Row 1 location"), { target: { value: "in_bc" } });
    fireEvent.change(screen.getByLabelText("Row 1 value"), { target: { value: "125.50" } });
    fireEvent.change(screen.getByLabelText("Row 1 account number"), { target: { value: "" } });

    await waitFor(() => expect((importButton as HTMLButtonElement).disabled).toBe(false));
    expect(screen.queryByTestId("inventory-excel-preview-errors")).toBeNull();

    fireEvent.click(importButton);
    expect(mocks.inventoryBulkCreate).toHaveBeenCalledWith(expect.objectContaining({
      estateId: "estate-1",
      items: [expect.objectContaining({
        category: "tangible",
        description: "Artwork",
        location: "in_bc",
        value: 12_550,
        accountNumber: "",
      })],
    }));
  });

  it("accepts a dropped workbook and gives immediate reading feedback", async () => {
    let resolveWorkbook: ((value: ArrayBuffer) => void) | undefined;
    const readingPromise = new Promise<ArrayBuffer>((resolve) => { resolveWorkbook = resolve; });
    const file = new File(["placeholder"], "inventory.xlsx", { type: XLSX_MIME_TYPE });
    Object.defineProperty(file, "arrayBuffer", { value: () => readingPromise });

    const { InventoryTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <InventoryTab estateId="estate-1" estate={ESTATE_BASE} />
      </TooltipProvider>,
    );

    fireEvent.dragEnter(screen.getByTestId("inventory-excel-drop-zone"), { dataTransfer: { files: [file], types: ["Files"] } });
    fireEvent.drop(screen.getByTestId("inventory-excel-drop-zone"), { dataTransfer: { files: [file], types: ["Files"] } });

    await waitFor(() => {
      expect(screen.getByTestId("inventory-excel-reading-status")).toBeTruthy();
    });
    expect(screen.getByText("Reading Excel workbook…")).toBeTruthy();
    resolveWorkbook?.(new ArrayBuffer(0));
    await waitFor(() => {
      expect(screen.queryByTestId("inventory-excel-reading-status")).toBeNull();
    });
  });
});
