import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(join(process.cwd(), "client/src/pages/EstateDetail.tsx"), "utf8");

describe("AI import proposal cache contract", () => {
  // The isolated import implementation remains covered because existing
  // proposals can still be safely processed server-side, but it is no longer
  // mounted in the estate Intake workflow.
  it("refreshes the estate proposal list after processing succeeds", () => {
    const importCard = source.slice(source.indexOf("function AiImportCard"), source.indexOf("function AiImportsSection"));

    expect(importCard).toMatch(/processMutation[\s\S]*?onSuccess:\s*\(\)\s*=>\s*\{[\s\S]*?utils\.aiImport\.list\.invalidate\(\{ estateId \}\)/);
  });

  it("fails the importer UI closed until processor approval and point-of-use acknowledgment", () => {
    const importCard = source.slice(source.indexOf("function AiImportCard"), source.indexOf("function AiImportsSection"));
    expect(importCard).toMatch(/trpc\.system\.aiFeatures\.useQuery\(\)/);
    expect(importCard).toContain("File text is sent to two third-party AI models");
    expect(importCard).toContain("Confirm authorization to send this document to the AI providers");
    expect(importCard).toMatch(/disabled=\{!aiProcessorEnabled\}/);
    expect(importCard).toMatch(/!processorDisclosureAcknowledged/);
    expect(importCard).toContain("processorDisclosureAcknowledged: true");
    expect(importCard).toMatch(/handleFileUpload[\s\S]*?setProcessorDisclosureAcknowledged\(false\)/);
  });

  it("does not mount document import or proposal controls in the Intake tab", () => {
    const tabMap = source.slice(source.indexOf("intake: <"), source.indexOf("contacts: <"));

    expect(tabMap).not.toContain("AiImportCard");
    expect(tabMap).not.toContain("AiImportsSection");
  });
});
