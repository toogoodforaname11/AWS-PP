import React from "react";
import { fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

vi.setConfig({ testTimeout: 45000 });

(globalThis as any).React = React;

vi.mock("sonner", () => ({
  toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }),
}));

const mocks = vi.hoisted(() => ({
  contacts: [] as any[],
  settings: { formFocusedIntake: false } as any,
}));

vi.mock("@/lib/trpc", () => {
  const queryDataFor = (key: string): any => {
    if (key === "contact.list") return mocks.contacts;
    if (key === "estate.get") return { id: "estate-1", revision: 1 };
    if (key === "settings.get") return mocks.settings;
    if (key === "contactTemplate.list") return [];
    return undefined;
  };
  const mutationFor = () => ({
    mutate: vi.fn(),
    mutateAsync: vi.fn(async () => ({ success: true })),
    isPending: false,
  });
  function utilsNode(): any {
    return new Proxy({} as any, {
      get(_target, prop: string) {
        if (["invalidate", "setData", "cancel"].includes(prop)) return () => undefined;
        return utilsNode();
      },
    });
  }
  function node(path: string[]): any {
    return new Proxy({} as any, {
      get(_target, prop: string) {
        if (prop === "useQuery") return () => ({ data: queryDataFor(path.join(".")), isLoading: false, error: null });
        if (prop === "useMutation") return () => mutationFor();
        if (prop === "useUtils") return () => utilsNode();
        return node([...path, prop]);
      },
    });
  }
  return { trpc: node([]) };
});

async function components() {
  const estateDetail = await import("./EstateDetail");
  const { TooltipProvider } = await import("@/components/ui/tooltip");
  return { ...estateDetail, TooltipProvider };
}

const FOREIGN_COMMITTEE_CONTACT = {
  id: "contact-1",
  estateId: "estate-1",
  name: "Alex Representative",
  role: "beneficiary",
  recipientType: "beneficiary",
  relationship: "other",
  isMinor: 0,
  isMentallyIncapable: 1,
  hasCommittee: 1,
  committeeType: "foreign_equivalent",
  committeeName: "Jordan Committee",
  committeeAddress: "100 Court Street",
  committeeJurisdiction: "Washington State",
};

beforeEach(() => {
  mocks.contacts = [{ ...FOREIGN_COMMITTEE_CONTACT }];
  mocks.settings = { formFocusedIntake: false };
  window.localStorage.clear();
  Object.defineProperty(globalThis, "ResizeObserver", {
    configurable: true,
    value: class {
      observe() {}
      unobserve() {}
      disconnect() {}
    },
  });
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
});

describe("Contact form-focused audit", () => {
  it("hides only the operational Appointing Jurisdiction field while preserving form-relevant committee facts", async () => {
    const { ContactFormFields, TooltipProvider } = await components();
    const contact = { ...FOREIGN_COMMITTEE_CONTACT };
    const { rerender } = render(
      <TooltipProvider>
        <ContactFormFields contact={contact} setContact={vi.fn()} allContacts={[]} formFocusedIntake={false} />
      </TooltipProvider>,
    );

    expect(screen.getByTestId("contact-form-fields").getAttribute("data-form-mode")).toBe("full");
    expect(screen.getByTestId("contact-appointing-jurisdiction-field")).toBeTruthy();
    expect(screen.getByText("Committee Name")).toBeTruthy();
    expect(screen.getByText("Committee Address")).toBeTruthy();
    expect(screen.getByText("Committee Type")).toBeTruthy();

    rerender(
      <TooltipProvider>
        <ContactFormFields contact={contact} setContact={vi.fn()} allContacts={[]} formFocusedIntake />
      </TooltipProvider>,
    );

    expect(screen.getByTestId("contact-form-fields").getAttribute("data-form-mode")).toBe("form-focused");
    expect(screen.queryByTestId("contact-appointing-jurisdiction-field")).toBeNull();
    expect(screen.getByText("Committee Name")).toBeTruthy();
    expect(screen.getByText("Committee Address")).toBeTruthy();
    expect(screen.getByText("Committee Type")).toBeTruthy();
  });

  it("applies the saved preference to both the Add and Edit Contact dialogs", async () => {
    mocks.settings = { formFocusedIntake: true };
    const { ContactsTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <ContactsTab estateId="estate-1" />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByRole("button", { name: "Add Contact" }));
    expect(screen.getByTestId("contact-form-fields").getAttribute("data-form-mode")).toBe("form-focused");

    fireEvent.keyDown(document, { key: "Escape" });
    await waitFor(() => expect(screen.queryByTestId("contact-form-fields")).toBeNull());

    fireEvent.click(screen.getByRole("button", { name: "Edit Alex Representative" }));
    expect(screen.getByTestId("contact-form-fields").getAttribute("data-form-mode")).toBe("form-focused");
    expect(screen.queryByTestId("contact-appointing-jurisdiction-field")).toBeNull();
    expect(screen.getByText("Committee Name")).toBeTruthy();
  });

  it("uses the wider structured dialog surface and keeps guidance compact until requested", async () => {
    const { ContactsTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <ContactsTab estateId="estate-1" />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByRole("button", { name: "Add Contact" }));
    const dialog = document.querySelector<HTMLElement>("[data-slot='dialog-content']");
    expect(dialog?.className).toContain("contact-dialog-content");
    expect(dialog?.className).toContain("sm:max-w-4xl");
    expect(dialog?.className).toContain("rounded-2xl");
    expect(dialog?.querySelector(".contact-dialog-header")).toBeTruthy();
    expect(dialog?.querySelector(".contact-dialog-scroll-area")).toBeTruthy();
    expect(dialog?.querySelector(".contact-dialog-footer")).toBeTruthy();
    expect(document.querySelector<HTMLElement>("[data-slot='dialog-overlay']")?.className).toContain("contact-dialog-overlay");

    fireEvent.click(dialog!.querySelector<HTMLElement>("[data-slot='popover-trigger']")!);
    const beneficiaryOption = screen.getByRole("menuitemcheckbox", { name: "Beneficiary" });
    expect(beneficiaryOption.className).toContain("rounded-lg");
    expect(beneficiaryOption.className).toContain("active:scale-[0.99]");

    const contactFields = screen.getByTestId("contact-form-fields");
    expect(contactFields.className).toContain("space-y-5");
    expect(contactFields.querySelector(".contact-form-section")).toBeTruthy();
    expect(screen.queryByText(/Confirm that the name, residential address, postal address/i)).toBeNull();

    const pgtGuidance = screen.getByRole("button", { name: "More information about PGT supplemental information" });
    expect(pgtGuidance.className).toContain("contact-info-tooltip-marker");
    expect(pgtGuidance.closest("label")?.textContent).toMatch(/PGT supplemental information reviewed/i);
    fireEvent.pointerMove(pgtGuidance, { pointerType: "mouse" });
    await waitFor(() => expect(screen.getAllByText(/Confirm that the name, residential address, postal address/i).length).toBeGreaterThan(0));
    expect(document.querySelector<HTMLElement>("[data-slot='tooltip-content']")?.className).toContain("rounded-xl");
  });

  it("flushes a closed Add Contact draft and restores it after a remount", async () => {
    const { ContactsTab, TooltipProvider, contactAddDraftKey } = await components();
    const view = render(
      <TooltipProvider>
        <ContactsTab estateId="estate-1" />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByRole("button", { name: "Add Contact" }));
    const nameInput = screen.getByTestId("contact-form-fields").querySelector<HTMLInputElement>("[data-slot='input']")!;
    fireEvent.change(nameInput, { target: { value: "Casey Recovery" } });
    expect(screen.getByTestId("contact-add-autosave-status").textContent).toMatch(/Automatic recovery is protecting this draft/i);

    fireEvent.keyDown(document, { key: "Escape" });
    await waitFor(() => expect(screen.queryByTestId("contact-form-fields")).toBeNull());
    const localDraft = JSON.parse(window.localStorage.getItem(`estate_draft_${contactAddDraftKey("estate-1")}`) || "{}");
    expect(localDraft.data.name).toBe("Casey Recovery");

    view.unmount();
    render(
      <TooltipProvider>
        <ContactsTab estateId="estate-1" />
      </TooltipProvider>,
    );
    fireEvent.click(screen.getByRole("button", { name: "Add Contact" }));
    await waitFor(() => expect(screen.getByTestId("contact-add-draft-recovery")).toBeTruthy());
    fireEvent.click(screen.getByRole("button", { name: "Restore" }));
    expect(screen.getByTestId("contact-form-fields").querySelector<HTMLInputElement>("[data-slot='input']")?.value).toBe("Casey Recovery");
  });

  it("keeps Add and Edit Contact recovery drafts scoped to the correct workflow", async () => {
    const { ContactsTab, TooltipProvider, contactEditDraftKey } = await components();
    const editDraft = { ...FOREIGN_COMMITTEE_CONTACT, name: "Alex Recovery" };
    window.localStorage.setItem(
      `estate_draft_${contactEditDraftKey("estate-1", "contact-1")}`,
      JSON.stringify({ data: editDraft, savedAt: Date.now() }),
    );
    render(
      <TooltipProvider>
        <ContactsTab estateId="estate-1" />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByRole("button", { name: "Edit Alex Representative" }));
    await waitFor(() => expect(screen.getByTestId("contact-edit-draft-recovery")).toBeTruthy());
    fireEvent.click(screen.getByRole("button", { name: "Restore" }));
    expect(screen.getByTestId("contact-form-fields").querySelector<HTMLInputElement>("[data-slot='input']")?.value).toBe("Alex Recovery");
    expect(window.localStorage.getItem(`estate_draft_${contactEditDraftKey("estate-1", "contact-1")}`)).toBeNull();
  });

  it("uses readable role labels on cards and in edit-dialog role chips", async () => {
    mocks.contacts = [
      {
        id: "client-reported-1",
        estateId: "estate-1",
        name: "Morgan Relative",
        role: "client_reported_person",
        executorStatus: "unknown",
      },
      {
        id: "executor-1",
        estateId: "estate-1",
        name: "Taylor Executor",
        role: "executor",
        executorStatus: "unknown",
      },
    ];
    const { ContactsTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <ContactsTab estateId="estate-1" />
      </TooltipProvider>,
    );

    expect(screen.getByText("Client-reported person")).toBeTruthy();
    expect(screen.queryByText("client_reported_person")).toBeNull();
    expect(screen.queryByText("unknown")).toBeNull();
    expect(screen.getAllByText("status not set")).toHaveLength(1);

    fireEvent.click(screen.getByRole("button", { name: "Edit Morgan Relative" }));
    const dialog = await screen.findByRole("dialog");
    expect(within(dialog).getByText("Client-reported person", { exact: true })).toBeTruthy();
    expect(within(dialog).queryByText("Client_reported_person", { exact: true })).toBeNull();
  });

  it("shows a client-reported person's actual relationship instead of the generic role", async () => {
    mocks.contacts = [
      {
        id: "client-reported-sibling",
        estateId: "estate-1",
        name: "Morgan Sibling",
        role: "client_reported_person",
        relationship: "sibling",
        executorStatus: "unknown",
      },
    ];
    const { ContactsTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <ContactsTab estateId="estate-1" />
      </TooltipProvider>
    );

    expect(screen.getByText("Sibling (client-reported)", { exact: true })).toBeTruthy();
    expect(screen.queryByText("Client-reported person", { exact: true })).toBeNull();

    fireEvent.click(screen.getByRole("button", { name: "Edit Morgan Sibling" }));
    const dialog = await screen.findByRole("dialog");
    expect(
      within(dialog).getByText("Sibling (client-reported)", { exact: true })
    ).toBeTruthy();
    expect(
      within(dialog).queryByText("Client-reported person", { exact: true })
    ).toBeNull();
  });

  it("shows a legacy client-reported relationship in the matching picker option", async () => {
    const { ContactFormFields, TooltipProvider } = await components();
    const contact = {
      ...FOREIGN_COMMITTEE_CONTACT,
      relationship: "second cousin",
    };
    const setContact = vi.fn();

    render(
      <TooltipProvider>
        <ContactFormFields
          contact={contact}
          setContact={setContact}
          allContacts={[]}
          formFocusedIntake={false}
        />
      </TooltipProvider>
    );

    expect(screen.getByText("Second Cousin", { exact: true })).toBeTruthy();
    expect(screen.queryByText("Select relationship")).toBeNull();
    expect(setContact).not.toHaveBeenCalled();
  });
});
