import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { FORM_CATALOG } from "@shared/types";

const { getLoginUrlAsync } = vi.hoisted(() => ({ getLoginUrlAsync: vi.fn() }));

vi.mock("@/const", () => ({ getLoginUrlAsync }));

import Landing from "./Landing";

describe("Landing sign-in recovery", () => {
  beforeEach(() => {
    vi.stubGlobal("IntersectionObserver", class {
      observe() {}
      unobserve() {}
      disconnect() {}
    });
  });

  afterEach(() => {
    getLoginUrlAsync.mockReset();
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
    window.history.replaceState({}, "", "/");
  });

  it("returns the user to a retryable sign-in action when the protected bootstrap fails", async () => {
    getLoginUrlAsync.mockRejectedValueOnce(new Error("temporary failure"));
    render(<Landing />);

    const signIn = screen.getByRole("button", { name: "Sign in" });
    fireEvent.click(signIn);

    await waitFor(() => expect(screen.getByRole("alert").textContent).toContain("We couldn’t start sign-in"));
    expect((signIn as HTMLButtonElement).disabled).toBe(false);
    expect(getLoginUrlAsync).toHaveBeenCalledTimes(1);
  });

  it("shows clear in-progress feedback while opening the secure identity provider", () => {
    getLoginUrlAsync.mockReturnValueOnce(new Promise(() => undefined));
    render(<Landing />);

    fireEvent.click(screen.getAllByRole("button", { name: "Get started" })[0]);

    const loadingActions = screen.getAllByRole("button", { name: /opening secure sign-in/i });
    expect(loadingActions).toHaveLength(3);
    expect(loadingActions.every((button) => (button as HTMLButtonElement).disabled)).toBe(true);
  });

  it("provides managed account-recovery guidance without presenting a local password reset", async () => {
    getLoginUrlAsync.mockRejectedValueOnce(new Error("temporary failure"));
    render(<Landing />);
    fireEvent.click(screen.getByRole("button", { name: "Sign in" }));

    await waitFor(() => screen.getByRole("button", { name: "Sign-in help" }));
    fireEvent.click(screen.getByRole("button", { name: "Sign-in help" }));

    expect(screen.getByRole("heading", { name: "Account recovery" })).toBeTruthy();
    expect(screen.getByText(/never stores passwords/i)).toBeTruthy();
    expect(screen.getByRole("link", { name: "Identity-provider account help" }).getAttribute("href")).toBe("https://help.manus.im");
  });

  it("shows a fresh retry action after a safely rejected expired OAuth callback", async () => {
    window.history.replaceState({}, "", "/?authError=oauth_expired");
    render(<Landing />);

    await waitFor(() => expect(screen.getByRole("alert").textContent).toContain("sign-in session expired"));
    expect(window.location.search).toBe("");
    expect(screen.getByRole("button", { name: "Try again" })).toBeTruthy();
    expect(getLoginUrlAsync).not.toHaveBeenCalled();
  });

  it("shows a clear retry action when the managed identity provider is temporarily unavailable", async () => {
    window.history.replaceState({}, "", "/?authError=oauth_unavailable");
    render(<Landing />);

    await waitFor(() => expect(screen.getByRole("alert").textContent).toContain("could not finish sign-in"));
    expect(window.location.search).toBe("");
    expect(screen.getByRole("button", { name: "Try again" })).toBeTruthy();
  });

  it("publishes a public BC probate overview and matching answer-ready FAQ metadata", () => {
    render(<Landing />);

    expect(screen.getByRole("heading", { name: /BC probate software for lawyers and personal executors/i })).toBeTruthy();
    expect(screen.getByRole("heading", { name: "A practical probate workspace" })).toBeTruthy();
    expect(screen.getByRole("heading", { name: "What can I configure in Settings?" })).toBeTruthy();
    expect(screen.getByRole("heading", { name: "What is the Executor Portal?" })).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Does ProbatePro provide legal advice?" }));
    expect(screen.getByText(/document-preparation and workflow tool/i)).toBeTruthy();
    expect(document.title).toBe("BC Probate Software for Lawyers & Executors | ProbatePro");
    expect(document.head.querySelector('meta[name="robots"]')?.getAttribute("content")).toBe("index, follow");

    const schema = document.head.querySelector('script[type="application/ld+json"][data-probatepro-seo="structured-data"]');
    expect(JSON.parse(schema?.textContent || "{}")).toMatchObject({
      "@context": "https://schema.org",
      "@graph": expect.arrayContaining([
        expect.objectContaining({ "@type": "SoftwareApplication", name: "ProbatePro" }),
        expect.objectContaining({ "@type": "FAQPage" }),
      ]),
    });
  });

  it("shows the supplied walkthrough in an accessible, low-bandwidth product frame", () => {
    const play = vi.spyOn(HTMLMediaElement.prototype, "play").mockResolvedValue(undefined);
    render(<Landing />);

    expect(document.querySelector(".landing-walkthrough-stage")).toBeTruthy();
    expect(screen.getByRole("heading", { name: "Product Demo Walkthrough" })).toBeTruthy();
    expect(screen.queryByText("02:54")).toBeNull();
    expect(screen.queryByText("Fictional sample estate")).toBeNull();

    const video = screen.getByLabelText("ProbatePro product walkthrough") as HTMLVideoElement;
    expect(video.controls).toBe(true);
    expect(video.playsInline).toBe(true);
    expect(video.getAttribute("preload")).toBe("metadata");
    expect(video.getAttribute("src")).toBe("/media/probatepro-walkthrough.mp4");
    expect(video.getAttribute("poster")).toBe("https://files.manuscdn.com/user_upload_by_module/session_file/310519663647848961/TbwxSmxxANQPXVEI.jpg");
    expect(video.querySelector('track[kind="captions"]')).toBeNull();
    expect(screen.queryByRole("link", { name: "Watch walkthrough" })).toBeNull();

    const playOverlay = screen.getByTestId("walkthrough-play-overlay");
    const playButton = screen.getByRole("button", { name: "Play product demo walkthrough" });
    expect(playOverlay.getAttribute("data-playing")).toBe("false");
    fireEvent.click(playButton);
    expect(play).toHaveBeenCalledTimes(1);

    fireEvent.play(video);
    expect(playOverlay.getAttribute("data-playing")).toBe("true");
    fireEvent.pause(video);
    expect(playOverlay.getAttribute("data-playing")).toBe("false");
  });

  it("presents the public answers as an accessible accordion with motion-safe content hooks", () => {
    render(<Landing />);

    const question = screen.getByRole("button", { name: "What can I configure in Settings?" });
    expect(question).toBeInstanceOf(HTMLButtonElement);
    expect(question.getAttribute("aria-expanded")).toBe("false");
    expect(question.className).toContain("landing-faq-trigger");

    fireEvent.click(question);

    expect(question.getAttribute("aria-expanded")).toBe("true");
    expect(document.querySelector("[data-state='open'] .landing-faq-content")).toBeTruthy();
    expect(document.querySelector("[data-state='open'] .landing-faq-answer")).toBeTruthy();

    fireEvent.click(question);
    expect(question.getAttribute("aria-expanded")).toBe("false");
  });

  it("describes the Executor Portal as a lawyer-reviewed client intake path", () => {
    render(<Landing />);

    fireEvent.click(screen.getByRole("button", { name: "What is the Executor Portal?" }));

    expect(screen.getByText(/secure estate-specific link to send to a client/i)).toBeTruthy();
    expect(screen.getByText(/selects and approves the individual facts to apply to the estate record/i)).toBeTruthy();
    expect(screen.queryByText(/limited, read-only estate access/i)).toBeNull();
  });

  it("keeps every supported non-core form in a collapsed, accessible public catalogue", () => {
    render(<Landing />);

    const conditionalForms = screen.getByRole("button", { name: /conditional forms.*auto-determined/i });
    expect(conditionalForms.getAttribute("aria-expanded")).toBe("false");
    expect(screen.queryByRole("region", { name: "Conditional forms" })).toBeNull();

    fireEvent.click(conditionalForms);

    expect(conditionalForms.getAttribute("aria-expanded")).toBe("true");
    const catalogue = screen.getByRole("region", { name: "Conditional forms" });
    for (const form of FORM_CATALOG.filter((form) => !["P1", "P2", "P9", "VSA532", "LETTER"].includes(form.code))) {
      expect(catalogue.textContent, form.code).toContain(form.name);
    }
    expect(catalogue.textContent).toContain("Affidavit of Translator");
  });

  it("places long-code form descriptions in the same catalogue text column", () => {
    render(<Landing />);
    fireEvent.click(screen.getByRole("button", { name: /conditional forms.*auto-determined/i }));

    const pgtDescription = screen.getByText("Minor or incapable notice recipient");
    const consentDescription = screen.getByText("Beneficiary nomination, prepared on demand");

    expect(pgtDescription.closest("[data-form-code='PGT information']")?.getAttribute("data-form-layout")).toBe("stacked");
    expect(consentDescription.closest("[data-form-code='CONSENT_NOMINATION']")?.getAttribute("data-form-layout")).toBe("stacked");
    expect(pgtDescription.getAttribute("data-form-description")).toBe("true");
    expect(consentDescription.getAttribute("data-form-description")).toBe("true");
  });

  it("gives the beneficiary-letter code enough room without entering its title", () => {
    render(<Landing />);

    const letter = screen.getByText("Letter to Beneficiaries (accompanies P1)");
    const row = letter.closest("[data-form-code='Letter']");

    expect(row?.className).toContain("grid-cols-[max-content_minmax(0,1fr)]");
  });
});
