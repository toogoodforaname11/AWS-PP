/**
 * Task 12: the preview's request lifecycle end to end — the exported FormPreviewModal inside the REAL trpc.Provider
 * and QueryClientProvider, the app's own links from createAppTrpcLinks, and a fetch stub at the network boundary that
 * serves a fictional mini-router through @trpc/server's fetch adapter (exact single, batch and error envelopes) and
 * can hold, re-stream, oversize or corrupt the preview's response. Fictional data only.
 */
import React, { useState } from "react";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { QueryClient, QueryClientProvider, focusManager, onlineManager } from "@tanstack/react-query";
import { initTRPC } from "@trpc/server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import superjson from "superjson";
import { trpc } from "@/lib/trpc";
import { createAppTrpcLinks } from "@/lib/trpcLinks";
import { browserResponse, chunkedStream, stalledStream } from "@/lib/browserResponse.testkit";
import { clearFallbackSession } from "@/lib/fallbackSession";
import { previewQueryKeyHash } from "@/lib/previewTransport";

/** The approved preview ceiling (P2): 4 MiB of decoded envelope bytes, written as a literal so this suite fails on behaviour. */
const PREVIEW_BODY_CEILING_BYTES = 4 * 1024 * 1024;

vi.setConfig({ testTimeout: 45000 });
(globalThis as any).React = React;

vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn(), loading: vi.fn(), dismiss: vi.fn() }) }));
import { toast } from "sonner";

const deliveryCalls = vi.hoisted(() => [] as Array<{ delivery: unknown; signal: unknown }>);
vi.mock("@/lib/attachmentDelivery", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@/lib/attachmentDelivery")>();
  return {
    ...actual,
    fetchDeliveryAttachment: vi.fn(async (delivery: unknown, signal?: AbortSignal) => { deliveryCalls.push({ delivery, signal }); return { kind: "failed", reason: "invalid" }; }),
  };
});

const pdf = vi.hoisted(() => {
  const log: unknown[][] = [];
  const record = (name: string) => (...args: unknown[]) => { log.push([name, ...args]); return undefined; };
  const doc = {
    internal: { pageSize: { getWidth: () => 612, getHeight: () => 792 } },
    addPage: record("addPage"), setFont: record("setFont"), setFontSize: record("setFontSize"), setDrawColor: record("setDrawColor"),
    line: record("line"), rect: record("rect"), text: record("text"), save: record("save"),
    splitTextToSize: (text: unknown) => { log.push(["splitTextToSize", text]); return String(text).split("\n"); },
  };
  return { log, doc };
});
vi.mock("jspdf", () => ({ jsPDF: vi.fn(() => pdf.doc) }));

const NEUTRAL = "The preview could not be loaded. Please try again.";
const TRANSPORT_UNAVAILABLE = "Server is temporarily unavailable. Please try again in a moment.";
const TRANSPORT_TIMEOUT = "The server took too long to respond. Please try again.";
const UNAUTHED = "Please login (10001)";
const encoder = new TextEncoder();
const SECTIONS_A = [{ type: "paragraph", text: "Fictional body A" }];
const SECTIONS_B = [{ type: "paragraph", text: "Fictional body B" }];

/* ───────────────────────── the fictional server ───────────────────────── */

type Recorded = { n: number; url: string; init: RequestInit; procedures: string[]; batch: boolean; inputs: unknown[]; signal?: AbortSignal };
type Transform = (response: Response, request: Recorded) => Response | Promise<Response>;

const server = {
  sections: SECTIONS_A as unknown[],
  /** Throws inside the preview procedure (a public tRPC error) when set. */
  previewError: null as null | { code: "BAD_REQUEST" | "UNAUTHORIZED"; message: string },
  generated: { id: "doc_1", delivery: { method: "POST", action: "/api/download/form", fields: { estateId: "e1", formCode: "P1", documentId: "doc_1" } }, format: "docx", filename: "P1.docx", documentName: "Fictional" },
  generateCalls: 0,
};

const t = initTRPC.create({ transformer: superjson });
const passthrough = (value: unknown) => value;
const router = t.router({
  document: t.router({
    preview: t.procedure.input(passthrough).query(({ input }) => {
      if (server.previewError) {
        const { TRPCError } = require("@trpc/server") as typeof import("@trpc/server");
        throw new TRPCError(server.previewError);
      }
      const { formCode } = input as { formCode: string };
      return { formCode, formName: `Fictional ${formCode}`, sections: server.sections };
    }),
    generate: t.procedure.input(passthrough).mutation(() => { server.generateCalls += 1; return server.generated; }),
  }),
  settings: t.router({ get: t.procedure.query(() => ({ lawyerName: "Fictional Lawyer" })) }),
});

const decodeInputs = (url: URL, batch: boolean): unknown[] => {
  const raw = url.searchParams.get("input");
  if (raw === null) return [];
  const parsed = JSON.parse(raw);
  return batch ? Object.keys(parsed).sort().map((k) => superjson.deserialize(parsed[k])) : [superjson.deserialize(parsed)];
};

function createNetwork({ honourAbort = true }: { honourAbort?: boolean } = {}) {
  const requests: Recorded[] = [];
  let transform: Transform = (response) => response;
  const fetchImpl = vi.fn((input: RequestInfo | URL, init?: RequestInit) => new Promise<Response>((resolve, reject) => {
    const url = new URL(String(input), "http://localhost");
    const batch = url.searchParams.get("batch") === "1";
    const request: Recorded = { n: requests.length + 1, url: String(input), init: init ?? {}, procedures: url.pathname.replace("/api/trpc/", "").split(","), batch, inputs: decodeInputs(url, batch), signal: init?.signal ?? undefined };
    requests.push(request);
    const signal = init?.signal;
    const aborted = () => reject(signal?.reason ?? new DOMException("The operation was aborted.", "AbortError"));
    if (honourAbort) {
      if (signal?.aborted) return aborted();
      signal?.addEventListener("abort", aborted, { once: true });
    }
    fetchRequestHandler({ endpoint: "/api/trpc", req: new Request(url, { method: init?.method ?? "GET", headers: init?.headers as HeadersInit, body: init?.body as BodyInit | undefined }), router, createContext: () => ({}) })
      .then((response) => transform(response, request))
      .then(resolve, reject);
  }));
  return {
    fetchImpl,
    requests,
    previews: () => requests.filter((r) => !r.batch && r.procedures[0] === "document.preview"),
    setTransform: (next: Transform) => { transform = next; },
    /** Holds the n-th preview response until released. */
    hold: (which: number) => {
      let release: (() => void) | undefined;
      const gate = new Promise<void>((resolve) => { release = resolve; });
      const previous = transform;
      transform = async (response, request) => {
        if (!request.batch && request.procedures[0] === "document.preview" && previewIndex(request) === which) { await gate; }
        return previous(response, request);
      };
      const previewIndex = (request: Recorded) => requests.filter((r) => !r.batch && r.procedures[0] === "document.preview" && r.n <= request.n).length;
      return () => release?.();
    },
  };
}

/** Re-streams a response body through the given stream factory, keeping status and content-type. */
const restream = (make: (bytes: Uint8Array) => ReadableStream<Uint8Array>): Transform => async (response) => {
  const bytes = new Uint8Array(await response.arrayBuffer());
  return browserResponse(make(bytes), { status: response.status, headers: { "content-type": response.headers.get("content-type") ?? "application/json" } });
};
const replaceBody = (body: string, status = 200, contentType = "application/json"): Transform => () =>
  browserResponse(body, { status, headers: { "content-type": contentType } });
const oversizeEnvelope = () => "{\"result\":{\"data\":{\"json\":{\"formCode\":\"P1\",\"formName\":\"FICTIONAL-BODY-MARKER\",\"sections\":[\"" + "x".repeat(PREVIEW_BODY_CEILING_BYTES) + "\"]}}}}";

/* ───────────────────────── the React harness ───────────────────────── */

type ModalProps = Record<string, unknown>;
const baseProps = (formCode = "P1"): ModalProps => ({ estateId: "e1", formCode, formName: `Fictional ${formCode}`, signatoryType: "executor", signatureDate: "2026-07-12", open: true, onOpenChange: () => {} });

let FormPreviewModal: any;
beforeAll(async () => {
  ({ FormPreviewModal } = await import("./EstateDetail"));
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => undefined, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => undefined, configurable: true });
  Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => undefined, configurable: true });
});

function Sibling() {
  const query = trpc.settings.get.useQuery();
  return <div data-testid="sibling">{query.data?.lawyerName ?? (query.isError ? "sibling-error" : "sibling-loading")}</div>;
}

type HarnessOptions = { honourAbort?: boolean; retryDelay?: number | "default"; transportDelay?: "zero" | "default"; sibling?: boolean };

function mountPreview(initial: ModalProps, options: HarnessOptions = {}) {
  const network = createNetwork({ honourAbort: options.honourAbort ?? true });
  const queryClient = new QueryClient({ defaultOptions: { queries: options.retryDelay === "default" ? {} : { retryDelay: options.retryDelay ?? 0 } } });
  // The exact subscriber main.tsx installs (main.tsx:24-30): the redirect replaced by a counter, the console line kept.
  const subscriber = { errorActions: 0, loginRedirects: 0 };
  queryClient.getQueryCache().subscribe((event) => {
    if (event.type === "updated" && event.action.type === "error") {
      subscriber.errorActions += 1;
      const error = event.query.state.error as { message?: string } | null;
      if (error?.message === UNAUTHED) subscriber.loginRedirects += 1;
      console.error("[API Query Error]", error);
    }
  });
  const trpcClient = trpc.createClient({ links: createAppTrpcLinks({ fetchImpl: network.fetchImpl, ...(options.transportDelay === "default" ? {} : { retryDelayMs: () => 0 }) }) });
  const tree = (props: ModalProps, extra: React.ReactNode = null) => (
    <trpc.Provider client={trpcClient} queryClient={queryClient}>
      <QueryClientProvider client={queryClient}>
        {options.sibling ? <Sibling /> : null}
        {extra}
        <FormPreviewModal {...props} />
      </QueryClientProvider>
    </trpc.Provider>
  );
  const utils = render(tree(initial));
  return {
    ...utils,
    network,
    queryClient,
    trpcClient,
    subscriber,
    setProps: (props: ModalProps) => utils.rerender(tree(props)),
    setTree: (props: ModalProps, extra: React.ReactNode) => utils.rerender(tree(props, extra)),
    close: (props: ModalProps) => utils.rerender(tree({ ...props, open: false })),
    previewKey: () => queryClient.getQueryCache().getAll().find((q) => (q.queryKey as unknown[])[0]?.toString() === "document,preview"),
  };
}

const markup = () => document.querySelector("div.space-y-2.font-serif.text-sm");
const alertText = () => screen.queryByRole("alert")?.textContent ?? null;
const controls = () => ({
  docx: screen.queryByTestId("preview-download-docx") !== null,
  print: screen.queryByRole("button", { name: "Print" }) !== null,
  pdf: screen.queryByRole("button", { name: "PDF" }) !== null,
  zoom: screen.queryByTitle("Zoom in") !== null,
});
const expectSections = async (text: string) => { await waitFor(() => expect(markup()?.textContent).toContain(text)); };
const expectAlert = async (sentence: string) => { await waitFor(() => expect(alertText()).toContain(sentence)); };
const previewData = (queryClient: QueryClient) => {
  const query = queryClient.getQueryCache().getAll().find((q) => String((q.queryKey as unknown[])[0]) === "document,preview");
  return query?.state.data as { sections?: unknown[] } | undefined;
};
const flush = () => act(async () => { await new Promise((resolve) => setTimeout(resolve, 0)); });

let consoleError: ReturnType<typeof vi.spyOn>;
beforeEach(() => {
  server.sections = SECTIONS_A;
  server.previewError = null;
  server.generateCalls = 0;
  deliveryCalls.length = 0;
  pdf.log.length = 0;
  sessionStorage.clear();
  onlineManager.setOnline(true);
  focusManager.setFocused(true);
  consoleError = vi.spyOn(console, "error").mockImplementation(() => undefined);
});
afterEach(() => {
  cleanup();
  vi.useRealTimers();
  consoleError.mockRestore();
  vi.restoreAllMocks();
  sessionStorage.clear();
});
const actWarnings = () => consoleError.mock.calls.filter((call) => String(call[0]).includes("not wrapped in act")).length;
const queryErrorLines = () => consoleError.mock.calls.filter((call) => String(call[0]).includes("[API Query Error]"));
/** Every own property at every depth, enumerable or not (message, stack, cause, data, meta, ...), as one string. */
const everyField = (value: unknown, seen = new Set<unknown>()): string => {
  if (!value || typeof value !== "object") return String(value);
  if (seen.has(value)) return "";
  seen.add(value);
  return Object.getOwnPropertyNames(value).map((key) => `${key}=${everyField((value as Record<string, unknown>)[key], seen)}`).join(" ");
};

/* ───────────────────────── supersession and close (R1–R4) ───────────────────────── */

describe("supersession and close", () => {
  it("R1: a slow preview A superseded by a fast preview B never replaces B's sections, shows no Alert, and its loading state belongs to B", async () => {
    const h = mountPreview(baseProps("P1"));
    const release = h.network.hold(1);
    await waitFor(() => expect(h.network.previews()).toHaveLength(1));
    server.sections = SECTIONS_B;
    h.setProps(baseProps("P2"));
    await expectSections("Fictional body B");
    release();
    await flush();
    expect(markup()?.textContent).toContain("Fictional body B");
    expect(markup()?.textContent).not.toContain("Fictional body A");
    expect(alertText()).toBeNull();
    expect(h.network.previews()[0].signal?.aborted).toBe(true);
    expect(h.subscriber.errorActions).toBe(0);
    expect(h.subscriber.loginRedirects).toBe(0);
  });

  it("R2: with a fetch that ignores abort, A's late success and late error still never reach B, the console or a redirect", async () => {
    const h = mountPreview(baseProps("P1"), { honourAbort: false });
    const release = h.network.hold(1);
    await waitFor(() => expect(h.network.previews()).toHaveLength(1));
    server.sections = SECTIONS_B;
    h.setProps(baseProps("P2"));
    await expectSections("Fictional body B");
    release();
    await flush();
    expect(markup()?.textContent).toContain("Fictional body B");
    expect(markup()?.textContent).not.toContain("Fictional body A");
    expect(h.subscriber.errorActions).toBe(0);
    expect(queryErrorLines()).toHaveLength(0);
  });

  it("R3: a close during the headers aborts the request; a same-input reopen (plain P1) sends a fresh request and renders", async () => {
    const h = mountPreview(baseProps("P1"));
    const release = h.network.hold(1);
    await waitFor(() => expect(h.network.previews()).toHaveLength(1));
    h.close(baseProps("P1"));
    await waitFor(() => expect(h.network.previews()[0].signal?.aborted).toBe(true));
    release();
    h.setProps(baseProps("P1"));
    await waitFor(() => expect(h.network.previews()).toHaveLength(2));
    await expectSections("Fictional body A");
    expect(h.subscriber.errorActions).toBe(0);
  });

  it("R3: a close during the body cancels the reader; a same-key reopen with cached data shows it at once and a close during the refetch keeps it", async () => {
    const h = mountPreview(baseProps("P1"));
    await expectSections("Fictional body A");
    let bodyCancelled = 0;
    h.network.setTransform(restream((bytes) => stalledStream(bytes.subarray(0, 8), () => { bodyCancelled += 1; })));
    h.close(baseProps("P1"));
    await flush();
    h.setProps(baseProps("P1"));
    expect(markup()?.textContent).toContain("Fictional body A");
    await waitFor(() => expect(h.network.previews()).toHaveLength(2));
    h.close(baseProps("P1"));
    await waitFor(() => expect(bodyCancelled).toBe(1));
    expect(previewData(h.queryClient)?.sections).toEqual(SECTIONS_A);
    expect(h.subscriber.errorActions).toBe(0);
  });

  it("R3b: a malformed payload rejects whole into the frozen Alert with Retry and is never cached; empty drafts still render", async () => {
    server.sections = [null];
    const h = mountPreview(baseProps("P1"));
    await expectAlert(NEUTRAL);
    expect(markup()).toBeNull();
    expect(controls()).toEqual({ docx: false, print: false, pdf: false, zoom: false });
    expect(previewData(h.queryClient)).toBeUndefined();
    expect(h.network.previews()).toHaveLength(1);
    expect(h.subscriber.errorActions).toBe(1);
    let expected = 1;
    for (const shape of [
      [{ type: "bogus", text: "x" }], [{ type: "paragraph", text: {} }], [{ type: "letter_recipient_block", recipientLines: "x" }],
      [{ type: "table", rows: [{ cells: "x" }] }], [{ type: "table", rows: [{ cells: [{}] }] }], [{ type: "table", rows: [{ cells: ["a"], colSpans: "2" }] }],
      [{ type: "paragraph", text: "x", bold: 1 }],
    ]) {
      server.sections = shape;
      fireEvent.click(screen.getByRole("button", { name: "Retry preview" }));
      expected += 1;
      // Each Retry sends exactly one request whose malformed answer is rejected once (terminal: no React Query retry).
      await waitFor(() => expect(h.subscriber.errorActions).toBe(expected));
      await flush();
      expect(h.network.previews()).toHaveLength(expected);
      expect(alertText()).toContain(NEUTRAL);
      expect(markup()).toBeNull();
      expect(previewData(h.queryClient)).toBeUndefined();
    }
    server.sections = [];
    fireEvent.click(screen.getByRole("button", { name: "Retry preview" }));
    await waitFor(() => expect(markup()).not.toBeNull());
    expect(h.network.previews()).toHaveLength(expected + 1);
    expect(screen.queryByText("Unable to load preview.")).toBeNull();
    expect(controls().docx).toBe(true);
    expect(document.body.textContent).not.toContain("Unexpected");
  });

  it("R3c: a reopen after gcTime with the same input sends exactly one fresh request without throwing", async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
    const h = mountPreview(baseProps("P1"));
    // Testing Library's waitFor polls inside React's act environment; vi.waitFor does not, and the resolving query
    // would then update state outside act and be counted below.
    await waitFor(() => expect(markup()?.textContent).toContain("Fictional body A"));
    h.close(baseProps("P1"));
    await act(async () => { await vi.advanceTimersByTimeAsync(5 * 60 * 1000 + 1000); });
    expect(h.previewKey()).toBeUndefined();
    h.setProps(baseProps("P1"));
    await waitFor(() => expect(h.network.previews()).toHaveLength(2));
    await waitFor(() => expect(markup()?.textContent).toContain("Fictional body A"));
    expect(actWarnings()).toBe(0);
  });

  it("R3d: a window-focus event while closed triggers no fetch", async () => {
    const h = mountPreview(baseProps("P1"));
    await expectSections("Fictional body A");
    h.close(baseProps("P1"));
    await flush();
    act(() => { focusManager.setFocused(false); focusManager.setFocused(true); });
    await flush();
    expect(h.network.previews()).toHaveLength(1);
    expect(actWarnings()).toBe(0);
  });

  it("R4: an unmount during the headers and during the body aborts without state writes or act warnings", async () => {
    const first = mountPreview(baseProps("P1"));
    const release = first.network.hold(1);
    await waitFor(() => expect(first.network.previews()).toHaveLength(1));
    first.unmount();
    await waitFor(() => expect(first.network.previews()[0].signal?.aborted).toBe(true));
    release();
    await flush();
    expect(first.subscriber.errorActions).toBe(0);
    cleanup();
    let cancelled = 0;
    const second = mountPreview(baseProps("P1"));
    second.network.setTransform(restream((bytes) => stalledStream(bytes.subarray(0, 8), () => { cancelled += 1; })));
    second.setProps(baseProps("P2"));
    await waitFor(() => expect(second.network.previews()).toHaveLength(2));
    second.unmount();
    await waitFor(() => expect(cancelled).toBe(1));
    expect(second.subscriber.errorActions).toBe(0);
    expect(actWarnings()).toBe(0);
  });
});

/* ───────────────────────── inputs, siblings, refusals (R5–R10) ───────────────────────── */

describe("render inputs and siblings", () => {
  it("R5: every render input change cancels the pending request and sends the new exact input, never resetting the user's choice", async () => {
    const h = mountPreview({ ...baseProps("P17"), p17AddressCity: "Victoria", p17AddressProvince: "BC" });
    await expectSections("Fictional body A");
    const steps: Array<[ModalProps, (input: any) => void]> = [
      [{ ...baseProps("P17"), p17AddressCity: "Victoria", p17AddressProvince: "BC", selectedContactId: "c1" }, (i) => expect(i.selectedContactId).toBe("c1")],
      [{ ...baseProps("P17"), p17AddressCity: "Victoria", p17AddressProvince: "BC", selectedContactId: "c1", deponentId: "d1" }, (i) => expect(i.deponentId).toBe("d1")],
      [{ ...baseProps("P17"), p17AddressCity: "Victoria", p17AddressProvince: "BC", selectedContactId: "c1", deponentId: "d1", affidavitOrdinal: "2nd" }, (i) => expect(i.affidavitOrdinal).toBe("2nd")],
      [{ ...baseProps("P17"), p17AddressCity: "Victoria", p17AddressProvince: "BC", selectedContactId: "c1", deponentId: "d1", affidavitOrdinal: "2nd", signatureDate: "2026-07-13" }, (i) => expect(i.signatureDate).toBe("2026-07-13")],
      [{ ...baseProps("P17"), p17AddressCity: "Victoria", p17AddressProvince: "BC", consentNomination: { nomineeContactId: "n1", relationshipToNominee: "child", beneficiarySharePercentage: 50 } }, (i) => expect(i.consentNomination).toEqual({ nomineeContactId: "n1", relationshipToNominee: "child", beneficiarySharePercentage: 50 })],
      [{ ...baseProps("P17"), p17AddressCity: "Victoria", p17AddressProvince: "BC", overrides: { willRevoked: true } }, (i) => expect(i.overrides).toMatchObject({ willRevoked: true })],
      [{ ...baseProps("P17"), p17AddressCity: "Victoria", p17AddressProvince: "BC", generateAnyway: true }, (i) => expect(i.generateAnyway).toBe(true)],
    ];
    // Each change lands while the previous step's request is still held, so it must abort that request.
    let releasePrevious: (() => void) | undefined;
    for (const [props, check] of steps) {
      const before = h.network.previews().length;
      const release = h.network.hold(before + 1);
      h.setProps(props);
      await waitFor(() => expect(h.network.previews()).toHaveLength(before + 1));
      check(h.network.previews()[before].inputs[0]);
      if (releasePrevious) {
        expect(h.network.previews()[before - 1].signal?.aborted).toBe(true);
        releasePrevious();
      }
      releasePrevious = release;
    }
    releasePrevious?.();
    await expectSections("Fictional body A");
    expect(h.subscriber.errorActions).toBe(0);
    // P17 keystrokes re-key the query through the overrides: each keystroke supersedes the held request and never resets the draft.
    fireEvent.click(screen.getByTestId("p17-preview-edit-address"));
    const city = screen.getByTestId("p17-preview-address-city") as HTMLInputElement;
    const before = h.network.previews().length;
    const releaseFirst = h.network.hold(before + 1);
    fireEvent.change(city, { target: { value: "Nanaim" } });
    await waitFor(() => expect(h.network.previews()).toHaveLength(before + 1));
    const releaseSecond = h.network.hold(before + 2);
    fireEvent.change(city, { target: { value: "Nanaimo" } });
    await waitFor(() => expect(h.network.previews()).toHaveLength(before + 2));
    expect(h.network.previews()[before].signal?.aborted).toBe(true);
    expect(city.value).toBe("Nanaimo");
    releaseFirst();
    releaseSecond();
    await expectSections("Fictional body A");
    const last = h.network.previews().at(-1)!.inputs[0] as { overrides?: Record<string, unknown> };
    expect(last.overrides?.addressCity).toBe("Nanaimo");
  });

  it("R6 (observed): the P17 reopen sequence — any pre-reset request is cancelled, and the final request carries the current drafts", async () => {
    const h = mountPreview({ ...baseProps("P17"), p17AddressCity: "Victoria", p17AddressProvince: "BC" });
    await expectSections("Fictional body A");
    fireEvent.click(screen.getByTestId("p17-preview-edit-address"));
    fireEvent.change(screen.getByTestId("p17-preview-address-city"), { target: { value: "Nanaimo" } });
    await expectSections("Fictional body A");
    h.close({ ...baseProps("P17"), p17AddressCity: "Victoria", p17AddressProvince: "BC" });
    await flush();
    const before = h.network.previews().length;
    h.setProps({ ...baseProps("P17"), p17AddressCity: "Victoria", p17AddressProvince: "BC" });
    await waitFor(() => expect(h.network.previews().length).toBeGreaterThan(before));
    await expectSections("Fictional body A");
    const sequence = h.network.previews().slice(before);
    const superseded = sequence.slice(0, -1);
    for (const request of superseded) expect(request.signal?.aborted).toBe(true);
    const final = sequence.at(-1)!.inputs[0] as { overrides?: Record<string, unknown> };
    expect(final.overrides?.addressCity ?? "Victoria").toBe("Victoria");
    expect(h.subscriber.errorActions).toBe(0);
  });

  it("R7: a sibling query issued in the same tick survives both the preview's cancel and the preview's cap refusal", async () => {
    const h = mountPreview(baseProps("P1"), { sibling: true });
    const release = h.network.hold(1);
    await waitFor(() => expect(h.network.requests.length).toBeGreaterThanOrEqual(2));
    h.close(baseProps("P1"));
    release();
    await waitFor(() => expect(screen.getByTestId("sibling").textContent).toBe("Fictional Lawyer"));
    cleanup();
    const g = mountPreview(baseProps("P1"), { sibling: true });
    g.network.setTransform((response, request) => request.batch ? response : replaceBody(oversizeEnvelope())(response, request));
    await expectAlert(NEUTRAL);
    await waitFor(() => expect(screen.getByTestId("sibling").textContent).toBe("Fictional Lawyer"));
    expect(server.generateCalls).toBe(0);
  });

  it("R8: a ceiling refusal shows the neutral sentence once with no retry; Retry sends a new request; a BAD_REQUEST envelope shows its public sentence and is retried per default", async () => {
    sessionStorage.setItem("manus-cookie", "app_session_id=fictional-token-r8");
    const h = mountPreview(baseProps("P1"));
    h.network.setTransform(replaceBody(oversizeEnvelope()));
    await expectAlert(NEUTRAL);
    await flush();
    expect(h.network.previews()).toHaveLength(1);
    expect(h.subscriber.errorActions).toBe(1);
    // P11: the one logged line carries the neutral sentence and nothing from the body, the headers or the token; no meta on a refusal.
    expect(new Headers(h.network.previews()[0].init.headers as HeadersInit).get("authorization")).toContain("fictional-token-r8");
    expect(queryErrorLines()).toHaveLength(1);
    const logged = queryErrorLines()[0][1] as { meta?: unknown };
    expect(logged.meta).toBeUndefined();
    const fields = everyField(logged);
    expect(fields).toContain(NEUTRAL);
    expect(fields).not.toContain("FICTIONAL-BODY-MARKER");
    expect(fields).not.toContain("fictional-token-r8");
    h.network.setTransform((response) => response);
    fireEvent.click(screen.getByRole("button", { name: "Retry preview" }));
    await expectSections("Fictional body A");
    expect(h.network.previews()).toHaveLength(2);
    server.previewError = { code: "BAD_REQUEST", message: "Choose the executor who signs this affidavit." };
    fireEvent.click(screen.getByRole("button", { name: "Zoom in" }));
    h.setProps(baseProps("P3"));
    await expectAlert("Choose the executor who signs this affidavit.");
    await waitFor(() => expect(h.network.previews().filter((r) => (r.inputs[0] as { formCode: string }).formCode === "P3")).toHaveLength(4));
  });

  it("R8a: a close during a Retry-after-refusal reverts silently to the previous error, with no second error line, and the reopen refetches", async () => {
    const h = mountPreview(baseProps("P1"));
    h.network.setTransform(replaceBody(oversizeEnvelope()));
    await expectAlert(NEUTRAL);
    await flush();
    const release = h.network.hold(2);
    h.network.setTransform((response) => response);
    fireEvent.click(screen.getByRole("button", { name: "Retry preview" }));
    await waitFor(() => expect(h.network.previews()).toHaveLength(2));
    h.close(baseProps("P1"));
    await flush();
    release();
    await flush();
    expect(h.subscriber.errorActions).toBe(1);
    // The ceiling refusal logged one line; the reverted Retry adds none.
    expect(queryErrorLines()).toHaveLength(1);
    h.setProps(baseProps("P1"));
    await waitFor(() => expect(h.network.previews()).toHaveLength(3));
    await expectSections("Fictional body A");
  });

  it("R8b: a network failure on every transport attempt becomes the transport's own sentence after React Query's default retries", async () => {
    const h = mountPreview(baseProps("P1"));
    h.network.fetchImpl.mockImplementation(() => Promise.reject(new TypeError("Failed to fetch")));
    await expectAlert(TRANSPORT_UNAVAILABLE);
    await waitFor(() => expect(h.network.fetchImpl).toHaveBeenCalledTimes(12));
  });

  it("R9: truncated JSON, a non-JSON 200, non-tRPC JSON and a wrong MIME all show only the neutral sentence; the HTML page is never read", async () => {
    const h = mountPreview(baseProps("P1"));
    await expectSections("Fictional body A");
    let htmlPulls = 0;
    const cases: Array<[string, Transform]> = [
      ["truncated", replaceBody("{\"result\":{\"data\":{\"json\":{\"sections\":[{\"type\":\"para")],
      ["html", () => browserResponse(new ReadableStream<Uint8Array>({ pull(c) { htmlPulls += 1; c.enqueue(encoder.encode("<html>login</html>")); c.close(); } }, { highWaterMark: 0 }), { status: 200, headers: { "content-type": "text/html" } })],
      ["non-trpc json", replaceBody("{\"error\":\"Too many requests, please slow down.\"}")],
      ["wrong mime", replaceBody("{\"result\":{\"data\":{\"json\":{\"sections\":[]}}}}", 200, "text/plain")],
    ];
    let formIndex = 2;
    for (const [, transform] of cases) {
      h.network.setTransform(transform);
      h.setProps(baseProps(`P${formIndex++}`));
      await expectAlert(NEUTRAL);
      expect(document.body.textContent).not.toMatch(/Unexpected|Unable to transform|SyntaxError|JSON at position/);
    }
    expect(htmlPulls).toBe(0);
  });

  it("R10: a valid empty draft renders the markup path, not the fallback text", async () => {
    server.sections = [];
    mountPreview(baseProps("P1"));
    await waitFor(() => expect(markup()).not.toBeNull());
    expect(screen.queryByText("Unable to load preview.")).toBeNull();
    expect(controls().docx).toBe(true);
  });
});

/* ───────────────────────── backoff, session, downloads (R11–R15, R17) ───────────────────────── */

describe("backoff, session and downloads", () => {
  it("R11: a close before dispatch, during the React Query backoff after a server error, and after completion never sends a further request", async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
    const h = mountPreview({ ...baseProps("P1"), open: false }, { retryDelay: "default" });
    await vi.advanceTimersByTimeAsync(50);
    expect(h.network.previews()).toHaveLength(0);
    server.previewError = { code: "BAD_REQUEST", message: "Choose the executor who signs this affidavit." };
    h.setProps(baseProps("P1"));
    await vi.waitFor(() => expect(h.network.previews()).toHaveLength(1));
    await vi.advanceTimersByTimeAsync(200);
    h.close(baseProps("P1"));
    await vi.advanceTimersByTimeAsync(10_000);
    expect(h.network.previews()).toHaveLength(1);
    expect(h.subscriber.errorActions).toBe(0);
    server.previewError = null;
    h.setProps(baseProps("P1"));
    await vi.waitFor(() => expect(markup()?.textContent).toContain("Fictional body A"));
    const after = h.network.previews().length;
    h.close(baseProps("P1"));
    await vi.advanceTimersByTimeAsync(1000);
    expect(h.network.previews()).toHaveLength(after);
  });

  it("R12: cookie mode sends no Authorization, Bearer mode sends it; a logout mid-body suppresses the old session's sections without a toast", async () => {
    const h = mountPreview(baseProps("P1"));
    await expectSections("Fictional body A");
    expect(new Headers(h.network.previews()[0].init.headers as HeadersInit).get("authorization")).toBeNull();
    sessionStorage.setItem("manus-cookie", "app_session_id=fictional-token");
    h.setProps(baseProps("P2"));
    await waitFor(() => expect(h.network.previews()).toHaveLength(2));
    expect(new Headers(h.network.previews()[1].init.headers as HeadersInit).get("authorization")).toBe("Bearer fictional-token");
    await expectSections("Fictional body A");
    // A sign-out lands once, while the old session's body is streaming: that body is dropped unread (cancelled), the
    // partition re-keys the query, and only a fresh request under the current identity can render.
    let cancelled = 0;
    let oldSessionResponses = 0;
    const oldSession = encoder.encode("{\"result\":{\"data\":{\"json\":{\"formCode\":\"P3\",\"formName\":\"x\",\"sections\":[{\"type\":\"paragraph\",\"text\":\"Fictional OLD SESSION body\"}]}}}}");
    server.sections = SECTIONS_B;
    h.network.setTransform((response) => {
      if (oldSessionResponses > 0) return response;
      oldSessionResponses += 1;
      let pulls = 0;
      return browserResponse(new ReadableStream<Uint8Array>({
        pull(c) { pulls += 1; if (pulls === 1) { clearFallbackSession(); c.enqueue(oldSession.subarray(0, 8)); } else { c.enqueue(oldSession.subarray(8)); c.close(); } },
        cancel() { cancelled += 1; },
      }, { highWaterMark: 0 }), { status: 200, headers: { "content-type": "application/json" } });
    });
    h.setProps(baseProps("P3"));
    await expectSections("Fictional body B");
    expect(document.body.textContent).not.toContain("OLD SESSION");
    expect(cancelled).toBe(1);
    expect(h.network.previews().filter((r) => (r.inputs[0] as { formCode: string }).formCode === "P3")).toHaveLength(2);
    expect(toast.error).not.toHaveBeenCalled();
    expect(h.subscriber.loginRedirects).toBe(0);
    for (const query of h.queryClient.getQueryCache().getAll()) expect(JSON.stringify(query.state.data ?? null)).not.toContain("OLD SESSION");
    // A rotation mid-body changes nothing.
    h.network.setTransform(restream((bytes) => new ReadableStream<Uint8Array>({
      pull(c) { sessionStorage.setItem("manus-cookie", "app_session_id=rotated"); c.enqueue(bytes); c.close(); },
    }, { highWaterMark: 0 })));
    h.setProps(baseProps("P4"));
    await expectSections("Fictional body B");
  });

  it("R13: a cancelled preview never calls document.generate", async () => {
    const h = mountPreview(baseProps("P1"));
    const release = h.network.hold(1);
    await waitFor(() => expect(h.network.previews()).toHaveLength(1));
    h.close(baseProps("P1"));
    release();
    await flush();
    expect(server.generateCalls).toBe(0);
    expect(deliveryCalls).toHaveLength(0);
  });

  it("R14: the frozen behaviours are unchanged under the real provider — two P11 signature lines, merged multiline rows in modal, print and PDF, the controls, and the DOCX handoff without a signal", async () => {
    server.sections = [
      { type: "signature", text: "SWORN (OR AFFIRMED) BEFORE ME", suppressRule: true },
      { type: "paragraph", text: "________________________________" },
      { type: "paragraph", text: "Commissioner" },
      { type: "paragraph", text: "________________________________" },
    ];
    const h = mountPreview(baseProps("P11"));
    await waitFor(() => expect(screen.getAllByText("________________________________")).toHaveLength(2));
    const instruction = "List item details and then list secured debt details below those items.";
    server.sections = [{
      type: "table",
      rows: [
        { cells: ["Part I\nReal Property within British Columbia", "Value at Death"], header: true, colSpans: [2, 1], cellAligns: ["left", "center"] },
        { cells: [instruction, ""], italic: true, colSpans: [2, 1], cellAligns: ["left", "center"] },
        { cells: ["Asset details\nLess: secured debt", "$10,000.00\n− $2,000.00", "$8,000.00"], cellAligns: ["left", "center", "center"] },
      ],
    }];
    h.setProps({ ...baseProps("P11"), signatureDate: "2026-07-13" });
    const detailCell = await screen.findByText((_, element) => element?.tagName === "TD" && element.textContent === "Asset details\nLess: secured debt");
    expect(detailCell.className).toContain("whitespace-pre-line");
    const partCell = screen.getByText((_, element) => element?.tagName === "TD" && element.textContent === "Part I\nReal Property within British Columbia") as HTMLTableCellElement;
    expect(partCell.colSpan).toBe(2);
    const printDocument = document.implementation.createHTMLDocument("");
    vi.spyOn(window, "open").mockReturnValue({ document: printDocument, print: vi.fn(), opener: window } as any);
    fireEvent.click(screen.getByRole("button", { name: "Print" }));
    const printHtml = printDocument.documentElement.outerHTML;
    expect(printHtml).toContain("white-space: pre-line");
    expect(printHtml).toContain("colspan=\"2\"");
    expect(printHtml).toContain(instruction);
    fireEvent.click(screen.getByRole("button", { name: "PDF" }));
    await waitFor(() => expect(pdf.log.some((call) => call[0] === "save")).toBe(true));
    expect(pdf.log.some((call) => call[0] === "rect")).toBe(true);
    expect(controls()).toEqual({ docx: true, print: true, pdf: true, zoom: true });
    fireEvent.click(screen.getByTestId("preview-download-docx"));
    await waitFor(() => expect(deliveryCalls).toHaveLength(1));
    expect(deliveryCalls[0].signal).toBeUndefined();
    expect(server.generateCalls).toBe(1);
  });

  it("R15: the preview path creates and revokes no Object URL", async () => {
    const created = vi.fn(() => "blob:fictional");
    const revoked = vi.fn();
    Object.defineProperty(URL, "createObjectURL", { configurable: true, writable: true, value: created });
    Object.defineProperty(URL, "revokeObjectURL", { configurable: true, writable: true, value: revoked });
    try {
      const h = mountPreview(baseProps("P1"));
      await expectSections("Fictional body A");
      h.setProps(baseProps("P2"));
      await expectSections("Fictional body A");
      h.close(baseProps("P2"));
      await flush();
      expect(created).not.toHaveBeenCalled();
      expect(revoked).not.toHaveBeenCalled();
    } finally {
      delete (URL as any).createObjectURL;
      delete (URL as any).revokeObjectURL;
    }
  });

  it("R17 (observed): a server that never answers reaches the Alert after 12 attempts and about 145 s", async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
    const h = mountPreview(baseProps("P1"), { retryDelay: "default", transportDelay: "default" });
    h.network.fetchImpl.mockImplementation((_input: RequestInfo | URL, init?: RequestInit) => new Promise<Response>((_resolve, reject) => {
      init?.signal?.addEventListener("abort", () => reject(init.signal!.reason ?? new DOMException("Timed out", "AbortError")), { once: true });
    }));
    const started = Date.now();
    for (let step = 0; step < 80 && !(alertText() ?? "").includes(TRANSPORT_TIMEOUT); step++) {
      await act(async () => { await vi.advanceTimersByTimeAsync(2_500); });
    }
    const elapsed = Date.now() - started;
    expect(alertText()).toContain(TRANSPORT_TIMEOUT);
    expect(h.network.fetchImpl).toHaveBeenCalledTimes(12);
    expect(elapsed).toBeGreaterThanOrEqual(140_000);
    expect(elapsed).toBeLessThan(160_000);
  }, 120_000);
});

/* ───────────────────────── offline, session partition, cache correctness (R18–R21) ───────────────────────── */

describe("offline, session partition and cache correctness", () => {
  it("R18a: opened offline, the first attempt runs and pauses; a close cancels it; reconnect resumes nothing; a reopen fetches fresh", async () => {
    onlineManager.setOnline(false);
    const h = mountPreview(baseProps("P1"));
    h.network.fetchImpl.mockImplementation(() => Promise.reject(new TypeError("Failed to fetch")));
    await waitFor(() => expect(h.network.fetchImpl).toHaveBeenCalledTimes(3));
    await waitFor(() => expect(h.previewKey()?.state.fetchStatus).toBe("paused"));
    h.close(baseProps("P1"));
    await flush();
    expect(h.previewKey()?.state.fetchStatus).toBe("idle");
    h.network.fetchImpl.mockRestore?.();
    const calls = h.network.fetchImpl.mock.calls.length;
    act(() => { onlineManager.setOnline(true); });
    await flush();
    expect(h.network.fetchImpl.mock.calls.length).toBe(calls);
    h.setProps(baseProps("P1"));
    await waitFor(() => expect(h.network.fetchImpl.mock.calls.length).toBeGreaterThan(calls));
  });

  it("R18b: a preview still open when the tab is back online and focused resumes and renders; online but unfocused stays paused", async () => {
    onlineManager.setOnline(false);
    const h = mountPreview(baseProps("P1"));
    const real = h.network.fetchImpl.getMockImplementation();
    h.network.fetchImpl.mockImplementation(() => Promise.reject(new TypeError("Failed to fetch")));
    await waitFor(() => expect(h.previewKey()?.state.fetchStatus).toBe("paused"));
    h.network.fetchImpl.mockImplementation(real!);
    act(() => { focusManager.setFocused(false); onlineManager.setOnline(true); });
    await flush();
    expect(h.previewKey()?.state.fetchStatus).toBe("paused");
    act(() => { focusManager.setFocused(true); });
    await expectSections("Fictional body A");
  });

  it("R18c: a sibling query paused offline resumes after the preview's close; R18e: a second observer keeps the query alive", async () => {
    onlineManager.setOnline(false);
    const h = mountPreview(baseProps("P1"), { sibling: true });
    const real = h.network.fetchImpl.getMockImplementation();
    h.network.fetchImpl.mockImplementation(() => Promise.reject(new TypeError("Failed to fetch")));
    await waitFor(() => expect(h.previewKey()?.state.fetchStatus).toBe("paused"));
    h.close(baseProps("P1"));
    h.network.fetchImpl.mockImplementation(real!);
    act(() => { onlineManager.setOnline(true); });
    await waitFor(() => expect(screen.getByTestId("sibling").textContent).toBe("Fictional Lawyer"));
    cleanup();
    // A second observer of the exact same query (same input, same generation-partitioned hash) keeps it alive.
    function Twin() {
      trpc.document.preview.useQuery(
        { estateId: "e1", formCode: "P1", formName: undefined, signatoryType: "executor", signatureDate: "2026-07-12" } as never,
        { networkMode: "offlineFirst", queryKeyHashFn: previewQueryKeyHash } as never,
      );
      return null;
    }
    const g = mountPreview(baseProps("P1"));
    const release = g.network.hold(1);
    await waitFor(() => expect(g.network.previews()).toHaveLength(1));
    g.setTree(baseProps("P1"), <Twin />);
    await flush();
    expect(g.queryClient.getQueryCache().getAll().filter((q) => String((q.queryKey as unknown[])[0]) === "document,preview")).toHaveLength(1);
    g.setTree({ ...baseProps("P1"), open: false }, <Twin />);
    await flush();
    expect(g.network.previews()[0].signal?.aborted).toBe(false);
    release();
    await waitFor(() => expect(g.previewKey()?.state.status).toBe("success"));
  });

  it("R19: a session end makes cached sections unreachable at the next render; a token rotation keeps them", async () => {
    const h = mountPreview(baseProps("P1"));
    await expectSections("Fictional body A");
    h.close(baseProps("P1"));
    await flush();
    server.sections = SECTIONS_B;
    clearFallbackSession();
    h.setProps(baseProps("P1"));
    expect(markup()?.textContent ?? "").not.toContain("Fictional body A");
    await expectSections("Fictional body B");
    expect(h.network.previews()).toHaveLength(2);
    h.close(baseProps("P1"));
    await flush();
    sessionStorage.setItem("manus-cookie", "app_session_id=rotated");
    server.sections = SECTIONS_A;
    h.setProps(baseProps("P1"));
    expect(markup()?.textContent).toContain("Fictional body B");
    await waitFor(() => expect(h.network.previews()).toHaveLength(3));
  });

  it("R20: a malformed same-key refetch leaves the valid payload in the cache, hides every preview-dependent control, and a valid Retry restores both", async () => {
    const h = mountPreview(baseProps("P1"));
    await expectSections("Fictional body A");
    expect(controls()).toEqual({ docx: true, print: true, pdf: true, zoom: true });
    server.sections = [null];
    act(() => { focusManager.setFocused(false); focusManager.setFocused(true); });
    await expectAlert(NEUTRAL);
    expect(previewData(h.queryClient)?.sections).toEqual(SECTIONS_A);
    expect(markup()).toBeNull();
    expect(controls()).toEqual({ docx: false, print: false, pdf: false, zoom: false });
    server.sections = SECTIONS_B;
    fireEvent.click(screen.getByRole("button", { name: "Retry preview" }));
    await expectSections("Fictional body B");
    expect(controls()).toEqual({ docx: true, print: true, pdf: true, zoom: true });
  });

  it("R21: a refusal or a server error after valid cached data hides the controls and keeps the cache; a valid Retry restores both", async () => {
    const h = mountPreview(baseProps("P1"));
    await expectSections("Fictional body A");
    h.network.setTransform(replaceBody(oversizeEnvelope()));
    act(() => { focusManager.setFocused(false); focusManager.setFocused(true); });
    await expectAlert(NEUTRAL);
    expect(previewData(h.queryClient)?.sections).toEqual(SECTIONS_A);
    expect(controls()).toEqual({ docx: false, print: false, pdf: false, zoom: false });
    h.network.setTransform((response) => response);
    server.previewError = { code: "BAD_REQUEST", message: "Choose the executor who signs this affidavit." };
    fireEvent.click(screen.getByRole("button", { name: "Retry preview" }));
    await expectAlert("Choose the executor who signs this affidavit.");
    expect(controls().docx).toBe(false);
    expect(previewData(h.queryClient)?.sections).toEqual(SECTIONS_A);
    server.previewError = null;
    server.sections = SECTIONS_B;
    fireEvent.click(screen.getByRole("button", { name: "Retry preview" }));
    await expectSections("Fictional body B");
    expect(controls().docx).toBe(true);
  });
});

/* ---------------------------- refusal paths through the modal (R22-R24) ---------------------------- */

describe("refusal paths through the modal", () => {
  it("R22: a body that stalls after its first bytes is cut by the idle timer into the neutral sentence with no retry; Retry renders", async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
    const h = mountPreview(baseProps("P1"));
    let bodyCancelled = 0;
    h.network.setTransform(restream((bytes) => stalledStream(bytes.subarray(0, 8), () => { bodyCancelled += 1; })));
    await waitFor(() => expect(h.network.previews()).toHaveLength(1));
    await act(async () => { await vi.advanceTimersByTimeAsync(1_000); });
    expect(alertText()).toBeNull();
    expect(bodyCancelled).toBe(0);
    // PREVIEW_BODY_IDLE_TIMEOUT_MS (15 s), written as a literal so this suite fails on behaviour.
    await act(async () => { await vi.advanceTimersByTimeAsync(15_000); });
    await expectAlert(NEUTRAL);
    expect(bodyCancelled).toBe(1);
    expect(h.network.previews()).toHaveLength(1);
    expect(h.subscriber.errorActions).toBe(1);
    expect((queryErrorLines()[0][1] as { meta?: unknown }).meta).toBeUndefined();
    h.network.setTransform((response) => response);
    fireEvent.click(screen.getByRole("button", { name: "Retry preview" }));
    await expectSections("Fictional body A");
    expect(h.network.previews()).toHaveLength(2);
  });

  it("R23: a stream that errors mid-body shows only the neutral sentence, sends no retry, exposes no engine text; Retry renders", async () => {
    const h = mountPreview(baseProps("P1"));
    h.network.setTransform(restream((bytes) => {
      let pulls = 0;
      return new ReadableStream<Uint8Array>({ pull(controller) { pulls += 1; if (pulls === 1) controller.enqueue(bytes.subarray(0, 8)); else controller.error(new Error("FICTIONAL connection reset")); } }, { highWaterMark: 0 });
    }));
    await expectAlert(NEUTRAL);
    await flush();
    expect(h.network.previews()).toHaveLength(1);
    expect(h.subscriber.errorActions).toBe(1);
    expect(document.body.textContent).not.toContain("connection reset");
    expect(everyField(queryErrorLines()[0][1])).not.toContain("FICTIONAL connection reset");
    expect((queryErrorLines()[0][1] as { meta?: unknown }).meta).toBeUndefined();
    h.network.setTransform((response) => response);
    fireEvent.click(screen.getByRole("button", { name: "Retry preview" }));
    await expectSections("Fictional body A");
    expect(h.network.previews()).toHaveLength(2);
  });

  it("R24: a refusal envelope over the 16 KiB bound is dropped unread into the neutral sentence, never its own text, with no retry; Retry renders", async () => {
    const h = mountPreview(baseProps("P1"));
    // PREVIEW_REFUSAL_BODY_LIMIT_BYTES (16 KiB), written as a literal so this suite fails on behaviour.
    const refusal = JSON.stringify({ error: { json: { message: "FICTIONAL-REFUSAL-TEXT " + "y".repeat(16 * 1024), code: -32600, data: { code: "BAD_REQUEST", httpStatus: 400 } } } });
    h.network.setTransform(replaceBody(refusal, 400));
    await expectAlert(NEUTRAL);
    await flush();
    expect(document.body.textContent).not.toContain("FICTIONAL-REFUSAL-TEXT");
    expect(h.network.previews()).toHaveLength(1);
    expect(h.subscriber.errorActions).toBe(1);
    expect(everyField(queryErrorLines()[0][1])).not.toContain("FICTIONAL-REFUSAL-TEXT");
    expect((queryErrorLines()[0][1] as { meta?: unknown }).meta).toBeUndefined();
    h.network.setTransform((response) => response);
    fireEvent.click(screen.getByRole("button", { name: "Retry preview" }));
    await expectSections("Fictional body A");
    expect(h.network.previews()).toHaveLength(2);
  });
});
