import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

// 2026-07-26 review fix (P15PLUS-006 display): a pre-0102 estate whose legacy
// electronicWillFormat token established a (iii)/(iv) fact must SHOW the
// resolved axes + the P45 alert — the raw axis columns are blank on those rows,
// so the old display hid a recorded fact while formStatus/readiness resolved it.

vi.setConfig({ testTimeout: 45000 }); // 2026-08-21: jsdom EstateDetail suites breached 15-20s under full-suite worker contention (flake class, memory probatepro-test-flakiness) — headroom, not speed, keeps the gate reproducible
(globalThis as any).React = React;

const mocks = vi.hoisted(() => ({ estateUpdate: vi.fn() }));

vi.mock("sonner", () => ({
  toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }),
}));

vi.mock("@/lib/trpc", () => {
  const idleMutation = () => ({ mutate: vi.fn(), mutateAsync: vi.fn(async () => ({})), isPending: false });
  const invalidator = () => ({ invalidate: vi.fn() });
  return {
    trpc: {
      inventory: {
        list: { useQuery: () => ({ data: [], isLoading: false }) },
        totals: { useQuery: () => ({ data: undefined }) },
        create: { useMutation: idleMutation },
        update: { useMutation: idleMutation },
        delete: { useMutation: idleMutation },
        reorder: { useMutation: idleMutation },
        bulkCreate: { useMutation: idleMutation },
      },
      contact: { list: { useQuery: () => ({ data: [] }) } },
      settings: { get: { useQuery: () => ({ data: { formFocusedIntake: false } }) } },
      notes: { pinned: { useQuery: () => ({ data: [] }) } },
      estate: {
        update: { useMutation: () => ({ mutate: mocks.estateUpdate, isPending: false, isSuccess: false }) },
        uploadWill: { useMutation: idleMutation },
        deleteWill: { useMutation: idleMutation },
        uploadCodicil: { useMutation: idleMutation },
        deleteCodicil: { useMutation: idleMutation },
        reorderCodicils: { useMutation: idleMutation },
        updateCodicilDate: { useMutation: idleMutation },
        uploadForeignGrant: { useMutation: idleMutation },
        deleteForeignGrant: { useMutation: idleMutation },
        uploadLegalEvidence: { useMutation: idleMutation },
        clearLegalEvidence: { useMutation: idleMutation },
      },
      useUtils: () => ({
        inventory: { list: invalidator(), totals: invalidator() },
        distribution: { compute: invalidator() },
        readiness: { check: invalidator(), timeline: invalidator() },
        deadline: { list: invalidator() },
        delivery: { getRecipients: invalidator() },
        estate: { get: invalidator(), list: invalidator() },
        document: { preflight: invalidator(), preflightMany: invalidator() },
      }),
    },
  };
});

async function components() {
  const estateDetail = await import("./EstateDetail");
  const { TooltipProvider } = await import("@/components/ui/tooltip");
  return { ...estateDetail, TooltipProvider };
}

function repoYesButton(): HTMLElement {
  const label = screen.getByText(/THIRD-PARTY electronic repository/);
  const wrapper = label.closest("div")!;
  return Array.from(wrapper.querySelectorAll("button")).find((b) => b.textContent === "Yes")!;
}

beforeEach(() => {
  mocks.estateUpdate.mockReset();
  window.localStorage.clear();
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
});

describe("Electronic-will axes display — legacy token resolution (2026-07-26 review fix)", () => {
  it("uses Type of Will as the only electronic-will answer and synchronizes the legacy P1/P9 flag", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const { unmount } = render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ id: "estate-1", revision: 1, hasWill: 1, willType: "physical", isElectronicWill: 0, willFilingType: "" }} />
      </TooltipProvider>,
    );
    const label = screen.getByText("Type of Will");
    const electronic = Array.from(label.parentElement!.querySelectorAll("button")).find((button) => button.textContent === "Electronic")!;
    fireEvent.click(electronic);
    unmount();

    expect(mocks.estateUpdate).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({ willType: "electronic", isElectronicWill: 1 }),
    }));
    expect(screen.queryByLabelText(/The will is an electronic will/i)).toBeNull();
  });

  it("shows and persists the canonical original-will location in Intake", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const { unmount } = render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{
          id: "estate-1", revision: 1, hasWill: 1, willStatus: "will",
          willType: "physical", isElectronicWill: 0, willFilingType: "",
          willLocation: "Law firm safe",
        }} />
      </TooltipProvider>,
    );

    const location = screen.getByLabelText("Where the original will is kept");
    expect((location as HTMLInputElement).value).toBe("Law firm safe");
    fireEvent.change(location, { target: { value: "Home safe" } });
    unmount();

    expect(mocks.estateUpdate).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({ willLocation: "Home safe" }),
    }));
  });

  it("persists an electronic-original filing selection with both canonical medium axes", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const { unmount } = render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ id: "estate-1", revision: 1, hasWill: 1, willType: "physical", isElectronicWill: 0, willFilingType: "" }} />
      </TooltipProvider>,
    );
    const label = screen.getByText("The will being filed is");
    const trigger = label.parentElement!.querySelector('[role="combobox"]') as HTMLElement;
    fireEvent.click(trigger);
    fireEvent.click(await screen.findByText("The electronic original."));
    unmount();

    expect(mocks.estateUpdate).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({
        willFilingType: "electronic_original",
        willType: "electronic",
        isElectronicWill: 1,
      }),
    }));
  });

  it("a legacy third_party_repo token displays repository = Yes and the P45 alert", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const estate = { id: "estate-1", hasWill: 1, willType: "electronic", electronicWillFormat: "third_party_repo" };
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...estate }} />
      </TooltipProvider>,
    );
    expect(repoYesButton().className).toContain("bg-slate-700");
    expect(screen.getByText(/require Form P45 \(Affidavit of Electronic Will\) and the long-form P4/)).toBeTruthy();
    // 2026-07-26 review fix: the P45 sworn format line must be fillable for a
    // repository-stored will — the description input shows for every non-PDF token.
    expect(screen.getByText("Describe the electronic format of the original will")).toBeTruthy();
    // The repository scenario is APPLICATION material (P4), never P45 sworn text —
    // the pre-fix copy claimed the opposite ("branches internally" / "covered within").
    expect(screen.queryByText(/branches internally/)).toBeNull();
    expect(screen.queryByText(/covered within Form P45/)).toBeNull();
    expect(screen.getByText(/filed as application material with the long-form P4/)).toBeTruthy();
    expect(screen.getByText(/filed as application material supporting the P4/)).toBeTruthy();
  });

  it("a legacy other_format token still shows the format-description input (pre-fix behavior preserved)", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const estate = { id: "estate-1", hasWill: 1, willType: "electronic", electronicWillFormat: "other_format" };
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...estate }} />
      </TooltipProvider>,
    );
    expect(screen.getByText("Describe the electronic format of the original will")).toBeTruthy();
  });

  it("a legacy pdf_original token displays PDF = Yes, repository = No, and no P45 alert", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const estate = { id: "estate-1", hasWill: 1, willType: "electronic", electronicWillFormat: "pdf_original" };
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...estate }} />
      </TooltipProvider>,
    );
    expect(repoYesButton().className).not.toContain("bg-slate-700");
    const repoNo = (() => {
      const label = screen.getByText(/THIRD-PARTY electronic repository/);
      return Array.from(label.closest("div")!.querySelectorAll("button")).find((b) => b.textContent === "No")!;
    })();
    expect(repoNo.className).toContain("bg-slate-700");
    expect(screen.queryByText(/require Form P45 \(Affidavit of Electronic Will\) and the long-form P4/)).toBeNull();
    // pdf_original needs no format description — the sworn line states PDF itself.
    expect(screen.queryByText("Describe the electronic format of the original will")).toBeNull();
  });

  it("a bare electronic will with no token and no axes shows nothing selected and no alert", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const estate = { id: "estate-1", hasWill: 1, willType: "electronic" };
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...estate }} />
      </TooltipProvider>,
    );
    expect(repoYesButton().className).not.toContain("bg-slate-700");
    expect(screen.queryByText(/require Form P45 \(Affidavit of Electronic Will\) and the long-form P4/)).toBeNull();
  });
});
