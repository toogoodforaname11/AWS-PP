import { PageHeader } from "@/components/PageHeader";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { AdminFailureReports } from "@/components/AdminFailureReports";
import { AlertTriangle, Ban, CheckCircle2, Loader2, Search, ShieldCheck, Users } from "lucide-react";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

const ISSUE_STATUSES = ["pending", "in_progress", "resolved"] as const;
const REPORTS_PER_PAGE = 12;
type IssueStatus = (typeof ISSUE_STATUSES)[number];
type QueueFilter = "all" | IssueStatus;
type QueuePriorityFilter = "all" | ReportPriority;
type QueueSort = "unresolved" | "priority_high" | "priority_low" | "newest" | "oldest";
type ReportPriority = "low" | "normal" | "high";
type TrendReport = { createdAt: Date | number | string; issueStatus: string; statusUpdatedAt?: Date | number | string | null };
type AdminReport = TrendReport & { id: string; userId: number; subject: string; category: string; details: string; priority?: ReportPriority; reporterName?: string | null; reporterEmail?: string | null };

const issueLabels: Record<IssueStatus, string> = { pending: "Pending", in_progress: "In Progress", resolved: "Resolved" };
const priorityLabels: Record<ReportPriority, string> = { high: "High", normal: "Normal", low: "Low" };

function formatDate(value: Date | number | string | null | undefined) {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : date.toLocaleString();
}

function dayStartUtc(value: Date | number | string) {
  const date = new Date(value);
  return Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate());
}

function localDateBoundary(value: string, nextDay = false) {
  const [year, month, day] = value.split("-").map(Number);
  if (!year || !month || !day) return null;
  return new Date(year, month - 1, day + (nextDay ? 1 : 0)).getTime();
}

function buildThirtyDayTrend(reports: TrendReport[]) {
  const today = dayStartUtc(Date.now());
  const start = today - 29 * 86_400_000;
  const days = Array.from({ length: 30 }, (_, index) => {
    const timestamp = start + index * 86_400_000;
    return { timestamp, label: new Date(timestamp).toLocaleDateString(undefined, { month: "short", day: "numeric", timeZone: "UTC" }), incoming: 0, resolved: 0 };
  });
  const byDay = new Map(days.map((day) => [day.timestamp, day]));
  reports.forEach((report) => {
    const incoming = byDay.get(dayStartUtc(report.createdAt));
    if (incoming) incoming.incoming += 1;
    if (report.issueStatus === "resolved" && report.statusUpdatedAt) {
      const resolved = byDay.get(dayStartUtc(report.statusUpdatedAt));
      if (resolved) resolved.resolved += 1;
    }
  });
  return days;
}

function ReportActivityChart({ reports }: { reports: TrendReport[] }) {
  const trend = buildThirtyDayTrend(reports);
  const maxValue = Math.max(0, ...trend.flatMap((day) => [day.incoming, day.resolved]));
  const [activeDay, setActiveDay] = useState<number | null>(null);
  if (maxValue === 0) return <p className="rounded-lg border border-dashed border-border/70 px-3 py-6 text-sm text-muted-foreground">No incoming or resolved report activity has been recorded in the last 30 days.</p>;

  const width = 720;
  const height = 180;
  const padding = { top: 16, right: 18, bottom: 28, left: 28 };
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;
  const point = (value: number, index: number) => ({ x: padding.left + (index / (trend.length - 1)) * chartWidth, y: padding.top + chartHeight - (value / maxValue) * chartHeight });
  const pointsFor = (key: "incoming" | "resolved") => trend.map((day, index) => { const coordinates = point(day[key], index); return `${coordinates.x},${coordinates.y}`; }).join(" ");
  const active = activeDay === null ? null : trend[activeDay];

  return <div className="space-y-3"><div className="flex flex-wrap gap-x-4 gap-y-2 text-xs text-muted-foreground"><span className="inline-flex items-center gap-1.5"><i className="h-2 w-2 rounded-full bg-sky-600" /> Incoming</span><span className="inline-flex items-center gap-1.5"><i className="h-2 w-2 rounded-full bg-emerald-600" /> Resolved</span><span className="ml-auto">{trend[0]?.label}–{trend[trend.length - 1]?.label}</span></div><div className="relative"><svg role="group" aria-label="30-day incoming and resolved report activity" className="h-48 w-full overflow-visible" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none"><line x1={padding.left} y1={padding.top + chartHeight} x2={width - padding.right} y2={padding.top + chartHeight} stroke="currentColor" opacity="0.18" /><line x1={padding.left} y1={padding.top + chartHeight / 2} x2={width - padding.right} y2={padding.top + chartHeight / 2} stroke="currentColor" opacity="0.1" strokeDasharray="4 4" /><polyline fill="none" points={pointsFor("incoming")} stroke="oklch(0.6 0.13 235)" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round" /><polyline fill="none" points={pointsFor("resolved")} stroke="oklch(0.64 0.12 155)" strokeWidth="3" strokeLinejoin="round" strokeLinecap="round" />{trend.map((day, index) => { const x = point(0, index).x; return <rect key={day.timestamp} x={x - chartWidth / (trend.length - 1) / 2} y={padding.top} width={chartWidth / (trend.length - 1)} height={chartHeight} fill="transparent" tabIndex={0} role="button" aria-label={`${day.label}: ${day.incoming} incoming, ${day.resolved} resolved`} onPointerEnter={() => setActiveDay(index)} onFocus={() => setActiveDay(index)} onPointerLeave={() => setActiveDay(null)} onBlur={() => setActiveDay(null)} />; })}<text x={padding.left} y={height - 6} fontSize="10" fill="currentColor" opacity="0.65">{trend[0]?.label}</text><text x={width - padding.right} y={height - 6} textAnchor="end" fontSize="10" fill="currentColor" opacity="0.65">{trend[trend.length - 1]?.label}</text></svg>{active && <div role="tooltip" className="pointer-events-none absolute top-2 z-10 rounded-lg border border-border/70 bg-popover/95 px-3 py-2 text-xs text-popover-foreground shadow-lg backdrop-blur-md" style={{ left: `${Math.min(78, Math.max(2, (activeDay! / (trend.length - 1)) * 100))}%` }}><p className="font-medium">{active.label}</p><p>Incoming: {active.incoming}</p><p>Resolved: {active.resolved}</p></div>}</div><p className="sr-only">{trend.map((day) => `${day.label}: ${day.incoming} incoming, ${day.resolved} resolved`).join(". ")}</p></div>;
}

function QueuePageSkeleton() {
  return <div aria-busy="true" aria-label="Loading report page" className="space-y-3">{Array.from({ length: 4 }, (_, index) => <div key={index} className="admin-glass-row motion-safe:animate-pulse rounded-xl p-3"><div className="h-4 w-3/5 rounded bg-muted" /><div className="mt-2 h-3 w-2/5 rounded bg-muted" /><div className="mt-4 h-8 w-36 rounded bg-muted" /></div>)}</div>;
}

export default function Administration() {
  const { user } = useAuth();
  const [location, navigate] = useLocation();
  const isAdmin = user?.role === "admin" && !user.suspendedAt;
  const [query, setQuery] = useState("");
  const [reasonById, setReasonById] = useState<Record<number, string>>({});
  const [suspensionCandidate, setSuspensionCandidate] = useState<{ id: number; name: string; reason: string } | null>(null);
  const [queueFilter, setQueueFilter] = useState<QueueFilter>("all");
  const [priorityFilter, setPriorityFilter] = useState<QueuePriorityFilter>("all");
  const [queueSort, setQueueSort] = useState<QueueSort>("unresolved");
  const [reportQuery, setReportQuery] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [queuePage, setQueuePage] = useState(1);
  const [selectedReportIds, setSelectedReportIds] = useState<Set<string>>(new Set());
  const [adminTab, setAdminTab] = useState<"workspace" | "failures">(() => new URLSearchParams(window.location.search).get("tab") === "failures" ? "failures" : "workspace");
  const [bulkResolveOpen, setBulkResolveOpen] = useState(false);
  const [reportActionCandidate, setReportActionCandidate] = useState<{ id: string; subject: string; type: "status"; previous: IssueStatus; next: IssueStatus } | { id: string; subject: string; type: "priority"; previous: ReportPriority; next: ReportPriority } | null>(null);
  const [isQueuePageTransitioning, setIsQueuePageTransitioning] = useState(false);
  const pageTransitionTimer = useRef<number | null>(null);
  const usersQuery = trpc.administration.listUsers.useQuery(undefined, { enabled: isAdmin });
  const reportsQuery = trpc.support.listAllReports.useQuery(undefined, { enabled: isAdmin, refetchInterval: 15_000, refetchOnWindowFocus: true });
  const utils = trpc.useUtils();
  const suspensionMutation = trpc.administration.setUserSuspension.useMutation({ onSuccess: () => { void usersQuery.refetch(); } });
  const statusMutation = trpc.support.updateIssueStatus.useMutation({ onSuccess: (_result, input) => { setReportActionCandidate(null); void reportsQuery.refetch(); void utils.support.getReportDetail.invalidate(); toast.success(`Report marked ${issueLabels[input.issueStatus]}`); } });
  const priorityMutation = trpc.support.updatePriority.useMutation({ onSuccess: (_result, input) => { setReportActionCandidate(null); void reportsQuery.refetch(); void utils.support.getReportDetail.invalidate(); toast.success(`Report priority set to ${priorityLabels[input.priority]}`); } });
  const undoBulkResolveMutation = trpc.support.undoResolvedReports.useMutation({ onSuccess: (result) => { void reportsQuery.refetch(); void utils.support.getReportDetail.invalidate(); toast.success(result.restoredCount === 1 ? "Report resolution undone" : `${result.restoredCount} report resolutions undone`); } });
  const bulkResolveMutation = trpc.support.resolveReports.useMutation({ onSuccess: (result) => { setSelectedReportIds(new Set()); setBulkResolveOpen(false); void reportsQuery.refetch(); void utils.support.getReportDetail.invalidate(); if (result.undoRecords.length > 0) toast.success(result.updatedCount === 1 ? "Report resolved" : `${result.updatedCount} reports resolved`, { duration: 8000, action: { label: "Undo", onClick: () => undoBulkResolveMutation.mutate({ records: result.undoRecords }) } }); } });
  const normalizedQuery = query.trim().toLowerCase();
  const normalizedReportQuery = reportQuery.trim().toLowerCase();
  const startTimestamp = startDate ? localDateBoundary(startDate) : null;
  const endExclusiveTimestamp = endDate ? localDateBoundary(endDate, true) : null;
  const hasActiveQueueControls = Boolean(reportQuery || startDate || endDate || queueFilter !== "all" || priorityFilter !== "all" || queueSort !== "unresolved");
  const clearQueueControls = () => {
    setReportQuery("");
    setStartDate("");
    setEndDate("");
    setQueueFilter("all");
    setPriorityFilter("all");
    setQueueSort("unresolved");
  };
  const users = useMemo(() => (usersQuery.data ?? []).filter((account) => !normalizedQuery || [account.name, account.email, account.role].some((value) => String(value ?? "").toLowerCase().includes(normalizedQuery))), [usersQuery.data, normalizedQuery]);
  const reports = (reportsQuery.data ?? []) as AdminReport[];
  const visibleReports = useMemo(() => {
    const reportRank: Record<IssueStatus, number> = { pending: 0, in_progress: 1, resolved: 2 };
    const priorityRank: Record<ReportPriority, number> = { high: 0, normal: 1, low: 2 };
    const filtered = reports.filter((report) => {
      const priority = report.priority ?? "normal";
      if (queueFilter !== "all" && report.issueStatus !== queueFilter) return false;
      if (priorityFilter !== "all" && priority !== priorityFilter) return false;
      const reportCreated = Number(new Date(report.createdAt));
      if (startTimestamp !== null && reportCreated < startTimestamp) return false;
      if (endExclusiveTimestamp !== null && reportCreated >= endExclusiveTimestamp) return false;
      if (!normalizedReportQuery) return true;
      return [report.subject, report.category, report.details, report.reporterName, report.reporterEmail, String(report.userId)].some((value) => String(value ?? "").toLowerCase().includes(normalizedReportQuery));
    });
    return [...filtered].sort((left, right) => {
      const leftCreated = Number(left.createdAt ?? 0); const rightCreated = Number(right.createdAt ?? 0);
      if (queueSort === "newest") return rightCreated - leftCreated;
      if (queueSort === "oldest") return leftCreated - rightCreated;
      if (queueSort === "priority_high") return (priorityRank[left.priority ?? "normal"] - priorityRank[right.priority ?? "normal"]) || (reportRank[left.issueStatus as IssueStatus] - reportRank[right.issueStatus as IssueStatus]) || rightCreated - leftCreated;
      if (queueSort === "priority_low") return (priorityRank[right.priority ?? "normal"] - priorityRank[left.priority ?? "normal"]) || (reportRank[left.issueStatus as IssueStatus] - reportRank[right.issueStatus as IssueStatus]) || rightCreated - leftCreated;
      return (reportRank[left.issueStatus as IssueStatus] - reportRank[right.issueStatus as IssueStatus]) || rightCreated - leftCreated;
    });
  }, [endExclusiveTimestamp, normalizedReportQuery, priorityFilter, queueFilter, queueSort, reports, startTimestamp]);
  const summary = useMemo(() => ({ pendingReports: reports.filter((report) => report.issueStatus === "pending").length, resolvedReports: reports.filter((report) => report.issueStatus === "resolved").length, activeUsers: (usersQuery.data ?? []).filter((account) => !account.suspendedAt).length }), [reports, usersQuery.data]);
  const pageCount = Math.max(1, Math.ceil(visibleReports.length / REPORTS_PER_PAGE));
  const safeQueuePage = Math.min(queuePage, pageCount);
  const pagedReports = visibleReports.slice((safeQueuePage - 1) * REPORTS_PER_PAGE, safeQueuePage * REPORTS_PER_PAGE);
  const selectablePageIds = pagedReports.filter((report) => report.issueStatus !== "resolved").map((report) => report.id);
  const selectedOnPage = selectablePageIds.filter((id) => selectedReportIds.has(id));
  const changeQueuePage = (nextPage: number) => {
    const targetPage = nextPage === pageCount && safeQueuePage < pageCount ? safeQueuePage + 1 : nextPage;
    if (targetPage === safeQueuePage || isQueuePageTransitioning) return;
    const reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;
    setQueuePage(targetPage);
    setSelectedReportIds(new Set());
    if (reducedMotion) return;
    if (pageTransitionTimer.current) window.clearTimeout(pageTransitionTimer.current);
    setIsQueuePageTransitioning(true);
    pageTransitionTimer.current = window.setTimeout(() => { setIsQueuePageTransitioning(false); pageTransitionTimer.current = null; }, 220);
  };
  useEffect(() => () => { if (pageTransitionTimer.current) window.clearTimeout(pageTransitionTimer.current); }, []);
  useEffect(() => { setQueuePage(1); setSelectedReportIds(new Set()); }, [endDate, priorityFilter, queueFilter, queueSort, reportQuery, startDate]);

  if (!isAdmin) return <main className="mx-auto max-w-xl py-10"><Alert variant="destructive"><AlertTriangle className="h-4 w-4" /><AlertTitle>Administrator access required</AlertTitle><AlertDescription>This workspace is restricted to active administrator accounts.</AlertDescription></Alert></main>;

  return <main className="admin-workspace admin-command-center space-y-6"><header className="admin-command-header"><div><p className="admin-command-kicker">Guarded operations</p><h1>Administrator</h1><p className="admin-command-subtitle">Access control, support triage, and operational intelligence—without exposing protected case content.</p></div><div className="admin-command-status" aria-label="Administrator workspace status"><span><i aria-hidden="true" /> Monitored</span><span>Private access</span></div></header>
    <div role="tablist" aria-label="Administrator sections" className="admin-section-switcher"><Button type="button" role="tab" aria-selected={adminTab === "workspace"} variant={adminTab === "workspace" ? "secondary" : "ghost"} size="sm" onClick={() => { setAdminTab("workspace"); navigate("/administration"); }}>Workspace</Button><Button type="button" role="tab" aria-selected={adminTab === "failures"} variant={adminTab === "failures" ? "secondary" : "ghost"} size="sm" onClick={() => { setAdminTab("failures"); navigate("/administration?tab=failures"); }}><AlertTriangle className="mr-2 h-4 w-4" />Failures & crash reports</Button></div>
    {adminTab === "failures" && <AdminFailureReports />}
    <div hidden={adminTab !== "workspace"}>
    <section aria-label="Administration summary" className="admin-ledger-stats"><div className="admin-glass-stat" data-tone="attention"><div className="admin-stat-heading"><span>Pending reports</span><AlertTriangle className="h-4 w-4" /></div><strong>{summary.pendingReports}</strong><em>Requires review</em></div><div className="admin-glass-stat" data-tone="resolved"><div className="admin-stat-heading"><span>Resolved issues</span><CheckCircle2 className="h-4 w-4" /></div><strong>{summary.resolvedReports}</strong><em>Closed with a record</em></div><div className="admin-glass-stat" data-tone="access"><div className="admin-stat-heading"><span>Active users</span><Users className="h-4 w-4" /></div><strong>{summary.activeUsers}</strong><em>Authorized access</em></div></section>
    <Card className="admin-glass-panel admin-activity-panel"><CardHeader><CardTitle>Report activity <span>· last 30 days</span></CardTitle><CardDescription>Incoming reports are grouped by submission date; resolved reports are grouped by the date their issue status was set to Resolved.</CardDescription></CardHeader><CardContent><ReportActivityChart reports={reports} /></CardContent></Card>
    <Alert className="admin-safeguard-note"><ShieldCheck className="h-4 w-4" /><AlertTitle>Access safeguards</AlertTitle><AlertDescription>Administrators cannot suspend themselves, and the final active administrator cannot be suspended. Suspended accounts are blocked from protected app actions until restored.</AlertDescription></Alert>
    <div className="admin-operation-grid">
      <Card className="admin-glass-panel admin-users-panel"><CardHeader><div className="flex flex-wrap items-start justify-between gap-3"><div><CardTitle className="flex items-center gap-2"><Users className="h-5 w-5 text-primary" /> Users</CardTitle><CardDescription>View active accounts and pause or restore access without deleting user records.</CardDescription></div><Badge variant="secondary" className="admin-glass-badge">{usersQuery.data?.length ?? 0} accounts</Badge></div></CardHeader><CardContent className="space-y-4"><div className="max-w-md"><Label htmlFor="admin-user-search">Search users</Label><Input id="admin-user-search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Name, email, or role" /></div>{usersQuery.isLoading ? <div role="status" className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading users…</div> : users.length === 0 ? <p className="text-sm text-muted-foreground">No users match this search.</p> : <div className="space-y-3">{users.map((account) => { const isSelf = account.id === user.id; const isSuspended = Boolean(account.suspendedAt); return <div key={account.id} className="admin-glass-row rounded-xl p-3"><div className="flex flex-wrap items-start justify-between gap-3"><div className="min-w-0"><p className="break-words font-medium">{account.name || "Unnamed user"}</p><p className="break-all text-sm text-muted-foreground">{account.email || "No email available"}</p><p className="mt-1 text-xs text-muted-foreground">Last sign-in: {formatDate(account.lastSignedIn)}</p></div><div className="flex flex-wrap items-center gap-2"><Badge variant={account.role === "admin" ? "default" : "secondary"}>{account.role === "admin" ? "Administrator" : "User"}</Badge><Badge variant={isSuspended ? "secondary" : "outline"}>{isSuspended ? "Paused" : "Active"}</Badge></div></div>{isSuspended && account.suspensionReason && <p className="mt-2 rounded-md bg-amber-500/10 px-2 py-1 text-xs text-amber-800 dark:text-amber-200">Reason: {account.suspensionReason}</p>}<div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-end"><div className="min-w-0 flex-1"><Label htmlFor={`suspension-reason-${account.id}`} className="text-xs">Pause reason (optional)</Label><Input id={`suspension-reason-${account.id}`} value={reasonById[account.id] ?? ""} disabled={isSuspended || isSelf || suspensionMutation.isPending} onChange={(event) => setReasonById((previous) => ({ ...previous, [account.id]: event.target.value }))} maxLength={500} placeholder="Record why access is being paused" /></div><Button type="button" variant="outline" className={isSuspended ? "border-emerald-500/35 bg-emerald-500/10 text-emerald-800 hover:bg-emerald-500/15 dark:text-emerald-200" : "border-amber-500/35 bg-amber-500/10 text-amber-800 hover:bg-amber-500/15 dark:text-amber-200"} disabled={isSelf || suspensionMutation.isPending} onClick={() => isSuspended ? suspensionMutation.mutate({ userId: account.id, suspended: false }) : setSuspensionCandidate({ id: account.id, name: account.name || account.email || "this user", reason: reasonById[account.id] ?? "" })}>{isSuspended ? <CheckCircle2 className="mr-2 h-4 w-4" /> : <Ban className="mr-2 h-4 w-4" />}{isSuspended ? "Restore access" : isSelf ? "Your account" : "Pause access"}</Button></div></div>; })}</div>}</CardContent></Card>
      <Card className="admin-glass-panel"><CardHeader><div className="flex flex-wrap items-start justify-between gap-3"><div><CardTitle>Support report queue</CardTitle><CardDescription>Search, filter, and order reports before opening their private response thread.</CardDescription></div><Badge variant="secondary" className="admin-glass-badge">{visibleReports.length} found</Badge></div></CardHeader><CardContent className="space-y-4">{reportsQuery.isLoading ? <div role="status" className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading reports…</div> : reports.length === 0 ? <p className="text-sm text-muted-foreground">No support reports are currently available.</p> : <><div className="grid min-w-0 gap-3 sm:grid-cols-2 lg:grid-cols-3"><div className="min-w-0 sm:col-span-2 lg:col-span-3"><Label htmlFor="admin-report-search" className="text-xs">Find a report</Label><div className="relative"><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><Input id="admin-report-search" className="pl-9" value={reportQuery} onChange={(event) => setReportQuery(event.target.value)} placeholder="Reporter email, subject, or keywords" /></div></div><div className="min-w-0"><Label htmlFor="admin-report-start-date" className="text-xs">From date</Label><Input id="admin-report-start-date" type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} /></div><div className="min-w-0"><Label htmlFor="admin-report-end-date" className="text-xs">To date</Label><Input id="admin-report-end-date" type="date" value={endDate} onChange={(event) => setEndDate(event.target.value)} /></div><div className="min-w-0"><Label htmlFor="admin-report-filter" className="text-xs">Issue state</Label><Select value={queueFilter} onValueChange={(value: QueueFilter) => setQueueFilter(value)}><SelectTrigger id="admin-report-filter" aria-label="Filter support reports by issue state" className="w-full min-w-0"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All reports</SelectItem>{ISSUE_STATUSES.map((status) => <SelectItem key={status} value={status}>{issueLabels[status]}</SelectItem>)}</SelectContent></Select></div><div className="min-w-0"><Label htmlFor="admin-report-priority-filter" className="text-xs">Priority</Label><Select value={priorityFilter} onValueChange={(value: QueuePriorityFilter) => setPriorityFilter(value)}><SelectTrigger id="admin-report-priority-filter" aria-label="Filter support reports by priority" className="w-full min-w-0"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">All priorities</SelectItem><SelectItem value="high">High priority</SelectItem><SelectItem value="normal">Normal priority</SelectItem><SelectItem value="low">Low priority</SelectItem></SelectContent></Select></div><div className="min-w-0 sm:col-span-2 lg:col-span-1"><Label htmlFor="admin-report-sort" className="text-xs">Order results</Label><Select value={queueSort} onValueChange={(value: QueueSort) => setQueueSort(value)}><SelectTrigger id="admin-report-sort" aria-label="Sort support reports" className="w-full min-w-0"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="unresolved">Unresolved, then newest</SelectItem><SelectItem value="priority_high">Priority: high to low</SelectItem><SelectItem value="priority_low">Priority: low to high</SelectItem><SelectItem value="newest">Date: newest first</SelectItem><SelectItem value="oldest">Date: oldest first</SelectItem></SelectContent></Select></div><div className="flex min-w-0 items-end sm:col-span-2 lg:col-span-3"><Button type="button" variant="outline" className="w-full" disabled={!hasActiveQueueControls} onClick={clearQueueControls}>Clear queue controls</Button></div></div>{visibleReports.length === 0 ? <p className="rounded-xl border border-dashed border-border/70 px-3 py-4 text-sm text-muted-foreground">No reports match this view. Clear the filters to restore the full queue.</p> : <><div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border/60 bg-background/35 px-3 py-2"><label className="flex items-center gap-2 text-sm font-medium"><Checkbox aria-label="Select unresolved reports on this page" checked={selectablePageIds.length > 0 && selectedOnPage.length === selectablePageIds.length} onCheckedChange={(checked) => setSelectedReportIds(checked ? new Set(selectablePageIds) : new Set())} disabled={selectablePageIds.length === 0 || bulkResolveMutation.isPending} /> Select unresolved on page</label>{selectedReportIds.size > 0 && <Button type="button" size="sm" className="bg-emerald-700 hover:bg-emerald-800" disabled={bulkResolveMutation.isPending} onClick={() => setBulkResolveOpen(true)}>Resolve {selectedReportIds.size} selected</Button>}</div>{isQueuePageTransitioning ? <QueuePageSkeleton /> : <div className="space-y-3">{pagedReports.map((report) => { const canSelect = report.issueStatus !== "resolved"; const priority = report.priority ?? "normal"; return <div key={report.id} className="admin-glass-row flex gap-3 rounded-xl p-3"><Checkbox aria-label={canSelect ? `Select ${report.subject} for bulk resolution` : `${report.subject} is already resolved`} checked={selectedReportIds.has(report.id)} disabled={!canSelect || bulkResolveMutation.isPending} onCheckedChange={(checked) => setSelectedReportIds((previous) => { const next = new Set(previous); if (checked) next.add(report.id); else next.delete(report.id); return next; })} /><div className="min-w-0 flex-1"><div className="flex flex-wrap items-start justify-between gap-2"><p className="font-medium break-words">{report.subject}</p><Badge variant={priority === "high" ? "destructive" : priority === "low" ? "secondary" : "outline"}>Priority · {priorityLabels[priority]}</Badge></div><p className="mt-1 break-words text-xs text-muted-foreground">{report.reporterEmail || report.reporterName || `Reporter #${report.userId}`} · {formatDate(report.createdAt)}</p><div className="mt-3 flex flex-col gap-2 sm:flex-row"><Select value={report.issueStatus as IssueStatus} onValueChange={(issueStatus: IssueStatus) => { if (issueStatus !== report.issueStatus) setReportActionCandidate({ id: report.id, subject: report.subject, type: "status", previous: report.issueStatus as IssueStatus, next: issueStatus }); }}><SelectTrigger aria-label={`Issue status for ${report.subject}`} className="w-full sm:w-40"><SelectValue /></SelectTrigger><SelectContent>{ISSUE_STATUSES.map((status) => <SelectItem key={status} value={status}>{issueLabels[status]}</SelectItem>)}</SelectContent></Select><Select value={priority} onValueChange={(nextPriority: ReportPriority) => { if (nextPriority !== priority) setReportActionCandidate({ id: report.id, subject: report.subject, type: "priority", previous: priority, next: nextPriority }); }}><SelectTrigger aria-label={`Priority for ${report.subject}`} className="w-full sm:w-36"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="high">High priority</SelectItem><SelectItem value="normal">Normal priority</SelectItem><SelectItem value="low">Low priority</SelectItem></SelectContent></Select><Button type="button" variant="outline" onClick={() => navigate(`/report-a-problem?reportId=${encodeURIComponent(report.id)}`)}>Open report</Button></div></div></div>; })}</div>}<div className="flex flex-wrap items-center justify-between gap-3 border-t border-border/60 pt-3"><p aria-live="polite" className="text-xs text-muted-foreground">Showing {((safeQueuePage - 1) * REPORTS_PER_PAGE) + 1}–{Math.min(safeQueuePage * REPORTS_PER_PAGE, visibleReports.length)} of {visibleReports.length} reports</p><div className="flex items-center gap-2"><Button type="button" size="sm" variant="outline" aria-label="Previous report page" disabled={safeQueuePage === 1 || isQueuePageTransitioning} onClick={() => changeQueuePage(Math.max(1, safeQueuePage - 1))}>Previous</Button><span className="text-xs tabular-nums text-muted-foreground">Page {safeQueuePage} of {pageCount}</span><Button type="button" size="sm" variant="outline" aria-label="Next report page" disabled={safeQueuePage === pageCount || isQueuePageTransitioning} onClick={() => changeQueuePage(Math.min(pageCount, safeQueuePage + 1))}>Next</Button></div></div></>}</>}</CardContent></Card>
    </div><AlertDialog open={Boolean(reportActionCandidate)} onOpenChange={(open) => { if (!open) setReportActionCandidate(null); }}><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>{reportActionCandidate?.type === "status" ? `Change issue status for ${reportActionCandidate.subject}?` : `Change priority for ${reportActionCandidate?.subject ?? "this report"}?`}</AlertDialogTitle><AlertDialogDescription>{reportActionCandidate?.type === "status" ? `This will change the issue status from ${issueLabels[reportActionCandidate.previous]} to ${issueLabels[reportActionCandidate.next]}.` : reportActionCandidate ? `This will change the report priority from ${priorityLabels[reportActionCandidate.previous]} to ${priorityLabels[reportActionCandidate.next]}.` : ""}</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={() => { if (!reportActionCandidate) return; if (reportActionCandidate.type === "status") statusMutation.mutate({ id: reportActionCandidate.id, issueStatus: reportActionCandidate.next }); else priorityMutation.mutate({ id: reportActionCandidate.id, priority: reportActionCandidate.next }); }}>{reportActionCandidate?.type === "status" ? "Confirm status update" : "Confirm priority update"}</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog><AlertDialog open={Boolean(suspensionCandidate)} onOpenChange={(open) => { if (!open) setSuspensionCandidate(null); }}><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Suspend {suspensionCandidate?.name}?</AlertDialogTitle><AlertDialogDescription>This blocks the account from protected app actions until an administrator restores access. Their records will remain intact.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => { if (suspensionCandidate) suspensionMutation.mutate({ userId: suspensionCandidate.id, suspended: true, reason: suspensionCandidate.reason }); setSuspensionCandidate(null); }}>Suspend user</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog><AlertDialog open={bulkResolveOpen} onOpenChange={setBulkResolveOpen}><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Resolve {selectedReportIds.size} selected reports?</AlertDialogTitle><AlertDialogDescription>This marks the selected unresolved reports as Resolved. You can still reopen an individual report later if more work is needed.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction className="bg-emerald-700 text-white hover:bg-emerald-800" onClick={() => bulkResolveMutation.mutate({ ids: Array.from(selectedReportIds) })}>Resolve reports</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
    </div>
  </main>;
}
