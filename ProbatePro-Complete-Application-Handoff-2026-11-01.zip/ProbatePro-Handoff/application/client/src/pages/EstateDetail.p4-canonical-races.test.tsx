import React from "react";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { checkFormRequirements } from "../../../shared/formRequirements";
import { coupleWillFilingTypeFacts } from "../../../shared/types";

vi.setConfig({ testTimeout: 45000 });
(globalThis as any).React = React;
vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }) }));
const state = vi.hoisted(() => ({
  stored: {} as Record<string, any>, cached: {} as Record<string, any>,
  saves: [] as any[], preflights: [] as any[], generated: [] as any[], effectiveAtGeneration: [] as any[], reports: [] as any[],
  ops: [] as string[], saveGate: null as Promise<void> | null, recheckGate: null as Promise<void> | null,
  loseResponse: false,
  failRecheck: false,
}));
const applicant = {
  id: "p4-popup-applicant", role: "applicant,executor", executorStatus: "applying", executorRank: "primary",
  name: "Fictional Applicant", relationship: "child", occupation: "Teacher", residentialAddress: "1 Fictional Lane, Vancouver BC V0V 0V0",
  residenceStreet: "1 Fictional Lane", residenceCity: "Vancouver", residenceProvince: "BC", residenceCountry: "Canada", residencePostalCode: "V0V 0V0",
};
function inspect(estate: any, input: any = {}) {
  return checkFormRequirements("P4", {
    estate, contacts: [applicant], inventory: [], requiredCatalog: [],
    requiredDocuments: [{ docKey: "wills_notice_result", received: 1 }, { docKey: "original_will", received: 1 }],
    renderContext: { selectedContactId: input.selectedContactId || applicant.id },
  } as any);
}
vi.mock("@/lib/trpc", () => {
  function utilities(path: string[]): any {
    return new Proxy({}, { get(_target, prop: string) {
      const key = path.join(".");
      if (prop === "getData") return () => key === "estate.get" ? state.cached : undefined;
      if (prop === "setData") return (_input: unknown, updater: any) => { if (key === "estate.get") state.cached = typeof updater === "function" ? updater(state.cached) : updater; };
      if (prop === "invalidate") return async () => undefined;
      if (prop === "cancel") return () => undefined;
      if (prop === "fetch") return async (input: any) => {
        if (key === "estate.get") { state.cached = { ...state.stored }; return state.stored; }
        if (key === "document.preflightMany") return [];
        if (key !== "document.preflight") return undefined;
        state.preflights.push(input);
        if (state.recheckGate && state.preflights.length > 1) await state.recheckGate;
        if (state.failRecheck && state.preflights.length > 1) throw new Error("Fictional recheck failure");
        const report = inspect({ ...state.stored, ...input.overrides }, input);
        state.reports.push(report);
        return report;
      };
      return utilities([...path, prop]);
    } });
  }
  function mutation(key: string, options?: any) {
    const mutateAsync = async (input: any) => {
      try {
        let result: any = { success: true };
        if (key === "estate.update") {
          state.ops.push("save:start");
          if (state.saveGate) await state.saveGate;
          if (input.expectedRevision !== state.stored.revision) throw new Error("Fictional stale revision");
          state.saves.push(input);
          state.stored = { ...state.stored, ...coupleWillFilingTypeFacts(input.data, state.stored), revision: state.stored.revision + 1 };
          state.ops.push("save:commit");
          if (state.loseResponse) { state.loseResponse = false; state.cached = { ...state.stored }; throw new Error("Fictional committed response loss"); }
          result = { success: true, revision: state.stored.revision };
        }
        if (key === "document.generate") {
          state.generated.push(input); state.effectiveAtGeneration.push({ ...state.stored, ...input.overrides });
          result = { id: "p4-popup-doc", filename: "P4_Fictional.docx", format: "docx", delivery: {
            method: "POST", action: "/api/download/form", fields: { estateId: "p4-popup-estate", formCode: "P4", documentId: "p4-popup-doc" },
          } };
        }
        await options?.onSuccess?.(result, input, undefined); return result;
      } catch (error) { await options?.onError?.(error, input, undefined); throw error; }
    };
    return { mutateAsync, mutate: (input: any) => { void mutateAsync(input).catch(() => undefined); }, isPending: false };
  }
  function node(path: string[]): any {
    return new Proxy({}, { get(_target, prop: string) {
      if (prop === "useUtils") return () => utilities([]);
      if (prop === "useMutation") return (options: any) => mutation(path.join("."), options);
      if (prop === "useQuery") return () => ({
        data: path.join(".") === "contact.list" ? [applicant] : path.join(".") === "estate.get" ? state.cached
          : ["document.list", "document.versions", "document.retainedFiles", "document.getLetterRecipients", "citation.list", "delivery.list", "delivery.getRecipients"].includes(path.join(".")) ? [] : undefined,
        isLoading: false, error: null,
      });
      return node([...path, prop]);
    } });
  }
  return { trpc: node([]) };
});
const downloads: Record<string, FormDataEntryValue>[] = [];
beforeEach(() => {
  cleanup(); vi.clearAllMocks();
  state.stored = {
    id: "p4-popup-estate", revision: 4, grantType: "grant_of_probate", willStatus: "will", hasWill: 1,
    deceasedFirstName: "Fictional", deceasedLastName: "Popup", willType: "", willFilingType: "", useLongFormAffidavit: 1,
    willDate: "2024-01-15", willStorageKey: "fictional-only/will.pdf", isElectronicWill: 0, oathType: "affirmed",
    testamentaryDocStatus: "none_found", beliefLastBcWill: "yes", specialCircumstances: "none", foreignWillStatus: "made_in_bc",
    wesaS58Reliance: "no", ordersAffectingWill: "no", vsaCertificateResult: "no_notice", isMilitaryWill: "no",
    executionIssues: "no_issues", attestationClauseStatus: "sufficient", willAlterations: "no_alterations", willAppearanceIssues: "no", referencedDocuments: "no",
    willDocumentsAttached: "yes", otherGrantsStatus: "no_other_grants", notifyPGT: "no", pgtIsApplicant: "no",
    p1NotRequired: 1, deceasedDomiciledInBC: "yes", codicilFiles: "[]", applicantType: "executor",
  };
  state.cached = { ...state.stored };
  for (const values of [state.saves, state.preflights, state.generated, state.effectiveAtGeneration, state.reports, state.ops, downloads]) values.length = 0;
  state.saveGate = null; state.recheckGate = null; state.loseResponse = false; state.failRecheck = false;
  for (const [name, value] of Object.entries({ hasPointerCapture: (): boolean => false, setPointerCapture: (): void => {}, releasePointerCapture: (): void => {}, scrollIntoView: (): void => {} })) Object.defineProperty(Element.prototype, name, { value, configurable: true });
  vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) { downloads.push(Object.fromEntries(new FormData(this))); });
});
afterEach(() => { cleanup(); vi.restoreAllMocks(); });
function gate() { let release!: () => void; const promise = new Promise<void>(resolve => { release = resolve; }); return { promise, release }; }
async function choose(id: string, name: string) { fireEvent.click(screen.getByTestId(id)); fireEvent.click(await screen.findByRole("option", { name })); }
async function openGap() {
  expect(inspect(state.stored).gaps.map(g => g.requirementId).sort()).toEqual(["p4_rule_25_3_6_will_filing_type_unconfirmed", "p4_will_medium_answered"].sort());
  expect(inspect({ ...state.stored, willFilingType: "electronic_original", willType: "electronic", isElectronicWill: 1 }).ok).toBe(true);
  const { FormsTab } = await import("./EstateDetail");
  render(<FormsTab estateId="p4-popup-estate" estate={{ ...state.stored }} onNavigateToTab={vi.fn()} />);
  fireEvent.click(screen.getByTestId("form-generate-P4"));
  await waitFor(() => expect(screen.queryByTestId("fix-confirm") || screen.queryByTestId("form-details-generate")).toBeTruthy());
  if (screen.queryByTestId("fix-confirm")) fireEvent.click(screen.getByTestId("fix-confirm"));
  await waitFor(() => expect(screen.getByTestId("form-details-generate")).toBeTruthy());
  fireEvent.click(screen.getByTestId("form-details-generate"));
  await waitFor(() => expect(screen.getByTestId("pre-generate-canonical-willType")).toBeTruthy());
}
async function mixedOriginal() { await choose("pre-generate-canonical-willType", "Physical"); await choose("pre-generate-input-willFilingType", "The electronic original."); }

describe("real P4 parent continuation uses the latest explicit popup input", () => {
  it.each(["pre-generate-apply", "pre-generate-proceed"])("holds %s after a filing-only save while a newer Copy and Physical input is pending", async button => {
    await openGap(); const save = gate(); state.saveGate = save.promise;
    await choose("pre-generate-input-willFilingType", "The electronic original.");
    fireEvent.click(screen.getByTestId(button)); await waitFor(() => expect(state.ops).toContain("save:start"));
    await choose("pre-generate-input-willFilingType", "A copy (original lost/destroyed).");
    await choose("pre-generate-canonical-willType", "Physical");
    await act(async () => { save.release(); });
    await waitFor(() => expect(state.reports).toHaveLength(2));
    expect(state.reports[1].ok).toBe(true); expect(state.generated).toHaveLength(0); expect(downloads).toHaveLength(0);
    expect(screen.getByTestId("pre-generate-canonical-willType").textContent).toContain("Physical");
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.generated).toHaveLength(1));
    expect(state.effectiveAtGeneration[0]).toMatchObject({ willType: "physical", isElectronicWill: 0, willFilingType: "copy" });
    expect(downloads).toHaveLength(1);
  });

  it.each(["pre-generate-apply", "pre-generate-proceed"])("holds %s when the post-acknowledgement correction equals the pre-coupling raw answer", async button => {
    await openGap(); const recheck = gate(); state.recheckGate = recheck.promise;
    await mixedOriginal(); fireEvent.click(screen.getByTestId(button));
    await waitFor(() => expect(state.saves).toHaveLength(1));
    await waitFor(() => expect((screen.getByTestId("pre-generate-canonical-willType") as HTMLButtonElement).disabled).toBe(false));
    await choose("pre-generate-canonical-willType", "Physical");
    await act(async () => { recheck.release(); });
    await waitFor(() => expect(state.reports).toHaveLength(2));
    expect(state.reports[1].ok).toBe(true); expect(state.generated).toHaveLength(0);
    expect(screen.getByTestId("pre-generate-canonical-willType").textContent).toContain("Physical");
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.generated).toHaveLength(1));
    expect(state.effectiveAtGeneration[0]).toMatchObject({ willType: "physical", isElectronicWill: 0 });
    expect(downloads).toHaveLength(1);
  });

  it("retries a committed mixed save with a lost response without reverting its effective submitted medium", async () => {
    await openGap(); state.loseResponse = true;
    await mixedOriginal(); fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.saves).toHaveLength(1));
    await act(async () => { await Promise.resolve(); });
    expect(state.generated).toHaveLength(0); expect(state.stored.willType).toBe("electronic");
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.generated).toHaveLength(1));
    expect(state.effectiveAtGeneration[0]).toMatchObject({ willType: "electronic", isElectronicWill: 1, willFilingType: "electronic_original" });
    expect(downloads).toHaveLength(1);
  });

  it("unlocks a durable filing-only medium after a failed recheck and applies an independent correction", async () => {
    await openGap(); state.failRecheck = true;
    await choose("pre-generate-input-willFilingType", "The electronic original.");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(state.saves).toHaveLength(1));
    await waitFor(() => expect(state.preflights).toHaveLength(2));
    await waitFor(() => expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(false));
    expect(state.generated).toHaveLength(0);
    expect((screen.getByTestId("pre-generate-canonical-willType") as HTMLButtonElement).disabled).toBe(false);
    await choose("pre-generate-canonical-willType", "Physical");
    state.failRecheck = false;
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.generated).toHaveLength(1));
    expect(state.saves[1].data).toEqual({ willType: "physical", isElectronicWill: 0 });
    expect(state.effectiveAtGeneration[0]).toMatchObject({ willType: "physical", isElectronicWill: 0 });
    expect(downloads).toHaveLength(1);
  });

  it("retries only the failed recheck after a filing-only acknowledgement, without another save", async () => {
    await openGap(); state.failRecheck = true;
    await choose("pre-generate-input-willFilingType", "The electronic original.");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(state.saves).toHaveLength(1));
    await waitFor(() => expect(state.preflights).toHaveLength(2));
    await waitFor(() => expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(false));
    state.failRecheck = false;
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(state.generated).toHaveLength(1));
    expect(state.preflights).toHaveLength(3);
    expect(state.saves).toHaveLength(1);
    expect(state.effectiveAtGeneration[0]).toMatchObject({ willType: "electronic", isElectronicWill: 1, willFilingType: "electronic_original" });
    expect(downloads).toHaveLength(1);
  });
});
