import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

// Heavy jsdom file: EstateDetail is imported inside the test body, same ceiling
// as the sibling audit specs.
vi.setConfig({ testTimeout: 45000 }); // 2026-08-21: jsdom EstateDetail suites breached 15-20s under full-suite worker contention (flake class, memory probatepro-test-flakiness) — headroom, not speed, keeps the gate reproducible

// tsconfig sets jsx:"preserve", so esbuild under vitest emits the classic
// createElement transform and vitest.config.ts has no react() plugin.
(globalThis as any).React = React;

const mocks = vi.hoisted(() => ({
  contacts: [] as any[],
  contactUpdate: vi.fn(),
  distribution: undefined as any,
}));

vi.mock("sonner", () => ({
  toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }),
}));

vi.mock("@/lib/trpc", () => {
  const idleMutation = () => ({ mutate: vi.fn(), mutateAsync: vi.fn(async () => ({})), isPending: false });
  const invalidator = () => ({ invalidate: vi.fn() });
  return {
    trpc: {
      contact: {
        list: { useQuery: () => ({ data: mocks.contacts, isLoading: false }) },
        update: { useMutation: () => ({ mutate: mocks.contactUpdate, isPending: false }) },
        create: { useMutation: idleMutation },
      },
      distribution: {
        compute: { useQuery: () => ({ data: mocks.distribution, isLoading: false }) },
        updateShare: { useMutation: idleMutation },
        splitEqually: { useMutation: idleMutation },
      },
      estate: { update: { useMutation: idleMutation } },
      inventory: { totals: { useQuery: () => ({ data: undefined }) } },
      useUtils: () => ({
        distribution: { compute: invalidator() },
        contact: { list: invalidator() },
        readiness: { check: invalidator(), timeline: invalidator() },
        estate: { get: invalidator(), list: invalidator() },
      }),
    },
  };
});

const INTESTACY_ESTATE = { id: "estate-1", grantType: "grant_of_administration_without_will", partialIntestacy: 0, testatePortionCents: 0 };

const SPOUSE = { id: "sp", name: "Jane Doe", role: "spouse", recipientType: "spouse", relationship: "spouse", isPredeceased: 0 };
const childContact = (commonDescendantStatus: string) => ({
  id: "kid-1", name: "Child A", role: "beneficiary", recipientType: "child",
  relationship: "child", isPredeceased: 0, commonDescendantStatus,
});

async function card() {
  const mod = await import("./EstateDetail");
  const { TooltipProvider } = await import("@/components/ui/tooltip");
  return { DistributionCard: mod.DistributionCard, TooltipProvider };
}

beforeEach(() => {
  mocks.contacts = [];
  mocks.contactUpdate.mockReset();
  mocks.distribution = { shares: [], totalDistributionCents: 0, netEstateCents: 0, isReconciled: true, wesaSection: "", warnings: [] };
  window.localStorage.clear();
});

// finding-3 (Nick rulings, 2026-07-27): the common-descendant control was a
// binary Checkbox whose `checked={d.isCommonDescendant === 1}` rendered the
// schema default as an affirmative answer — a phantom "Yes" nobody gave, which
// then drove the $300,000 WESA s.21(3) preferential share onto a sworn P10.
// Same failure class as Rule 11's triField phantom "No". It is now the house
// TriToggle: unrecorded highlights neither option and is labelled as such.
describe("WESA s.21(3)/(4) common-descendant control — tri-state (finding-3)", () => {
  it("shows an unanswered descendant as not answered and highlights neither option", async () => {
    mocks.contacts = [SPOUSE, childContact("")];
    const { DistributionCard, TooltipProvider } = await card();
    render(
      <TooltipProvider>
        <DistributionCard estateId="estate-1" estate={INTESTACY_ESTATE} />
      </TooltipProvider>,
    );

    expect(screen.getByText(/not answered/)).toBeTruthy();
    expect(screen.getByText(/print as blanks on Form P10/)).toBeTruthy();

    const yes = screen.getByRole("button", { name: "Yes" });
    const no = screen.getByRole("button", { name: "No" });
    // TriToggle marks the selected option with the filled slate background.
    expect(yes.className).not.toContain("bg-slate-700");
    expect(no.className).not.toContain("bg-slate-700");
  });

  it("persists an explicit answer through contact.update (markDirty class)", async () => {
    mocks.contacts = [SPOUSE, childContact("")];
    const { DistributionCard, TooltipProvider } = await card();
    render(
      <TooltipProvider>
        <DistributionCard estateId="estate-1" estate={INTESTACY_ESTATE} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByRole("button", { name: "Yes" }));
    expect(mocks.contactUpdate).toHaveBeenCalledWith({
      id: "kid-1",
      estateId: "estate-1",
      data: { commonDescendantStatus: "yes" },
    });

    mocks.contactUpdate.mockReset();
    fireEvent.click(screen.getByRole("button", { name: "No" }));
    expect(mocks.contactUpdate).toHaveBeenCalledWith({
      id: "kid-1",
      estateId: "estate-1",
      data: { commonDescendantStatus: "no" },
    });
    // The deprecated int is never written again.
    expect(JSON.stringify(mocks.contactUpdate.mock.calls)).not.toContain("isCommonDescendant");
  });

  // Issue H (2026-07-27): the client table called formatMoney() unconditionally, so
  // an unallocated share showed "$0.00" on screen while the P10 DOCX and preview
  // both rendered a blank — a fabricated zero on a user-facing surface, and a
  // UI-vs-document divergence (adr-no-fabricated-sworn-facts).
  it("renders an unallocated share and the total as BLANK, never $0.00", async () => {
    mocks.contacts = [SPOUSE, childContact("")];
    mocks.distribution = {
      shares: [
        { contactId: "sp", name: "Jane Doe", relationship: "spouse", shareDescription: "Preferential share + ½ of residue (WESA s.21(3) or s.21(4) — not yet determined)", estimatedValueCents: 0, isComputed: true, isUnallocated: true },
        { contactId: "kid-1", name: "Child A", relationship: "child", shareDescription: "Per stirpes share of ½ residue (WESA s.24)", estimatedValueCents: 0, isComputed: true, isUnallocated: true },
      ],
      totalDistributionCents: 0, netEstateCents: 1_000_000_00, isReconciled: false,
      wesaSection: "s.21(3) or s.21(4) — not determined", warnings: ["WESA s.21: Child A — record whether…"],
    };
    const { DistributionCard, TooltipProvider } = await card();
    const { container } = render(
      <TooltipProvider>
        <DistributionCard estateId="estate-1" estate={INTESTACY_ESTATE} />
      </TooltipProvider>,
    );

    const body = container.textContent || "";
    expect(body).toContain("Jane Doe");
    expect(body).toContain("not yet determined");
    // The fabricated zero must not appear anywhere in the table.
    expect(body).not.toContain("$0.00");
    // The real net estate still prints — only the undetermined amounts blank out.
    expect(body).toContain("$1,000,000.00");
    // Issue J: an undetermined distribution is not a reconciliation error. The old
    // copy invented a "$1,000,000.00 difference" out of an unrecorded answer.
    expect(body).not.toContain("does not equal net estate value");
    expect(body).toContain("cannot be totalled yet");
  });

  it("keeps the genuine reconciliation error when shares ARE allocated but do not add up", async () => {
    mocks.contacts = [SPOUSE, childContact("yes")];
    mocks.distribution = {
      shares: [{ contactId: "sp", name: "Jane Doe", relationship: "spouse", shareDescription: "50%", estimatedValueCents: 400_000_00, isComputed: false }],
      totalDistributionCents: 400_000_00, netEstateCents: 1_000_000_00, isReconciled: false,
      wesaSection: "s.21(3)", warnings: [],
    };
    const { DistributionCard, TooltipProvider } = await card();
    const { container } = render(
      <TooltipProvider>
        <DistributionCard estateId="estate-1" estate={INTESTACY_ESTATE} />
      </TooltipProvider>,
    );
    const body = container.textContent || "";
    expect(body).toContain("does not equal net estate value");
    expect(body).toContain("$600,000.00"); // the real difference still reported
  });

  it("still prints real figures once the branch is determined", async () => {
    mocks.contacts = [SPOUSE, childContact("yes")];
    mocks.distribution = {
      shares: [
        { contactId: "sp", name: "Jane Doe", relationship: "spouse", shareDescription: "Preferential share ($300,000.00) + ½ of residue (WESA s.21(3))", estimatedValueCents: 650_000_00, isComputed: true },
        { contactId: "kid-1", name: "Child A", relationship: "child", shareDescription: "Per stirpes share of ½ residue (WESA s.24)", estimatedValueCents: 350_000_00, isComputed: true },
      ],
      totalDistributionCents: 1_000_000_00, netEstateCents: 1_000_000_00, isReconciled: true,
      wesaSection: "s.21(3)", warnings: [],
    };
    const { DistributionCard, TooltipProvider } = await card();
    const { container } = render(
      <TooltipProvider>
        <DistributionCard estateId="estate-1" estate={INTESTACY_ESTATE} />
      </TooltipProvider>,
    );
    const body = container.textContent || "";
    expect(body).toContain("$650,000.00");
    expect(body).toContain("$350,000.00");
  });

  // Partial intestacy (WESA s.25) runs the same s.21 computation on the undisposed
  // portion, so the engine demands the answer — but the control was gated on
  // isIntestacy alone, so a probate + partialIntestacy file demanded an answer with
  // no way to give it. The file could never be reconciled from the UI.
  it("renders the control on a partial-intestacy TESTATE file, not just a pure intestacy", async () => {
    mocks.contacts = [SPOUSE, childContact("")];
    const { DistributionCard, TooltipProvider } = await card();
    render(
      <TooltipProvider>
        <DistributionCard
          estateId="estate-1"
          estate={{ id: "estate-1", grantType: "grant_of_probate", partialIntestacy: 1, testatePortionCents: 400_000_00 }}
        />
      </TooltipProvider>,
    );
    expect(screen.getByText(/Descendant Relationship to Spouse/)).toBeTruthy();
    expect(screen.getByRole("button", { name: "Yes" })).toBeTruthy();
  });

  it("drops the unanswered banner once every descendant is answered", async () => {
    mocks.contacts = [SPOUSE, childContact("yes")];
    const { DistributionCard, TooltipProvider } = await card();
    render(
      <TooltipProvider>
        <DistributionCard estateId="estate-1" estate={INTESTACY_ESTATE} />
      </TooltipProvider>,
    );

    expect(screen.queryByText(/not answered/)).toBeNull();
    expect(screen.queryByText(/print as blanks on Form P10/)).toBeNull();
    expect(screen.getByRole("button", { name: "Yes" }).className).toContain("bg-slate-700");
  });
});
