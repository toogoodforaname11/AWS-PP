/**
 * Intake de-duplication arc (RULES.md Rule 21 + 2026-08-05 de-dup) — wiring tests.
 *
 *  - the "usually the same" location subsection is collapsed by default,
 *    expands on click, and its "Same as residential" copy buttons write the
 *    residential value through normal dirty-tracked form state (never on render)
 *  - the VSA certificate result is asked ONCE, in Intake, retitled, with the
 *    notice-date field conditional on a found notice
 *  - the DocumentsTab wills-search tracking card is gone while the
 *    wills_notice_result required-document checkbox survives
 */
import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { REQUIRED_DOCUMENTS } from "@shared/types";

vi.setConfig({ testTimeout: 45000 }); // 2026-08-21: jsdom EstateDetail suites breached 15-20s under full-suite worker contention (flake class, memory probatepro-test-flakiness) — headroom, not speed, keeps the gate reproducible

// Same shim as the sibling EstateDetail specs (jsx:"preserve" under esbuild).
(globalThis as any).React = React;

vi.mock("sonner", () => ({
  toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }),
}));

const mocks = vi.hoisted(() => ({
  contacts: [] as any[],
  estateUpdateCalls: [] as any[],
  estateForGet: null as any,
  settings: { formFocusedIntake: false } as any,
}));

// Proxy auto-mock (EstateDetail.fix-applicability.test.tsx pattern): queries
// return harmless empty data, estate.update records its calls.
vi.mock("@/lib/trpc", () => {
  const queryDataFor = (key: string): any => {
    if (key === "contact.list") return mocks.contacts;
    if (key === "estate.get") return mocks.estateForGet;
    if (key === "settings.get") return mocks.settings;
    if (key === "notes.pinned" || key === "inventory.list" || key === "requiredDoc.list") return [];
    if (key === "system.aiFeatures") return { enabled: false };
    return undefined;
  };
  const mutationFor = (key: string) => ({
    mutate: (input: any) => { if (key === "estate.update") mocks.estateUpdateCalls.push(input); },
    mutateAsync: async (input: any) => {
      if (key === "estate.update") mocks.estateUpdateCalls.push(input);
      return { success: true };
    },
    isPending: false,
    isSuccess: false,
  });
  function utilsNode(path: string[]): any {
    return new Proxy({} as any, {
      get(_t, prop: string) {
        if (["invalidate", "setData", "cancel"].includes(prop)) return () => undefined;
        if (prop === "getData") return () => undefined;
        if (prop === "fetch") return async () => undefined;
        return utilsNode([...path, prop]);
      },
    });
  }
  function node(path: string[]): any {
    return new Proxy({} as any, {
      get(_t, prop: string) {
        if (prop === "useQuery") return () => ({ data: queryDataFor(path.join(".")), isLoading: false, error: null });
        if (prop === "useMutation") return () => mutationFor(path.join("."));
        if (prop === "useUtils") return () => utilsNode([]);
        return node([...path, prop]);
      },
    });
  }
  return { trpc: node([]) };
});

const ESTATE_BASE = {
  id: "estate-1",
  addressCity: "Vancouver",
  addressCountry: "Canada",
  domicileCity: "",
  deceasedResidenceCity: "",
  domicileCountry: "",
  vsaCertificateResult: "",
};

async function components() {
  const estateDetail = await import("./EstateDetail");
  const { TooltipProvider } = await import("@/components/ui/tooltip");
  return { ...estateDetail, TooltipProvider };
}

beforeEach(() => {
  mocks.contacts = [];
  mocks.estateUpdateCalls.length = 0;
  mocks.estateForGet = { ...ESTATE_BASE };
  mocks.settings = { formFocusedIntake: false };
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
  (globalThis as any).ResizeObserver = class {
    observe() {}
    unobserve() {}
    disconnect() {}
  };
  window.localStorage.clear();
});

describe("location subsection — one canonical last residential address", () => {
  it("does not re-ask residence, jurat, or P10/P11 legal determination fields in Intake", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE }} />
      </TooltipProvider>,
    );

    expect(screen.queryByLabelText("Domicile city (city where affidavits are sworn)")).toBeNull();
    expect(screen.queryByLabelText("Deceased's former city of residence")).toBeNull();
    expect(screen.queryByText("Was the deceased domiciled in British Columbia at the time of death?")).toBeNull();
    expect(screen.queryByText("Was the deceased ordinarily resident in British Columbia at the time of death?")).toBeNull();
    const addressGuidance = screen.getByRole("button", { name: "More information about deceased address guidance" });
    expect(addressGuidance.className).toContain("intake-info-tooltip-marker");
    expect(screen.queryByText(/This address supplies the deceased's location on P1, P2 and P17/i)).toBeNull();
    fireEvent.pointerMove(addressGuidance, { pointerType: "mouse" });
    expect(screen.queryByRole("tooltip")).toBeNull();
    await waitFor(() => expect(screen.getAllByText(/This address supplies the deceased's location on P1, P2 and P17/i).length).toBeGreaterThan(0));
    const tooltip = document.querySelector<HTMLElement>("[data-slot='tooltip-content']");
    expect(tooltip).not.toBeNull();
    expect(tooltip.className).toContain("bg-popover");
    expect(tooltip.className).toContain("text-popover-foreground");
    expect(tooltip.className).toContain("border-foreground/15");
    expect(tooltip.className).toContain("shadow-");
    expect(tooltip.className).toContain("fade-in-0");
    expect(tooltip.className).toContain("data-[state=closed]:fade-out-0");
    expect(tooltip.className).toContain("motion-reduce:animate-none");
  });

  it("never writes on render — no interaction, no save", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const { unmount } = render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE }} />
      </TooltipProvider>,
    );
    unmount();
    expect(mocks.estateUpdateCalls.length).toBe(0);
  });
});

describe("form-focused Intake mode", () => {
  it("shows grant and VSA explanatory guidance on hover or keyboard focus", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab
          estateId="estate-1"
          estate={{
            ...ESTATE_BASE,
            grantType: "grant_of_probate",
            vsaCertificateResult: "no_notice",
          }}
        />
      </TooltipProvider>,
    );

    const p4Override = screen.getByRole("button", { name: "More information about P4 long-form override guidance" });
    const grantTypes = screen.getByRole("button", { name: "More information about grant type definitions" });
    const vsaGuidance = screen.getByRole("button", { name: "More information about VSA wills notice search guidance" });

    [p4Override, grantTypes, vsaGuidance].forEach((trigger) => {
      expect(trigger.className).toContain("intake-info-tooltip-marker");
    });
    expect(screen.queryByText(/Override: forces Form P4/i)).toBeNull();
    expect(screen.queryByText(/Probate = named executor/i)).toBeNull();
    expect(screen.queryByText(/Record the result exactly as shown/i)).toBeNull();
    expect(screen.queryByText(/P3 §8 will state/i)).toBeNull();
    expect(screen.queryByText(/The search must cover the deceased's legal name/i)).toBeNull();

    fireEvent.pointerMove(p4Override, { pointerType: "mouse" });
    await waitFor(() => expect(screen.getAllByText(/Override: forces Form P4/i).length).toBeGreaterThan(0));

    fireEvent.pointerMove(grantTypes, { pointerType: "mouse" });
    await waitFor(() => expect(screen.getAllByText(/Probate = named executor/i).length).toBeGreaterThan(0));

    fireEvent.pointerMove(vsaGuidance, { pointerType: "mouse" });
    await waitFor(() => expect(screen.getAllByText(/Record the result exactly as shown/i).length).toBeGreaterThan(0));
    expect(screen.getAllByText(/P3 §8 will state/i).length).toBeGreaterThan(0);
    expect(screen.getAllByText(/The search must cover the deceased's legal name/i).length).toBeGreaterThan(0);
  });

  it("shows Notices and PGT guidance on hover or keyboard focus", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE }} />
      </TooltipProvider>,
    );

    const pgtInfo = screen.getByRole("button", { name: "More information about PGT notification guidance" });
    const contactsInfo = screen.getByRole("button", { name: "More information about notice contacts guidance" });
    expect(pgtInfo.className).toContain("intake-info-tooltip-marker");
    expect(contactsInfo.className).toContain("intake-info-tooltip-marker--contacts");
    expect(screen.queryByText(/Even if set to "No" here/i)).toBeNull();
    expect(screen.queryByText(/Answer "Yes" only after every executor/i)).toBeNull();

    fireEvent.pointerMove(pgtInfo, { pointerType: "mouse" });
    await waitFor(() => expect(screen.getAllByText(/Even if set to "No" here/i).length).toBeGreaterThan(0));

    fireEvent.pointerMove(contactsInfo, { pointerType: "mouse" });
    await waitFor(() => expect(screen.getAllByText(/Answer "Yes" only after every executor/i).length).toBeGreaterThan(0));
  });

  it("keeps every Intake guidance marker beside its question and opens it on touch", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab
          estateId="estate-1"
          estate={{
            ...ESTATE_BASE,
            willStatus: "no_will",
            grantType: "grant_of_admin",
            vsaCertificateResult: "no_notice",
          }}
        />
      </TooltipProvider>,
    );

    const guidanceRows: Array<[string, RegExp]> = [
      ["deceased address guidance", /Include street number or PO box/i],
      ["place of death guidance", /Place of death — city/i],
      ["VSA wills notice search guidance", /Result of VSA Wills Notice Search/i],
      ["grant type definitions", /Grant Type/i],
      ["P4 long-form override guidance", /Use long-form applicant affidavit/i],
      ["creditor notice review guidance", /Creditor notice review/i],
      ["PGT notification guidance", /Do you need to notify the PGT/i],
      ["notice contacts guidance", /Have all persons entitled to notice/i],
    ];

    for (const [label, question] of guidanceRows) {
      const trigger = screen.getByRole("button", { name: `More information about ${label}` });
      expect(trigger.closest(".flex")?.textContent).toMatch(question);
    }

    const p4Override = screen.getByRole("button", { name: "More information about P4 long-form override guidance" });
    expect(p4Override.getAttribute("aria-expanded")).toBeNull();
    fireEvent.pointerDown(p4Override, { pointerType: "touch" });
    expect(p4Override.getAttribute("aria-expanded")).toBe("true");
    await waitFor(() => expect(screen.getAllByText(/Override: forces Form P4/i).length).toBeGreaterThan(0));
    fireEvent.pointerDown(p4Override, { pointerType: "touch" });
    expect(p4Override.getAttribute("aria-expanded")).toBe("false");
  });

  it("hides only curated case-management fields while retaining the standard Intake by default", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const renderView = () => (
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE, grantIssuedDate: "2026-01-15" }} />
      </TooltipProvider>
    );
    const { rerender } = render(renderView());
    expect(screen.getByTestId("intake-mode-content").getAttribute("data-mode")).toBe("full");
    expect(screen.getByTestId("intake-mode-content").getAttribute("data-mode-transition")).toBe("smooth");
    expect(screen.queryByLabelText("SIN")).toBeNull();
    expect(screen.queryByLabelText("TIN")).toBeNull();
    expect(screen.getByTestId("intake-case-management-file-fields")).toBeTruthy();
    expect(screen.getByText("Post-grant statutory periods")).toBeTruthy();
    expect(screen.getByTestId("intake-section-progress")).toBeTruthy();
    expect(screen.getByTestId("vsa-applicant-contact-advisory")).toBeTruthy();
    expect(screen.getByText(/If a form needs a separate WESA s\.2 spouse determination/i)).toBeTruthy();
    expect(screen.getByText(/Citations are recorded per cited person/i)).toBeTruthy();

    mocks.settings = { formFocusedIntake: true };
    rerender(renderView());
    expect(screen.getByTestId("intake-mode-content").getAttribute("data-mode")).toBe("form-focused");
    await waitFor(() => expect(screen.queryByTestId("intake-case-management-file-fields")).toBeNull());
    await waitFor(() => expect(screen.queryByText("Post-grant statutory periods")).toBeNull());
    expect(screen.queryByTestId("intake-section-progress")).toBeNull();
    expect(screen.queryByTestId("form-focused-intake-notice")).toBeNull();
    expect(screen.queryByTestId("vsa-applicant-contact-advisory")).toBeNull();
    expect(screen.queryByText(/If a form needs a separate WESA s\.2 spouse determination/i)).toBeNull();
    expect(screen.queryByText(/Citations are recorded per cited person/i)).toBeNull();
    expect(screen.getByLabelText("Court Registry")).toBeTruthy();
    expect(screen.getByText("Date of Death *")).toBeTruthy();

    mocks.settings = { formFocusedIntake: false };
    rerender(renderView());
    expect(screen.getByTestId("intake-case-management-file-fields").className).toContain("form-focused-field-reveal");
    expect(screen.getByTestId("intake-post-grant-tracking").className).toContain("form-focused-field-reveal");
  });

  it("keeps the P5 statutory-priority control compact while retaining the full legal choices", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE, willStatus: "no_will", applicantPriorityParagraph: "c" }} />
      </TooltipProvider>,
    );

    const trigger = screen.getByTestId("p5-priority-trigger");
    expect(trigger.textContent).toBe("c — Child nominee — majority consent");
    expect(trigger.className).toContain("w-full");
    expect(screen.getByTestId("p5-priority-control").className).toContain("max-w-[34rem]");

    fireEvent.click(trigger);
    const option = screen.getByRole("option", { name: /e\.1.*a person, other than the spouse or child/i });
    expect(screen.getByTestId("p5-priority-options").className).toContain("max-h-[min(24rem,var(--radix-select-content-available-height))]");
    expect(option.className).toContain("hover:bg-primary/[0.06]");
    fireEvent.click(option);

    await waitFor(() => expect(trigger.textContent).toBe("e.1 — Successor's nominee — majority consent"));
  });

  it("keeps document-driving codicil and limited-grant facts, but hides their case-file-only companion fields", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    mocks.settings = { formFocusedIntake: true };
    render(
      <TooltipProvider>
        <IntakeTab
          estateId="estate-1"
          estate={{
            ...ESTATE_BASE,
            willStatus: "will",
            limitedGrant: 1,
            grantLimitation: "Limited to the real property at 123 Main Street.",
            codicilCount: 2,
            codicilDates: "2020-01-15, 2021-06-30",
          }}
        />
      </TooltipProvider>,
    );

    expect(screen.getByText("Number of Codicils")).toBeTruthy();
    expect(screen.getByLabelText("This is a limited grant")).toBeTruthy();
    expect(screen.queryByText("Codicil Dates (comma-separated)")).toBeNull();
    expect(screen.queryByText("Grant Limitation (describe the limitation)")).toBeNull();
  });

  it("excludes non-form occupation, PGT grant-tracking, and early-application records", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    mocks.settings = { formFocusedIntake: true };
    render(
      <TooltipProvider>
        <IntakeTab
          estateId="estate-1"
          estate={{
            ...ESTATE_BASE,
            notifyPGT: "yes",
            grantIssuedDate: "2026-01-15",
            pgtCommentsProvidedToCourt: 1,
            pgtCommentsProvidedToCourtDate: "2026-01-12",
            p1EarlyApplicationOrderDate: "2026-01-01",
            p1EarlyApplicationPermittedDate: "2026-01-10",
          }}
        />
      </TooltipProvider>,
    );

    expect(screen.getByText("Do you need to notify the PGT?")).toBeTruthy();
    expect(screen.queryByText("Deceased's Occupation")).toBeNull();
    expect(screen.queryByText("WESA s.124 grant conditions")).toBeNull();
    expect(screen.queryByText("Date copy of representation grant provided to PGT")).toBeNull();
    expect(screen.queryByText("Court-ordered earlier application date")).toBeNull();
  });
});

describe("civil status and WESA spouse determination", () => {
  it("keeps civil marital status as the single Intake entry and directs WESA review to relevant Generate Anyway flows", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE }} />
      </TooltipProvider>,
    );

    expect(screen.getByText("Civil marital status at death *")).toBeTruthy();
    expect(screen.getByText("Death-certificate status used for the prescribed civil-status wording on Form P2.")).toBeTruthy();
    expect(screen.getByText(/If a form needs a separate WESA s.2 spouse determination/i)).toBeTruthy();
    expect(screen.queryByText("WESA spouse determination at death *")).toBeNull();
    expect(screen.queryByText("Separation date (required when the spouses were separated)")).toBeNull();
  });
});

describe("person-specific Contact sources", () => {
  it("removes the duplicate spouse-name input and directs the user to the canonical Contact record", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const navigateToContacts = vi.fn();
    render(
      <TooltipProvider>
        <IntakeTab
          estateId="estate-1"
          estate={{ ...ESTATE_BASE, maritalStatus: "married", spouseName: "Legacy Spouse" }}
          onNavigateToContacts={navigateToContacts}
        />
      </TooltipProvider>,
    );

    expect(screen.queryByLabelText("Spouse / Common-law Partner Name")).toBeNull();
    expect(screen.getByText("Spouse details come from Contacts")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: /open spouse contact/i }));
    expect(navigateToContacts).toHaveBeenCalledTimes(1);
  });

  it("removes the duplicate applicant-type selector and directs applicant identity to Contacts", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const navigateToContacts = vi.fn();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE }} onNavigateToContacts={navigateToContacts} />
      </TooltipProvider>,
    );

    expect(screen.queryByText("Who is the applicant for the grant?")).toBeNull();
    expect(screen.getByText("Applicant details come from Contacts")).toBeTruthy();
    fireEvent.click(screen.getAllByRole("button", { name: /open applicant contact/i })[0]!);
    expect(navigateToContacts).toHaveBeenCalledTimes(1);
  });
});

describe("deceased alias source of truth", () => {
  it("keeps a client-reported full alias in the list editor without treating it as an AKA first name", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab
          estateId="estate-1"
          estate={{
            ...ESTATE_BASE,
            hasOtherNames: "yes",
            deceasedAliases: "TEST Alias",
            akaFirstName: "",
            akaMiddleName: "",
            akaLastName: "",
            hasAdditionalNames: "no",
          }}
        />
      </TooltipProvider>,
    );

    expect((screen.getByLabelText("AKA First Name") as HTMLInputElement).value).toBe("");
    expect((screen.getByLabelText("AKA Middle Name") as HTMLInputElement).value).toBe("");
    expect((screen.getByLabelText("AKA Last Name") as HTMLInputElement).value).toBe("");
    expect((screen.getByLabelText("Aliases (one per line)") as HTMLTextAreaElement).value).toBe("TEST Alias");
  });

  it("retains client-reported aliases alongside an existing structured AKA", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab
          estateId="estate-1"
          estate={{
            ...ESTATE_BASE,
            hasOtherNames: "yes",
            deceasedAliases: "TEST Alias",
            akaFirstName: "Existing",
            akaMiddleName: "",
            akaLastName: "AKA",
            hasAdditionalNames: "yes",
          }}
        />
      </TooltipProvider>,
    );

    expect((screen.getByLabelText("AKA First Name") as HTMLInputElement).value).toBe("Existing");
    expect((screen.getByLabelText("AKA Last Name") as HTMLInputElement).value).toBe("AKA");
    expect((screen.getByLabelText("Additional aliases (one per line)") as HTMLTextAreaElement).value).toBe("TEST Alias");
  });

  it("shows a newly applied portal alias when the first alias already occupies the structured AKA fields", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab
          estateId="estate-1"
          estate={{
            ...ESTATE_BASE,
            hasOtherNames: "yes",
            deceasedAliases: "TEST Alias Two",
            akaFirstName: "TEST",
            akaMiddleName: "",
            akaLastName: "Alias",
            hasAdditionalNames: "no",
          }}
        />
      </TooltipProvider>,
    );

    expect((screen.getByLabelText("AKA First Name") as HTMLInputElement).value).toBe("TEST");
    expect((screen.getByLabelText("AKA Last Name") as HTMLInputElement).value).toBe("Alias");
    expect(
      (screen.getByLabelText("Additional aliases (one per line)") as HTMLTextAreaElement).value,
    ).toBe("TEST Alias Two");
  });

  it("shows only the latest approved portal alias alongside a structured AKA", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab
          estateId="estate-1"
          estate={{
            ...ESTATE_BASE,
            hasOtherNames: "yes",
            deceasedAliases: "TEST Alias Six",
            akaFirstName: "TEST",
            akaMiddleName: "",
            akaLastName: "Alias",
            hasAdditionalNames: "yes",
          }}
        />
      </TooltipProvider>,
    );

    expect((screen.getByLabelText("AKA First Name") as HTMLInputElement).value).toBe("TEST");
    expect((screen.getByLabelText("AKA Last Name") as HTMLInputElement).value).toBe("Alias");
    expect(
      (screen.getByLabelText("Additional aliases (one per line)") as HTMLTextAreaElement).value,
    ).toBe("TEST Alias Six");
  });
});

describe("VSA single home (RULES.md Rule 21)", () => {
  it("intake carries the retitled certificate-result section; the date appears only when a notice was found", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const { unmount } = render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE }} />
      </TooltipProvider>,
    );
    expect(screen.getByText("Wills Notice Search Result (from the certificate)")).toBeTruthy();
    expect(screen.queryByLabelText("Date on the Wills Notice")).toBeNull();
    unmount();

    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE, vsaCertificateResult: "wills_notice_found" }} />
      </TooltipProvider>,
    );
    expect(screen.getByLabelText("Date on the Wills Notice")).toBeTruthy();
  });

  it("keeps the VSA result that selects form wording but hides readiness-only searched names in form-focused Intake", async () => {
    mocks.settings = { formFocusedIntake: true };
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE, vsaCertificateResult: "no_notice", vsaNamesSearched: "Hector Nicolson" }} />
      </TooltipProvider>,
    );

    expect(screen.getByText("Result of VSA Wills Notice Search (Form P3 §8 / P4 §4)")).toBeTruthy();
    expect(screen.queryByLabelText("Names searched (as shown on the VSA 532 certificate)")).toBeNull();

    const vsaGuidance = screen.getByRole("button", { name: "More information about VSA wills notice search guidance" });
    fireEvent.pointerMove(vsaGuidance, { pointerType: "mouse" });
    await waitFor(() => expect(screen.getAllByText(/Record the result exactly as shown/i).length).toBeGreaterThan(0));
    expect(screen.queryByText(/The search must cover the deceased's legal name/i)).toBeNull();
  });

  // Rule 24 (2026-08-17): the Documents tab is gone; the checklist card
  // (Rule 21's certificate tracker) lives on, relocated to the Readiness tab.
  it("RequiredSourceDocumentsCard has no wills-search card but keeps the certificate required-document checkbox", async () => {
    const { RequiredSourceDocumentsCard } = await components();
    render(<RequiredSourceDocumentsCard estateId="estate-1" />);

    expect(screen.queryByTestId("wills-search-card")).toBeNull();
    const certificateDoc = REQUIRED_DOCUMENTS.find((d) => d.key === "wills_notice_result");
    expect(certificateDoc).toBeTruthy();
    expect(screen.getByText(certificateDoc!.name)).toBeTruthy();
  });

  it("keeps long required-document labels inside a flexible, wrapping text column", async () => {
    const { RequiredSourceDocumentsCard } = await components();
    render(<RequiredSourceDocumentsCard estateId="estate-1" />);

    const certificateDoc = REQUIRED_DOCUMENTS.find((d) => d.key === "wills_notice_result");
    const label = screen.getByText(certificateDoc!.name).closest("label");
    expect(label?.className).toContain("break-words");
    expect(label?.parentElement?.className).toContain("min-w-0");
    expect(label?.parentElement?.className).toContain("flex-1");
  });
});

describe("VSA applicant contact source of truth", () => {
  it("removes duplicate applicant inputs and presents the applying contact details", async () => {
    mocks.contacts = [{
      id: "applicant-1",
      role: "applicant",
      executorRank: "primary",
      name: "Jordan Lee",
      postalAddress: "400 Harbour Street, Vancouver, BC V5K 2B3",
    }];
    const navigateToContacts = vi.fn();
    const { IntakeTab, TooltipProvider } = await components();
    const { unmount } = render(
      <TooltipProvider>
        <IntakeTab
          estateId="estate-1"
          estate={{ ...ESTATE_BASE, applicantFirstNames: "Legacy", applicantSurname: "Applicant", applicantPostalCode: "V6B 1A1" }}
          onNavigateToContacts={navigateToContacts}
        />
      </TooltipProvider>,
    );

    expect(screen.queryByLabelText("First Names (given names)")).toBeNull();
    expect(screen.queryByLabelText("Surname (family name)")).toBeNull();
    expect(screen.queryByLabelText("Applicant's Postal Code")).toBeNull();
    expect(screen.getByText("VSA 532 applicant details come from Contacts")).toBeTruthy();
    expect(screen.getByText(/Jordan Lee/)).toBeTruthy();
    expect(screen.getByText(/V5K 2B3/)).toBeTruthy();
    fireEvent.click(screen.getAllByRole("button", { name: /open applicant contact/i }).at(-1)!);
    expect(navigateToContacts).toHaveBeenCalledTimes(1);
    unmount();
  });
});

describe("staff Intake inline validation feedback", () => {
  it("waits until a required field is touched, then announces its correction and success state", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE }} />
      </TooltipProvider>,
    );

    const firstNames = screen.getByLabelText("First Names (given names) *");
    expect(firstNames.getAttribute("aria-invalid")).toBeNull();

    fireEvent.blur(firstNames);
    expect(firstNames.getAttribute("aria-invalid")).toBe("true");
    expect(screen.getAllByRole("alert").some((alert) => alert.textContent?.includes("Enter the deceased's first names."))).toBe(true);

    fireEvent.change(firstNames, { target: { value: "Avery" } });
    expect(firstNames.getAttribute("aria-invalid")).toBeNull();
    expect(screen.getAllByText("Recorded").length).toBeGreaterThan(0);
  });

  it("offers a keyboard-accessible correction tooltip only while an invalid field needs it", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE }} />
      </TooltipProvider>,
    );

    const firstNames = screen.getByLabelText("First Names (given names) *");
    fireEvent.blur(firstNames);

    const correction = screen.getByRole("button", { name: "How to correct First Names (given names)" });
    fireEvent.focus(correction);
    expect((await screen.findByRole("tooltip")).textContent).toContain("Enter every given name exactly as it appears on the death certificate.");
    expect(mocks.estateUpdateCalls).toHaveLength(0);

    fireEvent.change(firstNames, { target: { value: "Avery" } });
    expect(screen.queryByRole("button", { name: "How to correct First Names (given names)" })).toBeNull();
  });

  it("corrects cross-field date guidance immediately without blocking the Intake draft", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE }} />
      </TooltipProvider>,
    );

    const dateOfBirth = screen.getByLabelText("Date of Birth");
    const dateOfDeath = screen.getByLabelText("Date of Death *");
    fireEvent.change(dateOfDeath, { target: { value: "2025-01-01" } });
    fireEvent.change(dateOfBirth, { target: { value: "2026-01-01" } });

    expect(dateOfBirth.getAttribute("aria-invalid")).toBe("true");
    expect(screen.getAllByRole("alert").some((alert) => alert.textContent?.includes("Date of birth must be before date of death."))).toBe(true);

    fireEvent.change(dateOfBirth, { target: { value: "1940-01-01" } });
    expect(dateOfBirth.getAttribute("aria-invalid")).toBeNull();
    expect(screen.queryByText("Date of birth must be before date of death.")).toBeNull();
  });

  it("collects and saves the death-certificate place-of-death city beside the last residence", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE }} />
      </TooltipProvider>,
    );

    const placeOfDeath = screen.getByLabelText("Place of death — city");
    const placeOfDeathGuidance = screen.getByRole("button", { name: "More information about place of death guidance" });
    expect(placeOfDeathGuidance.className).toContain("intake-info-tooltip-marker");
    expect(screen.queryByText(/Enter the city exactly as shown on the death certificate/i)).toBeNull();
    fireEvent.pointerMove(placeOfDeathGuidance, { pointerType: "mouse" });
    await waitFor(() => expect(screen.getAllByText(/Enter the city exactly as shown on the death certificate/i).length).toBeGreaterThan(0));
    fireEvent.change(placeOfDeath, { target: { value: "Colwood" } });
    fireEvent.click(screen.getByRole("button", { name: "Save Changes" }));

    expect(mocks.estateUpdateCalls.at(-1)?.data).toEqual(expect.objectContaining({ placeOfDeath: "Colwood" }));
  });

  it("keeps creditor-review instruction behind its own information control", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE, willStatus: "no_will", grantType: "grant_of_admin" }} />
      </TooltipProvider>,
    );

    const creditorGuidance = screen.getByRole("button", { name: "More information about creditor notice review guidance" });
    expect(creditorGuidance.className).toContain("intake-info-tooltip-marker");
    expect(screen.queryByText(/Rule 25-2\(2\)\(b\)\(ii\) requires P1 notice/i)).toBeNull();
    fireEvent.pointerMove(creditorGuidance, { pointerType: "mouse" });
    await waitFor(() => expect(screen.getAllByText(/Rule 25-2\(2\)\(b\)\(ii\) requires P1 notice/i).length).toBeGreaterThan(0));
  });
});
