import React from "react";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.setConfig({ testTimeout: 45000 });
(globalThis as any).React = React;
vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }) }));
const state = vi.hoisted(() => ({
  stored: {} as Record<string, any>, cached: {} as Record<string, any>,
  saves: [] as any[], preflights: [] as any[], generated: [] as any[], effectiveAtGeneration: [] as any[],
  ops: [] as string[], saveGate: null as Promise<void> | null,
  saveFails: false, saveResponseFails: false, recheckFails: false, generationFails: false,
}));
vi.mock("@/lib/trpc", () => {
  const applicant = { id: "popup-applicant", role: "applicant,executor", executorStatus: "applying", executorRank: "primary", name: "Fictional Applicant", relationship: "child" };
  function utilities(path: string[]): any {
    return new Proxy({}, { get(_target, prop: string) {
      const key = path.join(".");
      if (prop === "getData") return () => key === "estate.get" ? state.cached : undefined;
      if (prop === "setData") return (_input: unknown, updater: any) => { if (key === "estate.get") state.cached = typeof updater === "function" ? updater(state.cached) : updater; };
      if (prop === "invalidate") return async () => { if (key === "document.preflight") state.ops.push("invalidate:preflight"); };
      if (prop === "cancel") return () => undefined;
      if (prop === "fetch") return async (input: any) => {
        if (key === "estate.get") { state.cached = { ...state.stored }; return state.stored; }
        if (key === "document.preflightMany") return [];
        if (key !== "document.preflight") return undefined;
        state.ops.push("fetch:preflight"); state.preflights.push(input);
        if (state.recheckFails && state.preflights.length > 1) { state.recheckFails = false; throw new Error("Fictional re-check failure"); }
        const effective = { ...state.stored, ...input.overrides };
        const gaps = effective.willStatus === "unknown" ? [{
          requirementId: "p5_will_status_required", label: "Will status is not recorded.",
          missingFields: ["estate.willStatus"], tab: "intake", source: "Existing recorded will status",
        }] : [];
        return { formCode: "P5", ok: gaps.length === 0, hardBlocked: false, gaps };
      };
      return utilities([...path, prop]);
    } });
  }
  function mutation(key: string, options?: any) {
    const mutateAsync = async (input: any) => {
      try {
        let result: any = { success: true };
        if (key === "estate.update") {
          state.ops.push("save:start");
          if (state.saveGate) await state.saveGate;
          if (state.saveFails) throw new Error("Fictional CAS conflict");
          if (input.expectedRevision !== state.stored.revision) throw new Error("Unexpected stale revision");
          state.saves.push(input);
          state.stored = { ...state.stored, ...input.data, revision: state.stored.revision + 1 };
          state.ops.push("save:commit");
          if (state.saveResponseFails) { state.saveResponseFails = false; state.cached = { ...state.stored }; throw new Error("Fictional response loss after commit"); }
          result = { success: true, revision: state.stored.revision };
        }
        if (key === "document.generate") {
          state.ops.push("generate"); state.generated.push(input);
          state.effectiveAtGeneration.push({ ...state.stored, ...input.overrides });
          if (state.generationFails) throw new Error("Fictional generation failure");
          result = { id: "popup-doc", filename: "P5_Fictional.docx", format: "docx", delivery: {
            method: "POST", action: "/api/download/form", fields: { estateId: "popup-estate", formCode: "P5", documentId: "popup-doc" },
          } };
        }
        await options?.onSuccess?.(result, input, undefined);
        return result;
      } catch (error) { await options?.onError?.(error, input, undefined); throw error; }
    };
    return { mutateAsync, mutate: (input: any) => { void mutateAsync(input).catch(() => undefined); }, isPending: false };
  }
  function node(path: string[]): any {
    return new Proxy({}, { get(_target, prop: string) {
      if (prop === "useUtils") return () => utilities([]);
      if (prop === "useMutation") return (options: any) => mutation(path.join("."), options);
      if (prop === "useQuery") return () => ({
        data: path.join(".") === "contact.list" ? [applicant] : path.join(".") === "estate.get" ? state.cached
          : ["document.list", "document.versions", "document.retainedFiles", "document.getLetterRecipients", "citation.list", "delivery.list", "delivery.getRecipients"].includes(path.join(".")) ? [] : undefined,
        isLoading: false, error: null,
      });
      return node([...path, prop]);
    } });
  }
  return { trpc: node([]) };
});
const downloads: Record<string, FormDataEntryValue>[] = [];
beforeEach(() => {
  cleanup(); vi.clearAllMocks();
  state.stored = {
    id: "popup-estate", revision: 4, grantType: "grant_of_probate", willStatus: "unknown", hasWill: 1,
    deceasedFirstName: "Fictional", deceasedLastName: "Popup", willType: "physical", willFilingType: "physical_original",
    willDate: "2024-01-15", willStorageKey: "fictional-only/will.pdf", isElectronicWill: 0,
    testamentaryDocStatus: "none_found", beliefLastBcWill: "yes", specialCircumstances: "none", foreignWillStatus: "made_in_bc",
    wesaS58Reliance: "no", ordersAffectingWill: "no", vsaCertificateResult: "no_notice", isMilitaryWill: "no",
    executionIssues: "no_issues", willAlterations: "no_alterations", willAppearanceIssues: "no", referencedDocuments: "no",
    willDocumentsAttached: "yes", otherGrantsStatus: "no_other_grants", notifyPGT: "no", pgtIsApplicant: "no",
    p1NotRequired: 1, deceasedDomiciledInBC: "yes", codicilFiles: "[]", applicantType: "executor",
    intestateConsentState: "majority_consent", applicantIsNominee: 0, applicantIsGovernmentNominee: 0,
  };
  state.cached = { ...state.stored };
  for (const values of [state.saves, state.preflights, state.generated, state.effectiveAtGeneration, state.ops, downloads]) values.length = 0;
  state.saveGate = null; state.saveFails = false; state.saveResponseFails = false; state.recheckFails = false; state.generationFails = false;
  for (const [name, value] of Object.entries({ hasPointerCapture: (): boolean => false, setPointerCapture: (): void => {}, releasePointerCapture: (): void => {}, scrollIntoView: (): void => {} })) {
    Object.defineProperty(Element.prototype, name, { value, configurable: true });
  }
  vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) { downloads.push(Object.fromEntries(new FormData(this))); });
});
afterEach(() => { cleanup(); vi.restoreAllMocks(); });
async function chooseCanonicalNoWill() {
  fireEvent.click(screen.getByTestId("pre-generate-canonical-willStatus"));
  fireEvent.click(await screen.findByRole("option", { name: "No will" }));
}
async function openGap(options: { retainedUnknownOverride?: boolean } = {}) {
  if (options.retainedUnknownOverride) {
    state.stored.willStatus = "will"; state.cached = { ...state.stored };
  }
  const { FormsTab } = await import("./EstateDetail");
  render(<FormsTab estateId="popup-estate" estate={{ ...state.stored }} onNavigateToTab={vi.fn()} />);
  fireEvent.click(screen.getByTestId("form-generate-P5"));
  await waitFor(() => expect(screen.getByTestId("fix-confirm")).toBeTruthy());
  if (options.retainedUnknownOverride) {
    const willStatus = screen.getByTestId("fix-question-willStatus");
    fireEvent.click(Array.from(willStatus.querySelectorAll("button")).find(button => button.textContent === "Not confirmed")!);
    fireEvent.click(screen.getByTestId("fix-question-applicantIsNominee"));
  }
  fireEvent.click(screen.getByTestId("fix-confirm"));
  await waitFor(() => expect(screen.getByTestId("form-details-generate")).toBeTruthy());
  fireEvent.click(screen.getByTestId("form-details-generate"));
  await waitFor(() => expect(screen.getByTestId("pre-generate-canonical-willStatus")).toBeTruthy());
}

describe("real single-form popup → canonical save → fresh generation", () => {
  it("saves the explicit Will Status with CAS, invalidates, rechecks and generates from the saved facts once", async () => {
    await openGap(); await chooseCanonicalNoWill();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(state.saves).toEqual([{ id: "popup-estate", expectedRevision: 4, data: { willStatus: "no_will", hasWill: 0 } }]);
    expect(state.generated).toHaveLength(1);
    expect(state.effectiveAtGeneration[0]).toMatchObject({ willStatus: "no_will", hasWill: 0 });
    expect(state.generated[0].overrides).not.toHaveProperty("willStatus");
    const saved = state.ops.indexOf("save:commit");
    expect(saved).toBeGreaterThan(-1);
    const drop = state.ops.indexOf("invalidate:preflight", saved + 1);
    expect(drop).toBeGreaterThan(saved);
    expect(state.ops.indexOf("fetch:preflight", drop + 1)).toBeGreaterThan(drop);
    expect(state.ops.indexOf("generate")).toBeGreaterThan(drop);
    // The existing FormsTab affidavit guard uses the selected executor,
    // not the lawyer-signature mode for non-affidavit documents.
    expect(state.generated[0]).toMatchObject({ formCode: "P5", selectedContactId: "popup-applicant", generateAnyway: true, signatoryType: "executor" });
  });

  it("does not generate before a pending save completes", async () => {
    let release!: () => void; state.saveGate = new Promise<void>(resolve => { release = resolve; });
    await openGap(); await chooseCanonicalNoWill();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.ops).toContain("save:start"));
    expect(state.generated).toEqual([]); expect(downloads).toEqual([]);
    await act(async () => { release(); });
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(state.generated).toHaveLength(1);
  });

  it.each(["pre-generate-apply", "pre-generate-proceed"])("keeps a newer answer pending when the old %s save rechecks all-green", async (button) => {
    let release!: () => void; state.saveGate = new Promise<void>(resolve => { release = resolve; });
    await openGap(); await chooseCanonicalNoWill();
    fireEvent.click(screen.getByTestId(button));
    await waitFor(() => expect(state.ops).toContain("save:start"));
    fireEvent.click(screen.getByTestId("pre-generate-canonical-willStatus"));
    fireEvent.click(await screen.findByRole("option", { name: "Not confirmed" }));
    await act(async () => { release(); });
    await waitFor(() => expect(state.generated.length > 0 || (screen.queryByTestId("pre-generate-apply") as HTMLButtonElement | null)?.disabled === false).toBe(true));
    expect(state.generated).toEqual([]);
    expect(downloads).toEqual([]);
    expect(screen.getByTestId("pre-generate-canonical-willStatus").textContent).toContain("Not confirmed");
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(state.saves).toHaveLength(2);
    expect(state.generated).toHaveLength(1);
    expect(state.effectiveAtGeneration[0]).toMatchObject({ willStatus: "unknown", hasWill: 1 });
  });

  it("keeps typed input and blocks dispatch on CAS failure, then retries through the same real dialog", async () => {
    state.saveFails = true;
    await openGap(); await chooseCanonicalNoWill();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.ops).toContain("save:start"));
    await waitFor(() => expect((screen.getByTestId("pre-generate-proceed") as HTMLButtonElement).disabled).toBe(false));
    expect(state.saves).toEqual([]); expect(state.generated).toEqual([]);
    expect(screen.getByTestId("pre-generate-canonical-willStatus").textContent).toContain("No will");
    state.saveFails = false;
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(state.effectiveAtGeneration[0]).toMatchObject({ willStatus: "no_will", hasWill: 0 });
  });

  it("does not revive a cancelled pending generation when its already-started save returns", async () => {
    let release!: () => void; state.saveGate = new Promise<void>(resolve => { release = resolve; });
    await openGap(); await chooseCanonicalNoWill();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.ops).toContain("save:start"));
    fireEvent.click(screen.getByTestId("pre-generate-cancel"));
    await act(async () => { release(); await Promise.resolve(); });
    expect(state.generated).toEqual([]); expect(downloads).toEqual([]);
    expect(state.saves).toHaveLength(1); // cancellation is not a database rollback
  });

  it("does not generate from a failed recheck and retains answers for an explicit retry", async () => {
    state.recheckFails = true;
    await openGap(); await chooseCanonicalNoWill();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.preflights).toHaveLength(2));
    await waitFor(() => expect((screen.getByTestId("pre-generate-proceed") as HTMLButtonElement).disabled).toBe(false));
    expect(state.generated).toEqual([]); expect(downloads).toEqual([]);
    expect(screen.getByTestId("pre-generate-canonical-willStatus").textContent).toContain("No will");
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(state.generated).toHaveLength(1);
    expect(state.effectiveAtGeneration[0].willStatus).toBe("no_will");
    expect(state.saves).toHaveLength(1);
  });

  it("applies an answer reverted to its opening value after the prior save committed but recheck failed", async () => {
    state.recheckFails = true;
    await openGap(); await chooseCanonicalNoWill();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.preflights).toHaveLength(2));
    await waitFor(() => expect((screen.getByTestId("pre-generate-proceed") as HTMLButtonElement).disabled).toBe(false));
    expect(state.stored.willStatus).toBe("no_will");
    expect(state.generated).toEqual([]);
    fireEvent.click(screen.getByTestId("pre-generate-canonical-willStatus"));
    fireEvent.click(await screen.findByRole("option", { name: "Not confirmed" }));
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(state.saves).toHaveLength(2);
    expect(state.saves[1]).toMatchObject({ expectedRevision: 5, data: { willStatus: "unknown", hasWill: 1 } });
    expect(state.effectiveAtGeneration[0]).toMatchObject({ willStatus: "unknown", hasWill: 1 });
    expect(state.generated).toHaveLength(1);
  });

  it("does not lose a deliberate reversion after a write's acknowledgement was lost", async () => {
    state.saveResponseFails = true;
    await openGap(); await chooseCanonicalNoWill();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.saves).toHaveLength(1));
    await waitFor(() => expect((screen.getByTestId("pre-generate-proceed") as HTMLButtonElement).disabled).toBe(false));
    expect(state.stored.willStatus).toBe("no_will");
    expect(state.generated).toEqual([]);
    fireEvent.click(screen.getByTestId("pre-generate-canonical-willStatus"));
    fireEvent.click(await screen.findByRole("option", { name: "Not confirmed" }));
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(state.saves).toHaveLength(2);
    expect(state.saves[1]).toMatchObject({ expectedRevision: 5, data: { willStatus: "unknown", hasWill: 1 } });
    expect(state.effectiveAtGeneration[0]).toMatchObject({ willStatus: "unknown", hasWill: 1 });
  });

  it("removes only the superseded same-field draft choices while keeping unrelated optional answers and the deponent", async () => {
    await openGap({ retainedUnknownOverride: true });
    expect(state.preflights[0].overrides).toMatchObject({ willStatus: "unknown", hasWill: 1, applicantIsNominee: 1 });
    await chooseCanonicalNoWill();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(state.generated[0].overrides).not.toHaveProperty("willStatus");
    expect(state.generated[0].overrides).not.toHaveProperty("hasWill");
    expect(state.generated[0].overrides).toMatchObject({ applicantIsNominee: 1 });
    expect(state.generated[0].selectedContactId).toBe("popup-applicant");
    expect(state.effectiveAtGeneration[0]).toMatchObject({ willStatus: "no_will", hasWill: 0, applicantIsNominee: 1 });
  });

  it("keeps the saved facts on generation failure and retries without a second generation in the failed attempt", async () => {
    state.generationFails = true;
    await openGap(); await chooseCanonicalNoWill();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.generated).toHaveLength(1));
    await waitFor(() => expect((screen.getByTestId("pre-generate-proceed") as HTMLButtonElement).disabled).toBe(false));
    expect(downloads).toEqual([]);
    state.generationFails = false;
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(state.generated).toHaveLength(2);
    expect(state.effectiveAtGeneration.every(value => value.willStatus === "no_will" && value.hasWill === 0)).toBe(true);
  });
});
