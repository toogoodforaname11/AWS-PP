import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

// Heavy jsdom file: each test does `await import("./EstateDetail")` (a very large module)
// inside the test body, so the first render sits ~5.5s — right at vitest's 5000ms default
// testTimeout. Raise the per-file ceiling so parallel-fork contention can't tip it over.
// A genuinely hung test still fails (at 15s). ponytail: bump to 20000 if CI still flakes.
vi.setConfig({ testTimeout: 45000 }); // 2026-08-21: jsdom EstateDetail suites breached 15-20s under full-suite worker contention (flake class, memory probatepro-test-flakiness) — headroom, not speed, keeps the gate reproducible

const mocks = vi.hoisted(() => ({
  deliveries: [] as any[],
  recipients: [] as any[],
  upsertMutate: vi.fn(),
  bulkMutate: vi.fn(),
  markP44MutateAsync: vi.fn(async () => ({})),
}));

vi.mock("sonner", () => ({
  toast: {
    success: vi.fn(),
    error: vi.fn(),
    info: vi.fn(),
  },
}));

vi.mock("@/lib/trpc", () => {
  const idleMutation = () => ({
    mutate: vi.fn(),
    mutateAsync: vi.fn(async () => ({ key: "test-key" })),
    isPending: false,
  });
  return {
    trpc: {
      document: {
        generate: { useMutation: idleMutation },
      },
      delivery: {
        list: { useQuery: () => ({ data: mocks.deliveries, isLoading: false }) },
        getRecipients: { useQuery: () => ({ data: mocks.recipients }) },
        upsert: { useMutation: () => ({ mutate: mocks.upsertMutate, mutateAsync: vi.fn(async (x: any) => { mocks.upsertMutate(x); return x; }), isPending: false }) },
        delete: { useMutation: idleMutation },
        bulkCreate: { useMutation: () => ({ mutate: mocks.bulkMutate, isPending: false }) },
        updateP46: { useMutation: idleMutation },
        markP44: { useMutation: () => ({ mutate: vi.fn(), mutateAsync: mocks.markP44MutateAsync, isPending: false }) },
        uploadDispensationOrder: { useMutation: idleMutation },
        deleteDispensationOrder: { useMutation: idleMutation },
      },
      useUtils: () => ({
        delivery: { list: { invalidate: vi.fn() } },
        readiness: { check: { invalidate: vi.fn() } },
      }),
    },
  };
});

async function components() {
  const estateDetail = await import("./EstateDetail");
  const { TooltipProvider } = await import("@/components/ui/tooltip");
  return { ...estateDetail, TooltipProvider };
}

describe("P9 delivery UI recovered-audit regressions", () => {
  beforeEach(() => {
    mocks.deliveries = [];
    mocks.recipients = [];
    mocks.upsertMutate.mockReset();
    mocks.bulkMutate.mockReset();
    mocks.markP44MutateAsync.mockClear();
    // Radix Select pointer interactions need this in jsdom.
    Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
    Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
    Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
    Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
  });

  it("#22: leaves branch-specific minor receiver fields hidden until a delivery branch is explicitly selected", async () => {
    const { ContactFormFields, TooltipProvider } = await components();

    render(
      <TooltipProvider>
        <ContactFormFields
          contact={{
            id: "minor-1",
            name: "Minor Recipient",
            role: "beneficiary",
            recipientType: "beneficiary",
            relationship: "child",
            isMinor: 1,
            minorDeliveryBranch: "",
            guardianName: "",
          }}
          setContact={vi.fn()}
          allContacts={[]}
        />
      </TooltipProvider>,
    );

    expect(screen.queryByText("Parent/Guardian Name")).toBeNull();
  });

  it("#21: can start and save a delivery linked to a PGT recipient returned by the server", async () => {
    const { DeliveriesCard, TooltipProvider } = await components();
    mocks.recipients = [{
      contactId: "pgt-1",
      name: "Public Guardian and Trustee",
      address: "700 - 808 West Hastings Street, Vancouver, BC",
      residentialAddress: "700 - 808 West Hastings Street, Vancouver, BC",
      postalAddress: "",
      email: "",
    }];

    render(
      <TooltipProvider>
        <DeliveriesCard estateId="estate-1" estate={{ id: "estate-1", notifyPGT: "yes" }} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByText("Public Guardian and Trustee"));
    fireEvent.change(screen.getByTestId("delivery-method-select"), { target: { value: "ordinary_mail" } });
    fireEvent.change(screen.getByLabelText("Delivery Date"), { target: { value: "2026-07-14" } });
    fireEvent.click(screen.getByRole("button", { name: "Save" }));

    expect(mocks.upsertMutate).toHaveBeenCalledWith(expect.objectContaining({
      estateId: "estate-1",
      contactId: "pgt-1",
      recipientName: "Public Guardian and Trustee",
      deliveryMethod: "ordinary_mail",
      deliveryDate: "2026-07-14",
    }));
  });

  it("#23: manual delivery entry records a selected method and sworn date", async () => {
    const { DeliveriesCard, TooltipProvider } = await components();

    render(
      <TooltipProvider>
        <DeliveriesCard estateId="estate-1" estate={{ id: "estate-1" }} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByRole("button", { name: "Add Delivery" }));
    fireEvent.change(screen.getByPlaceholderText("Full name"), { target: { value: "Notice Recipient" } });

    expect(screen.getByText("Select method")).toBeTruthy();
    const date = screen.getByLabelText("Delivery Date") as HTMLInputElement;
    expect(date.value).toBe("");

    fireEvent.change(screen.getByTestId("delivery-method-select"), { target: { value: "ordinary_mail" } });
    fireEvent.change(date, { target: { value: "2026-07-14" } });

    fireEvent.click(screen.getByRole("button", { name: "Save" }));
    expect(mocks.upsertMutate).toHaveBeenCalledWith(expect.objectContaining({
      recipientName: "Notice Recipient",
      deliveryMethod: "ordinary_mail",
      deliveryDate: "2026-07-14",
    }));
  });

  it("#23: Mark All Delivered opens with no sworn date preselected", async () => {
    const { DeliveriesCard, TooltipProvider } = await components();
    mocks.recipients = [{
      contactId: "recipient-1",
      name: "Notice Recipient",
      address: "1 Main Street, Vancouver, BC",
      residentialAddress: "1 Main Street, Vancouver, BC",
      postalAddress: "",
      email: "recipient@example.com",
    }];

    render(
      <TooltipProvider>
        <DeliveriesCard estateId="estate-1" estate={{ id: "estate-1" }} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByRole("button", { name: /Mark All Delivered \(1\)/ }));
    const input = await screen.findByTestId("bulk-delivery-date") as HTMLInputElement;
    expect(input.value).toBe("");
    expect(mocks.bulkMutate).not.toHaveBeenCalled();
  });

  it("#32: does not tell users that a Rule 25-2(14) order is a P9 exhibit", async () => {
    const { DeliveriesCard, TooltipProvider } = await components();

    render(
      <TooltipProvider>
        <DeliveriesCard estateId="estate-1" estate={{ id: "estate-1" }} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByRole("button", { name: "Add Delivery" }));
    fireEvent.click(screen.getByRole("checkbox", { name: "Delivery dispensed by court order" }));

    await waitFor(() => {
      expect(screen.queryByText(/requires the sealed court order to be attached as an exhibit in the P9 affidavit/i)).toBeNull();
    });
  });

  it("2026-07-26 review fix: editing a delivery saves the P44 withdrawal-delivery date AND method via markP44", async () => {
    const { DeliveriesCard, TooltipProvider } = await components();
    mocks.deliveries = [{
      id: "d1",
      estateId: "estate-1",
      contactId: "c1",
      recipientName: "Bea Beneficiary",
      deliveryMethod: "ordinary_mail",
      deliveryDate: "2026-01-10",
      p44DeliveryDate: "",
      p44DeliveryMethod: "",
    }];

    render(
      <TooltipProvider>
        <DeliveriesCard estateId="estate-1" estate={{ id: "estate-1" }} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByTitle("Edit"));
    fireEvent.change(screen.getByTestId("delivery-p44-date"), { target: { value: "2026-03-01" } });
    fireEvent.change(screen.getByTestId("delivery-p44-method"), { target: { value: "personal" } });
    fireEvent.click(screen.getByRole("button", { name: "Update" }));

    await waitFor(() => {
      expect(mocks.markP44MutateAsync).toHaveBeenCalledWith(expect.objectContaining({
        id: "d1",
        estateId: "estate-1",
        p44DeliveryDate: "2026-03-01",
        p44DeliveryMethod: "personal",
      }));
    });
  });

  it("markP44 is not called when the P44 date and method are unchanged", async () => {
    const { DeliveriesCard, TooltipProvider } = await components();
    mocks.deliveries = [{
      id: "d1",
      estateId: "estate-1",
      contactId: "c1",
      recipientName: "Bea Beneficiary",
      deliveryMethod: "ordinary_mail",
      deliveryDate: "2026-01-10",
      p44DeliveryDate: "2026-03-01",
      p44DeliveryMethod: "ordinary_mail",
    }];

    render(
      <TooltipProvider>
        <DeliveriesCard estateId="estate-1" estate={{ id: "estate-1" }} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByTitle("Edit"));
    fireEvent.click(screen.getByRole("button", { name: "Update" }));

    await waitFor(() => {
      expect(mocks.upsertMutate).toHaveBeenCalled();
    });
    expect(mocks.markP44MutateAsync).not.toHaveBeenCalled();
  });
});
