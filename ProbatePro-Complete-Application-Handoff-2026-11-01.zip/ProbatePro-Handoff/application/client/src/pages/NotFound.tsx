import { BookOpen, Compass, FileQuestion, FileText, Home, Scale, ShieldCheck } from "lucide-react";
import React, { useState } from "react";
import { useLocation } from "wouter";

const recoveryLinks = [
  {
    label: "Start at home",
    detail: "Return to your ProbatePro starting point.",
    path: "/",
    icon: Home,
  },
  {
    label: "Privacy",
    detail: "Review how ProbatePro protects information.",
    path: "/privacy",
    icon: ShieldCheck,
  },
  {
    label: "Terms",
    detail: "Read the service terms and access details.",
    path: "/terms",
    icon: FileText,
  },
] as const;

export default function NotFound() {
  const [, setLocation] = useLocation();
  const [illustrationUnavailable, setIllustrationUnavailable] = useState(false);

  const handleGoHome = () => {
    setLocation("/");
  };

  const handleGoBack = () => {
    window.history.back();
  };

  return (
    <main className="relative isolate flex min-h-dvh items-center overflow-hidden bg-[#f8fafc] px-5 py-10 text-[#162b45] sm:px-8">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-[0.48] [background-image:linear-gradient(to_right,rgba(30,58,95,0.06)_1px,transparent_1px),linear-gradient(to_bottom,rgba(30,58,95,0.06)_1px,transparent_1px)] [background-size:32px_32px]" />
      <div aria-hidden="true" className="pointer-events-none absolute -right-24 top-[-6rem] size-[22rem] rounded-full bg-[#dce7f4]/70 blur-3xl" />
      <div aria-hidden="true" className="pointer-events-none absolute -bottom-32 -left-24 size-[22rem] rounded-full bg-[#e9eef6]/90 blur-3xl" />

      <section className="relative mx-auto w-full max-w-3xl">
        <header className="mb-12 flex items-center gap-2.5 text-sm font-semibold tracking-[-0.01em] text-[#162b45]">
          <span className="grid size-8 place-items-center rounded-lg border border-[#1e3a5f]/15 bg-white/80 shadow-sm">
            <Scale aria-hidden="true" className="size-4 text-[#1e3a5f]" strokeWidth={2.1} />
          </span>
          ProbatePro
        </header>

	  <div className="border-y border-[#1e3a5f]/15 bg-white/65 py-8 backdrop-blur-sm sm:grid sm:grid-cols-[auto_1fr] sm:gap-10 sm:px-10 sm:py-11">
		<div className="mb-7 px-6 sm:mb-0 sm:px-0">
		  <p className="font-mono text-xs font-semibold tracking-[0.2em] text-[#6c7c91]">ROUTE / 404</p>
		  <div data-testid="not-found-illustration-motion" className="probate-404-illustration relative mt-3 grid size-28 place-items-center overflow-hidden rounded-2xl border border-[#1e3a5f]/15 bg-[#eff4fa]/80 shadow-[0_10px_24px_rgba(22,43,69,0.08)] sm:size-32">
			{illustrationUnavailable ? (
			  <div role="img" aria-label="Open estate file and navigation compass" className="probate-404-illustration-fallback relative grid size-full place-items-center" data-testid="not-found-illustration-fallback">
				<span aria-hidden="true" className="absolute left-5 top-5 h-14 w-16 rounded-lg border border-[#1e3a5f]/20 bg-white shadow-[0_6px_14px_rgba(22,43,69,0.09)]" />
				<span aria-hidden="true" className="absolute left-8 top-8 h-1.5 w-8 rounded-full bg-[#d2ddea]" />
				<span aria-hidden="true" className="absolute left-8 top-12 h-1.5 w-11 rounded-full bg-[#dce5ef]" />
				<Compass aria-hidden="true" className="relative ml-9 mt-8 size-8 rounded-full bg-[#1e3a5f] p-1.5 text-white shadow-md" strokeWidth={1.8} />
			  </div>
			) : (
			  <img
				alt="Open estate file and navigation compass"
				src="/manus-storage/probatepro-404-legal-file_dc16691a.png"
				className="size-full object-contain p-2"
				onError={() => setIllustrationUnavailable(true)}
			  />
			)}
			<span aria-hidden="true" className="probate-404-illustration-marker absolute bottom-2 right-2 grid size-7 place-items-center rounded-lg border border-[#1e3a5f]/15 bg-white/90 text-[#1e3a5f] shadow-sm">
			  <FileQuestion className="size-3.5" strokeWidth={1.9} />
			</span>
		  </div>
		</div>

          <div className="px-6 sm:px-0">
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#4d6684]">Page unavailable</p>
            <h1 className="mt-3 max-w-xl text-balance text-3xl font-semibold tracking-[-0.035em] text-[#162b45] sm:text-4xl">This address doesn’t point to a ProbatePro page.</h1>
            <p className="mt-4 max-w-xl text-pretty text-[15px] leading-7 text-[#526171]">The link may be incomplete, expired, or no longer available. Your estate files and saved work have not been changed.</p>

            <div id="not-found-button-group" className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
              <button type="button" onClick={handleGoHome} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-lg bg-[#1e3a5f] px-5 text-sm font-semibold text-white shadow-[0_8px_18px_rgba(22,43,69,0.18)] transition-[background-color,transform,box-shadow] duration-150 hover:bg-[#163050] hover:shadow-[0_10px_22px_rgba(22,43,69,0.24)] active:scale-[0.97] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1e3a5f] focus-visible:ring-offset-2">
                <Home aria-hidden="true" className="size-4" />
                Return to ProbatePro
              </button>
<button type="button" onClick={handleGoBack} className="inline-flex min-h-11 items-center justify-center rounded-lg border border-[#1e3a5f]/20 bg-white/80 px-5 text-sm font-semibold text-[#1e3a5f] transition-[background-color,transform] duration-150 hover:bg-[#eef4fa] active:scale-[0.97] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1e3a5f] focus-visible:ring-offset-2">Go back</button>
            </div>

		  <div className="mt-7 flex items-start gap-2.5 border-l-2 border-[#8094ad] pl-3 text-sm leading-6 text-[#5c6d80]">
			<Compass aria-hidden="true" className="mt-1 size-4 shrink-0 text-[#4d6684]" />
			<p>If you followed a shared portal link, ask the sender to confirm it is still active. For a persistent problem, return to ProbatePro and use <span className="font-medium text-[#1e3a5f]">Report a problem</span>.</p>
		  </div>

		  <nav aria-label="Helpful navigation" className="mt-8 border-t border-[#1e3a5f]/10 pt-6">
			<div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.15em] text-[#61748a]">
			  <BookOpen aria-hidden="true" className="size-3.5 text-[#4d6684]" />
			  Helpful links
			</div>
			<div className="mt-3 grid gap-2 sm:grid-cols-3">
			  {recoveryLinks.map(({ label, detail, path, icon: Icon }) => (
				<button
				  key={path}
				  type="button"
				  onClick={() => setLocation(path)}
				  className="group flex min-h-20 items-start gap-3 rounded-xl border border-[#1e3a5f]/12 bg-white/70 p-3 text-left transition-[background-color,border-color,transform,box-shadow] duration-150 hover:border-[#1e3a5f]/25 hover:bg-white hover:shadow-[0_8px_18px_rgba(22,43,69,0.07)] active:scale-[0.98] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1e3a5f] focus-visible:ring-offset-2"
				>
				  <span aria-hidden="true" className="mt-0.5 grid size-7 shrink-0 place-items-center rounded-lg bg-[#eff4fa] text-[#1e3a5f] transition-transform duration-150 group-hover:scale-105">
					<Icon className="size-3.5" strokeWidth={1.9} />
				  </span>
				  <span className="min-w-0">
					<span className="block text-sm font-semibold text-[#1e3a5f]">{label}</span>
					<span className="mt-0.5 block text-xs leading-5 text-[#66778a]">{detail}</span>
				  </span>
				</button>
			  ))}
			</div>
		  </nav>
		</div>
	  </div>
      </section>
    </main>
  );
}
