/** Manual P16 reviews populated alteration facts before its real download flow. */
import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.setConfig({ testTimeout: 45000 });
(globalThis as any).React = React;
vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }) }));

const mocks = vi.hoisted(() => ({
  estate: {} as any,
  generateCalls: [] as any[],
  preflightCalls: [] as any[],
  updateCalls: [] as any[],
  /** document.generate's POST delivery (Nick, 2026-10-20), never a GET URL. */
  delivery: {
    method: "POST",
    action: "/api/download/form",
    fields: { estateId: "estate-18", formCode: "P16", documentId: "doc_p16_1", signatoryType: "lawyer", signatureDate: "2026-07-12" },
  },
}));
vi.mock("@/lib/trpc", () => {
  const mutation = (path: string, options?: any) => {
    const mutateAsync = async (input: any) => {
      let result: any = {};
      if (path === "estate.update") {
        mocks.updateCalls.push(input);
        mocks.estate = { ...mocks.estate, ...input.data, revision: mocks.estate.revision + 1 };
        result = mocks.estate;
      }
      if (path === "document.generate") {
        mocks.generateCalls.push(input);
        result = { id: "doc_p16_1", delivery: mocks.delivery, filename: "P16_Alex_North.docx", format: "docx" };
      }
      await options?.onSuccess?.(result, input, undefined);
      return result;
    };
    return { mutateAsync, mutate: (input: any) => { void mutateAsync(input); }, isPending: false };
  };
  function utils(path: string[]): any {
    return new Proxy({}, {
      get(_target, property: string) {
        if (["invalidate", "setData", "cancel"].includes(property)) return () => undefined;
        if (property === "getData") return () => mocks.estate;
        if (property === "fetch") return async (input: any) => {
          if (path.join(".") === "document.preflight") {
            mocks.preflightCalls.push(input);
            return { formCode: "P16", ok: true, hardBlocked: false, gaps: [] };
          }
          if (path.join(".") === "document.preflightMany") return [];
          if (path.join(".") === "estate.get") return mocks.estate;
          return undefined;
        };
        return utils([...path, property]);
      },
    });
  }
  function node(path: string[]): any {
    return new Proxy({}, {
      get(_target, property: string) {
        if (property === "useQuery") return () => {
          const key = path.join(".");
          const lists = ["document.list", "document.versions", "document.retainedFiles", "document.getLetterRecipients", "citation.list", "delivery.list", "delivery.getRecipients"];
          return { data: key === "contact.list" ? [applicant] : lists.includes(key) ? [] : undefined, isLoading: false, error: null };
        };
        if (property === "useMutation") return (options: any) => mutation(path.join("."), options);
        if (property === "useUtils") return () => utils([]);
        return node([...path, property]);
      },
    });
  }
  return { trpc: node([]) };
});

const applicant = { id: "applicant-1", role: "applicant,executor", executorStatus: "applying", executorRank: "primary", name: "Alex Applicant", relationship: "child" };
const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
/** Each same-tab form POST the page submits; the browser's attachment download follows it. */
const downloads: Array<{ method: string; action: string | null; fields: Record<string, string> }> = [];
const posted = (fields: Record<string, string>) => ({ method: "post", action: "/api/download/form", fields: { ...fields, attemptId: expect.stringMatching(UUID_V4) } });
beforeEach(() => {
  vi.clearAllMocks();
  mocks.estate = {
    id: "estate-18", revision: 1, grantType: "grant_of_probate", hasWill: 1, willStatus: "will",
    deceasedFirstName: "Alex", deceasedLastName: "North", applicantType: "executor", p1NotRequired: 1,
    willAlterations: "has_alterations", willAlterationRoute: "p16_affidavit", willDate: "2024-01-15",
    p16AlterationPage: "Page 1", p16AlterationLine: "Page 1, line 12", p16AlterationType: "interlineation",
    p16AlterationWords: "cottage words, presence yes", p16DeponentPresentAtSigning: "yes",
  };
  mocks.generateCalls.length = 0;
  mocks.preflightCalls.length = 0;
  mocks.updateCalls.length = 0;
  downloads.length = 0;
  vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) {
    downloads.push({ method: this.method, action: this.getAttribute("action"), fields: Object.fromEntries(new FormData(this)) as Record<string, string> });
  });
});
afterEach(() => vi.restoreAllMocks());

async function openP16() {
  const { FormsTab } = await import("./EstateDetail");
  render(<FormsTab estateId="estate-18" estate={mocks.estate} onNavigateToTab={vi.fn()} />);
  fireEvent.click(screen.getByTestId("form-generate-P16"));
  fireEvent.click(screen.getByTestId("form-details-generate"));
  await waitFor(() => expect(screen.getByTestId("pre-generate-p16-alteration-fields")).toBeTruthy());
}

describe("P16 manual alteration review", () => {
  it("reviews a complete record, saves the user's actual words separately, then downloads once without reopening review", async () => {
    await openP16();
    expect(mocks.generateCalls).toHaveLength(0);
    expect(screen.getByTestId("pre-generate-input-p16AlterationWords")).toHaveProperty("value", "cottage words, presence yes");
    expect(screen.getByTestId("pre-generate-input-p16DeponentPresentAtSigning").textContent).toBe("Yes");
    fireEvent.change(screen.getByLabelText("Page"), { target: { value: "1" } });
    fireEvent.change(screen.getByLabelText("Line"), { target: { value: "12" } });
    fireEvent.change(screen.getByTestId("pre-generate-input-p16AlterationWords"), { target: { value: "my interest in Lot 7" } });
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toEqual([posted(mocks.delivery.fields)]));
    expect(mocks.updateCalls).toHaveLength(1);
    expect(mocks.updateCalls[0].data).toMatchObject({ p16AlterationPage: "1", p16AlterationLine: "12", p16AlterationWords: "my interest in Lot 7" });
    expect(mocks.updateCalls[0].data).not.toHaveProperty("p16DeponentPresentAtSigning");
    expect(mocks.estate.p16DeponentPresentAtSigning).toBe("yes");
    expect(mocks.preflightCalls).toHaveLength(2);
    expect(mocks.generateCalls).toHaveLength(1);
  });

  it("lets the user confirm existing exact words without rewriting them or the presence answer", async () => {
    mocks.estate.p16AlterationWords = "my cottage and its contents";
    await openP16();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(mocks.generateCalls).toHaveLength(1);
    expect(mocks.updateCalls).toEqual([]);
    expect(mocks.estate.p16AlterationWords).toBe("my cottage and its contents");
    expect(mocks.estate.p16DeponentPresentAtSigning).toBe("yes");
  });
});
