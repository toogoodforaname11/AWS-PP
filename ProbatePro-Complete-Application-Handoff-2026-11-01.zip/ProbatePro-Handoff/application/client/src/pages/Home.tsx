import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { SpotlightCard } from "@/components/SpotlightCard";
import { PageHeader } from "@/components/PageHeader";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { staggerContainer, staggerItem } from "@/lib/motion";
import { Plus, Search, Scale, FileText, Clock, AlertTriangle, CheckCircle2, Trash2, Archive, ArchiveRestore, ChevronDown, Copy, Pin, StickyNote, Pencil, Check, X, CircleDot, MoreHorizontal, Download, ClipboardCheck } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuRadioGroup, DropdownMenuRadioItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import React, { useEffect, useMemo, useState, useRef } from "react";
import { useLocation, useSearch } from "wouter";
import { toast } from "sonner";
import { STATUS_LABELS, grantTypeLabel, fmtDisplayDate, shortcutLabel } from "@/lib/labels";
import { STORAGE_DISPOSITION_ATTESTATIONS } from "@shared/storageDisposition";
import { isPostDelivery } from "@shared/postDelivery";
import { deliverAndAnnounce, useDeliveryFeedbackOwner } from "@/lib/attachmentDelivery";

const STATUS_COLORS: Record<string, string> = {
  intake: "bg-sky-50 text-sky-700 border-sky-200",
  // Incomplete is an operational state, not an alarm. Use a calm, high-contrast
  // neutral treatment so the row remains purposeful rather than warning-yellow.
  incomplete: "bg-slate-50 text-slate-700 border-slate-300/90 shadow-[0_1px_0_rgba(15,23,42,0.04)] dark:bg-slate-900/70 dark:text-slate-100 dark:border-slate-700",
  ready_to_file: "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/30 dark:text-blue-300 dark:border-blue-800",
  filed: "bg-purple-50 text-purple-700 border-purple-200",
  granted: "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-300 dark:border-emerald-800",
  complete: "bg-gray-50 text-gray-600 border-gray-200",
  archived: "bg-slate-50 text-slate-500 border-slate-200",
};

const FILTER_OPTIONS = [
  { value: "all", label: "All" },
  { value: "needs_attention", label: "Needs attention" },
  { value: "active", label: "Active" },
  { value: "intake", label: "Intake" },
  { value: "incomplete", label: "Incomplete" },
  { value: "ready_to_file", label: "Ready to File" },
  { value: "filed", label: "Filed" },
  { value: "granted", label: "Granted" },
  { value: "complete", label: "Complete" },
  { value: "archived", label: "Archived" },
];

const ESTATE_SWIPE_REVEAL_WIDTH = 164;
const ESTATE_SWIPE_COMMIT_THRESHOLD = 76;
const ESTATE_SWIPE_GESTURE_THRESHOLD = 12;
const CREATE_ESTATE_FAILURE_MESSAGE = "We could not create this estate file. Please try again. If the problem continues, contact support.";

function createEstateErrorMessage(error: unknown): string {
  const candidate = error && typeof error === "object" ? error as { data?: { code?: unknown } } : null;
  const code = candidate?.data?.code;
  if (code === "UNAUTHORIZED") return "Your session has ended. Please sign in and try again.";
  if (code === "TOO_MANY_REQUESTS") return "Too many creation attempts were made. Please wait a moment and try again.";
  if (code === "BAD_REQUEST") return "Please review the estate details and try again.";
  return CREATE_ESTATE_FAILURE_MESSAGE;
}

// "active" mirrors the Active Files metric: anything not complete/archived
const matchesStatusFilter = (status: string, filter: string) =>
  filter === "active" ? status !== "complete" && status !== "archived" : status === filter;

type DashboardEstate = {
  id: string;
  status: string;
  willStatus?: string | null;
  deceasedFirstName?: string | null;
  deceasedLastName?: string | null;
  dateOfDeath?: string | null;
  registry?: string | null;
  domicileCity?: string | null;
};

const isEstateRowNestedControl = (target: EventTarget | null) =>
  target instanceof Element && Boolean(target.closest("button, input, select, textarea, a, [role='button'], [data-radix-popper-content-wrapper]"));

export function EstateRowSkeleton({ count = 3 }: { count?: number }) {
  return (
    <div className="grid gap-2" aria-label="Loading estate files" aria-live="polite" role="status">
      {Array.from({ length: count }, (_, index) => (
        <div
          key={index}
          data-testid="estate-row-skeleton"
          className="overflow-hidden rounded-lg border border-border/70 bg-card p-3 shadow-sm sm:px-4 sm:py-3"
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex min-w-0 flex-1 items-start gap-2 sm:gap-4">
              <div className="h-3 w-7 shrink-0 rounded bg-muted/70 estate-row-skeleton-pulse motion-reduce:animate-none sm:w-10" />
              <div className="min-w-0 flex-1 space-y-2">
                <div className="h-4 w-3/4 rounded bg-muted/70 estate-row-skeleton-pulse motion-reduce:animate-none sm:w-2/5" />
                <div className="h-3 w-1/2 rounded bg-muted/50 estate-row-skeleton-pulse motion-reduce:animate-none sm:w-1/4" />
              </div>
            </div>
            <div className="h-8 w-20 shrink-0 rounded-md bg-muted/60 estate-row-skeleton-pulse motion-reduce:animate-none sm:h-6 sm:w-24" />
          </div>
          <div className="mt-3 h-px w-full overflow-hidden rounded bg-muted/70">
            <div className="h-full w-2/5 rounded bg-muted-foreground/15 estate-row-skeleton-pulse motion-reduce:animate-none" />
          </div>
          <div className="mt-3 h-9 w-full rounded-md bg-primary/[0.045] estate-row-skeleton-pulse motion-reduce:animate-none sm:h-7 sm:w-44" />
        </div>
      ))}
    </div>
  );
}

export function resolveDashboardNextAction(estate: DashboardEstate) {
  if (estate.status === "complete" || estate.status === "archived") {
    return { label: "View file", tab: undefined };
  }
  if (estate.willStatus !== "will" && estate.willStatus !== "no_will") {
    return { label: "Confirm will status", tab: "intake" };
  }
  if (!estate.deceasedFirstName || !estate.deceasedLastName) {
    return { label: "Record deceased’s name", tab: "intake" };
  }
  if (!estate.dateOfDeath) {
    return { label: "Record date of death", tab: "intake" };
  }
  if (!estate.registry) {
    return { label: "Choose registry", tab: "intake" };
  }
  if (!estate.domicileCity) {
    return { label: "Record domicile city", tab: "intake" };
  }
  if (estate.status === "ready_to_file") {
    return { label: "Review ready-to-file checklist", tab: "readiness" };
  }
  return { label: "Review readiness", tab: "readiness" };
}

export default function Home() {
  const [, setLocation] = useLocation();
  const searchParams = useSearch();
  const prefersReducedMotion = useReducedMotion();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [estateView, setEstateView] = useState<"active" | "archived">("active");
  const [noteSearchQuery, setNoteSearchQuery] = useState("");
  const noteSearchTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newEstateName, setNewEstateName] = useState("");
  const [newRegistry, setNewRegistry] = useState("");
  const [newFileType, setNewFileType] = useState("probate_only");
  const [newWillStatus, setNewWillStatus] = useState<"unknown" | "will" | "no_will">("unknown");
  const [newEstateError, setNewEstateError] = useState<string | null>(null);
  const [editingNameId, setEditingNameId] = useState<string | null>(null);
  const [editingNameValue, setEditingNameValue] = useState("");
  const [pressedEstateId, setPressedEstateId] = useState<string | null>(null);
  const [openSwipeEstateId, setOpenSwipeEstateId] = useState<string | null>(null);
  const [swipeOffsets, setSwipeOffsets] = useState<Record<string, number>>({});
  const editNameInputRef = useRef<HTMLInputElement>(null);
  const swipeStartRef = useRef<Map<string, { x: number; y: number }>>(new Map());
  const swipeOffsetRef = useRef<Record<string, number>>({});
  const suppressRowClickRef = useRef<string | null>(null);

  // Keyboard shortcut: Ctrl+N to create new estate
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "n") {
        e.preventDefault();
        setDialogOpen(true);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const { data: estates, isLoading, isError, refetch } = trpc.estate.list.useQuery();
  const { data: settings } = trpc.settings.get.useQuery();
  const isPersonalExecutor = settings?.accountPurpose === "personal_executor";
  const { data: storageDispositions } = trpc.estate.dispositions.useQuery();
  const { data: witnessStats } = trpc.estate.witnessStats.useQuery();
  const { data: letterStats } = trpc.estate.letterStats.useQuery();
  const { data: distributionStats } = trpc.estate.distributionStats.useQuery();
  const { data: clientIntakeStatus } = trpc.clientIntake.dashboardStatus.useQuery();
  const { data: deadlines, isError: deadlinesError } = trpc.deadline.list.useQuery();
  const utils = trpc.useUtils();
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; name: string; status: string } | null>(null);
  const [deleteDispositionBasis, setDeleteDispositionBasis] = useState<"created_in_error" | "retention_complete">("retention_complete");
  const [deleteAttestationAccepted, setDeleteAttestationAccepted] = useState(false);
  const [deleteConfirmation, setDeleteConfirmation] = useState("");
  const createMutation = trpc.estate.create.useMutation({
    onSuccess: (data) => {
      utils.estate.list.invalidate();
      setDialogOpen(false);
      setNewEstateName("");
      setNewWillStatus("unknown");
      setNewEstateError(null);
      setLocation(isPersonalExecutor ? `/estate/${data.id}?tab=intake` : `/estate/${data.id}`);
      toast.success("Estate file created");
    },
    onError: (error) => {
      setNewEstateError(createEstateErrorMessage(error));
    },
  });
  const deleteMutation = trpc.estate.delete.useMutation({
    onSuccess: (data) => {
      utils.estate.list.invalidate();
      utils.deadline.list.invalidate();
      utils.estate.dispositions.invalidate();
      setDeleteTarget(null);
      setDeleteConfirmation("");
      setDeleteAttestationAccepted(false);
      toast.success(data.destructionQueued
        ? "Estate file deleted; stored objects are queued for verified provider destruction"
        : "Estate deleted. No stored files required provider destruction.");
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete estate");
    },
  });
  const archiveMutation = trpc.estate.update.useMutation({
    onSuccess: (_data, variables) => {
      utils.estate.list.invalidate();
      utils.deadline.list.invalidate();
      const isArchiving = (variables.data as any).status === "archived";
      const isStatusChange = Object.prototype.hasOwnProperty.call(variables.data, "status");
      toast.success(isStatusChange ? (isArchiving ? "Estate archived" : "Estate status updated") : "Estate updated");
    },
    onError: (error) => toast.error(error.message || "Estate could not be updated"),
  });
  const duplicateMutation = trpc.estate.duplicate.useMutation({
    onSuccess: (result) => {
      utils.estate.list.invalidate();
      toast.success(`Estate duplicated as file #${result.fileNumber}`);
    },
    onError: () => {
      toast.error("Failed to duplicate estate");
    },
  });
  // Task 13: an export's delivery feedback belongs to this page and to that estate's export.
  const exportFeedback = useDeliveryFeedbackOwner("home");
  const exportMutation = trpc.estate.export.useMutation({
    onSuccess: (result, variables) => {
      if (!isPostDelivery(result?.delivery)) {
        toast.error("The estate export could not be prepared for download. Please try again.");
        return;
      }
      deliverAndAnnounce(result.delivery, `Estate export (${result.fileCount} stored file${result.fileCount === 1 ? "" : "s"})`, {
        feedback: { owner: exportFeedback, slot: `export:${variables.id}` },
      });
    },
    onError: (error) => {
      toast.error(error.message || "The estate export could not be prepared. Please try again.");
    },
  });

  // A new personal executor is guided into the existing create-file dialog, not
  // given a fabricated estate or inferred legal role. Consume the one-shot URL
  // intent so dismissing the dialog does not reopen it on refresh/back.
  useEffect(() => {
    if (!new URLSearchParams(searchParams).has("start-intake") || !settings || !estates || isError) return;
    setLocation("/", { replace: true });
    if (isPersonalExecutor && estates.length === 0) setDialogOpen(true);
  }, [searchParams, settings, estates, isError, isPersonalExecutor, setLocation]);

  // Compute dashboard metrics
  const metrics = useMemo(() => {
    if (!estates) return null;
    const total = estates.length;
    const readyToFile = estates.filter((e) => e.status === "ready_to_file").length;
    const upcomingDeadlines = (deadlines?.events || []).filter((event) =>
      event.daysRemaining !== undefined && event.daysRemaining >= 0 && event.daysRemaining <= 7 &&
      ((event.kind === "obligation" && (event.status === "upcoming" || event.status === "due")) ||
       (event.kind === "limitation" && (event.status === "open" || event.status === "last_day")))
    ).length;
    const activeFiles = estates.filter((e) => e.status !== "complete" && e.status !== "archived").length;
    return { total: estates.filter((e) => e.status !== "archived").length, readyToFile, upcomingDeadlines, activeFiles };
  }, [estates, deadlines]);

  const attentionEstateIds = useMemo(() => {
    const attention = new Set<string>();
    for (const estate of estates || []) {
      if (estate.status === "incomplete" || estate.willStatus === "unknown") attention.add(estate.id);
    }
    for (const issue of deadlines?.issues || []) {
      if (issue.severity === "error") attention.add(issue.estateId);
    }
    for (const [estateId, stats] of Object.entries(distributionStats || {})) {
      if (stats.hasShares && !stats.isReconciled) attention.add(estateId);
    }
    return attention;
  }, [estates, deadlines?.issues, distributionStats]);

  const statusFilterCounts = useMemo(() => {
    const files = estates ?? [];
    return Object.fromEntries(FILTER_OPTIONS.map((option) => {
      if (option.value === "all") {
        return [option.value, files.filter((estate) => estateView === "archived" ? estate.status === "archived" : estate.status !== "archived").length];
      }
      if (option.value === "needs_attention") {
        return [option.value, files.filter((estate) => estate.status !== "archived" && attentionEstateIds.has(estate.id)).length];
      }
      return [option.value, files.filter((estate) => matchesStatusFilter(estate.status, option.value)).length];
    }));
  }, [attentionEstateIds, estateView, estates]);

  const selectedStatusOption = FILTER_OPTIONS.find((option) => option.value === statusFilter) ?? FILTER_OPTIONS[0];
  const estateListSettled = Array.isArray(estates) && !isLoading && !isError;
  const estateListCountState = isLoading || !Array.isArray(estates) ? "Loading" : isError ? "Unavailable" : null;
  const selectedStatusCount = estateListSettled ? statusFilterCounts[selectedStatusOption.value] ?? 0 : null;
  const activeFilesCount = estateListSettled ? metrics?.activeFiles ?? 0 : null;
  const archivedFilesCount = estateListSettled ? estates.filter((estate) => estate.status === "archived").length : null;
  const estateListTotal = estateListSettled ? estates.length : null;

  const selectEstateStatusFilter = (value: string) => {
    setStatusFilter(value);
    setEstateView(value === "archived" ? "archived" : "active");
  };

  const filtered = useMemo(() => {
    return (estates || []).filter((e) => {
      if (estateView === "archived" && e.status !== "archived") return false;
      if (estateView === "active" && e.status === "archived") return false;
      // Status / triage filter
      if (statusFilter === "needs_attention" && !attentionEstateIds.has(e.id)) return false;
      if (statusFilter !== "all" && statusFilter !== "needs_attention" && !matchesStatusFilter(e.status, statusFilter)) return false;
      // Text search
      if (!search) return true;
      const q = search.toLowerCase();
      const name = [e.deceasedFirstName, e.deceasedMiddleNames, e.deceasedSecondMiddleName, e.deceasedLastName].filter(Boolean).join(" ").toLowerCase();
      const eName = (e.estateName || "").toLowerCase();
      return name.includes(q) || eName.includes(q) || String(e.fileNumber).includes(q) || e.registry.toLowerCase().includes(q);
    });
  }, [estates, search, statusFilter, estateView]);

  // Notes search: debounced query
  const handleSearchChange = (value: string) => {
    setSearch(value);
    if (noteSearchTimer.current) clearTimeout(noteSearchTimer.current);
    if (value.trim().length >= 2) {
      noteSearchTimer.current = setTimeout(() => setNoteSearchQuery(value.trim()), 400);
    } else {
      setNoteSearchQuery("");
    }
  };

  const closeEstateSwipe = (estateId: string) => {
    swipeOffsetRef.current[estateId] = 0;
    setSwipeOffsets((current) => ({ ...current, [estateId]: 0 }));
    setOpenSwipeEstateId((current) => current === estateId ? null : current);
  };

  const handleEstateSwipeStart = (event: React.PointerEvent<HTMLDivElement>, estateId: string) => {
    if (event.pointerType === "mouse" || window.innerWidth >= 768 || isEstateRowNestedControl(event.target)) return;
    swipeStartRef.current.set(estateId, { x: event.clientX, y: event.clientY });
    event.currentTarget.setPointerCapture?.(event.pointerId);
  };

  const handleEstateSwipeMove = (event: React.PointerEvent<HTMLDivElement>, estateId: string) => {
    const start = swipeStartRef.current.get(estateId);
    if (!start) return;
    const horizontalTravel = event.clientX - start.x;
    const verticalTravel = event.clientY - start.y;
    if (Math.abs(verticalTravel) > Math.abs(horizontalTravel) && Math.abs(verticalTravel) > ESTATE_SWIPE_GESTURE_THRESHOLD) {
      swipeStartRef.current.delete(estateId);
      return;
    }
    if (Math.abs(horizontalTravel) < ESTATE_SWIPE_GESTURE_THRESHOLD) return;
    event.preventDefault();
    const startingOffset = openSwipeEstateId === estateId ? -ESTATE_SWIPE_REVEAL_WIDTH : 0;
    const nextOffset = Math.max(-ESTATE_SWIPE_REVEAL_WIDTH, Math.min(0, startingOffset + horizontalTravel));
    swipeOffsetRef.current[estateId] = nextOffset;
    setSwipeOffsets((current) => ({ ...current, [estateId]: nextOffset }));
  };

  const handleEstateSwipeEnd = (estateId: string) => {
    const start = swipeStartRef.current.get(estateId);
    swipeStartRef.current.delete(estateId);
    if (!start) return;
    const finalOffset = swipeOffsetRef.current[estateId] ?? 0;
    if (Math.abs(finalOffset) > ESTATE_SWIPE_GESTURE_THRESHOLD) suppressRowClickRef.current = estateId;
    if (finalOffset <= -ESTATE_SWIPE_COMMIT_THRESHOLD) {
      swipeOffsetRef.current[estateId] = -ESTATE_SWIPE_REVEAL_WIDTH;
      setSwipeOffsets((current) => ({ ...current, [estateId]: -ESTATE_SWIPE_REVEAL_WIDTH }));
      setOpenSwipeEstateId(estateId);
      return;
    }
    closeEstateSwipe(estateId);
  };
  const { data: noteSearchResults } = trpc.notes.search.useQuery(
    { query: noteSearchQuery },
    { enabled: noteSearchQuery.length >= 2 }
  );

  return (
    <div className="space-y-6" data-tour="dashboard-overview">
      <PageHeader
        title="Estate Files"
        description="Manage BC Supreme Court probate applications"
        action={
          <Dialog open={dialogOpen} onOpenChange={(open) => {
            setDialogOpen(open);
            if (!open) setNewEstateError(null);
          }}>
            <DialogTrigger asChild>
              <Button className="probate-primary-action" title={`Create new estate (${shortcutLabel("N")})`} data-tour="new-estate-action">
                <Plus className="h-4 w-4 mr-2" />
                New Estate
                <kbd className="hidden md:inline-flex ml-2 h-5 items-center rounded border border-primary-foreground/30 bg-primary-foreground/10 px-1.5 font-mono text-[10px]">{shortcutLabel("N")}</kbd>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Estate File</DialogTitle>
                <DialogDescription className="sr-only">Name the estate file and choose its type and registry</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 pt-2">
                <div className="space-y-2">
                  <Label>Estate Name</Label>
                  <Input
                    placeholder="e.g. Smith Estate, Johnson Probate"
                    value={newEstateName}
                    onChange={(e) => {
                      setNewEstateName(e.target.value);
                      if (newEstateError) setNewEstateError(null);
                    }}
                    autoFocus
                  />
                  <p className="text-xs text-muted-foreground">A friendly name to identify this file</p>
                </div>
                {newEstateError && (
                  <div
                    role="alert"
                    className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm leading-5 text-destructive break-words"
                  >
                    {newEstateError}
                  </div>
                )}
                <div className="space-y-2">
                  <Label>File Workspace</Label>
                  <Select value={newFileType} onValueChange={setNewFileType}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="probate_only">Probate file</SelectItem>
                      <SelectItem value="full_admin">Estate administration workspace</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">This organizes the file only. It does not decide whether a will exists.</p>
                </div>
                <div className="space-y-2">
                  <Label>Will Status</Label>
                  <Select value={newWillStatus} onValueChange={(value) => setNewWillStatus(value as "unknown" | "will" | "no_will")}>
                    <SelectTrigger data-testid="new-estate-will-status"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="unknown">Not yet confirmed</SelectItem>
                      <SelectItem value="will">A will is present</SelectItem>
                      <SelectItem value="no_will">No will / administration without will</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">You can confirm or correct this later in Intake. Legal document generation stays protected until it is recorded.</p>
                </div>
                <div className="space-y-2">
                  <Label>Registry</Label>
                  <Select value={newRegistry} onValueChange={setNewRegistry}>
                    <SelectTrigger><SelectValue placeholder="Select registry" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Vancouver">Vancouver</SelectItem>
                      <SelectItem value="Victoria">Victoria</SelectItem>
                      <SelectItem value="New Westminster">New Westminster</SelectItem>
                      <SelectItem value="Kelowna">Kelowna</SelectItem>
                      <SelectItem value="Kamloops">Kamloops</SelectItem>
                      <SelectItem value="Prince George">Prince George</SelectItem>
                      <SelectItem value="Nanaimo">Nanaimo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  className="probate-primary-action w-full"
                  onClick={() => {
                    setNewEstateError(null);
                    createMutation.mutate({ estateName: newEstateName, fileType: newFileType, willStatus: newWillStatus, registry: newRegistry });
                  }}
                  disabled={createMutation.isPending || !newEstateName.trim()}
                >
                  {createMutation.isPending ? "Creating..." : "Create Estate File"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        }
      />

      {isPersonalExecutor && estates?.length === 0 && !isError && (
        <section className="rounded-xl border border-primary/15 bg-card px-5 py-5 shadow-sm sm:px-6" data-testid="personal-executor-start">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="min-w-0">
              <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-primary">Getting started</p>
              <h2 className="mt-1 text-lg font-semibold tracking-tight text-foreground">Begin with Full Intake</h2>
              <p className="mt-1 max-w-lg text-sm leading-6 text-muted-foreground">Create an estate file, then work through the questions at your own pace. Your answers can be reviewed and updated later.</p>
            </div>
            <Button className="probate-primary-action shrink-0" onClick={() => setDialogOpen(true)} data-testid="personal-executor-start-button">Start Full Intake</Button>
          </div>
        </section>
      )}

      {/* Dashboard Metrics Row (P1-1) */}
      {metrics && metrics.total > 0 && (
        <motion.div
          className="grid grid-cols-2 md:grid-cols-4 gap-3"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: [0.23, 1, 0.32, 1] }}
        >
          <MetricCard
            icon={<FileText className="h-4 w-4" />}
            label="Total Files"
            value={metrics.total}
            tint="slate"
            onClick={() => setStatusFilter("all")}
          />
          <MetricCard
            icon={<CheckCircle2 className="h-4 w-4" />}
            label="Ready to File"
            value={metrics.readyToFile}
            tint="emerald"
            onClick={() => setStatusFilter("ready_to_file")}
          />
          <MetricCard
            icon={<Clock className="h-4 w-4" />}
            label={deadlinesError ? "Deadlines unavailable" : "Deadlines (7d)"}
            value={deadlinesError ? "—" : metrics.upcomingDeadlines}
            tint="amber"
            onClick={() => setLocation("/deadlines")}
          />
          <MetricCard
            icon={<AlertTriangle className="h-4 w-4" />}
            label="Active Files"
            value={metrics.activeFiles}
            tint="violet"
            onClick={() => setStatusFilter("active")}
          />
        </motion.div>
      )}

      {storageDispositions && storageDispositions.length > 0 && (
        <section className="rounded-xl border bg-card p-4 space-y-3" aria-labelledby="storage-disposition-heading">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h2 id="storage-disposition-heading" className="text-sm font-semibold">Storage destruction audit</h2>
              <p className="text-xs text-muted-foreground">Provider destruction remains visible after the estate file is removed.</p>
            </div>
            <Badge variant="outline">{storageDispositions.length} record{storageDispositions.length === 1 ? "" : "s"}</Badge>
          </div>
          <div className="space-y-2 max-h-56 overflow-y-auto">
            {storageDispositions.map((disposition) => {
              const stateLabel = disposition.state === "complete"
                ? "Verified destroyed"
                : disposition.state === "retrying"
                  ? "Provider retrying"
                  : "Queued";
              return (
                <div key={disposition.id} className="flex flex-col gap-1 rounded-lg border px-3 py-2 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{disposition.estateLabel || `Estate file #${disposition.fileNumber}`}</p>
                    <p className="text-xs text-muted-foreground">
                      File #{disposition.fileNumber} · {disposition.objectCount} object{disposition.objectCount === 1 ? "" : "s"} · requested {fmtDisplayDate(disposition.requestedAt)}
                    </p>
                    {disposition.lastError && <p className="text-xs text-destructive">Last provider error: {disposition.lastError}</p>}
                  </div>
                  <Badge variant={disposition.state === "complete" ? "secondary" : "outline"}>{stateLabel}</Badge>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Search bar + status filter chips (P3-6) */}
      <motion.div
        className="space-y-3"
        data-tour="estate-workspace"
        initial={{ opacity: 0, y: 4 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15, duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
      >
        <div className="flex items-center justify-between gap-3">
          <div className="inline-flex rounded-lg border border-border/80 bg-muted/30 p-0.5" role="group" aria-label="Estate list view">
            <button
              type="button"
              aria-pressed={estateView === "active"}
              onClick={() => {
                setEstateView("active");
                setStatusFilter("active");
              }}
              className={`rounded-md px-2.5 py-1.5 text-xs font-semibold transition-colors ${estateView === "active" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
            >
              Active <span className="ml-1 tabular-nums text-muted-foreground">{activeFilesCount ?? "—"}</span>
            </button>
            <button
              type="button"
              aria-pressed={estateView === "archived"}
              onClick={() => {
                setEstateView("archived");
                setStatusFilter("archived");
              }}
              className={`rounded-md px-2.5 py-1.5 text-xs font-semibold transition-colors ${estateView === "archived" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
            >
              Archived <span className="ml-1 tabular-nums text-muted-foreground">{archivedFilesCount ?? "—"}</span>
            </button>
          </div>
          <p className="text-xs text-muted-foreground">{estateView === "archived" ? "Archived files" : "Current files"}</p>
        </div>
        <div className="relative group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground transition-colors group-focus-within:text-primary" />
          <Input
            placeholder="Search by name, file number, registry, or notes..."
            className="pl-10"
            value={search}
            onChange={(e) => handleSearchChange(e.target.value)}
          />
        </div>
        <div className="flex items-center justify-between gap-3" data-testid="estate-status-filter-control">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">File status</p>
            <p className="mt-0.5 text-xs text-muted-foreground">Choose a view without crowding the workspace.</p>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                type="button"
                variant="outline"
                data-testid="estate-status-filter-trigger"
                className="group h-10 min-w-[11.5rem] justify-between rounded-lg border-border/70 bg-card px-3 font-medium shadow-[0_1px_1px_rgba(15,23,42,0.06)] transition-[background-color,border-color,box-shadow,transform] duration-150 ease-out hover:border-primary/40 hover:bg-muted/30 hover:shadow-md active:scale-[0.98] data-[state=open]:border-primary/45 data-[state=open]:bg-primary/[0.045] data-[state=open]:shadow-md"
                aria-label={estateListCountState
                  ? `Filter estate files: ${estateListCountState.toLowerCase()}`
                  : `Filter estate files: ${selectedStatusOption.label}, ${selectedStatusCount} files`}
              >
                <span className="flex min-w-0 items-center gap-2">
                  <span className="truncate">{selectedStatusOption.label}</span>
                  <span className="rounded-md bg-muted px-1.5 py-0.5 text-[11px] tabular-nums text-muted-foreground">{selectedStatusCount ?? "—"}</span>
                </span>
                <ChevronDown className="ml-3 h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-150 ease-out group-data-[state=open]:rotate-180" aria-hidden="true" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
              align="end"
              sideOffset={8}
              className="w-[min(22rem,calc(100vw-2rem))] rounded-xl border-border/70 bg-popover/95 p-1.5 shadow-xl backdrop-blur supports-[backdrop-filter]:bg-popover/90"
            >
              <DropdownMenuLabel className="flex items-center justify-between px-2.5 py-2 text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">
                <span>Show files by status</span>
                <span className="normal-case tracking-normal">{estateListCountState ? `${estateListCountState} files` : `${estateListTotal} total`}</span>
              </DropdownMenuLabel>
              <DropdownMenuSeparator className="mx-1" />
              <DropdownMenuRadioGroup value={statusFilter} onValueChange={selectEstateStatusFilter}>
                {FILTER_OPTIONS.map((option) => {
                  const count = estateListSettled ? statusFilterCounts[option.value] ?? 0 : null;
                  const isSelected = option.value === statusFilter;
                  return (
                    <DropdownMenuRadioItem
                      key={option.value}
                      value={option.value}
                      data-testid={`estate-status-filter-option-${option.value}`}
                      className={`group min-h-10 rounded-lg py-2 pr-2.5 pl-8 transition-[background-color,color,transform] duration-150 ease-out focus:bg-primary/[0.08] focus:text-foreground data-[state=checked]:bg-primary/[0.08] data-[state=checked]:font-medium ${isSelected ? "text-foreground" : "text-muted-foreground"}`}
                    >
                      <span className="min-w-0 flex-1 truncate">{option.label}</span>
                      <span className="rounded-md border border-border/60 bg-background/70 px-1.5 py-0.5 text-[11px] font-medium tabular-nums text-muted-foreground">{count ?? "—"}</span>
                    </DropdownMenuRadioItem>
                  );
                })}
              </DropdownMenuRadioGroup>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </motion.div>

      {/* Notes search results */}
      {noteSearchResults && noteSearchResults.length > 0 && (
        <motion.div
          className="space-y-2"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          transition={{ duration: 0.2 }}
        >
          <p className="text-xs font-medium text-muted-foreground flex items-center gap-1">
            <StickyNote className="h-3 w-3" /> Notes matching "{noteSearchQuery}" ({noteSearchResults.length})
          </p>
          <div className="space-y-1.5 max-h-48 overflow-y-auto">
            {noteSearchResults.map((note: any) => {
              const estate = estates?.find((e) => e.id === note.estateId);
              const estateName = estate ? (estate.estateName || [estate.deceasedFirstName, estate.deceasedMiddleNames, estate.deceasedSecondMiddleName, estate.deceasedLastName].filter(Boolean).join(" ") || "Untitled Estate") : "Unknown";
              return (
                <div
                  key={note.id}
                  className="flex items-start gap-2 p-2 rounded-md border border-border/60 bg-card hover:bg-muted/30 cursor-pointer transition-colors"
                  onClick={() => setLocation(`/estate/${note.estateId}?tab=notes`)}
                >
                  {note.pinned === 1 && <Pin className="h-3 w-3 text-amber-500 fill-amber-500 shrink-0 mt-0.5" />}
                  <div className="min-w-0 flex-1">
                    <p className="text-xs text-muted-foreground font-medium">#{estate?.fileNumber} {estateName}</p>
                    <p className="text-xs text-foreground/80 truncate">{note.content}</p>
                  </div>
                  <span className="text-[10px] text-muted-foreground/60 shrink-0">
                    {fmtDisplayDate(note.createdAt)}
                  </span>
                </div>
              );
            })}
          </div>
        </motion.div>
      )}

      {/* Loading skeleton */}
      {isLoading ? (
        <EstateRowSkeleton />
      ) : isError ? (
        /* estate.list failed — show an explicit error, never the empty state (B1) */
        <motion.div
          className="flex flex-col items-center justify-center py-20 text-center"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
        >
          <AlertTriangle className="h-8 w-8 text-destructive/70 mb-4" />
          <p className="text-muted-foreground font-medium">Estate files could not be loaded</p>
          <p className="text-sm text-muted-foreground/60 mt-1 max-w-xs">
            The server could not be reached or returned an error. Your files are safe — try again.
          </p>
          <Button variant="outline" className="mt-4" onClick={() => refetch()}>
            Retry
          </Button>
        </motion.div>
      ) : filtered.length === 0 ? (
        <motion.div
          data-testid="estate-list-empty-state"
          className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border/80 bg-card/40 px-6 py-14 text-center sm:py-16"
          initial={prefersReducedMotion ? false : { opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={prefersReducedMotion ? { duration: 0 } : { duration: 0.22, ease: [0.23, 1, 0.32, 1] }}
        >
          <div className="relative mb-5 h-20 w-24" aria-hidden="true">
            <div className="absolute left-3 top-2 h-14 w-16 -rotate-6 rounded-md border border-border/50 bg-muted/30" />
            <div className="absolute left-5 top-1 h-14 w-16 -rotate-2 rounded-md border border-border/60 bg-muted/45" />
            <div className="absolute left-5 top-2 flex h-14 w-16 flex-col justify-center gap-1.5 rounded-md border border-border/80 bg-card px-3 shadow-sm">
              <div className="h-1.5 w-full rounded-full bg-muted-foreground/15" />
              <div className="h-1.5 w-4/5 rounded-full bg-muted-foreground/12" />
              <div className="h-1.5 w-1/2 rounded-full bg-muted-foreground/10" />
            </div>
            <div className="absolute bottom-0 right-0 flex size-8 items-center justify-center rounded-lg border border-primary/20 bg-primary/[0.06] text-primary">
              {estateView === "archived" ? <Archive className="h-4 w-4" /> : <Scale className="h-4 w-4" />}
            </div>
          </div>
          <h2 className="text-sm font-semibold text-foreground">
            {estates?.length === 0
              ? "No estate files yet"
              : estateView === "archived" && !search
                ? "No archived files"
                : estateView === "active" && !search
                  ? "No active files"
                  : "No files match this view"}
          </h2>
          <p className="mt-1 max-w-sm text-sm leading-6 text-muted-foreground">
            {estates?.length === 0
              ? "Create your first estate file to begin managing probate applications."
              : estateView === "archived" && !search
                ? "Archived estate files will remain here for reference and can be restored when needed."
                : estateView === "active" && !search
                  ? "Your current estate workspace is clear. Archived files remain available separately."
                  : "Try clearing the search or choose a different status filter."}
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-2">
            {estates?.length === 0 ? (
              <Button size="sm" className="probate-primary-action" onClick={() => setDialogOpen(true)}>
                <Plus className="mr-1 h-4 w-4" /> {isPersonalExecutor ? "Start Full Intake" : "Create first estate"}
              </Button>
            ) : estateView === "archived" && !search ? (
              <Button size="sm" variant="outline" onClick={() => { setEstateView("active"); setStatusFilter("active"); }}>
                Show active files
              </Button>
            ) : (
              <Button size="sm" variant="outline" onClick={() => { handleSearchChange(""); setStatusFilter(estateView === "archived" ? "archived" : "active"); }}>
                Clear search and filters
              </Button>
            )}
          </div>
        </motion.div>
      ) : (
        /* Keep an Active/Archived view change perceptible without delaying records. */
        <motion.div
          key={`estate-list-${estateView}`}
          data-testid={`estate-list-view-${estateView}`}
          className="grid grid-cols-1 gap-2"
          initial={prefersReducedMotion ? false : { opacity: 0, y: 4 }}
          animate={{ opacity: 1, y: 0 }}
          transition={prefersReducedMotion ? { duration: 0 } : { duration: 0.18, ease: [0.23, 1, 0.32, 1] }}
        >
          <motion.div
            className="grid grid-cols-1 gap-2"
            variants={staggerContainer}
            initial="hidden"
            animate="show"
          >
            <AnimatePresence>
            {filtered.map((estate) => {
              const displayName = estate.estateName || [estate.deceasedFirstName, estate.deceasedMiddleNames, estate.deceasedSecondMiddleName, estate.deceasedLastName].filter(Boolean).join(" ") || "Untitled Estate";
              // Calculate simple progress based on key milestones
              const progressChecks = [
                !!estate.deceasedFirstName && !!estate.deceasedLastName, // Name filled
                !!estate.dateOfDeath, // Date of death
                !!estate.registry, // Registry selected
                !!estate.domicileCity, // Domicile
                !!estate.willStorageKey || estate.hasWill === 0, // Will uploaded or intestate
              ];
              const progressPct = Math.round((progressChecks.filter(Boolean).length / progressChecks.length) * 100);
              const isEditing = editingNameId === estate.id;
              const nextAction = resolveDashboardNextAction(estate);
              return (
                <motion.div key={estate.id} variants={staggerItem} layout>
                  <div
                    className="estate-row-swipe-shell relative overflow-hidden rounded-lg md:overflow-visible"
                    onPointerDown={(event) => handleEstateSwipeStart(event, estate.id)}
                    onPointerMove={(event) => handleEstateSwipeMove(event, estate.id)}
                    onPointerUp={() => handleEstateSwipeEnd(estate.id)}
                    onPointerCancel={() => closeEstateSwipe(estate.id)}
                  >
                    {openSwipeEstateId === estate.id && (
                      <div className="estate-row-swipe-actions absolute inset-y-0 right-0 z-0 flex w-[164px] items-stretch md:hidden" aria-label={`Quick actions for ${displayName}`}>
                        <button
                          type="button"
                          className="flex w-1/2 flex-col items-center justify-center gap-1 bg-primary px-2 text-[11px] font-semibold text-primary-foreground"
                          onClick={(event) => {
                            event.stopPropagation();
                            closeEstateSwipe(estate.id);
                            setLocation(`/estate/${estate.id}`);
                          }}
                        >
                          Open file
                        </button>
                        <button
                          type="button"
                          className="flex w-1/2 flex-col items-center justify-center gap-1 bg-slate-700 px-2 text-[11px] font-semibold text-white transition-colors hover:bg-slate-800 dark:bg-slate-600 dark:hover:bg-slate-500"
                          onClick={(event) => {
                            event.stopPropagation();
                            closeEstateSwipe(estate.id);
                            archiveMutation.mutate({ id: estate.id, expectedRevision: estate.revision, data: { status: estate.status === "archived" ? "incomplete" : "archived" } });
                          }}
                        >
                          {estate.status === "archived" ? <ArchiveRestore className="h-4 w-4" aria-hidden="true" /> : <Archive className="h-4 w-4" aria-hidden="true" />}
                          {estate.status === "archived" ? "Restore" : "Archive"}
                        </button>
                      </div>
                    )}
                    <SpotlightCard
                      data-testid={`estate-row-${estate.id}`}
                      className={`relative z-10 cursor-pointer group estate-row-interactive estate-row-swipe-surface ${pressedEstateId === estate.id ? "estate-row-interactive--pressed" : ""}`}
                      style={{ transform: swipeOffsets[estate.id] ? `translateX(${swipeOffsets[estate.id]}px)` : undefined }}
                      onClick={() => {
                        if (suppressRowClickRef.current === estate.id) {
                          suppressRowClickRef.current = null;
                          return;
                        }
                        if (!isEditing) setLocation(`/estate/${estate.id}`);
                      }}
                      onPointerDown={(event) => {
                        if (event.pointerType === "mouse" || isEstateRowNestedControl(event.target)) return;
                        setPressedEstateId(estate.id);
                      }}
                      onPointerUp={() => setPressedEstateId((current) => current === estate.id ? null : current)}
                      onPointerCancel={() => setPressedEstateId((current) => current === estate.id ? null : current)}
                      onPointerLeave={() => setPressedEstateId((current) => current === estate.id ? null : current)}
                    >
                    <div className="space-y-2 p-3 sm:space-y-1.5 sm:px-4 sm:py-3">
                     <div className="flex items-start justify-between gap-2">
                      <div className="flex min-w-0 items-start gap-2 sm:items-center sm:gap-4">
                        <div className="w-auto shrink-0 pt-0.5 font-mono text-[11px] tabular-nums text-muted-foreground/70 sm:w-12 sm:pt-0 sm:text-sm">
                          #{estate.fileNumber}
                        </div>
                        <div className="min-w-0">
                          {isEditing ? (
                            <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                              <input
                                ref={editNameInputRef}
                                className="w-36 rounded border border-primary/40 px-1.5 py-0.5 text-sm font-medium focus:outline-none focus:ring-1 focus:ring-primary/50 sm:w-48"
                                value={editingNameValue}
                                onChange={(e) => setEditingNameValue(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === "Enter") {
                                    archiveMutation.mutate({ id: estate.id, expectedRevision: estate.revision, data: { estateName: editingNameValue } });
                                    setEditingNameId(null);
                                  } else if (e.key === "Escape") {
                                    setEditingNameId(null);
                                  }
                                }}
                                autoFocus
                              />
                              <button
                                className="p-0.5 rounded hover:bg-emerald-50 dark:hover:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  archiveMutation.mutate({ id: estate.id, expectedRevision: estate.revision, data: { estateName: editingNameValue } });
                                  setEditingNameId(null);
                                }}
                              >
                                <Check className="h-3.5 w-3.5" />
                              </button>
                              <button
                                className="p-0.5 rounded hover:bg-red-50 dark:hover:bg-red-950/30 text-red-600 dark:text-red-300"
                                onClick={(e) => { e.stopPropagation(); setEditingNameId(null); }}
                              >
                                <X className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1.5 min-w-0">
                              <p className="line-clamp-2 text-[13px] font-semibold leading-5 sm:truncate sm:text-sm" title={displayName}>{displayName}</p>
                              <button
                                className="p-0.5 rounded text-muted-foreground/40 hover:text-primary hover:bg-primary/5 transition-colors md:opacity-0 md:group-hover:opacity-100"
                                title="Rename estate"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setEditingNameId(estate.id);
                                  setEditingNameValue(estate.estateName || "");
                                }}
                              >
                                <Pencil className="h-3 w-3" />
                              </button>
                            </div>
                          )}
                          <p className="truncate text-[11px] leading-4 text-muted-foreground sm:text-xs">
                            {estate.registry || "No registry"} {estate.dateOfDeath ? `· d. ${fmtDisplayDate(estate.dateOfDeath)}` : ""}
                            {estate.grantType && !["grant_of_probate", "probate", "unknown"].includes(estate.grantType) ? ` · ${grantTypeLabel(estate.grantType)}` : ""}
                          </p>
                        </div>
                      </div>
                      <div className="flex shrink-0 items-center gap-1 sm:gap-2">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <button
                              onClick={(e) => e.stopPropagation()}
                              data-testid={`estate-status-${estate.id}`}
                              className={`estate-status-trigger inline-flex min-h-8 items-center gap-1 rounded-lg border px-2.5 text-[11px] font-semibold tracking-[-0.01em] transition-[background-color,border-color,color,box-shadow,transform] duration-150 sm:min-h-0 sm:rounded-md sm:px-2 sm:py-0.5 sm:text-xs ${STATUS_COLORS[estate.status] || ""}`}
                              aria-label={`Change status for ${displayName}; currently ${STATUS_LABELS[estate.status] || estate.status}`}
                            >
                              {STATUS_LABELS[estate.status] || estate.status}
                              <ChevronDown className="h-3 w-3 opacity-60" />
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
                            {Object.entries(STATUS_LABELS).filter(([k]) => k !== "archived").map(([value, label]) => (
                              <DropdownMenuItem
                                key={value}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  archiveMutation.mutate({ id: estate.id, expectedRevision: estate.revision, data: { status: value } });
                                }}
                                className={value === estate.status ? "font-medium" : ""}
                              >
                                <span className={`inline-block w-2 h-2 rounded-full mr-2 ${value === estate.status ? "bg-primary" : "bg-muted-foreground/30"}`} />
                                {label}
                              </DropdownMenuItem>
                            ))}
                          </DropdownMenuContent>
                        </DropdownMenu>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <button
                              type="button"
                              onClick={(e) => e.stopPropagation()}
                              className="inline-flex size-8 items-center justify-center rounded-md border border-border/70 text-muted-foreground transition-colors hover:border-primary/30 hover:bg-primary/5 hover:text-primary md:hidden"
                              aria-label={`More actions for ${displayName}`}
                              title={`More actions for ${displayName}`}
                            >
                              <MoreHorizontal className="h-4 w-4" aria-hidden="true" />
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
                            <DropdownMenuItem onClick={(e) => {
                              e.stopPropagation();
                              setEditingNameId(estate.id);
                              setEditingNameValue(estate.estateName || "");
                            }}>
                              <Pencil className="mr-2 h-3.5 w-3.5" /> Rename file
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={(e) => {
                              e.stopPropagation();
                              duplicateMutation.mutate({ id: estate.id });
                            }} disabled={duplicateMutation.isPending}>
                              <Copy className="mr-2 h-3.5 w-3.5" /> Duplicate file
                            </DropdownMenuItem>
                            <DropdownMenuItem className="transition-[background-color,color] duration-150 focus:bg-primary/[0.08] focus:text-foreground" onClick={(e) => {
                              e.stopPropagation();
                              exportMutation.mutate({ id: estate.id });
                            }} disabled={exportMutation.isPending}>
                              <Download className="mr-2 h-3.5 w-3.5" /> {exportMutation.isPending ? "Preparing export…" : "Export estate copy"}
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={(e) => {
                              e.stopPropagation();
                              archiveMutation.mutate({ id: estate.id, expectedRevision: estate.revision, data: { status: estate.status === "archived" ? "incomplete" : "archived" } });
                            }}>
                              {estate.status === "archived" ? <ArchiveRestore className="mr-2 h-3.5 w-3.5" /> : <Archive className="mr-2 h-3.5 w-3.5" />}
                              {estate.status === "archived" ? "Restore file" : "Archive file"}
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={(e) => {
                              e.stopPropagation();
                              const n = estate.estateName || [estate.deceasedFirstName, estate.deceasedMiddleNames, estate.deceasedSecondMiddleName, estate.deceasedLastName].filter(Boolean).join(" ") || "Untitled Estate";
                              setDeleteTarget({ id: estate.id, name: n, status: estate.status });
                              setDeleteDispositionBasis(estate.status === "archived" ? "retention_complete" : "created_in_error");
                              setDeleteConfirmation("");
                              setDeleteAttestationAccepted(false);
                            }}>
                              <Trash2 className="mr-2 h-3.5 w-3.5" /> Delete file
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            duplicateMutation.mutate({ id: estate.id });
                          }}
                          disabled={duplicateMutation.isPending}
                          className="hidden rounded-md p-1.5 text-muted-foreground/50 transition-colors hover:bg-blue-50 hover:text-blue-700 disabled:pointer-events-none disabled:opacity-40 dark:hover:bg-blue-950/30 dark:hover:text-blue-300 md:inline-flex md:opacity-0 md:group-hover:opacity-100"
                          title="Duplicate estate"
                        >
                          <Copy className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            exportMutation.mutate({ id: estate.id });
                          }}
                          disabled={exportMutation.isPending}
                          className="estate-row-icon-action hidden size-8 items-center justify-center rounded-md text-muted-foreground/60 disabled:pointer-events-none disabled:opacity-40 md:inline-flex md:opacity-0 md:group-hover:opacity-100 md:focus-visible:opacity-100"
                          title="Export estate copy"
                          aria-label={`Export ${displayName}`}
                        >
                          <Download className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (estate.status === "archived") {
                              archiveMutation.mutate({ id: estate.id, expectedRevision: estate.revision, data: { status: "incomplete" } });
                            } else {
                              archiveMutation.mutate({ id: estate.id, expectedRevision: estate.revision, data: { status: "archived" } });
                            }
                          }}
                          className="hidden rounded-md p-1.5 text-muted-foreground/50 transition-colors hover:bg-slate-100 hover:text-slate-800 dark:hover:bg-slate-800 dark:hover:text-slate-100 md:inline-flex md:opacity-0 md:group-hover:opacity-100"
                          title={estate.status === "archived" ? "Restore estate" : "Archive estate"}
                        >
                          {estate.status === "archived" ? <ArchiveRestore className="h-3.5 w-3.5" /> : <Archive className="h-3.5 w-3.5" />}
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            const n = estate.estateName || [estate.deceasedFirstName, estate.deceasedMiddleNames, estate.deceasedSecondMiddleName, estate.deceasedLastName].filter(Boolean).join(" ") || "Untitled Estate";
                            setDeleteTarget({ id: estate.id, name: n, status: estate.status });
                            setDeleteDispositionBasis(estate.status === "archived" ? "retention_complete" : "created_in_error");
                            setDeleteConfirmation("");
                            setDeleteAttestationAccepted(false);
                          }}
                          className="hidden rounded-md p-1.5 text-muted-foreground/50 transition-colors hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/30 dark:hover:text-red-300 md:inline-flex md:opacity-0 md:group-hover:opacity-100"
                          title="Delete estate"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                     </div>
                     {/* Progress bar */}
                     {progressPct < 100 && (
                       <div className="flex items-center gap-2 sm:pl-16">
                         <div className="flex-1 h-1 rounded-full bg-muted overflow-hidden">
                           <div className="h-full rounded-full bg-primary/60 transition-all" style={{ width: `${progressPct}%` }} />
                         </div>
                         <span className="text-[11px] tabular-nums text-muted-foreground/70 sm:text-[10px]">{progressPct}%</span>
                       </div>
                     )}
                     <div className="sm:pl-16" onClick={(e) => e.stopPropagation()}>
                       <button
                          type="button"
                          onClick={() => setLocation(`/estate/${estate.id}${nextAction.tab ? `?tab=${nextAction.tab}` : ""}`)}
                         className="estate-next-action inline-flex min-h-9 w-full max-w-full items-center justify-between gap-1.5 rounded-lg border border-slate-900 bg-slate-900 px-2.5 py-1.5 text-xs font-semibold text-white shadow-[0_2px_0_rgba(15,23,42,0.92),0_7px_16px_rgba(15,23,42,0.16)] transition-[background-color,border-color,box-shadow,transform] duration-150 hover:-translate-y-px hover:border-slate-800 hover:bg-slate-800 hover:shadow-[0_2px_0_rgba(15,23,42,0.92),0_10px_18px_rgba(15,23,42,0.2)] focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-400 focus-visible:ring-offset-2 active:translate-y-0 active:shadow-[0_1px_0_rgba(15,23,42,0.92)] dark:border-slate-100 dark:bg-slate-100 dark:text-slate-950 dark:hover:border-white dark:hover:bg-white sm:min-h-0 sm:w-auto sm:justify-start sm:rounded-md sm:px-2 sm:py-1 sm:text-[11px]"
                         aria-label={`Next action for ${displayName}: ${nextAction.label}`}
                         data-testid={`estate-next-action-${estate.id}`}
                       >
                         <CircleDot className="h-3 w-3 shrink-0" aria-hidden="true" />
                         <span className="truncate">Next: {nextAction.label}</span>
                       </button>
                     </div>
                     {/* Document indicators (letters + P8 + distribution) */}
                     <div className="flex items-center gap-4 pl-0 sm:pl-16 flex-wrap">
                     {(() => {
                       const intake = clientIntakeStatus?.[estate.id];
                       if (!intake?.hasCustomQuestions || !intake.pendingReview) return null;
                       return (
                         <button
                           type="button"
                           data-testid={`client-intake-status-${estate.id}`}
                           className="inline-flex min-h-7 items-center gap-1.5 rounded-md border border-primary/25 bg-primary/[0.045] px-2 py-1 text-[10px] font-semibold tracking-[0.005em] text-primary shadow-[0_1px_0_rgba(30,58,95,0.08)] transition-[background-color,border-color,box-shadow,transform] duration-150 hover:-translate-y-px hover:border-primary/40 hover:bg-primary/[0.08] hover:shadow-[0_4px_10px_rgba(30,58,95,0.12)] focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/45 focus-visible:ring-offset-2 active:translate-y-0 dark:border-primary/35 dark:bg-primary/10"
                           onClick={(event) => {
                             event.stopPropagation();
                             setLocation(`/estate/${estate.id}?tab=client-portal`);
                           }}
                           aria-label={`Client intake received for ${displayName}. Review in Client Portal`}
                         >
                           <ClipboardCheck className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                           <span>Client intake received</span>
                         </button>
                       );
                     })()}
                     {(() => {
                       const dStats = distributionStats?.[estate.id];
                       if (!dStats) return null;
                       if (dStats.hasShares && !dStats.isReconciled) {
                         return (
                           <div className="flex items-center gap-1.5">
                             <AlertTriangle className="h-3 w-3 text-red-500" />
                             <span className="text-[10px] font-medium text-red-600 dark:text-red-300">Distribution unreconciled</span>
                           </div>
                         );
                       } else if (!dStats.hasShares) {
                         return (
                           <div className="flex items-center gap-1.5">
                             <Scale className="h-3 w-3 text-muted-foreground/60" />
                            <span className="text-[10px] font-medium text-slate-600 dark:text-slate-300">No shares recorded</span>
                           </div>
                         );
                       }
                       return null;
                     })()}
                     {(() => {
                       const stats = letterStats?.[estate.id];
                       if (!stats || stats.needed === 0) return null;
                       const allDone = stats.generated >= stats.needed;
                       return (
                         <div className="flex items-center gap-1.5">
                           <FileText className="h-3 w-3 text-muted-foreground/60" />
                           <span className={`text-[10px] font-medium tabular-nums ${
                             allDone ? "text-emerald-700 dark:text-emerald-300" : "text-amber-700 dark:text-amber-300"
                           }`}>
                             Letters: {stats.generated}/{stats.needed}
                           </span>
                           <span className="text-[10px] text-muted-foreground/50">
                             {allDone ? "complete" : "needed"}
                           </span>
                         </div>
                       );
                     })()}
                     {(() => {
                       const stats = witnessStats?.[estate.id];
                       if (!stats || stats.needed === 0) return null;
                       const allDone = stats.generated >= stats.needed;
                       return (
                         <div className="flex items-center gap-1.5">
                           <FileText className="h-3 w-3 text-muted-foreground/60" />
                           <span className={`text-[10px] font-medium tabular-nums ${
                             allDone ? "text-emerald-700 dark:text-emerald-300" : "text-amber-700 dark:text-amber-300"
                           }`}>
                             P8: {stats.generated}/{stats.needed}
                           </span>
                           <span className="text-[10px] text-muted-foreground/50">
                             {allDone ? "complete" : "needed"}
                           </span>
                         </div>
                       );
                     })()}
                     </div>
                    </div>
                    </SpotlightCard>
                  </div>
                </motion.div>
              );
            })}
            </AnimatePresence>
          </motion.div>
        </motion.div>
      )}

      {/* Delete confirmation dialog */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => {
        if (!open) {
          setDeleteTarget(null);
          setDeleteConfirmation("");
          setDeleteAttestationAccepted(false);
        }
      }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Permanently destroy estate file?</AlertDialogTitle>
            <AlertDialogDescription className="space-y-3">
              <span className="block">This removes <strong>{deleteTarget?.name}</strong>, its database records, and every retained provider object. A retryable deletion record remains until permanent destruction is verified by post-deletion existence checks against the provider.</span>
              <span className="block">Under PIPA s. 35, destroy records only after their legal and business purposes have ended. Law-practice record obligations require complete and permanent destruction of stored records when destruction is authorized and instructed.</span>
              <span className="block">
                <a className="underline" href="https://www.bclaws.gov.bc.ca/civix/document/id/complete/statreg/00_03063_01#section35" target="_blank" rel="noreferrer">PIPA s. 35</a>
                {" · "}
                <a className="underline" href="https://www.lawsociety.bc.ca/for-lawyers/act-rules-and-code/law-society-rules/part-10-%E2%80%93-general/" target="_blank" rel="noreferrer">Law Society of BC rules on lawyers' records</a>
              </span>
            </AlertDialogDescription>
            <div className="space-y-3 text-sm">
              <div className="space-y-1">
                <Label htmlFor="estate-disposition-basis">Disposition basis</Label>
                <select
                  id="estate-disposition-basis"
                  className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm"
                  value={deleteDispositionBasis}
                  onChange={(event) => {
                    setDeleteDispositionBasis(event.target.value as "created_in_error" | "retention_complete");
                    setDeleteAttestationAccepted(false);
                  }}
                >
                  <option value="created_in_error">Created in error — never a client file</option>
                  <option value="retention_complete">Client-file retention period is complete</option>
                </select>
              </div>
              {deleteDispositionBasis === "retention_complete" && deleteTarget?.status !== "archived" && (
                <p className="text-xs text-destructive">Archive this estate first. Destruction of a client file is unavailable while it remains active.</p>
              )}
              <div className="flex items-start gap-2 rounded-md border p-3">
                <Checkbox
                  id="estate-disposition-attestation"
                  checked={deleteAttestationAccepted}
                  onCheckedChange={(checked) => setDeleteAttestationAccepted(checked === true)}
                />
                <Label htmlFor="estate-disposition-attestation" className="text-xs font-normal leading-relaxed">
                  {STORAGE_DISPOSITION_ATTESTATIONS[deleteDispositionBasis]}
                </Label>
              </div>
              <div className="space-y-1">
                <Label htmlFor="estate-destroy-confirmation">Type DESTROY to confirm</Label>
                <Input
                  id="estate-destroy-confirmation"
                  value={deleteConfirmation}
                  onChange={(event) => setDeleteConfirmation(event.target.value)}
                  autoComplete="off"
                />
              </div>
            </div>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700 text-white"
              onClick={() => {
                if (!deleteTarget) return;
                if (deleteDispositionBasis === "created_in_error") {
                  deleteMutation.mutate({
                    id: deleteTarget.id,
                    dispositionBasis: "created_in_error",
                    attestation: STORAGE_DISPOSITION_ATTESTATIONS.created_in_error,
                    confirmation: "DESTROY",
                  });
                } else {
                  deleteMutation.mutate({
                    id: deleteTarget.id,
                    dispositionBasis: "retention_complete",
                    attestation: STORAGE_DISPOSITION_ATTESTATIONS.retention_complete,
                    confirmation: "DESTROY",
                  });
                }
              }}
              disabled={deleteMutation.isPending
                || deleteConfirmation !== "DESTROY"
                || !deleteAttestationAccepted
                || (deleteDispositionBasis === "retention_complete" && deleteTarget?.status !== "archived")}
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

const TINT_STYLES: Record<string, { icon: string; number: string }> = {
  slate: { icon: "text-slate-500 dark:text-slate-400", number: "text-slate-800 dark:text-slate-100" },
  emerald: { icon: "text-emerald-600 dark:text-emerald-400", number: "text-emerald-800 dark:text-emerald-100" },
  amber: { icon: "text-amber-600 dark:text-amber-400", number: "text-amber-800 dark:text-amber-100" },
  violet: { icon: "text-violet-600 dark:text-violet-400", number: "text-violet-800 dark:text-violet-100" },
};

function MetricCard({ icon, label, value, tint = "slate", onClick }: {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
  tint?: "slate" | "emerald" | "amber" | "violet";
  onClick?: () => void;
}) {
  const styles = TINT_STYLES[tint];
  return (
    <div
      className={`liquid-glass liquid-glass--${tint} relative overflow-hidden rounded-xl p-4 ${onClick ? "cursor-pointer" : ""}`}
      onClick={onClick}
    >
      <div className="relative z-10">
        <div className={`mb-2 ${styles.icon}`}>{icon}</div>
        <p className={`text-2xl font-bold tabular-nums tracking-tight ${styles.number}`}>{value}</p>
        <p className="text-[11px] text-muted-foreground font-medium mt-1 uppercase tracking-wider">{label}</p>
      </div>
    </div>
  );
}
