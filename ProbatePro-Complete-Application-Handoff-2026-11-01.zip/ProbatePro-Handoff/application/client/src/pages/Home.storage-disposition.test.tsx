import React from "react";
import { act, fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { toast } from "sonner";
import { STORAGE_DISPOSITION_ATTESTATIONS } from "@shared/storageDisposition";

(globalThis as any).React = React;

const mocks = vi.hoisted(() => ({
  createMutate: vi.fn(),
  createOptions: null as any,
  createPending: false,
  deleteMutate: vi.fn(),
  updateMutate: vi.fn(),
  exportMutate: vi.fn(),
  exportPending: false,
  deleteOptions: null as any,
  invalidateDispositions: vi.fn(),
  navigate: vi.fn(),
  settings: { accountPurpose: "unselected" } as { accountPurpose: string },
  estateRows: null as any[] | null,
  estateListState: "success" as "success" | "loading" | "error",
  clientIntakeStatus: {} as Record<string, { hasCustomQuestions: boolean; pendingReview: boolean }>,
  queryString: "",
}));

vi.mock("wouter", () => ({ useLocation: () => ["/", mocks.navigate], useSearch: () => mocks.queryString }));
vi.mock("sonner", () => ({
  toast: { success: vi.fn(), error: vi.fn(), info: vi.fn() },
}));

vi.mock("@/lib/trpc", () => {
  const idleMutation = () => ({ mutate: vi.fn(), isPending: false });
  const invalidate = vi.fn();
  return {
    trpc: {
      estate: {
        list: { useQuery: () => ({
          data: mocks.estateListState === "success" ? mocks.estateRows ?? [{
            id: "estate-1",
            estateName: "Smith Estate",
            deceasedFirstName: "Alex",
            deceasedMiddleNames: "",
            deceasedSecondMiddleName: "",
            deceasedLastName: "Smith",
            fileNumber: 42,
            status: "incomplete",
            registry: "Vancouver",
            dateOfDeath: "",
            domicileCity: "",
            willStorageKey: "",
            hasWill: 1,
            grantType: "probate",
          }] : undefined,
          isLoading: mocks.estateListState === "loading",
          isError: mocks.estateListState === "error",
          refetch: vi.fn(),
        }) },
        dispositions: { useQuery: () => ({
          data: [{
            id: "disposition-old",
            estateLabel: "Prior Estate",
            fileNumber: 7,
            state: "retrying",
            objectCount: 3,
            requestedAt: 1_700_000_000_000,
            completedAt: null,
            lastError: "provider unavailable",
          }],
        }) },
        witnessStats: { useQuery: () => ({ data: {} }) },
        letterStats: { useQuery: () => ({ data: {} }) },
        distributionStats: { useQuery: () => ({ data: {} }) },
        create: {
          useMutation: (options: any) => {
            mocks.createOptions = options;
            return { mutate: mocks.createMutate, isPending: mocks.createPending };
          },
        },
        update: { useMutation: () => ({ mutate: mocks.updateMutate, isPending: false }) },
        duplicate: { useMutation: idleMutation },
        export: { useMutation: () => ({ mutate: mocks.exportMutate, isPending: mocks.exportPending }) },
        delete: {
          useMutation: (options: any) => {
            mocks.deleteOptions = options;
            return { mutate: mocks.deleteMutate, isPending: false };
          },
        },
      },
      deadline: { list: { useQuery: () => ({ data: { events: [] }, isError: false }) } },
      notes: { search: { useQuery: () => ({ data: [] }) } },
      clientIntake: { dashboardStatus: { useQuery: () => ({ data: mocks.clientIntakeStatus }) } },
      settings: { get: { useQuery: () => ({ data: mocks.settings }) } },
      useUtils: () => ({
        estate: { list: { invalidate }, dispositions: { invalidate: mocks.invalidateDispositions } },
        deadline: { list: { invalidate } },
      }),
    },
  };
});

import Home from "./Home";

beforeEach(() => {
  vi.clearAllMocks();
  mocks.createOptions = null;
  mocks.createPending = false;
  mocks.exportPending = false;
  mocks.deleteOptions = null;
  mocks.settings = { accountPurpose: "unselected" };
  mocks.estateRows = null;
  mocks.estateListState = "success";
  mocks.clientIntakeStatus = {};
  mocks.queryString = "";
  Object.defineProperty(window, "innerWidth", { configurable: true, value: 390, writable: true });
});

describe("personal executor first estate", () => {
  it("opens the existing create dialog from the one-shot welcome handoff without creating a record", () => {
    mocks.settings = { accountPurpose: "personal_executor" };
    mocks.estateRows = [];
    mocks.queryString = "start-intake=1";
    render(<Home />);
    expect(screen.getByRole("heading", { name: "Create New Estate File" })).toBeTruthy();
    expect(mocks.createMutate).not.toHaveBeenCalled();
    expect(mocks.navigate).toHaveBeenCalledWith("/", { replace: true });
    expect(screen.getByTestId("personal-executor-start-button").className).toContain("probate-primary-action");
    fireEvent.change(screen.getByPlaceholderText("e.g. Smith Estate, Johnson Probate"), { target: { value: "Sample Estate" } });
    fireEvent.click(screen.getByRole("button", { name: "Create Estate File" }));
    act(() => mocks.createOptions.onSuccess({ id: "estate-synthetic" }));
    expect(mocks.navigate).toHaveBeenCalledWith("/estate/estate-synthetic?tab=intake");
  });

  it("leaves lawyer estate creation unchanged", () => {
    render(<Home />);
    const newEstateButton = screen.getByTitle(/Create new estate/);
    expect(newEstateButton.className).toContain("probate-primary-action");
    fireEvent.click(newEstateButton);
    act(() => mocks.createOptions.onSuccess({ id: "lawyer-estate" }));
    expect(mocks.navigate).toHaveBeenCalledWith("/estate/lawyer-estate");
  });
});

describe("Home storage disposition controls", () => {
  it("does not show zero estate totals while the estate list is unresolved", () => {
    mocks.estateListState = "loading";
    render(<Home />);

    expect(screen.getByLabelText("Loading estate files")).toBeTruthy();
    expect(screen.queryByTestId("estate-list-empty-state")).toBeNull();
    expect(screen.getByRole("button", { name: /Active/ }).textContent).not.toContain("0");
    expect(screen.getByRole("button", { name: /Archived/ }).textContent).not.toContain("0");
    expect(screen.getByTestId("estate-status-filter-trigger").textContent).not.toContain("0");
  });

  it("does not show zero estate totals when the estate list fails", () => {
    mocks.estateListState = "error";
    render(<Home />);

    expect(screen.getByText("Estate files could not be loaded")).toBeTruthy();
    expect(screen.queryByTestId("estate-list-empty-state")).toBeNull();
    expect(screen.getByRole("button", { name: /Active/ }).textContent).not.toContain("0");
    expect(screen.getByRole("button", { name: /Archived/ }).textContent).not.toContain("0");
    expect(screen.getByTestId("estate-status-filter-trigger").textContent).not.toContain("0");
  });

  it("keeps a new-estate draft visible and shows a safe inline recovery message when creation fails", () => {
    render(<Home />);
    fireEvent.click(screen.getByTitle(/Create new estate/));
    const nameInput = screen.getByPlaceholderText("e.g. Smith Estate, Johnson Probate");
    fireEvent.change(nameInput, { target: { value: "Jordan Estate" } });
    fireEvent.click(screen.getByRole("button", { name: "Create Estate File" }));

    expect(mocks.createMutate).toHaveBeenCalledWith({
      estateName: "Jordan Estate",
      fileType: "probate_only",
      willStatus: "unknown",
      registry: "",
    });

    act(() => {
      mocks.createOptions.onError({
        message: "Failed query: INSERT INTO estates VALUES (private estate data)",
        data: { code: "INTERNAL_SERVER_ERROR" },
      });
    });

    expect(screen.getByRole("alert").textContent).toBe("We could not create this estate file. Please try again. If the problem continues, contact support.");
    expect((nameInput as HTMLInputElement).value).toBe("Jordan Estate");
    expect(screen.queryByText(/Failed query: INSERT/)).toBeNull();
    expect(toast.error).not.toHaveBeenCalled();

    fireEvent.change(nameInput, { target: { value: "Jordan Estate Updated" } });
    expect(screen.queryByRole("alert")).toBeNull();
    expect((nameInput as HTMLInputElement).value).toBe("Jordan Estate Updated");
  });

  it("disables duplicate New Estate submissions while the initial creation request is pending", () => {
    mocks.createPending = true;
    render(<Home />);
    fireEvent.click(screen.getByTitle(/Create new estate/));

    expect((screen.getByRole("button", { name: "Creating..." }) as HTMLButtonElement).disabled).toBe(true);
  });

  it("keeps provider destruction status visible after its estate is gone", () => {
    render(<Home />);
    expect(screen.getByRole("heading", { name: "Storage destruction audit" })).toBeTruthy();
    expect(screen.getByText("Prior Estate")).toBeTruthy();
    expect(screen.getByText("Provider retrying")).toBeTruthy();
    expect(screen.getByText(/Last provider error: provider unavailable/)).toBeTruthy();
  });

  it("switches between Active and Archived quick estate-list views while retaining the active-state cue", () => {
    render(<Home />);
    const active = screen.getByRole("button", { name: /Active 1/ });
    const archived = screen.getByRole("button", { name: /Archived 0/ });
    expect(active.getAttribute("aria-pressed")).toBe("true");

    fireEvent.click(archived);
    expect(archived.getAttribute("aria-pressed")).toBe("true");
    expect(screen.queryByText("Smith Estate")).toBeNull();
    expect(screen.getByTestId("estate-list-empty-state")).toBeTruthy();
    expect(screen.getByRole("heading", { name: "No archived files" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "Show active files" })).toBeTruthy();

    fireEvent.click(active);
    expect(active.getAttribute("aria-pressed")).toBe("true");
    expect(screen.getByText("Smith Estate")).toBeTruthy();
  });

  it("keeps status counts inside one persistent selector while the full status menu is open", () => {
    render(<Home />);

    const trigger = screen.getByTestId("estate-status-filter-trigger");
    expect(trigger.textContent).toContain("All");
    expect(trigger.textContent).toContain("1");
    expect(screen.queryByTestId("estate-status-filter-option-incomplete")).toBeNull();

    fireEvent.pointerDown(trigger, { button: 0, ctrlKey: false });
    expect(screen.getByTestId("estate-status-filter-option-all").textContent).toContain("1");
    expect(screen.getByTestId("estate-status-filter-option-needs_attention").textContent).toContain("1");
    expect(screen.getByTestId("estate-status-filter-option-incomplete").textContent).toContain("1");
    expect(screen.getByTestId("estate-status-filter-option-ready_to_file").textContent).toContain("0");

    fireEvent.click(screen.getByTestId("estate-status-filter-option-incomplete"));
    expect(trigger.textContent).toContain("Incomplete");
    expect(trigger.textContent).toContain("1");
    expect(screen.queryByTestId("estate-status-filter-option-incomplete")).toBeNull();
  });

  it("requires the exact created-in-error attestation and DESTROY confirmation", () => {
    render(<Home />);
    fireEvent.click(screen.getByTitle("Delete estate"));

    const destroy = screen.getByRole("button", { name: "Delete" });
    expect((destroy as HTMLButtonElement).disabled).toBe(true);
    expect(screen.getByText(STORAGE_DISPOSITION_ATTESTATIONS.created_in_error)).toBeTruthy();

    // Legal copy pins: no uncaptured LSBC rule-number claims, and the honest
    // description of how destruction is verified.
    expect(screen.getByText(/Law-practice record obligations require complete and permanent destruction of stored records when destruction is authorized and instructed\./)).toBeTruthy();
    expect(screen.getByText(/A retryable deletion record remains until permanent destruction is verified by post-deletion existence checks against the provider\./)).toBeTruthy();

    fireEvent.click(screen.getByRole("checkbox"));
    fireEvent.change(screen.getByLabelText("Type DESTROY to confirm"), { target: { value: "DESTROY" } });
    expect((destroy as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(destroy);

    expect(mocks.deleteMutate).toHaveBeenCalledWith({
      id: "estate-1",
      dispositionBasis: "created_in_error",
      attestation: STORAGE_DISPOSITION_ATTESTATIONS.created_in_error,
      confirmation: "DESTROY",
    });
  });

  it("keeps mobile secondary actions in a labelled menu while preserving the delete confirmation", () => {
    render(<Home />);
    const status = screen.getByTestId("estate-status-estate-1");
    expect(status.className).toContain("bg-slate-50");
    expect(status.className).not.toContain("amber");
    expect(status.getAttribute("aria-label")).toContain("currently Incomplete");
    const nextAction = screen.getByTestId("estate-next-action-estate-1");
    expect(nextAction.className).toContain("w-full");
    expect(nextAction.className).toContain("bg-slate-900");
    const moreActions = screen.getByRole("button", { name: "More actions for Smith Estate" });
    fireEvent.pointerDown(moreActions, { button: 0, ctrlKey: false });
    expect(screen.getByText("Rename file")).toBeTruthy();
    expect(screen.getByText("Duplicate file")).toBeTruthy();
    expect(screen.getByText("Export estate copy")).toBeTruthy();
    expect(screen.getByText("Delete file")).toBeTruthy();
    expect(screen.getByLabelText("Export Smith Estate").className).toContain("estate-row-icon-action");
  });

  it("routes a submitted custom intake signal to the lawyer review tab without exposing client details", () => {
    mocks.clientIntakeStatus = {
      "estate-1": { hasCustomQuestions: true, pendingReview: true },
    };
    render(<Home />);

    const status = screen.getByTestId("client-intake-status-estate-1");
    expect(status.textContent).toContain("Client intake received");
    expect(status.textContent).not.toContain("Jordan");
    expect(status.className).toContain("border-primary/25");
    expect(status.className).not.toContain("rounded-full");

    fireEvent.click(status);
    expect(mocks.navigate).toHaveBeenCalledWith("/estate/estate-1?tab=client-portal");
  });

  it("does not show a custom-intake signal without both current questions and a pending review", () => {
    mocks.clientIntakeStatus = {
      "estate-1": { hasCustomQuestions: false, pendingReview: true },
    };
    render(<Home />);
    expect(screen.queryByTestId("client-intake-status-estate-1")).toBeNull();
  });

  it("requests only the visible lawyer-owned estate when exporting a copy", () => {
    render(<Home />);
    const moreActions = screen.getByRole("button", { name: "More actions for Smith Estate" });
    fireEvent.pointerDown(moreActions, { button: 0, ctrlKey: false });
    fireEvent.click(screen.getByText("Export estate copy"));

    expect(mocks.exportMutate).toHaveBeenCalledWith({ id: "estate-1" });
  });

  it("adds a restrained touch press state only to the estate row itself", () => {
    render(<Home />);
    const row = screen.getByTestId("estate-row-estate-1");
    fireEvent.pointerDown(row, { pointerType: "touch" });
    expect(row.className).toContain("estate-row-interactive--pressed");
    fireEvent.pointerUp(row, { pointerType: "touch" });
    expect(row.className).not.toContain("estate-row-interactive--pressed");

    fireEvent.pointerDown(screen.getByTestId("estate-status-estate-1"), { pointerType: "touch" });
    expect(row.className).not.toContain("estate-row-interactive--pressed");
  });

  it("reveals explicit mobile Open file and Archive actions after a left swipe without auto-archiving", () => {
    render(<Home />);
    const row = screen.getByTestId("estate-row-estate-1");
    fireEvent.pointerDown(row, { pointerType: "touch", clientX: 240, clientY: 12, pointerId: 1 });
    fireEvent.pointerMove(row, { pointerType: "touch", clientX: 112, clientY: 12, pointerId: 1 });
    fireEvent.pointerUp(row, { pointerType: "touch", clientX: 112, clientY: 12, pointerId: 1 });
    expect(screen.getByRole("button", { name: "Open file" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "Archive" })).toBeTruthy();
    expect(mocks.updateMutate).not.toHaveBeenCalled();

    fireEvent.click(screen.getByRole("button", { name: "Open file" }));
    expect(mocks.navigate).toHaveBeenCalledWith("/estate/estate-1");
  });

  it("archives only after the separately revealed mobile Archive action is tapped", () => {
    render(<Home />);
    const row = screen.getByTestId("estate-row-estate-1");
    fireEvent.pointerDown(row, { pointerType: "touch", clientX: 240, clientY: 12, pointerId: 1 });
    fireEvent.pointerMove(row, { pointerType: "touch", clientX: 112, clientY: 12, pointerId: 1 });
    fireEvent.pointerUp(row, { pointerType: "touch", clientX: 112, clientY: 12, pointerId: 1 });
    fireEvent.click(screen.getByRole("button", { name: "Archive" }));
    expect(mocks.updateMutate).toHaveBeenCalledWith({
      id: "estate-1",
      expectedRevision: undefined,
      data: { status: "archived" },
    });
  });

  it("refreshes the durable audit after a successful deletion", () => {
    render(<Home />);
    mocks.deleteOptions.onSuccess({ destructionQueued: 2 });
    expect(mocks.invalidateDispositions).toHaveBeenCalledTimes(1);
    expect(toast.success).toHaveBeenCalledWith(
      "Estate file deleted; stored objects are queued for verified provider destruction",
    );
  });

  it("does not claim provider destruction when no stored objects were queued", () => {
    render(<Home />);
    mocks.deleteOptions.onSuccess({ destructionQueued: 0 });
    expect(toast.success).toHaveBeenCalledWith(
      "Estate deleted. No stored files required provider destruction.",
    );
  });
});
