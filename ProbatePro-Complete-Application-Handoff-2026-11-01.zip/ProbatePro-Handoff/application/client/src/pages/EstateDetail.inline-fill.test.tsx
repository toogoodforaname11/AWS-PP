/**
 * FormsTab ↔ PreGenerateDialog inline-fill wiring (RULES.md Rule 22 addendum).
 *
 * The dialog test proves the editors render and hand values back; the server
 * tests prove what the allowlist accepts. This file covers the glue only the
 * page can see:
 *   - "Apply & re-check" re-runs preflight with the typed values merged into
 *     the SAME overrides channel the pending generate will use (one merge —
 *     what cleared the gap is what the document prints)
 *   - save-to-intake CHECKED persists through estate.update with the CAS
 *     revision, and the generate still carries the values as overrides
 *   - save-to-intake UNCHECKED persists NOTHING and still renders from them
 *   - a failed save does not silently downgrade to override-only
 */
import React from "react";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { describe, expect, it, vi, beforeEach } from "vitest";

import { toast as mockedToast } from "sonner"; // the vi.mock below replaces the module; imported to assert on toast.error

vi.setConfig({ testTimeout: 45000 }); // 2026-08-21: jsdom EstateDetail suites breached 15-20s under full-suite worker contention (flake class, memory probatepro-test-flakiness) — headroom, not speed, keeps the gate reproducible

(globalThis as any).React = React;

vi.mock("sonner", () => ({
  toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }),
}));

const mocks = vi.hoisted(() => ({
  generateCalls: [] as any[],
  estateUpdateCalls: [] as any[],
  preflightCalls: [] as any[],
  requiredDocUpsertCalls: [] as any[],
  contacts: [] as any[],
  /** Gap rows the next preflight fetch returns; cleared as fields are filled. */
  pendingGapColumns: [] as string[],
  /** Doc-receipt gaps (Addendum 24.1); cleared once an upsert is recorded. */
  pendingDocGapKeys: [] as string[],
  /** When true, a non-generateAnyway preflight returns the na hard block. */
  naHardBlock: false,
  estateUpdateShouldFail: false,
  generateShouldFail: false,
  estateUpdateGate: null as Promise<void> | null,
  preflightGateCall: 0,
  preflightGate: null as Promise<void> | null,
  estateFetchResult: null as any,
  // ── Wave 2 row-edit recorders (inert for the pre-wave-2 tests above) ──
  contactUpdateCalls: [] as any[],
  inventoryUpdateCalls: [] as any[],
  contactUpdateShouldFail: false,
  /** Row-editor descriptors the preflight gap carries; null = no row gap. */
  pendingRowEditors: null as any[] | null,
  /** Ordered trace of row mutations, the preflight invalidate, and fetches. */
  ops: [] as string[],
  // ── Wave 2 quick-add (inventoryAdd) recorders ──
  inventoryCreateCalls: [] as any[],
  /** When true, the preflight gap carries the inventoryAdd descriptor until a create is recorded. */
  pendingQuickAddGap: false,
  /** 1-based index of the preflight fetch that should throw (0 = never). */
  preflightShouldFailCall: 0,
}));

vi.mock("@/lib/trpc", () => {
  const queryDataFor = (key: string): any => {
    if (key === "contact.list") return mocks.contacts;
    if (key === "document.list" || key === "document.versions" || key === "document.retainedFiles") return [];
    if (key === "document.getLetterRecipients") return [];
    if (key === "citation.list" || key === "delivery.list" || key === "delivery.getRecipients") return [];
    return undefined;
  };
  const mutationFor = (key: string, opts?: any) => ({
    mutate: (input: any) => {
      if (key === "document.generate") mocks.generateCalls.push(input);
    },
    mutateAsync: async (input: any) => {
      if (key === "document.generate") {
        mocks.generateCalls.push(input);
        if (mocks.generateShouldFail) {
          opts?.onError?.({ message: "Generation failed" });
          throw new Error("Generation failed");
        }
        return { success: true };
      }
      if (key === "estate.update") {
        if (mocks.estateUpdateShouldFail) {
          opts?.onError?.({ message: "CAS conflict" });
          throw new Error("CAS conflict");
        }
        if (mocks.estateUpdateGate) await mocks.estateUpdateGate;
        mocks.estateUpdateCalls.push(input);
        opts?.onSuccess?.({ success: true, revision: 9 });
        return { success: true, revision: 9 };
      }
      if (key === "requiredDoc.upsert") {
        mocks.requiredDocUpsertCalls.push(input);
        return { success: true };
      }
      if (key === "contact.update") {
        if (mocks.contactUpdateShouldFail) {
          opts?.onError?.({ message: "Contact update failed" });
          throw new Error("Contact update failed");
        }
        mocks.contactUpdateCalls.push(input);
        mocks.ops.push("contact.update");
        return { success: true };
      }
      if (key === "inventory.update") {
        mocks.inventoryUpdateCalls.push(input);
        mocks.ops.push("inventory.update");
        return { success: true };
      }
      if (key === "inventory.create") {
        mocks.inventoryCreateCalls.push(input);
        mocks.ops.push("inventory.create");
        return { id: `created-${mocks.inventoryCreateCalls.length}` };
      }
      return { success: true };
    },
    isPending: false,
  });
  function utilsNode(path: string[]): any {
    return new Proxy({} as any, {
      get(_t, prop: string) {
        if (prop === "invalidate") {
          // Same no-op contract as before, but traced so the wave-2 tests can
          // assert the awaited preflight drop lands BEFORE the re-check fetch.
          return () => {
            if (path.join(".") === "document.preflight") mocks.ops.push("invalidate:preflight");
            return undefined;
          };
        }
        if (prop === "setData" || prop === "cancel") return () => undefined;
        if (prop === "getData") return () => ({ id: "estate-1", revision: 4 });
        if (prop === "fetch") {
          return async (input: any) => {
            const key = path.join(".");
            if (key === "estate.get") return mocks.estateFetchResult;
            if (key === "document.preflight") {
              mocks.preflightCalls.push(input);
              mocks.ops.push("fetch:preflight");
              if (mocks.preflightShouldFailCall === mocks.preflightCalls.length) {
                throw new Error("preflight unavailable");
              }
              if (mocks.preflightGateCall === mocks.preflightCalls.length && mocks.preflightGate) {
                await mocks.preflightGate;
              }
              // Addendum 24.1: mimic the server's na hard block for requests
              // that do NOT carry generateAnyway — the stale-verdict shape the
              // escape hatch exists for.
              if (mocks.naHardBlock && input.generateAnyway !== true) {
                return {
                  formCode: input.formCode,
                  ok: false,
                  hardBlocked: true,
                  notApplicable: true,
                  gaps: [{
                    requirementId: `${String(input.formCode).toLowerCase()}_applicability`,
                    label: `${input.formCode} is not applicable`,
                    missingFields: [],
                    tab: "intake",
                    source: "formStatus()",
                    blocker: "hard",
                  }],
                };
              }
              // A gap survives only while its column is still unfilled in the
              // overrides the caller sent — this is what makes the re-check
              // shrink the list, exactly as the server engine would.
              const supplied = input.overrides || {};
              const gaps = mocks.pendingGapColumns
                .filter((column) => !supplied[column])
                .map((column) => ({
                  requirementId: `req_${column}`,
                  label: `Needs ${column}`,
                  missingFields: [`estate.${column}`],
                  tab: "intake",
                  source: "Test requirement",
                }));
              // Doc-receipt gaps clear once the matching upsert was recorded —
              // receipt is a PERSISTED record, never an override.
              const docGaps = mocks.pendingDocGapKeys
                .filter((k) => !mocks.requiredDocUpsertCalls.some((c) => c.docKey === k))
                .map((k) => ({
                  requirementId: `req_doc_${k}`,
                  label: `Receive ${k}`,
                  missingFields: [`requiredDocuments[docKey=${k}].received`],
                  tab: "readiness",
                  source: "Test requirement",
                }));
              // Wave 2: a row-editor gap survives until every named row's
              // update was persisted through the tabs' own mutations —
              // descriptors, not overrides, exactly as the server emitter
              // would re-resolve them after the writes.
              const rowEditors = (mocks.pendingRowEditors ?? []).filter((ed: any) => (ed.kind === "contact"
                ? !mocks.contactUpdateCalls.some((c) => c.id === ed.id)
                : !mocks.inventoryUpdateCalls.some((c) => c.id === ed.id)));
              const rowGaps = rowEditors.length === 0 ? [] : [{
                requirementId: "req_row_facts",
                label: "Row facts needed",
                missingFields: [],
                tab: "contacts",
                source: "Test requirement",
                editors: rowEditors,
              }];
              // Wave 2 quick-add: the gap survives until a create is recorded
              // — a persisted row, never an override.
              const quickAddGaps = mocks.pendingQuickAddGap && mocks.inventoryCreateCalls.length === 0
                ? [{
                    requirementId: "req_quick_add",
                    label: "At least one asset row",
                    missingFields: [],
                    tab: "inventory",
                    source: "Test requirement",
                    editors: [{ kind: "inventoryAdd", rowLabel: "Add first asset" }],
                  }]
                : [];
              const allGaps = [...gaps, ...docGaps, ...rowGaps, ...quickAddGaps];
              return { formCode: input.formCode, ok: allGaps.length === 0, gaps: allGaps };
            }
            if (key === "document.preflightMany") return [];
            return undefined;
          };
        }
        return utilsNode([...path, prop]);
      },
    });
  }
  function node(path: string[]): any {
    return new Proxy({} as any, {
      get(_t, prop: string) {
        if (prop === "useQuery") {
          return () => ({ data: queryDataFor(path.join(".")), isLoading: false, error: null });
        }
        if (prop === "useMutation") {
          return (opts?: any) => mutationFor(path.join("."), opts);
        }
        if (prop === "useUtils") return () => utilsNode([]);
        return node([...path, prop]);
      },
    });
  }
  return { trpc: node([]) };
});

const applicant = {
  id: "applicant-1",
  role: "applicant,executor",
  executorStatus: "applying",
  executorRank: "primary",
  name: "Alex Applicant",
};

function cleanEstate(overrides: Record<string, unknown> = {}) {
  return {
    id: "estate-1",
    revision: 4,
    grantType: "grant_of_probate",
    hasWill: 1,
    willType: "physical",
    isElectronicWill: 0,
    testamentaryDocStatus: "none_found",
    beliefLastBcWill: "yes",
    specialCircumstances: "none",
    willFilingType: "physical_original",
    foreignWillStatus: "made_in_bc",
    wesaS58Reliance: "no",
    ordersAffectingWill: "no",
    vsaCertificateResult: "no_notice",
    isMilitaryWill: "no",
    executionIssues: "no_issues",
    willAlterations: "no_alterations",
    willAppearanceIssues: "no",
    referencedDocuments: "no",
    willDocumentsAttached: "yes",
    otherGrantsStatus: "no_other_grants",
    notifyPGT: "no",
    pgtIsApplicant: "no",
    p1NotRequired: 1,
    deceasedDomiciledInBC: "yes",
    deceasedFirstName: "",
    deceasedLastName: "North",
    willDate: "2024-01-15",
    codicilFiles: "[]",
    applicantType: "executor",
    ...overrides,
  };
}

async function renderFormsTab() {
  const { FormsTab } = await import("./EstateDetail");
  render(<FormsTab estateId="estate-1" estate={cleanEstate()} onNavigateToTab={vi.fn()} />);
}

/**
 * Drive P13's Optional popup through to the gap dialog. P13 is the smallest
 * path with `supportsOverrides` set, so the pending mutation genuinely
 * consumes what the inline editors collect.
 */
async function openGapDialogViaP13() {
  await renderFormsTab();
  fireEvent.click(screen.getByTestId("form-generate-P13"));
  const tri = screen.getByTestId("fix-question-pgtIsApplicant");
  fireEvent.click(Array.from(tri.querySelectorAll("button")).find((b) => b.textContent === "Yes")!);
  fireEvent.click(screen.getByTestId("fix-confirm"));
  await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());
}

function typeInto(column: string, value: string): void {
  fireEvent.change(screen.getByTestId(`pre-generate-input-${column}`), { target: { value } });
}

beforeEach(() => {
  // Cascade containment (2026-08-21): if a sibling test TIMES OUT, its pending
  // continuation can render a second FormsTab AFTER that test's auto-cleanup
  // ran — the stale container then makes this test see duplicate testids
  // ("Found multiple elements by form-generate-P13"). Cleaning again up front
  // unmounts any late-registered container before this test renders.
  cleanup();
  mocks.generateCalls.length = 0;
  mocks.estateUpdateCalls.length = 0;
  mocks.preflightCalls.length = 0;
  mocks.requiredDocUpsertCalls.length = 0;
  mocks.contacts = [applicant];
  mocks.pendingGapColumns = ["deceasedFirstName"];
  mocks.pendingDocGapKeys = [];
  mocks.naHardBlock = false;
  mocks.estateUpdateShouldFail = false;
  mocks.generateShouldFail = false;
  mocks.estateUpdateGate = null;
  mocks.preflightGateCall = 0;
  mocks.preflightGate = null;
  mocks.estateFetchResult = cleanEstate();
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
});

describe("Apply & re-check merges into the one overrides channel", () => {
  it("re-runs preflight with the typed value ALONGSIDE the popup's answers", async () => {
    await openGapDialogViaP13();
    expect(mocks.preflightCalls.length).toBe(1);
    expect(mocks.preflightCalls[0].overrides).toEqual({ pgtIsApplicant: "yes" });

    typeInto("deceasedFirstName", "Margaret");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(mocks.preflightCalls.length).toBe(2));
    // The applicability answer is NOT lost when the inline value is added —
    // one merged object authorizes and renders.
    expect(mocks.preflightCalls[1].overrides).toEqual({
      pgtIsApplicant: "yes",
      deceasedFirstName: "Margaret",
    });
  });

  it("closes the dialog and generates from the merged set once the gap clears", async () => {
    await openGapDialogViaP13();
    typeInto("deceasedFirstName", "Margaret");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    // The re-check comes back ok → runWithPreflight fires the mutation and
    // must close the dialog first (the PART 5 re-entry fix).
    await waitFor(() => expect(mocks.generateCalls.length).toBe(1));
    expect(mocks.generateCalls[0]).toMatchObject({
      formCode: "P13",
      overrides: { pgtIsApplicant: "yes", deceasedFirstName: "Margaret" },
    });
    await waitFor(() => expect(screen.queryByTestId("pre-generate-dialog")).toBeNull());
  });
});

describe("save-to-intake", () => {
  it("atomically persists and renders every electronic-will medium axis selected inline", async () => {
    mocks.pendingGapColumns = ["willFilingType"];
    await openGapDialogViaP13();
    fireEvent.click(screen.getByTestId("pre-generate-input-willFilingType"));
    fireEvent.click(await screen.findByText("The electronic original."));
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(mocks.estateUpdateCalls.length).toBe(1));
    expect(mocks.estateUpdateCalls[0].data).toEqual({
      willFilingType: "electronic_original",
      willType: "electronic",
      isElectronicWill: 1,
    });
    await waitFor(() => expect(mocks.generateCalls.length).toBe(1));
    expect(mocks.generateCalls[0].overrides).toMatchObject({
      willFilingType: "electronic_original",
      willType: "electronic",
      isElectronicWill: 1,
    });
  });

  it("CHECKED persists the typed values with the CAS revision and still renders from them", async () => {
    await openGapDialogViaP13();
    typeInto("deceasedFirstName", "Margaret");
    expect(screen.getByTestId("pre-generate-save-to-intake").getAttribute("data-state")).toBe("checked");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(mocks.estateUpdateCalls.length).toBe(1));
    expect(mocks.estateUpdateCalls[0]).toMatchObject({
      id: "estate-1",
      expectedRevision: 4,
      data: { deceasedFirstName: "Margaret" },
    });
    // Only the inline value persists — the applicability answer stays
    // transient (Rule 22 §3 is untouched by the addendum).
    expect(mocks.estateUpdateCalls[0].data.pgtIsApplicant).toBeUndefined();
    await waitFor(() => expect(mocks.generateCalls.length).toBe(1));
    expect(mocks.generateCalls[0].overrides).toMatchObject({ deceasedFirstName: "Margaret" });
  });

  it("UNCHECKED persists NOTHING and still renders from the typed values", async () => {
    await openGapDialogViaP13();
    typeInto("deceasedFirstName", "Margaret");
    fireEvent.click(screen.getByTestId("pre-generate-save-to-intake"));
    expect(screen.getByTestId("pre-generate-save-to-intake").getAttribute("data-state")).toBe("unchecked");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(mocks.generateCalls.length).toBe(1));
    expect(mocks.generateCalls[0].overrides).toMatchObject({ deceasedFirstName: "Margaret" });
    expect(mocks.estateUpdateCalls).toEqual([]);
  });

  it("a failed save does not silently downgrade to override-only", async () => {
    // The user was told these values would reach the intake. If the write
    // fails, the run stops with the dialog intact rather than generating a
    // document off a promise the app did not keep.
    mocks.estateUpdateShouldFail = true;
    await openGapDialogViaP13();
    typeInto("deceasedFirstName", "Margaret");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(mocks.preflightCalls.length).toBe(1));
    expect(mocks.generateCalls).toEqual([]);
    expect(mocks.estateUpdateCalls).toEqual([]);
    expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy();
  });
});

describe("staleness guards around the two awaits", () => {
  it("Escape during the intake save cancels the suspended apply without generating", async () => {
    let releaseSave!: () => void;
    mocks.estateUpdateGate = new Promise<void>((resolve) => { releaseSave = resolve; });
    await openGapDialogViaP13();
    typeInto("deceasedFirstName", "Margaret");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(true));
    fireEvent.keyDown(document, { key: "Escape", code: "Escape" });
    await waitFor(() => expect(screen.queryByTestId("pre-generate-dialog")).toBeNull());

    await act(async () => { releaseSave(); });
    await new Promise((resolve) => setTimeout(resolve, 25));
    expect(mocks.generateCalls).toEqual([]);
  });

  it("X during the re-check cancels the suspended apply without generating", async () => {
    let releasePreflight!: () => void;
    mocks.preflightGateCall = 2;
    mocks.preflightGate = new Promise<void>((resolve) => { releasePreflight = resolve; });
    await openGapDialogViaP13();
    typeInto("deceasedFirstName", "Margaret");
    fireEvent.click(screen.getByTestId("pre-generate-save-to-intake"));
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(mocks.preflightCalls.length).toBe(2));
    const close = document.querySelector<HTMLButtonElement>('[data-slot="dialog-close"]');
    expect(close).toBeTruthy();
    fireEvent.click(close!);
    await waitFor(() => expect(screen.queryByTestId("pre-generate-dialog")).toBeNull());

    await act(async () => { releasePreflight(); });
    await new Promise((resolve) => setTimeout(resolve, 25));
    expect(mocks.generateCalls).toEqual([]);
  });

  it("a Proceed during the apply does not produce a SECOND generation", async () => {
    // handlePgApplyInline suspends on the save and again on the re-check. If
    // it resumed blind, the user clicking "Generate anyway" in that window
    // would consume the pending thunk AND the resumed apply would fire it
    // again — two filed drafts, the first missing the typed values.
    await openGapDialogViaP13();
    typeInto("deceasedFirstName", "Margaret");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    // Same tick, before the save resolves: the user proceeds.
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));

    await waitFor(() => expect(mocks.generateCalls.length).toBeGreaterThan(0));
    // Settle any resumed continuation before asserting the total.
    await new Promise((resolve) => setTimeout(resolve, 50));
    expect(mocks.generateCalls.length).toBe(1);
  });

  // Loop 3 (Nick 2026-09-02): "Generate anyway" applies the typed value first.
  // When the re-check comes back all-green the apply itself generates; the
  // dialog's follow-on proceed must then end quietly — ONE generation, the
  // value persisted, and never the XC-12 "Nothing is pending" error (review C2).
  it("Generate anyway with a typed value saves it, generates ONCE, and raises no false 'nothing pending' error", async () => {
    await openGapDialogViaP13();
    typeInto("deceasedFirstName", "Margaret");
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));

    await waitFor(() => expect(mocks.generateCalls.length).toBe(1));
    await new Promise((resolve) => setTimeout(resolve, 50));
    expect(mocks.estateUpdateCalls.length).toBe(1);
    expect(mocks.estateUpdateCalls[0].data).toEqual({ deceasedFirstName: "Margaret" });
    expect(mocks.generateCalls.length).toBe(1);
    expect((mockedToast as any).error).not.toHaveBeenCalledWith(expect.stringContaining("Nothing is pending"));
    await waitFor(() => expect(screen.queryByTestId("pre-generate-dialog")).toBeNull());
  });

  it("shows success only after a real generation resolves and restores a failed attempt for retry", async () => {
    mocks.generateShouldFail = true;
    await openGapDialogViaP13();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));

    await waitFor(() => expect(mocks.generateCalls.length).toBe(1));
    await waitFor(() => expect(screen.queryByTestId("pre-generate-loading")).toBeNull());
    expect(screen.queryByTestId("pre-generate-success")).toBeNull();
    expect((screen.getByTestId("pre-generate-proceed") as HTMLButtonElement).disabled).toBe(false);

    mocks.generateShouldFail = false;
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(mocks.generateCalls.length).toBe(2));
    await waitFor(() => expect(screen.getByTestId("pre-generate-success")).toBeTruthy());
  });

  it("re-applying after a successful save sends only what changed SINCE — no redundant intake rewrite", async () => {
    mocks.pendingGapColumns = ["deceasedFirstName", "courtFileNumber"];
    await openGapDialogViaP13();
    typeInto("deceasedFirstName", "Margaret");
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(mocks.estateUpdateCalls.length).toBe(1));
    // The court-file-number gap survives, so the dialog stays open for a second pass.
    await waitFor(() => expect(screen.getByTestId("pre-generate-input-courtFileNumber")).toBeTruthy());

    // Seed was re-banked, so the already-saved name is no longer "changed".
    fireEvent.change(screen.getByTestId("pre-generate-input-courtFileNumber"), { target: { value: "VAN-S-S-123456" } });
    // The apply button re-enables only once the first apply has fully settled
    // (the guard covers the save AND the re-check).
    await waitFor(() => expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(false));
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(mocks.estateUpdateCalls.length).toBe(2));
    expect(mocks.estateUpdateCalls[1].data).toEqual({ courtFileNumber: "VAN-S-S-123456" });
  });
});

// ── Addendum 24.1 integration coverage ───────────────────────────────────────

describe("inline doc-receipt apply (Addendum 24.1)", () => {
  it("persists the receipt via requiredDoc.upsert, never estate.update, and generates once the gap clears", async () => {
    mocks.pendingGapColumns = [];
    mocks.pendingDocGapKeys = ["death_certificate"];
    await openGapDialogViaP13();

    const box = screen.getByTestId("pre-generate-doc-death_certificate");
    fireEvent.click(box);
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(mocks.requiredDocUpsertCalls.length).toBe(1));
    expect(mocks.requiredDocUpsertCalls[0]).toMatchObject({
      estateId: "estate-1",
      docKey: "death_certificate",
      received: true,
    });
    // Doc-only apply must NOT touch estate.update (empty-patch guard).
    expect(mocks.estateUpdateCalls.length).toBe(0);
    // The re-check saw the recorded receipt, the gap cleared, and the pending
    // mutation fired.
    await waitFor(() => expect(mocks.generateCalls.length).toBe(1));
    expect(mocks.generateCalls[0]).toMatchObject({ formCode: "P13" });
  });
});

describe("na escape hatch wiring (Addendum 24.1)", () => {
  it("re-routes the na hard block through the fix dialog and carries generateAnyway on the second pass", async () => {
    mocks.pendingGapColumns = [];
    mocks.naHardBlock = true;
    // The mounted FormsTab prop says "no", but the server snapshot refreshed
    // after the na verdict says "yes". The reopened dialog must display and
    // render from this fresh snapshot, not mix the two points in time.
    mocks.estateFetchResult = cleanEstate({ pgtIsApplicant: "yes" });
    await renderFormsTab();

    // First pass: answer YES in the fix popup — the draft computes APPLICABLE,
    // so the popup sends generateAnyway=false; the (stale-verdict) server
    // still answers with the na hard block.
    fireEvent.click(screen.getByTestId("form-generate-P13"));
    const tri = screen.getByTestId("fix-question-pgtIsApplicant");
    fireEvent.click(Array.from(tri.querySelectorAll("button")).find((b) => b.textContent === "Yes")!);
    fireEvent.click(screen.getByTestId("fix-confirm"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());

    // The escape replaces the dead Blocked button…
    const escape = screen.getByTestId("pre-generate-override-na");
    expect(escape.textContent).toMatch(/Answer & generate anyway/);
    fireEvent.click(escape);

    // …and reopens the fix dialog from the refreshed estate snapshot. YES is
    // already selected; confirming without touching it proves the full
    // displayed snapshot (not merely changed fields) rides the request.
    await waitFor(() => expect(screen.getByTestId("fix-question-pgtIsApplicant")).toBeTruthy());
    const tri2 = screen.getByTestId("fix-question-pgtIsApplicant");
    expect(Array.from(tri2.querySelectorAll("button")).find((b) => b.textContent === "Yes")?.getAttribute("aria-pressed")).toBe("true");
    fireEvent.click(screen.getByTestId("fix-confirm"));

    await waitFor(() => expect(mocks.generateCalls.length).toBe(1));
    expect(mocks.generateCalls[0]).toMatchObject({
      formCode: "P13",
      generateAnyway: true,
      overrides: { pgtIsApplicant: "yes" },
    });
  });
});

// ── Inline-fill wave 2: persisted contact/inventory row edits ────────────────
//
// The dialog test proves the row editors collect and hand back the 4th
// onApplyInline argument (including quick-add/createInventory payloads); this
// block covers the page glue: handlePgApplyInline persists each row edit
// through the tabs' own mutations (contact.update / category-LESS
// inventory.update — the server's value mirrors read the stored category,
// 2026-08-21 review), awaits the document.preflight invalidate BEFORE the
// re-check fetch, and aborts the whole apply (no re-check, dialog stays open)
// when a row write fails. inventory.create is deliberately NOT wired here —
// the quick-add payload is pinned at the component level, and driving a full
// FormsTab create flow would only re-prove the same loop shape as update.

describe("row-edit persistence (wave 2)", () => {
  const rowEditors = () => ([
    {
      kind: "contact", id: "c1", rowLabel: "Jane Doe", column: "occupation",
      control: { control: "text", label: "Occupation" }, currentValue: "",
    },
    {
      kind: "inventory", id: "i1", rowLabel: "TD chequing", column: "value",
      control: { control: "currency", label: "Value (dollars)" }, currentValue: "",
      category: "financial",
    },
  ]);

  beforeEach(() => {
    mocks.contactUpdateCalls.length = 0;
    mocks.inventoryUpdateCalls.length = 0;
    mocks.contactUpdateShouldFail = false;
    mocks.pendingRowEditors = rowEditors();
    mocks.pendingGapColumns = [];
    mocks.ops.length = 0;
    mocks.inventoryCreateCalls.length = 0;
    mocks.pendingQuickAddGap = false;
    mocks.preflightShouldFailCall = 0;
  });

  it("persists contact.update and category-less inventory.update, awaits the preflight drop before the re-check, then generates", async () => {
    await openGapDialogViaP13();
    expect(screen.getByTestId("pre-generate-row-contact:c1").textContent).toContain("Jane Doe");

    fireEvent.change(screen.getByTestId("pre-generate-row-input-contact-c1-occupation"), { target: { value: "Retired" } });
    fireEvent.change(screen.getByTestId("pre-generate-row-input-inventory-i1-value"), { target: { value: "250.00" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(mocks.generateCalls.length).toBe(1));
    expect(mocks.contactUpdateCalls).toEqual([{ id: "c1", estateId: "estate-1", data: { occupation: "Retired" } }]);
    // Currency dollars → cents; NO category rider (2026-08-21 review: a
    // preflight-time category snapshot could revert a concurrent
    // reclassification — inventory.update's value mirrors read the STORED
    // category for category-less patches).
    expect(mocks.inventoryUpdateCalls).toEqual([{ id: "i1", estateId: "estate-1", data: { value: 25000 } }]);
    // Row edits are records, never estate columns — no estate.update ran.
    expect(mocks.estateUpdateCalls).toEqual([]);
    // Ordering contract (mirror of the doc-receipt style): the awaited
    // document.preflight invalidate lands AFTER the row writes and BEFORE the
    // re-check fetch — otherwise the re-check could read a cached report that
    // predates the persisted rows.
    expect(mocks.ops).toEqual([
      "fetch:preflight", // dialog-open preflight
      "contact.update",
      "inventory.update",
      "invalidate:preflight",
      "fetch:preflight", // the re-check reads only after the drop
    ]);
    await waitFor(() => expect(screen.queryByTestId("pre-generate-dialog")).toBeNull());
  });

  it("a failing contact.update aborts the apply: no re-check fetch, no generation, dialog stays open with values pending", async () => {
    mocks.contactUpdateShouldFail = true;
    await openGapDialogViaP13();
    fireEvent.change(screen.getByTestId("pre-generate-row-input-contact-c1-occupation"), { target: { value: "Retired" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    // Let the rejected mutateAsync and the resolved-false continuation settle.
    await act(async () => { await new Promise((resolve) => setTimeout(resolve, 25)); });

    // The apply resolved false: the dialog is still open and the typed value
    // was NOT banked, so Apply is re-armed for a retry…
    expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy();
    expect((screen.getByTestId("pre-generate-apply") as HTMLButtonElement).disabled).toBe(false);
    // …and nothing downstream ran: the inventory sibling was never attempted
    // (the loop aborted on the first failure), there was no re-check fetch
    // beyond the dialog-open one, and no generation fired.
    expect(mocks.inventoryUpdateCalls).toEqual([]);
    expect(mocks.preflightCalls.length).toBe(1);
    expect(mocks.generateCalls).toEqual([]);
  });

  it("quick-add creates the row ONCE across a retry after a failed re-check (no duplicate sworn asset)", async () => {
    // Radix Select prerequisites for jsdom (the component file's stub idiom).
    Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
    Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
    Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
    Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
    mocks.pendingRowEditors = null;
    mocks.pendingQuickAddGap = true;
    // The FIRST re-check (preflight fetch #2) fails AFTER the create persisted
    // — the exact create-succeeded-then-re-check-failed retry the one-shot
    // ledger exists for (2026-08-21 review, HIGH).
    mocks.preflightShouldFailCall = 2;

    await openGapDialogViaP13();
    expect(screen.getByTestId("pre-generate-inventory-add")).toBeTruthy();

    fireEvent.click(screen.getByTestId("pre-generate-add-category"));
    fireEvent.click(await screen.findByText("Financial Assets"));
    fireEvent.change(screen.getByTestId("pre-generate-add-description"), { target: { value: "TD account" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(mocks.inventoryCreateCalls.length).toBe(1));
    await act(async () => { await new Promise((resolve) => setTimeout(resolve, 25)); });
    // Re-check failed: no generation, dialog open, draft still pending.
    expect(mocks.generateCalls).toEqual([]);
    expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy();

    // Retry: the ledger skips the already-persisted row; the re-check now
    // succeeds (the created row cleared the gap) and generation proceeds.
    fireEvent.click(screen.getByTestId("pre-generate-apply"));
    await waitFor(() => expect(mocks.generateCalls.length).toBe(1));
    expect(mocks.inventoryCreateCalls.length).toBe(1);
    expect(mocks.inventoryCreateCalls[0]).toMatchObject({
      estateId: "estate-1", category: "financial", description: "TD account",
      location: "unknown", value: 0, valueRecorded: 0, passesToPersonalRepresentative: "",
    });
  });
});

// ── 2026-08-21 goal-loop pins ────────────────────────────────────────────────
//
// F3: a generation failure AFTER an all-green inline re-check restores the
//     continuation and reopens the (Ready) dialog — Proceed is a real retry
//     carrying the same merged overrides context.
// F2: the quick-add create carries the dialog-minted idempotency id through
//     inventory.create (id stability across retries is pinned at the component
//     level in PreGenerateDialog.test.tsx; the server replay is pinned in
//     server/routers.inventory.test.ts).
// F1: a deponent-selected run's na hard block still OFFERS the escape (the old
//     guard suppressed it on renderContext.selectedContactId — the P4
//     dead-end), and the deponent rides the re-route into the generate call.

describe("goal-loop fixes (2026-08-21)", () => {
  beforeEach(() => {
    // The wave-2 recorders are reset only by the wave-2 describe's own
    // beforeEach — mirror it here so these tests are order-independent.
    mocks.contactUpdateCalls.length = 0;
    mocks.inventoryUpdateCalls.length = 0;
    mocks.contactUpdateShouldFail = false;
    mocks.pendingRowEditors = null;
    mocks.ops.length = 0;
    mocks.inventoryCreateCalls.length = 0;
    mocks.pendingQuickAddGap = false;
    mocks.preflightShouldFailCall = 0;
  });

  it("F3: a generation failure after an all-green re-check reopens the Ready dialog and Proceed retries the SAME merged context", async () => {
    mocks.pendingGapColumns = [];
    mocks.pendingRowEditors = [{
      kind: "contact", id: "c1", rowLabel: "Jane Doe", column: "occupation",
      control: { control: "text", label: "Occupation" }, currentValue: "",
    }];
    mocks.generateShouldFail = true;
    await openGapDialogViaP13();

    fireEvent.change(screen.getByTestId("pre-generate-row-input-contact-c1-occupation"), { target: { value: "Retired" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    // The row write persisted and cleared the gap, the re-check came back
    // all-green, and the generation itself rejected. The old behavior closed
    // everything and dropped the merged overrides (typed answers lost when
    // save-to-intake was unchecked); now the dialog REOPENS in the Ready
    // state with the continuation restored.
    await waitFor(() => expect(mocks.generateCalls.length).toBe(1));
    expect(mocks.contactUpdateCalls).toEqual([{ id: "c1", estateId: "estate-1", data: { occupation: "Retired" } }]);
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());
    await waitFor(() => expect(screen.getByText(/Ready to generate/i)).toBeTruthy());
    const proceed = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
    expect(proceed.disabled).toBe(false);
    expect(screen.queryByTestId("pre-generate-success")).toBeNull();

    // Proceed goes through handlePgProceed with the RESTORED continuation —
    // the retry renders from the same merged overrides that authorized it.
    mocks.generateShouldFail = false;
    fireEvent.click(proceed);
    await waitFor(() => expect(mocks.generateCalls.length).toBe(2));
    expect(mocks.generateCalls[1]).toMatchObject({ formCode: "P13" });
    expect(mocks.generateCalls[1].overrides).toEqual({ pgtIsApplicant: "yes" });
    expect(mocks.generateCalls[1].overrides).toEqual(mocks.generateCalls[0].overrides);
    await waitFor(() => expect(screen.getByTestId("pre-generate-success")).toBeTruthy());
  });

  it("F2: the quick-add create carries the dialog-minted idempotency id (uuid) through inventory.create", async () => {
    mocks.pendingGapColumns = [];
    mocks.pendingQuickAddGap = true;
    await openGapDialogViaP13();

    fireEvent.click(screen.getByTestId("pre-generate-add-category"));
    fireEvent.click(await screen.findByText("Financial Assets"));
    fireEvent.change(screen.getByTestId("pre-generate-add-description"), { target: { value: "TD account" } });
    fireEvent.click(screen.getByTestId("pre-generate-apply"));

    await waitFor(() => expect(mocks.inventoryCreateCalls.length).toBe(1));
    // handlePgApplyInline forwards the id the dialog minted — the server's
    // idempotent replay depends on it arriving intact.
    expect(mocks.inventoryCreateCalls[0].id).toMatch(/^[0-9a-f-]{36}$/);
    await waitFor(() => expect(mocks.generateCalls.length).toBe(1));
  });

  it("F1: a deponent-selected P3 run hides the non-content availability row and carries the deponent through its draft action", async () => {
    mocks.pendingGapColumns = [];
    mocks.naHardBlock = true;
    await renderFormsTab();

    // P3 is the Required primary-applicant affidavit for this clean estate and
    // has a FORM_DETAILS entry: Generate opens the details dialog, whose sole
    // applying-applicant candidate becomes the run's selectedContactId.
    fireEvent.click(screen.getByTestId("form-generate-P3"));
    await waitFor(() => expect(screen.getByTestId("form-details-dialog")).toBeTruthy());
    fireEvent.click(screen.getByTestId("form-details-generate"));

    // The stale preflight verdict reports P3 as not applicable. That is an
    // availability decision, not content for the P3 face, so the content-only
    // popup must not render a hard card or a separate availability escape.
    // The pending renderContext still carries the selected sworn deponent.
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());
    expect(mocks.preflightCalls[0].selectedContactId).toBe("applicant-1");
    expect(screen.queryByTestId("pre-generate-override-na")).toBeNull();
    expect(screen.queryByTestId("pre-generate-hard-p3_applicability")).toBeNull();
    const proceed = screen.getByTestId("pre-generate-proceed");
    // With no face-content gap remaining, the action is deliberately cleanly
    // labelled “Generate”; the parent still converts this hidden availability
    // verdict into the explicit draft context below.
    expect(proceed.textContent).toBe("Generate");
    expect((proceed as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(proceed);

    await waitFor(() => expect(mocks.generateCalls.length).toBe(1));
    expect(mocks.generateCalls[0]).toMatchObject({
      formCode: "P3",
      generateAnyway: true,
      selectedContactId: "applicant-1",
    });
  });
});
