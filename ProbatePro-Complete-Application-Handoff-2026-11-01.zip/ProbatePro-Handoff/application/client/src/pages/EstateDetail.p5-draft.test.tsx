/** P5 optional draft access: real dialogs and download helper, faithful mutation callbacks. */
import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.setConfig({ testTimeout: 45000 });
(globalThis as any).React = React;

vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }) }));
import { toast } from "sonner";

const mocks = vi.hoisted(() => ({
  generateCalls: [] as any[],
  preflightCalls: [] as any[],
  estateUpdateCalls: [] as any[],
  generateError: null as Error | null,
  generateResponse: null as null | { id?: string; delivery?: unknown; filename?: string; format?: string },
  contacts: [] as any[],
  preflightReport: null as null | ((input: any) => any),
  previewInputs: [] as any[],
  /** document.generate's POST delivery (Nick, 2026-10-20), never a GET URL. */
  delivery: {
    method: "POST",
    action: "/api/download/form",
    fields: { estateId: "estate-18", formCode: "P5", documentId: "doc_p5_1", signatoryType: "lawyer", signatureDate: "2026-07-12", generateAnyway: "true" },
  },
}));

vi.mock("@/lib/trpc", () => {
  const mutation = (path: string, options?: any) => {
    const mutateAsync = async (input: any) => {
      if (path === "estate.update") mocks.estateUpdateCalls.push(input);
      try {
        if (path === "document.generate") {
          mocks.generateCalls.push(input);
          if (mocks.generateError) throw mocks.generateError;
        }
        const result = path === "document.generate"
          ? (mocks.generateResponse ?? { id: "doc_p5_1", delivery: mocks.delivery, filename: "P5_Alex_North.docx", format: "docx" })
          : {};
        await options?.onSuccess?.(result, input, undefined);
        return result;
      } catch (error) {
        await options?.onError?.(error, input, undefined);
        throw error;
      }
    };
    return { mutateAsync, mutate: (input: any) => { void mutateAsync(input).catch(() => undefined); }, isPending: false };
  };
  function utils(path: string[]): any {
    return new Proxy({}, {
      get(_target, property: string) {
        if (["invalidate", "setData", "cancel"].includes(property)) return () => undefined;
        if (property === "fetch") return async (input: any) => {
          if (path.join(".") === "document.preflight") {
            mocks.preflightCalls.push(input);
            if (mocks.preflightReport) return mocks.preflightReport(input);
            return {
              formCode: "P5", ok: false, hardBlocked: false, notApplicable: true,
              gaps: [{
                requirementId: "p5_applicability",
                label: "P5 applies only to administration without will annexed — use P3 or P4 for will-based grants. You can generate a draft for review.",
                missingFields: [], tab: "forms", source: "SCCR Rule 25-3 (2)",
              }, {
                requirementId: "p5_no_will_confirmation",
                label: "The estate records a will. P5 section 5 will be left blank for review.",
                missingFields: [], tab: "intake", source: "Form P5 section 5",
              }],
            };
          }
          if (path.join(".") === "document.preflightMany") return [];
          if (path.join(".") === "estate.get") return probateEstate();
          return undefined;
        };
        return utils([...path, property]);
      },
    });
  }
  function node(path: string[]): any {
    return new Proxy({}, {
      get(_target, property: string) {
        if (property === "useQuery") return (input?: any, options?: any) => {
          const key = path.join(".");
          if (key === "document.preview" && options?.enabled) mocks.previewInputs.push(input);
          const lists = ["document.list", "document.versions", "document.retainedFiles", "document.getLetterRecipients", "citation.list", "delivery.list", "delivery.getRecipients"];
          return { data: key === "contact.list" ? mocks.contacts : key === "document.preview" ? { sections: [{ type: "paragraph", text: "P5 draft" }] } : lists.includes(key) ? [] : undefined, isLoading: false, error: null };
        };
        if (property === "useMutation") return (options: any) => mutation(path.join("."), options);
        if (property === "useUtils") return () => utils([]);
        return node([...path, property]);
      },
    });
  }
  return { trpc: node([]) };
});

const applicant = { id: "applicant-1", role: "applicant,executor", executorStatus: "applying", executorRank: "primary", name: "Alex Applicant", relationship: "child" };
const probateEstate = () => ({
  id: "estate-18", grantType: "grant_of_probate", willStatus: "will", hasWill: 1,
  willType: "physical", willDate: "2024-01-15", willStorageKey: "estates/estate-18/will.pdf",
  isElectronicWill: 0, testamentaryDocStatus: "none_found", beliefLastBcWill: "yes",
  specialCircumstances: "none", willFilingType: "physical_original", foreignWillStatus: "made_in_bc",
  wesaS58Reliance: "no", ordersAffectingWill: "no", vsaCertificateResult: "no_notice", isMilitaryWill: "no",
  executionIssues: "no_issues", willAlterations: "no_alterations", willAppearanceIssues: "no",
  referencedDocuments: "no", willDocumentsAttached: "yes", otherGrantsStatus: "no_other_grants",
  notifyPGT: "no", pgtIsApplicant: "no", p1NotRequired: 1, deceasedDomiciledInBC: "yes",
  deceasedFirstName: "Alex", deceasedLastName: "North", codicilFiles: "[]", applicantType: "executor",
  intestateConsentState: "majority_consent", applicantIsNominee: 0, applicantIsGovernmentNominee: 0,
});

const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
/** Each same-tab form POST the page submits; the browser's attachment download follows it. */
const downloads: Array<{ method: string; action: string | null; fields: Record<string, string> }> = [];
const posted = (fields: Record<string, string>) => ({ method: "post", action: "/api/download/form", fields: { ...fields, attemptId: expect.stringMatching(UUID_V4) } });
beforeEach(() => {
  vi.clearAllMocks();
  mocks.generateCalls.length = 0;
  mocks.preflightCalls.length = 0;
  mocks.estateUpdateCalls.length = 0;
  mocks.generateError = null;
  mocks.generateResponse = null;
  mocks.contacts = [applicant];
  mocks.preflightReport = null;
  mocks.previewInputs.length = 0;
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
  downloads.length = 0;
  vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) {
    downloads.push({ method: this.method, action: this.getAttribute("action"), fields: Object.fromEntries(new FormData(this)) as Record<string, string> });
  });
});
afterEach(() => vi.restoreAllMocks());

async function openP5() {
  const estate = probateEstate();
  const { FormsTab } = await import("./EstateDetail");
  render(<FormsTab estateId="estate-18" estate={estate} onNavigateToTab={vi.fn()} />);
  expect(screen.getByTestId("form-badge-P5").textContent).toBe("Optional");
  fireEvent.click(screen.getByTestId("form-generate-P5"));
  expect(screen.getByTestId("fix-still-na").textContent).toContain("will-based grants");
  expect((screen.getByTestId("fix-confirm") as HTMLButtonElement).disabled).toBe(false);
  return estate;
}

async function chooseSelect(testId: string, name: string | RegExp) {
  fireEvent.keyDown(screen.getByTestId(testId), { key: "Enter" });
  fireEvent.click(await screen.findByRole("option", { name, exact: typeof name === "string" }));
}

async function confirmP5() {
  fireEvent.click(screen.getByTestId("fix-confirm"));
  await waitFor(() => expect(screen.getByTestId("form-details-dialog")).toBeTruthy());
  expect(screen.getByTestId("form-details-date")).toBeTruthy();
  fireEvent.click(screen.getByTestId("form-details-generate"));
  await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());
  expect(screen.getByTestId("pre-generate-dialog").textContent).toContain("section 5 will be left blank");
  const proceed = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
  expect(proceed.disabled).toBe(false);
  expect(proceed.textContent).toMatch(/Generate anyway/i);
  fireEvent.click(proceed);
}

describe("P5 optional draft on a probate file with a physical will", () => {
  it("changing grant type and Will Status to make P5 Required still requests a draft without saving intake", async () => {
    const estate = await openP5();
    await chooseSelect("fix-question-grantType", "Grant of Administration");
    fireEvent.click(Array.from(screen.getByTestId("fix-question-willStatus").querySelectorAll("button")).find((button) => button.textContent === "No will")!);
    expect(screen.getByTestId("fix-now-applicable").textContent).toContain("Required");
    await confirmP5();
    await waitFor(() => expect(downloads).toHaveLength(1));
    const overrides = { grantType: "grant_of_admin", willStatus: "no_will", hasWill: 0 };
    expect(mocks.preflightCalls[0]).toMatchObject({ generateAnyway: true, overrides });
    expect(mocks.generateCalls[0]).toMatchObject({ generateAnyway: true, overrides });
    expect(mocks.estateUpdateCalls).toEqual([]);
    expect(estate).toMatchObject({ grantType: "grant_of_probate", willStatus: "will", hasWill: 1 });
  });

  it("Required P5 missing facts still reaches a draft download through FormDetails", async () => {
    mocks.preflightReport = () => ({ formCode: "P5", ok: false, hardBlocked: false, gaps: [{ requirementId: "p5_testamentary_doc_status", label: "Testamentary-document search outcome is not recorded.", missingFields: [], tab: "intake", source: "Form P5 section 4" }] });
    const { FormsTab } = await import("./EstateDetail");
    const estate = { ...probateEstate(), grantType: "grant_of_admin", willStatus: "no_will", hasWill: 0, testamentaryDocStatus: "", otherGrantsStatus: "" };
    render(<FormsTab estateId="estate-18" estate={estate} onNavigateToTab={vi.fn()} />);
    expect(screen.getByTestId("form-badge-P5").textContent).toBe("Required");
    fireEvent.click(screen.getByTestId("form-generate-P5"));
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-proceed")).toBeTruthy());
    expect(mocks.preflightCalls[0]).toMatchObject({ formCode: "P5", generateAnyway: true });
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(mocks.generateCalls[0]).toMatchObject({ formCode: "P5", generateAnyway: true });
    expect(mocks.estateUpdateCalls).toEqual([]);
  });

  it("saves an explicit P5 section 2 paragraph from the direct form popup before generation", async () => {
    mocks.preflightReport = () => ({ formCode: "P5", ok: false, hardBlocked: false, gaps: [{ requirementId: "p5_testamentary_doc_status", label: "Testamentary-document search outcome is not recorded.", missingFields: [], tab: "intake", source: "Form P5 section 4" }] });
    const { FormsTab } = await import("./EstateDetail");
    const estate = { ...probateEstate(), grantType: "grant_of_admin", willStatus: "no_will", hasWill: 0, testamentaryDocStatus: "", otherGrantsStatus: "", applicantPriorityParagraph: "" };
    render(<FormsTab estateId="estate-18" estate={estate} onNavigateToTab={vi.fn()} />);

    fireEvent.click(screen.getByTestId("form-generate-P5"));
    expect(screen.getByTestId("form-details-applicantPriorityParagraph")).toBeTruthy();
    fireEvent.click(screen.getByTestId("form-details-applicantPriorityParagraph-c"));

    await waitFor(() => expect(mocks.estateUpdateCalls).toContainEqual(expect.objectContaining({
      data: { applicantPriorityParagraph: "c" },
    })));
    await waitFor(() => expect((screen.getByTestId("form-details-generate") as HTMLButtonElement).disabled).toBe(false));
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());
  });

  it("Required P4 missing facts carries Generate Anyway from Form Details to a draft DOCX request", async () => {
    mocks.preflightReport = () => ({ formCode: "P4", ok: false, hardBlocked: false, gaps: [{ requirementId: "p4_belief_last_will", label: "Confirm the applicant's belief that this is the last will dealing with British Columbia property.", missingFields: [], tab: "intake", source: "Form P4 section 5" }] });
    const { FormsTab } = await import("./EstateDetail");
    render(<FormsTab estateId="estate-18" estate={{ ...probateEstate(), willAlterations: "unauthorized" }} onNavigateToTab={vi.fn()} />);

    fireEvent.click(screen.getByTestId("form-generate-P4"));
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-proceed")).toBeTruthy());
    expect((screen.getByTestId("pre-generate-proceed") as HTMLButtonElement).textContent).toMatch(/Generate anyway/i);
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));

    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(mocks.generateCalls[0]).toMatchObject({ formCode: "P4", generateAnyway: true });
    expect(mocks.estateUpdateCalls).toEqual([]);
  });

  it("P4 keeps Generate Anyway retryable when generation returns no attachment", async () => {
    mocks.preflightReport = () => ({ formCode: "P4", ok: false, hardBlocked: false, gaps: [{ requirementId: "p4_belief_last_will", label: "Confirm the applicant's belief that this is the last will dealing with British Columbia property.", missingFields: [], tab: "intake", source: "Form P4 section 5" }] });
    mocks.generateResponse = { id: "doc_p4_1", filename: "P4_Alex_North.docx", format: "docx" };
    const { FormsTab } = await import("./EstateDetail");
    render(<FormsTab estateId="estate-18" estate={{ ...probateEstate(), willAlterations: "unauthorized" }} onNavigateToTab={vi.fn()} />);

    fireEvent.click(screen.getByTestId("form-generate-P4"));
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-proceed")).toBeTruthy());
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));

    await waitFor(() => expect(toast.error).toHaveBeenCalledWith(
      expect.stringContaining("P4 was not generated because no DOCX download was returned"),
      { duration: Infinity },
    ));
    expect(downloads).toEqual([]);
    expect(screen.queryByText("Document generated!")).toBeNull();
    expect(screen.getByTestId("document-generation-recovery").textContent).toContain("No document was created");
    expect(screen.getByTestId("document-generation-review-retry").textContent).toContain("Review P4 & retry");
    await waitFor(() => expect((screen.getByTestId("pre-generate-proceed") as HTMLButtonElement).disabled).toBe(false));
  });

  it("P4 shows the returned failure reason with durable review-and-retry guidance", async () => {
    mocks.preflightReport = () => ({ formCode: "P4", ok: false, hardBlocked: false, gaps: [{ requirementId: "p4_special_circumstances_followup", label: "Record the special-circumstances follow-up.", missingFields: [], tab: "intake", source: "Form P4 section 6(c)" }] });
    mocks.generateError = new Error("P4 section 6(c) requires one follow-up selection.");
    const { FormsTab } = await import("./EstateDetail");
    render(<FormsTab estateId="estate-18" estate={{ ...probateEstate(), specialCircumstances: "witness_assistance" }} onNavigateToTab={vi.fn()} />);

    fireEvent.click(screen.getByTestId("form-generate-P4"));
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-proceed")).toBeTruthy());
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));

    await waitFor(() => expect(screen.getByTestId("document-generation-recovery").textContent).toContain("requires one follow-up selection"));
    expect(screen.getByTestId("document-generation-recovery").textContent).toContain("The P4 answers remain available");
    expect(screen.getByTestId("document-generation-review-retry").textContent).toContain("Review P4 & retry");
    expect(toast.error).toHaveBeenCalledWith(expect.stringContaining("Apply & re-check or Generate anyway"), { duration: Infinity });
    expect(downloads).toEqual([]);
  });

  it("P4 Preview preserves Generate Anyway through Form Details into the preview and later download context", async () => {
    mocks.preflightReport = () => ({ formCode: "P4", ok: false, hardBlocked: false, gaps: [{ requirementId: "p4_belief_last_will", label: "Confirm the applicant's belief that this is the last will dealing with British Columbia property.", missingFields: [], tab: "intake", source: "Form P4 section 5" }] });
    const { FormsTab } = await import("./EstateDetail");
    render(<FormsTab estateId="estate-18" estate={{ ...probateEstate(), willAlterations: "unauthorized" }} onNavigateToTab={vi.fn()} />);

    fireEvent.click(screen.getByLabelText("Preview P4"));
    fireEvent.click(screen.getByTestId("form-details-preview"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-proceed")).toBeTruthy());
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));

    await waitFor(() => expect(mocks.previewInputs).not.toHaveLength(0));
    expect(mocks.previewInputs.at(-1)).toMatchObject({ formCode: "P4", generateAnyway: true, selectedContactId: applicant.id });
    expect(mocks.generateCalls).toEqual([]);
  });

  it("Required P5 Preview retains the draft flag from FormDetails through preflight into the preview", async () => {
    mocks.preflightReport = () => ({ formCode: "P5", ok: false, hardBlocked: false, gaps: [{ requirementId: "p5_testamentary_doc_status", label: "Testamentary-document search outcome is not recorded.", missingFields: [], tab: "intake", source: "Form P5 section 4" }] });
    const { FormsTab } = await import("./EstateDetail");
    render(<FormsTab estateId="estate-18" estate={{ ...probateEstate(), grantType: "grant_of_admin", willStatus: "no_will", hasWill: 0, testamentaryDocStatus: "", otherGrantsStatus: "" }} onNavigateToTab={vi.fn()} />);
    fireEvent.click(screen.getByLabelText("Preview P5"));
    fireEvent.click(screen.getByTestId("form-details-preview"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-proceed")).toBeTruthy());
    expect(mocks.preflightCalls[0]).toMatchObject({ formCode: "P5", generateAnyway: true });
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(mocks.previewInputs).not.toHaveLength(0));
    expect(mocks.previewInputs.at(-1)).toMatchObject({ formCode: "P5", generateAnyway: true, selectedContactId: applicant.id });
    expect(mocks.generateCalls).toEqual([]);
    expect(mocks.estateUpdateCalls).toEqual([]);
  });

  it("a selected secondary deponent is retained through the content-only P5 draft action", async () => {
    mocks.contacts = [applicant, { ...applicant, id: "second-applicant", name: "Taylor Spouse", executorRank: "secondary", relationship: "spouse" }];
    mocks.preflightReport = () => mocks.preflightCalls.length === 1
      ? { formCode: "P5", ok: false, hardBlocked: true, notApplicable: true, gaps: [{ requirementId: "p5_applicability", label: "The estate now records a will-based grant.", missingFields: [], tab: "forms", source: "Form P5", blocker: "hard" }] }
      : { formCode: "P5", ok: false, hardBlocked: false, notApplicable: true, gaps: [{ requirementId: "p5_applicability", label: "You can generate a P5 draft for review.", missingFields: [], tab: "forms", source: "Form P5" }] };
    const { FormsTab } = await import("./EstateDetail");
    render(<FormsTab estateId="estate-18" estate={{ ...probateEstate(), grantType: "grant_of_admin" }} onNavigateToTab={vi.fn()} />);
    fireEvent.click(screen.getByTestId("form-generate-P5"));
    await chooseSelect("form-details-deponent", /Taylor Spouse/);
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-proceed")).toBeTruthy());
    expect(screen.queryByTestId("pre-generate-override-na")).toBeNull();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(mocks.generateCalls[0]).toMatchObject({ formCode: "P5", generateAnyway: true, selectedContactId: "second-applicant" });
    expect(mocks.estateUpdateCalls).toEqual([]);
  });
  it("warns and downloads P5 with the existing will/standing answers and no intake edits", async () => {
    const estate = await openP5();
    expect(screen.getByTestId("fix-question-willStatus").querySelector('[aria-pressed="true"]')?.textContent).toBe("Will present");
    expect(screen.getByTestId("fix-p5-standing").textContent).toContain("paragraph (b)");
    await confirmP5();
    await waitFor(() => expect(downloads).toEqual([posted(mocks.delivery.fields)]));
    expect(mocks.preflightCalls[0]).toMatchObject({ formCode: "P5", generateAnyway: true });
    expect(mocks.generateCalls[0]).toMatchObject({ formCode: "P5", generateAnyway: true });
    expect(mocks.generateCalls[0].overrides).toBeUndefined();
    expect(toast.info).toHaveBeenCalledWith("Form generated — download requested. Check your browser's downloads.");
    expect(toast.error).not.toHaveBeenCalled();
    expect(mocks.estateUpdateCalls).toEqual([]);
    expect(estate).toMatchObject({ willStatus: "will", hasWill: 1, grantType: "grant_of_probate" });
  });

  it("carries No will and nominee answers for this draft while retaining the stored-will warning", async () => {
    const estate = await openP5();
    fireEvent.click(Array.from(screen.getByTestId("fix-question-willStatus").querySelectorAll("button")).find((button) => button.textContent === "No will")!);
    fireEvent.click(screen.getByTestId("fix-question-applicantIsNominee"));
    expect(screen.getByTestId("fix-p5-standing").textContent).toContain("paragraph (c)");
    await confirmP5();
    await waitFor(() => expect(downloads).toHaveLength(1));
    const expectedOverrides = { willStatus: "no_will", hasWill: 0, applicantIsNominee: 1 };
    expect(mocks.preflightCalls[0]).toMatchObject({ formCode: "P5", generateAnyway: true, overrides: expectedOverrides });
    expect(mocks.generateCalls[0]).toMatchObject({ formCode: "P5", generateAnyway: true, overrides: expectedOverrides });
    expect(mocks.generateCalls[0].overrides).not.toHaveProperty("grantType");
    expect(mocks.generateCalls[0].overrides).not.toHaveProperty("applicantPriorityParagraph");
    expect(mocks.estateUpdateCalls).toEqual([]);
    expect(estate).toMatchObject({ willStatus: "will", hasWill: 1, grantType: "grant_of_probate", willStorageKey: "estates/estate-18/will.pdf" });
  });

  it("a generation error remains visible and retry downloads the same requested P5", async () => {
    mocks.generateError = new Error("P5 upload failed. Try again.");
    await openP5();
    await confirmP5();
    await waitFor(() => expect(toast.error).toHaveBeenCalledWith("P5 upload failed. Try again."));
    expect(downloads).toEqual([]);
    expect(toast.success).not.toHaveBeenCalled();
    expect(toast.info).not.toHaveBeenCalled();
    expect(screen.queryByText("Document generated!")).toBeNull();
    await waitFor(() => expect((screen.getByTestId("pre-generate-proceed") as HTMLButtonElement).disabled).toBe(false));
    mocks.generateError = null;
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(mocks.generateCalls).toHaveLength(2);
    expect(mocks.generateCalls[1]).toEqual(mocks.generateCalls[0]);
    expect(mocks.estateUpdateCalls).toEqual([]);
  });
});
