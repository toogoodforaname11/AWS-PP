import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

// Heavy jsdom file: each test imports EstateDetail (a very large module) inside the
// test body. Same ceiling as the sibling audit specs.
vi.setConfig({ testTimeout: 45000 }); // 2026-08-21: jsdom EstateDetail suites breached 15-20s under full-suite worker contention (flake class, memory probatepro-test-flakiness) — headroom, not speed, keeps the gate reproducible

// tsconfig sets jsx:"preserve", so esbuild under vitest emits the classic
// React.createElement transform; vitest.config.ts has no react() plugin to supply the
// automatic runtime the app gets from vite.config.ts. IntakeTab renders ui/collapsible,
// which annotates React.ComponentProps without importing React — fine in the app, but
// undefined here. ponytail: harness gap, not a product bug — drop this line once
// vitest.config.ts sets esbuild.jsx:"automatic" (out of scope for this change).
(globalThis as any).React = React;

const mocks = vi.hoisted(() => ({
  contacts: [] as any[],
  estateUpdate: vi.fn(),
}));

vi.mock("sonner", () => ({
  toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }),
}));

vi.mock("@/lib/trpc", () => {
  const idleMutation = () => ({ mutate: vi.fn(), mutateAsync: vi.fn(async () => ({})), isPending: false });
  const invalidator = () => ({ invalidate: vi.fn() });
  return {
    trpc: {
      inventory: {
        list: { useQuery: () => ({ data: [], isLoading: false }) },
        totals: { useQuery: () => ({ data: undefined }) },
        create: { useMutation: idleMutation },
        update: { useMutation: idleMutation },
        delete: { useMutation: idleMutation },
        reorder: { useMutation: idleMutation },
        bulkCreate: { useMutation: idleMutation },
      },
      contact: { list: { useQuery: () => ({ data: mocks.contacts }) } },
      settings: { get: { useQuery: () => ({ data: { formFocusedIntake: false } }) } },
      notes: { pinned: { useQuery: () => ({ data: [] }) } },
      estate: {
        update: { useMutation: () => ({ mutate: mocks.estateUpdate, isPending: false, isSuccess: false }) },
        uploadWill: { useMutation: idleMutation },
        deleteWill: { useMutation: idleMutation },
        uploadCodicil: { useMutation: idleMutation },
        deleteCodicil: { useMutation: idleMutation },
        reorderCodicils: { useMutation: idleMutation },
        updateCodicilDate: { useMutation: idleMutation },
        uploadForeignGrant: { useMutation: idleMutation },
        deleteForeignGrant: { useMutation: idleMutation },
        uploadLegalEvidence: { useMutation: idleMutation },
        clearLegalEvidence: { useMutation: idleMutation },
      },
      useUtils: () => ({
        inventory: { list: invalidator(), totals: invalidator() },
        distribution: { compute: invalidator() },
        readiness: { check: invalidator(), timeline: invalidator() },
        deadline: { list: invalidator() },
        delivery: { getRecipients: invalidator() },
        estate: { get: invalidator(), list: invalidator() },
        document: { preflight: invalidator(), preflightMany: invalidator() },
      }),
    },
  };
});

const ESTATE_BASE = { id: "estate-1", p10FiledDate: "", p11FiledDate: "" };

const FIELD_LABEL = "Related material to be sealed with the court file (Form P13 — optional)";

async function components() {
  const estateDetail = await import("./EstateDetail");
  const { TooltipProvider } = await import("@/components/ui/tooltip");
  return { ...estateDetail, TooltipProvider };
}

beforeEach(() => {
  mocks.contacts = [];
  mocks.estateUpdate.mockReset();
  // Radix pointer interactions need these in jsdom.
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
  window.localStorage.clear();
});

// Rule 17 (2026-08-04): Form P13's optional face insertion "[add, if required:
// including the following related material ...[identify]...]" is fed by the
// lawyer-recorded estates.p13SealedMaterial (migration 0112). The field lives
// under the Rule 25-3(13) PGT-applicant question and only appears when that
// answer is "yes" — the only state in which P13 is generable at all.
describe("Rule 17 — P13 related-material intake field", () => {
  it("renders under a 'yes' PGT-applicant answer and persists via estate.update (markDirty class)", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const { unmount } = render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE, pgtIsApplicant: "yes" }} />
      </TooltipProvider>,
    );

    fireEvent.change(screen.getByLabelText(FIELD_LABEL), {
      target: { value: "the affidavit of assets and liabilities filed in this proceeding" },
    });
    // Intake persists on unmount (tab switch).
    unmount();

    expect(mocks.estateUpdate).toHaveBeenCalledWith(expect.objectContaining({
      id: "estate-1",
      data: expect.objectContaining({
        p13SealedMaterial: "the affidavit of assets and liabilities filed in this proceeding",
      }),
    }));
  });

  it("stays hidden while the PGT-applicant answer is not 'yes'", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE, pgtIsApplicant: "no" }} />
      </TooltipProvider>,
    );

    expect(screen.queryByLabelText(FIELD_LABEL)).toBeNull();
  });
});
