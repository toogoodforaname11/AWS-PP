// @vitest-environment jsdom
import { describe, expect, it } from "vitest";
import { canonicalizeEstateTabSearch, getEstateTabFromSearch, resolveVisibleEstateTab, showsFullWorkspaceWorkflow, visibleEstateTabs } from "./EstateDetail";

describe("EstateDetail legacy Documents deep links", () => {
  it("restores tab=documents to Readiness on initial load and canonicalizes the URL", () => {
    expect(getEstateTabFromSearch("?tab=documents")).toBe("readiness");
    expect(canonicalizeEstateTabSearch("?tab=documents")).toBe("tab=readiness");
  });

  it("uses the same compatibility mapping on later history-search changes", () => {
    const historySearches = ["?tab=intake", "?tab=documents", "?tab=forms"];
    expect(historySearches.map(getEstateTabFromSearch)).toEqual(["intake", "readiness", "forms"]);
  });

  it("preserves unrelated query parameters during canonical replacement", () => {
    expect(canonicalizeEstateTabSearch("?matter=abc&tab=documents&view=compact"))
      .toBe("matter=abc&tab=readiness&view=compact");
  });
});

describe("Form-focused workspace chrome", () => {
  it("removes operational timeline and work-summary surfaces only in the streamlined view", () => {
    expect(showsFullWorkspaceWorkflow(true)).toBe(false);
    expect(showsFullWorkspaceWorkflow(false)).toBe(true);
  });

  it("hides Readiness only in the streamlined tab navigation and safely resolves its deep link to Forms", () => {
    expect(visibleEstateTabs(false).map((tab) => tab.value)).toContain("readiness");
    expect(visibleEstateTabs(true).map((tab) => tab.value)).not.toContain("readiness");
    expect(visibleEstateTabs(true).map((tab) => tab.value)).toEqual(["intake", "contacts", "inventory", "forms", "client-portal", "notes", "activity"]);
    expect(resolveVisibleEstateTab("readiness", true)).toBe("forms");
    expect(resolveVisibleEstateTab("readiness", false)).toBe("readiness");
  });
});

describe("Estate Client Portal navigation", () => {
  it("keeps client review accessible in both intake modes and through an estate deep link", () => {
    expect(getEstateTabFromSearch("?tab=client-portal")).toBe("client-portal");
    for (const mode of [true, false]) expect(visibleEstateTabs(mode).find(tab => tab.value === "client-portal")?.label).toBe("Client Portal");
  });
});
