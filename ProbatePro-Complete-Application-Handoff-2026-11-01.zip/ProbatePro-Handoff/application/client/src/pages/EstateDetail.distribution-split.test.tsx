import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

// finding-12 (2026-07-27): the Distribution card's "Split equally" button was gated on
// `distResult.shares.length >= 0` — ALWAYS TRUE — so it showed on every testate file, and
// one click immediately overwrote every beneficiary's share/shareType/estimatedValue with
// no confirmation. `shares` is not the beneficiary count either: buildTestateDistribution
// filters on `b.share || b.estimatedValue` (shared/types.ts:3605), so gating on it would
// hide the button exactly when nothing has been recorded yet. The gate now reads the same
// predicate the route overwrites, and the click goes through the file's established
// controlled-AlertDialog confirmation idiom.

vi.setConfig({ testTimeout: 45000 }); // 2026-08-21: jsdom EstateDetail suites breached 15-20s under full-suite worker contention (flake class, memory probatepro-test-flakiness) — headroom, not speed, keeps the gate reproducible
(globalThis as any).React = React;

const mocks = vi.hoisted(() => ({
  splitEqually: vi.fn(),
  contacts: { value: [] as any[] },
}));

vi.mock("sonner", () => ({
  toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }),
}));

vi.mock("@/lib/trpc", () => {
  const idleMutation = () => ({ mutate: vi.fn(), mutateAsync: vi.fn(async () => ({})), isPending: false });
  const invalidator = () => ({ invalidate: vi.fn() });
  return {
    trpc: {
      distribution: {
        compute: {
          useQuery: () => ({
            data: {
              shares: [], totalDistributionCents: 0, netEstateCents: 0,
              isReconciled: true, wesaSection: "", warnings: [],
            },
            isLoading: false,
          }),
        },
        updateShare: { useMutation: idleMutation },
        splitEqually: { useMutation: () => ({ mutate: mocks.splitEqually, isPending: false }) },
      },
      contact: {
        list: { useQuery: () => ({ data: mocks.contacts.value }) },
        create: { useMutation: idleMutation },
        update: { useMutation: idleMutation },
      },
      estate: { update: { useMutation: idleMutation } },
      useUtils: () => ({
        contact: { list: invalidator() },
        deadline: { list: invalidator() },
        distribution: { compute: invalidator() },
        document: { preflight: invalidator(), preflightMany: invalidator() },
        estate: { get: invalidator() },
        readiness: { check: invalidator(), timeline: invalidator() },
      }),
    },
  };
});

async function components() {
  const estateDetail = await import("./EstateDetail");
  const { TooltipProvider } = await import("@/components/ui/tooltip");
  return { ...estateDetail, TooltipProvider };
}

const beneficiary = (id: string, name: string, extra: any = {}) => ({
  id, name, role: "beneficiary", isPredeceased: 0, share: "", shareType: "", estimatedValue: 0, ...extra,
});

// The control is testate-only — an intestacy hides it regardless of beneficiaries.
const testateEstate = { id: "estate-1", grantType: "grant_of_probate", hasWill: 1 };

async function renderCard() {
  const { DistributionCard, TooltipProvider } = await components();
  return render(
    <TooltipProvider>
      <DistributionCard estateId="estate-1" estate={{ ...testateEstate }} />
    </TooltipProvider>,
  );
}

beforeEach(() => {
  mocks.splitEqually.mockReset();
  mocks.contacts.value = [];
});

describe("Distribution card — Split equally is gated and confirmed (finding-12)", () => {
  it("hides the button entirely when the estate has no beneficiaries", async () => {
    mocks.contacts.value = [{ id: "x1", name: "Executor Only", role: "executor", isPredeceased: 0 }];
    await renderCard();
    expect(screen.queryByText("Split equally")).toBeNull();
  });

  it("shows the button once beneficiaries exist, and a click only OPENS the confirmation — it does not mutate", async () => {
    mocks.contacts.value = [beneficiary("b1", "Ada"), beneficiary("b2", "Ben")];
    await renderCard();

    const button = screen.getByText("Split equally");
    expect(button).toBeTruthy();
    expect(mocks.splitEqually).not.toHaveBeenCalled();

    fireEvent.click(button);
    expect(screen.getByText(/Set affected beneficiaries to an equal split\?/)).toBeTruthy();
    // The click opened a dialog and nothing else — the old code mutated right here.
    expect(mocks.splitEqually).not.toHaveBeenCalled();
  });

  it("cancelling the confirmation makes no mutation call", async () => {
    mocks.contacts.value = [beneficiary("b1", "Ada"), beneficiary("b2", "Ben")];
    await renderCard();

    fireEvent.click(screen.getByText("Split equally"));
    fireEvent.click(screen.getByText("Cancel"));

    expect(mocks.splitEqually).not.toHaveBeenCalled();
  });

  it("confirming fires the mutation exactly once", async () => {
    mocks.contacts.value = [beneficiary("b1", "Ada"), beneficiary("b2", "Ben")];
    await renderCard();

    fireEvent.click(screen.getByText("Split equally"));
    fireEvent.click(screen.getByText("Overwrite shares"));

    expect(mocks.splitEqually).toHaveBeenCalledTimes(1);
    expect(mocks.splitEqually).toHaveBeenCalledWith({ estateId: "estate-1" });
  });

  it("names the shares that will be replaced and the predeceased beneficiaries that are skipped", async () => {
    mocks.contacts.value = [
      beneficiary("b1", "Ada", { share: "60", shareType: "percentage", estimatedValue: 60000 }),
      beneficiary("b2", "Ben", { isPredeceased: 1 }),
      beneficiary("b3", "Cy"),
    ];
    await renderCard();
    fireEvent.click(screen.getByText("Split equally"));

    // 2 living records are written from 3 beneficiary records — the lapsed portion is not redistributed.
    expect(screen.getByText(/2 affected living beneficiaries from 3 beneficiary records/)).toBeTruthy();
    expect(screen.getByText(/This is an action count, not a Form P10 row count/)).toBeTruthy();
    expect(screen.getByText(/Shares already recorded, which will be replaced:\s*Ada\./)).toBeTruthy();
    expect(screen.getByText(/Skipped as recorded predeceased:\s*Ben\./)).toBeTruthy();
    expect(screen.getByText(/WESA s\.46 gift-over/)).toBeTruthy();
    // The confirm copy must say the will has to actually direct an equal division.
    expect(screen.getByText(/Only do this if the will actually directs an equal\s+division/)).toBeTruthy();
  });

  it("warns that a predeceased beneficiary's EXISTING share survives and still prints on Form P10", async () => {
    // buildTestateDistribution has no isPredeceased filter, so telling the lawyer the
    // portion is simply "left unallocated" would be false here.
    mocks.contacts.value = [
      beneficiary("b1", "Ada"),
      beneficiary("b2", "Ben", { isPredeceased: 1, share: "50", shareType: "percentage", estimatedValue: 50000 }),
    ];
    await renderCard();
    fireEvent.click(screen.getByText("Split equally"));

    expect(screen.getByText(/Ben already carries a recorded share/)).toBeTruthy();
    expect(screen.getByText(/will still print on Form P10/)).toBeTruthy();
    expect(screen.getByText(/will not total 100%/)).toBeTruthy();
  });

  it("hides the button on an intestacy even when beneficiaries exist", async () => {
    mocks.contacts.value = [beneficiary("b1", "Ada")];
    const { DistributionCard, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <DistributionCard estateId="estate-1" estate={{ id: "estate-1", grantType: "admin_no_will", hasWill: 0 }} />
      </TooltipProvider>,
    );
    expect(screen.queryByText("Split equally")).toBeNull();
  });
});
