import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

const { setLocation } = vi.hoisted(() => ({ setLocation: vi.fn() }));

vi.mock("wouter", () => ({
  useLocation: () => ["/missing-record", setLocation],
}));

import NotFound from "./NotFound";

describe("NotFound", () => {
  afterEach(() => {
    setLocation.mockReset();
    vi.restoreAllMocks();
  });

	it("offers clear, safe route recovery without suggesting that estate data was changed", () => {
	  render(<NotFound />);

	  expect(screen.getByRole("heading", { name: /doesn’t point to a ProbatePro page/i })).toBeTruthy();
	  expect(screen.getByText(/estate files and saved work have not been changed/i)).toBeTruthy();
	  expect(screen.getByRole("img", { name: /open estate file and navigation compass/i })).toBeTruthy();
	  expect(screen.getByRole("navigation", { name: /helpful navigation/i })).toBeTruthy();
	  expect(screen.getByRole("button", { name: "Return to ProbatePro" })).toBeTruthy();
	  expect(screen.getByRole("button", { name: "Go back" })).toBeTruthy();
	  expect(screen.getByRole("button", { name: /start at home/i })).toBeTruthy();
	  expect(screen.getByRole("button", { name: /privacy/i })).toBeTruthy();
	  expect(screen.getByRole("button", { name: /terms/i })).toBeTruthy();
	});

  it("routes the primary recovery action to the application home", () => {
    render(<NotFound />);

    fireEvent.click(screen.getByRole("button", { name: "Return to ProbatePro" }));

	  expect(setLocation).toHaveBeenCalledWith("/");
	});

	it("routes each helpful navigation choice through the safe application router", () => {
	  render(<NotFound />);

	  fireEvent.click(screen.getByRole("button", { name: /privacy/i }));
	  fireEvent.click(screen.getByRole("button", { name: /terms/i }));

	  expect(setLocation).toHaveBeenNthCalledWith(1, "/privacy");
	  expect(setLocation).toHaveBeenNthCalledWith(2, "/terms");
	});

	it("keeps an accessible legal-file illustration available if the generated asset cannot load", () => {
	  render(<NotFound />);

	  fireEvent.error(screen.getByRole("img", { name: /open estate file and navigation compass/i }));

	  expect(screen.getByTestId("not-found-illustration-fallback")).toBeTruthy();
	  expect(screen.getByRole("img", { name: /open estate file and navigation compass/i })).toBeTruthy();
	});

	it("marks the illustration for the calm reduced-motion-safe animation treatment", () => {
	  render(<NotFound />);

	  expect(screen.getByTestId("not-found-illustration-motion").className).toContain("probate-404-illustration");
	});

  it("uses browser navigation for the secondary recovery action", () => {
    const back = vi.spyOn(window.history, "back").mockImplementation(() => undefined);
    render(<NotFound />);

    fireEvent.click(screen.getByRole("button", { name: "Go back" }));

    expect(back).toHaveBeenCalledTimes(1);
  });
});
