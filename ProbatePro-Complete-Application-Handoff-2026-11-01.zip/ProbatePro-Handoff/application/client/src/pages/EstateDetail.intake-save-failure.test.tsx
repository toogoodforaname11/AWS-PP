import React from "react";
import { act, fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

// UI-001 (2026-08-04 audit): IntakeTab's estate.update had no onError, and the
// unmount autosave cleared the localStorage recovery draft + showed the success
// toast SYNCHRONOUSLY before the mutation settled — a failed save showed
// "saved", lost the edits AND destroyed the draft. These tests pin the fix:
// draft clearing and toasts live in the mutation callbacks; onError keeps the
// draft, names the failure, and returns the sticky bar to "Unsaved changes".

vi.setConfig({ testTimeout: 45000 }); // 2026-08-21: jsdom EstateDetail suites breached 15-20s under full-suite worker contention (flake class, memory probatepro-test-flakiness) — headroom, not speed, keeps the gate reproducible
(globalThis as any).React = React;

// 2026-08-04 follow-up: both callbacks now take react-query's `variables` (the
// mutate payload) so a save that settles LATE acts on the estate it saved, not
// on whatever estate the component points at by then. The mocks pass variables
// exactly as react-query does.
type UpdateVars = { id: string; expectedRevision: number; data?: any };

const mocks = vi.hoisted(() => ({
  estateUpdate: vi.fn(),
  // 2026-08-05: the mutation mock is now STATEFUL (isPending/isSuccess/variables
  // transition like react-query's) so the component's isSuccess status effect
  // actually runs under test — the false-"Saved" overwrite escaped the old
  // harness because isSuccess was hardcoded false.
  setUpdateState: null as null | ((s: { isPending: boolean; isSuccess: boolean; variables?: UpdateVars }) => void),
  updateOpts: null as null | {
    onSuccess?: (data: { revision: number }, variables: UpdateVars) => void;
    onError?: (e: { message: string }, variables: UpdateVars) => void;
  },
  toastSuccess: vi.fn(),
  toastError: vi.fn(),
  inventoryTotalsInvalidate: vi.fn(),
  aiImportApply: vi.fn(),
}));

const requestFor = (id: string): UpdateVars => {
  const call = [...mocks.estateUpdate.mock.calls].reverse().find(([variables]) => variables.id === id);
  return (call?.[0] || { id, expectedRevision: 1 }) as UpdateVars;
};
const ok = (id: string) => {
  const variables = requestFor(id);
  mocks.updateOpts!.onSuccess!({ revision: variables.expectedRevision + 1 }, variables);
  mocks.setUpdateState?.({ isPending: false, isSuccess: true, variables });
};
const fail = (id: string, message: string) => {
  const variables = requestFor(id);
  mocks.updateOpts!.onError!({ message }, variables);
  mocks.setUpdateState?.({ isPending: false, isSuccess: false, variables });
};

vi.mock("sonner", () => ({
  toast: Object.assign(vi.fn(), {
    success: mocks.toastSuccess,
    error: mocks.toastError,
    info: vi.fn(),
  }),
}));

vi.mock("@/lib/trpc", () => {
  const idleMutation = () => ({ mutate: vi.fn(), mutateAsync: vi.fn(async () => ({})), isPending: false });
  const invalidator = () => ({ invalidate: vi.fn() });
  return {
    trpc: {
      inventory: {
        list: { useQuery: () => ({ data: [], isLoading: false }) },
        totals: { useQuery: () => ({ data: undefined }) },
        create: { useMutation: idleMutation },
        update: { useMutation: idleMutation },
        delete: { useMutation: idleMutation },
        reorder: { useMutation: idleMutation },
        bulkCreate: { useMutation: idleMutation },
      },
      contact: { list: { useQuery: () => ({ data: [] }) } },
      settings: { get: { useQuery: () => ({ data: { formFocusedIntake: false } }) } },
      notes: { pinned: { useQuery: () => ({ data: [] }) } },
      aiImport: {
        list: {
          useQuery: () => ({
            data: [{ id: "import-1", status: "proposed", fileNames: "will.txt", proposal: "{}", error: null }],
          }),
        },
        applyImport: {
          useMutation: () => ({ mutate: mocks.aiImportApply, isPending: false }),
        },
        dismiss: { useMutation: idleMutation },
      },
      estate: {
        update: {
          useMutation: (opts: any) => {
            mocks.updateOpts = opts;
            const ReactRef = (globalThis as any).React;
            const [state, setState] = ReactRef.useState({ isPending: false, isSuccess: false, variables: undefined });
            mocks.setUpdateState = setState;
            return {
              mutate: (variables: UpdateVars) => {
                mocks.estateUpdate(variables);
                setState({ isPending: true, isSuccess: false, variables });
              },
              ...state,
            };
          },
        },
        uploadWill: { useMutation: idleMutation },
        deleteWill: { useMutation: idleMutation },
        uploadCodicil: { useMutation: idleMutation },
        deleteCodicil: { useMutation: idleMutation },
        reorderCodicils: { useMutation: idleMutation },
        updateCodicilDate: { useMutation: idleMutation },
        uploadForeignGrant: { useMutation: idleMutation },
        deleteForeignGrant: { useMutation: idleMutation },
        uploadLegalEvidence: { useMutation: idleMutation },
        clearLegalEvidence: { useMutation: idleMutation },
      },
      useUtils: () => ({
        inventory: { list: invalidator(), totals: { invalidate: mocks.inventoryTotalsInvalidate } },
        distribution: { compute: invalidator() },
        readiness: { check: invalidator(), timeline: invalidator() },
        deadline: { list: invalidator() },
        delivery: { getRecipients: invalidator() },
        estate: { get: invalidator(), list: invalidator() },
        document: { preflight: invalidator(), preflightMany: invalidator() },
        aiImport: { list: invalidator() },
        contact: { list: invalidator() },
      }),
    },
  };
});

const DRAFT_KEY = "estate_draft_intake_estate-1";

async function renderIntake() {
  const { IntakeTab } = await import("./EstateDetail");
  const { TooltipProvider } = await import("@/components/ui/tooltip");
  return render(
    <TooltipProvider>
      <IntakeTab estateId="estate-1" estate={{ id: "estate-1", revision: 1, hasWill: 1 }} />
    </TooltipProvider>,
  );
}

function seedDraft() {
  window.localStorage.setItem(
    DRAFT_KEY,
    JSON.stringify({ data: { id: "estate-1", hasWill: 1, courtFileNumber: "VAN-X" }, savedAt: Date.now() }),
  );
}

beforeEach(() => {
  mocks.estateUpdate.mockReset();
  mocks.toastSuccess.mockReset();
  mocks.toastError.mockReset();
  mocks.inventoryTotalsInvalidate.mockReset();
  mocks.aiImportApply.mockReset();
  mocks.updateOpts = null;
  window.localStorage.clear();
});

describe("GAP-006: useFirmAsServiceAddress toggle removed", () => {
  it("no longer renders the dead 'Use firm's address as address of service?' toggle for a lawyer applicant", async () => {
    const { IntakeTab } = await import("./EstateDetail");
    const { TooltipProvider } = await import("@/components/ui/tooltip");
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ id: "estate-1", revision: 1, hasWill: 1, applicantType: "lawyer" }} />
      </TooltipProvider>,
    );
    // Nothing ever read the answer, and the lawyer-signing ruling makes the
    // service address ALWAYS the firm when the lawyer acts — honoring "No" is
    // impermissible, so the switch was removed (schema column untouched).
    expect(screen.queryByText(/Use firm's address as address of service/)).toBeNull();
  });
});

describe("IntakeTab save failure handling (UI-001)", () => {
  it("a failed save keeps the recovery draft, shows an error toast, and reports Unsaved changes", async () => {
    seedDraft();
    await renderIntake();
    // Dirty the form so the sticky bar leaves 'idle'.
    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "VAN-S-S-1" } });
    expect(screen.getByText("Unsaved changes")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Save Changes" }));
    expect(requestFor("estate-1").expectedRevision).toBe(1);

    act(() => { fail("estate-1", "network down"); });

    expect(mocks.toastError).toHaveBeenCalledTimes(1);
    expect(String(mocks.toastError.mock.calls[0][0])).toContain("network down");
    // The draft survives a failed save — only onSuccess clears it.
    expect(window.localStorage.getItem(DRAFT_KEY)).not.toBeNull();
    // No false "saved" state anywhere.
    expect(mocks.toastSuccess).not.toHaveBeenCalled();
    expect(screen.getByText("Unsaved changes")).toBeTruthy();
    expect(screen.queryByText(/Saving…/)).toBeNull();
  });

  it("a successful save clears the recovery draft", async () => {
    seedDraft();
    await renderIntake();
    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "VAN-S-S-OK" } });
    fireEvent.click(screen.getByRole("button", { name: "Save Changes" }));
    act(() => { ok("estate-1"); });
    expect(window.localStorage.getItem(DRAFT_KEY)).toBeNull();
    expect(mocks.inventoryTotalsInvalidate).toHaveBeenCalledWith({ estateId: "estate-1" });
    // The mounted path shows the sticky-bar state, not the unmount toast.
    expect(mocks.toastSuccess).not.toHaveBeenCalled();
  });

  it("uses the returned revision for a second save before the delayed refetch", async () => {
    await renderIntake();
    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "FIRST" } });
    fireEvent.click(screen.getByRole("button", { name: "Save Changes" }));
    expect(requestFor("estate-1").expectedRevision).toBe(1);

    act(() => { ok("estate-1"); });
    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "SECOND" } });
    fireEvent.click(screen.getByRole("button", { name: "Save Changes" }));

    expect(mocks.estateUpdate).toHaveBeenCalledTimes(2);
    expect(requestFor("estate-1").expectedRevision).toBe(2);
  });

  it("does not re-save or announce a change when the page closes immediately after a confirmed save", async () => {
    const view = await renderIntake();
    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "CONFIRMED-BEFORE-REFRESH" } });
    fireEvent.click(screen.getByRole("button", { name: "Save Changes" }));

    act(() => { ok("estate-1"); });
    view.unmount();

    expect(mocks.estateUpdate).toHaveBeenCalledTimes(1);
    expect(mocks.toastSuccess).not.toHaveBeenCalledWith("Intake changes saved", expect.anything());
  });

  it("unmount autosave: fires the mutation but defers the toast and draft clear to the outcome", async () => {
    const view = await renderIntake();
    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "VAN-S-S-2" } });
    seedDraft();
    view.unmount();

    // The autosave fired, but nothing claimed success yet and the draft survives.
    expect(mocks.estateUpdate).toHaveBeenCalledTimes(1);
    expect(mocks.toastSuccess).not.toHaveBeenCalled();
    expect(window.localStorage.getItem(DRAFT_KEY)).not.toBeNull();

    // Server confirms: NOW the toast fires and the draft clears.
    act(() => { ok("estate-1"); });
    expect(mocks.toastSuccess).toHaveBeenCalledWith("Intake changes saved", expect.anything());
    expect(window.localStorage.getItem(DRAFT_KEY)).toBeNull();
  });

  it("unmount autosave failure: keeps the draft and shows an error toast", async () => {
    const view = await renderIntake();
    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "VAN-S-S-3" } });
    seedDraft();
    view.unmount();

    expect(mocks.estateUpdate).toHaveBeenCalledTimes(1);
    act(() => { fail("estate-1", "boom"); });
    expect(mocks.toastSuccess).not.toHaveBeenCalled();
    expect(mocks.toastError).toHaveBeenCalledTimes(1);
    expect(String(mocks.toastError.mock.calls[0][0])).toContain("boom");
    expect(window.localStorage.getItem(DRAFT_KEY)).not.toBeNull();
  });

  it("a stale success cannot clear edits made after that save started", async () => {
    await renderIntake();
    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "FIRST-SNAPSHOT" } });
    fireEvent.click(screen.getByRole("button", { name: "Save Changes" }));
    expect(mocks.estateUpdate).toHaveBeenCalledTimes(1);

    // The input remains editable while the request is in flight. This second
    // revision is absent from the request that is about to report success.
    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "NEWER-UNSAVED" } });
    window.localStorage.setItem(DRAFT_KEY, JSON.stringify({
      data: { id: "estate-1", courtFileNumber: "NEWER-UNSAVED" },
      savedAt: Date.now(),
    }));

    act(() => { ok("estate-1"); });

    expect(screen.getByLabelText("Court File Number")).toHaveProperty("value", "NEWER-UNSAVED");
    expect(screen.getByText("Unsaved changes")).toBeTruthy();
    expect(JSON.parse(window.localStorage.getItem(DRAFT_KEY)!).data.courtFileNumber).toBe("NEWER-UNSAVED");
  });

  it("unmount during an in-flight save does not launch an out-of-order full-row write", async () => {
    const view = await renderIntake();
    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "FIRST-SNAPSHOT" } });
    fireEvent.click(screen.getByRole("button", { name: "Save Changes" }));
    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "LATEST-DRAFT" } });

    view.unmount();

    expect(mocks.estateUpdate).toHaveBeenCalledTimes(1);
    expect(mocks.estateUpdate.mock.calls[0][0].data.courtFileNumber).toBe("FIRST-SNAPSHOT");
    expect(JSON.parse(window.localStorage.getItem(DRAFT_KEY)!).data.courtFileNumber).toBe("LATEST-DRAFT");

    act(() => { ok("estate-1"); });
    expect(JSON.parse(window.localStorage.getItem(DRAFT_KEY)!).data.courtFileNumber).toBe("LATEST-DRAFT");
  });
});

describe("AI-import coordination with the mounted Intake draft", () => {
  it("blocks Apply All while the sibling Intake form has unsaved edits", async () => {
    const { IntakeTab, AiImportsSection } = await import("./EstateDetail");
    const { TooltipProvider } = await import("@/components/ui/tooltip");
    function Harness() {
      const [pending, setPending] = React.useState(false);
      return (
        <TooltipProvider>
          <IntakeTab
            estateId="estate-1"
            estate={{ id: "estate-1", revision: 1, hasWill: 1 }}
            onDraftStateChange={(_estateId, next) => setPending(next)}
          />
          <AiImportsSection estateId="estate-1" intakeDraftPending={pending} />
        </TooltipProvider>
      );
    }
    render(<Harness />);

    const apply = screen.getByRole("button", { name: "Apply All" }) as HTMLButtonElement;
    expect(apply.disabled).toBe(false);
    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "VAN-DRAFT" } });

    expect(screen.getByTestId("ai-import-intake-draft-warning").textContent).toMatch(/Save Intake changes/i);
    expect(apply.disabled).toBe(true);
    fireEvent.click(apply);
    expect(mocks.aiImportApply).not.toHaveBeenCalled();
  });

  it("blocks Apply All when an Intake recovery draft exists before mount", async () => {
    seedDraft();
    const { IntakeTab, AiImportsSection } = await import("./EstateDetail");
    const { TooltipProvider } = await import("@/components/ui/tooltip");
    function Harness() {
      const [pending, setPending] = React.useState(false);
      return (
        <TooltipProvider>
          <IntakeTab
            estateId="estate-1"
            estate={{ id: "estate-1", revision: 1, hasWill: 1 }}
            onDraftStateChange={(_estateId, next) => setPending(next)}
          />
          {/* The prop mirrors production: ONLY the state channel IntakeTab
              reports (a raw localStorage disjunct was tried and reverted —
              2026-08-17 review). IntakeTab reports a pre-mount recovery draft
              through onDraftStateChange, which is what this test pins. */}
          <AiImportsSection estateId="estate-1" intakeDraftPending={pending} />
        </TooltipProvider>
      );
    }
    render(<Harness />);

    expect((screen.getByRole("button", { name: "Apply All" }) as HTMLButtonElement).disabled).toBe(true);
    expect(screen.getByTestId("ai-import-intake-draft-warning")).toBeTruthy();
    expect(mocks.aiImportApply).not.toHaveBeenCalled();
  });
});

// The UI-001 fix promised a draft it never wrote, and cleared the wrong estate's
// draft. Both come from the same place: work that outlives the render that started it.
describe("IntakeTab recovery draft is real and estate-correct", () => {
  it("saves the latest Intake edit when the user switches tabs and clears recovery only after confirmation", async () => {
    const view = await renderIntake();
    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "TAB-SWITCH-LATEST" } });

    // AnimatedTabs keys its content by active tab, so a production tab switch
    // unmounts IntakeTab. Pin the same lifecycle rather than relying on a timer.
    view.unmount();

    expect(mocks.estateUpdate).toHaveBeenCalledTimes(1);
    expect(requestFor("estate-1").data?.courtFileNumber).toBe("TAB-SWITCH-LATEST");
    expect(JSON.parse(window.localStorage.getItem(DRAFT_KEY)!).data.courtFileNumber).toBe("TAB-SWITCH-LATEST");

    act(() => { ok("estate-1"); });
    expect(window.localStorage.getItem(DRAFT_KEY)).toBeNull();
  });

  it("shows the exact local autosave time beside Save Changes and retains it after a failed server save", async () => {
    await renderIntake();
    expect(screen.getByTestId("intake-autosave-status").textContent).toContain("Automatic recovery is ready");

    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "TIMESTAMP-DRAFT" } });
    fireEvent(window, new Event("pagehide"));

    const autosaveStatus = screen.getByTestId("intake-autosave-status");
    expect(autosaveStatus.textContent).toMatch(/Last auto-saved locally at/);
    expect(autosaveStatus.querySelector("time")?.getAttribute("dateTime")).toMatch(/^\d{4}-\d{2}-\d{2}T/);
    expect(mocks.estateUpdate).not.toHaveBeenCalled();

    fireEvent.click(screen.getByRole("button", { name: "Save Changes" }));
    act(() => { fail("estate-1", "network down"); });
    expect(screen.getByTestId("intake-autosave-status").textContent).toMatch(/Last auto-saved locally at/);
  });

  it("flushes the latest local draft on page hide and mobile-style visibility suspension without sending a server write", async () => {
    const view = await renderIntake();
    const courtFileNumber = screen.getByLabelText("Court File Number");
    fireEvent.change(courtFileNumber, { target: { value: "PAGE-HIDE-DRAFT" } });

    // pagehide is the reliable closure signal on browsers that do not fire
    // beforeunload (including back-forward cache transitions).
    fireEvent(window, new Event("pagehide"));
    expect(JSON.parse(window.localStorage.getItem(DRAFT_KEY)!).data.courtFileNumber).toBe("PAGE-HIDE-DRAFT");
    expect(mocks.estateUpdate).not.toHaveBeenCalled();

    fireEvent.change(courtFileNumber, { target: { value: "MOBILE-SUSPEND-DRAFT" } });
    Object.defineProperty(document, "visibilityState", { value: "hidden", configurable: true });
    fireEvent(document, new Event("visibilitychange"));

    expect(JSON.parse(window.localStorage.getItem(DRAFT_KEY)!).data.courtFileNumber).toBe("MOBILE-SUSPEND-DRAFT");
    expect(mocks.estateUpdate).not.toHaveBeenCalled();
    Object.defineProperty(document, "visibilityState", { value: "visible", configurable: true });
    view.unmount();
  });

  it("edit-then-unmount inside the debounce window still leaves a draft when the save fails", async () => {
    const view = await renderIntake();
    // No draft seeded and no timers advanced: useLocalDraft's 1s debounce has NOT
    // fired, and unmount cancels it. Only a synchronous flush can save these edits.
    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "VAN-S-S-9" } });
    expect(window.localStorage.getItem(DRAFT_KEY)).toBeNull();

    view.unmount();
    expect(mocks.estateUpdate).toHaveBeenCalledTimes(1);
    const flushed = window.localStorage.getItem(DRAFT_KEY);
    expect(flushed).not.toBeNull();
    expect(JSON.parse(flushed!).data.courtFileNumber).toBe("VAN-S-S-9");

    // The save fails: the toast promises a local draft, and one actually exists.
    act(() => { fail("estate-1", "network down"); });
    expect(String(mocks.toastError.mock.calls[0][0])).toContain("kept as a local draft");
    expect(JSON.parse(window.localStorage.getItem(DRAFT_KEY)!).data.courtFileNumber).toBe("VAN-S-S-9");
  });

  it("estate A's autosave settling while estate B is on screen clears A's draft, not B's", async () => {
    const { IntakeTab } = await import("./EstateDetail");
    const { TooltipProvider } = await import("@/components/ui/tooltip");
    const A = "estate_draft_intake_estate-a";
    const B = "estate_draft_intake_estate-b";
    window.localStorage.setItem(B, JSON.stringify({ data: { id: "estate-b", courtFileNumber: "B-DRAFT" }, savedAt: Date.now() }));

    const view = render(
      <TooltipProvider>
        <IntakeTab estateId="estate-a" estate={{ id: "estate-a", revision: 1, hasWill: 1 }} />
      </TooltipProvider>,
    );
    fireEvent.change(screen.getByLabelText("Court File Number"), { target: { value: "A-EDIT" } });

    // Estate→estate navigation: same IntakeTab instance, new estate props. The
    // [estateId] effect cleanup flushes A's draft and autosaves A.
    view.rerender(
      <TooltipProvider>
        <IntakeTab estateId="estate-b" estate={{ id: "estate-b", revision: 1, hasWill: 1 }} />
      </TooltipProvider>,
    );
    expect(mocks.estateUpdate).toHaveBeenCalledTimes(1);
    expect(mocks.estateUpdate.mock.calls[0][0].id).toBe("estate-a");
    expect(JSON.parse(window.localStorage.getItem(A)!).data.courtFileNumber).toBe("A-EDIT");

    // A's save lands while B is displayed.
    act(() => { ok("estate-a"); });
    expect(window.localStorage.getItem(A)).toBeNull();
    expect(JSON.parse(window.localStorage.getItem(B)!).data.courtFileNumber).toBe("B-DRAFT");
    // No "saved" promise about the estate the user is actually looking at.
    expect(mocks.toastSuccess).not.toHaveBeenCalled();
  });
});
