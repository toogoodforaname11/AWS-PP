import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

// Heavy jsdom file: each test imports EstateDetail (a very large module) inside
// the test body. Same ceiling as the sibling audit specs.
vi.setConfig({ testTimeout: 45000 }); // 2026-08-21: jsdom EstateDetail suites breached 15-20s under full-suite worker contention (flake class, memory probatepro-test-flakiness) — headroom, not speed, keeps the gate reproducible

// tsconfig sets jsx:"preserve", so esbuild under vitest emits the classic
// React.createElement transform; ui/collapsible annotates React.ComponentProps
// without importing React. Same shim as the sibling EstateDetail specs.
(globalThis as any).React = React;

vi.mock("sonner", () => ({
  toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }),
}));

// P19GrantCard calls no trpc hooks — the module-level import just needs to resolve.
vi.mock("@/lib/trpc", () => ({ trpc: {} }));

/**
 * P19 is court-issued, but may be generated as a working draft. Missing grant
 * dates must not block either action; the DOCX seals line shows a highlighted
 * fill until the registry date is recorded.
 */
describe("P19 card — working draft actions", () => {
  it("offers enabled Generate and Preview actions without a grant date", async () => {
    const { P19GrantCard } = await import("./EstateDetail");
    const onGenerateP19 = vi.fn();
    const onPreviewP19 = vi.fn();
    render(
      <P19GrantCard
        estateId="estate-1"
        estate={{ id: "estate-1", grantIssuedDate: "" }}
        updateGrantDate={{ mutate: vi.fn() }}
        onGenerateP19={onGenerateP19}
        onPreviewP19={onPreviewP19}
      />,
    );
    expect((screen.getByTestId("p19-generate") as HTMLButtonElement).disabled).toBe(false);
    expect((screen.getByTestId("p19-preview") as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(screen.getByTestId("p19-generate"));
    fireEvent.click(screen.getByTestId("p19-preview"));
    expect(onGenerateP19).toHaveBeenCalledOnce();
    expect(onPreviewP19).toHaveBeenCalledOnce();
    expect(screen.getByText(/blank seal-date space is highlighted/i)).toBeTruthy();
  });

  it("keeps the grant-issued-date recorder live: Mark Grant Issued writes grantIssuedDate", async () => {
    const { P19GrantCard } = await import("./EstateDetail");
    const mutate = vi.fn();
    render(
      <P19GrantCard
        estateId="estate-1"
        estate={{ id: "estate-1", grantIssuedDate: "" }}
        updateGrantDate={{ mutate }}
        onGenerateP19={vi.fn()}
        onPreviewP19={vi.fn()}
      />,
    );
    fireEvent.click(screen.getByRole("button", { name: "Mark Grant Issued" }));
    expect(mutate).toHaveBeenCalledWith({
      id: "estate-1",
      data: { grantIssuedDate: expect.stringMatching(/^\d{4}-\d{2}-\d{2}$/) },
      // B22: success/error toasts are per-call, so the toast only fires on real server outcomes
    }, expect.objectContaining({ onSuccess: expect.any(Function), onError: expect.any(Function) }));
  });

  it("clear button appears only once a date is recorded and clears it", async () => {
    const { P19GrantCard } = await import("./EstateDetail");
    const mutate = vi.fn();
    render(
      <P19GrantCard
        estateId="estate-1"
        estate={{ id: "estate-1", grantIssuedDate: "2026-07-01" }}
        updateGrantDate={{ mutate }}
        onGenerateP19={vi.fn()}
        onPreviewP19={vi.fn()}
      />,
    );
    // Recorded date flips the recorder to its issued state and disables re-marking.
    expect((screen.getByRole("button", { name: "Grant Issued" }) as HTMLButtonElement).disabled).toBe(true);
    fireEvent.click(screen.getByTitle("Clear grant issued date"));
    expect(mutate).toHaveBeenCalledWith(
      { id: "estate-1", data: { grantIssuedDate: "" } },
      expect.objectContaining({ onSuccess: expect.any(Function), onError: expect.any(Function) }),
    );
  });
});
