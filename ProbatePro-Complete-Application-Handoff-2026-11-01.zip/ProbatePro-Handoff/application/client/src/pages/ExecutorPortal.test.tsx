import { fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import React from "react";
import { menuItems } from "@/components/DashboardLayout";

const mocks = vi.hoisted(() => ({ loading: false, estates: [] as any[], accesses: [] as any[] }));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    useUtils: () => ({ portalAccess: { listAll: { invalidate: vi.fn() } } }),
    estate: { list: { useQuery: () => ({ data: mocks.estates }) } },
    portalAccess: {
      listAll: { useQuery: () => ({ data: mocks.accesses, isLoading: mocks.loading }) },
      create: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
      revoke: { useMutation: () => ({ mutate: vi.fn() }) },
      extend: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
      reissue: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
    },
  },
}));

import ExecutorPortal from "./ExecutorPortal";

afterEach(() => { mocks.loading = false; mocks.estates = []; mocks.accesses = []; });

describe("ExecutorPortal", () => {
  it("keeps executor access management out of search results", () => {
    render(<ExecutorPortal />);

    expect(document.title).toBe("Executor Portal | ProbatePro");
    expect(document.head.querySelector('meta[name="robots"]')?.getAttribute("content")).toBe("noindex, nofollow");
    expect(document.head.querySelector('link[rel="canonical"]')?.getAttribute("href")).toBe("https://probate-pro.com/executor-portal");
  });

  it("places Executor Portal immediately above the How It Works FAQs destination", () => {
    expect(menuItems.map((item) => item.label)).toEqual(["Estate Files", "Deadlines", "Executor Portal", "How It Works", "Report a Problem", "Settings"]);
  });

  it("renders the existing portal access controls outside general Settings", () => {
    render(<ExecutorPortal />);
    expect(screen.getByTestId("executor-portal-route")).toBeTruthy();
    expect(screen.getByRole("heading", { name: "Executor Portal" })).toBeTruthy();
    expect(screen.getByText("Executor / Client Portal Access")).toBeTruthy();
    expect(screen.getByRole("button", { name: /grant access/i })).toBeTruthy();
  });

  it("frames portal access as a client-intake and lawyer-review workflow", () => {
    render(<ExecutorPortal />);

    expect(screen.getByText(/issue client-intake links and review submissions before applying selected facts/i)).toBeTruthy();
    expect(screen.getByText(/secure client-intake link for an executor or client/i)).toBeTruthy();
    expect(screen.queryByText(/generate read-only portal links/i)).toBeNull();
  });

  it("shows an accessible control-shaped skeleton while portal access data loads", () => {
    mocks.loading = true;
    render(<ExecutorPortal />);
    expect(screen.getByTestId("executor-portal-loading-skeleton").getAttribute("aria-busy")).toBe("true");
    expect(screen.getByRole("status").textContent).toMatch(/Loading executor portal access/i);
    expect(screen.queryByRole("button", { name: /grant access/i })).toBeNull();
  });

  it("filters portal access by executor, email, and estate, with clear no-result feedback", () => {
    mocks.estates = [
      { id: "estate-alex", fileNumber: "101", estateName: "Morgan Estate", deceasedFirstName: "", deceasedMiddleNames: "", deceasedSecondMiddleName: "", deceasedLastName: "" },
      { id: "estate-blake", fileNumber: "202", estateName: "Chen Estate", deceasedFirstName: "", deceasedMiddleNames: "", deceasedSecondMiddleName: "", deceasedLastName: "" },
    ];
    mocks.accesses = [
      { id: "access-alex", estateId: "estate-alex", contactName: "Alex Executor", email: "alex@example.com", expiresAt: Date.now() + 86400000 * 45, active: 1, consumedAt: null, createdAt: Date.now() },
      { id: "access-blake", estateId: "estate-blake", contactName: "Blake Client", email: "blake@example.com", expiresAt: Date.now() + 86400000 * 45, active: 0, consumedAt: null, createdAt: Date.now() },
    ];
    render(<ExecutorPortal />);
    const search = screen.getByRole("textbox", { name: /search executor portal access/i });
    fireEvent.change(search, { target: { value: "Morgan" } });
    expect(screen.getByText("Alex Executor")).toBeTruthy();
    expect(screen.queryByText("Blake Client")).toBeNull();
    fireEvent.change(search, { target: { value: "no result" } });
    expect(screen.getByText(/No portal access links match/i)).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: /clear executor portal search/i }));
    expect(screen.getByText("Blake Client")).toBeTruthy();
  });

  it("filters portal access by status and composes it with search", () => {
    mocks.accesses = [
      { id: "access-active", estateId: "estate-active", contactName: "Active Executor", email: "active@example.com", expiresAt: Date.now() + 86400000 * 45, active: 1, consumedAt: null, createdAt: Date.now() },
      { id: "access-revoked", estateId: "estate-revoked", contactName: "Revoked Executor", email: "revoked@example.com", expiresAt: Date.now() + 86400000 * 45, active: 0, consumedAt: null, createdAt: Date.now() },
    ];
    render(<ExecutorPortal />);
    fireEvent.click(screen.getByRole("combobox", { name: /filter executor portal access by status/i }));
    fireEvent.click(screen.getByRole("option", { name: "Revoked" }));
    expect(screen.getByText("Revoked Executor")).toBeTruthy();
    expect(screen.queryByText("Active Executor")).toBeNull();
    fireEvent.change(screen.getByRole("textbox", { name: /search executor portal access/i }), { target: { value: "active" } });
    expect(screen.getByText(/No portal access links match the current search/i)).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: /clear filters/i }));
    expect(screen.getByText("Active Executor")).toBeTruthy();
    expect(screen.getByText("Revoked Executor")).toBeTruthy();
  });
});
