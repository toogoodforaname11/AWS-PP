import React from "react";
import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

const portalQueries = vi.hoisted(() => ({
  estate: vi.fn(() => ({
    data: {
      id: "estate-1",
      fileNumber: "101",
      status: "active",
      deceasedFirstName: "Avery",
      deceasedMiddleNames: "",
      deceasedSecondMiddleName: "",
      deceasedLastName: "Morgan",
      dateOfDeath: "2026-01-02",
      registry: "Victoria",
      p1DeliveredDate: "",
      grantIssuedDate: "",
    },
    isLoading: false,
  })),
  inventory: vi.fn(() => ({ data: [] })),
  activity: vi.fn(() => ({ data: [] })),
}));

vi.mock("@/components/ClientIntakeForm", () => ({
  ClientIntakeForm: ({ draftScope }: { draftScope?: string }) => (
    <div data-testid="client-intake-form" data-draft-scope={draftScope} />
  ),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    portal: {
      login: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
      me: {
        useQuery: () => ({
          data: {
            estateId: "estate-1",
            contactName: "Jordan Client",
            email: "jordan@example.test",
          },
          isLoading: false,
          isError: false,
        }),
      },
      estate: {
        useQuery: portalQueries.estate,
      },
      inventory: { useQuery: portalQueries.inventory },
      activity: { useQuery: portalQueries.activity },
      clientIntakeSubmissions: { useQuery: () => ({ data: [] }) },
      logout: { useMutation: () => ({ mutate: vi.fn() }) },
    },
  },
}));

import Portal from "./Portal";

describe("Portal", () => {
  it("renders only the client intake while retaining private estate context", () => {
    render(<Portal />);

    expect(screen.getByTestId("client-intake-form")).toBeTruthy();
    expect(screen.queryByText("Contacts")).toBeNull();
    expect(screen.queryByText("Estate Summary")).toBeNull();
    expect(screen.queryByText("Inventory (Masked Values)")).toBeNull();
    expect(screen.queryByText("Recent Activity")).toBeNull();
    expect(portalQueries.estate).toHaveBeenCalledTimes(1);
    expect(portalQueries.inventory).not.toHaveBeenCalled();
    expect(portalQueries.activity).not.toHaveBeenCalled();
  });

  it("passes an opaque client intake draft scope without showing estate details", () => {
    render(<Portal />);

    const draftScope = screen
      .getByTestId("client-intake-form")
      .getAttribute("data-draft-scope");
    expect(draftScope).toMatch(/^portal-[a-z0-9]+$/);
    expect(draftScope).not.toContain("estate-1");
    expect(draftScope).not.toContain("jordan@example.test");
    expect(screen.queryByText("Estate Summary")).toBeNull();
  });
});
