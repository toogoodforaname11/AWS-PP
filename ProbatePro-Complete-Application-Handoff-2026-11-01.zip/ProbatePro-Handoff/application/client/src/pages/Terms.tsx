import React from "react";
import { Scale } from "lucide-react";
import { Link } from "wouter";
import { Seo } from "@/components/Seo";

export default function Terms() {
  return (
    <div className="min-h-screen bg-[#fafafa] text-[#1a1a2e]">
      <Seo
        title="Terms of Service | ProbatePro"
        description="Terms of Service for the ProbatePro British Columbia probate workflow application."
        path="/terms"
        index
      />
      {/* Navigation */}
      <nav className="fixed top-0 inset-x-0 z-50 backdrop-blur-md bg-[#fafafa]/80 border-b border-black/[0.04]">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Scale className="h-5 w-5 text-[#2d3561]" />
            <span className="font-semibold text-[15px] tracking-tight text-[#1a1a2e]">
              ProbatePro
            </span>
          </div>
          <Link href="/" className="text-sm text-[#4a4a5a] transition-colors hover:text-[#2d3561]">Back</Link>
        </div>
      </nav>

      {/* Content */}
      <main className="pt-28 pb-16 px-6">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold tracking-tight mb-2">Terms of Service</h1>
          <p className="text-sm text-[#4a4a5a]/60 mb-10">Last updated: August 5, 2026</p>

          <div className="prose prose-sm max-w-none text-[#2a2a3a] space-y-6 [&_h2]:text-lg [&_h2]:font-semibold [&_h2]:mt-8 [&_h2]:mb-3 [&_p]:leading-relaxed [&_ul]:space-y-1 [&_li]:leading-relaxed">
            <h2>1. Agreement to Terms</h2>
            <p>
              These Terms of Service ("Terms") constitute a legally binding agreement between you ("User," "you," or "your") and Kairo ("Company," "we," "us," or "our"), governing your access to and use of the ProbatePro application available at probate-pro.com (the "Service"). By accessing or using the Service, you acknowledge that you have read, understood, and agree to be bound by these Terms. If you do not agree to these Terms, you must not access or use the Service.
            </p>

            <h2>2. Description of Service</h2>
            <p>
              ProbatePro is a software-as-a-service ("SaaS") tool designed to assist legal professionals and personal representatives in managing British Columbia Supreme Court probate applications. The Service provides document generation, estate file management, deadline tracking, and form preparation features based on Part 25 and Appendix A.1 of the British Columbia Supreme Court Civil Rules and related British Columbia legislation, including the Wills, Estates and Succession Act and the Probate Fee Act.
            </p>
            <p>
              The Service is a document preparation and management tool only. It does not provide legal advice, legal representation, or legal services of any kind. The generated documents are templates populated with user-provided data and must be reviewed by a qualified legal professional before filing with any court.
            </p>

            <h2>3. Eligibility</h2>
            <p>
              You must be at least 19 years of age (the age of majority in British Columbia) to use this Service. By using the Service, you represent and warrant that you meet this age requirement and have the legal capacity to enter into these Terms.
            </p>

            <h2>4. Account Registration and Security</h2>
            <p>
              Access to the Service requires authentication through our designated sign-in process. You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account. You agree to notify us immediately of any unauthorized use of your account or any other breach of security. We reserve the right to suspend or terminate your account if we reasonably believe unauthorized access has occurred.
            </p>

            <h2>5. Acceptable Use</h2>
            <p>You agree not to use the Service to:</p>
            <ul className="list-disc pl-6">
              <li>Upload, store, or transmit any content that is unlawful, fraudulent, or infringes upon the rights of others</li>
              <li>Misrepresent your identity or authority to act on behalf of an estate</li>
              <li>Attempt to gain unauthorized access to any part of the Service, other accounts, or computer systems</li>
              <li>Use the Service for any purpose other than legitimate estate administration and probate application preparation</li>
              <li>Reverse-engineer, decompile, or disassemble any portion of the Service</li>
              <li>Use automated systems (bots, scrapers) to access the Service without our express written consent</li>
              <li>Upload malicious code, viruses, or any software intended to damage or alter the Service</li>
            </ul>

            <h2>6. User Content and Data</h2>
            <p>
              You retain all ownership rights to the data, documents, and information you upload to or create through the Service ("User Content"). By using the Service, you grant us a limited, non-exclusive license to store, process, and display your User Content solely for the purpose of providing and improving the Service.
            </p>
            <p>
              You represent and warrant that you have all necessary rights, consents, and authority to upload and process the personal information contained in your User Content, including information about deceased persons, beneficiaries, executors, and other parties involved in estate administration.
            </p>

            <h2>7. Document Generation Disclaimer</h2>
            <p>
              The documents generated by the Service are produced based on templates aligned with Part 25 and Appendix A.1 of the British Columbia Supreme Court Civil Rules as of the date of generation. While we strive to maintain accuracy, we do not guarantee that generated documents will be accepted by any court, comply with all applicable rules at the time of filing, or be suitable for your specific circumstances.
            </p>
            <p>
              <strong>You acknowledge and agree that:</strong>
            </p>
            <ul className="list-disc pl-6">
              <li>All generated documents must be reviewed by a qualified legal professional before filing</li>
              <li>Court rules and forms may change without notice, and the Service may not immediately reflect such changes</li>
              <li>The Service does not replace professional legal counsel</li>
              <li>You are solely responsible for the accuracy of information entered into the Service and the legal sufficiency of any documents filed with the court</li>
            </ul>

            <h2>8. Fees and Payment</h2>
            <p>
              Access to the Service may be subject to subscription fees as described on our pricing page. We reserve the right to modify our pricing at any time with 30 days' advance notice. Continued use of the Service after a price change constitutes acceptance of the new pricing. All fees are non-refundable except as required by applicable law.
            </p>

            <h2>9. Intellectual Property</h2>
            <p>
              The Service, including its design, code, features, documentation, and all associated intellectual property, is owned by Kairo and protected by Canadian and international copyright, trademark, and other intellectual property laws. These Terms do not grant you any right, title, or interest in the Service beyond the limited right to use it in accordance with these Terms.
            </p>

            <h2>10. Limitation of Liability</h2>
            <p>
              To the maximum extent permitted by applicable law, Kairo shall not be liable for any indirect, incidental, special, consequential, or punitive damages, including but not limited to loss of profits, data, business opportunities, or goodwill, arising out of or in connection with your use of the Service.
            </p>
            <p>
              In no event shall our total aggregate liability exceed the amount you paid to us for the Service during the twelve (12) months immediately preceding the event giving rise to the claim. This limitation applies regardless of the theory of liability (contract, tort, strict liability, or otherwise).
            </p>

            <h2>11. Indemnification</h2>
            <p>
              You agree to indemnify, defend, and hold harmless Kairo, its officers, directors, employees, and agents from and against any claims, liabilities, damages, losses, and expenses (including reasonable legal fees) arising out of or in connection with your use of the Service, your User Content, your violation of these Terms, or your violation of any rights of a third party.
            </p>

            <h2>12. Service Availability and Modifications</h2>
            <p>
              We strive to maintain continuous availability of the Service but do not guarantee uninterrupted access. The Service may be temporarily unavailable due to maintenance, updates, or circumstances beyond our control. We reserve the right to modify, suspend, or discontinue any part of the Service at any time with reasonable notice where practicable.
            </p>

            <h2>13. Termination</h2>
            <p>
              Either party may terminate this agreement at any time. You may terminate by ceasing to use the Service and requesting account closure. We may terminate or suspend your access immediately, without prior notice, if you breach these Terms or if we are required to do so by law. Upon termination, your right to use the Service ceases immediately. Account closure does not itself authorize destruction of estate or law-practice records. Export and disposition requests are handled under the Privacy Policy, the responsible firm's approved legal and business retention requirements, and any applicable legal hold or production obligation.
            </p>

            <h2>14. Governing Law and Dispute Resolution</h2>
            <p>
              These Terms are governed by and construed in accordance with the laws of the Province of British Columbia and the federal laws of Canada applicable therein, without regard to conflict of law principles. Any disputes arising out of or relating to these Terms shall be resolved exclusively in the courts of British Columbia, and you consent to the personal jurisdiction of such courts.
            </p>

            <h2>15. Changes to Terms</h2>
            <p>
              We may update these Terms from time to time. When we make material changes, we will notify you by updating the "Last updated" date and, where appropriate, providing additional notice (such as an in-app notification or email). Your continued use of the Service after the effective date of any changes constitutes acceptance of the revised Terms.
            </p>

            <h2>16. Severability</h2>
            <p>
              If any provision of these Terms is found to be unenforceable or invalid by a court of competent jurisdiction, that provision shall be limited or eliminated to the minimum extent necessary, and the remaining provisions shall remain in full force and effect.
            </p>

            <h2>17. Entire Agreement</h2>
            <p>
              These Terms, together with our Privacy Policy, constitute the entire agreement between you and Kairo regarding the Service and supersede all prior agreements, understandings, and communications, whether written or oral.
            </p>

            <h2>18. Contact</h2>
            <p>
              If you have questions about these Terms of Service, please contact us at:
            </p>
            <p>
              <strong>Kairo</strong><br />
              Email: nick@kairo.chat<br />
              Website: probate-pro.com
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-black/[0.04]">
        <div className="max-w-6xl mx-auto flex items-center justify-between text-sm text-[#4a4a5a]/60">
          <div className="flex items-center gap-2">
            <Scale className="h-4 w-4" />
            <span>&copy; {new Date().getFullYear()} Kairo</span>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/terms" className="hover:text-[#2d3561] transition-colors">Terms</Link>
            <Link href="/privacy" className="hover:text-[#2d3561] transition-colors">Privacy</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
