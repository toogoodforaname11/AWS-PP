import { act, render, screen } from "@testing-library/react";
import React from "react";
import { afterEach, describe, expect, it } from "vitest";
import Goodbye from "./Goodbye";

afterEach(() => window.history.replaceState({}, "", "/"));

describe("Goodbye page", () => {
  it("confirms a completed signed-out deletion without exposing account data", () => {
    act(() => window.history.replaceState({}, "", "/goodbye?account=deleted"));
    render(<Goodbye />);
    expect(screen.getByTestId("goodbye-ambient-start").getAttribute("aria-hidden")).toBe("true");
    expect(screen.getByTestId("goodbye-completion-card")).toBeTruthy();
    expect(screen.getByRole("heading", { name: "Your account has been closed." })).toBeTruthy();
    expect(screen.getByRole("link", { name: /Return to the start page/i }).getAttribute("href")).toBe("/");
    expect(screen.queryByText(/delete@example\.com/i)).toBeNull();
  });

  it("is safe to visit directly without claiming an account was deleted", () => {
    render(<Goodbye />);
    expect(screen.getByRole("heading", { name: "Goodbye from ProbatePro." })).toBeTruthy();
  });
});
