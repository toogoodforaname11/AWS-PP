/** P11 draft download: real optional-form dialogs preserve the recorded BC facts. */
import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.setConfig({ testTimeout: 45000 });
(globalThis as any).React = React;

vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }) }));
import { toast } from "sonner";

const mocks = vi.hoisted(() => ({
  generateCalls: [] as any[],
  preflightCalls: [] as any[],
  estateUpdateCalls: [] as any[],
  generationFailure: "" as string,
  /** document.generate's POST delivery (Nick, 2026-10-20), never a GET URL. */
  delivery: {
    method: "POST",
    action: "/api/download/form",
    fields: { estateId: "estate-18", formCode: "P11", documentId: "doc_p11_1", signatoryType: "lawyer", signatureDate: "2026-07-12", generateAnyway: "true" },
  },
}));

vi.mock("@/lib/trpc", () => {
  const mutation = (path: string, options?: any) => {
    const mutateAsync = async (input: any) => {
      if (path === "estate.update") mocks.estateUpdateCalls.push(input);
      try {
        if (path === "document.generate") {
          mocks.generateCalls.push(input);
          if (input.formCode === "P11" && !input.generateAnyway) throw new Error("Confirm optional P11 generation first.");
          if (mocks.generationFailure === input.formCode) throw new Error("A controlled generation failure occurred.");
        }
        const result = path === "document.generate"
          ? { id: "doc_p11_1", delivery: mocks.delivery, filename: "P11_Alex_North.docx", format: "docx" }
          : {};
        await options?.onSuccess?.(result, input, undefined);
        return result;
      } catch (error) {
        await options?.onError?.(error, input, undefined);
        throw error;
      }
    };
    return { mutateAsync, mutate: (input: any) => { void mutateAsync(input).catch(() => undefined); }, isPending: false };
  };
  function utils(path: string[]): any {
    return new Proxy({}, {
      get(_target, property: string) {
        if (["invalidate", "setData", "cancel"].includes(property)) return () => undefined;
        if (property === "fetch") return async (input: any) => {
          if (path.join(".") === "document.preflight") {
            mocks.preflightCalls.push(input);
            if (input.formCode === "P10") {
              return { formCode: "P10", ok: true, hardBlocked: false, notApplicable: false, gaps: [] };
            }
            return {
              formCode: "P11", ok: false, hardBlocked: !input.generateAnyway, notApplicable: true,
              gaps: [{
                requirementId: "p11_applicability",
                label: "P11 is not required — use P10. You can still generate P11 for review.",
                missingFields: [], tab: "forms", source: "SCCR Rule 25-3 (8)",
                ...(input.generateAnyway ? {} : { blocker: "hard" }),
              }],
            };
          }
          if (path.join(".") === "document.preflightMany") return [];
          return undefined;
        };
        return utils([...path, property]);
      },
    });
  }
  function node(path: string[]): any {
    return new Proxy({}, {
      get(_target, property: string) {
        if (property === "useQuery") return () => {
          const key = path.join(".");
          const lists = ["document.list", "document.versions", "document.retainedFiles", "document.getLetterRecipients", "citation.list", "delivery.list", "delivery.getRecipients"];
          return { data: key === "contact.list" ? [applicant] : lists.includes(key) ? [] : undefined, isLoading: false, error: null };
        };
        if (property === "useMutation") return (options: any) => mutation(path.join("."), options);
        if (property === "useUtils") return () => utils([]);
        return node([...path, property]);
      },
    });
  }
  return { trpc: node([]) };
});

const applicant = { id: "applicant-1", role: "applicant,executor", executorStatus: "applying", executorRank: "primary", name: "Alex Applicant", relationship: "child" };
const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
/** Each same-tab form POST the page submits; the browser's attachment download follows it. */
const downloads: Array<{ method: string; action: string | null; fields: Record<string, string> }> = [];
const posted = (fields: Record<string, string>) => ({ method: "post", action: "/api/download/form", fields: { ...fields, attemptId: expect.stringMatching(UUID_V4) } });
beforeEach(() => {
  vi.clearAllMocks();
  mocks.generateCalls.length = 0;
  mocks.preflightCalls.length = 0;
  mocks.estateUpdateCalls.length = 0;
  mocks.generationFailure = "";
  downloads.length = 0;
  vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) {
    downloads.push({ method: this.method, action: this.getAttribute("action"), fields: Object.fromEntries(new FormData(this)) as Record<string, string> });
  });
});
afterEach(() => vi.restoreAllMocks());

describe("P11 optional draft for a deceased domiciled in BC", () => {
  it.each(["yes", "no"])("warns and downloads with domicile Yes and ordinary residence %s, without changing Intake", async (residence) => {
    const estate = {
      id: "estate-18", grantType: "grant_of_probate", willStatus: "will", hasWill: 1,
      deceasedFirstName: "Alex", deceasedLastName: "North", applicantType: "executor",
      deceasedDomiciledInBC: "yes", deceasedOrdinarilyResidentInBC: residence,
      foreignAdministrationConfirmed: "none_outside", p11DiligentSearchConfirmed: "yes",
      juratCity: "Vancouver", p1NotRequired: 1,
    };
    const { FormsTab } = await import("./EstateDetail");
    render(<FormsTab estateId="estate-18" estate={estate} onNavigateToTab={vi.fn()} />);
    expect(screen.getByTestId("form-badge-P10").textContent).toBe("Required");
    expect(screen.getByTestId("form-badge-P11").textContent).toBe("Optional");

    fireEvent.click(screen.getByTestId("form-generate-P11"));
    expect(screen.getByTestId("fix-still-na").textContent).toContain("P11 is not required — use P10");
    expect(screen.getByTestId("fix-question-deceasedDomiciledInBC").textContent).toBe("Yes");
    expect(screen.getByTestId("fix-question-deceasedOrdinarilyResidentInBC").textContent).toBe(residence === "yes" ? "Yes" : "No");
    expect((screen.getByTestId("fix-confirm") as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(screen.getByTestId("fix-confirm"));

    await waitFor(() => expect(screen.getByTestId("form-details-dialog")).toBeTruthy());
    expect(screen.getByTestId("form-details-date")).toBeTruthy();
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());
    expect(screen.getByTestId("pre-generate-dialog").textContent).toContain("is not applicable — producing anyway");
    expect(screen.queryByTestId("pre-generate-editor-deceasedDomiciledInBC")).toBeNull();
    expect(screen.queryByTestId("pre-generate-editor-deceasedOrdinarilyResidentInBC")).toBeNull();
    const proceed = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
    expect(proceed.disabled).toBe(false);
    expect(proceed.textContent).toBe("Generate");
    expect(mocks.generateCalls).toHaveLength(0);
    fireEvent.click(proceed);

    await waitFor(() => expect(downloads).toEqual([posted(mocks.delivery.fields)]));
    expect(mocks.preflightCalls).toHaveLength(1);
    expect(mocks.preflightCalls[0]).toMatchObject({ formCode: "P11", generateAnyway: true });
    expect(mocks.generateCalls).toHaveLength(1);
    expect(mocks.generateCalls[0]).toMatchObject({ formCode: "P11", generateAnyway: true });
    expect(mocks.generateCalls[0].overrides).toBeUndefined();
    expect(mocks.estateUpdateCalls).toEqual([]);
    expect(estate).toMatchObject({ deceasedDomiciledInBC: "yes", deceasedOrdinarilyResidentInBC: residence });
    expect(toast.info).toHaveBeenCalledWith("Form generated — download requested. Check your browser's downloads.");
    expect(toast.error).not.toHaveBeenCalled();
  });

  it("keeps a controlled P10 generation failure visibly actionable and retryable", async () => {
    mocks.generationFailure = "P10";
    const estate = {
      id: "estate-18", grantType: "grant_of_probate", willStatus: "will", hasWill: 1,
      deceasedFirstName: "Alex", deceasedLastName: "North", applicantType: "executor",
      deceasedDomiciledInBC: "yes", deceasedOrdinarilyResidentInBC: "no",
      foreignAdministrationConfirmed: "none_outside", p11DiligentSearchConfirmed: "yes",
      juratCity: "Vancouver", p1NotRequired: 1,
    };
    const { FormsTab } = await import("./EstateDetail");
    render(<FormsTab estateId="estate-18" estate={estate} onNavigateToTab={vi.fn()} />);

    expect(screen.getByTestId("form-badge-P10").textContent).toBe("Required");
    fireEvent.click(screen.getByTestId("form-generate-P10"));
    await waitFor(() => expect(screen.getByTestId("form-details-generate")).toBeTruthy());
    fireEvent.click(screen.getByTestId("form-details-generate"));

    await waitFor(() => expect(screen.getByTestId("document-generation-recovery").textContent).toMatch(/P10 was not generated/i));
    expect(screen.getByTestId("document-generation-review-retry")).toBeTruthy();
    expect(screen.getByTestId("form-details-generate")).toBeTruthy();
    expect(downloads).toEqual([]);
    expect(mocks.generateCalls).toEqual([expect.objectContaining({ formCode: "P10" })]);
    expect(toast.error).toHaveBeenCalledWith("A controlled generation failure occurred.", { duration: Infinity });
  });
});
