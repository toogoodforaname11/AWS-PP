import React from "react";
import { Link } from "wouter";
import { CheckCircle2, Scale } from "lucide-react";
import { motion, useReducedMotion } from "framer-motion";
import { Button } from "@/components/ui/button";

export default function Goodbye() {
  const wasDeleted = typeof window !== "undefined" && new URLSearchParams(window.location.search).get("account") === "deleted";
  const prefersReducedMotion = useReducedMotion();
  const entrance = (delay = 0) => ({
    initial: { opacity: 0, y: prefersReducedMotion ? 0 : 8 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: prefersReducedMotion ? 0 : 0.28, delay: prefersReducedMotion ? 0 : delay, ease: [0.22, 1, 0.36, 1] as const },
  });
  const ambientDrift = prefersReducedMotion
    ? { x: 0, y: 0, scale: 1 }
    : { x: [0, 20, -14, 0], y: [0, -12, 16, 0], scale: [1, 1.06, 0.98, 1] };

  return (
    <main className="relative grid min-h-screen place-items-center overflow-hidden bg-[#f7f8fc] px-5 py-10 text-slate-950 dark:bg-[#11131a] dark:text-slate-50">
      <motion.div data-testid="goodbye-ambient-start" aria-hidden="true" animate={ambientDrift} transition={{ duration: prefersReducedMotion ? 0 : 18, repeat: prefersReducedMotion ? 0 : Infinity, ease: "easeInOut" }} className="pointer-events-none absolute -left-24 top-[-8rem] h-72 w-72 rounded-full bg-blue-200/35 blur-3xl dark:bg-blue-700/15" />
      <motion.div aria-hidden="true" animate={prefersReducedMotion ? { x: 0, y: 0, scale: 1 } : { x: [0, -18, 12, 0], y: [0, 14, -16, 0], scale: [1, 0.98, 1.05, 1] }} transition={{ duration: prefersReducedMotion ? 0 : 21, repeat: prefersReducedMotion ? 0 : Infinity, ease: "easeInOut" }} className="pointer-events-none absolute -bottom-32 -right-20 h-80 w-80 rounded-full bg-rose-200/30 blur-3xl dark:bg-rose-800/15" />
      <motion.section data-testid="goodbye-completion-card" initial={{ opacity: 0, y: prefersReducedMotion ? 0 : 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: prefersReducedMotion ? 0 : 0.34, ease: [0.22, 1, 0.36, 1] }} className="relative w-full max-w-xl overflow-hidden rounded-[1.6rem] border border-slate-200/90 bg-white/90 p-7 shadow-[0_30px_90px_-42px_rgba(15,23,42,0.45),inset_0_1px_0_rgba(255,255,255,0.95)] backdrop-blur sm:p-10 dark:border-white/10 dark:bg-slate-950/80">
        <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-blue-800 via-slate-700 to-rose-600" />
        <motion.div {...entrance(0.04)} className="mb-8 flex items-center gap-3 text-slate-700 dark:text-slate-200"><span className="grid size-10 place-items-center rounded-xl border border-slate-200 bg-slate-50 shadow-[inset_0_1px_0_white] dark:border-white/10 dark:bg-white/5"><Scale className="size-5" /></span><span className="font-semibold tracking-tight">ProbatePro</span></motion.div>
        <motion.div {...entrance(0.1)} className="mb-5 grid size-12 place-items-center rounded-2xl border border-emerald-500/25 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"><CheckCircle2 className="size-6" /></motion.div>
        <motion.div {...entrance(0.15)}><p className="mb-2 text-sm font-semibold uppercase tracking-[0.16em] text-slate-500">Account closure</p><h1 className="max-w-md text-3xl font-semibold tracking-[-0.045em] sm:text-4xl">{wasDeleted ? "Your account has been closed." : "Goodbye from ProbatePro."}</h1></motion.div>
        <motion.p {...entrance(0.2)} className="mt-5 max-w-lg text-[0.98rem] leading-7 text-slate-600 dark:text-slate-300">{wasDeleted ? "Your active session has ended. We have removed the private account data eligible for deletion; any estate files remain protected by their established retention workflow." : "If you recently closed an account, this page confirms that your active session is no longer available."}</motion.p>
        <motion.div {...entrance(0.25)} className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
          <Button asChild className="bg-slate-900 text-white shadow-[0_3px_0_rgba(15,23,42,0.45)] hover:bg-slate-800 dark:bg-white dark:text-slate-950 dark:hover:bg-slate-100"><Link href="/">Return to the start page</Link></Button>
          <Link href="/privacy" className="text-sm font-medium text-slate-600 underline-offset-4 hover:underline dark:text-slate-300">Privacy information</Link>
        </motion.div>
      </motion.section>
    </main>
  );
}
