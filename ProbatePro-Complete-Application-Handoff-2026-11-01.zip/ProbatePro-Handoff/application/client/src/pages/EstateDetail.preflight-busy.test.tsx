/**
 * Addendum 24.8 ("never silent-succeed with no download"): once a form dialog
 * closes, the span until the server's preflight/generate answer must show
 * visible progress — a blank screen for several seconds reads as a silent
 * failure and invites a second click.
 */
import React from "react";
import { fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.setConfig({ testTimeout: 45000 });
(globalThis as any).React = React;
vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }) }));
import { toast } from "sonner";

const state = vi.hoisted(() => ({
  estate: {} as any,
  contacts: [] as any[],
  documents: [] as any[],
  generateCalls: [] as any[],
  // The preflight answer waits on this gate so the test can observe the
  // in-flight span, then release or reject it.
  gate: Promise.resolve() as Promise<void>,
  release: (() => undefined) as () => void,
  reject: ((_error: Error) => undefined) as (error: Error) => void,
  /** document.generate's POST delivery (Nick, 2026-10-20), never a GET URL. */
  delivery: {
    method: "POST",
    action: "/api/download/form",
    fields: { estateId: "estate-19", formCode: "P8", documentId: "doc_p8_1", signatoryType: "lawyer", signatureDate: "2026-09-06", deponentId: "avery", selectedContactId: "avery" },
  },
}));

vi.mock("@/lib/trpc", () => {
  const queryData = (key: string): any => {
    if (key === "contact.list") return state.contacts;
    if (key === "document.list") return state.documents;
    if (key === "document.preview") return { sections: [] };
    if (key === "settings.get") return { lawyerName: "Firm Lawyer", firmCity: "Victoria" };
    return ["document.versions", "document.retainedFiles", "document.getLetterRecipients", "citation.list", "delivery.list", "delivery.getRecipients"].includes(key) ? [] : undefined;
  };
  const mutation = (key: string, options?: any) => {
    const mutateAsync = async (input: any) => {
      try {
        if (key === "document.generate") state.generateCalls.push(input);
        const result = key === "document.generate"
          ? { id: "doc_p8_1", delivery: state.delivery, filename: "P8_Avery_Calder-Quay.docx", format: "docx" }
          : { revision: 2 };
        await options?.onSuccess?.(result, input, undefined);
        return result;
      } catch (error) {
        await options?.onError?.(error, input, undefined);
        throw error;
      }
    };
    return { mutateAsync, mutate: (input: any) => { void mutateAsync(input).catch(() => undefined); }, isPending: false };
  };
  const utils = (path: string[]): any => new Proxy({}, {
    get(_target, property: string): any {
      if (["invalidate", "setData", "cancel"].includes(property)) return () => undefined;
      if (property === "getData") return () => state.estate;
      if (property === "fetch") return async (input: any) => {
        if (path.join(".") === "estate.get") return state.estate;
        if (path.join(".") !== "document.preflight") return [];
        await state.gate;
        const { checkFormRequirements } = await import("@shared/formRequirements");
        const primary = state.documents.find((doc) => ["P3", "P4", "P5", "P6", "P7"].includes(doc.formCode));
        return checkFormRequirements("P8", {
          estate: state.estate, contacts: state.contacts, inventory: [], liabilities: [], deliveries: [],
          renderContext: { selectedContactId: input.selectedContactId, p8SingleFormDeponentId: input.selectedContactId, primaryAffidavit: primary ?? null },
        } as any);
      };
      return utils([...path, property]);
    },
  });
  const node = (path: string[]): any => new Proxy({}, {
    get(_target, property: string): any {
      if (property === "useQuery") return () => ({ data: queryData(path.join(".")), isLoading: false, error: null });
      if (property === "useMutation") return (options: any) => mutation(path.join("."), options);
      if (property === "useUtils") return () => utils([]);
      return node([...path, property]);
    },
  });
  return { trpc: node([]) };
});

const jordan = {
  id: "jordan", name: "Jordan Ellis Calder-Quay", role: "applicant,executor", executorStatus: "applying",
  executorRank: "primary", applicantKind: "individual", occupation: "Teacher", relationship: "child",
  residentialAddress: "10 Main Street, Victoria, BC", residenceStreet: "10 Main Street",
  residenceCity: "Victoria", residenceProvince: "BC", residenceCountry: "Canada",
};
const avery = { ...jordan, id: "avery", name: "Avery Calder-Quay", executorRank: "alternate", occupation: "Engineer" };
const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
/** Each same-tab form POST the page submits; the browser's attachment download follows it. */
const downloads: Array<{ method: string; action: string | null; fields: Record<string, string> }> = [];
const posted = (fields: Record<string, string>) => ({ method: "post", action: "/api/download/form", fields: { ...fields, attemptId: expect.stringMatching(UUID_V4) } });

beforeEach(() => {
  vi.clearAllMocks();
  state.estate = {
    id: "estate-19", revision: 1, deceasedFirstName: "Helen Rose", deceasedLastName: "Calder-Quay",
    grantType: "grant_of_probate", hasWill: 1, willStatus: "has_will", applicantType: "individual",
    deceasedDomiciledInBC: "yes", deceasedOrdinarilyResidentInBC: "yes", oathType: "affirmed", domicileCity: "Victoria",
  };
  state.contacts = [jordan, avery];
  state.documents = [];
  state.generateCalls = [];
  state.gate = new Promise<void>((resolve, reject) => { state.release = resolve; state.reject = reject; });
  downloads.length = 0;
  vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) {
    downloads.push({ method: this.method, action: this.getAttribute("action"), fields: Object.fromEntries(new FormData(this)) as Record<string, string> });
  });
});
afterEach(() => vi.restoreAllMocks());

async function mountAndClickAvery() {
  const { FormsTab } = await import("./EstateDetail");
  render(<FormsTab estateId="estate-19" estate={state.estate} onNavigateToTab={vi.fn()} />);
  fireEvent.click(within(screen.getByTestId("form-row-P8")).getByRole("button", { name: "Generate", exact: true }));
  fireEvent.click(await screen.findByTestId("form-details-generate"));
}

describe("visible progress between a closed dialog and the server's answer", () => {
  it("shows a working indicator while preflight is in flight and clears it once the gap dialog opens", async () => {
    await mountAndClickAvery();
    const busy = await screen.findByTestId("preflight-busy");
    expect(busy.textContent).toContain("P8");
    expect(screen.queryByTestId("pre-generate-dialog")).toBeNull();
    state.release();
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());
    expect(screen.queryByTestId("preflight-busy")).toBeNull();
  });

  it("keeps the indicator through an all-green generate and clears it after the download starts", async () => {
    state.documents = [{ id: "primary", formCode: "P3", deponentId: "jordan", deponentName: jordan.name, signatureDate: "2026-09-05" }];
    await mountAndClickAvery();
    await screen.findByTestId("preflight-busy");
    expect(downloads).toHaveLength(0);
    state.release();
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(downloads[0]).toEqual(posted(state.delivery.fields));
    await waitFor(() => expect(screen.queryByTestId("preflight-busy")).toBeNull());
    expect(state.generateCalls[0]).toMatchObject({ formCode: "P8", deponentId: "avery" });
    expect(toast.info).toHaveBeenCalledTimes(1);
  });

  it("does not start a misleading preflight when a single applicant needs a real co-applicant", async () => {
    state.contacts = [jordan];
    const { FormsTab } = await import("./EstateDetail");
    render(<FormsTab estateId="estate-19" estate={state.estate} onNavigateToTab={vi.fn()} />);
    fireEvent.click(screen.getByTestId("form-generate-P8"));
    expect(await screen.findByTestId("p8-co-applicant-intake-dialog")).toBeTruthy();
    expect(screen.queryByTestId("preflight-busy")).toBeNull();
    fireEvent.click(screen.getByTestId("p8-save-co-applicant"));
    expect(await screen.findByTestId("p8-co-applicant-error")).toBeTruthy();
    expect(screen.queryByTestId("preflight-busy")).toBeNull();
    expect(downloads).toHaveLength(0);
  });
});
