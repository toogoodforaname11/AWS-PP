import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import React from "react";
import { CircleAlert } from "lucide-react";
import { menuItems } from "@/components/DashboardLayout";

const mocks = vi.hoisted(() => ({
  mutate: vi.fn(), refetch: vi.fn(), isPending: false, error: null as null | Error,
  reports: [] as Array<Record<string, unknown>>, onSuccess: undefined as undefined | ((value: { success: boolean; deliveryStatus: "delivered" | "delivery_failed" }) => void),
  updateStatus: vi.fn(), allReports: [] as Array<Record<string, unknown>>, replyTemplates: [] as Array<Record<string, unknown>>,
  createTemplate: vi.fn(), updateTemplate: vi.fn(), deleteTemplate: vi.fn(),
  detail: undefined as undefined | { report: Record<string, unknown>; responses: Array<Record<string, unknown>>; actionHistory?: Array<Record<string, unknown>> }, addResponse: vi.fn(), role: "user",
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    support: {
      reportProblem: { useMutation: (options: { onSuccess?: (value: { success: boolean; deliveryStatus: "delivered" | "delivery_failed" }) => void }) => { mocks.onSuccess = options.onSuccess; return { mutate: mocks.mutate, isPending: mocks.isPending, error: mocks.error }; } },
      listReports: { useQuery: () => ({ data: mocks.reports, isLoading: false, refetch: mocks.refetch }) },
      listAllReports: { useQuery: () => ({ data: mocks.allReports, isLoading: false, refetch: mocks.refetch }) },
      updateIssueStatus: { useMutation: () => ({ mutate: mocks.updateStatus, isPending: false }) },
      listReplyTemplates: { useQuery: () => ({ data: mocks.replyTemplates, isLoading: false, refetch: mocks.refetch }) },
      createReplyTemplate: { useMutation: () => ({ mutate: mocks.createTemplate, isPending: false }) },
      updateReplyTemplate: { useMutation: () => ({ mutate: mocks.updateTemplate, isPending: false }) },
      deleteReplyTemplate: { useMutation: () => ({ mutate: mocks.deleteTemplate, isPending: false }) },
      getReportDetail: { useQuery: () => ({ data: mocks.detail, isLoading: false, error: null, refetch: mocks.refetch }) },
      addResponse: { useMutation: () => ({ mutate: mocks.addResponse, isPending: false }) },
    },
  },
}));
vi.mock("@/_core/hooks/useAuth", () => ({ useAuth: () => ({ user: { id: 9, role: mocks.role } }) }));

import ReportProblem from "./ReportProblem";

afterEach(() => { cleanup(); localStorage.clear(); window.history.replaceState({}, "", "/report-a-problem"); mocks.mutate.mockReset(); mocks.refetch.mockReset(); mocks.updateStatus.mockReset(); mocks.addResponse.mockReset(); mocks.createTemplate.mockReset(); mocks.updateTemplate.mockReset(); mocks.deleteTemplate.mockReset(); mocks.isPending = false; mocks.error = null; mocks.reports = []; mocks.allReports = []; mocks.replyTemplates = []; mocks.detail = undefined; mocks.role = "user"; mocks.onSuccess = undefined; });

describe("ReportProblem", () => {
  it("places Report a Problem directly below How It Works", () => {
    expect(menuItems.map((item) => item.label)).toEqual(["Estate Files", "Deadlines", "Executor Portal", "How It Works", "Report a Problem", "Settings"]);
  });

  it("uses an exclamation-mark alert icon for Report a Problem", () => {
    const reportItem = menuItems.find((item) => item.label === "Report a Problem");
    expect(reportItem).toMatchObject({ path: "/report-a-problem", icon: CircleAlert });
  });

  it("autosaves and restores the in-progress report draft", () => {
    const first = render(<ReportProblem />);
    fireEvent.change(screen.getByLabelText("Problem summary"), { target: { value: "Preview does not open" } });
    fireEvent.change(screen.getByLabelText("What happened?"), { target: { value: "I selected the preview button and the dialog did not appear." } });
    expect(screen.getByRole("status", { name: "" }).textContent).toMatch(/draft saved/i);
    expect(localStorage.getItem("probatepro:report-problem-draft:v1")).toContain("Preview does not open");
    first.unmount();
    render(<ReportProblem />);
    expect((screen.getByLabelText("Problem summary") as HTMLInputElement).value).toBe("Preview does not open");
    expect((screen.getByLabelText("What happened?") as HTMLTextAreaElement).value).toMatch(/preview button/i);
  });

  it("accepts removable evidence and sends it with the structured report", async () => {
    render(<ReportProblem />);
    fireEvent.change(screen.getByLabelText("Problem summary"), { target: { value: "Preview does not open" } });
    fireEvent.change(screen.getByLabelText("What happened?"), { target: { value: "I selected the preview button and the dialog did not appear." } });
    const evidence = new File(["support context"], "evidence.txt", { type: "text/plain" });
    fireEvent.change(screen.getByLabelText("Screenshot or file (optional)"), { target: { files: [evidence] } });
    await screen.findByText("evidence.txt");
    fireEvent.click(screen.getByRole("button", { name: "Send report" }));
    await waitFor(() => expect(mocks.mutate).toHaveBeenCalledWith(expect.objectContaining({ attachment: expect.objectContaining({ fileName: "evidence.txt", mimeType: "text/plain" }) })));
    fireEvent.click(screen.getByRole("button", { name: "Remove evidence.txt" }));
    expect(screen.queryByText("evidence.txt")).toBeNull();
  });

  it("shows only the caller's previous reports with delivery status and evidence metadata", () => {
    mocks.reports = [{ id: "report-1", category: "performance", subject: "Slow preview", details: "The preview is slow after selecting a document.", createdAt: 1_740_000_000_000, issueStatus: "in_progress", deliveryStatus: "delivery_failed", deliveryError: "Support delivery is temporarily unavailable.", attachmentStorageKey: "support-reports/1/report-1.png", attachmentName: "screen.png" }];
    render(<ReportProblem />);
    expect(screen.getByText("View Previous Reports")).toBeTruthy();
    expect(screen.getByText("Slow preview")).toBeTruthy();
    expect(screen.getByText("Delivery pending")).toBeTruthy();
    expect(screen.getByLabelText("Issue status: In Progress")).toBeTruthy();
  });

  it("opens a private full-detail view with the submitted information and support response", () => {
    mocks.reports = [{ id: "report-1", category: "performance", subject: "Slow preview", details: "The preview is slow after selecting a document.", createdAt: 1_740_000_000_000, issueStatus: "resolved", deliveryStatus: "delivered", page: "/estate/1", attachmentStorageKey: "support-reports/9/screen.png", attachmentName: "screen.png" }];
    mocks.detail = { report: mocks.reports[0], responses: [{ id: "response-1", message: "The preview issue has been resolved in the latest update.", createdAt: 1_740_000_001_000 }] };
    render(<ReportProblem />);
    fireEvent.click(screen.getByRole("button", { name: "View details for Slow preview" }));
    expect(screen.getByRole("dialog").textContent).toMatch(/submitted details/i);
    expect(screen.getByText("The preview issue has been resolved in the latest update.")).toBeTruthy();
    expect(screen.getByRole("dialog").textContent).toMatch(/resolved/i);
    expect(screen.getByRole("link", { name: "screen.png" }).getAttribute("href")).toBe("/manus-storage/support-reports/9/screen.png");
  });

  it("lets an administrator add a private response from the opened report detail", () => {
    mocks.role = "admin";
    mocks.allReports = [{ id: "report-2", userId: 22, category: "access", subject: "Sign-in problem", details: "The user cannot reach the sign-in callback.", createdAt: 1_740_000_000_000, issueStatus: "pending", deliveryStatus: "delivered" }];
    mocks.detail = { report: mocks.allReports[0], responses: [] };
    render(<ReportProblem />);
    fireEvent.click(screen.getByRole("button", { name: "View details for Sign-in problem" }));
    fireEvent.change(screen.getByLabelText("Add a support response"), { target: { value: "We are investigating the sign-in callback." } });
    fireEvent.click(screen.getByRole("button", { name: "Send response" }));
    expect(mocks.addResponse).toHaveBeenCalledWith({ reportId: "report-2", message: "We are investigating the sign-in callback." });
  });

  it("shows a private administrator action history with actor and change context", () => {
    mocks.role = "admin";
    mocks.allReports = [{ id: "report-audit", userId: 22, category: "access", subject: "Audited report", details: "Status updates should be traceable.", createdAt: 1_740_000_000_000, issueStatus: "resolved", deliveryStatus: "delivered" }];
    mocks.detail = { report: mocks.allReports[0], responses: [], actionHistory: [{ id: "action-1", action: "bulk_resolved", previousValue: "pending", nextValue: "resolved", actorName: "Nick Brzozowski", createdAt: 1_740_000_001_000 }] };
    render(<ReportProblem />);
    fireEvent.click(screen.getByRole("button", { name: "View details for Audited report" }));
    const history = screen.getByLabelText("Administrator action history");
    expect(history.textContent).toMatch(/resolved in bulk/i);
    expect(history.textContent).toMatch(/pending → resolved/i);
    expect(history.textContent).toMatch(/Nick Brzozowski/);
  });

  it("inserts an editable quick reply for an administrator without sending it automatically", () => {
    mocks.role = "admin";
    mocks.allReports = [{ id: "report-3", userId: 22, category: "access", subject: "Sign-in problem", details: "The user cannot reach the sign-in callback.", createdAt: 1_740_000_000_000, issueStatus: "pending", deliveryStatus: "delivered" }];
    mocks.detail = { report: mocks.allReports[0], responses: [] };
    render(<ReportProblem />);
    fireEvent.click(screen.getByRole("button", { name: "View details for Sign-in problem" }));
    fireEvent.click(screen.getByLabelText("Choose an editable quick reply"));
    fireEvent.click(screen.getByRole("option", { name: "Investigation underway" }));
    expect((screen.getByLabelText("Add a support response") as HTMLTextAreaElement).value).toMatch(/investigating this issue/i);
    expect(mocks.addResponse).not.toHaveBeenCalled();
  });

  it("opens the report named by an administrator queue link", () => {
    mocks.role = "admin";
    mocks.allReports = [{ id: "report-linked", userId: 22, category: "access", subject: "Direct queue report", details: "The queue link should open this report.", createdAt: 1_740_000_000_000, issueStatus: "pending", deliveryStatus: "delivered" }];
    mocks.detail = { report: mocks.allReports[0], responses: [] };
    window.history.replaceState({}, "", "/report-a-problem?reportId=report-linked");
    render(<ReportProblem />);
    expect(screen.getByRole("dialog").textContent).toMatch(/Direct queue report/);
  });

  it("loads, updates, and saves an administrator-owned custom quick reply without sending it", () => {
    mocks.role = "admin";
    mocks.replyTemplates = [{ id: "template-1", name: "Firm update", message: "We have shared this with the firm team." }];
    mocks.allReports = [{ id: "report-4", userId: 22, category: "access", subject: "Sign-in problem", details: "The user cannot reach the sign-in callback.", createdAt: 1_740_000_000_000, issueStatus: "pending", deliveryStatus: "delivered" }];
    mocks.detail = { report: mocks.allReports[0], responses: [] };
    render(<ReportProblem />);
    fireEvent.click(screen.getByRole("button", { name: "View details for Sign-in problem" }));
    fireEvent.click(screen.getByLabelText("Choose an editable quick reply"));
    fireEvent.click(screen.getByRole("option", { name: "Firm update" }));
    expect((screen.getByLabelText("Add a support response") as HTMLTextAreaElement).value).toMatch(/firm team/i);
    fireEvent.click(screen.getByRole("button", { name: "Preview reply" }));
    expect(screen.getByLabelText("Support response preview").textContent).toMatch(/firm team/i);
    expect(mocks.addResponse).not.toHaveBeenCalled();
    fireEvent.change(screen.getByLabelText("Save as template"), { target: { value: "Firm update revised" } });
    fireEvent.click(screen.getByRole("button", { name: "Update template" }));
    expect(mocks.updateTemplate).toHaveBeenCalledWith({ id: "template-1", name: "Firm update revised", message: "We have shared this with the firm team." });
    expect(mocks.addResponse).not.toHaveBeenCalled();
  });
});
