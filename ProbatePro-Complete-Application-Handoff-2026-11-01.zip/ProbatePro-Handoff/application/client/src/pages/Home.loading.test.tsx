import React from "react";
import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { EstateRowSkeleton } from "./Home";

describe("EstateRowSkeleton", () => {
  it("mirrors the estate record hierarchy with calm, reduced-motion-safe loading rows", () => {
    render(<EstateRowSkeleton count={2} />);
    expect(screen.getByRole("status", { name: "Loading estate files" })).toBeTruthy();
    const rows = screen.getAllByTestId("estate-row-skeleton");
    expect(rows).toHaveLength(2);
    expect(rows[0].textContent).toBe("");
    expect(rows[0].querySelectorAll(".estate-row-skeleton-pulse")).toHaveLength(6);
    expect(rows[0].innerHTML).toContain("motion-reduce:animate-none");
  });
});
