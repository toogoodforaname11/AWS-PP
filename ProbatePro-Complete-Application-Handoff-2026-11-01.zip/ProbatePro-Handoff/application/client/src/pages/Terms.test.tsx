import { render, screen } from "@testing-library/react";
import React from "react";
import { describe, expect, it } from "vitest";
import Terms from "./Terms";

// 2026-08-04 legal-copy finding: the Terms body called the product "Estate
// Manager" (the page's own nav already said ProbatePro) and cited a
// nonexistent authority — BC has no separate "Probate Rules"; the probate
// regime this app implements is Part 25 and Appendix A.1 of the Supreme Court
// Civil Rules. These pins keep the public legal copy accurate. Counsel
// approval of the overall legal copy remains an open launch item (tracked with
// the AI-processor disclosure) — these pins are about factual accuracy only.
describe("Terms of Service — product name and governing authority", () => {
  it("has an indexable public canonical page without changing the legal copy", () => {
    render(<Terms />);
    expect(document.title).toBe("Terms of Service | ProbatePro");
    expect(document.head.querySelector('meta[name="robots"]')?.getAttribute("content")).toBe("index, follow");
    expect(document.head.querySelector('link[rel="canonical"]')?.getAttribute("href")).toBe("https://probate-pro.com/terms");
  });

  it("names the service ProbatePro, not the stale Estate Manager", () => {
    render(<Terms />);
    expect(screen.getByText(/the ProbatePro application available at probate-pro\.com \(the "Service"\)/)).toBeTruthy();
    expect(screen.getByText(/ProbatePro is a software-as-a-service \("SaaS"\) tool/)).toBeTruthy();
    expect(screen.queryByText(/Estate Manager/)).toBeNull();
  });

  it("cites Part 25 and Appendix A.1 of the Supreme Court Civil Rules — never the nonexistent 'Probate Rules'", () => {
    render(<Terms />);
    // §2 Description of Service and §7 Document Generation Disclaimer.
    expect(screen.getAllByText(/Part 25 and Appendix A\.1 of the British Columbia Supreme Court Civil Rules/).length).toBe(2);
    expect(screen.queryByText(/Probate Rules/)).toBeNull();
  });

  it("carries the 2026-08-05 legal-copy revision date (retention/storage rewrite shipped after Aug 4)", () => {
    render(<Terms />);
    expect(screen.getByText("Last updated: August 5, 2026")).toBeTruthy();
  });

  it("does not promise automatic account-termination deletion that bypasses client-file retention", () => {
    render(<Terms />);
    expect(screen.getByText(/Account closure does not itself authorize destruction of estate or law-practice records/)).toBeTruthy();
    expect(screen.queryByText(/after which it will be securely deleted/)).toBeNull();
  });
});
