import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Copy, Plus, Trash2, Building2, Save, RefreshCw, Shield, Upload, X, Image, PenLine, Mail, CheckCircle2, CircleAlert, CircleCheck, History, CheckSquare, HelpCircle, Search, KeyRound, ExternalLink, BriefcaseBusiness, UserRound, Check } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { motion, AnimatePresence } from "framer-motion";
import { PageHeader } from "@/components/PageHeader";
import React, { useState, useEffect, useRef } from "react";
import { announceFormFocusedIntakeActivation, storeFormFocusedIntakePreference, useFormFocusedIntakePreference } from "@/hooks/useFormFocusedIntakePreference";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { fmtDisplayDate } from "@/lib/labels";
import { clearFallbackSession } from "@/lib/fallbackSession";
import { AddressAutocomplete } from "@/components/AddressAutocomplete";
import { formatPhone } from "@/lib/formatters";
import { useLocalDraft } from "@/hooks/useLocalDraft";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { getLoginUrlAsync } from "@/const";
import { Seo } from "@/components/Seo";
import { IDLE_UPLOAD_FEEDBACK, UploadFeedback, fileTooLargeMessage, invalidFileTypeMessage, type UploadFeedbackState } from "@/components/UploadFeedback";
import {
  DEFAULT_LETTER_TEMPLATE,
  LETTER_PLACEHOLDERS,
  letterTemplateContractIssues,
  resolveLetterTemplate,
} from "@shared/letter-template";

type SectionSaveState = "idle" | "saving" | "saved" | "error";
type AccountDeletionReason = "no_longer_needed" | "switching_solution" | "too_complex" | "missing_features" | "cost" | "other";

function SectionSaveFeedback({ state }: { state: SectionSaveState }) {
  if (state === "idle") return null;
  const content = state === "saving"
    ? { label: "Saving…", className: "text-muted-foreground", icon: <RefreshCw className="h-3.5 w-3.5 animate-spin" /> }
    : state === "saved"
      ? { label: "Saved", className: "text-green-700 dark:text-green-400", icon: <CheckCircle2 className="h-3.5 w-3.5" /> }
      : { label: "Couldn’t save — try again", className: "text-destructive", icon: <CircleAlert className="h-3.5 w-3.5" /> };
  return (
    <span role="status" className={`inline-flex items-center gap-1.5 text-xs font-medium ${content.className}`}>
      {content.icon}
      {content.label}
    </span>
  );
}

const SETTINGS_NAVIGATION = [
  { href: "#firm-details", label: "Firm details" },
  { href: "#letter-template", label: "Letter template" },
  { href: "#letter-closing", label: "Closing block" },
  { href: "#intake-view", label: "Intake view" },
  { href: "#assistant-preferences", label: "Assistant" },
  { href: "#checkbox-appearance", label: "Checkbox appearance" },
  { href: "#account-recovery", label: "Password & sign-in" },
  { href: "#account-danger-zone", label: "Account" },
];

export default function Settings() {
  const { data: accountSettings } = trpc.settings.get.useQuery();
  const personalExecutor = accountSettings?.accountPurpose === "personal_executor";
  const navigationItems = personalExecutor
    ? [
        { href: "#account-purpose", label: "Account purpose" },
        { href: "#letter-settings", label: "Letters" },
        ...SETTINGS_NAVIGATION.filter((item) => item.href !== "#firm-details"),
      ]
    : SETTINGS_NAVIGATION;
  return (
    <div className="space-y-6">
      <Seo
        title="Settings | ProbatePro"
        description="Private ProbatePro workspace settings."
        path="/settings"
        index={false}
      />
      <PageHeader
        title="Settings"
        description={personalExecutor ? "Manage your personal workspace and application preferences" : "Manage firm settings, templates, and application preferences"}
      />
      <motion.div
        className="grid gap-6 lg:grid-cols-[12rem_minmax(0,1fr)]"
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.3, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] }}
      >
        <nav className="flex flex-wrap gap-1 rounded-xl border bg-card/70 p-2 lg:sticky lg:top-6 lg:h-fit lg:flex-col" aria-label="Settings sections">
          {navigationItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="shrink-0 rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            >
              {item.label}
            </a>
          ))}
        </nav>
        <div className="min-w-0 space-y-6">
          <AccountPurposeSection />
          <FirmSettingsSection />
          <WorkspacePreferencesSection />
          <ChatbotPreferencesSection />
          <CheckboxPreviewSection />
          <ManagedAccountRecovery />
          <AccountDangerZone />
          {/* Legal */}
          <div className="pt-4 border-t flex items-center gap-4 text-sm text-muted-foreground">
            <a href="/terms" className="hover:text-foreground transition-colors">Terms of Service</a>
            <span className="text-muted-foreground/30">·</span>
            <a href="/privacy" className="hover:text-foreground transition-colors">Privacy Policy</a>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

type AccountPurpose = "lawyer" | "personal_executor";

function AccountPurposeSection() {
  const { data: settings, isLoading } = trpc.settings.get.useQuery();
  const utils = trpc.useUtils();
  const currentPurpose: AccountPurpose = settings?.accountPurpose === "personal_executor" ? "personal_executor" : "lawyer";
  const [open, setOpen] = useState(false);
  const [selectedPurpose, setSelectedPurpose] = useState<AccountPurpose>(currentPurpose);

  useEffect(() => {
    if (!open) setSelectedPurpose(currentPurpose);
  }, [currentPurpose, open]);

  const updatePurpose = trpc.settings.update.useMutation({
    onSuccess: (_data, variables) => {
      if (typeof variables?.formFocusedIntake === "boolean") {
        storeFormFocusedIntakePreference(variables.formFocusedIntake);
      }
      utils.settings.get.invalidate();
      setOpen(false);
      toast.success("Account type updated");
    },
    onError: (error) => toast.error(error.message || "Unable to update account type"),
  });

  const selectedDetails = selectedPurpose === "lawyer"
    ? { label: "Lawyer", description: "Use a form-focused starting view; Full Intake remains available.", icon: BriefcaseBusiness }
    : { label: "Personal executor", description: "Use Full Intake as the guided starting view.", icon: UserRound };
  const CurrentIcon = currentPurpose === "lawyer" ? BriefcaseBusiness : UserRound;

  return (
    <Card id="account-purpose" data-testid="account-purpose-settings" className="scroll-mt-6 overflow-hidden border-primary/20 bg-[linear-gradient(135deg,rgba(30,64,105,0.055),rgba(255,255,255,0.84)_54%,rgba(222,236,248,0.36))] shadow-[0_16px_34px_-32px_rgba(15,42,70,0.75),inset_0_1px_0_rgba(255,255,255,0.9)] dark:bg-[linear-gradient(135deg,rgba(30,64,105,0.2),rgba(24,24,27,0.82)_54%,rgba(30,64,105,0.1))]">
      <CardContent className="relative grid gap-4 p-5 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
        <div className="pointer-events-none absolute inset-y-0 left-0 w-1 bg-gradient-to-b from-sky-300 via-primary to-slate-800" />
        <div className="min-w-0 pl-2">
          <div className="mb-2 flex items-center gap-2 text-primary">
            <span className="grid size-8 place-items-center rounded-lg border border-primary/20 bg-primary/10 shadow-[inset_0_1px_0_rgba(255,255,255,0.5)]"><CurrentIcon className="size-4" aria-hidden="true" /></span>
            <p className="text-sm font-bold tracking-[0.01em]">Account type</p>
          </div>
          <p className="text-sm leading-6 text-muted-foreground">Current workspace: <span className="font-semibold text-foreground">{currentPurpose === "lawyer" ? "Lawyer" : "Personal executor"}</span>. This only selects a workspace starting view; it does not establish an appointment, professional status, or access to any estate.</p>
        </div>
        <Dialog open={open} onOpenChange={(nextOpen) => {
          if (updatePurpose.isPending && !nextOpen) return;
          setOpen(nextOpen);
        }}>
          <DialogTrigger asChild>
            <Button type="button" variant="outline" disabled={isLoading} className="h-10 shrink-0 border-primary/25 bg-background/75 px-4 font-semibold text-primary shadow-[0_3px_0_rgba(15,42,70,0.2),inset_0_1px_0_rgba(255,255,255,0.85)] transition-[background-color,border-color,box-shadow,transform] duration-150 ease-out hover:-translate-y-px hover:border-primary/45 hover:bg-background hover:shadow-[0_5px_0_rgba(15,42,70,0.18),inset_0_1px_0_rgba(255,255,255,0.95)] focus-visible:ring-primary/35 active:translate-y-px active:shadow-[0_1px_0_rgba(15,42,70,0.22)] motion-reduce:transform-none" data-testid="change-account-type">
              Change account type
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg" data-testid="account-type-dialog" onEscapeKeyDown={(event) => {
            if (updatePurpose.isPending) event.preventDefault();
          }}>
            <DialogHeader>
              <DialogTitle>Choose account type</DialogTitle>
              <DialogDescription className="leading-6">Select the workspace presentation that suits you. The change is reversible and does not change estate access, form requirements, or any recorded appointment.</DialogDescription>
            </DialogHeader>
            <fieldset className="grid gap-3 sm:grid-cols-2">
              <legend className="sr-only">Account type</legend>
              {([
                {
                  value: "lawyer",
                  label: "Lawyer",
                  description: "Form-focused Intake is the starting view.",
                  tooltip: "Starts with Form-focused Intake and one catalog of supported forms. Firm details, letterhead, and form preferences remain available in Settings; Full Intake can be enabled anytime.",
                  icon: BriefcaseBusiness,
                },
                {
                  value: "personal_executor",
                  label: "Personal executor",
                  description: "Full Intake is the starting view.",
                  tooltip: "Starts with guided Full Intake and the same form-generation checks. You can change the Intake view anytime; this selection does not record an executor appointment.",
                  icon: UserRound,
                },
              ] as const).map(({ value, label, description, tooltip, icon: Icon }) => {
                const selected = selectedPurpose === value;
                return (
                  <label key={value} data-state={selected ? "selected" : "idle"} className="onboarding-purpose-card flex min-h-32 cursor-pointer flex-col justify-between rounded-xl border p-4">
                    <input type="radio" name="settings-account-purpose" value={value} checked={selected} onChange={() => setSelectedPurpose(value)} className="sr-only" data-testid={`account-type-${value}`} />
                    <span className="flex items-center justify-between gap-2 text-foreground">
                      <span className="flex items-center gap-1.5">
                        <span className="grid size-8 place-items-center rounded-lg border border-border/80 bg-muted/45 text-primary"><Icon className="size-4" aria-hidden="true" /></span>
                        <Tooltip delayDuration={360} skipDelayDuration={160}>
                          <TooltipTrigger asChild>
                            <button
                              type="button"
                              aria-label={`About the ${label} workspace`}
                              className="inline-flex size-6 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/35"
                              onClick={(event) => { event.preventDefault(); event.stopPropagation(); }}
                            >
                              <HelpCircle className="size-3.5" aria-hidden="true" />
                            </button>
                          </TooltipTrigger>
                          <TooltipContent side="top" sideOffset={8} className="max-w-xs rounded-xl border bg-popover px-3 py-2 text-xs leading-relaxed text-popover-foreground shadow-lg">
                            {tooltip}
                          </TooltipContent>
                        </Tooltip>
                      </span>
                      <span className="onboarding-purpose-check grid size-5 place-items-center rounded-md" aria-hidden="true">{selected && <Check className="size-3.5" strokeWidth={2.6} />}</span>
                    </span>
                    <span><span className="block text-sm font-semibold">{label}</span><span className="mt-1 block text-xs leading-5 text-muted-foreground">{description}</span></span>
                  </label>
                );
              })}
            </fieldset>
            <p className="rounded-lg border border-border/70 bg-muted/30 px-3 py-2.5 text-xs leading-5 text-muted-foreground" role="status">
              {selectedDetails.label}: {selectedDetails.description} Existing firm details remain saved if you switch to a personal workspace.
            </p>
            <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
              <Button type="button" variant="outline" disabled={updatePurpose.isPending} onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="button" className="probate-primary-action min-w-40" disabled={updatePurpose.isPending || selectedPurpose === currentPurpose} onClick={() => updatePurpose.mutate({ accountPurpose: selectedPurpose, formFocusedIntake: selectedPurpose === "lawyer" })} data-testid="confirm-account-type">
                {updatePurpose.isPending ? <><RefreshCw aria-hidden="true" className="size-4 animate-spin motion-reduce:animate-none" /> Saving…</> : "Save account type"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}

function WorkspacePreferencesSection() {
  const { data: settings, isLoading } = trpc.settings.get.useQuery();
  const utils = trpc.useUtils();
  const formFocusedIntake = useFormFocusedIntakePreference(settings?.formFocusedIntake);
  const [saveState, setSaveState] = useState<SectionSaveState>("idle");
  const updateMutation = trpc.settings.update.useMutation({
    onSuccess: (_data, variables) => {
      if (typeof variables?.formFocusedIntake === "boolean") {
        storeFormFocusedIntakePreference(variables.formFocusedIntake);
        if (variables.formFocusedIntake) announceFormFocusedIntakeActivation();
      }
      setSaveState("saved");
      toast.success("Intake view preference saved");
      utils.settings.get.invalidate();
      window.setTimeout(() => setSaveState("idle"), 3000);
    },
    onError: (error) => {
      setSaveState("error");
      toast.error(error.message);
    },
  });

  return (
    <Card id="intake-view" className="scroll-mt-6">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm">Intake &amp; forms view</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-start justify-between gap-4 rounded-lg border border-border/70 bg-muted/25 p-3">
          <div className="min-w-0 space-y-1">
            <div className="flex items-center gap-1.5">
              <Label htmlFor="form-focused-intake" className="cursor-pointer text-sm font-medium">
                Form-focused intake
              </Label>
              <TooltipProvider delayDuration={200}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      type="button"
                      className="inline-flex size-5 shrink-0 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      aria-label="Explain form-focused intake"
                    >
                      <HelpCircle className="h-3.5 w-3.5" aria-hidden="true" />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="top" className="max-w-sm text-xs leading-relaxed">
                    <p className="font-medium">What changes</p>
                    <p className="mt-1">The full view keeps all Intake fields and separates Forms into Required and Optional. Form-focused view hides only curated case-management fields and lists every supported form together in catalog order.</p>
                    <p className="mt-1.5 text-muted-foreground">It never changes form requirements, warnings, or generation. The selected view is also remembered on this browser.</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <p className="max-w-2xl text-xs leading-5 text-muted-foreground">
              This Settings switch stays in sync with the primary control in the sidebar.
            </p>
          </div>
          <Switch
            id="form-focused-intake"
            aria-label="Use form-focused intake"
            checked={formFocusedIntake}
            disabled={isLoading || updateMutation.isPending}
            onCheckedChange={(formFocusedIntake) => {
              setSaveState("saving");
              updateMutation.mutate({ formFocusedIntake });
            }}
          />
        </div>
        <SectionSaveFeedback state={saveState} />
      </CardContent>
    </Card>
  );
}

function ManagedAccountRecovery() {
  const [isOpening, setIsOpening] = useState(false);
  const [openError, setOpenError] = useState("");

  const openManagedRecovery = async () => {
    if (isOpening) return;
    setOpenError("");
    setIsOpening(true);
    try {
      const loginUrl = await getLoginUrlAsync("/settings");
      window.location.assign(loginUrl);
    } catch {
      setIsOpening(false);
      setOpenError("We couldn’t open secure sign-in. Check your connection and try again.");
    }
  };

  return (
    <Card id="account-recovery" data-testid="account-recovery" className="scroll-mt-6 overflow-hidden border-primary/20 bg-[linear-gradient(135deg,rgba(30,64,105,0.055),rgba(255,255,255,0.82)_54%,rgba(222,236,248,0.44))] shadow-[0_18px_38px_-34px_rgba(15,42,70,0.75),inset_0_1px_0_rgba(255,255,255,0.9)] dark:bg-[linear-gradient(135deg,rgba(30,64,105,0.24),rgba(24,24,27,0.82)_54%,rgba(30,64,105,0.14))]">
      <CardContent data-testid="account-recovery-content" className="relative grid gap-4 p-5 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
        <div className="pointer-events-none absolute inset-y-0 left-0 w-1 bg-gradient-to-b from-sky-300 via-primary to-slate-800" />
        <div className="min-w-0 pl-2">
          <div className="mb-2 flex items-center gap-2 text-primary">
            <span className="grid size-8 place-items-center rounded-lg border border-primary/20 bg-primary/10 shadow-[inset_0_1px_0_rgba(255,255,255,0.5)]"><KeyRound className="size-4" /></span>
            <p className="text-sm font-bold tracking-[0.01em]">Password and sign-in help</p>
          </div>
          <p className="max-w-2xl text-sm leading-6 text-muted-foreground">ProbatePro never stores your password. Open secure sign-in to use your managed identity provider’s recovery or alternate-account options, then return here when you are finished.</p>
          <a href="https://help.manus.im" target="_blank" rel="noreferrer" className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-primary underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
            Identity-provider account help <ExternalLink aria-hidden="true" className="size-3" />
          </a>
          {openError ? <Alert role="alert" className="mt-3 border-rose-300/70 bg-rose-50/70 text-rose-950 dark:border-rose-400/30 dark:bg-rose-950/25 dark:text-rose-100"><AlertDescription>{openError}</AlertDescription></Alert> : null}
        </div>
        <Button type="button" onClick={openManagedRecovery} disabled={isOpening} aria-busy={isOpening || undefined} className="h-10 shrink-0 px-4 font-semibold shadow-[0_3px_0_rgba(15,42,70,0.32)] transition-transform duration-150 ease-out hover:-translate-y-px hover:shadow-[0_5px_0_rgba(15,42,70,0.26)] active:translate-y-px active:shadow-[0_1px_0_rgba(15,42,70,0.3)] motion-reduce:transform-none">
          {isOpening ? <><RefreshCw aria-hidden="true" className="mr-2 size-4 animate-spin motion-reduce:animate-none" />Opening secure sign-in…</> : "Open sign-in help"}
        </Button>
      </CardContent>
    </Card>
  );
}

function AccountDangerZone() {
  const utils = trpc.useUtils();
  const [, setLocation] = useLocation();
  const [open, setOpen] = useState(false);
  const [confirmation, setConfirmation] = useState("");
  const [deletionReason, setDeletionReason] = useState<AccountDeletionReason | "">("");
  const [otherFeedback, setOtherFeedback] = useState("");
  const [completed, setCompleted] = useState(false);
  const [deletionError, setDeletionError] = useState("");
  const surveyChoiceClass = "cursor-pointer rounded-md transition-[background-color,color,transform] duration-150 ease-out motion-reduce:transform-none motion-reduce:transition-none data-[highlighted]:translate-x-0.5 data-[highlighted]:bg-rose-50 data-[state=checked]:bg-rose-100 data-[state=checked]:font-medium data-[state=checked]:text-rose-900 dark:data-[highlighted]:bg-rose-950/55 dark:data-[state=checked]:bg-rose-950/70 dark:data-[state=checked]:text-rose-100";
  const deleteAccount = trpc.auth.deleteAccount.useMutation({
    onSuccess: (result) => {
      clearFallbackSession();
      try { localStorage.removeItem("manus-runtime-user-info"); } catch {}
      utils.auth.me.setData(undefined, null);
      setCompleted(true);
      setOpen(false);
      toast.success(result.queuedFirmAssets > 0 ? "Account deleted. Firm assets are queued for secure removal." : "Account deleted and signed out.");
    },
    onError: (error) => {
      setDeletionError(error.message);
      toast.error(error.message);
    },
  });

  useEffect(() => {
    if (!completed) return;
    const redirect = window.setTimeout(() => setLocation("/goodbye?account=deleted", { replace: true }), 520);
    return () => window.clearTimeout(redirect);
  }, [completed, setLocation]);

  if (completed) {
    return (
      <Card id="account-danger-zone" className="scroll-mt-6 border-emerald-500/30 bg-emerald-500/[0.04]">
        <CardContent className="flex flex-col gap-3 py-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-w-0">
            <p className="font-semibold text-emerald-800 dark:text-emerald-300">Account deleted</p>
            <p className="text-sm text-muted-foreground">You have been signed out on this device. Redirecting to Goodbye…</p>
          </div>
          <Button asChild variant="outline" className="shrink-0"><a href="/">Return to start</a></Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card id="account-danger-zone" data-testid="account-danger-zone" className="scroll-mt-6 overflow-hidden border-rose-500/30 bg-[linear-gradient(135deg,rgba(159,18,57,0.065),rgba(255,255,255,0.72)_44%,rgba(251,113,133,0.075))] shadow-[0_20px_38px_-32px_rgba(159,18,57,0.85),inset_0_1px_0_rgba(255,255,255,0.9)] dark:bg-[linear-gradient(135deg,rgba(159,18,57,0.2),rgba(24,24,27,0.8)_48%,rgba(190,24,93,0.13))]">
      <CardContent className="relative grid gap-4 p-5 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
        <div className="pointer-events-none absolute inset-y-0 left-0 w-1 bg-gradient-to-b from-rose-400 via-rose-600 to-rose-900" />
        <div className="min-w-0 pl-2">
          <div className="mb-2 flex items-center gap-2 text-rose-800 dark:text-rose-200">
            <span className="grid size-8 place-items-center rounded-lg border border-rose-500/30 bg-rose-500/10 shadow-[inset_0_1px_0_rgba(255,255,255,0.45)]"><Trash2 className="size-4" /></span>
            <p className="text-sm font-bold tracking-[0.01em]">Account closure</p>
          </div>
          <p className="max-w-2xl text-sm leading-6 text-muted-foreground">Permanently remove your profile, firm settings, saved templates, private notes, and support reports. Estate files are intentionally protected: remove or transfer them through their established retention workflow before closing your account.</p>
        </div>
        <AlertDialog open={open} onOpenChange={(next) => {
          if (deleteAccount.isPending && !next) return;
          setOpen(next);
          setDeletionError("");
          if (!next) { setConfirmation(""); setDeletionReason(""); setOtherFeedback(""); }
        }}>
          <AlertDialogTrigger asChild>
            <Button variant="outline" className="h-10 shrink-0 border-rose-500/45 bg-gradient-to-b from-rose-500/10 to-rose-950/10 px-4 font-semibold text-rose-800 shadow-[0_3px_0_rgba(159,18,57,0.35),inset_0_1px_0_rgba(255,255,255,0.7)] transition-all hover:-translate-y-px hover:border-rose-500/70 hover:bg-rose-500/15 hover:shadow-[0_5px_0_rgba(159,18,57,0.32),inset_0_1px_0_rgba(255,255,255,0.8)] active:translate-y-[2px] active:shadow-[0_1px_0_rgba(159,18,57,0.3)] dark:text-rose-200">
              Delete account
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent className="border-rose-500/30 shadow-[0_28px_90px_-38px_rgba(159,18,57,0.68)]">
            <AlertDialogHeader>
              <AlertDialogTitle>Delete your account?</AlertDialogTitle>
              <AlertDialogDescription className="leading-6">This is permanent. Your account profile and private settings will be removed, and you will be signed out. Estate files are not removed by this action.</AlertDialogDescription>
            </AlertDialogHeader>
            <div className="space-y-2">
              <Label htmlFor="delete-account-confirmation" className="text-sm font-medium">Type <span className="font-mono text-rose-700 dark:text-rose-300">DELETE MY ACCOUNT</span> to confirm</Label>
              <Input id="delete-account-confirmation" autoComplete="off" value={confirmation} onChange={(event) => setConfirmation(event.target.value)} aria-describedby="delete-account-help" />
              <p id="delete-account-help" className="text-xs leading-5 text-muted-foreground">This confirmation protects against an accidental permanent deletion.</p>
              <div className="space-y-2 rounded-lg border border-border/70 bg-muted/35 p-3 transition-[border-color,background-color,box-shadow] duration-200 ease-out motion-reduce:transition-none hover:border-rose-300/70 hover:bg-rose-50/35 dark:hover:border-rose-400/30 dark:hover:bg-rose-950/15">
                <Label htmlFor="delete-account-reason" className="text-sm font-medium">What is your main reason for leaving? <span className="font-normal text-muted-foreground">Optional</span></Label>
                <Select value={deletionReason} onValueChange={(value) => {
                  const nextReason = value as AccountDeletionReason;
                  setDeletionReason(nextReason);
                  if (nextReason !== "other") setOtherFeedback("");
                }}>
                  <SelectTrigger id="delete-account-reason" aria-label="Optional reason for deleting account" className={`h-10 border-rose-200/70 bg-background/85 transition-[border-color,background-color,box-shadow,transform] duration-200 ease-out motion-reduce:transform-none motion-reduce:transition-none hover:-translate-y-px hover:border-rose-400/75 hover:bg-rose-50/75 hover:shadow-[0_4px_14px_-9px_rgba(159,18,57,0.7)] focus-visible:border-rose-500 focus-visible:ring-rose-500/30 dark:border-rose-400/20 dark:hover:bg-rose-950/35 ${deletionReason ? "border-rose-400/75 bg-rose-50/80 shadow-[0_3px_12px_-9px_rgba(159,18,57,0.75)] dark:bg-rose-950/35" : ""}`}><SelectValue placeholder="Prefer not to say" /></SelectTrigger>
                  <SelectContent className="border-rose-200/80 shadow-[0_18px_42px_-20px_rgba(136,19,55,0.48)] dark:border-rose-400/20">
                    <SelectItem className={surveyChoiceClass} value="no_longer_needed">I no longer need ProbatePro</SelectItem>
                    <SelectItem className={surveyChoiceClass} value="switching_solution">I am switching to another solution</SelectItem>
                    <SelectItem className={surveyChoiceClass} value="too_complex">The workflow felt too complex</SelectItem>
                    <SelectItem className={surveyChoiceClass} value="missing_features">I needed a feature that was unavailable</SelectItem>
                    <SelectItem className={surveyChoiceClass} value="cost">Cost or billing considerations</SelectItem>
                    <SelectItem className={surveyChoiceClass} value="other">Another reason</SelectItem>
                  </SelectContent>
                </Select>
                {deletionReason === "other" ? (
                  <div className="space-y-1.5 pt-1">
                    <Label htmlFor="delete-account-other-feedback" className="text-xs font-medium">Additional feedback <span className="font-normal text-muted-foreground">Optional — not sent</span></Label>
                    <Textarea id="delete-account-other-feedback" value={otherFeedback} onChange={(event) => setOtherFeedback(event.target.value)} maxLength={500} placeholder="A private note for your reference while you finish this step" className="min-h-20 resize-y border-rose-200/70 bg-background/85 text-sm focus-visible:border-rose-500 focus-visible:ring-rose-500/30 dark:border-rose-400/20" aria-describedby="delete-account-other-feedback-help" />
                    <p id="delete-account-other-feedback-help" className="text-xs leading-5 text-muted-foreground">This text stays only in this dialog. It is not transmitted, stored, logged, or included in anonymous feedback.</p>
                  </div>
                ) : null}
                <p className="text-xs leading-5 text-muted-foreground">Optional feedback is stored only as an anonymous category. No free text, case data, or account identifier is kept.</p>
              </div>
              {deletionError ? <Alert variant="destructive" role="alert"><AlertDescription>{deletionError}</AlertDescription></Alert> : null}
            </div>
            <AlertDialogFooter className="gap-3 sm:justify-end">
              <AlertDialogCancel disabled={deleteAccount.isPending} className="h-11 w-full border-slate-300 bg-gradient-to-b from-white to-slate-100 px-5 font-semibold text-slate-800 shadow-[0_2px_0_rgba(71,85,105,0.32),inset_0_1px_0_rgba(255,255,255,0.95)] transition-[background-color,border-color,box-shadow,transform] duration-150 ease-out hover:-translate-y-px hover:border-slate-400 hover:bg-white hover:shadow-[0_4px_0_rgba(71,85,105,0.28),inset_0_1px_0_rgba(255,255,255,1)] focus-visible:ring-slate-500/35 active:translate-y-px active:shadow-[0_1px_0_rgba(71,85,105,0.3)] disabled:cursor-not-allowed disabled:opacity-55 dark:border-slate-600 dark:from-slate-800 dark:to-slate-900 dark:text-slate-100 dark:hover:bg-slate-800 sm:w-auto sm:min-w-40">Keep account</AlertDialogCancel>
              <AlertDialogAction disabled={confirmation !== "DELETE MY ACCOUNT" || deleteAccount.isPending} onClick={(event) => { event.preventDefault(); setOtherFeedback(""); deleteAccount.mutate({ confirmation: "DELETE MY ACCOUNT", deletionReason: deletionReason || undefined }); }} className="h-11 w-full min-w-0 bg-rose-700 text-white shadow-[0_2px_0_rgba(136,19,55,0.5)] hover:bg-rose-800 disabled:cursor-wait disabled:opacity-90 sm:w-auto sm:min-w-52">
                {deleteAccount.isPending ? <span role="status" aria-live="polite" className="inline-flex items-center gap-2"><RefreshCw aria-hidden="true" className="size-4 animate-spin motion-reduce:animate-none" />Deleting account…</span> : "Permanently delete account"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </CardContent>
    </Card>
  );
}

function ChatbotPreferencesSection() {
  return (
    <Card id="assistant-preferences" data-testid="chatbot-preferences-card" className="scroll-mt-6">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <HelpCircle className="h-4 w-4 text-primary" />
          Assistant
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-lg border bg-muted/20 p-4">
          <div className="min-w-0 space-y-1">
            <p className="font-medium">Assistant approval</p>
            <p className="text-sm text-muted-foreground">
              Use the Assistant control in the sidebar, immediately above Light/Dark mode, to approve processing and enable the assistant. Turning it off withdraws approval and removes the assistant.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// DEFAULT_LETTER_TEMPLATE now lives in @shared/letter-template so the Settings
// editor and docgen's default path use the same text (Nick UAT F1).

function FirmSettingsSection() {
  const { data: settings, isLoading } = trpc.settings.get.useQuery();
  const utils = trpc.useUtils();
  const [lawyerName, setLawyerName] = useState("");
  const [firmName, setFirmName] = useState("");
  const [firmAddress, setFirmAddress] = useState("");
  const [firmCity, setFirmCity] = useState("");
  const [firmProvince, setFirmProvince] = useState("");
  const [firmPostalCode, setFirmPostalCode] = useState("");
  const [firmPhone, setFirmPhone] = useState("");
  const [firmFax, setFirmFax] = useState("");
  const [showFirmFax, setShowFirmFax] = useState(true);
  const [firmEmail, setFirmEmail] = useState("");
  const [letterBodyTemplate, setLetterBodyTemplate] = useState("");
  const [letterClosing, setLetterClosing] = useState("Yours truly,");
  const [letterShowPerLine, setLetterShowPerLine] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadingDocx, setUploadingDocx] = useState(false);
  const [imageUploadFeedback, setImageUploadFeedback] = useState<UploadFeedbackState>(IDLE_UPLOAD_FEEDBACK);
  const [docxUploadFeedback, setDocxUploadFeedback] = useState<UploadFeedbackState>(IDLE_UPLOAD_FEEDBACK);
  const isDirtyRef = useRef(false);
  const saveTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const initializedRef = useRef(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const docxInputRef = useRef<HTMLInputElement>(null);

  const [saveStatus, setSaveStatus] = useState<'idle' | 'unsaved' | 'saving' | 'saved'>('idle');
  const [letterheadSaveStatus, setLetterheadSaveStatus] = useState<SectionSaveState>("idle");
  const [templateSaveStatus, setTemplateSaveStatus] = useState<SectionSaveState>("idle");
  const [closingSaveStatus, setClosingSaveStatus] = useState<SectionSaveState>("idle");
  const savedTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const markDirty = () => {
    isDirtyRef.current = true;
    if (saveTimeoutRef.current) { clearTimeout(saveTimeoutRef.current); saveTimeoutRef.current = null; }
    if (saveStatus !== 'saving') setSaveStatus('unsaved');
  };

  useEffect(() => {
    if (settings && !isDirtyRef.current) {
      setLawyerName(settings.lawyerName || "");
      setFirmName(settings.firmName || "");
      // Parse composite firmAddress into parts (stored as "street\ncity province postalCode")
      const addr = settings.firmAddress || "";
      const lines = addr.split("\n");
      if (lines.length >= 2) {
        // New format: line 1 = street, line 2 = "city province postalCode"
        setFirmAddress(lines[0]);
        const secondLine = lines[1];
        const pcMatch = secondLine.match(/([A-Z]\d[A-Z]\s?\d[A-Z]\d)/);
        const provMatch = secondLine.match(/\b(AB|BC|MB|NB|NL|NS|NT|NU|ON|PE|QC|SK|YT)\b/);
        setFirmPostalCode(pcMatch ? pcMatch[1] : "");
        setFirmProvince(provMatch ? provMatch[1] : "");
        // City is everything before the province
        const cityPart = secondLine.replace(/\s*(AB|BC|MB|NB|NL|NS|NT|NU|ON|PE|QC|SK|YT)\s+[A-Z]\d[A-Z]\s?\d[A-Z]\d.*$/, "").trim();
        setFirmCity(cityPart);
      } else {
        // Legacy single-line format: try to parse
        setFirmAddress(addr);
        const pcMatch = addr.match(/([A-Z]\d[A-Z]\s?\d[A-Z]\d)/);
        const provMatch = addr.match(/\b(AB|BC|MB|NB|NL|NS|NT|NU|ON|PE|QC|SK|YT)\b/);
        setFirmPostalCode(pcMatch ? pcMatch[1] : "");
        setFirmProvince(provMatch ? provMatch[1] : "");
        const cityMatch = addr.match(/,\s*([^,]+?)\s+(?:AB|BC|MB|NB|NL|NS|NT|NU|ON|PE|QC|SK|YT)\b/);
        setFirmCity(cityMatch ? cityMatch[1].trim() : "");
        // Strip city/province/postal from the street field for legacy addresses
        if (cityMatch) {
          setFirmAddress(addr.substring(0, addr.indexOf(cityMatch[0])).replace(/,\s*$/, ""));
        }
      }
      // P15PLUS-012: the structured firmCity column (migration 0098) wins over
      // the address parse — it feeds the affidavit jurat oath-city fallback.
      if ((settings as any).firmCity) {
        setFirmCity((settings as any).firmCity);
      }
      setFirmPhone(settings.firmPhone || "");
      setFirmFax(settings.firmFax || "");
      setShowFirmFax((settings as any).showFirmFax !== false);
      setFirmEmail(settings.firmEmail || "");
      // F1: keep state "" until the user actually edits — the textarea shows the
      // shared default via its display fallback (value={letterBodyTemplate ||
      // DEFAULT_LETTER_TEMPLATE}), and docgen falls back to the SAME shared
      // default, so displayed == printed WITHOUT persisting the default text into
      // every row (which would pin users against future default updates).
      setLetterBodyTemplate(resolveLetterTemplate(settings.letterBodyTemplate));
      setLetterClosing((settings as any).letterClosing || "Yours truly,");
      setLetterShowPerLine((settings as any).letterShowPerLine !== false);
      initializedRef.current = true;
    }
  }, [settings]);

  // localStorage auto-save: persist settings form data to prevent loss on page refresh
  const settingsFormData = { lawyerName, firmName, firmAddress, firmCity, firmProvince, firmPostalCode, firmPhone, firmFax, showFirmFax, firmEmail, letterBodyTemplate, letterClosing, letterShowPerLine };
  const { pendingDraft: pendingSettingsDraft, pendingDraftTime: pendingSettingsDraftTime, acceptDraft: acceptSettingsDraft, dismissDraft: dismissSettingsDraft, clearDraft: clearSettingsDraft } = useLocalDraft({
    key: "settings_firm",
    data: settingsFormData,
    isDirty: isDirtyRef.current || saveStatus === 'unsaved',
  });

  const updateMutation = trpc.settings.update.useMutation({
    onSuccess: () => {
      clearSettingsDraft(); // Clear localStorage draft after successful server save
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
      saveTimeoutRef.current = setTimeout(() => {
        isDirtyRef.current = false;
        utils.settings.get.invalidate();
      }, 2000);
    },
  });

  const settleSectionSave = (setStatus: React.Dispatch<React.SetStateAction<SectionSaveState>>, message: string) => {
    toast.success(message);
    setStatus("saved");
    window.setTimeout(() => setStatus("idle"), 3000);
  };

  const failSectionSave = (setStatus: React.Dispatch<React.SetStateAction<SectionSaveState>>, err: { message: string }) => {
    toast.error(err.message);
    setStatus("error");
  };

  const uploadLetterheadMutation = trpc.settings.uploadLetterhead.useMutation({
    onSuccess: () => {
      utils.settings.get.invalidate();
      settleSectionSave(setLetterheadSaveStatus, "Letterhead image uploaded");
      setUploading(false);
      setImageUploadFeedback({ phase: "complete", progress: 100, message: "Letterhead image uploaded" });
      window.setTimeout(() => setImageUploadFeedback(IDLE_UPLOAD_FEEDBACK), 2200);
    },
    onError: (err) => {
      failSectionSave(setLetterheadSaveStatus, err);
      setUploading(false);
      setImageUploadFeedback({ phase: "error", progress: 0, message: err.message || "Unable to upload the letterhead image. Please try again." });
    },
  });

  const deleteLetterheadMutation = trpc.settings.deleteLetterhead.useMutation({
    onSuccess: () => {
      utils.settings.get.invalidate();
      settleSectionSave(setLetterheadSaveStatus, "Letterhead removed");
    },
    onError: (err) => failSectionSave(setLetterheadSaveStatus, err),
  });

  const uploadDocxMutation = trpc.settings.uploadLetterheadDocx.useMutation({
    onSuccess: () => {
      utils.settings.get.invalidate();
      settleSectionSave(setLetterheadSaveStatus, "DOCX letterhead template uploaded");
      setUploadingDocx(false);
      setDocxUploadFeedback({ phase: "complete", progress: 100, message: "DOCX letterhead template uploaded" });
      window.setTimeout(() => setDocxUploadFeedback(IDLE_UPLOAD_FEEDBACK), 2200);
    },
    onError: (err) => {
      failSectionSave(setLetterheadSaveStatus, err);
      setUploadingDocx(false);
      setDocxUploadFeedback({ phase: "error", progress: 0, message: err.message || "Unable to upload the DOCX template. Please try again." });
    },
  });

  const deleteDocxMutation = trpc.settings.deleteLetterheadDocx.useMutation({
    onSuccess: () => {
      utils.settings.get.invalidate();
      settleSectionSave(setLetterheadSaveStatus, "DOCX template removed");
    },
    onError: (err) => failSectionSave(setLetterheadSaveStatus, err),
  });

  const handleDocxUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.name.toLowerCase().endsWith(".docx")) {
      const message = invalidFileTypeMessage(file.name, "a .docx file");
      setDocxUploadFeedback({ phase: "error", progress: 0, message });
      toast.error(message);
      e.target.value = "";
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      const message = fileTooLargeMessage("10 MB");
      setDocxUploadFeedback({ phase: "error", progress: 0, message });
      toast.error(message);
      e.target.value = "";
      return;
    }
    setUploadingDocx(true);
    setLetterheadSaveStatus("saving");
    setDocxUploadFeedback({ phase: "reading", progress: 28, message: `Preparing ${file.name}` });
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(",")[1];
      setDocxUploadFeedback({ phase: "uploading", progress: 72, message: `Securely uploading ${file.name}` });
      uploadDocxMutation.mutate({ fileBase64: base64, fileName: file.name });
    };
    reader.onerror = () => {
      const message = `Unable to read ${file.name}. Please select the file again.`;
      toast.error(message);
      setLetterheadSaveStatus("error");
      setUploadingDocx(false);
      setDocxUploadFeedback({ phase: "error", progress: 0, message });
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!["image/png", "image/jpeg"].includes(file.type)) {
      const message = invalidFileTypeMessage(file.name, "a PNG or JPG image");
      setImageUploadFeedback({ phase: "error", progress: 0, message });
      toast.error(message);
      e.target.value = "";
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      const message = fileTooLargeMessage("5 MB");
      setImageUploadFeedback({ phase: "error", progress: 0, message });
      toast.error(message);
      e.target.value = "";
      return;
    }

    setUploading(true);
    setLetterheadSaveStatus("saving");
    setImageUploadFeedback({ phase: "reading", progress: 28, message: `Preparing ${file.name}` });
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(",")[1];
      // Get image dimensions
      const img = new window.Image();
      img.onload = () => {
        setImageUploadFeedback({ phase: "uploading", progress: 72, message: `Securely uploading ${file.name}` });
        uploadLetterheadMutation.mutate({
          fileBase64: base64,
          fileName: file.name,
          mimeType: file.type,
          width: img.naturalWidth,
          height: img.naturalHeight,
        });
      };
      img.onerror = () => {
        const message = `Unable to read ${file.name} as an image. Choose a valid PNG or JPG file.`;
        toast.error(message);
        setLetterheadSaveStatus("error");
        setUploading(false);
        setImageUploadFeedback({ phase: "error", progress: 0, message });
      };
      img.src = reader.result as string;
    };
    reader.onerror = () => {
      const message = `Unable to read ${file.name}. Please select the file again.`;
      toast.error(message);
      setLetterheadSaveStatus("error");
      setUploading(false);
      setImageUploadFeedback({ phase: "error", progress: 0, message });
    };
    reader.readAsDataURL(file);
    // Reset input so the same file can be re-selected
    e.target.value = "";
  };

  if (isLoading) return (
    <Card>
      <CardHeader className="pb-3">
        <div className="h-4 w-24 bg-muted animate-pulse rounded" />
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="h-3 w-48 bg-muted animate-pulse rounded" />
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="h-9 bg-muted animate-pulse rounded" />
          <div className="h-9 bg-muted animate-pulse rounded" />
          <div className="h-9 bg-muted animate-pulse rounded" />
          <div className="h-14 bg-muted animate-pulse rounded" />
        </div>
      </CardContent>
    </Card>
  );

  const hasUploadedLetterhead = !!settings?.letterheadStorageUrl;
  const hasDocxTemplate = !!(settings as any)?.letterheadDocxName;

  const restoreSettingsDraft = () => {
    const draft = acceptSettingsDraft();
    if (draft) {
      setLawyerName(draft.lawyerName || "");
      setFirmName(draft.firmName || "");
      setFirmAddress(draft.firmAddress || "");
      setFirmCity(draft.firmCity || "");
      setFirmProvince(draft.firmProvince || "");
      setFirmPostalCode(draft.firmPostalCode || "");
      setFirmPhone(draft.firmPhone || "");
      setFirmFax(draft.firmFax || "");
      setShowFirmFax(draft.showFirmFax !== false);
      setFirmEmail(draft.firmEmail || "");
      setLetterBodyTemplate(resolveLetterTemplate(draft.letterBodyTemplate));
      setLetterClosing(draft.letterClosing || "Yours truly,");
      setLetterShowPerLine(draft.letterShowPerLine !== false);
      markDirty();
      toast.success("Draft restored");
    }
  };

  const personalExecutor = settings?.accountPurpose === "personal_executor";

  return (
    <>
    {/* ── Draft recovery banner ── */}
    {pendingSettingsDraft && (
      <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
        <History className="h-4 w-4 text-amber-600" />
        <AlertDescription className="flex items-center justify-between">
          <span className="text-sm">
            Unsaved settings draft found from {pendingSettingsDraftTime ? `${fmtDisplayDate(pendingSettingsDraftTime)} ${new Date(pendingSettingsDraftTime).toLocaleTimeString()}` : "earlier"}.
          </span>
          <span className="flex gap-2 ml-4 shrink-0">
            <Button size="sm" variant="outline" className="h-7 text-xs" onClick={dismissSettingsDraft}>Discard</Button>
            <Button size="sm" className="h-7 text-xs" onClick={restoreSettingsDraft}>Restore Draft</Button>
          </span>
        </AlertDescription>
      </Alert>
    )}
    <Card id={personalExecutor ? "letter-settings" : "firm-details"} className="scroll-mt-6">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Image className="h-4 w-4 text-muted-foreground" />
          <CardTitle className="text-sm">{personalExecutor ? "Letter settings" : "Firm Letterhead"}</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <SectionSaveFeedback state={letterheadSaveStatus} />
        {/* DOCX Template Upload (preferred) */}
        <div className="space-y-2">
          <p className="text-xs font-medium">DOCX Letterhead Template (Recommended)</p>
          <p className="text-xs text-muted-foreground">
            Upload your .docx letterhead template. Generated letters will inject content into this template, preserving headers, footers, logos, and formatting exactly as designed.
          </p>
          {hasDocxTemplate && (
            <div className="border rounded-md p-3 bg-muted/30">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <PenLine className="h-4 w-4 text-primary" />
                  <span className="text-xs font-medium">{(settings as any).letterheadDocxName}</span>
                  <Badge variant="secondary" className="text-[9px]">Active</Badge>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 px-2 text-xs text-destructive hover:text-destructive"
                  onClick={() => deleteDocxMutation.mutate()}
                  disabled={deleteDocxMutation.isPending}
                >
                  <X className="h-3 w-3 mr-1" />
                  Remove
                </Button>
              </div>
              <label className="mt-3 flex cursor-pointer items-start gap-2 border-t pt-3">
                <input
                  type="checkbox"
                  aria-label="Hide address, phone, and email in beneficiary-letter signing blocks"
                  checked={!!(settings as any)?.hideBeneficiaryLetterSigningContact}
                  onChange={(event) => {
                    setLetterheadSaveStatus("saving");
                    updateMutation.mutate({ hideBeneficiaryLetterSigningContact: event.target.checked }, {
                      onSuccess: () => settleSectionSave(setLetterheadSaveStatus, "Letter signing preference saved"),
                      onError: (err) => failSectionSave(setLetterheadSaveStatus, err),
                    });
                  }}
                  className="mt-0.5 h-3.5 w-3.5 shrink-0 rounded border-input accent-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                />
                <span className="min-w-0">
                  <span className="block text-xs font-medium">Hide address, phone, and email in beneficiary-letter signing blocks</span>
                  <span className="mt-0.5 block text-[10px] leading-relaxed text-muted-foreground">Use this when those details are already on your uploaded letterhead. The closing and signature remain visible.</span>
                </span>
              </label>
            </div>
          )}
          <div>
            <input
              ref={docxInputRef}
              type="file"
              accept=".docx"
              className="hidden"
              onChange={handleDocxUpload}
            />
            <Button
              size="sm"
              variant={hasDocxTemplate ? "outline" : "default"}
              onClick={() => docxInputRef.current?.click()}
              disabled={uploadingDocx}
            >
              <Upload className="h-3.5 w-3.5 mr-1" />
              {uploadingDocx ? "Uploading..." : hasDocxTemplate ? "Replace Template" : "Upload DOCX Template"}
            </Button>
            <UploadFeedback state={docxUploadFeedback} compact className="mt-2 max-w-md" />
            <p className="text-[10px] text-muted-foreground mt-1">.docx file, max 10MB. Headers, footers, and page setup will be preserved.</p>
          </div>
        </div>

        {/* Divider */}
        {!hasDocxTemplate && (
          <div className="border-t pt-4">
            <p className="text-xs font-medium mb-1">Alternative: Letterhead Image</p>
            <p className="text-xs text-muted-foreground">
              Upload a letterhead image instead. Generated letters will place the letter content below your letterhead image.
            </p>
          </div>
        )}

        {/* Uploaded letterhead preview (only shown when no DOCX template) */}
        {!hasDocxTemplate && hasUploadedLetterhead && (
          <div className="border rounded-md p-3 bg-white">
            <div className="flex items-center justify-between mb-2">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Current Letterhead</p>
              <Button
                size="sm"
                variant="ghost"
                className="h-6 px-2 text-xs text-destructive hover:text-destructive"
                onClick={() => deleteLetterheadMutation.mutate()}
                disabled={deleteLetterheadMutation.isPending}
              >
                <X className="h-3 w-3 mr-1" />
                Remove
              </Button>
            </div>
            <img
              src={settings.letterheadStorageUrl}
              alt="Firm letterhead"
              className="max-w-full h-auto border rounded"
              style={{ maxHeight: 200 }}
            />
            <p className="text-[10px] text-muted-foreground mt-1">{settings.letterheadName}</p>
          </div>
        )}

        {/* Upload image button (only shown when no DOCX template) */}
        {!hasDocxTemplate && (
        <div>
          <input
            ref={fileInputRef}
            type="file"
            accept=".png,.jpg,.jpeg,image/png,image/jpeg"
            className="hidden"
            onChange={handleFileUpload}
          />
          <Button
            size="sm"
            variant={hasUploadedLetterhead ? "outline" : "default"}
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
          >
            <Upload className="h-3.5 w-3.5 mr-1" />
            {uploading ? "Uploading..." : hasUploadedLetterhead ? "Replace Letterhead" : "Upload Letterhead Image"}
          </Button>
          <UploadFeedback state={imageUploadFeedback} compact className="mt-2 max-w-md" />
          <p className="text-[10px] text-muted-foreground mt-1">PNG or JPG, max 5MB. This image will appear at the top of generated letters.</p>
        </div>
        )}

        {/* Suppress sender text toggle (shown when ANY letterhead — image OR DOCX template — is uploaded) */}
        {(hasDocxTemplate || hasUploadedLetterhead) && (
          <div className="border rounded-md p-3 bg-muted/20">
            <div className="flex items-center justify-between gap-4">
              <div className="space-y-0.5">
                <div className="flex items-center gap-1.5">
                  <Label className="text-xs font-medium">Hide sender information in letters</Label>
                  <TooltipProvider delayDuration={200}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <HelpCircle className="h-3.5 w-3.5 text-muted-foreground cursor-help" />
                      </TooltipTrigger>
                      <TooltipContent side="top" className="max-w-xs text-xs leading-relaxed">
                        <p className="font-medium mb-1">The following will be removed from letters:</p>
                        <ul className="list-disc pl-3.5 space-y-0.5">
                          <li>Sender or firm name</li>
                          <li>Street address</li>
                          <li>City, province, and postal code</li>
                          <li>Phone and fax numbers</li>
                          <li>Email address</li>
                        </ul>
                        <p className="mt-1.5 text-muted-foreground">The closing and signature block are always kept.</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <p className="text-[10px] text-muted-foreground leading-relaxed">
                  When enabled, sender name, address, and contact details will not appear as text in generated letters. Your closing and signature block remain visible.
                </p>
              </div>
              <Switch
                aria-label="Hide sender information in letters"
                checked={!!settings?.suppressFirmText}
                onCheckedChange={(checked) => {
                  setLetterheadSaveStatus("saving");
                  updateMutation.mutate({ suppressFirmText: checked }, {
                    onSuccess: () => settleSectionSave(setLetterheadSaveStatus, "Letter preferences saved"),
                    onError: (err) => failSectionSave(setLetterheadSaveStatus, err),
                  });
                }}
              />
            </div>
          </div>
        )}

        {!personalExecutor && (
          <div className="border-t pt-4">
            <p className="text-xs text-muted-foreground mb-3">
              Lawyer and firm details used for P2 contact information, address for service, and text-based letterhead.
            </p>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label className="text-xs">Lawyer Name</Label>
                  <Input value={lawyerName} onChange={(e) => { markDirty(); setLawyerName(e.target.value); }} placeholder="e.g. Jane Smith" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Firm Name</Label>
                  <Input value={firmName} onChange={(e) => { markDirty(); setFirmName(e.target.value); }} placeholder="e.g. Smith & Associates" />
                </div>
                <div className="space-y-1.5 sm:col-span-2">
                  <Label className="text-xs">Street Address</Label>
                  <AddressAutocomplete
                    value={firmAddress}
                    onChange={(v) => { markDirty(); setFirmAddress(v); }}
                    onSelect={(components) => {
                      const street = components.unit ? `${components.unit}-${components.street}` : components.street;
                      setFirmAddress(street);
                      setFirmCity(components.city || "");
                      setFirmProvince(components.province || "");
                      setFirmPostalCode(components.postalCode || "");
                      markDirty();
                    }}
                    placeholder="Start typing firm address..."
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">City</Label>
                  <Input value={firmCity} onChange={(e) => { markDirty(); setFirmCity(e.target.value); }} placeholder="Vancouver" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Province <span className="text-destructive">*</span></Label>
                  <Select value={firmProvince || ""} onValueChange={(v) => { markDirty(); setFirmProvince(v); }}>
                    <SelectTrigger className="h-9" aria-invalid={!firmProvince && firmCity ? true : undefined}><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      {["AB","BC","MB","NB","NL","NS","NT","NU","ON","PE","QC","SK","YT"].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  {!firmProvince && firmCity && (
                    <p className="text-[11px] text-destructive flex items-center gap-1" role="alert">
                      <CircleAlert className="h-3 w-3 shrink-0" /> Province is required
                    </p>
                  )}
                  {firmProvince && (
                    <p className="text-[11px] text-green-700 dark:text-green-400 flex items-center gap-1">
                      <CircleCheck className="h-3 w-3 shrink-0" /> {firmProvince}
                    </p>
                  )}
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Postal Code <span className="text-destructive">*</span></Label>
                  <Input
                    value={firmPostalCode}
                    onChange={(e) => {
                      let val = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "");
                      if (val.length > 3) val = val.slice(0, 3) + " " + val.slice(3);
                      if (val.length > 7) val = val.slice(0, 7);
                      markDirty();
                      setFirmPostalCode(val);
                    }}
                    aria-invalid={firmPostalCode && !/^[A-Z]\d[A-Z]\s?\d[A-Z]\d$/.test(firmPostalCode) ? true : undefined}
                    placeholder="V6B 1A1"
                    maxLength={7}
                  />
                  {firmPostalCode && !/^[A-Z]\d[A-Z]\s?\d[A-Z]\d$/.test(firmPostalCode) && (
                    <p className="text-[11px] text-destructive flex items-center gap-1" role="alert">
                      <CircleAlert className="h-3 w-3 shrink-0" /> Invalid format — expected A1A 1A1 (e.g. V6B 1A1)
                    </p>
                  )}
                  {firmPostalCode && /^[A-Z]\d[A-Z]\s?\d[A-Z]\d$/.test(firmPostalCode) && (
                    <p className="text-[11px] text-green-700 dark:text-green-400 flex items-center gap-1">
                      <CircleCheck className="h-3 w-3 shrink-0" /> Valid postal code
                    </p>
                  )}
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Phone</Label>
                  <Input value={firmPhone} onChange={(e) => { markDirty(); setFirmPhone(formatPhone(e.target.value)); }} placeholder="604-555-1234" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Fax</Label>
                  <div className="flex items-center gap-3">
                    <Input className="min-w-0 flex-1" value={firmFax} onChange={(e) => { markDirty(); setFirmFax(formatPhone(e.target.value)); }} placeholder="604-555-1235 (optional)" />
                    <label className="inline-flex shrink-0 cursor-pointer items-center gap-2 whitespace-nowrap text-xs text-muted-foreground">
                      <input
                        type="checkbox"
                        className="size-4 accent-primary"
                        checked={showFirmFax}
                        onChange={(event) => { markDirty(); setShowFirmFax(event.target.checked); }}
                        aria-label="Include firm fax in documents"
                      />
                      Include in documents
                    </label>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Email</Label>
                  <Input value={firmEmail} onChange={(e) => { markDirty(); setFirmEmail(e.target.value); }} placeholder="info@firm.ca" />
                </div>
              </div>
            <div className="flex items-center gap-3 mt-4">
              <Button
                size="sm"
                onClick={() => {
                  // Compose firmAddress from parts for storage; firmCity also
                  // persists structurally (P15PLUS-012 — the jurat oath-city fallback).
                  const composedAddress = [firmAddress, [firmCity, firmProvince, firmPostalCode].filter(Boolean).join(" ")].filter(Boolean).join("\n");
                  setSaveStatus('saving');
                  updateMutation.mutate({ lawyerName, firmName, firmAddress: composedAddress, firmCity, firmPhone, firmFax, showFirmFax, firmEmail }, {
                    onSuccess: () => {
                      toast.success("Firm details saved");
                      setSaveStatus('saved');
                      if (savedTimerRef.current) clearTimeout(savedTimerRef.current);
                      savedTimerRef.current = setTimeout(() => setSaveStatus('idle'), 3000);
                    },
                    onError: (err) => {
                      toast.error(err.message);
                      setSaveStatus('unsaved');
                    },
                  });
                }}
                disabled={updateMutation.isPending}
              >
                <Save className="h-3.5 w-3.5 mr-1" />
                {updateMutation.isPending ? "Saving..." : "Save Firm Details"}
              </Button>
              <AnimatePresence mode="wait">
                {saveStatus === 'saving' && (
                  <motion.span key="saving" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-xs text-muted-foreground flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-amber-500 animate-pulse" /> Saving…
                  </motion.span>
                )}
                {saveStatus === 'saved' && (
                  <motion.span key="saved" initial={{ opacity: 0, x: -4 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }} className="text-xs text-green-700 dark:text-green-400 flex items-center gap-1">
                    <CheckCircle2 className="h-3.5 w-3.5" /> Saved
                  </motion.span>
                )}
                {saveStatus === 'unsaved' && (
                  <motion.span key="unsaved" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-xs text-muted-foreground/70 flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground/40" /> Unsaved changes
                  </motion.span>
                )}
              </AnimatePresence>
            </div>
          </div>
        )}
      </CardContent>
    </Card>

    <Card id="letter-template" className="scroll-mt-6">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Building2 className="h-4 w-4 text-muted-foreground" />
          <CardTitle className="text-sm">Letter Body Template</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-xs text-muted-foreground">
          Customize the body text used in generated letters to Rule 25-2 recipients. Use recipient-neutral wording unless every intended recipient is recorded as a beneficiary. ProbatePro supplies the address, salutation, subject line, and closing.
        </p>
        <div className="flex flex-wrap gap-1.5 mb-2">
          {LETTER_PLACEHOLDERS.map(p => (
            <Badge key={p} variant="secondary" className="text-[10px] font-mono cursor-pointer" onClick={() => {
              navigator.clipboard.writeText(p).then(
                () => toast.success(`Copied ${p}`),
                () => toast.error(`Could not copy — select ${p} in the template and copy it manually`)
              );
            }}>{p}</Badge>
          ))}
        </div>
        <Textarea
          value={letterBodyTemplate || DEFAULT_LETTER_TEMPLATE}
          onChange={(e) => { markDirty(); setLetterBodyTemplate(e.target.value); }}
          rows={14}
          className="font-mono text-xs leading-relaxed"
          placeholder="Enter your custom letter body..."
        />
        <div className="flex flex-wrap items-center gap-2">
          <Button
            size="sm"
            onClick={() => {
              const issues = letterTemplateContractIssues(letterBodyTemplate || DEFAULT_LETTER_TEMPLATE);
              if (issues.length > 0) {
                toast.error(`Remove the ${issues.join(" and ")} from the body template.`);
                return;
              }
              setTemplateSaveStatus("saving");
              updateMutation.mutate({ letterBodyTemplate: letterBodyTemplate || DEFAULT_LETTER_TEMPLATE }, {
                onSuccess: () => settleSectionSave(setTemplateSaveStatus, "Letter template saved"),
                onError: (err) => failSectionSave(setTemplateSaveStatus, err),
              });
            }}
            disabled={updateMutation.isPending}
          >
            <Save className="h-3.5 w-3.5 mr-1" />
            {updateMutation.isPending ? "Saving..." : "Save Template"}
          </Button>
          <SectionSaveFeedback state={templateSaveStatus} />
          <Button
            size="sm"
            variant="outline"
            onClick={() => { markDirty(); setLetterBodyTemplate(DEFAULT_LETTER_TEMPLATE); toast.info("Template reset — click Save Template to apply"); }}
          >
            Reset to Default
          </Button>
        </div>
      </CardContent>
    </Card>

    <Card id="letter-closing" className="scroll-mt-6">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <PenLine className="h-4 w-4 text-muted-foreground" />
          <CardTitle className="text-sm">Letter Closing Block</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-xs text-muted-foreground">
          Customize the closing line and signature style used at the end of generated letters.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-xs">Closing Text</Label>
            <Input
              value={letterClosing}
              onChange={(e) => { markDirty(); setLetterClosing(e.target.value); }}
              placeholder="e.g. Yours truly,"
              className="h-9"
            />
            <div className="flex flex-wrap gap-1">
              {["Yours truly,", "Yours sincerely,", "Yours faithfully,", "Respectfully,", "Kind regards,"].map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => setLetterClosing(suggestion)}
                  className={`text-[10px] px-1.5 py-0.5 rounded border transition-colors ${letterClosing === suggestion ? "bg-primary/10 border-primary/30 text-primary" : "bg-muted/50 border-transparent text-muted-foreground hover:border-border"}`}
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Show &quot;Per:&quot; line</Label>
            <div className="flex items-center gap-2 h-9">
              <Switch checked={letterShowPerLine} onCheckedChange={setLetterShowPerLine} />
              <span className="text-xs text-muted-foreground">{letterShowPerLine ? "Shown" : "Hidden"}</span>
            </div>
          </div>
        </div>
        <div className="rounded-md border p-3 bg-muted/30">
          <p className="text-xs text-muted-foreground mb-1">Preview:</p>
          <p className="text-sm">{letterClosing}</p>
          <p className="text-sm font-semibold mt-2">{firmName || (personalExecutor ? "[Sender name]" : "[Firm Name]")}</p>
          {letterShowPerLine && lawyerName && <p className="text-sm">Per: {lawyerName}</p>}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            size="sm"
            onClick={() => {
              setClosingSaveStatus("saving");
              updateMutation.mutate({ letterClosing, letterShowPerLine }, {
                onSuccess: () => settleSectionSave(setClosingSaveStatus, "Closing block saved"),
                onError: (err) => failSectionSave(setClosingSaveStatus, err),
              });
            }}
            disabled={updateMutation.isPending}
          >
            <Save className="h-3.5 w-3.5 mr-1" />
            {updateMutation.isPending ? "Saving..." : "Save Closing"}
          </Button>
          <SectionSaveFeedback state={closingSaveStatus} />
        </div>
      </CardContent>
    </Card>
    </>
  );
}

function CheckboxPreviewSection() {
  const { data: settings, isLoading } = trpc.settings.get.useQuery();
  const utils = trpc.useUtils();
  const [size, setSize] = useState(0); // 0 = default (SZ=22 half-points = 11pt)
  const [bold, setBold] = useState(1); // 1 = bold, 0 = normal
  const [textOnly, setTextOnly] = useState(false);
  const [initialized, setInitialized] = useState(false);
  const [saveStatus, setSaveStatus] = useState<SectionSaveState>("idle");

  useEffect(() => {
    if (settings && !initialized) {
      setSize((settings as any).checkboxSize || 0);
      setBold((settings as any).checkboxBold ?? 1);
      setTextOnly((settings as any).checkboxTextOnly === true || (settings as any).checkboxTextOnly === 1);
      setInitialized(true);
    }
  }, [settings, initialized]);

  const updateMutation = trpc.settings.update.useMutation({
    onMutate: () => setSaveStatus("saving"),
    onSuccess: () => {
      toast.success("Checkbox preferences saved");
      setSaveStatus("saved");
      window.setTimeout(() => setSaveStatus("idle"), 3000);
      utils.settings.get.invalidate();
    },
    onError: (err) => {
      toast.error(err.message);
      setSaveStatus("error");
    },
  });

  // Compute display values
  const effectiveSize = size || 22; // default 22 half-points = 11pt
  const ptSize = effectiveSize / 2;
  const pxSize = Math.round(ptSize * 1.333); // approximate px for preview

  if (isLoading) return (
    <Card>
      <CardHeader className="pb-3"><div className="h-4 w-24 bg-muted animate-pulse rounded" /></CardHeader>
      <CardContent><div className="h-20 bg-muted animate-pulse rounded" /></CardContent>
    </Card>
  );

  return (
    <Card id="checkbox-appearance" className="scroll-mt-6">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <CheckSquare className="h-4 w-4 text-muted-foreground" />
          <CardTitle className="text-sm">Checkbox Appearance</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-5">
        <p className="text-xs text-muted-foreground">
          Customize how checkboxes appear in generated DOCX court forms. Changes apply to all forms.
        </p>

        {/* Size control */}
        <div className="space-y-2">
          <Label className="text-xs">Size ({ptSize}pt)</Label>
          <div className="flex items-center gap-4">
            <input
              type="range"
              min={16}
              max={36}
              step={2}
              value={effectiveSize}
              onChange={(e) => setSize(Number(e.target.value))}
              className="flex-1 h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
            />
            <span className="text-xs text-muted-foreground w-12 text-right">{ptSize}pt</span>
          </div>
          <div className="flex gap-1">
            {[{label: "Small (9pt)", val: 18}, {label: "Default (11pt)", val: 22}, {label: "Medium (12pt)", val: 24}, {label: "Large (14pt)", val: 28}].map(opt => (
              <button
                key={opt.val}
                type="button"
                onClick={() => setSize(opt.val)}
                className={`text-[10px] px-1.5 py-0.5 rounded border transition-colors ${
                  effectiveSize === opt.val
                    ? "bg-primary/10 border-primary/30 text-primary"
                    : "bg-muted/50 border-transparent text-muted-foreground hover:border-border"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Bold control */}
        <div className="space-y-1.5">
          <Label className="text-xs">Border Thickness</Label>
          <div className="flex items-center gap-2">
            <Switch checked={bold === 1} onCheckedChange={(v) => setBold(v ? 1 : 0)} />
            <span className="text-xs text-muted-foreground">{bold ? "Bold (thicker borders)" : "Normal (thinner borders)"}</span>
          </div>
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs">Relevant text only</Label>
          <div className="flex items-center gap-2">
            <Switch checked={textOnly} onCheckedChange={setTextOnly} aria-label="Show relevant text only" />
            <span className="text-xs text-muted-foreground">Hide checkbox markers and retain only the applicable wording in generated documents and previews.</span>
          </div>
        </div>

        {/* Live preview */}
        <div className="rounded-md border p-4 bg-muted/30 space-y-3">
          <p className="text-xs text-muted-foreground mb-2">Preview:</p>
          <div className="font-serif space-y-2">
            <div className="flex items-start gap-2">
              {!textOnly && <span style={{ fontSize: `${pxSize}px`, fontWeight: bold ? 700 : 400, lineHeight: 1 }}>☒</span>}
              <span className="text-sm" style={{ fontFamily: 'Times New Roman, serif' }}>There is one applicant to this submission for estate grant and a P4 affidavit is filed with this submission for estate grant.</span>
            </div>
            {!textOnly && <div className="flex items-start gap-2">
              <span style={{ fontSize: `${pxSize}px`, fontWeight: bold ? 700 : 400, lineHeight: 1 }}>☐</span>
              <span className="text-sm" style={{ fontFamily: 'Times New Roman, serif' }}>There is no real property or tangible personal property outside of British Columbia.</span>
            </div>}
            <div className="flex items-start gap-2">
              {!textOnly && <span style={{ fontSize: `${pxSize}px`, fontWeight: bold ? 700 : 400, lineHeight: 1 }}>☒</span>}
              <span className="text-sm" style={{ fontFamily: 'Times New Roman, serif' }}>I am named as an executor in the will.</span>
            </div>
          </div>
        </div>

        {/* Save + Reset */}
        <div className="flex flex-wrap items-center gap-2">
          <Button
            size="sm"
            onClick={() => updateMutation.mutate({ checkboxSize: size, checkboxBold: bold, checkboxTextOnly: textOnly })}
            disabled={updateMutation.isPending}
          >
            <Save className="h-3.5 w-3.5 mr-1" />
            {updateMutation.isPending ? "Saving..." : "Save Checkbox Preferences"}
          </Button>
          <SectionSaveFeedback state={saveStatus} />
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              setSize(0);
              setBold(1);
              setTextOnly(false);
              updateMutation.mutate({ checkboxSize: 0, checkboxBold: 1, checkboxTextOnly: false }, {
                onSuccess: () => {
                  toast.success("Checkbox settings reset to default");
                  utils.settings.get.invalidate();
                },
              });
            }}
            disabled={updateMutation.isPending || (size === 0 && bold === 1 && !textOnly)}
          >
            Reset to Default
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export function PortalAccessSection({ estateId }: { estateId?: string } = {}) {
  const { data: estates } = trpc.estate.list.useQuery();
  const { data: accesses, isLoading, error: accessError } = trpc.portalAccess.listAll.useQuery(estateId ? { estateId } : undefined);
  const utils = trpc.useUtils();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedEstate, setSelectedEstate] = useState(estateId || "");
  const [clientName, setClientName] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [accessSearch, setAccessSearch] = useState("");
  const [accessStatusFilter, setAccessStatusFilter] = useState<"all" | "active" | "revoked" | "expired" | "redeemed">("all");
  const [issuedLink, setIssuedLink] = useState("");

  const copyPortalLink = async (url: string, successMessage: string) => {
    try {
      if (!navigator.clipboard?.writeText) throw new Error("Clipboard unavailable");
      await navigator.clipboard.writeText(url);
      toast.success(successMessage);
    } catch {
      toast.error("The link is ready below. Copy it manually before leaving this page.");
    }
  };

  const presentIssuedLink = (accessToken: string, successMessage: string) => {
    const url = `${window.location.origin}/portal?t=${accessToken}`;
    setIssuedLink(url);
    void copyPortalLink(url, successMessage);
  };

  const createMutation = trpc.portalAccess.create.useMutation({
    onSuccess: (data) => {
      utils.portalAccess.listAll.invalidate();
      setDialogOpen(false);
      setSelectedEstate(estateId || "");
      setClientName("");
      setClientEmail("");
      presentIssuedLink(data.accessToken, "Client-intake link created and copied");
    },
  });
  const revokeMutation = trpc.portalAccess.revoke.useMutation({
    onSuccess: () => { utils.portalAccess.listAll.invalidate(); toast.success("Access revoked"); },
  });
  const extendMutation = trpc.portalAccess.extend.useMutation({
    onSuccess: () => { utils.portalAccess.listAll.invalidate(); toast.success("Access extended by 90 days"); },
  });
  const reissueMutation = trpc.portalAccess.reissue.useMutation({
    onSuccess: () => { utils.portalAccess.listAll.invalidate(); },
  });

  const reissueLink = (access: any, action: "replace" | "email") => {
    reissueMutation.mutate({ id: access.id, estateId: access.estateId }, {
      onSuccess: (data) => {
        const url = `${window.location.origin}/portal?t=${data.accessToken}`;
        if (action === "replace") {
          setIssuedLink(url);
          void copyPortalLink(url, "Replacement client-intake link copied");
          return;
        }
        setIssuedLink(url);
        const subject = encodeURIComponent("Estate Intake Link");
        const body = encodeURIComponent(`Hello ${access.contactName || ""},\n\nYou have been invited to share information with the legal team for this estate.\n\nPlease use the following one-time secure link to complete the client-intake questions:\n${url}\n\nYour submitted answers will be reviewed before any selected facts are applied to the estate record. This link will expire on ${fmtDisplayDate(data.expiresAt)}. Once exchanged, use the same browser session to continue.\n\nRegards`);
        window.location.href = `mailto:${access.email}?subject=${subject}&body=${body}`;
        void copyPortalLink(url, "Replacement client-intake link copied");
        toast.success("Replacement link created; email draft opened");
      },
    });
  };

  const getExpiryStatus = (expiresAt: number | null | undefined) => {
    if (!expiresAt) return { label: "No expiry (legacy)", variant: "outline" as const, color: "" };
    const now = Date.now();
    if (expiresAt < now) return { label: "Expired", variant: "destructive" as const, color: "text-destructive" };
    const daysLeft = Math.ceil((expiresAt - now) / (1000 * 60 * 60 * 24));
    if (daysLeft <= 7) return { label: `${daysLeft}d left`, variant: "destructive" as const, color: "text-destructive" };
    if (daysLeft <= 30) return { label: `${daysLeft}d left`, variant: "secondary" as const, color: "text-amber-700 dark:text-amber-300" };
    return { label: `${daysLeft}d left`, variant: "outline" as const, color: "text-emerald-700 dark:text-emerald-300" };
  };

  // Map estate IDs to names for display
  const estateMap = (estates || []).reduce((acc, e) => {
    acc[e.id] = `#${e.fileNumber} — ${e.estateName || [e.deceasedFirstName, e.deceasedMiddleNames, e.deceasedSecondMiddleName, e.deceasedLastName].filter(Boolean).join(" ") || "Untitled"}`;
    return acc;
  }, {} as Record<string, string>);
  const normalizedAccessSearch = accessSearch.trim().toLowerCase();
  const accessList = (accesses || []).filter(access => !estateId || access.estateId === estateId);
  const matchesStatus = (access: any) => {
    if (accessStatusFilter === "all") return true;
    if (accessStatusFilter === "revoked") return access.active === 0;
    if (accessStatusFilter === "expired") return access.active !== 0 && Boolean(access.expiresAt && access.expiresAt < Date.now());
    if (accessStatusFilter === "redeemed") return access.active !== 0 && Boolean(access.consumedAt);
    return access.active !== 0 && !access.consumedAt && !(access.expiresAt && access.expiresAt < Date.now());
  };
  const filteredAccesses = accessList.filter((access: any) => {
    const matchesSearch = !normalizedAccessSearch || [access.contactName, access.email, estateMap[access.estateId], access.estateId].filter(Boolean).join(" ").toLowerCase().includes(normalizedAccessSearch);
    return matchesSearch && matchesStatus(access);
  });
  const hasActiveFilters = Boolean(accessSearch || accessStatusFilter !== "all");
  const clearAccessFilters = () => { setAccessSearch(""); setAccessStatusFilter("all"); };

  if (isLoading) return (
    <Card data-testid="executor-portal-loading-skeleton" aria-busy="true" aria-label="Loading executor portal access">
      <CardHeader className="flex flex-row items-center justify-between gap-4 pb-3">
        <div className="flex items-center gap-2">
          <div className="h-4 w-4 rounded-full bg-muted motion-safe:animate-pulse" />
          <div className="h-4 w-44 rounded bg-muted motion-safe:animate-pulse" />
        </div>
        <div className="h-8 w-28 rounded-md bg-muted motion-safe:animate-pulse" />
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="h-3 max-w-xl rounded bg-muted motion-safe:animate-pulse" />
          <div className="h-3 w-4/5 max-w-lg rounded bg-muted motion-safe:animate-pulse" />
        </div>
        <div className="space-y-3 border-t pt-4">
          {[0, 1].map((row) => <div key={row} className="flex items-center justify-between gap-3">
            <div className="min-w-0 flex-1 space-y-2"><div className="h-3 w-40 rounded bg-muted motion-safe:animate-pulse" /><div className="h-3 w-3/5 rounded bg-muted motion-safe:animate-pulse" /></div>
            <div className="h-7 w-24 shrink-0 rounded bg-muted motion-safe:animate-pulse" />
          </div>)}
        </div>
        <span role="status" className="sr-only">Loading executor portal access</span>
      </CardContent>
    </Card>
  );

  if (accessError) return <Card><CardContent className="py-6 text-sm text-destructive" role="alert">Client links could not be loaded. Refresh this page to try again.</CardContent></Card>;

  return (
    <Card>
      <CardHeader className="pb-3 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <Shield className="h-4 w-4 text-muted-foreground" />
          <CardTitle className="text-sm">Executor / Client Portal Access</CardTitle>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild><Button size="sm"><Plus className="h-3 w-3 mr-1" /> Grant Access</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Portal Access</DialogTitle>
              <DialogDescription className="sr-only">Create a secure client-intake link for one estate file</DialogDescription>
            </DialogHeader>
            <div className="space-y-3 pt-2">
              {!estateId && <div className="space-y-1">
                <Label className="text-xs">Estate File</Label>
                <Select value={selectedEstate} onValueChange={setSelectedEstate}>
                  <SelectTrigger><SelectValue placeholder="Select estate" /></SelectTrigger>
                  <SelectContent>
                    {(estates || []).map((e) => (
                      <SelectItem key={e.id} value={e.id}>
                        #{e.fileNumber} — {e.estateName || [e.deceasedFirstName, e.deceasedMiddleNames, e.deceasedSecondMiddleName, e.deceasedLastName].filter(Boolean).join(" ") || "Untitled"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>}
              {estateId && <p className="text-sm font-medium">{estateMap[estateId] || "This estate file"}</p>}
              <div className="space-y-1"><Label className="text-xs">Client Name</Label><Input value={clientName} onChange={(e) => setClientName(e.target.value)} placeholder="e.g. John Smith" /></div>
              <div className="space-y-1"><Label className="text-xs">Client Email (optional)</Label><Input value={clientEmail} onChange={(e) => setClientEmail(e.target.value)} placeholder="e.g. john@example.com" /></div>
              <p className="text-xs text-muted-foreground">The link expires automatically after 90 days. You can extend it later.</p>
              <Button className="w-full" onClick={() => createMutation.mutate({ estateId: estateId || selectedEstate, email: clientEmail.trim(), contactName: clientName })} disabled={createMutation.isPending || !(estateId || selectedEstate) || !clientName}>
                {createMutation.isPending ? "Creating..." : "Create Access Link"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        <p className="text-xs text-muted-foreground mb-4">
          Issue client-intake links and review submissions before applying selected facts to an estate record. Each link is scoped to one estate, expires after 90 days, and can be exchanged only once. Creating another link invalidates any earlier unredeemed link for that access row.
        </p>
        {issuedLink && (
          <div className="mb-4 rounded-lg border border-primary/20 bg-primary/[0.035] p-3" role="status" aria-live="polite">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
              <div className="min-w-0 flex-1 space-y-1.5">
                <Label htmlFor="issued-client-intake-link" className="text-xs font-semibold text-foreground">New client-intake link</Label>
                <Input id="issued-client-intake-link" value={issuedLink} readOnly onFocus={(event) => event.currentTarget.select()} className="h-9 bg-background font-mono text-xs" />
                <p className="text-xs leading-5 text-muted-foreground">Shown only for this session. Copy it before leaving the Client Portal tab.</p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <Button type="button" size="sm" variant="outline" onClick={() => void copyPortalLink(issuedLink, "Client-intake link copied")} aria-label="Copy client intake link">
                  <Copy className="mr-1.5 h-3.5 w-3.5" />
                  Copy link
                </Button>
                <Button type="button" size="sm" variant="ghost" onClick={() => setIssuedLink("")} aria-label="Dismiss issued client intake link">Dismiss</Button>
              </div>
            </div>
          </div>
        )}
        {accessList.length > 0 && <div className="mb-4 flex flex-col gap-2 sm:flex-row">
          <div className="relative min-w-0 flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input value={accessSearch} onChange={(event) => setAccessSearch(event.target.value)} className="h-9 pr-10 pl-9" aria-label="Search executor portal access" placeholder="Search executor, client, email, or estate" />
            {accessSearch && <Button type="button" variant="ghost" size="icon" className="absolute right-1 top-1/2 h-7 w-7 -translate-y-1/2" onClick={() => setAccessSearch("")} aria-label="Clear executor portal search"><X className="h-3.5 w-3.5" /></Button>}
          </div>
          <Select value={accessStatusFilter} onValueChange={(value: typeof accessStatusFilter) => setAccessStatusFilter(value)}>
            <SelectTrigger className="h-9 w-full sm:w-40" aria-label="Filter executor portal access by status"><SelectValue placeholder="All statuses" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="redeemed">Redeemed</SelectItem>
              <SelectItem value="expired">Expired</SelectItem>
              <SelectItem value="revoked">Revoked</SelectItem>
            </SelectContent>
          </Select>
        </div>}
        <div aria-live="polite">
          <div className="divide-y divide-border">
            {filteredAccesses.map((a: any) => {
              const expiry = getExpiryStatus(a.expiresAt);
              const isExpired = a.expiresAt && a.expiresAt < Date.now();
              return (
                <div key={a.id} className="flex flex-col gap-3 py-3 first:pt-0 last:pb-0 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-medium truncate">{a.contactName || a.email}</span>
                      <Badge variant={a.active === 0 ? "destructive" : expiry.variant} className="text-[10px] px-1.5 py-0">
                        {a.active === 0 ? "Revoked" : expiry.label}
                      </Badge>
                      {a.active !== 0 && a.consumedAt && <Badge variant="secondary" className="text-[10px] px-1.5 py-0">Link redeemed</Badge>}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5 truncate">
                      {estateMap[a.estateId] || a.estateId}{a.email ? ` · ${a.email}` : ""} · Created {fmtDisplayDate(a.createdAt)}
                    </p>
                  </div>
                  <div className="flex items-center gap-1 ml-2 shrink-0">
                    {a.active !== 0 && (
                      <>
                        {(isExpired || (a.expiresAt && (a.expiresAt - Date.now()) < 30 * 24 * 60 * 60 * 1000)) && (
                          <Button variant="outline" size="sm" className="text-xs h-7 px-2" onClick={() => extendMutation.mutate({ id: a.id, estateId: a.estateId, days: 90 })} disabled={extendMutation.isPending}>
                            <RefreshCw className="h-3 w-3 mr-1" />
                            Extend
                          </Button>
                        )}
                        {!isExpired && <Button variant="outline" size="sm" className="h-7 px-2 text-xs" onClick={() => reissueLink(a, "replace")} disabled={reissueMutation.isPending} aria-label="Replace client intake link"><RefreshCw className="mr-1 h-3 w-3" />Replace link</Button>}
                        {!isExpired && a.email && <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => reissueLink(a, "email")} disabled={reissueMutation.isPending} aria-label="Email a replacement client intake link" title="Create a replacement link and open an email draft"><Mail className="h-3.5 w-3.5" /></Button>}
                        <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => revokeMutation.mutate({ id: a.id, estateId: a.estateId })}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
            {accessList.length === 0 && (
              <div className="text-center py-8">
                <Shield className="h-8 w-8 mx-auto text-muted-foreground/30 mb-2" />
                <p className="text-sm text-muted-foreground">No portal access links created yet.</p>
                <p className="text-xs text-muted-foreground/60 mt-1">Use "Grant Access" to create a secure client-intake link for an executor or client.</p>
              </div>
            )}
            {accessList.length > 0 && filteredAccesses.length === 0 && (
              <div className="text-center py-8">
                <Search className="h-8 w-8 mx-auto text-muted-foreground/30 mb-2" />
                <p className="text-sm text-muted-foreground">No portal access links match the current search and status filter.</p>
                <Button variant="link" size="sm" className="mt-1 h-auto px-0" onClick={clearAccessFilters}>Clear filters</Button>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
