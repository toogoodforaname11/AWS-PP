/**
 * Task 13: truthful delivery feedback, same-delivery coordination and safe recovery, end to end in the real Forms
 * tab (FormsTab, PreGenerateDialog, FormDetailsDialog, DeliveriesCard) and the preview modal. tRPC is faked at the
 * network boundary; deliveries answer with real Response/ReadableStream fixtures. Fictional data only.
 */
import React from "react";
import JSZip from "jszip";
import { act, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { browserResponse } from "@/lib/browserResponse.testkit";

vi.setConfig({ testTimeout: 45000 });
(globalThis as any).React = React;
vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn(), loading: vi.fn(), dismiss: vi.fn() }) }));
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { useDeliveryFeedbackOwner } from "@/lib/attachmentDelivery";
import { clearFallbackSession } from "@/lib/fallbackSession";

const TOKEN = "fictional.bearer.task13-forms";
const TOKEN_B = "fictional.bearer.task13-forms-b";
const DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const STALE = "This download link is out of date. Generate the document again.";
// Fictional stand-in for the route's unreadable-stored-file refusal: regeneration alone cannot repair it.
const REUPLOAD = "The letterhead template could not be read. Upload it again in Settings, then generate the document again.";
const REQUESTED = "Form generated — download requested. Check your browser's downloads.";
const PREPARING = "Form generated — preparing the download…";
const STARTED = "Form generated — download started.";
const GENERIC = "The download could not be completed. Please try again.";
// Task 13 r3.2 (D13, Nick 2026-10-24): the forced review's sentence, exactly as approved — with lines, for P3–P7 with
// lines, and with no lines.
const RETAINED = "This uses your earlier attempt's choices listed below and any answers you entered for it. Other details recorded on the estate, such as the oath and jurat city, are used as they are now. Generating again replaces the current version, even if it is newer than this attempt.";
const RETAINED_PRIMARY = "This uses your earlier attempt's choices listed below and any answers you entered for it. Other details recorded on the estate, such as the oath and jurat city, are used as they are now. Generating again replaces the current applicant's affidavit (P3 to P7), even if it is newer than this attempt.";
const RETAINED_EMPTY = "This uses your earlier attempt's choices and any answers you entered for it. Other details recorded on the estate, such as the oath and jurat city, are used as they are now. Generating again replaces the current version, even if it is newer than this attempt.";

const state = vi.hoisted(() => ({
  estate: {} as any,
  contacts: [] as any[],
  documents: [] as any[],
  deliveries: [] as any[],
  recipients: [] as any[],
  letterRecipients: [] as any[],
  generateCalls: [] as any[],
  preflightCalls: [] as any[],
  invalidated: [] as string[],
  preflightReport: null as null | ((input: any) => any),
  documentSeq: 0,
  /** Generations still to hold until the test releases them (overlap cases). */
  holdGenerations: 0,
  heldGenerations: [] as Array<() => void>,
  /** While set, every refresh (invalidate) waits on it. */
  invalidateGate: null as null | Promise<void>,
  /** Runs inside each generation, e.g. to rotate the session as a response header would. */
  onGenerate: null as null | (() => void),
}));

vi.mock("@/lib/trpc", async () => {
  const { useRef } = await import("react");
  const queryData = (key: string): any => {
    if (key === "contact.list") return state.contacts;
    if (key === "document.list") return state.documents;
    if (key === "delivery.list") return state.deliveries;
    if (key === "delivery.getRecipients") return state.recipients;
    if (key === "document.getLetterRecipients") return state.letterRecipients;
    if (key === "document.preview") return { sections: [] };
    if (key === "settings.get") return { lawyerName: "Firm Lawyer", firmCity: "Victoria" };
    return ["document.versions", "document.retainedFiles", "citation.list", "inventory.list"].includes(key) ? [] : undefined;
  };
  // Task 13 r3.1: as TanStack v5 does (MutationObserver.setOptions on every render), a call in flight completes with
  // the LATEST render's callbacks, not those of the render that sent it.
  const mutation = (key: string, latest: { current: any }) => {
    const mutateAsync = async (input: any) => {
      try {
        let result: any = { revision: 2 };
        if (key === "document.generate") {
          state.generateCalls.push(JSON.parse(JSON.stringify(input)));
          state.documentSeq += 1;
          const documentId = `doc_${input.formCode}_${state.documentSeq}`;
          result = {
            id: documentId,
            // Each generation returns a new prepared delivery, as the server does.
            delivery: { method: "POST", action: "/api/download/form", fields: { estateId: input.estateId, formCode: input.formCode, documentId } },
            filename: `${input.formCode}.docx`,
            format: "docx",
          };
          state.onGenerate?.();
          if (state.holdGenerations > 0) {
            state.holdGenerations -= 1;
            await new Promise<void>((resolve) => { state.heldGenerations.push(resolve); });
          }
        }
        // Match TanStack: onSuccess is awaited; a throw there rejects mutateAsync and runs onError.
        await latest.current?.onSuccess?.(result, input, undefined);
        return result;
      } catch (error) {
        await latest.current?.onError?.(error, input, undefined);
        throw error;
      }
    };
    return { mutateAsync, mutate: (input: any) => { void mutateAsync(input).catch(() => undefined); }, isPending: false };
  };
  const utils = (path: string[]): any => new Proxy({}, {
    get(_target, property: string): any {
      const key = path.join(".");
      if (property === "invalidate") return async () => { state.invalidated.push(key); if (state.invalidateGate) await state.invalidateGate; };
      if (["cancel", "setData"].includes(property)) return () => undefined;
      if (property === "getData") return () => (key === "contact.list" ? state.contacts : key === "estate.get" ? state.estate : undefined);
      if (property === "fetch") return async (input: any) => {
        if (key === "estate.get") return state.estate;
        if (key === "document.preflight") {
          state.preflightCalls.push(JSON.parse(JSON.stringify(input)));
          return state.preflightReport ? await state.preflightReport(input) : { formCode: input.formCode, ok: true, gaps: [] };
        }
        if (key === "document.preflightMany") return (input.formCodes as string[]).map((formCode) => ({ formCode, ok: true, gaps: [] }));
        return [];
      };
      return utils([...path, property]);
    },
  });
  const node = (path: string[]): any => new Proxy({}, {
    get(_target, property: string): any {
      if (property === "useQuery") return () => ({ data: queryData(path.join(".")), isLoading: false, error: null });
      if (property === "useMutation") return (options: any) => {
        const latest = useRef(options);
        latest.current = options;
        return mutation(path.join("."), latest);
      };
      if (property === "useUtils") return () => utils([]);
      return node([...path, property]);
    },
  });
  return { trpc: node([]) };
});

const jordan = {
  id: "jordan", name: "Jordan Ellis Calder-Quay", role: "applicant,executor", executorStatus: "applying",
  executorRank: "primary", applicantKind: "individual", occupation: "Teacher", relationship: "child",
  residentialAddress: "10 Main Street, Victoria, BC", residenceStreet: "10 Main Street",
  residenceCity: "Victoria", residenceProvince: "BC", residenceCountry: "Canada",
};
const avery = { ...jordan, id: "avery", name: "Avery Calder-Quay", executorRank: "alternate", occupation: "Engineer" };
const sam = { id: "bene-1", name: "Sam Beneficiary", role: "beneficiary", relationship: "child", address: "1 Fictional Way, Victoria, BC", isPredeceased: 0 };
const rowan = { ...jordan, id: "ren-1", name: "Rowan Renouncer", role: "executor", executorStatus: "renounced", executorRank: "alternate", applicantKind: undefined };

let docxBytes: Uint8Array;
let zipBytes: Uint8Array;
const fetchSpy = vi.fn<(input: RequestInfo | URL, init?: RequestInit) => Promise<Response>>();
const held: Array<(response: Response) => void> = [];
const nativeSubmits: Array<Record<string, string>> = [];
const anchorClicks: Array<{ href: string; download: string }> = [];
const blobs: Blob[] = [];

function attachment(bytes: Uint8Array, type: string, filename: string): Response {
  return browserResponse(bytes, {
    status: 200,
    headers: { "content-type": type, "content-disposition": `attachment; filename="${filename}"`, "content-length": String(bytes.length) },
  });
}
function refusal(status: number, error: string): Response {
  return browserResponse(JSON.stringify({ error }), { status, headers: { "content-type": "application/json; charset=utf-8" } });
}
/** The next delivery fetch waits until the test answers it. */
function holdNextFetch(): void {
  fetchSpy.mockImplementationOnce(() => new Promise<Response>((resolve) => { held.push(resolve); }));
}
async function answerHeld(response: Response): Promise<void> {
  await waitFor(() => expect(held.length).toBeGreaterThan(0));
  held.shift()!(response);
}
const attemptOf = (index: number) => new URLSearchParams(String((fetchSpy.mock.calls[index]?.[1] as RequestInit).body)).get("attemptId");
const settle = () => new Promise<void>((resolve) => { setTimeout(resolve, 0); });
const p3Docx = () => attachment(docxBytes, DOCX, "P3_Calder-Quay_1.docx");

beforeAll(async () => {
  docxBytes = await new JSZip().file("word/document.xml", "<w:document/>").generateAsync({ type: "uint8array" });
  zipBytes = await new JSZip().file("a.docx", docxBytes).generateAsync({ type: "uint8array" });
});

beforeEach(() => {
  vi.clearAllMocks();
  for (const fn of [toast.success, toast.error, toast.info, toast.loading, toast.dismiss]) vi.mocked(fn).mockReset();
  state.estate = {
    id: "estate-19", revision: 1, deceasedFirstName: "Helen Rose", deceasedLastName: "Calder-Quay",
    grantType: "grant_of_probate", willStatus: "will", hasWill: 1, registry: "Victoria",
    deceasedDomiciledInBC: "yes", deceasedOrdinarilyResidentInBC: "yes", oathType: "affirmed", domicileCity: "Victoria",
  };
  state.contacts = [jordan, avery, sam];
  state.documents = [{ id: "primary", formCode: "P3", deponentId: "jordan", deponentName: jordan.name, signatureDate: "2026-09-05" }];
  state.deliveries = [];
  state.recipients = [];
  state.letterRecipients = [];
  state.generateCalls = [];
  state.preflightCalls = [];
  state.invalidated = [];
  state.preflightReport = null;
  state.documentSeq = 0;
  state.holdGenerations = 0;
  state.heldGenerations = [];
  state.invalidateGate = null;
  state.onGenerate = null;
  held.length = 0;
  nativeSubmits.length = 0;
  anchorClicks.length = 0;
  blobs.length = 0;
  fetchSpy.mockReset();
  vi.stubGlobal("fetch", fetchSpy);
  sessionStorage.setItem("manus-cookie", `app_session_id=${TOKEN}`);
  vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) {
    nativeSubmits.push(Object.fromEntries(new FormData(this)) as Record<string, string>);
  });
  vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(function (this: HTMLAnchorElement) {
    anchorClicks.push({ href: this.href, download: this.download });
  });
  Object.defineProperty(URL, "createObjectURL", {
    configurable: true, writable: true,
    value: vi.fn((blob: Blob) => { blobs.push(blob); return `blob:http://localhost/task13-${blobs.length}`; }),
  });
  Object.defineProperty(URL, "revokeObjectURL", { configurable: true, writable: true, value: vi.fn() });
  // Radix Select in jsdom (the existing FormDetailsDialog.test.tsx recipe).
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => undefined, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => undefined, configurable: true });
  Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => undefined, configurable: true });
});

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  sessionStorage.clear();
  delete (URL as any).createObjectURL;
  delete (URL as any).revokeObjectURL;
});

async function FormsTabComponent() {
  return (await import("./EstateDetail")).FormsTab;
}
async function mountForms(estateId = "estate-19") {
  const FormsTab = await FormsTabComponent();
  const view = render(<FormsTab estateId={estateId} estate={{ ...state.estate, id: estateId }} onNavigateToTab={vi.fn()} />);
  return { ...view, FormsTab };
}
async function generateP3(): Promise<void> {
  fireEvent.click(screen.getByTestId("form-generate-P3"));
  const details = await screen.findByTestId("form-details-generate").catch(() => null);
  if (details) fireEvent.click(details);
  await waitFor(() => expect(state.generateCalls.length).toBeGreaterThan(0));
}
function recoveryPanel(): HTMLElement {
  return screen.getByTestId("document-generation-recovery");
}
/**
 * Task 13 r3 (D11): the estate page's shape. It owns the estate's feedback owner, as AnimatedTabs does, and passes it
 * to the Forms tab; `showTab` swaps the tab content, which unmounts FormsTab exactly as a tab switch does.
 */
async function mountEstatePage(estateId = "estate-19") {
  const FormsTab = await FormsTabComponent();
  function EstatePage({ tab }: { tab: "forms" | "notes" }) {
    const estateFeedback = useDeliveryFeedbackOwner(`estate:${estateId}`);
    return tab === "forms"
      ? <FormsTab estateId={estateId} estate={{ ...state.estate, id: estateId }} onNavigateToTab={vi.fn()} feedbackOwner={estateFeedback} />
      : <p data-testid="estate-notes-tab">Notes</p>;
  }
  const view = render(<EstatePage tab="forms" />);
  return { ...view, showTab: (tab: "forms" | "notes") => view.rerender(<EstatePage tab={tab} />) };
}
/**
 * Task 13 r3 (D11, plan critique #1): AnimatedTabs' tab container — one owner per estate, passed as a prop into the
 * estate-keyed, animated tab content, so an exiting tab keeps the props it was rendered with.
 */
async function mountAnimatedEstatePage(estateId: string) {
  const FormsTab = await FormsTabComponent();
  function EstatePage({ estateId }: { estateId: string }) {
    const estateFeedback = useDeliveryFeedbackOwner(`estate:${estateId}`);
    return (
      <AnimatePresence mode="wait">
        <motion.div
          key={`${estateId}:forms`}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -4 }}
          transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] }}
          data-testid={`estate-tab-${estateId}`}
        >
          <FormsTab estateId={estateId} estate={{ ...state.estate, id: estateId }} onNavigateToTab={vi.fn()} feedbackOwner={estateFeedback} />
        </motion.div>
      </AnimatePresence>
    );
  }
  const view = render(<EstatePage estateId={estateId} />);
  return { ...view, showEstate: (next: string) => view.rerender(<EstatePage estateId={next} />) };
}
/** Task 13 r3 (D13): the review's retained-choices block, read as its sentence and its label/value lines in order. */
function retainedChoices(): { sentence: string | null | undefined; lines: Array<[string | null, string | null | undefined]> } {
  const block = within(screen.getByTestId("pre-generate-dialog")).getByTestId("pre-generate-retained-choices");
  return {
    sentence: block.querySelector("p")?.textContent,
    lines: Array.from(block.querySelectorAll("dt")).map((term): [string | null, string | null | undefined] => [term.textContent, term.nextElementSibling?.textContent]),
  };
}

describe("Task 13: one prepared delivery is one fetch (Forms tab)", () => {
  it("an in-flight auto-download disables its own Download button; clicks send nothing until it settles, then a retry is a fresh attempt", async () => {
    holdNextFetch();
    await mountForms();
    await generateP3();
    const retry = await screen.findByTestId("document-generation-download-retry") as HTMLButtonElement;
    await waitFor(() => expect(retry.disabled).toBe(true));
    expect(retry.textContent).toMatch(/Downloading…/);
    fireEvent.click(retry);
    fireEvent.click(retry);
    await settle();
    expect(fetchSpy).toHaveBeenCalledTimes(1);

    await answerHeld(p3Docx());
    await waitFor(() => expect(anchorClicks).toHaveLength(1));
    await waitFor(() => expect(retry.disabled).toBe(false));
    expect(retry.textContent).toMatch(/Download P3/);

    fetchSpy.mockResolvedValueOnce(p3Docx());
    fireEvent.click(retry);
    await waitFor(() => expect(anchorClicks).toHaveLength(2));
    expect(fetchSpy).toHaveBeenCalledTimes(2);
    expect(attemptOf(1)).toMatch(UUID_V4);
    expect(attemptOf(1)).not.toBe(attemptOf(0));
    expect(state.generateCalls).toHaveLength(1);
    expect(blobs).toHaveLength(2);
  });

  it("generation settles and the dialog reports the generation while the delivery is still pending", async () => {
    state.preflightReport = (input) => ({
      formCode: input.formCode, ok: false, hardBlocked: false,
      gaps: [{ requirementId: "task13_warning", label: "Record a fictional detail", missingFields: [], tab: "forms", source: "Form P3" }],
    });
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    holdNextFetch();
    await mountForms();
    fireEvent.click(screen.getByTestId("form-generate-P3"));
    const details = await screen.findByTestId("form-details-generate").catch(() => null);
    if (details) fireEvent.click(details);
    const proceed = await screen.findByTestId("pre-generate-proceed");
    // Missing information still warns and proceeds (no new block).
    expect((proceed as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(proceed);
    await waitFor(() => expect(screen.getByText("Document generated!")).toBeTruthy());
    expect(toast.loading).toHaveBeenCalledWith(PREPARING);
    expect(toast.success).not.toHaveBeenCalled();
    expect(anchorClicks).toEqual([]);
    expect(state.generateCalls[0]).toMatchObject({ formCode: "P3", generateAnyway: true });

    await answerHeld(p3Docx());
    await waitFor(() => expect(toast.success).toHaveBeenCalledWith(STARTED, { id: "t-1" }));
    expect(anchorClicks).toHaveLength(1);
  });
});

describe("Task 13: copy says only what is known (Forms tab)", () => {
  it("a cookie session's native auto-download says only that the download was requested", async () => {
    sessionStorage.clear();
    await mountForms();
    await generateP3();
    await waitFor(() => expect(nativeSubmits).toHaveLength(1));
    expect(toast.info).toHaveBeenCalledWith(REQUESTED);
    expect(toast.success).not.toHaveBeenCalled();
    expect(toast.loading).not.toHaveBeenCalled();
    expect(recoveryPanel().textContent).toMatch(/P3 is ready/);
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it("a fetch auto-download shows one loading toast that becomes the handoff", async () => {
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    fetchSpy.mockResolvedValueOnce(p3Docx());
    await mountForms();
    await generateP3();
    await waitFor(() => expect(toast.success).toHaveBeenCalledWith(STARTED, { id: "t-1" }));
    expect(toast.loading).toHaveBeenCalledWith(PREPARING);
    expect(toast.info).not.toHaveBeenCalled();
    expect(toast.error).not.toHaveBeenCalled();
  });

  it("a failed delivery after a successful generation is never reported as a failed generation", async () => {
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    fetchSpy.mockRejectedValueOnce(new TypeError("Failed to fetch"));
    await mountForms();
    await generateP3();
    await waitFor(() => expect(toast.error).toHaveBeenCalledWith("Server is temporarily unavailable. Please try again in a moment.", { id: "t-1" }));
    expect(toast.error).toHaveBeenCalledTimes(1);
    expect(recoveryPanel().textContent).toMatch(/P3 is ready/);
    expect(recoveryPanel().textContent).not.toMatch(/not generated/i);
    expect(screen.getByTestId("document-generation-download-retry")).toBeTruthy();
  });
});

describe("Task 13: a refused link is replaced by its refusal and a deliberate review", () => {
  it.each([
    [409, STALE],
    [409, REUPLOAD],
    [400, "Invalid download parameters."],
    [413, "The request is too large."],
  ])("a %i refusal hides the dead link, keeps the server's words verbatim and offers Review and generate again", async (status, sentence) => {
    fetchSpy.mockResolvedValueOnce(refusal(status, sentence));
    await mountForms();
    await generateP3();
    await waitFor(() => expect(recoveryPanel().textContent).toContain(`P3 — ${sentence}`));
    expect(recoveryPanel().getAttribute("role")).toBe("alert");
    expect(screen.queryByTestId("document-generation-download-retry")).toBeNull();
    expect(screen.queryByTestId("document-generation-review-retry")).toBeNull();
    expect(screen.getByTestId("document-generation-regenerate").textContent).toBe("Review and generate again");
    expect(within(recoveryPanel()).getByRole("button", { name: "Dismiss" })).toBeTruthy();
    expect(toast.error).toHaveBeenCalledTimes(1);
    expect(state.generateCalls).toHaveLength(1);
  });

  it("a 401 keeps the link (a fresh attempt once access is restored) and offers no regeneration", async () => {
    fetchSpy.mockResolvedValueOnce(refusal(401, "Authentication required"));
    await mountForms();
    await generateP3();
    await waitFor(() => expect(toast.error).toHaveBeenCalledWith("Authentication required"));
    const retry = screen.getByTestId("document-generation-download-retry") as HTMLButtonElement;
    await waitFor(() => expect(retry.disabled).toBe(false));
    expect(screen.queryByTestId("document-generation-regenerate")).toBeNull();
    sessionStorage.setItem("manus-cookie", `app_session_id=${TOKEN_B}`);
    fetchSpy.mockResolvedValueOnce(p3Docx());
    fireEvent.click(retry);
    await waitFor(() => expect(anchorClicks).toHaveLength(1));
    expect(((fetchSpy.mock.calls[1]?.[1] as RequestInit).headers as Record<string, string>).Authorization).toBe(`Bearer ${TOKEN_B}`);
    expect(state.generateCalls).toHaveLength(1);
  });

  it("Review and generate again refreshes the facts, always reviews, and generates only on the user's Generate with every original choice", async () => {
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    await generateP3();
    const regenerate = await screen.findByTestId("document-generation-regenerate");
    const preflightsBefore = state.preflightCalls.length;
    fireEvent.click(regenerate);
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    for (const key of ["estate.get", "contact.list", "document.list", "inventory.list", "delivery.list", "delivery.getRecipients", "citation.list", "document.getLetterRecipients"]) {
      expect(state.invalidated).toContain(key);
    }
    expect(state.preflightCalls.length).toBe(preflightsBefore + 1);
    expect(state.generateCalls).toHaveLength(1);
    fetchSpy.mockResolvedValueOnce(p3Docx());
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(2));
    expect(state.generateCalls[1]).toEqual(state.generateCalls[0]);
    await waitFor(() => expect(anchorClicks).toHaveLength(1));
  });

  it("cancelling the review generates nothing and keeps the refusal", async () => {
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    await generateP3();
    fireEvent.click(await screen.findByTestId("document-generation-regenerate"));
    fireEvent.click(await screen.findByTestId("pre-generate-cancel"));
    await settle();
    expect(state.generateCalls).toHaveLength(1);
    expect(recoveryPanel().textContent).toContain(`P3 — ${STALE}`);
  });

  it("a signing date changed after the refusal is neither what the review checks nor what it prints", async () => {
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    await generateP3();
    const regenerate = await screen.findByTestId("document-generation-regenerate");
    const original = String(state.generateCalls[0].signatureDate);
    // The Forms tab's own Signature Date field (no label link): the date input holding the generated date.
    const field = Array.from(document.querySelectorAll<HTMLInputElement>('input[type="date"]')).find((input) => input.value === original)!;
    fireEvent.change(field, { target: { value: "2026-12-01" } });
    expect(field.value).toBe("2026-12-01");
    fireEvent.click(regenerate);
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    expect(state.preflightCalls.at(-1)).toMatchObject({ formCode: "P3", signatureDate: original });
    fetchSpy.mockResolvedValueOnce(p3Docx());
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(2));
    expect(state.generateCalls[1]).toEqual(state.generateCalls[0]);
  });

  it("P8 keeps its chosen deponent and affidavit number through the review", async () => {
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    fireEvent.click(within(screen.getByTestId("form-row-P8")).getAllByRole("button", { name: "Generate" })[0]);
    fireEvent.change(await screen.findByTestId("form-details-affidavit-ordinal"), { target: { value: "second" } });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(1));
    expect(state.generateCalls[0]).toMatchObject({ formCode: "P8", deponentId: "avery", affidavitOrdinal: "second" });
    await waitFor(() => expect(screen.getByTestId("p8-download-recovery").textContent).toContain(STALE));
    expect(screen.getByTestId("p8-download-recovery").getAttribute("role")).toBe("alert");
    expect(screen.queryByTestId("p8-download-retry")).toBeNull();
    fireEvent.click(screen.getByTestId("p8-download-regenerate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    fetchSpy.mockResolvedValueOnce(attachment(docxBytes, DOCX, "P8_Avery_Calder-Quay_1.docx"));
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(2));
    expect(state.generateCalls[1]).toEqual(state.generateCalls[0]);
  });

  it("production P46 (Deliveries card → details) keeps its delivery and the demandant's date through the review", async () => {
    state.estate = { ...state.estate, willType: "electronic" };
    state.deliveries = [{ id: "d1", contactId: "bene-1", recipientName: "Sam Beneficiary", deliveryMethod: "personal", deliveryDate: "2026-09-01" }];
    state.recipients = [{ contactId: "bene-1", name: "Sam Beneficiary", p46Eligible: true }];
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    fireEvent.click(await screen.findByTestId("p46-generate-d1"));
    fireEvent.change(await screen.findByTestId("form-details-date"), { target: { value: "2026-10-01" } });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(1));
    expect(state.generateCalls[0]).toMatchObject({ formCode: "P46", deliveryId: "d1", signatureDate: "2026-10-01" });
    fireEvent.click(await screen.findByTestId("document-generation-regenerate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    fetchSpy.mockResolvedValueOnce(attachment(docxBytes, DOCX, "P46_Sam_Beneficiary_1.docx"));
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(2));
    expect(state.generateCalls[1]).toEqual(state.generateCalls[0]);
  });

  it("a recipient letter keeps its recipient through the review", async () => {
    state.letterRecipients = [{ contactId: "bene-1", name: "Sam Beneficiary", address: "1 Fictional Way", isBeneficiary: true }];
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    fireEvent.click(screen.getAllByRole("button", { name: "Letter" })[0]);
    await waitFor(() => expect(state.generateCalls).toHaveLength(1));
    expect(state.generateCalls[0]).toMatchObject({ formCode: "LETTER", targetBeneficiaryId: "bene-1" });
    fireEvent.click(await screen.findByTestId("document-generation-regenerate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    expect(state.preflightCalls.at(-1)).toMatchObject({ formCode: "LETTER", targetContactId: "bene-1" });
    fetchSpy.mockResolvedValueOnce(attachment(docxBytes, DOCX, "LETTER_Sam_Beneficiary_1.docx"));
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(2));
    expect(state.generateCalls[1]).toEqual(state.generateCalls[0]);
  });

  it("P17 keeps its renouncer through the review", async () => {
    state.contacts = [jordan, avery, sam, rowan];
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    fireEvent.click(within(screen.getByTestId("form-row-P17")).getByRole("button", { name: "Generate" }));
    await waitFor(() => expect(state.generateCalls).toHaveLength(1));
    expect(state.generateCalls[0]).toMatchObject({ formCode: "P17", deponentId: "ren-1" });
    fireEvent.click(await screen.findByTestId("document-generation-regenerate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    fetchSpy.mockResolvedValueOnce(attachment(docxBytes, DOCX, "P17_Rowan_Renouncer_1.docx"));
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(2));
    expect(state.generateCalls[1]).toEqual(state.generateCalls[0]);
  });

  it("an optional P7 draft keeps the per-run answers typed into the gap dialog (real gap engine) through the review", async () => {
    const applicant = {
      id: "applicant-1", role: "applicant,executor", executorStatus: "applying", executorRank: "primary",
      name: "Alex Applicant", relationship: "child", occupation: "Teacher", applicantKind: "individual",
      residenceStreet: "10 Main Street", residentialAddress: "10 Main Street", residenceCity: "Victoria",
      residenceProvince: "BC", residenceCountry: "Canada", residencePostalCode: "V8V 1A1",
    };
    state.contacts = [applicant];
    state.documents = [];
    state.estate = {
      id: "estate-19", revision: 1, grantType: "grant_of_probate", willStatus: "will", hasWill: 1,
      deceasedFirstName: "Helen Rose", deceasedLastName: "Calder-Quay", registry: "Victoria",
      applicantType: "executor", deceasedDomiciledInBC: "yes", deceasedOrdinarilyResidentInBC: "yes",
      testamentaryDocStatus: "none_found", notifyPGT: "no", p1NotRequired: 1,
      vsaCertificateResult: "no_notice", oathType: "affirmed", juratCity: "Victoria",
      foreignGrantGranteeNames: "", foreignGrantIssuingCourt: "", foreignGrantIssuingJurisdiction: "", foreignGrantIssuedDate: "",
    };
    state.preflightReport = async (input) => {
      const { checkFormRequirements } = await import("@shared/formRequirements");
      const { applyEstateOverrides } = await import("@shared/formOverrides");
      const { formStatus } = await import("@shared/types");
      const estate = applyEstateOverrides(state.estate, input.overrides);
      const status = formStatus("P7", estate, state.contacts as any);
      const report = checkFormRequirements("P7", {
        estate, contacts: state.contacts, inventory: [], liabilities: [], deliveries: [], documents: [],
        requiredDocuments: [{ docKey: "wills_notice_result", received: 1 }],
      } as any);
      if (status.applicability === "na") report.gaps.unshift({
        requirementId: "p7_applicability", label: status.reason, missingFields: [], tab: "forms", source: "Form P7",
        ...(input.generateAnyway ? {} : { blocker: "hard" as const }),
      });
      return { ...report, ok: report.gaps.length === 0, notApplicable: status.applicability === "na", hardBlocked: report.gaps.some((gap: any) => gap.blocker === "hard") };
    };
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    fireEvent.click(screen.getByTestId("form-generate-P7"));
    fireEvent.click(screen.getByTestId("fix-confirm"));
    fireEvent.click(await screen.findByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());
    const answers = { foreignGrantIssuingCourt: "High Court", foreignGrantIssuingJurisdiction: "England and Wales" };
    for (const [column, value] of Object.entries(answers)) {
      fireEvent.change(screen.getByTestId(`pre-generate-editor-${column}`).querySelector("input, textarea")!, { target: { value } });
    }
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(1));
    expect(state.generateCalls[0]).toMatchObject({ formCode: "P7", generateAnyway: true, overrides: answers });
    // The modal shows "Document generated!" for 3 s and closes itself; only then can a user reach the panel.
    await waitFor(() => expect(screen.queryByTestId("pre-generate-dialog")).toBeNull(), { timeout: 6000 });
    fireEvent.click(await screen.findByTestId("document-generation-regenerate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());
    // The refreshed check runs with the retained answers, so their gaps stay answered.
    expect(state.preflightCalls.at(-1)).toMatchObject({ formCode: "P7", overrides: answers });
    expect(state.generateCalls).toHaveLength(1);
    fetchSpy.mockResolvedValueOnce(attachment(docxBytes, DOCX, "P7_Helen_Calder-Quay_1.docx"));
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(2));
    expect(state.generateCalls[1]).toEqual(state.generateCalls[0]);
  });

  it("a consent reopens its own dialog with the retained answers, and only Generate DOCX regenerates", async () => {
    state.letterRecipients = [{ contactId: "bene-1", name: "Sam Beneficiary", address: "1 Fictional Way", isBeneficiary: true }];
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    // A string role name matches the whole accessible name, so this is not "Consent to Appoint".
    fireEvent.click(await screen.findByRole("button", { name: "Consent" }));
    fireEvent.click(screen.getByLabelText("Nominated personal representative"));
    fireEvent.click(screen.getByRole("option", { name: jordan.name }));
    fireEvent.change(screen.getByLabelText("Nominee’s relationship to the signer"), { target: { value: "brother" } });
    fireEvent.change(screen.getByLabelText("Signer’s beneficiary percentage"), { target: { value: "50" } });
    fireEvent.click(screen.getByRole("button", { name: "Generate DOCX" }));
    await waitFor(() => expect(state.generateCalls).toHaveLength(1));
    expect(state.generateCalls[0]).toMatchObject({
      formCode: "CONSENT_NOMINATION", targetBeneficiaryId: "bene-1",
      consentNomination: { nomineeContactId: "jordan", relationshipToNominee: "brother", beneficiarySharePercentage: 50 },
    });
    fireEvent.click(await screen.findByTestId("document-generation-regenerate"));
    await waitFor(() => expect(screen.getByRole("heading", { name: "Consent and Nomination" })).toBeTruthy());
    expect((screen.getByLabelText("Nominee’s relationship to the signer") as HTMLInputElement).value).toBe("brother");
    expect((screen.getByLabelText("Signer’s beneficiary percentage") as HTMLInputElement).value).toBe("50");
    expect(state.generateCalls).toHaveLength(1);
    fetchSpy.mockResolvedValueOnce(attachment(docxBytes, DOCX, "CONSENT_NOMINATION_1.docx"));
    fireEvent.click(screen.getByRole("button", { name: "Generate DOCX" }));
    await waitFor(() => expect(state.generateCalls).toHaveLength(2));
    expect(state.generateCalls[1]).toEqual(state.generateCalls[0]);
  });

  it("a consent to appoint an administrator reopens with its retained choice, and only Generate DOCX regenerates", async () => {
    state.estate = { ...state.estate, willStatus: "no_will", hasWill: 0 };
    state.letterRecipients = [{ contactId: "bene-1", name: "Sam Beneficiary", address: "1 Fictional Way", isBeneficiary: true }];
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    fireEvent.click(await screen.findByRole("button", { name: "Consent to Appoint" }));
    fireEvent.click(screen.getByLabelText("Administrator or applying applicant to be appointed"));
    fireEvent.click(screen.getByRole("option", { name: jordan.name }));
    fireEvent.click(screen.getByRole("button", { name: "Generate DOCX" }));
    await waitFor(() => expect(state.generateCalls).toHaveLength(1));
    expect(state.generateCalls[0]).toMatchObject({
      formCode: "CONSENT_APPOINT_ADMINISTRATOR", targetBeneficiaryId: "bene-1", consentAppointAdministrator: { administratorContactId: "jordan" },
    });
    fireEvent.click(await screen.findByTestId("document-generation-regenerate"));
    await waitFor(() => expect(screen.getByRole("heading", { name: "Consent to Appointment of an Administrator" })).toBeTruthy());
    expect(state.generateCalls).toHaveLength(1);
    fetchSpy.mockResolvedValueOnce(attachment(docxBytes, DOCX, "CONSENT_APPOINT_ADMINISTRATOR_1.docx"));
    fireEvent.click(screen.getByRole("button", { name: "Generate DOCX" }));
    await waitFor(() => expect(state.generateCalls).toHaveLength(2));
    expect(state.generateCalls[1]).toEqual(state.generateCalls[0]);
  });

  it("a reopened consent clears a retained nominee who is no longer offered, so the user chooses again", async () => {
    state.letterRecipients = [{ contactId: "bene-1", name: "Sam Beneficiary", address: "1 Fictional Way", isBeneficiary: true }];
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    fireEvent.click(await screen.findByRole("button", { name: "Consent" }));
    fireEvent.click(screen.getByLabelText("Nominated personal representative"));
    fireEvent.click(screen.getByRole("option", { name: jordan.name }));
    fireEvent.change(screen.getByLabelText("Nominee’s relationship to the signer"), { target: { value: "brother" } });
    fireEvent.change(screen.getByLabelText("Signer’s beneficiary percentage"), { target: { value: "50" } });
    fireEvent.click(screen.getByRole("button", { name: "Generate DOCX" }));
    await waitFor(() => expect(state.generateCalls).toHaveLength(1));
    // The nominee is recorded as predeceased before the review.
    state.contacts = state.contacts.map((contact) => (contact.id === "jordan" ? { ...contact, isPredeceased: 1 } : contact));
    fireEvent.click(await screen.findByTestId("document-generation-regenerate"));
    await waitFor(() => expect(screen.getByRole("heading", { name: "Consent and Nomination" })).toBeTruthy());
    expect((screen.getByLabelText("Nominee’s relationship to the signer") as HTMLInputElement).value).toBe("brother");
    fireEvent.click(screen.getByRole("button", { name: "Generate DOCX" }));
    expect(toast.error).toHaveBeenCalledWith("Select a nominee, enter the relationship, and enter a beneficiary percentage from 0 to 100.");
    expect(state.generateCalls).toHaveLength(1);
  });

  it("Review and generate again is locked only by its own refresh, never by another form's check", async () => {
    state.letterRecipients = [{ contactId: "bene-1", name: "Sam Beneficiary", address: "1 Fictional Way", isBeneficiary: true }];
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    await generateP3();
    const regenerate = await screen.findByTestId("document-generation-regenerate") as HTMLButtonElement;
    let failLetterCheck: (error: Error) => void = () => undefined;
    state.preflightReport = (input) => (input.formCode === "LETTER"
      ? new Promise((_resolve, reject) => { failLetterCheck = reject; })
      : { formCode: input.formCode, ok: true, gaps: [] });
    fireEvent.click(screen.getAllByRole("button", { name: "Letter" })[0]);
    await screen.findByTestId("preflight-busy");
    // An unrelated check in flight does not lock it.
    expect(regenerate.disabled).toBe(false);
    expect(regenerate.getAttribute("aria-disabled")).toBeNull();
    failLetterCheck(new Error("Unable to check the letter right now."));
    await waitFor(() => expect(screen.queryByTestId("preflight-busy")).toBeNull());
    let openRefresh: () => void = () => undefined;
    state.invalidateGate = new Promise<void>((resolve) => { openRefresh = resolve; });
    fireEvent.click(regenerate);
    await waitFor(() => expect(regenerate.getAttribute("aria-disabled")).toBe("true"));
    // Its own refresh is in flight: a second press starts nothing (and focus is kept: never `disabled`).
    fireEvent.click(regenerate);
    expect(regenerate.disabled).toBe(false);
    expect(state.invalidated.filter((key) => key === "estate.get")).toHaveLength(1);
    openRefresh();
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    expect(state.generateCalls).toHaveLength(1);
  });

  it("a dialog the user opens during the refresh is never taken over by the review", async () => {
    state.letterRecipients = [{ contactId: "bene-1", name: "Sam Beneficiary", address: "1 Fictional Way", isBeneficiary: true }];
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    await generateP3();
    const regenerate = await screen.findByTestId("document-generation-regenerate");
    let openRefresh: () => void = () => undefined;
    state.invalidateGate = new Promise<void>((resolve) => { openRefresh = resolve; });
    fireEvent.click(regenerate);
    await waitFor(() => expect(state.invalidated).toContain("estate.get"));
    state.preflightReport = (input) => ({
      formCode: input.formCode, ok: false, hardBlocked: false,
      gaps: [{ requirementId: "task13_letter_warning", label: "Record a fictional letter detail", missingFields: [], tab: "forms", source: "Letter" }],
    });
    fireEvent.click(screen.getAllByRole("button", { name: "Letter" })[0]);
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Letter to Sam Beneficiary/));
    const checksBefore = state.preflightCalls.length;
    await act(async () => {
      openRefresh();
      await settle();
      await settle();
    });
    expect(state.preflightCalls).toHaveLength(checksBefore);
    expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Letter to Sam Beneficiary/);
    expect(screen.getByTestId("pre-generate-dialog").textContent).not.toMatch(/Ready to generate/i);
    expect(state.generateCalls).toHaveLength(1);
  });

  it("when a refusal replaces the Download button a keyboard user pressed, focus moves to the review action", async () => {
    fetchSpy.mockResolvedValueOnce(refusal(401, "Authentication required"));
    await mountForms();
    await generateP3();
    const retry = await screen.findByTestId("document-generation-download-retry") as HTMLButtonElement;
    await waitFor(() => expect(retry.disabled).toBe(false));
    retry.focus();
    expect(document.activeElement).toBe(retry);
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    fireEvent.click(retry);
    const regenerate = await screen.findByTestId("document-generation-regenerate");
    await waitFor(() => expect(document.activeElement).toBe(regenerate));
  });

  it("overlapping generations of one form never attach the wrong choices to a refused link", async () => {
    state.holdGenerations = 2;
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE)).mockResolvedValueOnce(p3Docx());
    await mountForms();
    for (const expected of [1, 2]) {
      fireEvent.click(screen.getByTestId("form-generate-P3"));
      const details = await screen.findByTestId("form-details-generate").catch(() => null);
      if (details) fireEvent.click(details);
      await waitFor(() => expect(state.generateCalls).toHaveLength(expected));
    }
    // The first settles while the second is still in flight: its refused link gets no replay at all.
    state.heldGenerations[0]();
    await waitFor(() => expect(recoveryPanel().textContent).toContain(`P3 — ${STALE}`));
    expect(screen.queryByTestId("document-generation-regenerate")).toBeNull();
    state.heldGenerations[1]();
    await waitFor(() => expect(anchorClicks).toHaveLength(1));
  });

  it("a review checks the date its dialog's own check used, even if the Signature Date field changed meanwhile", async () => {
    let releaseCheck: () => void = () => undefined;
    state.preflightReport = (input) => new Promise((resolve) => {
      releaseCheck = () => resolve({
        formCode: input.formCode, ok: false, hardBlocked: false,
        gaps: [{ requirementId: "task13_warning", label: "Record a fictional detail", missingFields: [], tab: "forms", source: "Form P3" }],
      });
    });
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    fireEvent.click(screen.getByTestId("form-generate-P3"));
    const details = await screen.findByTestId("form-details-generate").catch(() => null);
    if (details) fireEvent.click(details);
    await waitFor(() => expect(state.preflightCalls).toHaveLength(1));
    const checked = String(state.preflightCalls[0].signatureDate);
    // The Forms tab's Signature Date field changes while the check is in flight.
    const field = Array.from(document.querySelectorAll<HTMLInputElement>('input[type="date"]')).find((input) => input.value === checked)!;
    fireEvent.change(field, { target: { value: "2026-12-01" } });
    releaseCheck();
    fireEvent.click(await screen.findByTestId("pre-generate-proceed"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(1));
    expect(state.generateCalls[0].signatureDate).toBe(checked);
    state.preflightReport = null;
    // The modal shows "Document generated!" for 3 s and closes itself; only then can a user reach the panel.
    await waitFor(() => expect(screen.queryByTestId("pre-generate-dialog")).toBeNull(), { timeout: 6000 });
    fireEvent.click(await screen.findByTestId("document-generation-regenerate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    expect(state.preflightCalls.at(-1)).toMatchObject({ formCode: "P3", signatureDate: checked });
  });
});

describe("Task 13 r3 (D13): the forced review shows the choices it will replay", () => {
  it("the P8 stale-link review shows the deponent, the affidavit number as typed and the date sent, with no Signatory line", async () => {
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    fireEvent.click(within(screen.getByTestId("form-row-P8")).getAllByRole("button", { name: "Generate" })[0]);
    fireEvent.change(await screen.findByTestId("form-details-affidavit-ordinal"), { target: { value: "2nd" } });
    fireEvent.change(screen.getByTestId("form-details-date"), { target: { value: "2026-10-01" } });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(1));
    expect(state.generateCalls[0]).toMatchObject({ formCode: "P8", deponentId: "avery", affidavitOrdinal: "2nd", signatureDate: "2026-10-01" });
    fireEvent.click(await screen.findByTestId("p8-download-regenerate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    expect(retainedChoices()).toEqual({
      sentence: RETAINED,
      lines: [["For", avery.name], ["Affidavit number", "2nd"], ["Date", "2026-10-01"]],
    });
  });

  it("with the affidavit number left automatic, the review has no Affidavit number line", async () => {
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    fireEvent.click(within(screen.getByTestId("form-row-P8")).getAllByRole("button", { name: "Generate" })[0]);
    fireEvent.change(await screen.findByTestId("form-details-date"), { target: { value: "2026-10-01" } });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(1));
    expect(state.generateCalls[0]).toMatchObject({ formCode: "P8", deponentId: "avery", signatureDate: "2026-10-01" });
    expect(state.generateCalls[0]).not.toHaveProperty("affidavitOrdinal");
    fireEvent.click(await screen.findByTestId("p8-download-regenerate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    expect(retainedChoices().lines).toEqual([["For", avery.name], ["Date", "2026-10-01"]]);
  });

  it("the review keeps the date the generation sent after the Forms tab's Signature Date changes", async () => {
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    fireEvent.click(screen.getByTestId("form-generate-P3"));
    fireEvent.change(await screen.findByTestId("form-details-date"), { target: { value: "2026-10-01" } });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(1));
    expect(state.generateCalls[0]).toMatchObject({ formCode: "P3", signatureDate: "2026-10-01" });
    const regenerate = await screen.findByTestId("document-generation-regenerate");
    // The Forms tab's own Signature Date field (no label link): the date input holding the generated date.
    const field = Array.from(document.querySelectorAll<HTMLInputElement>('input[type="date"]')).find((input) => input.value === "2026-10-01")!;
    fireEvent.change(field, { target: { value: "2026-12-01" } });
    expect(field.value).toBe("2026-12-01");
    fireEvent.click(regenerate);
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    expect(retainedChoices().lines.filter(([label]) => label === "Date")).toEqual([["Date", "2026-10-01"]]);
  });

  it("a P3 review names the deponent its request sent as selectedContactId", async () => {
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    await generateP3();
    expect(state.generateCalls[0]).toMatchObject({ formCode: "P3", selectedContactId: "jordan" });
    expect(state.generateCalls[0]).not.toHaveProperty("deponentId");
    expect(state.generateCalls[0]).not.toHaveProperty("targetBeneficiaryId");
    fireEvent.click(await screen.findByTestId("document-generation-regenerate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    expect(retainedChoices().lines.filter(([label]) => label === "For")).toEqual([["For", jordan.name]]);
  });

  it("a P1 review shows the signatory its request sent, by the details dialog's own label", async () => {
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    fireEvent.click(screen.getByTestId("form-generate-P1"));
    fireEvent.click(await screen.findByTestId("form-details-signatory"));
    fireEvent.click(await screen.findByRole("option", { name: "Lawyer" }));
    fireEvent.change(screen.getByTestId("form-details-date"), { target: { value: "2026-10-01" } });
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(1));
    expect(state.generateCalls[0]).toMatchObject({ formCode: "P1", signatoryType: "lawyer", signatureDate: "2026-10-01" });
    fireEvent.click(await screen.findByTestId("document-generation-regenerate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    expect(retainedChoices().lines.filter(([label]) => label === "Signatory")).toEqual([["Signatory", "Lawyer"]]);
  });

  it("a primary affidavit's review (P3) says that generating again replaces the current applicant's affidavit (P3 to P7)", async () => {
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    await generateP3();
    fireEvent.click(await screen.findByTestId("document-generation-regenerate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    expect(retainedChoices().sentence).toBe(RETAINED_PRIMARY);
  });

  it("a review with no lines to list (P13) says so: the sentence without \"listed below\", and no list", async () => {
    fetchSpy.mockResolvedValueOnce(refusal(409, STALE));
    await mountForms();
    // P13 is an Optional form here: its popup confirms, then it generates.
    fireEvent.click(screen.getByTestId("form-generate-P13"));
    fireEvent.click(await screen.findByTestId("fix-confirm"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(1));
    expect(state.generateCalls[0]).toMatchObject({ formCode: "P13", signatoryType: "executor" });
    expect(state.generateCalls[0].signatureDate).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    fireEvent.click(await screen.findByTestId("document-generation-regenerate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    expect(retainedChoices()).toEqual({ sentence: RETAINED_EMPTY, lines: [] });
  });

  it("the review names the deponent as the refreshed contacts now record them, keyed by the id the request sent", async () => {
    holdNextFetch();
    await mountForms();
    fireEvent.click(within(screen.getByTestId("form-row-P8")).getAllByRole("button", { name: "Generate" })[0]);
    fireEvent.click(await screen.findByTestId("form-details-generate"));
    await waitFor(() => expect(state.generateCalls).toHaveLength(1));
    expect(state.generateCalls[0]).toMatchObject({ formCode: "P8", deponentId: "avery" });
    await waitFor(() => expect(held).toHaveLength(1));
    // The deponent is renamed (one way a link goes stale), and the server refuses the old link.
    state.contacts = state.contacts.map((contact) => (contact.id === "avery" ? { ...contact, name: "Avery Renamed-Quay" } : contact));
    await answerHeld(refusal(409, STALE));
    fireEvent.click(await screen.findByTestId("p8-download-regenerate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Ready to generate/i));
    expect(retainedChoices().lines.filter(([label]) => label === "For")).toEqual([["For", "Avery Renamed-Quay"]]);
  });

  it("a normal Generate review shows no retained choices", async () => {
    state.preflightReport = (input) => ({
      formCode: input.formCode, ok: false, hardBlocked: false,
      gaps: [{ requirementId: "task13_warning", label: "Record a fictional detail", missingFields: [], tab: "forms", source: "Form P3" }],
    });
    await mountForms();
    fireEvent.click(screen.getByTestId("form-generate-P3"));
    const details = await screen.findByTestId("form-details-generate").catch(() => null);
    if (details) fireEvent.click(details);
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/Missing information for P3/));
    expect(screen.queryByTestId("pre-generate-retained-choices")).toBeNull();
    expect(state.generateCalls).toHaveLength(0);
  });
});

describe("Task 13 r3.2 (D13): retainedChoicesOf, the review's lines read from the request that was sent", () => {
  const date = "2026-10-01";
  it.each([
    ["P8 with a typed affidavit number", { formCode: "P8", deponentId: "avery", affidavitOrdinal: "2nd", signatureDate: date, signatoryType: "executor" }, [["For", avery.name], ["Affidavit number", "2nd"], ["Date", date]]],
    ["P8 with the affidavit number automatic", { formCode: "P8", deponentId: "avery", signatureDate: date, signatoryType: "executor" }, [["For", avery.name], ["Date", date]]],
    ["P19, whose builder never prints the date", { formCode: "P19", signatureDate: date, signatoryType: "executor" }, []],
    ["P13, whose builder never prints the date", { formCode: "P13", signatureDate: date, signatoryType: "executor" }, []],
    ["P1 signed by the lawyer", { formCode: "P1", signatureDate: date, signatoryType: "lawyer" }, [["Date", date], ["Signatory", "Lawyer"]]],
    ["P1 signed by the executor", { formCode: "P1", signatureDate: date, signatoryType: "executor" }, [["Date", date], ["Signatory", "Executor (applicant)"]]],
    ["P2 signed by the lawyer", { formCode: "P2", signatureDate: date, signatoryType: "lawyer" }, [["Date", date], ["Signatory", "Lawyer"]]],
    ["P2 signed by the executor", { formCode: "P2", signatureDate: date, signatoryType: "executor" }, [["Date", date], ["Signatory", "Executor (applicant)"]]],
    ["P44 signed by the lawyer", { formCode: "P44", signatureDate: date, signatoryType: "lawyer" }, [["Date", date], ["Signatory", "Lawyer"]]],
    ["P44 signed by the executor", { formCode: "P44", signatureDate: date, signatoryType: "executor" }, [["Date", date], ["Signatory", "Executor (applicant)"]]],
    ["VSA532 signed by the lawyer: its date and the Lawyer box", { formCode: "VSA532", signatureDate: date, signatoryType: "lawyer" }, [["Date", date], ["Signatory", "Lawyer"]]],
    ["VSA532 with the executor sent: its date, and no Signatory (the box printed depends on the applicant contact)", { formCode: "VSA532", signatureDate: date, signatoryType: "executor" }, [["Date", date]]],
    ["P3 with its deponent sent as selectedContactId", { formCode: "P3", selectedContactId: "jordan", signatureDate: date, signatoryType: "executor" }, [["For", jordan.name], ["Date", date]]],
    ["a LETTER for the recipient sent as targetBeneficiaryId, with its date", { formCode: "LETTER", targetBeneficiaryId: "bene-1", signatureDate: date, signatoryType: "executor" }, [["For", sam.name], ["Date", date]]],
    ["P17 for its renouncer, with its date", { formCode: "P17", deponentId: "ren-1", signatureDate: date, signatoryType: "executor" }, [["For", rowan.name], ["Date", date]]],
    ["PGT_INFO with its date", { formCode: "PGT_INFO", signatureDate: date, signatoryType: "executor" }, [["Date", date]]],
    ["P1 with an unknown signatory", { formCode: "P1", signatureDate: date, signatoryType: "notary" }, [["Date", date]]],
  ])("%s", async (_label, input, lines) => {
    const { retainedChoicesOf } = await import("./EstateDetail");
    expect(retainedChoicesOf(input, [jordan, avery, sam, rowan])).toEqual(lines.map(([label, value]) => ({ label, value })));
  });
});

describe("Task 13: obsolete feedback never reaches the current view", () => {
  it("dismissing the panel removes its live toast; the late result says nothing", async () => {
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    holdNextFetch();
    await mountForms();
    await generateP3();
    await waitFor(() => expect(toast.loading).toHaveBeenCalledWith(PREPARING));
    fireEvent.click(within(recoveryPanel()).getByRole("button", { name: "Dismiss" }));
    expect(toast.dismiss).toHaveBeenCalledWith("t-1");
    await answerHeld(p3Docx());
    await waitFor(() => expect(anchorClicks).toHaveLength(1));
    await settle();
    expect(toast.success).not.toHaveBeenCalled();
    expect(screen.queryByTestId("document-generation-recovery")).toBeNull();
  });

  it("a newer generation of the form replaces the older attempt's feedback", async () => {
    vi.mocked(toast.loading).mockReturnValueOnce("t-old").mockReturnValueOnce("t-new");
    holdNextFetch();
    holdNextFetch();
    await mountForms();
    await generateP3();
    await waitFor(() => expect(held).toHaveLength(1));
    fireEvent.click(screen.getByTestId("form-generate-P3"));
    const details = await screen.findByTestId("form-details-generate").catch(() => null);
    if (details) fireEvent.click(details);
    await waitFor(() => expect(state.generateCalls).toHaveLength(2));
    expect(toast.dismiss).toHaveBeenCalledWith("t-old");
    await waitFor(() => expect(held).toHaveLength(2));
    held.shift()!(p3Docx());
    held.shift()!(p3Docx());
    await waitFor(() => expect(anchorClicks).toHaveLength(2));
    await waitFor(() => expect(toast.success).toHaveBeenCalledTimes(1));
    expect(toast.success).toHaveBeenCalledWith(STARTED, { id: "t-new" });
  });

  it("leaving the Forms tab mid-download drops its feedback", async () => {
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    holdNextFetch();
    const view = await mountForms();
    await generateP3();
    await waitFor(() => expect(held).toHaveLength(1));
    view.unmount();
    expect(toast.dismiss).toHaveBeenCalledWith("t-1");
    await answerHeld(refusal(409, STALE));
    await settle();
    await settle();
    expect(toast.error).not.toHaveBeenCalled();
  });

  it("moving to another estate remounts the Forms tab: this estate's recovery and its late result are gone", async () => {
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    holdNextFetch();
    const FormsTab = await FormsTabComponent();
    // As the estate page does: the tab content is keyed by estate (and tab), so another estate is a new tab.
    const Keyed = ({ estateId }: { estateId: string }) => <FormsTab key={estateId} estateId={estateId} estate={{ ...state.estate, id: estateId }} onNavigateToTab={vi.fn()} />;
    const view = render(<Keyed estateId="estate-19" />);
    await generateP3();
    await waitFor(() => expect(held).toHaveLength(1));
    view.rerender(<Keyed estateId="estate-20" />);
    expect(toast.dismiss).toHaveBeenCalledWith("t-1");
    expect(screen.queryByTestId("document-generation-recovery")).toBeNull();
    await answerHeld(p3Docx());
    await waitFor(() => expect(anchorClicks).toHaveLength(1));
    await settle();
    expect(toast.success).not.toHaveBeenCalled();
    expect(screen.queryByTestId("document-generation-recovery")).toBeNull();
  });

  it("a token rotation mid-download shows the attempt's error in place of the loading toast, and the panel keeps its Download button", async () => {
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    holdNextFetch();
    await mountForms();
    await generateP3();
    await waitFor(() => expect(held).toHaveLength(1));
    // Task 13 r3 (D12): the tab's token rotates; its session did not end.
    sessionStorage.setItem("manus-cookie", `app_session_id=${TOKEN_B}`);
    await answerHeld(p3Docx());
    const retry = screen.getByTestId("document-generation-download-retry") as HTMLButtonElement;
    await waitFor(() => expect(retry.disabled).toBe(false));
    await settle();
    expect(toast.error).toHaveBeenCalledWith(GENERIC, { id: "t-1" });
    expect(toast.error).toHaveBeenCalledTimes(1);
    expect(toast.dismiss).not.toHaveBeenCalled();
    expect(toast.success).not.toHaveBeenCalled();
    expect(anchorClicks).toEqual([]);
    expect(retry.isConnected).toBe(true);
    expect(retry.textContent).toMatch(/Download P3/);
  });

  it("ending the session mid-download stays silent: no error and no success", async () => {
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    holdNextFetch();
    await mountForms();
    await generateP3();
    await waitFor(() => expect(held).toHaveLength(1));
    clearFallbackSession();
    await answerHeld(p3Docx());
    await waitFor(() => expect(toast.dismiss).toHaveBeenCalledWith("t-1"));
    await settle();
    expect(toast.error).not.toHaveBeenCalled();
    expect(toast.success).not.toHaveBeenCalled();
    expect(anchorClicks).toEqual([]);
  });

  it("an unmount between the handoff and the dispatch announces nothing", async () => {
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    fetchSpy.mockResolvedValueOnce(p3Docx());
    const view = await mountForms();
    vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(function (this: HTMLAnchorElement) {
      anchorClicks.push({ href: this.href, download: this.download });
      view.unmount();
    });
    await generateP3();
    await waitFor(() => expect(anchorClicks).toHaveLength(1));
    await settle();
    expect(toast.success).not.toHaveBeenCalled();
    expect(toast.dismiss).toHaveBeenCalledWith("t-1");
  });

  it("closing the preview mid-download drops its result", async () => {
    const { FormPreviewModal } = await import("./EstateDetail");
    holdNextFetch();
    let outcome: Promise<string> | null = null;
    const props = {
      estateId: "estate-19", formCode: "P3", formName: "Affidavit of Applicant for Grant of Probate", signatoryType: "executor",
      signatureDate: "2026-09-06", onOpenChange: vi.fn(),
      runWithPreflight: (async (_codes: string[], _name: string, doMutate: () => unknown) => {
        outcome = Promise.resolve(doMutate()).then(() => "resolved", () => "rejected");
        return true;
      }) as any,
    };
    const view = render(<FormPreviewModal {...props} open={true} />);
    fireEvent.click(screen.getByTestId("preview-download-docx"));
    await waitFor(() => expect(held).toHaveLength(1));
    view.rerender(<FormPreviewModal {...props} open={false} />);
    await answerHeld(attachment(zipBytes, "application/zip", "P3_Calder-Quay_1.zip"));
    await waitFor(() => expect(outcome).not.toBeNull());
    await expect(outcome!).resolves.toBe("resolved");
    expect(anchorClicks).toHaveLength(1);
    expect(toast.success).not.toHaveBeenCalled();
    expect(toast.error).not.toHaveBeenCalled();
  });

  it("a session the generate response rotated still hears the preview's result", async () => {
    const { FormPreviewModal } = await import("./EstateDetail");
    // As a rotated-session response header does: the stored token changes while the document is generated.
    state.onGenerate = () => { sessionStorage.setItem("manus-cookie", `app_session_id=${TOKEN_B}`); };
    fetchSpy.mockResolvedValueOnce(p3Docx());
    let outcome: Promise<string> | null = null;
    render(<FormPreviewModal
      estateId="estate-19" formCode="P3" formName="Affidavit of Applicant for Grant of Probate" signatoryType="executor"
      signatureDate="2026-09-06" open={true} onOpenChange={vi.fn()}
      runWithPreflight={(async (_codes: string[], _name: string, doMutate: () => unknown) => {
        outcome = Promise.resolve(doMutate()).then(() => "resolved", () => "rejected");
        return true;
      }) as any}
    />);
    fireEvent.click(screen.getByTestId("preview-download-docx"));
    await waitFor(() => expect(outcome).not.toBeNull());
    await expect(outcome!).resolves.toBe("resolved");
    expect(((fetchSpy.mock.calls[0]?.[1] as RequestInit).headers as Record<string, string>).Authorization).toBe(`Bearer ${TOKEN_B}`);
    expect(toast.success).toHaveBeenCalledWith("DOCX download started.");
  });
});

describe("Task 13 r3 (D11): feedback survives a tab switch within the estate", () => {
  it("switching tabs during a held download keeps its loading toast, and the release announces the download under that id", async () => {
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    holdNextFetch();
    const page = await mountEstatePage();
    await generateP3();
    await waitFor(() => expect(held).toHaveLength(1));
    page.showTab("notes");
    expect(screen.queryByTestId("form-generate-P3")).toBeNull();
    await answerHeld(p3Docx());
    await waitFor(() => expect(anchorClicks).toHaveLength(1));
    await settle();
    expect(toast.dismiss).not.toHaveBeenCalled();
    expect(toast.success).toHaveBeenCalledWith(STARTED, { id: "t-1" });
  });

  it("a generation still pending when the Forms tab unmounts is announced when it finishes: the loading toast, then the download started", async () => {
    state.holdGenerations = 1;
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    fetchSpy.mockResolvedValueOnce(p3Docx());
    const page = await mountEstatePage();
    await generateP3();
    page.showTab("notes");
    state.heldGenerations[0]();
    await waitFor(() => expect(anchorClicks).toHaveLength(1));
    await settle();
    expect(toast.loading).toHaveBeenCalledWith(PREPARING);
    expect(toast.success).toHaveBeenCalledWith(STARTED, { id: "t-1" });
  });

  it("after switching away and back, the old Forms instance's late result never silences the new instance's attempt in the same slot", async () => {
    state.holdGenerations = 1;
    vi.mocked(toast.loading).mockReturnValueOnce("t-new").mockReturnValueOnce("t-old");
    holdNextFetch();
    holdNextFetch();
    const page = await mountEstatePage();
    // The old instance's generation is held; switching away and back mounts a new instance.
    await generateP3();
    page.showTab("notes");
    page.showTab("forms");
    fireEvent.click(screen.getByTestId("form-generate-P3"));
    const details = await screen.findByTestId("form-details-generate").catch(() => null);
    if (details) fireEvent.click(details);
    await waitFor(() => expect(state.generateCalls).toHaveLength(2));
    await waitFor(() => expect(held).toHaveLength(1));
    // The old instance's generation finishes late and starts its own download in a slot of the same name.
    state.heldGenerations[0]();
    await waitFor(() => expect(held).toHaveLength(2));
    held.shift()!(p3Docx());
    held.shift()!(p3Docx());
    await waitFor(() => expect(anchorClicks).toHaveLength(2));
    await settle();
    expect(toast.dismiss).not.toHaveBeenCalled();
    expect(toast.success).toHaveBeenCalledWith(STARTED, { id: "t-new" });
    expect(toast.success).toHaveBeenCalledWith(STARTED, { id: "t-old" });
    expect(toast.success).toHaveBeenCalledTimes(2);
  });

  it("moving to another estate while a generation is held: once that estate is shown, the late result says nothing (AnimatePresence mode=wait)", async () => {
    state.holdGenerations = 1;
    fetchSpy.mockResolvedValueOnce(p3Docx());
    const page = await mountAnimatedEstatePage("estate-19");
    await generateP3();
    page.showEstate("estate-20");
    // jsdom runs the 0.2 s exit in real time: estate-19's tab leaves, then estate-20's is shown.
    await waitFor(() => {
      expect(screen.queryByTestId("estate-tab-estate-19")).toBeNull();
      expect(screen.getByTestId("estate-tab-estate-20")).toBeTruthy();
    });
    state.heldGenerations[0]();
    // Feedback cleanup is not cancellation: the browser still receives the file.
    await waitFor(() => expect(anchorClicks).toHaveLength(1));
    await settle();
    expect(toast.loading).not.toHaveBeenCalled();
    expect(toast.success).not.toHaveBeenCalled();
    expect(toast.error).not.toHaveBeenCalled();
  });

  it("moving to another estate while a download is held: its loading toast is gone once that estate is shown, and the late result says nothing (AnimatePresence mode=wait)", async () => {
    vi.mocked(toast.loading).mockReturnValueOnce("t-1");
    holdNextFetch();
    const page = await mountAnimatedEstatePage("estate-19");
    await generateP3();
    await waitFor(() => expect(held).toHaveLength(1));
    page.showEstate("estate-20");
    await waitFor(() => {
      expect(screen.queryByTestId("estate-tab-estate-19")).toBeNull();
      expect(screen.getByTestId("estate-tab-estate-20")).toBeTruthy();
    });
    const dismissedWhenShown = vi.mocked(toast.dismiss).mock.calls.map(([id]) => id);
    await answerHeld(p3Docx());
    await waitFor(() => expect(anchorClicks).toHaveLength(1));
    await settle();
    expect(dismissedWhenShown).toEqual(["t-1"]);
    expect(toast.success).not.toHaveBeenCalled();
    expect(toast.error).not.toHaveBeenCalled();
  });
});

describe("Task 13 r3.1 (D11): the Notes tab's export feedback survives a tab switch", () => {
  it("an export refused after the Notes tab unmounts still shows its error, through the estate page's owner", async () => {
    const { NotesTab } = await import("./EstateDetail");
    expect(NotesTab).toBeTypeOf("function");
    const sentence = "Request limit reached for this action. Please wait a moment and try again.";
    function EstatePage({ tab }: { tab: "notes" | "forms" }) {
      const estateFeedback = useDeliveryFeedbackOwner("estate:estate-19");
      return tab === "notes"
        ? <NotesTab estateId="estate-19" estate={state.estate} feedbackOwner={estateFeedback} />
        : <p data-testid="estate-forms-tab">Forms</p>;
    }
    holdNextFetch();
    const view = render(<EstatePage tab="notes" />);
    fireEvent.click(screen.getByRole("button", { name: "Export PDF" }));
    await waitFor(() => expect(held).toHaveLength(1));
    view.rerender(<EstatePage tab="forms" />);
    expect(screen.queryByRole("button", { name: "Export PDF" })).toBeNull();
    await answerHeld(refusal(429, sentence));
    await waitFor(() => expect(toast.error).toHaveBeenCalledWith(sentence));
    expect(toast.error).toHaveBeenCalledTimes(1);
    expect(toast.dismiss).not.toHaveBeenCalled();
    expect(fetchSpy.mock.calls[0]?.[0]).toBe("/api/notes/export-pdf");
  });
});

describe("Task 13: cleanup survives a failing toast (Forms tab)", () => {
  it("a throwing loading toast leaves the generation successful and the delivery delivered", async () => {
    vi.mocked(toast.loading).mockImplementationOnce(() => { throw new Error("toaster unavailable"); });
    fetchSpy.mockResolvedValueOnce(p3Docx());
    await mountForms();
    await generateP3();
    await waitFor(() => expect(anchorClicks).toHaveLength(1));
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    expect(recoveryPanel().textContent).toMatch(/P3 is ready/);
    expect(recoveryPanel().textContent).not.toMatch(/not generated/i);
    expect(toast.error).not.toHaveBeenCalled();
  });
});
