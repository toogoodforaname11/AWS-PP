import * as React from "react";
import { trpc } from "@/lib/trpc";
import { cn, downloadFromUrl, previewStoredFile } from "@/lib/utils";
import { deliverAndAnnounce, deliverAttachment, fetchDeliveryAttachment, unusableLinkMessage, useDeliveryFeedbackOwner, useDeliveryPending, useEstateFeedbackOwner, type DeliveryFeedback, type DeliveryFeedbackOwner, type DeliveryOutcome } from "@/lib/attachmentDelivery";
import { isPostDelivery, type PostDelivery } from "@shared/postDelivery";
import { PRIMARY_AFFIDAVIT_FORMS } from "@shared/const";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Collapsible, CollapsibleTrigger, CollapsibleContent } from "@/components/ui/collapsible";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Plus, Trash2, Download, FileText, Package, Check, CheckCircle2, AlertTriangle, XCircle, Upload, Pencil, Eye, Printer, GripVertical, ChevronDown, X, Search, Lightbulb, Info, Bookmark, History, Copy, Pin, PinOff, Send, MoreVertical, Paperclip, Image, FileDown, Tag, Clock, Calendar, ShieldCheck, CircleAlert, CircleCheck, ZoomIn, ZoomOut, Maximize2, Minimize2, Sparkles, Loader2 } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { motion, AnimatePresence } from "framer-motion";
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors, type DragEndEvent } from "@dnd-kit/core";
import { arrayMove, SortableContext, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { useLocation, useParams, useSearch } from "wouter";
import { toast } from "sonner";
import { applyElectronicWillAxis, applicantContactVsaDetails, coupleWillFilingTypeFacts, electronicWillFacts, estateHasNoWillOfRecord, estateWillStatus, formatMoney, FORM_CATALOG, REQUIRED_DOCUMENTS, requiredDocumentsForEstate, shouldUseP4, normalizeGrantType, normalizeWillIssues, requiresPGT, grantPackageCodes, formStatus, validateAdminWithWillEligibility, contactHasRole, contactRoles, isAncillary, isApplyingApplicant, isP1NoticeRequired, p1NoticeRecipients, requiresForeignGrantCopy, requiresSeparateWillCopy, primaryApplicantAffidavitForm, p8ApplyingCoApplicants, primaryAffidavitDeponentFromDocuments, findPrimaryApplicant, probateItemValue, isInventoryValueRecorded, isCreditorContact, isExecutorContact, isSupplementalDisclosure, passesToPersonalRepresentative, isDescendantContact, isSpouseCandidate, isMarriageLikeRelationship, sideOf, readsFamilySide, isSpouseSeparated, recipientMayNeedRepresentativeDelivery, isLivingContact, isConsentAdministratorCandidate, isDeterminedOneHalfResidueDescendantShare } from "../../../shared/types";
import type { FormStatus, FormApplicability } from "../../../shared/types";
import type { ReadinessTab } from "../../../shared/types";
import { parseP16LegacyLocation } from "../../../shared/p16Location";
import { normalizeContactRelationshipForPicker } from "../../../shared/contactRelationshipPicker";
import { P16_ALTERATION_WORDS_MAX_LENGTH } from "../../../shared/formOverrides";
import { PreGenerateDialog, type P1InlineActions, type PreGenerateRowEdits } from "@/components/PreGenerateDialog";
import type { CanonicalPopupApplyObserver } from "@/components/CanonicalPopupFields";
import { TriToggle } from "@/components/TriToggle";
import { FormDetailsDialog, FORM_DETAILS } from "@/components/FormDetailsDialog";
import { FixApplicabilityDialog, applicabilityLabel } from "@/components/FixApplicabilityDialog";
import { P8CoApplicantIntakeDialog } from "@/components/P8CoApplicantIntakeDialog";
import { FORMS_TAB_EXCLUDED_FORMS } from "../../../shared/applicabilityQuestions";
import { CitationTracker, PgtDocumentDeliveryTracker } from "@/components/CanonicalLegalEvents";
import { codicilUploadShortfall } from "../../../shared/formRequirements";
import type { FormGapReport } from "../../../shared/formRequirements";
import { AddressAutocomplete } from "@/components/AddressAutocomplete";
import { formatPhone, formatCurrency, parseCurrencyToNumber, parseCurrencyToCents, formatCourtFileNumber } from "@/lib/formatters";
import { grantTypeLabel, deliveryMethodLabel, fmtDisplayDate, roleLabel, shortcutLabel } from "@/lib/labels";
import { hydrateInventoryItemForEdit, inventoryEffectiveValueInput, inventoryValueRecordedFromForm, realPropertyFmvInput, updateInventoryValueInput, updateRealPropertyFmvInput } from "@/lib/inventoryValue";
import { createInventorySpreadsheetTemplate, inventorySpreadsheetRowsToItems, validateSpreadsheetInventoryItem } from "@/lib/inventorySpreadsheet";
import type { SpreadsheetInventoryItem } from "@/lib/inventorySpreadsheet";
import { readFirstXlsxWorksheetRows, XLSX_MIME_TYPE } from "@/lib/xlsxWorkbook";
import { useLocalDraft, clearLocalDraft } from "@/hooks/useLocalDraft";
import { useFormFocusedIntakePreference } from "@/hooks/useFormFocusedIntakePreference";
import { todayIn } from "../../../shared/date-utils";
import { renderPrintDocument } from "@/lib/printDocument";
import { previewErrorMessage, previewQueryKeyHash, previewRetry } from "@/lib/previewTransport";
import { codicilClearIndices } from "@/lib/codicilBatch";
import { moveCodicilOrder } from "@/lib/codicilOrder";
import { FileDropZone, IDLE_UPLOAD_FEEDBACK, UploadFeedback, fileTooLargeMessage, invalidFileTypeMessage, type UploadFeedbackState } from "@/components/UploadFeedback";
import { CodicilFactsCard, type CodicilFacts } from "@/components/CodicilExtractionFacts";
import { EstateClientPortal } from "@/components/EstateClientPortal";
import { CodicilReorderControls } from "@/components/CodicilReorderControls";
import { EstateAccessRecovery } from "@/components/EstateAccessRecovery";

function normalizeAlias(value: string) {
  return value.trim().replace(/\s+/g, " ").toLocaleLowerCase();
}

/**
 * Does the WESA s.22 multi-spouse guidance card apply to this file?
 *
 * Exported so the rule is stated once and testable. The card was gated on
 * `isIntestacy` alone — which is `admin_no_will` and nothing else — so it was
 * hidden on partial-intestacy files, the very class that needs it: the
 * intestate portion of a s.25 estate runs through the same s.22 spousal-share
 * logic, and unrecorded portions blank the spousal rows there identically.
 *
 * Third time a client-side predicate has drifted from the engine it mirrors
 * (after the s.2(1)(b) spouse gate and the Family Side control), so this one is
 * a named rule with a test rather than an inline expression.
 */
export function showsMultiSpouseGuidance(
  opts: {
    isIntestacy: boolean;
    isPartialIntestacy: boolean;
    spouseCount: number;
    /** WESA s.2(2)(a) — the estate-level separation that divests EVERY spouse.
     *  The engine's own spouse set carries this term (`spouseEligible`), the
     *  client's `isSpouseCandidate` does not, and taking a bare count would
     *  have baked that last drift axis into the very rule written to stop it:
     *  a separated file with two partners got an amber card asserting "this
     *  estate has 2 spouses per WESA s.2" and telling the user to record
     *  portions, on a file the engine escheats whole to the Crown. */
    isSeparated: boolean;
  },
): boolean {
  if (opts.isSeparated) return false;
  return (opts.isIntestacy || opts.isPartialIntestacy) && opts.spouseCount > 1;
}

export const WESA_S130_PRIORITY_OPTIONS = [
  { value: "a", shortLabel: "Spouse or spouse's nominee", label: "(a) the spouse of the deceased person or a person nominated by the spouse" },
  { value: "b", shortLabel: "Child — majority consent", label: "(b) a child of the deceased person having the consent of a majority of the children of the deceased person" },
  { value: "c", shortLabel: "Child nominee — majority consent", label: "(c) a person nominated by a child of the deceased person if that person has the consent of a majority of the deceased person's children" },
  { value: "d", shortLabel: "Child — no majority consent", label: "(d) a child of the deceased person not having the consent of a majority of the deceased person's children" },
  { value: "e", shortLabel: "Other successor — majority consent", label: "(e) an intestate successor other than the spouse or child of the deceased person, having the consent of the intestate successors representing a majority in interest of the estate, including the intestate successor who applies for a grant of administration" },
  { value: "e.1", shortLabel: "Successor's nominee — majority consent", label: "(e.1) a person, other than the spouse or child of the deceased person, nominated by an intestate successor of the deceased person if that person has the consent of the intestate successors representing a majority in interest of the estate, including the intestate successor who nominated the person to apply for a grant of administration" },
  { value: "f", shortLabel: "Other successor — no majority consent", label: "(f) an intestate successor other than the spouse or child of the deceased person, not having the consent of the intestate successors representing a majority in interest of the estate, including the intestate successor who applies for a grant of administration" },
  { value: "f.1", shortLabel: "Government nominee (Escheat)", label: "(f.1) in the case of a deceased person whose estate would pass to the government and would be subject to the Escheat Act, a person nominated by the government" },
  { value: "g", shortLabel: "Other court-appointed person", label: "(g) any other person the court considers appropriate to appoint, including, without limitation, and subject to the Public Guardian and Trustee's consent, the Public Guardian and Trustee" },
] as const;

export const WESA_S80_OPTIONS = [
  { value: "a", label: "(a) with the law of the place where the will is made," },
  { value: "b", label: "(b) with the law of the will-maker's domicile, either at the date the will is made or at the date of the will-maker's death," },
  { value: "c", label: "(c) with the law of the will-maker's ordinary residence, either at the date the will is made or at the date of the will-maker's death," },
  { value: "d", label: "(d) with the law of a country of which the will-maker was a citizen, either at the date the will is made or at the date of the will-maker's death," },
  { value: "e", label: "(e) with the law of British Columbia, but the will is made outside British Columbia," },
  { value: "f", label: "(f) with the law of the place where the will-maker's property is situated at the date the will is made or at the date of the will-maker's death," },
  { value: "g", label: "(g) in the case of a will made on board a vessel or aircraft of any description, with the law of the place with which, having regard to the registration, if any, of a vessel or aircraft, the vessel or aircraft is most closely connected, or" },
  { value: "h", label: "(h) to the extent that the will exercises a power of appointment, with the law governing the essential validity of that power." },
] as const;

type IntakeGuidance = {
  label: string;
  children: React.ReactNode;
  className?: string;
  markerClassName?: string;
  testId?: string;
};

function IntakeGuidanceTooltip({
  label,
  children,
  className,
  markerClassName,
  testId,
}: IntakeGuidance) {
  const [usesTouchTrigger, setUsesTouchTrigger] = useState(false);
  const [touchOpen, setTouchOpen] = useState(false);

  return (
    <span className={cn("inline-flex shrink-0 align-middle", className)}>
      <Tooltip
        delayDuration={360}
        skipDelayDuration={160}
        open={usesTouchTrigger ? touchOpen : undefined}
        onOpenChange={(nextOpen) => {
          if (usesTouchTrigger) setTouchOpen(nextOpen);
        }}
      >
        <TooltipTrigger asChild>
          <button
            type="button"
            className={cn(
              "intake-info-tooltip-marker inline-flex h-7 w-7 items-center justify-center rounded-full text-muted-foreground transition-[background-color,color,transform] duration-150 ease-out hover:bg-primary/[0.08] hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/35 focus-visible:ring-offset-2",
              markerClassName,
            )}
            aria-label={`More information about ${label}`}
            aria-expanded={usesTouchTrigger ? touchOpen : undefined}
            data-testid={testId}
            onPointerEnter={(event) => {
              if (event.pointerType === "mouse" && usesTouchTrigger) {
                setUsesTouchTrigger(false);
                setTouchOpen(false);
              }
            }}
            onPointerDown={(event) => {
              if (event.pointerType !== "mouse") {
                event.preventDefault();
                setUsesTouchTrigger(true);
                setTouchOpen((open) => !open);
              }
            }}
          >
            <Info className="relative z-10 h-4 w-4" aria-hidden="true" />
          </button>
        </TooltipTrigger>
        <TooltipContent
          side="bottom"
          align="start"
          sideOffset={8}
          className="z-[70] w-[min(24rem,calc(100vw-2rem))] rounded-xl border border-foreground/15 bg-popover px-3 py-2.5 text-xs font-medium leading-relaxed text-popover-foreground shadow-[0_12px_32px_-12px_color-mix(in_oklab,var(--foreground)_34%,transparent)] ring-1 ring-background/35 [&>svg]:!bg-popover [&>svg]:!fill-popover"
        >
          <div role="note">
            {children}
          </div>
        </TooltipContent>
      </Tooltip>
    </span>
  );
}

export function P5TestamentaryDocumentFields({
  status,
  description,
  onChange,
}: {
  status: string;
  description: string;
  onChange: (patch: { testamentaryDocStatus?: string; laterTestamentaryDescription?: string }) => void;
}) {
  return (
    <div className="space-y-2" data-testid="p5-testamentary-document-fields">
      <Label className="text-xs font-medium text-muted-foreground">Form P5 §4 — After a diligent search, was any testamentary document of the deceased found?</Label>
      <div className="space-y-2 pl-1">
        <label className="flex items-start gap-2 cursor-pointer">
          <input type="radio" name="p5TestamentaryDocStatus" checked={status === "none_found"} onChange={() => onChange({ testamentaryDocStatus: "none_found" })} className="mt-0.5" />
          <span className="text-xs">No testamentary document of the deceased has been found.</span>
        </label>
        <label className="flex items-start gap-2 cursor-pointer">
          <input type="radio" name="p5TestamentaryDocStatus" checked={status === "found"} onChange={() => onChange({ testamentaryDocStatus: "found" })} className="mt-0.5" />
          <span className="text-xs">One or more testamentary documents have been found.</span>
        </label>
      </div>
      {status === "found" && (
        <div className="space-y-1 pl-4">
          <Label className="text-xs">Why the testamentary document is invalid or not relevant</Label>
          <Textarea value={description} onChange={(event) => onChange({ laterTestamentaryDescription: event.target.value })} className="min-h-[60px] text-xs" placeholder="Briefly state the reasons." />
          <p className="text-[10px] text-muted-foreground">A copy of each testamentary document found is attached as an exhibit to the affidavit.</p>
        </div>
      )}
    </div>
  );
}

/* ─── Address formatting helpers (mirror docgen logic for revert-to-auto) ─── */
function titleCaseAddr(s: string): string {
  if (!s) return s;
  return s.replace(/\b\w/g, ch => ch.toUpperCase());
}
function upperProvinceAddr(s: string): string {
  if (!s) return s;
  return s.length <= 3 ? s.toUpperCase() : titleCaseAddr(s);
}
function upperPostalCodeAddr(s: string): string {
  if (!s) return s;
  const upper = s.replace(/\s/g, "").toUpperCase();
  if (upper.length === 6 && /^[A-Z]\d[A-Z]\d[A-Z]\d$/.test(upper)) {
    return upper.slice(0, 3) + " " + upper.slice(3);
  }
  return upper;
}

export default function EstateDetail() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const estateId = params.id!;

  const { data: estate, isLoading, isError } = trpc.estate.get.useQuery(
    { id: estateId },
    { retry: false },
  );
  const { data: settings } = trpc.settings.get.useQuery();
  const formFocusedIntake = useFormFocusedIntakePreference(settings?.formFocusedIntake);

  if (isLoading) return <div className="flex items-center justify-center py-20"><div className="h-8 w-8 border-2 border-primary border-t-transparent rounded-full animate-spin" /></div>;
  if (isError || !estate) return <EstateAccessRecovery onBack={() => setLocation("/")} />;

  const name = estate.estateName || [estate.deceasedFirstName, estate.deceasedMiddleNames, estate.deceasedSecondMiddleName, estate.deceasedLastName].filter(Boolean).join(" ") || "Untitled Estate";
  const workspaceLabel = estate.fileType === "probate_only"
    ? "Probate file"
    : estate.fileType === "full_admin"
      ? "Estate administration workspace"
      : estate.fileType === "intestacy"
        ? "Legacy intestacy file"
        : estate.fileType.replace(/_/g, " ");

  return (
    <div className="estate-workspace min-w-0 space-y-4">
      <motion.div
        className="flex flex-wrap items-start gap-3 p-3 -mx-3 rounded-xl sm:flex-nowrap sm:items-center"
        initial={{ opacity: 0, x: -8 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] }}
      >
        <Button variant="ghost" size="sm" onClick={() => setLocation("/")} className="shrink-0 active:scale-[0.97] transition-transform">
          Back
        </Button>
        <div className="min-w-[12rem] flex-1">
          <div className="flex min-w-0 flex-wrap items-start gap-2 sm:items-center">
            <h1 className="min-w-0 break-words text-xl font-semibold tracking-tight">#{estate.fileNumber} — {name}</h1>
            <GrantTypeBadge estate={estate} estateId={estateId} />
          </div>
          <p className="break-words text-xs text-muted-foreground">{estate.registry} Registry · {workspaceLabel}</p>
        </div>
        <div className="ml-auto shrink-0 sm:ml-0">
          <StatusDropdown estateId={estateId} currentStatus={estate.status} revision={estate.revision} />
        </div>
      </motion.div>

      {/* ─── Name Review Banner ─── */}
      {!!estate.needsNameReview && !estate.deceasedFirstName && !estate.deceasedLastName && (
        <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-800 dark:bg-amber-950/30 dark:border-amber-800 dark:text-amber-300">
          <AlertTriangle className="h-4 w-4 shrink-0" />
          <span><strong>Name review needed:</strong> First name / surname was auto-split from a full name. Please verify the split in the Intake tab and save to dismiss this banner.</span>
        </div>
      )}

      {showsFullWorkspaceWorkflow(formFocusedIntake) && <FilingTimeline estateId={estateId} revision={estate.revision} />}

      <AnimatedTabs estateId={estateId} estate={estate} formFocusedIntake={formFocusedIntake} />
    </div>
  );
}

// ─── FILING TIMELINE ────────────────────────────────────────────────────────────
const TIMELINE_STEPS = [
  { key: "p1FirstDeliveryDate", label: "First P1 Delivery" },
  { key: "p1LastDeliveryDate", label: "Last P1 Delivery" },
  { key: "p2FiledDate", label: "P2 Filed" },
  { key: "p10FiledDate", label: "P10 Filed" },
  { key: "p11FiledDate", label: "P11 Filed" },
  { key: "grantIssuedDate", label: "Grant Issued" },
] as const;

function FilingTimeline({ estateId, revision }: { estateId: string; revision: number }) {
  const { data: timeline } = trpc.readiness.timeline.useQuery({ estateId });
  const [editOpen, setEditOpen] = useState(false);
  const utils = trpc.useUtils();
  const updateMutation = trpc.estate.update.useMutation({
    onSuccess: () => {
      void utils.readiness.check.invalidate({ estateId });
      void utils.readiness.timeline.invalidate({ estateId });
      void utils.deadline.list.invalidate();
      void utils.estate.list.invalidate();
      void utils.document.preflight.invalidate();
      void utils.document.preflightMany.invalidate();
      void utils.estate.get.invalidate({ id: estateId });
      toast.success("Filing dates updated");
    },
  });
  const [editForm, setEditForm] = useState<Record<string, string>>({});

  if (!timeline) return null;

  // Check if any dates are set
  const hasAnyDate = TIMELINE_STEPS.some(s => (timeline as any)[s.key]);
  if (!hasAnyDate && !editOpen) {
    return (
      <Collapsible>
        <CollapsibleTrigger className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
          <Calendar className="h-3.5 w-3.5" />
          <span>Filing Timeline</span>
          <ChevronDown className="h-3 w-3" />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-2">
          <div className="flex items-center gap-2">
            <p className="text-xs text-muted-foreground italic">No filing dates recorded yet.</p>
            <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => { setEditForm(timeline); setEditOpen(true); }}>
              <Pencil className="h-3 w-3 mr-1" /> Set dates
            </Button>
          </div>
        </CollapsibleContent>
      </Collapsible>
    );
  }

  const completedCount = TIMELINE_STEPS.filter(s => (timeline as any)[s.key]).length;

  return (
    <>
      <Collapsible defaultOpen={completedCount > 0 && completedCount < TIMELINE_STEPS.length}>
        <CollapsibleTrigger className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
          <Calendar className="h-3.5 w-3.5" />
          <span>Filing Timeline ({completedCount}/{TIMELINE_STEPS.length})</span>
          <ChevronDown className="h-3 w-3" />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-2">
          <div className="flex items-start gap-3">
            <div className="flex flex-col items-center">
              {TIMELINE_STEPS.map((step, i) => {
                const dateVal = (timeline as any)[step.key];
                const isSet = !!dateVal;
                return (
                  <div key={step.key} className="flex flex-col items-center">
                    <div className={`w-2.5 h-2.5 rounded-full border-2 ${
                      isSet ? "bg-emerald-500 border-emerald-500" : "bg-background border-muted-foreground/40"
                    }`} />
                    {i < TIMELINE_STEPS.length - 1 && (
                      <div className={`w-0.5 h-5 ${
                        isSet && (timeline as any)[TIMELINE_STEPS[i + 1].key] ? "bg-emerald-500" : "bg-muted-foreground/20"
                      }`} />
                    )}
                  </div>
                );
              })}
            </div>
            <div className="flex flex-col gap-[7px] -mt-0.5">
              {TIMELINE_STEPS.map((step) => {
                const dateVal = (timeline as any)[step.key];
                return (
                  <div key={step.key} className="flex items-center gap-2 h-[18px]">
                    <span className={`text-xs ${dateVal ? "text-foreground font-medium" : "text-muted-foreground"}`}>
                      {step.label}
                    </span>
                    {dateVal && (
                      <span className="text-[10px] text-muted-foreground">
                        {fmtDisplayDate(dateVal)}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
          <Button variant="ghost" size="sm" className="h-6 text-xs mt-2" onClick={() => { setEditForm(timeline); setEditOpen(true); }}>
            <Pencil className="h-3 w-3 mr-1" /> Edit dates
          </Button>
        </CollapsibleContent>
      </Collapsible>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-sm">Set Filing Dates</DialogTitle>
            <DialogDescription className="sr-only">Record the P2/P10/P11 filed dates and the grant-issued date</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            {TIMELINE_STEPS.filter(s => ["p2FiledDate", "p10FiledDate", "p11FiledDate", "grantIssuedDate"].includes(s.key)).map((step) => (
              <div key={step.key} className="space-y-1">
                <Label className="text-xs">{step.label}</Label>
                <Input
                  type="date"
                  value={(editForm as any)[step.key] || ""}
                  onChange={(e) => setEditForm(prev => ({ ...prev, [step.key]: e.target.value }))}
                  className="h-8 text-xs"
                />
              </div>
            ))}
            <p className="text-[10px] text-muted-foreground italic">
              Wills search and delivery dates are computed automatically from their respective records.
            </p>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="ghost" size="sm" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button size="sm" onClick={() => {
              updateMutation.mutate({
                id: estateId,
                expectedRevision: revision,
                data: {
                  p2FiledDate: editForm.p2FiledDate || "",
                  p10FiledDate: editForm.p10FiledDate || "",
                  p11FiledDate: editForm.p11FiledDate || "",
                  grantIssuedDate: editForm.grantIssuedDate || "",
                },
              });
              setEditOpen(false);
            }}>Save</Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

// ─── STATUS DROPDOWN (quick status change from header) ────────────────
const STATUS_OPTIONS = [
  { value: "intake", label: "Intake", color: "bg-sky-50 text-sky-700 border-sky-200 dark:bg-sky-950/30 dark:text-sky-300 dark:border-sky-800" },
  { value: "incomplete", label: "Incomplete", color: "bg-slate-50 text-slate-700 border-slate-200 dark:bg-slate-900/50 dark:text-slate-200 dark:border-slate-700" },
  { value: "ready_to_file", label: "Ready to File", color: "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/30 dark:text-blue-300 dark:border-blue-800" },
  { value: "filed", label: "Filed", color: "bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950/30 dark:text-purple-300 dark:border-purple-800" },
  { value: "granted", label: "Granted", color: "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-300 dark:border-emerald-800" },
  { value: "complete", label: "Complete", color: "bg-gray-50 text-gray-600 border-gray-200 dark:bg-gray-900/40 dark:text-gray-300 dark:border-gray-700" },
];

function StatusDropdown({ estateId, currentStatus, revision }: { estateId: string; currentStatus: string; revision: number }) {
  const utils = trpc.useUtils();
  const updateMutation = trpc.estate.update.useMutation({
    onSuccess: () => {
      void utils.estate.get.invalidate({ id: estateId });
      void utils.estate.list.invalidate();
      void utils.readiness.check.invalidate({ estateId });
      void utils.readiness.timeline.invalidate({ estateId });
      void utils.deadline.list.invalidate();
      void utils.document.preflight.invalidate();
      void utils.document.preflightMany.invalidate();
      toast.success("Status updated");
    },
    onError: (error) => toast.error(error.message || "Status could not be updated"),
  });
  const current = STATUS_OPTIONS.find(s => s.value === currentStatus) || STATUS_OPTIONS[0];
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-xs font-medium transition-colors hover:opacity-80 ${current.color}`}>
          {current.label}
          <ChevronDown className="h-3 w-3 opacity-60" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {STATUS_OPTIONS.map(opt => (
          <DropdownMenuItem
            key={opt.value}
            onClick={() => updateMutation.mutate({ id: estateId, expectedRevision: revision, data: { status: opt.value } })}
            className={opt.value === currentStatus ? "font-medium" : ""}
          >
            <span className={`inline-block w-2 h-2 rounded-full mr-2 ${opt.value === currentStatus ? "bg-primary" : "bg-muted-foreground/30"}`} />
            {opt.label}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

// ─── GRANT TYPE BADGE ────────────────────────────────────────────────
function GrantTypeBadge({ estate, estateId }: { estate: any; estateId: string }) {
  const [, setLocation] = useLocation();
  const gt = normalizeGrantType(estate.grantType);
  const label = grantTypeLabel(estate.grantType);
  const color = gt === "probate" ? "bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-900/30 dark:text-indigo-300 dark:border-indigo-700"
    : gt === "admin_with_will" ? "bg-violet-50 text-violet-700 border-violet-200 dark:bg-violet-900/30 dark:text-violet-300 dark:border-violet-700"
    : gt === "admin_no_will" ? "bg-slate-50 text-slate-700 border-slate-200 dark:bg-slate-900/50 dark:text-slate-200 dark:border-slate-700"
    : "bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600";
  return (
    <button
      onClick={() => setLocation(`/estate/${estateId}?tab=intake`)}
      className={`inline-flex items-center px-2 py-0.5 rounded-md border text-[10px] font-medium transition-colors hover:opacity-80 cursor-pointer ${color}`}
      title="Click to edit grant type in Intake tab"
    >
      {label}
    </button>
  );
}

// ─── ANIMATED TABS ───────────────────────────────────────────────────
// Rule 24 (Nick, 2026-08-17): the Documents tab was removed — its checklist
// card lives in Readiness, the AI import card + proposals in Intake.
const TAB_ITEMS = [
  { value: "intake", label: "Intake" },
  { value: "contacts", label: "Contacts" },
  { value: "inventory", label: "Inventory" },
  { value: "forms", label: "Forms" },
  { value: "client-portal", label: "Client Portal" },
  { value: "readiness", label: "Readiness" },
  { value: "notes", label: "Notes" },
  { value: "activity", label: "Activity" },
] as const;

type TabValue = (typeof TAB_ITEMS)[number]["value"];

/** Resolve both current tab values and the removed Documents deep link. */
export function getEstateTabFromSearch(search: string): TabValue {
  const params = new URLSearchParams(search);
  const tab = params.get("tab");
  if (tab === "documents") return "readiness";
  if (tab && TAB_ITEMS.some((item) => item.value === tab)) return tab as TabValue;
  return "intake";
}

/** Return a canonical query string only when a legacy tab needs rewriting. */
export function canonicalizeEstateTabSearch(search: string): string | null {
  const params = new URLSearchParams(search);
  if (params.get("tab") !== "documents") return null;
  params.set("tab", "readiness");
  return params.toString();
}

/** The streamlined workspace removes operational workflow chrome, not form logic. */
export function showsFullWorkspaceWorkflow(formFocusedIntake: boolean): boolean {
  return !formFocusedIntake;
}

/** Simplified mode keeps the form-entry workflow while removing operational review surfaces. */
export function visibleEstateTabs(formFocusedIntake: boolean) {
  return formFocusedIntake
    ? TAB_ITEMS.filter((tab) => tab.value !== "readiness")
    : TAB_ITEMS;
}

/** A hidden Readiness deep link returns to Forms rather than rendering a tab with no trigger. */
export function resolveVisibleEstateTab(activeTab: TabValue, formFocusedIntake: boolean): TabValue {
  return formFocusedIntake && activeTab === "readiness" ? "forms" : activeTab;
}

function AnimatedTabs({ estateId, estate, formFocusedIntake }: { estateId: string; estate: any; formFocusedIntake: boolean }) {
  const [intakePending, setIntakePending] = useState(false);
  // Task 13 r3 (Nick, 2026-10-24): one delivery-feedback owner per estate page, passed to the tabs as a prop, so a
  // tab switch keeps an attempt's feedback. A tab still exiting after an estate change keeps the old, retired owner.
  const estateFeedback = useDeliveryFeedbackOwner(`estate:${estateId}`);
  const search = useSearch();
  const [, setLocation] = useLocation();

  // Readiness check for amber dot indicators on tabs
  const { data: readinessData } = trpc.readiness.check.useQuery({ estateId });
  const tabGaps = useMemo(() => {
    if (!readinessData?.items) return { forms: false, contacts: false, inventory: false, intake: false };
    const hasIssue = (tab: string) => readinessData.items.some((i: any) => i.tab === tab && (i.level === "fail" || i.level === "warn"));
    return {
      forms: hasIssue("forms"),
      contacts: hasIssue("contacts"),
      inventory: hasIssue("inventory"),
      intake: hasIssue("intake"),
    };
  }, [readinessData]);

  // P2-1: Read tab from URL query param. Removed `documents` links resolve to
  // Readiness, where the former checklist now lives.
  const [activeTab, setActiveTab] = useState<TabValue>(() => getEstateTabFromSearch(search));
  const currentTab = resolveVisibleEstateTab(activeTab, formFocusedIntake);
  const navigationTabs = visibleEstateTabs(formFocusedIntake);

  // P2-1: Sync activeTab when browser back/forward changes the URL
  useEffect(() => {
    const canonicalSearch = canonicalizeEstateTabSearch(search);
    const rawTabFromUrl = getEstateTabFromSearch(search);
    const tabFromUrl = resolveVisibleEstateTab(rawTabFromUrl, formFocusedIntake);
    const hiddenReadinessLink = formFocusedIntake && rawTabFromUrl === "readiness";
    if (canonicalSearch !== null || hiddenReadinessLink) {
      const params = new URLSearchParams(canonicalSearch ?? search);
      params.set("tab", tabFromUrl);
      setLocation(`/estate/${estateId}?${params.toString()}`, { replace: true });
    }
    if (tabFromUrl !== activeTab) {
      setActiveTab(tabFromUrl);
    }
  }, [search, activeTab, estateId, formFocusedIntake, setLocation]);

  // P2-1: Sync tab to URL on change (use correct route /estate/:id)
  const handleTabChange = useCallback((tab: TabValue) => {
    setActiveTab(tab);
    const params = new URLSearchParams(search);
    params.set("tab", tab);
    setLocation(`/estate/${estateId}?${params.toString()}`, { replace: true });
  }, [estateId, search, setLocation]);

  // P2-4: Allow readiness tab to navigate to other tabs
  const navigateToTab = useCallback((tab: string) => {
    const mapped = mapReadinessTabToValue(tab);
    if (mapped) {
      const destination = resolveVisibleEstateTab(mapped, formFocusedIntake);
      handleTabChange(destination);
      // If navigating to forms for distribution, scroll to the distribution section after render
      if (destination === "forms" && tab === "forms") {
        setTimeout(() => {
          const el = document.getElementById("distribution-section");
          if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 150);
      }
    }
  }, [formFocusedIntake, handleTabChange]);

  const workItems = useMemo(() => (readinessData?.items || [])
    .filter((item: any) => item.level === "fail" || item.level === "warn")
    .slice(0, 3), [readinessData]);
  const primaryWorkItem = workItems[0];

  const tabContent: Record<string, React.ReactNode> = {
    // Keep `intake: <` on one line — the chatbot's ESTATE_TABS drift test
    // parses this map by that shape. AI-assisted document import is available
    // through the chatbot rather than as a second Intake workflow.
    intake: <IntakeTab estateId={estateId} estate={estate} onDraftStateChange={(id, pending) => { if (id === estateId) setIntakePending(pending); }} onNavigateToContacts={() => handleTabChange("contacts")} />,
    contacts: <ContactsTab estateId={estateId} />,
    inventory: <InventoryTab estateId={estateId} estate={estate} />,
    forms: <FormsTab estateId={estateId} estate={estate} onNavigateToTab={navigateToTab} feedbackOwner={estateFeedback} />,
    "client-portal": <EstateClientPortal estateId={estateId} estate={estate} hasUnsavedChanges={intakePending} />,
    readiness: <ReadinessTabContent estateId={estateId} onNavigateToTab={navigateToTab} />,
    notes: <NotesTab estateId={estateId} estate={estate} feedbackOwner={estateFeedback} />,
    activity: <ActivityTab estateId={estateId} />,
  };

  return (
    <div className="w-full">
      {showsFullWorkspaceWorkflow(formFocusedIntake) && <section className="mb-4 rounded-xl border border-primary/10 bg-primary/[0.025] px-4 py-3 shadow-sm" aria-labelledby="estate-work-summary-heading" data-testid="estate-work-summary">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <CircleCheck className={`h-4 w-4 shrink-0 ${readinessData?.ready ? "text-emerald-600" : "text-primary"}`} aria-hidden="true" />
              <h2 id="estate-work-summary-heading" className="text-sm font-semibold">Today’s work</h2>
              {readinessData?.ready && <Badge variant="secondary" className="text-[10px]">Ready to file</Badge>}
            </div>
            {primaryWorkItem ? (
              <p className="mt-1 max-w-3xl text-xs text-muted-foreground">
                <span className="font-medium text-foreground">{primaryWorkItem.label}:</span> {primaryWorkItem.detail}
              </p>
            ) : (
              <p className="mt-1 text-xs text-muted-foreground">No current readiness blockers. Review the forms when you are ready to prepare documents.</p>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {primaryWorkItem && (
              <Button size="sm" onClick={() => navigateToTab(primaryWorkItem.tab)} className="active:scale-[0.97]">
                Continue {primaryWorkItem.tab === "readiness" ? "review" : primaryWorkItem.tab}
              </Button>
            )}
            <Button size="sm" variant="outline" onClick={() => handleTabChange("readiness")}>Review readiness</Button>
            <Button size="sm" variant="outline" onClick={() => handleTabChange("forms")}>Forms</Button>
          </div>
        </div>
        {workItems.length > 1 && (
          <div className="mt-3 flex flex-wrap gap-x-3 gap-y-1 border-t border-primary/10 pt-2">
            {workItems.slice(1).map((item: any) => (
              <button
                key={item.id}
                type="button"
                onClick={() => navigateToTab(item.tab)}
                className="inline-flex max-w-full items-center gap-1 text-[11px] text-muted-foreground underline-offset-2 hover:text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40"
              >
                <span className="truncate">{item.label}</span>
              </button>
            ))}
          </div>
        )}
      </section>}
      <motion.div
        initial={{ opacity: 0, y: 4 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.3, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] }}
      >
        <div className="overflow-x-auto -mx-1 px-1">
          <div className="inline-flex h-10 items-center rounded-lg bg-muted p-1 text-muted-foreground min-w-full md:w-full">
            {navigationTabs.map((tab) => (
              <button
                key={tab.value}
                onClick={() => handleTabChange(tab.value)}
                className={`relative inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1.5 text-sm font-medium transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring flex-1 ${
                  currentTab === tab.value ? "text-foreground" : "hover:text-foreground/80"
                }`}
              >
                {currentTab === tab.value && (
                  <motion.div
                    layoutId="active-tab-indicator"
                    className="absolute inset-0 rounded-md liquid-glass-tab"
                    transition={{ type: "spring", bounce: 0.15, duration: 0.5 }}
                  />
                )}
                <span className="relative z-10">{tab.label}</span>
                {tab.value === "forms" && tabGaps.forms && (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span className="relative z-10 ml-1.5 h-2 w-2 rounded-full bg-primary/75 motion-safe:animate-pulse cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent side="bottom" className="text-xs">
                      Missing fields detected — check readiness before generating
                    </TooltipContent>
                  </Tooltip>
                )}
                {tab.value === "contacts" && tabGaps.contacts && (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span className="relative z-10 ml-1.5 h-2 w-2 rounded-full bg-primary/75 motion-safe:animate-pulse cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent side="bottom" className="text-xs">
                      Incomplete contact information — address or role missing
                    </TooltipContent>
                  </Tooltip>
                )}
                {tab.value === "inventory" && tabGaps.inventory && (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span className="relative z-10 ml-1.5 h-2 w-2 rounded-full bg-primary/75 motion-safe:animate-pulse cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent side="bottom" className="text-xs">
                      Inventory data incomplete — items may need values or details
                    </TooltipContent>
                  </Tooltip>
                )}
              </button>
            ))}
          </div>
        </div>
      </motion.div>

      <AnimatePresence mode="wait">
        <motion.div
          // Keyed on the estate as well as the tab: estate→estate SPA navigation
          // re-renders this subtree in place whenever estate.get is warm, and every
          // tab holds estate-scoped state. IntakeTab in particular mirrors the row
          // into `form` and only re-seeds while NOT dirty — so without this key,
          // dirty edits from estate A stayed on screen (and saveable) under estate B.
          // The remount runs IntakeTab's unmount autosave for A, as a tab switch does.
          key={`${estateId}:${currentTab}`}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -4 }}
          transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] }}
          className="mt-4"
        >
          {tabContent[currentTab]}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

// Map readiness tab identifiers to our tab values
function mapReadinessTabToValue(readinessTab: string): TabValue | null {
  const mapping: Record<string, TabValue> = {
    intake: "intake",
    contacts: "contacts",
    inventory: "inventory",
    // Rule 24: the Documents tab is gone; its checklist card lives in
    // Readiness now, so both the retargeted rows ("readiness") and any
    // stale "documents" identifier land there.
    documents: "readiness",
    readiness: "readiness",
    forms: "forms",
  };
  return mapping[readinessTab] || null;
}

// ─── INTAKE TAB ──────────────────────────────────────────────────────

function PinnedNotesBanner({ estateId }: { estateId: string }) {
  const { data: pinnedNotes = [] } = trpc.notes.pinned.useQuery({ estateId });
  if (pinnedNotes.length === 0) return null;
  return (
    <div className="rounded-lg border border-amber-200 bg-amber-50/40 dark:bg-amber-950/10 dark:border-amber-800/40 p-3 space-y-1.5">
      <p className="text-xs font-medium text-amber-700 dark:text-amber-400 flex items-center gap-1"><Pin className="h-3 w-3 fill-amber-500" /> Pinned Notes</p>
      {pinnedNotes.map((n: any) => (
        <p key={n.id} className="text-xs text-amber-800 dark:text-amber-300 pl-4 border-l-2 border-amber-300 dark:border-amber-700">{n.content.length > 200 ? n.content.slice(0, 200) + "..." : n.content}</p>
      ))}
    </div>
  );
}

// Stable SectionHeader component (defined outside IntakeTab to prevent re-mount on re-render)
function SectionHeader({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="border border-border rounded-lg overflow-hidden">
      <Collapsible defaultOpen>
        <CollapsibleTrigger className="flex items-center justify-between w-full px-4 py-3 bg-slate-800 dark:bg-slate-200 text-white dark:text-slate-900 hover:bg-slate-700 dark:hover:bg-slate-300 transition-colors group">
          <span className="text-sm font-semibold">{title}</span>
          <ChevronDown className="h-4 w-4 transition-transform group-data-[state=open]:rotate-180" />
        </CollapsibleTrigger>
        <CollapsibleContent className="px-4 py-5 space-y-4 bg-background">
          {children}
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}

// P4 §6(a)/§7 affidavit list editor (Nick UAT D2-D4). Stores the face's numbered
// "affidavit of NAME sworn DATE" fills as JSON [{name,sworn}] — the exact shape
// docgen's normalizeWillIssues parses. Empty list → "" (never "[]").
function AffidavitRows({ value, onChange, maxRows }: { value: string; onChange: (json: string) => void; maxRows?: number }) {
  let rows: { name: string; sworn: string }[] = [];
  try { const p = JSON.parse(value || "[]"); if (Array.isArray(p)) rows = p; } catch { /* ignore */ }
  const commit = (next: { name: string; sworn: string }[]) => {
    const cleaned = next.filter(r => r.name || r.sworn);
    onChange(cleaned.length ? JSON.stringify(cleaned) : "");
  };
  return (
    <div className="space-y-1.5">
      {rows.map((r, i) => (
        <div key={i} className="flex items-center gap-2">
          <Input value={r.name} placeholder="Affidavit of (name)" className="text-xs flex-1"
            onChange={(e) => { const n = [...rows]; n[i] = { ...n[i], name: e.target.value }; commit(n); }} />
          <Input type="date" value={r.sworn} className="text-xs w-36"
            onChange={(e) => { const n = [...rows]; n[i] = { ...n[i], sworn: e.target.value }; commit(n); }} />
          <Button type="button" variant="ghost" size="sm" className="h-7 w-7 p-0 shrink-0"
            onClick={() => commit(rows.filter((_, j) => j !== i))}>×</Button>
        </div>
      ))}
      {(!maxRows || rows.length < maxRows) && <Button type="button" variant="outline" size="sm" className="h-7 text-xs"
        onClick={() => commit([...rows, { name: "", sworn: "" }])}>+ Add affidavit</Button>}
    </div>
  );
}

export function IntakeTab({ estateId, estate, onDraftStateChange, onNavigateToContacts }: {
  estateId: string;
  estate: any;
  onDraftStateChange?: (estateId: string, pending: boolean) => void;
  onNavigateToContacts?: () => void;
}) {
  const [form, setForm] = useState(estate);
  const normalizedWillIssues = useMemo(() => normalizeWillIssues(form as any), [form]);
  const recordedWillStatus = estateWillStatus(form as any);
  const [autoSuggested, setAutoSuggested] = useState(false);
  const [touchedIntakeFields, setTouchedIntakeFields] = useState<Set<string>>(() => new Set());
  const isDirtyRef = useRef(false);
  const [hasUnsavedIntake, setHasUnsavedIntake] = useState(false);
  const utils = trpc.useUtils();
  const { data: contacts } = trpc.contact.list.useQuery({ estateId });
  const { data: settings } = trpc.settings.get.useQuery();
  const formFocusedIntake = useFormFocusedIntakePreference(settings?.formFocusedIntake);
  const previousFormFocusedIntake = useRef(formFocusedIntake);
  const [showFormModeReveal, setShowFormModeReveal] = useState(false);
  useEffect(() => {
    const returningToFullIntake = previousFormFocusedIntake.current && !formFocusedIntake;
    previousFormFocusedIntake.current = formFocusedIntake;
    if (!returningToFullIntake) {
      setShowFormModeReveal(false);
      return;
    }
    setShowFormModeReveal(true);
    const clearReveal = window.setTimeout(() => setShowFormModeReveal(false), 620);
    return () => window.clearTimeout(clearReveal);
  }, [formFocusedIntake]);
  const prefersReducedMotion = typeof window !== "undefined"
    && typeof window.matchMedia === "function"
    && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const formModeTransition = prefersReducedMotion
    ? { duration: 0 }
    : { duration: 0.22, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] };
  const applyingContact = useMemo(() => findPrimaryApplicant(contacts || []), [contacts]);
  const applyingContactDetails = useMemo(() => applicantContactVsaDetails(applyingContact), [applyingContact]);
  const saveTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // A full-row Intake save may settle after the user has continued editing.
  // Track revisions per estate and bind each mutation variables object to the
  // exact revision it carries. A stale success must never clear a newer draft,
  // claim "Saved", or let the next server refresh overwrite later keystrokes.
  const formRevisionByEstateRef = useRef(new Map<string, number>());
  const submittedRevisionByRequestRef = useRef(new WeakMap<object, number>());
  // Keyed by estate id (2026-08-05 validation fix): a single boolean suppressed
  // estate B's unmount autosave while estate A's unrelated save was in flight.
  const savePendingByEstateRef = useRef(new Set<string>());
  // These callbacks resolve LATE — after the component may have re-pointed at a
  // different estate (estate→estate SPA navigation does not remount IntakeTab
  // when estate.get is warm; only the cold-cache loading gate unmounts it). So
  // every effect below keys off `variables.id` — the estate that was actually
  // saved — and only touches on-screen state when that is still the estate shown.
  const updateMutation = trpc.estate.update.useMutation({
    onSuccess: (data, variables) => {
      const savedEstateId = variables.id;
      const isCurrent = savedEstateId === estateId;
      savePendingByEstateRef.current.delete(savedEstateId);
      const submittedRevision = submittedRevisionByRequestRef.current.get(variables as object);
      const latestRevision = formRevisionByEstateRef.current.get(savedEstateId) || 0;
      const savedLatestSnapshot = submittedRevision !== undefined && submittedRevision === latestRevision;
      // Advance the local concurrency token immediately. The query refetch is
      // intentionally delayed to protect newer keystrokes, but a second save in
      // that window must compare against the revision this write just created.
      if (isCurrent) {
        formRef.current = { ...formRef.current, revision: data.revision };
        estateRef.current = { ...estateRef.current, revision: data.revision };
        setForm((previous: any) => ({ ...previous, revision: data.revision }));
      }
      void utils.readiness.check.invalidate({ estateId: savedEstateId });
      void utils.readiness.timeline.invalidate({ estateId: savedEstateId });
      void utils.deadline.list.invalidate();
      void utils.estate.list.invalidate();
      // Ordinary residence is a PFA s. 1 input. Refresh the fee summary after
      // every intake save so changing Not determined -> Yes/No cannot leave a
      // cached "Pending" or an amount from the other statutory basis.
      void utils.inventory.totals.invalidate({ estateId: savedEstateId });
      void utils.delivery.getRecipients.invalidate({ estateId: savedEstateId });
      void utils.document.preflight.invalidate();
      void utils.document.preflightMany.invalidate();
      // Clear the localStorage recovery draft only once the server confirmed the
      // save. The unmount-autosave path relies on this hook-level callback (it
      // still fires after unmount; per-mutate callbacks would not). Clear the key
      // of the estate that was SAVED — clearDraftRef points at whatever estate is
      // on screen now, which would wipe the wrong estate's recovery copy.
      if (savedLatestSnapshot) {
        if (isCurrent) clearDraftRef.current();
        else clearLocalDraft(`intake_${savedEstateId}`);
      } else if (isCurrent) {
        setSaveStatus('unsaved');
      }
      // A success for the latest snapshot is already durable. Mark it clean now
      // so a browser refresh or tab switch in the two-second query-settle window
      // cannot send the same full-row snapshot a second time and announce a
      // change the user did not make after returning to the page.
      if (isCurrent && savedLatestSnapshot) {
        isDirtyRef.current = false;
        setHasUnsavedIntake(false);
        onDraftStateChange?.(savedEstateId, false);
      }
      if (unmountSaveRef.current) {
        unmountSaveRef.current = false;
        // Only reassure about the estate the user is looking at: "saved" while a
        // different estate is on screen reads as a promise about THAT estate.
        if (isCurrent && savedLatestSnapshot) toast.success("Intake changes saved", { duration: 2000, icon: "✓" });
      }
      // Delay only the server refetch. New keystrokes increment the local
      // revision before this timer runs, and the clean marker above means a
      // confirmed snapshot cannot be needlessly re-sent during this window.
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
      saveTimeoutRef.current = setTimeout(() => {
        // Never clear the dirty flag on behalf of another estate's save — that
        // would let the server sync stomp the edits in front of the user.
        const stillLatest = submittedRevision !== undefined
          && submittedRevision === (formRevisionByEstateRef.current.get(savedEstateId) || 0);
        if (isCurrent && savedLatestSnapshot && stillLatest) {
          isDirtyRef.current = false;
          setHasUnsavedIntake(false);
          onDraftStateChange?.(savedEstateId, false);
        }
        utils.estate.get.invalidate({ id: savedEstateId });
      }, 2000);
    },
    onError: (error, variables) => {
      // A failed save must never pretend it succeeded: keep the localStorage
      // draft (only onSuccess clears it), tell the user what failed, and put the
      // sticky bar back into the honest "unsaved" state (the isPending/isSuccess
      // effect would otherwise leave it stuck on "Saving…"). The toast fires even
      // for a previous estate — a lost save must always be surfaced — but the
      // sticky bar belongs to the estate on screen.
      savePendingByEstateRef.current.delete(variables.id);
      unmountSaveRef.current = false;
      const detail = error.message || "Unknown error.";
      toast.error(`Failed to save intake changes: ${detail}${/[.!?]$/.test(detail) ? "" : "."} Your edits are kept as a local draft.`);
      if (variables.id === estateId) setSaveStatus('unsaved');
    },
  });
  const legalEvidenceField = {
    p1_early_application: "p1EarlyApplicationOrderFilePath",
    pgt_early_grant: "pgtEarlyGrantOrderFilePath",
    distribution_exception: "distributionExceptionFilePath",
    wesa_s58_order: "wesaS58OrderFilePath",
  } as const;
  const uploadLegalEvidenceMutation = trpc.estate.uploadLegalEvidence.useMutation({
    onSuccess: (data, variables) => {
      setForm((previous: any) => ({ ...previous, [legalEvidenceField[variables.kind]]: data.key }));
      void utils.estate.get.invalidate({ id: estateId });
      void utils.readiness.check.invalidate({ estateId });
      void utils.readiness.timeline.invalidate({ estateId });
      void utils.deadline.list.invalidate();
      void utils.document.preflight.invalidate();
      void utils.document.preflightMany.invalidate();
      toast.success("Legal evidence uploaded");
    },
    onError: (error) => toast.error(error.message || "Upload failed"),
  });
  const clearLegalEvidenceMutation = trpc.estate.clearLegalEvidence.useMutation({
    onSuccess: (_data, variables) => {
      setForm((previous: any) => ({ ...previous, [legalEvidenceField[variables.kind]]: "" }));
      void utils.estate.get.invalidate({ id: estateId });
      void utils.readiness.check.invalidate({ estateId });
      void utils.readiness.timeline.invalidate({ estateId });
      void utils.deadline.list.invalidate();
      void utils.document.preflight.invalidate();
      void utils.document.preflightMany.invalidate();
    },
  });
  const uploadLegalEvidence = async (
    kind: keyof typeof legalEvidenceField,
    file: File | undefined,
  ) => {
    if (!file) return;
    const bytes = new Uint8Array(await file.arrayBuffer());
    let binary = "";
    for (let index = 0; index < bytes.length; index += 1) binary += String.fromCharCode(bytes[index]);
    await uploadLegalEvidenceMutation.mutateAsync({
      estateId,
      kind,
      fileBase64: btoa(binary),
      fileName: file.name,
      mimeType: file.type || "application/octet-stream",
    });
  };
  // Only sync from server when the user hasn't made local edits
  useEffect(() => {
    if (!isDirtyRef.current) {
      setForm(estate);
    }
  }, [estate]);

  // Track form ref for auto-save on unmount (tab switch)
  const formRef = useRef(form);
  const estateRef = useRef(estate);
  // Holds the latest clearDraft so the unmount handler can wipe the localStorage
  // draft after an autosave \u2014 the isSuccess effect that normally clears it never
  // runs when the component unmounts on tab-switch, leaving a stale draft banner.
  const clearDraftRef = useRef<() => void>(() => {});
  // Same for flushDraft: useLocalDraft only persists on a 1s debounce and cancels
  // the pending timer on unmount, so edits made inside that window would exist
  // nowhere once the component goes away — and the failed-save toast promises a
  // draft. Flushing before the autosave fires makes that promise true.
  const flushDraftRef = useRef<() => void>(() => {});
  // True while an unmount autosave is in flight, so the mutation's onSuccess
  // knows to show the "saved" toast (the component is gone; the sticky bar can't).
  const unmountSaveRef = useRef(false);
  useEffect(() => { formRef.current = form; }, [form]);
  useEffect(() => { estateRef.current = estate; }, [estate]);

  const submitIntakeUpdate = (targetEstateId: string, data: Record<string, unknown>) => {
    const { revision: suppliedRevision, ...patch } = data;
    const expectedRevision = Number(suppliedRevision ?? estateRef.current?.revision);
    const variables = { id: targetEstateId, expectedRevision, data: patch };
    submittedRevisionByRequestRef.current.set(
      variables,
      formRevisionByEstateRef.current.get(targetEstateId) || 0,
    );
    savePendingByEstateRef.current.add(targetEstateId);
    updateMutation.mutate(variables);
  };

  // Auto-save when component unmounts (user switches tabs). Draft clearing and
  // the success/error toasts live in the mutation callbacks above \u2014 firing them
  // here synchronously showed "saved" (and destroyed the recovery draft) even
  // when the save later failed.
  useEffect(() => {
    return () => {
      const currentForm = formRef.current;
      const originalEstate = estateRef.current;
      const { id, createdAt, createdByUserId, fileNumber, ...formData } = currentForm;
      const { id: _id, createdAt: _ca, createdByUserId: _cu, fileNumber: _fn, ...estateData } = originalEstate;
      // A confirmed latest snapshot may still differ from the parent estate
      // prop until its delayed refetch. The explicit dirty marker distinguishes
      // that clean, already-saved state from a user edit that still needs an
      // unmount autosave.
      const isDirty = isDirtyRef.current && JSON.stringify(formData) !== JSON.stringify(estateData);
      if (isDirty) {
        // Persist the recovery copy FIRST: if the save fails, the error toast
        // says the edits are kept as a local draft, and now they always are.
        flushDraftRef.current();
        // Do not launch a second full-row write behind an in-flight manual save:
        // network completion order could let its older request overwrite this
        // newer snapshot. The flushed local draft is the safe recovery source;
        // the stale success is revision-checked and cannot remove it.
        if (!savePendingByEstateRef.current.has(estateId)) {
          unmountSaveRef.current = true;
          submitIntakeUpdate(estateId, formData);
        }
      }
    };
  }, [estateId]); // eslint-disable-line react-hooks/exhaustive-deps

  // Save status: 'idle' | 'unsaved' | 'saving' | 'saved'
  const [saveStatus, setSaveStatus] = useState<'idle' | 'unsaved' | 'saving' | 'saved'>('idle');
  const savedTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    // The sticky bar reports on THIS estate only: a save still settling for the
    // estate the user just navigated away from must not paint this one "Saved".
    // (Draft clearing lives in the mutation's onSuccess, which knows which estate
    // was saved — doing it here cleared whichever estate was on screen.)
    if (updateMutation.variables && updateMutation.variables.id !== estateId) return;
    if (updateMutation.isPending) setSaveStatus('saving');
    else if (updateMutation.isSuccess) {
      // 2026-08-05 validation fix: this effect runs AFTER onSuccess and used to
      // overwrite its honest 'unsaved' with 'saved' whenever isSuccess was true
      // — telling the user keystrokes newer than the settled snapshot were
      // saved. Only claim 'saved' when the request that settled carried the
      // LATEST revision; otherwise leave the 'unsaved' state onSuccess set.
      const settledRevision = updateMutation.variables
        ? submittedRevisionByRequestRef.current.get(updateMutation.variables as object)
        : undefined;
      const latestRevision = formRevisionByEstateRef.current.get(estateId) || 0;
      if (settledRevision === undefined || settledRevision !== latestRevision) return;
      setSaveStatus('saved');
      if (savedTimerRef.current) clearTimeout(savedTimerRef.current);
      savedTimerRef.current = setTimeout(() => setSaveStatus('idle'), 3000);
    }
  }, [updateMutation.isPending, updateMutation.isSuccess, updateMutation.variables?.id, estateId]);
  // localStorage auto-save: persist form data to prevent loss on page refresh
  const { pendingDraft, pendingDraftTime, lastSavedAt, acceptDraft, dismissDraft, clearDraft, flushDraft } = useLocalDraft({
    key: `intake_${estateId}`,
    data: form,
    isDirty: isDirtyRef.current || saveStatus === 'unsaved',
  });
  useEffect(() => { clearDraftRef.current = clearDraft; }, [clearDraft]);
  useEffect(() => { flushDraftRef.current = flushDraft; }, [flushDraft]);
  useEffect(() => {
    const pending = hasUnsavedIntake
      || pendingDraft !== null
      || saveStatus === 'unsaved'
      || saveStatus === 'saving';
    onDraftStateChange?.(estateId, pending);
  }, [estateId, hasUnsavedIntake, onDraftStateChange, pendingDraft, saveStatus]);

  // Auto-detect: if sole beneficiary is also the applicant, suggest P1 not required
  useEffect(() => {
    if (!contacts || contacts.length === 0 || autoSuggested) return;
    const applicants = contacts.filter((c: any) => contactHasRole(c, "applicant"));
    if (applicants.length === 0) return;

    // Check if there are ANY other contacts who would be P1 recipients
    // (not just beneficiaries — also executors, intestate successors, creditors in
    // intestacy, citors). Shared predicate — buildReadiness re-validates with the
    // same filter, so the latch can never outlive its justification.
    const otherRecipients = p1NoticeRecipients(form as any, contacts as any[]);

    if (!isP1NoticeRequired({ ...form, p1NotRequired: true }, contacts) && otherRecipients.length === 0 && !form.p1NotRequired) {
      markDirty();
      setForm((prev: any) => ({ ...prev, p1NotRequired: true }));
      setAutoSuggested(true);
      toast.info("P1 Notice auto-marked as not required \u2014 no other persons require P1 notice.", {
        duration: 8000,
        action: {
          label: "Undo",
          onClick: () => { markDirty(); setForm((prev: any) => ({ ...prev, p1NotRequired: false })); },
        },
      });
    }
  }, [contacts, form.p1NotRequired, autoSuggested]);

  // Auto-compute deceasedAliases from the AKA name fields (used by docgen and readiness)
  useEffect(() => {
    if (form.hasOtherNames !== "yes") {
      if (form.deceasedAliases) setForm((prev: any) => ({ ...prev, deceasedAliases: "" }));
      return;
    }
    const parts = [form.akaFirstName, form.akaMiddleName, form.akaLastName].filter(Boolean);
    const alias1 = parts.join(" ").trim();
    // A client-reported full alias has no safe first/middle/last split. Preserve
    // that canonical list until a lawyer intentionally enters a structured AKA.
    const existing = (form.deceasedAliases || "").split(";").map((s: string) => s.trim()).filter(Boolean);
    // A portal report stores each full alias in the canonical list without
    // guessing a first/middle/last split. When a lawyer has also supplied a
    // structured AKA, retain every client-reported alias except a duplicate of
    // that structured primary name; its position in the list is not reliable.
    const normalizedPrimary = normalizeAlias(alias1);
    const aliases = alias1
      ? [
          alias1,
          ...existing.filter(
            (alias: string) =>
              normalizeAlias(alias) !== normalizedPrimary
          ),
        ].filter(Boolean)
      : existing;
    const computed = aliases.join("; ");
    if (computed !== form.deceasedAliases) {
      setForm((prev: any) => ({ ...prev, deceasedAliases: computed }));
    }
  }, [form.hasOtherNames, form.akaFirstName, form.akaMiddleName, form.akaLastName]); // eslint-disable-line react-hooks/exhaustive-deps

  const save = () => {
    const { id, createdAt, createdByUserId, fileNumber, ...data } = form;
    // Clear the needsNameReview flag when user saves (they've had a chance to verify the split)
    if (form.needsNameReview && (form.deceasedLastName || form.applicantSurname)) {
      data.needsNameReview = 0;
    }
    // Clear legacy deceasedAddress when individual address fields are populated
    // This prevents stale AI-imported addresses from overriding user-entered data in forms
    if (data.addressStreet && (data as any).deceasedAddress) {
      (data as any).deceasedAddress = "";
    }
    submitIntakeUpdate(estateId, data);
  };

  const markDirty = () => {
    isDirtyRef.current = true;
    setHasUnsavedIntake(true);
    onDraftStateChange?.(estateId, true);
    formRevisionByEstateRef.current.set(
      estateId,
      (formRevisionByEstateRef.current.get(estateId) || 0) + 1,
    );
    if (saveTimeoutRef.current) { clearTimeout(saveTimeoutRef.current); saveTimeoutRef.current = null; }
    if (saveStatus !== 'saving') setSaveStatus('unsaved');
  };

  // Staff can begin an Intake before every court fact is known, so validation is
  // intentionally non-blocking: a field is evaluated only after the user has
  // interacted with it. Core fields receive a clear correction prompt, known
  // formats are checked as they are typed, and completed optional fields receive
  // a quiet confirmation without turning a partial draft into a wall of errors.
  const markIntakeFieldTouched = useCallback((key: string) => {
    setTouchedIntakeFields((previous) => {
      if (previous.has(key)) return previous;
      const next = new Set(previous);
      next.add(key);
      return next;
    });
  }, []);
  const validationForIntakeField = useCallback((key: string) => {
    if (!touchedIntakeFields.has(key)) return null;
    const value = form[key];
    const text = typeof value === "string" ? value.trim() : value === null || value === undefined ? "" : String(value);
    const requiredMessages: Record<string, string> = {
      deceasedFirstName: "Enter the deceased's first names.",
      deceasedLastName: "Enter the deceased's surname.",
      dateOfDeath: "Enter the date of death.",
      maritalStatus: "Select the marital status at death.",
      registry: "Select the court registry.",
      grantType: "Select the grant type.",
    };
    if (requiredMessages[key] && !text) return { tone: "error" as const, message: requiredMessages[key] };
    if (key === "dateOfDeath" && text && form.dateOfBirth && text < String(form.dateOfBirth)) {
      return { tone: "error" as const, message: "Date of death cannot be before date of birth." };
    }
    if (key === "dateOfBirth" && text && form.dateOfDeath && text > String(form.dateOfDeath)) {
      return { tone: "error" as const, message: "Date of birth must be before date of death." };
    }
    return text ? { tone: "success" as const, message: "Recorded" } : null;
  }, [form, touchedIntakeFields]);
  const validationMessageId = (key: string) => `intake-validation-${key}`;
  const correctionHintForIntakeField = (key: string) => {
    const value = form[key];
    const text = typeof value === "string" ? value.trim() : value === null || value === undefined ? "" : String(value);
    const hints: Record<string, string> = {
      deceasedFirstName: "Enter every given name exactly as it appears on the death certificate.",
      deceasedLastName: "Enter the family name exactly as it appears on the death certificate.",
      maritalStatus: "Choose the legal or civil marital status at the date of death.",
      registry: "Choose the Supreme Court registry where the application will be filed.",
      grantType: "Choose the type of estate grant being requested.",
    };
    if (key === "dateOfDeath") {
      return text
        ? "Choose a date on or after the recorded date of birth."
        : "Enter the date shown on the death certificate in YYYY-MM-DD format.";
    }
    if (key === "dateOfBirth") return "Choose a date before the recorded date of death.";
    return hints[key] || "Review the field and correct the highlighted value.";
  };
  const renderIntakeFieldValidation = (key: string, label?: string) => {
    const feedback = validationForIntakeField(key);
    if (!feedback) return null;
    const isError = feedback.tone === "error";
    const correctionHint = isError ? correctionHintForIntakeField(key) : null;
    const correctionLabel = label?.replace(/\s*\*\s*$/, "") || "this field";
    return (
      <p
        id={validationMessageId(key)}
        role={isError ? "alert" : undefined}
        className={`flex items-center gap-1 text-[11px] font-medium ${isError ? "text-destructive" : "text-emerald-700 dark:text-emerald-300"}`}
      >
        {isError ? <CircleAlert className="h-3 w-3 shrink-0" aria-hidden="true" /> : <CircleCheck className="h-3 w-3 shrink-0" aria-hidden="true" />}
        <span>{feedback.message}</span>
        {correctionHint && (
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                type="button"
                className="-my-1 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-destructive/80 transition-colors hover:bg-destructive/10 hover:text-destructive focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-destructive/40"
                aria-label={`How to correct ${correctionLabel}`}
              >
                <Info className="h-3.5 w-3.5" aria-hidden="true" />
              </button>
            </TooltipTrigger>
            <TooltipContent side="top" className="max-w-64 text-xs leading-relaxed">
              {correctionHint}
            </TooltipContent>
          </Tooltip>
        )}
      </p>
    );
  };

  // htmlFor/id: the label was previously unassociated with its input, so screen
  // readers announced the field unlabelled. `key` is the estate column, unique per form.
  const field = (
    label: string,
    key: string,
    type = "text",
    placeholder?: string,
    formatter?: (v: string) => string,
    description?: string,
    guidance?: IntakeGuidance,
  ) => {
    const feedback = validationForIntakeField(key);
    const descriptionId = description ? `intake-help-${key}` : undefined;
    const describedBy = [descriptionId, feedback ? validationMessageId(key) : undefined].filter(Boolean).join(" ") || undefined;
    return (
      <div className="min-w-0 space-y-1" data-invalid={feedback?.tone === "error" || undefined}>
        <div className="flex min-w-0 items-center gap-0.5">
          <Label className={`block min-w-0 break-words text-xs font-medium leading-snug ${feedback?.tone === "error" ? "text-destructive" : "text-muted-foreground"}`} htmlFor={key}>{label}</Label>
          {guidance && <IntakeGuidanceTooltip {...guidance} className={cn("-my-1", guidance.className)} />}
        </div>
        <Input
          id={key}
          type={type}
          value={form[key] || ""}
          onChange={(e) => {
            const val = formatter ? formatter(e.target.value) : e.target.value;
            markIntakeFieldTouched(key);
            markDirty();
            setForm((prev: any) => ({ ...prev, [key]: val }));
          }}
          onBlur={() => markIntakeFieldTouched(key)}
          aria-invalid={feedback?.tone === "error" || undefined}
          aria-describedby={describedBy}
          className={`h-9 transition-colors ${feedback?.tone === "error" ? "border-destructive focus-visible:ring-destructive/25" : feedback?.tone === "success" ? "border-emerald-500/60 focus-visible:ring-emerald-500/25" : ""}`}
          placeholder={placeholder}
        />
        {description && <p id={descriptionId} className="text-[10px] text-muted-foreground leading-tight">{description}</p>}
        {renderIntakeFieldValidation(key, label)}
      </div>
    );
  };

  // `description` mirrors field()'s: help text renders BELOW the control, so a
  // select and an input in the same section read the same way.
  const selectField = (
    label: string,
    key: string,
    options: { value: string; label: string }[],
    description?: string,
    guidance?: IntakeGuidance,
  ) => {
    // Filter out empty-value options (Radix Select.Item requires non-empty value)
    const safeOptions = options.filter(o => o.value !== "");
    const currentValue = form[key] || "";
    const feedback = validationForIntakeField(key);
    const descriptionId = description ? `intake-help-${key}` : undefined;
    const describedBy = [descriptionId, feedback ? validationMessageId(key) : undefined].filter(Boolean).join(" ") || undefined;
    return (
      <div className="min-w-0 space-y-1" data-invalid={feedback?.tone === "error" || undefined}>
        <div className="flex min-w-0 items-center gap-0.5">
          <Label className={`block min-w-0 break-words text-xs font-medium leading-snug ${feedback?.tone === "error" ? "text-destructive" : "text-muted-foreground"}`} htmlFor={key}>{label}</Label>
          {guidance && <IntakeGuidanceTooltip {...guidance} className={cn("-my-1", guidance.className)} />}
        </div>
        <Select value={currentValue || ""} onValueChange={(v) => { markIntakeFieldTouched(key); markDirty(); setForm((prev: any) => ({ ...prev, [key]: v })); }}>
          <SelectTrigger id={key} onBlur={() => markIntakeFieldTouched(key)} aria-invalid={feedback?.tone === "error" || undefined} aria-describedby={describedBy} className={`h-9 transition-colors ${feedback?.tone === "error" ? "border-destructive focus:ring-destructive/25" : feedback?.tone === "success" ? "border-emerald-500/60 focus:ring-emerald-500/25" : ""}`}><SelectValue placeholder="Select..." /></SelectTrigger>
          <SelectContent>
            {safeOptions.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
          </SelectContent>
        </Select>
        {description && <p id={descriptionId} className="text-[10px] text-muted-foreground leading-tight">{description}</p>}
        {renderIntakeFieldValidation(key, label)}
      </div>
    );
  };

  const triField = (label: string, key: string, opts?: string[], lbls?: string[], guidance?: IntakeGuidance) => (
    <div className="min-w-0 space-y-1.5" data-invalid={validationForIntakeField(key)?.tone === "error" || undefined}>
      <div className="flex min-w-0 items-center gap-0.5">
        <Label className="block min-w-0 break-words text-xs font-medium leading-snug text-muted-foreground">{label}</Label>
        {guidance && <IntakeGuidanceTooltip {...guidance} className={cn("-my-1", guidance.className)} />}
      </div>
      <TriToggle value={form[key] || ""} onChange={(v) => { markIntakeFieldTouched(key); markDirty(); setForm((prev: any) => ({ ...prev, [key]: v })); }} options={opts} labels={lbls} />
      {renderIntakeFieldValidation(key, label)}
    </div>
  );

  // SectionHeader moved outside to prevent re-mount on re-render

  // ── Intake completeness indicator ──
  const INTAKE_KEY_FIELDS = useMemo(() => [
    "deceasedFirstName", "deceasedLastName", "dateOfDeath", "dateOfBirth",
    "deceasedPlaceOfBirth", "addressStreet", "addressCity", "addressProvince",
    "addressPostalCode", "maritalStatus", "grantType", "registry",
  ], []);
  const INTAKE_DEFAULTS: Record<string, string> = { domicileCountry: "Canada", addressProvince: "BC", addressCountry: "Canada" };
  const intakeFilledCount = useMemo(() => {
    return INTAKE_KEY_FIELDS.filter((k) => {
      const v = form[k];
      if (v === null || v === undefined) return false;
      if (typeof v === "string") {
        const trimmed = v.trim();
        if (trimmed.length === 0) return false;
        // Don't count fields that still have their pre-filled default
        if (INTAKE_DEFAULTS[k] && trimmed === INTAKE_DEFAULTS[k]) return false;
        return true;
      }
      return true;
    }).length;
  }, [form, INTAKE_KEY_FIELDS]);
  const intakeTotal = INTAKE_KEY_FIELDS.length;
  const intakePct = Math.round((intakeFilledCount / intakeTotal) * 100);
  const intakeSectionProgress = useMemo(() => {
    const recorded = (key: string) => {
      const value = form[key];
      if (value === null || value === undefined) return false;
      if (typeof value !== "string") return true;
      const normalized = value.trim();
      return normalized.length > 0 && (!INTAKE_DEFAULTS[key] || normalized !== INTAKE_DEFAULTS[key]);
    };
    const sections = [
      { label: "Deceased", fields: ["deceasedFirstName", "deceasedLastName", "dateOfBirth", "dateOfDeath", "maritalStatus"] },
      { label: "Address & registry", fields: ["addressStreet", "addressCity", "addressProvince", "addressPostalCode", "registry"] },
      { label: "Application", fields: ["willStatus", "grantType"] },
    ];
    return sections.map((section) => ({
      ...section,
      complete: section.fields.filter(recorded).length,
      missing: section.fields.filter((key) => !recorded(key)).length,
    }));
  }, [form]);
  const applyingApplicantCount = useMemo(
    () => (contacts || []).filter((contact: any) => isApplyingApplicant(contact)).length,
    [contacts],
  );

  return (
    <motion.div
      className="space-y-4 pt-4"
      layout="position"
      transition={formModeTransition}
      data-testid="intake-mode-content"
      data-mode={formFocusedIntake ? "form-focused" : "full"}
      data-mode-transition={prefersReducedMotion ? "none" : "smooth"}
    >
      {/* Pinned notes banner */}
      <PinnedNotesBanner estateId={estateId} />
      {/* ── Draft recovery banner ── */}
      {pendingDraft && (
        <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
          <History className="h-4 w-4 text-amber-600" />
          <AlertDescription className="flex items-center justify-between">
            <span className="text-sm">
              Unsaved draft found from {pendingDraftTime ? `${fmtDisplayDate(pendingDraftTime)} ${new Date(pendingDraftTime).toLocaleTimeString()}` : "earlier"}.
            </span>
            <span className="flex gap-2 ml-4 shrink-0">
              <Button size="sm" variant="outline" className="h-7 text-xs" onClick={dismissDraft}>Discard</Button>
              <Button size="sm" className="h-7 text-xs" onClick={() => { const draft = acceptDraft(); if (draft) { setForm(draft); markDirty(); toast.success("Draft restored"); } }}>Restore Draft</Button>
            </span>
          </AlertDescription>
        </Alert>
      )}
      {/* ── Intake completeness bar ── */}
      <div className="flex items-center gap-3 px-1">
        <span className="text-xs font-medium text-muted-foreground whitespace-nowrap">
          Intake: {intakeFilledCount}/{intakeTotal} key fields
        </span>
        <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              intakePct === 100 ? "bg-green-500" : intakePct > 60 ? "bg-amber-500" : "bg-red-500"
            }`}
            style={{ width: `${intakePct}%` }}
          />
        </div>
        <span className={`text-xs font-semibold tabular-nums ${
          intakePct === 100 ? "text-green-700 dark:text-green-400" : intakePct > 60 ? "text-amber-700 dark:text-amber-300" : "text-red-600 dark:text-red-300"
        }`}>
          {intakePct}%
        </span>
      </div>
      {!formFocusedIntake && (
        <div className="rounded-lg border border-border/70 bg-muted/20 px-3 py-2" data-testid="intake-section-progress">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <span className="text-[11px] font-medium text-muted-foreground">Section progress</span>
            {intakeSectionProgress.map((section) => (
              <span key={section.label} className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] ${section.missing === 0 ? "border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950/30 dark:text-emerald-300" : "border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-300"}`}>
                {section.label}: {section.complete}/{section.fields.length}
                {section.missing > 0 && <span className="opacity-75">· {section.missing} to complete</span>}
              </span>
            ))}
          </div>
          <p className="mt-1.5 text-[10px] leading-relaxed text-muted-foreground">Use these counts to plan data entry. The Readiness tab remains the authoritative checklist for filing and form preparation.</p>
        </div>
      )}

      {/* ─── DECEASED INFORMATION ─── */}
      <SectionHeader title="Deceased Information">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {field("First Names (given names) *", "deceasedFirstName")}
          {field("Surname (family name) *", "deceasedLastName")}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {field("First Middle Name", "deceasedMiddleNames")}
          {field("Second Middle Name", "deceasedSecondMiddleName")}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {field("Date of Birth", "dateOfBirth", "date")}
          {field("Date of Death *", "dateOfDeath", "date")}
        </div>
        {selectField("Civil marital status at death *", "maritalStatus", [
          { value: "single", label: "Single / never married" },
          { value: "married", label: "Married" },
          { value: "widowed", label: "Widowed" },
          { value: "divorced", label: "Divorced" },
          { value: "separated", label: "Separated" },
          { value: "common-law", label: "Common-law" },
        ])}
        <p className="text-[10px] text-muted-foreground -mt-2">Death-certificate status used for the prescribed civil-status wording on Form P2.</p>
        {(form.maritalStatus === "married" || form.maritalStatus === "common-law" || form.maritalStatus === "separated" || form.maritalStatus === "widowed") && (
          <div className="mt-3 rounded-lg border border-primary/15 bg-primary/[0.035] px-3 py-2.5" role="status">
            <p className="text-xs font-semibold text-foreground">Spouse details come from Contacts</p>
            <p className="mt-0.5 text-[11px] leading-snug text-muted-foreground">Add or update the spouse or common-law partner in Contacts. That record supplies P1 notices and Form P2 Schedule §2(a), including the surviving or deceased classifier.</p>
            {onNavigateToContacts && (
              <Button type="button" size="sm" variant="outline" className="mt-2 h-7 px-2 text-[11px]" onClick={onNavigateToContacts}>
                Open spouse contact
              </Button>
            )}
          </div>
        )}

        {!formFocusedIntake && (
          <p className="text-[10px] text-muted-foreground -mt-1">If a form needs a separate WESA s.2 spouse determination for notice, administration priority, or succession, the Generate Anyway dialog will start from this civil-status answer and let you confirm or correct it there.</p>
        )}
      </SectionHeader>

      {/* ─── DECEASED ADDRESS ─── */}
      <SectionHeader title="Last Residential Address of the Deceased">
        <div className="-mt-2 mb-3 flex min-w-0 items-center gap-0.5">
          <p className="text-xs italic text-muted-foreground">Include street number or PO box, city/town, province, country and postal code.</p>
          <IntakeGuidanceTooltip
            label="deceased address guidance"
            testId="deceased-address-guidance-trigger"
            className="-my-1"
          >
            This address supplies the deceased&apos;s location on P1, P2 and P17. Any legally distinct affidavit or non-domiciled-estate determination is collected only when the relevant form is generated.
          </IntakeGuidanceTooltip>
        </div>
        <div className={`flex items-center gap-2 mb-3 p-2 rounded-md border transition-colors duration-200 ${form.addressFormatOverride ? "border-amber-300 bg-amber-50 dark:border-amber-700 dark:bg-amber-950/30" : "border-border/50 bg-muted/30"}`}>
          <Switch
            id="addressFormatOverride"
            checked={!!form.addressFormatOverride}
            onCheckedChange={(checked) => { markDirty(); setForm((prev: any) => ({ ...prev, addressFormatOverride: checked ? 1 : 0 })); }}
          />
          <Label htmlFor="addressFormatOverride" className="text-xs font-medium cursor-pointer select-none">Manual formatting override</Label>
          <AnimatePresence>
            {!!form.addressFormatOverride && (
              <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}>
                <Badge variant="outline" className="text-[10px] h-5 border-amber-400 text-amber-700 dark:text-amber-400 bg-amber-100/50 dark:bg-amber-900/30 font-medium">ACTIVE</Badge>
              </motion.div>
            )}
          </AnimatePresence>
          <Tooltip>
            <TooltipTrigger asChild><Info className="h-3.5 w-3.5 text-muted-foreground" /></TooltipTrigger>
            <TooltipContent side="right" className="max-w-[260px] text-xs space-y-1.5 p-3">
              <p className="font-medium">Manual Formatting Override</p>
              <p>When enabled, address fields will appear <strong>exactly as typed</strong> in generated documents — no automatic title-casing, province uppercasing, or postal code formatting.</p>
              <p className="text-muted-foreground">Use this for foreign addresses, non-standard formatting, or addresses with special characters (e.g. “São Paulo”, “SW1A 1AA”).</p>
            </TooltipContent>
          </Tooltip>
          <AnimatePresence>
            {!!form.addressFormatOverride && (
              <motion.div initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 8 }} transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }} className="ml-auto">
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 px-2 text-[10px] text-amber-700 dark:text-amber-400 hover:text-amber-900 hover:bg-amber-100 dark:hover:bg-amber-900/40"
                  onClick={() => {
                    markDirty();
                    setForm((prev: any) => ({
                      ...prev,
                      addressFormatOverride: 0,
                      addressStreet: titleCaseAddr(prev.addressStreet || ""),
                      addressCity: titleCaseAddr(prev.addressCity || ""),
                      addressProvince: upperProvinceAddr(prev.addressProvince || ""),
                      addressPostalCode: upperPostalCodeAddr(prev.addressPostalCode || ""),
                      addressCountry: titleCaseAddr(prev.addressCountry || ""),
                    }));
                    toast.info("Automatic formatting restored");
                  }}
                >
                  <X className="h-3 w-3 mr-0.5" /> Revert to auto
                </Button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <div className="space-y-1">
              <Label className="text-xs font-medium text-muted-foreground">Street Address</Label>
              <AddressAutocomplete
                value={form.addressStreet || ""}
                onChange={(val) => { markDirty(); setForm((prev: any) => ({ ...prev, addressStreet: val })); }}
                onSelect={(components) => {
                  markDirty();
                  setForm((prev: any) => ({
                    ...prev,
                    addressStreet: components.street,
                    addressUnit: components.unit || prev.addressUnit,
                    addressCity: components.city || prev.addressCity,
                    addressProvince: components.province || prev.addressProvince,
                    addressPostalCode: components.postalCode || prev.addressPostalCode,
                    addressCountry: components.country || prev.addressCountry,
                  }));
                }}
                placeholder="Start typing an address..."
              />
            </div>
          </div>
          {field("Unit/Suite/Apt.", "addressUnit")}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {field("Post Office Box", "deceasedPostOfficeBox")}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {field("City", "addressCity")}
          <div className="space-y-1.5">
            <Label className="text-xs font-medium text-muted-foreground">Province <span className="text-destructive">*</span></Label>
            <Select value={form.addressProvince || ""} onValueChange={(v) => { markDirty(); setForm((prev: any) => ({ ...prev, addressProvince: v })); }}>
              <SelectTrigger className="h-9" aria-invalid={!form.addressProvince && form.addressCity ? true : undefined}><SelectValue placeholder="Select province..." /></SelectTrigger>
              <SelectContent>
                {["AB","BC","MB","NB","NL","NS","NT","NU","ON","PE","QC","SK","YT"].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
              </SelectContent>
            </Select>
            {!form.addressProvince && form.addressCity && (
              <p className="text-[11px] text-destructive flex items-center gap-1" role="alert">
                <CircleAlert className="h-3 w-3 shrink-0" /> Province is required
              </p>
            )}
            {form.addressProvince && (
              <p className="text-[11px] text-green-700 dark:text-green-400 flex items-center gap-1">
                <CircleCheck className="h-3 w-3 shrink-0" /> {form.addressProvince}
              </p>
            )}
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-medium text-muted-foreground">Postal Code <span className="text-destructive">*</span></Label>
            <Input
              type="text"
              value={form.addressPostalCode || ""}
              onChange={(e) => {
                // Auto-format: uppercase, insert space after 3rd char
                let val = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "");
                if (val.length > 3) val = val.slice(0, 3) + " " + val.slice(3);
                if (val.length > 7) val = val.slice(0, 7);
                markDirty();
                setForm((prev: any) => ({ ...prev, addressPostalCode: val }));
              }}
              aria-invalid={form.addressPostalCode && !/^[A-Z]\d[A-Z]\s?\d[A-Z]\d$/.test(form.addressPostalCode) ? true : undefined}
              placeholder="V6R 2P8"
              maxLength={7}
            />
            {form.addressPostalCode && !/^[A-Z]\d[A-Z]\s?\d[A-Z]\d$/.test(form.addressPostalCode) && (
              <p className="text-[11px] text-destructive flex items-center gap-1" role="alert">
                <CircleAlert className="h-3 w-3 shrink-0" /> Invalid format — expected A1A 1A1 (e.g. V6R 2P8)
              </p>
            )}
            {form.addressPostalCode && /^[A-Z]\d[A-Z]\s?\d[A-Z]\d$/.test(form.addressPostalCode) && (
              <p className="text-[11px] text-green-700 dark:text-green-400 flex items-center gap-1">
                <CircleCheck className="h-3 w-3 shrink-0" /> Valid postal code
              </p>
            )}
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1">
            {field("Place of death — city", "placeOfDeath", "text", "e.g. Victoria", undefined, undefined, {
              label: "place of death guidance",
              testId: "place-of-death-guidance-trigger",
              children: "Enter the city exactly as shown on the death certificate. This is used for the Consent to Appointment of an Administrator; if blank, the last-residence city is used.",
            })}
          </div>
        </div>
        {field("Country", "addressCountry")}
      </SectionHeader>

      {/* ─── ADDITIONAL INFORMATION ─── */}
      <SectionHeader title="Additional Information about the Deceased">
        {selectField("Deceased's Gender", "deceasedGender", [
          { value: "male", label: "Male" },
          { value: "female", label: "Female" },
          { value: "non-binary", label: "Non-binary" },
          { value: "other", label: "Other" },
        ])}
        {!formFocusedIntake && field("Deceased's Occupation", "deceasedOccupation")}
        {field("Place of Birth (city, province/state, country)", "deceasedPlaceOfBirth", "text", "e.g. Vancouver, BC, Canada")}
        {triField("Was the deceased known by any other names?", "hasOtherNames")}
        {form.hasOtherNames === "yes" && (
          <div className="pl-4 border-l-2 border-primary/20 space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {field("AKA First Name", "akaFirstName")}
              {field("AKA Middle Name", "akaMiddleName")}
              {field("AKA Last Name", "akaLastName")}
            </div>
            {triField("Was the deceased known by any additional names?", "hasAdditionalNames")}
            {(() => {
              const primary = [form.akaFirstName, form.akaMiddleName, form.akaLastName]
                .filter(Boolean)
                .join(" ")
                .trim();
              const aliases = (form.deceasedAliases || "")
                .split(";")
                .map((alias: string) => alias.trim())
                .filter(Boolean);
              const additionalAliases = primary
                ? aliases.filter((alias: string) => normalizeAlias(alias) !== normalizeAlias(primary))
                : aliases;
              const showAliases =
                form.hasAdditionalNames === "yes" || additionalAliases.length > 0;

              if (!showAliases) return null;

              return (
              <div className="space-y-1">
                <Label
                  htmlFor="deceased-alias-list"
                  className="text-xs font-medium text-muted-foreground"
                >
                  {[form.akaFirstName, form.akaMiddleName, form.akaLastName].some(Boolean)
                    ? "Additional aliases (one per line)"
                    : "Aliases (one per line)"}
                </Label>
                <Textarea
                  id="deceased-alias-list"
                  value={additionalAliases.join("\n")}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => {
                    const first = [form.akaFirstName, form.akaMiddleName, form.akaLastName].filter(Boolean).join(" ").trim();
                    const additional = e.target.value.split("\n").map((s: string) => s.trim()).filter(Boolean);
                    const all = [first, ...additional].filter(Boolean).join("; ");
                    markDirty();
                    setForm({ ...form, deceasedAliases: all });
                  }}
                  placeholder="e.g. John A. Smith&#10;Johnny Smith"
                  className="min-h-[60px] text-sm"
                />
                <p className="text-[10px] text-muted-foreground">These names appear on P1, P2, and P10 forms. Ensure all names under which the deceased held property are listed.</p>
              </div>
              );
            })()}
          </div>
        )}
        {selectField("Was the deceased a member of a treaty first nation?", "treatyFirstNation", [
          { value: "no", label: "No" },
          { value: "yes", label: "Yes" },
          { value: "nisga", label: "Yes — Nisga'a citizen" },
          { value: "na", label: "N/A" },
        ])}
        {(form.treatyFirstNation === "yes") && (
          <div className="pl-4 border-l-2 border-primary/20">
            {field("Treaty First Nation Name", "treatyFirstNationName")}
          </div>
        )}
      </SectionHeader>

      {/* ─── INFORMATION ABOUT THE WILL ─── */}
      <SectionHeader title="Information About the Will">
        <div className="space-y-1">
          <Label className="text-xs font-medium text-muted-foreground">Will Status</Label>
          {/* markDirty added 2026-07-11 — pre-existing omission (P2-arc silent-revert class) */}
          <TriToggle value={recordedWillStatus} onChange={(v) => { markDirty(); setForm({ ...form, willStatus: v, hasWill: v === "no_will" ? 0 : 1 }); }} options={["unknown", "will", "no_will"]} labels={["Not confirmed", "Will present", "No will"]} />
          {recordedWillStatus === "unknown" && <p className="text-[11px] text-amber-700 dark:text-amber-300">Record the will status before generating legal documents. This avoids treating a new file workspace as a legal conclusion.</p>}
        </div>
        {recordedWillStatus === "will" ? (
          <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-muted-foreground">Type of Will</Label>
              {/* 0138: no phantom highlight — an unanswered medium must LOOK unanswered
                  (the DB default is not a recorded answer; P4 ¶8 swears this fact). */}
              <TriToggle
                value={form.willType || (form.isElectronicWill ? "electronic" : "")}
                onChange={(v) => {
                  markDirty();
                  setForm((prev: any) => ({
                    ...prev,
                    willType: v,
                    // The former checkbox below asked the same factual question
                    // a second time. Keep its legacy column synchronized so P1,
                    // P9, P45, and historic records use one consistent answer.
                    isElectronicWill: v === "electronic" ? 1 : 0,
                  }));
                }}
                options={["na", "physical", "electronic"]}
                labels={["N/A", "Physical", "Electronic"]}
              />
            </div>
            <div className="space-y-4">
              {field("Will Date", "willDate", "date")}
              {field(
                "Where the original will is kept",
                "willLocation",
                "text",
                "e.g. firm safe or home safe"
              )}
            </div>
          </div>
          {form.willType === "electronic" && (
            <div className="pl-4 border-l-2 border-primary/20 space-y-3">
              {/* P15PLUS-006 (Nick ruling 2026-07-26): the Rule 25-3(3)(a.1) axes are
                  DISTINCT facts — availability ((i)), first-saved-PDF ((ii)/(iii)),
                  third-party repository ((iv)). P45 derives strictly from (iii)/(iv).
                  The legacy electronicWillFormat token is DERIVED ((iv)→(iii)→(ii)→(i)
                  precedence) so P4 §6(c.1)'s sworn branch selection keeps working. */}
              {(() => {
                // Adversarial-verify fix 2026-07-26: applyElectronicWillAxis
                // RESOLVES the legacy token into the axes before applying the
                // change, so a partial answer on a pre-0102 estate never
                // clobbers the recorded (iii)/(iv) fact or P4 §6(c.1)'s branch.
                const setAxis = (key: "electronicWillOriginalAvailable" | "electronicWillFirstSavedPdf" | "electronicWillInRepository", v: string) => {
                  markDirty();
                  setForm((prev: any) => ({ ...prev, ...applyElectronicWillAxis(prev, key, v) }));
                };
                // 2026-07-26 review fix: DISPLAY the resolved facts too — a
                // pre-0102 estate whose legacy token says third_party_repo must
                // not show three unanswered questions while formStatus/readiness
                // treat the (iv) fact as recorded. Write path unchanged.
                const ewAxes = electronicWillFacts(form as any);
                return (
                  <div className="space-y-2">
                    <div className="space-y-1.5">
                      <Label className="text-xs font-medium text-muted-foreground">Was the will FIRST SAVED in PDF format? (Rule 25-3(3)(a.1)(ii)/(iii))</Label>
                      <TriToggle value={ewAxes.firstSavedPdf} onChange={(v) => setAxis("electronicWillFirstSavedPdf", v)} options={["yes", "no"]} labels={["Yes", "No"]} />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs font-medium text-muted-foreground">Is the will maintained in a THIRD-PARTY electronic repository? (Rule 25-3(3)(a.1)(iv))</Label>
                      <TriToggle value={ewAxes.inRepository} onChange={(v) => setAxis("electronicWillInRepository", v)} options={["yes", "no"]} labels={["Yes", "No"]} />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs font-medium text-muted-foreground">Does the original electronic form exist and is it available to submit? (Rule 25-3(3)(a.1)(i))</Label>
                      <TriToggle value={ewAxes.originalAvailable} onChange={(v) => setAxis("electronicWillOriginalAvailable", v)} options={["yes", "no"]} labels={["Yes", "No"]} />
                    </div>
                  </div>
                );
              })()}
              {(() => { const a = electronicWillFacts(form as any); return (a.firstSavedPdf === "no" || a.inRepository === "yes"); })() && (
              <Alert className="bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800">
                <Info className="h-3.5 w-3.5 text-blue-600" />
                <AlertDescription className="text-[11px] text-blue-700 dark:text-blue-300">
                  <strong>WESA s.35.1 &amp; Rule 25-3(3)(a.1):</strong> Electronic wills not first saved in PDF, or maintained in a third-party repository, require Form P45 (Affidavit of Electronic Will) and the long-form P4. {electronicWillFacts(form as any).inRepository === "yes" && "Repository access details are recorded below and filed as application material with the long-form P4 — they are never sworn text in the P45."}
                </AlertDescription>
              </Alert>
              )}
              {/* Electronic will locked status — determines P45 Alternative 1 vs 2 */}
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-muted-foreground">Has the electronic will been locked against editing?</Label>
                <Select value={form.electronicWillLocked || ""} onValueChange={(v) => { markDirty(); setForm((prev: any) => ({ ...prev, electronicWillLocked: v })); }}>
                  <SelectTrigger className="h-9"><SelectValue placeholder="Select..." /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="no">No — I verified the edit date (P45 Alternative 1)</SelectItem>
                    <SelectItem value="yes">Yes — Will is locked against editing (P45 Alternative 2)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {form.electronicWillLocked === "no" && (
                <div className="space-y-1">
                  <Label className="text-xs font-medium text-muted-foreground">How was the edit date verified?</Label>
                  <Textarea value={form.electronicWillVerificationMethod || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, electronicWillVerificationMethod: e.target.value })); }} className="min-h-[60px] text-sm" placeholder="e.g. I checked the file properties and confirmed the last modified date matches the date of execution..." />
                </div>
              )}
              {form.electronicWillLocked === "yes" && (
                <div className="space-y-1">
                  <Label className="text-xs font-medium text-muted-foreground">How was the will locked?</Label>
                  <Textarea value={form.electronicWillLockMethod || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, electronicWillLockMethod: e.target.value })); }} className="min-h-[60px] text-sm" placeholder="e.g. The PDF was digitally signed and certified, preventing further edits..." />
                </div>
              )}
              {/* 2026-07-26 review fix: the P45 sworn line "the original electronic
                  form of the will is ____" needs this description for EVERY
                  non-PDF-original token (repository included) — same predicate as
                  the p45_electronic_will_format_description requirement row. */}
              {!!form.electronicWillFormat && form.electronicWillFormat !== "pdf_original" && (
                <div className="space-y-1">
                  <Label className="text-xs font-medium text-muted-foreground">Describe the electronic format of the original will</Label>
                  <Input value={form.electronicWillFormatDescription || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, electronicWillFormatDescription: e.target.value })); }} className="h-9" placeholder="e.g. Microsoft Word .docx, or PDF if repository-stored" />
                </div>
              )}
              {form.electronicWillFormat === "original_unavailable" && (
                <div className="space-y-3 pl-2 border-l-2 border-amber-200 dark:border-amber-800">
                  <Label className="text-xs font-medium text-muted-foreground">Basis for explaining why the original electronic form cannot be submitted</Label>
                  <div className="space-y-2">
                    <label className="flex items-start gap-2 cursor-pointer">
                      <input type="radio" name="electronicOriginalUnavailableKnowledge" value="first_hand" checked={form.electronicOriginalUnavailableKnowledge === "first_hand"} onChange={() => { markDirty(); setForm((prev: any) => ({ ...prev, electronicOriginalUnavailableKnowledge: "first_hand" })); }} className="mt-0.5" />
                      <span className="text-xs">The deponent has first-hand knowledge of the reason.</span>
                    </label>
                    <label className="flex items-start gap-2 cursor-pointer">
                      <input type="radio" name="electronicOriginalUnavailableKnowledge" value="affidavit" checked={form.electronicOriginalUnavailableKnowledge === "affidavit"} onChange={() => { markDirty(); setForm((prev: any) => ({ ...prev, electronicOriginalUnavailableKnowledge: "affidavit" })); }} className="mt-0.5" />
                      <span className="text-xs">A separate affidavit explains why a copy is available but the original is not.</span>
                    </label>
                  </div>
                  {form.electronicOriginalUnavailableKnowledge === "first_hand" && (
                    <Textarea value={form.electronicOriginalUnavailableReason || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, electronicOriginalUnavailableReason: e.target.value })); }} className="min-h-[60px] text-xs" placeholder="State the first-hand reason the original electronic form cannot be submitted." />
                  )}
                  {form.electronicOriginalUnavailableKnowledge === "affidavit" && (
                    <AffidavitRows maxRows={1} value={form.electronicOriginalUnavailableAffidavits || ""} onChange={(json) => { markDirty(); setForm((prev: any) => ({ ...prev, electronicOriginalUnavailableAffidavits: json })); }} />
                  )}
                </div>
              )}
              {form.electronicWillFormat === "third_party_repo" && (
                <>
                  <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
                    <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
                    <AlertDescription className="text-[11px] text-amber-700 dark:text-amber-300">
                      <strong>Rule 25-3(3)(a.1)(iv):</strong> A will maintained in a third-party repository mandates Form P45 and the long-form P4. The repository details below are filed as application material supporting the P4 — the P45 swears only the format confirmation.
                    </AlertDescription>
                  </Alert>
                  <div className="space-y-1">
                    <Label className="text-xs font-medium text-muted-foreground">Repository Name</Label>
                    <Input value={form.electronicWillRepositoryName || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, electronicWillRepositoryName: e.target.value })); }} className="h-9" placeholder="e.g. Willful, SafeBeyond" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-medium text-muted-foreground">Repository Address</Label>
                    <Input value={form.electronicWillRepositoryAddress || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, electronicWillRepositoryAddress: e.target.value })); }} className="h-9" placeholder="Full address or URL of the repository" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs font-medium text-muted-foreground">Applicant's Access to Will</Label>
                    <Input value={form.electronicWillRepositoryAccess || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, electronicWillRepositoryAccess: e.target.value })); }} className="h-9" placeholder="Describe how the applicant has access to the will in the repository" />
                  </div>
                </>
              )}
            </div>
          )}
          <p className="text-[10px] text-muted-foreground">The Type of Will selection above is the single source for electronic-will rules, including Form P45, Rule 25-2(1.1)(b) P1 notice wording, P9 delivery wording, and the no-visible-signature question.</p>
          {!!form.isElectronicWill && (
            <div className="pl-6 space-y-2">
              <div className="flex items-center gap-1.5">
                <Label className="text-xs font-medium text-muted-foreground">Reason there is no visible signature on the will (Rule 25-2(3)(h))</Label>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-3.5 w-3.5 text-muted-foreground cursor-help shrink-0" />
                  </TooltipTrigger>
                  <TooltipContent side="top" className="max-w-xs text-xs">
                    Required by Rule 25-2(3)(h) if the electronic will has no visible signature.
                  </TooltipContent>
                </Tooltip>
              </div>
              <Textarea
                value={form.noVisibleSignatureReason || ""}
                onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, noVisibleSignatureReason: e.target.value })); }}
                className="min-h-[60px] text-sm"
                placeholder="e.g., The will was executed using a digital signature platform (DocuSign) which does not produce a visible wet-ink signature on the document..."
              />
            </div>
          )}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {triField("Does the will create a testamentary trust?", "hasTestamentaryTrust")}
            {form.hasTestamentaryTrust === "yes" && triField("Is a trustee named in the will?", "trusteeNamed")}
          </div>
          {form.hasTestamentaryTrust === "yes" && form.trusteeNamed === "yes" && (
            <p className="text-[10px] text-green-700 dark:text-green-400 italic flex items-center gap-1"><Info className="h-3 w-3 shrink-0" /><span><strong>Rule 25-3(11) exception:</strong> PGT notification may not be required for non-spouse/child minor beneficiaries when a testamentary trust with a named trustee exists.</span></p>
          )}
          {/* Codicils */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label className="text-xs font-medium text-muted-foreground">Number of Codicils</Label>
              <Input type="number" min={0} value={form.codicilCount || 0} onChange={(e) => { markDirty(); setForm({ ...form, codicilCount: Number(e.target.value) }); }} className="h-9" />
              <p className="text-[10px] text-muted-foreground">This count identifies the codicils that accompany the will and is named in the delivery affidavit when applicable.</p>
            </div>
            {!formFocusedIntake && field("Codicil Dates (comma-separated)", "codicilDates", "text", "e.g. 2020-01-15, 2021-06-30", undefined, "Case-file reference only — individual codicil dates are maintained with their uploaded documents.")}
          </div>
          {/* B-04: the hasCodicil tri-field wrote a phantom key (no schema column — silently
              dropped on save); codicilCount is the persisted entry point and gates the note. */}
          {(form.codicilCount > 0) && (
            <p className="text-[10px] text-blue-600 dark:text-blue-400 italic flex items-center gap-1"><Info className="h-3 w-3 shrink-0" /><span><strong>Rule 25-3(3)(d):</strong> Each codicil must be listed in P2 Part 4 (Testamentary Documents) and filed with the court.</span></p>
          )}
          {triField("Are there court orders affecting the validity or content of the will?", "ordersAffectingWill", ["na", "yes", "no"])}
          {form.ordersAffectingWill === "yes" && (
            <>
              <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
              <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
              <AlertDescription className="text-[11px] text-amber-700 dark:text-amber-300">
                  <strong>Rules 25-3(3)(a)(iii), 25-3(3)(a.1)(v) and 25-3(6)(i):</strong> Record the order in Form P2 and use the long-form P4 affidavit. If the order has not already been filed in this proceeding, file a copy with this submission for estate grant.
              </AlertDescription>
            </Alert>
              {field("Describe the order", "orderDescription", "text", "e.g. Order varying clause 3")}
              {/* P15PLUS-010 (Nick ruling 2026-07-26): the two P19 grant clauses are
                  independent registry selections — record each on its own fact.
                  Unanswered leaves the clause off the grant (registry hand-adds). */}
              {triField("P19: is the will to be READ IN CONJUNCTION with this order?", "p19WillReadWithOrder", ["yes", "no"])}
              {triField("P19: is the grant ISSUED PURSUANT TO this order?", "p19IssuedPursuantToOrder", ["yes", "no"])}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {field("Order date", "orderDate", "date")}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-muted-foreground">Filing status in this proceeding</Label>
                  <Select value={form.orderFiled || ""} onValueChange={(v) => { markDirty(); setForm((prev: any) => ({ ...prev, orderFiled: v })); }}>
                    <SelectTrigger className="h-9"><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="filed">Already filed in this proceeding</SelectItem>
                      <SelectItem value="not_yet_filed">Not yet filed — filing a copy with this submission</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </>
          )}
          <div className="space-y-1.5">
            <Label className="text-xs font-medium text-muted-foreground">The will being filed is</Label>
            <Select value={form.willFilingType || ""} onValueChange={(v) => { markDirty(); setForm((prev: any) => ({ ...prev, ...coupleWillFilingTypeFacts({ willFilingType: v }) })); }}>
              <SelectTrigger className="h-9"><SelectValue placeholder="Select..." /></SelectTrigger>
              <SelectContent>
                <SelectItem value="physical_original">The physical original.</SelectItem>
                <SelectItem value="copy">A copy (original lost/destroyed).</SelectItem>
                <SelectItem value="electronic_original">The electronic original.</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-[10px] text-muted-foreground leading-tight">Filing a copy triggers Rule 25-3(6)(d) requiring the long-form P4 affidavit. Electronic originals require Form P45.</p>
          </div>
          {form.willFilingType === "copy" && (
            <>
            <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
              <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
              <AlertDescription className="text-[11px] text-amber-700 dark:text-amber-300">
                <strong>Rule 25-3(6)(d):</strong> Filing a copy of the will (original lost/destroyed) requires the long-form P4 affidavit. The affidavit must explain the circumstances of loss.
              </AlertDescription>
            </Alert>
            <div className="space-y-2 pl-4">
              <Label className="text-xs">Basis for explaining why the physical original cannot be filed</Label>
              <label className="flex items-start gap-2 cursor-pointer">
                <input type="radio" name="willCopyKnowledge" value="first_hand" checked={form.willCopyKnowledge === "first_hand"} onChange={() => { markDirty(); setForm((prev: any) => ({ ...prev, willCopyKnowledge: "first_hand" })); }} className="mt-0.5" />
                <span className="text-xs">The deponent has first-hand knowledge and will state the reason in P4.</span>
              </label>
              <label className="flex items-start gap-2 cursor-pointer">
                <input type="radio" name="willCopyKnowledge" value="affidavit" checked={form.willCopyKnowledge === "affidavit"} onChange={() => { markDirty(); setForm((prev: any) => ({ ...prev, willCopyKnowledge: "affidavit" })); }} className="mt-0.5" />
                <span className="text-xs">A separate affidavit explains why a copy is available but the original is not.</span>
              </label>
              {form.willCopyKnowledge === "first_hand" && (
                <Textarea value={form.willCopyDescription || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, willCopyDescription: e.target.value })); }} className="min-h-[60px] text-xs" placeholder="State the first-hand reason the original cannot be filed." />
              )}
              {form.willCopyKnowledge === "affidavit" && (
                <AffidavitRows maxRows={1} value={form.willCopyAffidavit || ""} onChange={(json) => { markDirty(); setForm((prev: any) => ({ ...prev, willCopyAffidavit: json })); }} />
              )}
            </div>
            </>
          )}
          <div className="space-y-2">
            <Label className="text-xs font-medium text-muted-foreground">Does the will refer to other documents (memorandum, letter of wishes, etc.)?</Label>
            <div className="space-y-2 pl-1">
              {[
                { value: "no", label: "The will does not refer to any documents or refers only to documents attached to the will." },
                { value: "filed", label: "The will refers to document(s) not attached to the will that are filed with this submission." },
                { value: "cannot_be_obtained", label: "The will refers to document(s) not attached to the will that cannot be obtained." },
                { value: "not_testamentary", label: "The will refers to document(s) not attached to the will that are not filed because the document is not testamentary." },
              ].map(opt => (
                <label key={opt.value} className="flex items-start gap-2 cursor-pointer">
                  <input type="radio" name="referencedDocuments" value={opt.value} checked={form.referencedDocuments === opt.value || (opt.value === "filed" && form.referencedDocuments === "yes")} onChange={() => { markDirty(); setForm({ ...form, referencedDocuments: opt.value }); }} className="mt-0.5" />
                  <span className="text-xs">{opt.label}</span>
                </label>
              ))}
            </div>
          </div>
          {(form.referencedDocuments === "filed" || form.referencedDocuments === "yes") && (
            field("Name/describe the referenced document(s)", "referencedDocumentNames")
          )}
          {form.referencedDocuments === "cannot_be_obtained" && (
            <div className="space-y-1">
              <Label className="text-xs">Describe the referenced document(s) and why they cannot be obtained</Label>
              <Textarea value={form.referencedDocumentsCannotObtainReason || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, referencedDocumentsCannotObtainReason: e.target.value })); }} className="min-h-[60px] text-xs" placeholder="e.g., The memorandum dated 1/Feb/2020 could not be located after a thorough search..." />
            </div>
          )}
          {form.referencedDocuments === "not_testamentary" && (
            <div className="space-y-1">
              <Label className="text-xs">Describe the document(s) and why each is not testamentary</Label>
              <Textarea value={form.referencedDocumentsNotTestamentary || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, referencedDocumentsNotTestamentary: e.target.value })); }} className="min-h-[60px] text-xs" placeholder="e.g., The letter is not witnessed and does not relate to the disposition of the estate..." />
            </div>
          )}
          {/* Testamentary document status */}
          <div className="space-y-2">
            <Label className="text-xs font-medium text-muted-foreground">
              {form.hasWill
                ? "Has a testamentary document of the deceased been found that is dated later than the will?"
                : "After a diligent search, was any testamentary document of the deceased found?"}
            </Label>
            <div className="space-y-2 pl-1">
              {[
                ...(form.hasWill ? [{ value: "na", label: "N/A" }] : []),
                { value: "none_found", label: form.hasWill ? "No testamentary document dated later than the will has been found." : "No testamentary document of the deceased has been found." },
                { value: "found", label: form.hasWill ? "One or more testamentary documents dated later than the will have been found." : "One or more testamentary documents have been found." },
              ].map(opt => (
                <label key={opt.value} className="flex items-start gap-2 cursor-pointer">
                  <input type="radio" name="testamentaryDocStatus" value={opt.value} checked={form.testamentaryDocStatus === opt.value} onChange={() => { markDirty(); setForm({ ...form, testamentaryDocStatus: opt.value }); }} className="mt-0.5" />
                  <span className="text-xs">{opt.label}</span>
                </label>
              ))}
            </div>
          </div>
          {form.testamentaryDocStatus === "found" && (
            <>
            <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
              <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
              <AlertDescription className="text-[11px] text-amber-700 dark:text-amber-300">
                {form.hasWill ? (
                  <><strong>Form P4 §5:</strong> Attach the later testamentary document as an exhibit and record why it is invalid or not relevant.</>
                ) : (
                  <><strong>Form P5 §4:</strong> Attach the testamentary document as an exhibit and record why it is invalid or not relevant to this application.</>
                )}
              </AlertDescription>
            </Alert>
            <div className="space-y-1 pl-4">
              <Label className="text-xs">{form.hasWill ? "Why the later testamentary document is invalid or not relevant (Form P4 §5)" : "Why the testamentary document is invalid or not relevant (Form P5 §4)"}</Label>
              <Textarea value={form.laterTestamentaryDescription || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, laterTestamentaryDescription: e.target.value })); }} className="min-h-[60px] text-xs" placeholder="Briefly state the reasons." />
            </div>
            </>
          )}
          {/* Execution issues */}
          <div className="space-y-2">
            <Label className="text-xs font-medium text-muted-foreground">Issues on will execution</Label>
            <div className="space-y-2 pl-1">
              {[
                { value: "na", label: "N/A" },
                { value: "no_issues", label: "I am not aware of there being any issues respecting execution of the will." },
                { value: "has_issues", label: "I believe that there are issue(s) that apply(ies) to the will" },
              ].map(opt => (
                <label key={opt.value} className="flex items-start gap-2 cursor-pointer">
                  <input type="radio" name="executionIssues" value={opt.value} checked={form.executionIssues === opt.value} onChange={() => { markDirty(); setForm({ ...form, executionIssues: opt.value }); }} className="mt-0.5" />
                  <span className="text-xs">{opt.label}</span>
                </label>
              ))}
            </div>
          </div>
          {form.executionIssues === "has_issues" && (
            <>
            <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
              <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
              <AlertDescription className="text-[11px] text-amber-700 dark:text-amber-300">
                <strong>Rule 25-3(6)(g):</strong> Execution issues require the long-form P4 affidavit. The affidavit must address the specific issues.
              </AlertDescription>
            </Alert>
            <div className="space-y-1 pl-4">
              <Label className="text-xs">Describe the execution issues (for P4 affidavit)</Label>
              <Textarea value={form.executionIssueDescription || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, executionIssueDescription: e.target.value })); }} className="min-h-[60px] text-xs" placeholder="e.g., The will was signed by the will-maker but only one witness was present at the time of signing..." />
            </div>
            {/* P4 §6(a) Attestation Clause (Nick UAT D2) */}
            <div className="space-y-2 pl-4">
              <Label className="text-xs font-medium text-muted-foreground">P4 §6(a) — Attestation Clause</Label>
              <div className="space-y-1.5">
                {[
                  { value: "", label: "Not recorded (omit paragraph (a))" },
                  { value: "not_applicable", label: "None of paragraph (a) applies to the will." },
                  { value: "insufficient", label: "The will has no attestation clause, or an insufficient one." },
                ].map(opt => (
                  <label key={opt.value} className="flex items-start gap-2 cursor-pointer">
                    <input type="radio" name="attestationClauseStatus" checked={(form.attestationClauseStatus || "") === opt.value} onChange={() => { markDirty(); setForm((prev: any) => ({ ...prev, attestationClauseStatus: opt.value })); }} className="mt-0.5" />
                    <span className="text-xs">{opt.label}</span>
                  </label>
                ))}
              </div>
              {form.attestationClauseStatus === "insufficient" && (
                <div className="space-y-1.5 pl-4">
                  <Label className="text-xs">Affidavit route (Rule 25-3(15)/(16))</Label>
                  {[
                    { value: "subscribing_witness", label: "Affidavit of a subscribing witness (Rule 25-3 (15))" },
                    { value: "person_present", label: "Affidavit of a person present (Rule 25-3 (16)(a))" },
                    { value: "signature_affidavits", label: "Signature-confirming affidavits (Rule 25-3 (16)(b))" },
                    { value: "presumption_circumstances", label: "Presumption-of-execution affidavit (Rule 25-3 (16)(c))" },
                    { value: "s80_validity", label: "Valid under WESA s.80 — validity affidavits" },
                  ].map(opt => (
                    <label key={opt.value} className="flex items-start gap-2 cursor-pointer">
                      <input type="radio" name="attestationRoute" checked={form.attestationRoute === opt.value} onChange={() => { markDirty(); setForm((prev: any) => ({ ...prev, attestationRoute: opt.value })); }} className="mt-0.5" />
                      <span className="text-xs">{opt.label}</span>
                    </label>
                  ))}
                  {form.attestationRoute && (
                    <div className="space-y-1 pt-1">
                      <Label className="text-[11px] text-muted-foreground">Affidavit(s) submitted for filing</Label>
                      <AffidavitRows value={form.attestationAffidavits || ""} onChange={(json) => { markDirty(); setForm((prev: any) => ({ ...prev, attestationAffidavits: json })); }} />
                    </div>
                  )}
                </div>
              )}
            </div>
            </>
          )}
          {/* Foreign will */}
          <div className="space-y-2">
            <Label className="text-xs font-medium text-muted-foreground">Was the will a foreign one? If so, where was it made?</Label>
            <div className="space-y-2 pl-1">
              {[
                { value: "na", label: "N/A" },
                { value: "made_in_bc", label: "The will was made in British Columbia." },
                { value: "foreign_compliant", label: "The will was made outside of British Columbia, but complies with Division 1 of Part 4 of the Wills, Estates and Succession Act." },
                { value: "foreign_non_compliant", label: "The will was made outside of British Columbia and does not comply with Division 1 of Part 4 of the Wills, Estates and Succession Act." },
              ].map(opt => (
                <label key={opt.value} className="flex items-start gap-2 cursor-pointer">
                  <input type="radio" name="foreignWillStatus" value={opt.value} checked={form.foreignWillStatus === opt.value} onChange={() => { markDirty(); setForm({ ...form, foreignWillStatus: opt.value }); }} className="mt-0.5" />
                  <span className="text-xs">{opt.label}</span>
                </label>
              ))}
            </div>
          </div>
          {form.foreignWillStatus === "foreign_non_compliant" && (
            <>
            <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
              <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
              <AlertDescription className="text-[11px] text-amber-700 dark:text-amber-300">
                <strong>Form P4 §6(c.2) &amp; WESA s.80:</strong> Record the applicable section 80 paragraph and the affidavit filed to explain why section 80 applies.
              </AlertDescription>
            </Alert>
            <div className="space-y-3 pl-4">
              <div className="space-y-1">
                <Label className="text-xs">Applicable paragraph of WESA s.80(1)</Label>
                <Select value={form.foreignWillSection80Paragraph || ""} onValueChange={(v) => { markDirty(); setForm((prev: any) => ({ ...prev, foreignWillSection80Paragraph: v })); }}>
                  <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Select paragraph (a)–(h)" /></SelectTrigger>
                  <SelectContent>
                    {WESA_S80_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">Supporting affidavit deponent</Label>
                  <Input value={form.foreignWillAffidavitName || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, foreignWillAffidavitName: e.target.value })); }} className="h-9 text-xs" placeholder="Name" />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Supporting affidavit sworn date</Label>
                  <Input type="date" value={form.foreignWillAffidavitDate || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, foreignWillAffidavitDate: e.target.value })); }} className="h-9 text-xs" />
                </div>
              </div>
            </div>
            </>
          )}
          {/* Rule 25-3(6)(i) appearance-issues gate — moved here from
              Short-Form Confirmations (2026-08-05 intake de-dup) so the
              will-condition questions sit together. Same column, same control;
              independent of the §7(c) appearance-type details below by design. */}
          <div className="space-y-2">
            <Label className="text-xs font-medium text-muted-foreground">Rule 25-3(6)(i) — Applicant not aware of any issues from the appearance of the will</Label>
            <Select value={form.willAppearanceIssues || ""} onValueChange={(v) => { markDirty(); setForm((prev: any) => ({ ...prev, willAppearanceIssues: v })); }}>
              <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Select..." /></SelectTrigger>
              <SelectContent>
                <SelectItem value="no">No issues — the will's appearance is unremarkable</SelectItem>
                <SelectItem value="yes">Yes — there are issues with the will's appearance</SelectItem>
              </SelectContent>
            </Select>
            {form.willAppearanceIssues === "yes" && (
              <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
                <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
                <AlertDescription className="text-[11px] text-amber-700 dark:text-amber-300">
                  <strong>P4 required:</strong> Appearance issues (e.g., stains, tears, staple holes suggesting removed pages) require the long-form P4 affidavit to explain.
                </AlertDescription>
              </Alert>
            )}
          </div>
          {/* Alterations */}
          <div className="space-y-2">
            <Label className="text-xs font-medium text-muted-foreground">Were there any alterations to the will?</Label>
            <div className="space-y-2 pl-1">
              {[
                { value: "na", label: "N/A" },
                { value: "no_alterations", label: "I am not aware of alterations." },
                { value: "has_alterations", label: "There are interlineations, erasures or obliterations in, or other alterations to the will." },
              ].map(opt => (
                <label key={opt.value} className="flex items-start gap-2 cursor-pointer">
                  <input type="radio" name="willAlterations" value={opt.value} checked={form.willAlterations === opt.value || (opt.value === "has_alterations" && normalizedWillIssues.alterations === "present")} onChange={() => { markDirty(); setForm({ ...form, willAlterations: opt.value }); }} className="mt-0.5" />
                  <span className="text-xs">{opt.label}</span>
                </label>
              ))}
            </div>
          </div>
          {normalizedWillIssues.alterations === "present" && (
            <>
            <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
              <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
              <AlertDescription className="text-[11px] text-amber-700 dark:text-amber-300">
                <strong>Rule 25-3(6)(h):</strong> Alterations to the will require the long-form P4 affidavit. The affidavit must address each alteration.
              </AlertDescription>
            </Alert>
            <div className="space-y-2 pl-4">
              {/* Nick 2026-09-01 directive (P16): structured page/line/type/quoted
                  words compose ¶1's location slot exactly, without repeating the
                  will date; the free-text field remains the fallback exact
                  reference when page/line do not fit the alteration. */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div className="space-y-1"><Label className="text-xs">Page</Label><Input value={(form as any).p16AlterationPage || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, p16AlterationPage: e.target.value })); }} placeholder="e.g. 1" className="h-8 text-xs" /></div>
                <div className="space-y-1"><Label className="text-xs">Line</Label><Input value={(form as any).p16AlterationLine || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, p16AlterationLine: e.target.value })); }} placeholder="e.g. 4" className="h-8 text-xs" /></div>
                <div className="col-span-2 space-y-1">
                  <Label className="text-xs">Type of alteration</Label>
                  <Select value={(form as any).p16AlterationType || ""} onValueChange={(v) => { markDirty(); setForm((prev: any) => ({ ...prev, p16AlterationType: v })); }}>
                    <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="interlineation">Interlineation (words added)</SelectItem>
                      <SelectItem value="erasure">Erasure</SelectItem>
                      <SelectItem value="obliteration">Obliteration</SelectItem>
                      <SelectItem value="other">Other alteration</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Exact words added or affected (quoted on P16 ¶1)</Label>
                <Input value={(form as any).p16AlterationWords || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, p16AlterationWords: e.target.value })); }} maxLength={P16_ALTERATION_WORDS_MAX_LENGTH} placeholder="Enter the actual words from the will" className="h-8 text-xs" />
                <p className="text-[10px] text-muted-foreground">Enter only the actual words from the will. Record page, line, alteration type, and presence in their separate fields.</p>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Other exact reference (used when page/line above are blank; for P16 ¶1)</Label>
                <Textarea value={form.willAlterationsDetail || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, willAlterationsDetail: e.target.value })); }} className="min-h-[60px] text-xs" placeholder="e.g., the margin beside clause 4" />
                {/* Nick 2026-09-03 (fifth estate-#18 live audit, "cottage words persist
                    from old intake"): the pre-0157 auto-composed text above is a
                    hidden second source until it is visible — say what it holds and
                    which of it still prints once the structured fields are used. */}
                {(() => {
                  const legacy = parseP16LegacyLocation(String(form.willAlterationsDetail || ""));
                  if (!legacy || String((form as any).p16AlterationPage || "").trim() !== "") return null;
                  const anyStructured = ["p16AlterationLine", "p16AlterationType", "p16AlterationWords"].some((k) => String((form as any)[k] || "").trim() !== "");
                  return (
                    <p className="text-[10px] text-muted-foreground leading-tight" data-testid="p16-legacy-location-note">
                      Earlier free text records: {legacy.position}{legacy.type ? ` (${legacy.type}` : ""}{legacy.words ? `; the words "${legacy.words}"` : ""}{legacy.type ? ")" : ""}.{" "}
                      {anyStructured
                        ? "Only its page still prints; the type and words print only if entered above. Clear this box once the fields above are complete."
                        : "It prints as-is until you enter the page, line, type or words above — then only its page carries over."}
                    </p>
                  );
                })()}
              </div>
            </div>
            {/* P15PLUS-003/004 (Nick ruling 2026-07-26): the Rule 25-3(20)/(21)
                routes are alternatives — the affidavit "may but need not be in
                Form P16", (b) allows filed evidence, and (21) excepts entirely
                effaced words. P16 stays REQUIRED until a route is chosen. */}
            <div className="space-y-1 pl-4">
              <Label className="text-xs">Rule 25-3(20)/(21) compliance route</Label>
              <Select value={form.willAlterationRoute || ""} onValueChange={(v) => { markDirty(); setForm((prev: any) => ({ ...prev, willAlterationRoute: v })); }}>
                <SelectTrigger className="h-9" data-testid="will-alteration-route"><SelectValue placeholder="Select the route (P16 stays required until chosen)..." /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="p16_affidavit">Affidavit in Form P16</SelectItem>
                  <SelectItem value="other_affidavit">Affidavit NOT in Form P16 ("may but need not be in Form P16")</SelectItem>
                  <SelectItem value="evidence">Filed evidence route (Rule 25-3(20)(b)/(21)(b))</SelectItem>
                  <SelectItem value="effaced">Words entirely effaced — cannot be ascertained on inspection (Rule 25-3(21) exception)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="pl-4">
              {triField("Was the person who will swear P16 present when the will was signed? (P16 ¶2 swears this first-person)", "p16DeponentPresentAtSigning", ["yes", "no"])}
            </div>
            {/* P4 §7(a)-(c) issue-type capture (Nick UAT D3/D4) */}
            <div className="space-y-2 pl-4">
              <Label className="text-xs font-medium text-muted-foreground">P4 §7 — Which of the following are present?</Label>
              {(() => {
                const typeSet = new Set(String(form.willAlterationTypes || "").split(",").map((s: string) => s.trim()).filter(Boolean));
                const toggleType = (t: string, on: boolean) => {
                  const s = new Set(typeSet); on ? s.add(t) : s.delete(t);
                  markDirty(); setForm((prev: any) => ({ ...prev, willAlterationTypes: Array.from(s).join(",") }));
                };
                const set = (patch: any) => { markDirty(); setForm((prev: any) => ({ ...prev, ...patch })); };
                return (
                  <div className="space-y-2">
                    {/* (a) Interlineations */}
                    <label className="flex items-center gap-2 cursor-pointer">
                      <Checkbox checked={typeSet.has("interlineations")} onCheckedChange={(v: any) => toggleType("interlineations", !!v)} />
                      <span className="text-xs">(a) Interlineations</span>
                    </label>
                    {typeSet.has("interlineations") && (
                      <div className="space-y-1 pl-6">
                        {[
                          { value: "compliant", label: "Made in compliance with WESA Div. 1 Part 4" },
                          { value: "authenticated", label: "Authenticated by re-execution or a codicil" },
                          { value: "affidavit_evidence", label: "Cannot confirm — affidavit evidence (Rule 25-3 (20)(a))" },
                          { value: "no_information", label: "No information as to the will-maker's intentions" },
                        ].map(o => (
                          <label key={o.value} className="flex items-start gap-2 cursor-pointer">
                            <input type="radio" name="interlineationTreatment" checked={form.interlineationTreatment === o.value} onChange={() => set({ interlineationTreatment: o.value })} className="mt-0.5" />
                            <span className="text-xs">{o.label}</span>
                          </label>
                        ))}
                        {form.interlineationTreatment === "affidavit_evidence" && (
                          <AffidavitRows value={form.interlineationAffidavits || ""} onChange={(json) => set({ interlineationAffidavits: json })} />
                        )}
                      </div>
                    )}
                    {/* (b) Erasures / obliterations */}
                    <label className="flex items-center gap-2 cursor-pointer">
                      <Checkbox checked={typeSet.has("erasures")} onCheckedChange={(v: any) => toggleType("erasures", !!v)} />
                      <span className="text-xs">(b) Words erased or obliterated</span>
                    </label>
                    {typeSet.has("erasures") && (
                      <div className="space-y-1 pl-6">
                        {[
                          { value: "effaced", label: "Entirely effaced — cannot be ascertained" },
                          { value: "readable_mixed", label: "Some readable; none of the boxes below apply to all" },
                          { value: "words_erased", label: "Words were erased or obliterated and…" },
                        ].map(o => (
                          <label key={o.value} className="flex items-start gap-2 cursor-pointer">
                            <input type="radio" name="erasureStatus" checked={form.erasureStatus === o.value} onChange={() => set({ erasureStatus: o.value })} className="mt-0.5" />
                            <span className="text-xs">{o.label}</span>
                          </label>
                        ))}
                        {form.erasureStatus === "words_erased" && (() => {
                          const treatSet = new Set(String(form.erasureTreatments || "").split(",").map((s: string) => s.trim()).filter(Boolean));
                          const toggleTreat = (t: string, on: boolean) => { const s = new Set(treatSet); on ? s.add(t) : s.delete(t); set({ erasureTreatments: Array.from(s).join(",") }); };
                          return (
                            <div className="space-y-1 pl-4">
                              {[
                                { value: "compliant", label: "Made in compliance with WESA Div. 1 Part 4" },
                                { value: "authenticated", label: "Authenticated by re-execution or a codicil" },
                                { value: "should_not_form_part", label: "Should not form part — affidavits (Rule 25-3 (21)(a))" },
                                { value: "no_information", label: "No information as to intentions" },
                              ].map(o => (
                                <label key={o.value} className="flex items-center gap-2 cursor-pointer">
                                  <Checkbox checked={treatSet.has(o.value)} onCheckedChange={(v: any) => toggleTreat(o.value, !!v)} />
                                  <span className="text-xs">{o.label}</span>
                                </label>
                              ))}
                              {treatSet.has("should_not_form_part") && (
                                <AffidavitRows value={form.erasureAffidavits || ""} onChange={(json) => set({ erasureAffidavits: json })} />
                              )}
                              {treatSet.size >= 2 && (
                                <Input value={form.erasureLocations || ""} onChange={(e) => set({ erasureLocations: e.target.value })} className="text-xs" placeholder="Page number(s) and location(s) each box applies to" />
                              )}
                            </div>
                          );
                        })()}
                      </div>
                    )}
                    {/* (c) Appearance issues — gated purely on the §7 "appearance" type
                        (its own willAlterationTypes token), independent of the pre-existing
                        Rule 25-3(6)(i) willAppearanceIssues Select. Unchecking clears the
                        recorded §7(c) data so a retracted issue can never still print. */}
                    <label className="flex items-center gap-2 cursor-pointer">
                      <Checkbox checked={typeSet.has("appearance")} onCheckedChange={(v: any) => {
                        toggleType("appearance", !!v);
                        if (!v) set({ appearanceIssueTypes: "", appearanceIssueOther: "", appearanceAffidavits: "" });
                      }} />
                      <span className="text-xs">(c) Issues from the appearance of the will</span>
                    </label>
                    {typeSet.has("appearance") && (() => {
                      const apSet = new Set(String(form.appearanceIssueTypes || "").split(",").map((s: string) => s.trim()).filter(Boolean));
                      const toggleAp = (t: string, on: boolean) => { const s = new Set(apSet); on ? s.add(t) : s.delete(t); set({ appearanceIssueTypes: Array.from(s).join(",") }); };
                      return (
                        <div className="space-y-1 pl-6">
                          {[
                            { value: "revocation_attempt", label: "An attempt was made to revoke the will" },
                            { value: "missing_attachment", label: "A page/document previously attached is missing" },
                            { value: "incomplete", label: "The will is incomplete" },
                            { value: "non_compliant_alteration", label: "Altered otherwise than in compliance with WESA" },
                            { value: "other", label: "Other (specify)" },
                          ].map(o => (
                            <label key={o.value} className="flex items-center gap-2 cursor-pointer">
                              <Checkbox checked={apSet.has(o.value)} onCheckedChange={(v: any) => toggleAp(o.value, !!v)} />
                              <span className="text-xs">{o.label}</span>
                            </label>
                          ))}
                          {apSet.has("other") && (
                            <Input value={form.appearanceIssueOther || ""} onChange={(e) => set({ appearanceIssueOther: e.target.value })} className="text-xs" placeholder="It appears that …" />
                          )}
                          <div className="pt-1">
                            <Label className="text-[11px] text-muted-foreground">Supporting affidavit(s)</Label>
                            <AffidavitRows value={form.appearanceAffidavits || ""} onChange={(json) => set({ appearanceAffidavits: json })} />
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                );
              })()}
            </div>
            </>
          )}
          {/* Military will — Rule 25-3(6)(f) */}
          <div className="space-y-2">
            <Label className="text-xs font-medium text-muted-foreground">Is this a military will?</Label>
            <div className="flex gap-4 pl-1">
              {[{ value: "no", label: "No" }, { value: "yes", label: "Yes — military will (not executed per WESA Div 1 Part 4)" }].map(opt => (
                <label key={opt.value} className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="isMilitaryWill" value={opt.value} checked={form.isMilitaryWill === opt.value} onChange={() => { markDirty(); setForm({ ...form, isMilitaryWill: opt.value }); }} />
                  <span className="text-xs">{opt.label}</span>
                </label>
              ))}
            </div>
          </div>
          {form.isMilitaryWill === "yes" && (
            <>
            <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
              <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
              <AlertDescription className="text-[11px] text-amber-700 dark:text-amber-300">
                <strong>Rule 25-3(6)(f) &amp; WESA s.38:</strong> A military will not executed per Division 1 Part 4 requires the long-form P4 affidavit.
              </AlertDescription>
            </Alert>
            <div className="space-y-1 pl-4">
              <Label className="text-xs">Describe the military service and circumstances (for P4 affidavit)</Label>
              <Textarea value={form.militaryWillDescription || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, militaryWillDescription: e.target.value })); }} className="min-h-[60px] text-xs" placeholder="e.g., The deceased was a member of the Canadian Armed Forces serving in..." />
            </div>
            </>
          )}
          {/* Special execution circumstances — Rule 25-3 (18)(a)-(f) */}
          <div className="space-y-2">
            <Label className="text-xs font-medium text-muted-foreground">Special execution circumstances</Label>
            <div className="space-y-2 pl-1">
              {[
                { value: "none", label: "None" },
                { value: "blind", label: "The will-maker was blind" },
                { value: "illiterate", label: "The will-maker was illiterate" },
                { value: "non_english", label: "The will-maker did not fully understand the language in which the will was written" },
                { value: "signed_by_mark", label: "The will-maker signed by a means of a mark instead of handwritten words" },
                { value: "signed_by_another", label: "The will-maker directed another person to sign the will on behalf of the will-maker in the will-maker's presence" },
              ].map(opt => (
                <label key={opt.value} className="flex items-start gap-2 cursor-pointer">
                  <input type="checkbox" value={opt.value} checked={opt.value === "none" ? form.specialCircumstances === "none" : String(form.specialCircumstances || "").split(",").includes(opt.value)} onChange={(event) => {
                    markDirty();
                    if (opt.value === "none") {
                      setForm({ ...form, specialCircumstances: "none" });
                      return;
                    }
                    const selected = String(form.specialCircumstances || "").split(",").map((v: string) => v.trim()).filter((v: string) => v && v !== "none");
                    const next = event.target.checked ? (selected.includes(opt.value) ? selected : [...selected, opt.value]) : selected.filter((v: string) => v !== opt.value);
                    setForm({ ...form, specialCircumstances: next.length ? next.join(",") : "" });
                  }} className="mt-0.5" />
                  <span className="text-xs">{opt.label}</span>
                </label>
              ))}
            </div>
          </div>
          {String(form.specialCircumstances || "").split(",").some((v: string) => v && v !== "none") && (
            <div className="space-y-2 pl-2 border-l-2 border-amber-200 dark:border-amber-800">
              <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
                <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
                <AlertDescription className="text-[11px] text-amber-700 dark:text-amber-300">
                  <strong>Rule 25-3 (18):</strong> Select every circumstance that applied. Rule 25-3 (18)(f) requires those circumstances to be indicated in the long-form P4 affidavit.
                </AlertDescription>
              </Alert>
              <Label className="text-[11px] text-muted-foreground">How will the circumstance be addressed in the P4 affidavit?</Label>
              <div className="space-y-2 pl-1">
                {[
                  { value: "attestation_indicates", label: "The attestation clause in the will indicates that the circumstance applied to the will-maker at the time of the signing of the will." },
                  { value: "supporting_affidavits", label: "The following affidavit(s) is/are submitted for filing with the submission for estate grant as evidence that the requirements of the Wills, Estates and Succession Act relating to the execution of the will were met and that the will-maker knew and approved of the content of the will:" },
                  { value: "s80_validity", label: "The will is valid as to the formal requirements for making the will and is admissible to probate under section 80 of the Wills, Estates and Succession Act, and the following affidavit(s) confirm that validity:" },
                ].map(opt => (
                  <label key={opt.value} className="flex items-start gap-2 cursor-pointer">
                    <input type="radio" name="specialCircumstancesFollowUp" value={opt.value} checked={form.specialCircumstancesFollowUp === opt.value} onChange={() => { markDirty(); setForm({ ...form, specialCircumstancesFollowUp: opt.value }); }} className="mt-0.5" />
                    <span className="text-xs">{opt.label}</span>
                  </label>
                ))}
              </div>
              {form.specialCircumstancesFollowUp && form.specialCircumstancesFollowUp !== "attestation_indicates" && (
                <div className="pt-1">
                  <Label className="text-[11px] text-muted-foreground">Supporting affidavit(s)</Label>
                  <AffidavitRows value={form.specialCircumstancesAffidavits || ""} onChange={(json) => { markDirty(); setForm((prev: any) => ({ ...prev, specialCircumstancesAffidavits: json })); }} />
                </div>
              )}
            </div>
          )}
          {/* Will language — P2 Section 8 */}
          <div className="space-y-2">
            <Label className="text-xs font-medium text-muted-foreground">Will language</Label>
            <div className="flex gap-4 pl-1">
              {[{ value: "english", label: "English" }, { value: "other", label: "Other language (translation required)" }].map(opt => (
                <label key={opt.value} className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="willLanguage" value={opt.value} checked={form.willLanguage === opt.value} onChange={() => { markDirty(); setForm({ ...form, willLanguage: opt.value }); }} />
                  <span className="text-xs">{opt.label}</span>
                </label>
              ))}
            </div>
          </div>
          {form.willLanguage === "other" && (
            <>
              <Alert className="bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800">
                <Info className="h-3.5 w-3.5 text-blue-600" />
                <AlertDescription className="text-[11px] text-blue-700 dark:text-blue-300">
                  <strong>Rule 25-3(2)(h):</strong> For each document filed with the submission that is not written in English, an affidavit of translator in Form P12 must be filed.
                </AlertDescription>
              </Alert>
              {field("Source language of the will (e.g., Punjabi, Mandarin)", "willSourceLanguage")}
              {field("Translator name (for Form P12 reference)", "translatorName")}
              {field("Translator's address (prints on the P12 preamble)", "translatorAddress")}
              {field("Translator's occupation (prints on the P12 preamble)", "translatorOccupation")}
              {field("Document translated (a translated will prints as 'will dated dd/mmm/yyyy' from the recorded will date; name any other document, e.g. 'codicil dated 01/Feb/2021')", "translatedDocument")}
            </>
          )}
          {/* ─── WESA s.58 CURATIVE RELIANCE ─── */}
          <Card className="border-purple-200 dark:border-purple-800 bg-purple-50/30 dark:bg-purple-950/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">WESA s.58 Curative Reliance</CardTitle>
            <CardDescription className="text-[11px]">
              Only enable if a court has issued (or you are applying for) an order under WESA s.58 declaring a record to be fully effective as a will, revocation, alteration, or revival.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Select value={form.wesaS58Reliance || ""} onValueChange={(v) => { markDirty(); setForm((prev: any) => ({ ...prev, wesaS58Reliance: v })); }}>
              <SelectTrigger className="text-xs">
                <SelectValue placeholder="Select..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="no">No — standard will</SelectItem>
                <SelectItem value="yes">Yes — applying for or relying on a s.58 order</SelectItem>
              </SelectContent>
            </Select>
            {form.wesaS58Reliance === "yes" && (
              <>
                <Select value={form.wesaS58RecordType || ""} onValueChange={(v) => { markDirty(); setForm((prev: any) => ({ ...prev, wesaS58RecordType: v })); }}>
                  <SelectTrigger className="text-xs">
                    <SelectValue placeholder="Record type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="text_message">Text message / SMS</SelectItem>
                    <SelectItem value="draft_will">Draft or unexecuted will</SelectItem>
                    <SelectItem value="unwitnessed_note">Unwitnessed handwritten note</SelectItem>
                    <SelectItem value="email">Email</SelectItem>
                    <SelectItem value="other">Other electronic or written record</SelectItem>
                  </SelectContent>
                </Select>
                <Textarea
                  placeholder="Describe the record (medium, date, contents, custody)"
                  value={form.wesaS58RecordDescription || ""}
                  onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, wesaS58RecordDescription: e.target.value })); }}
                  className="min-h-[60px] text-xs"
                />
                <div className="space-y-1">
                  <Label className="text-xs">Court order date (if already granted)</Label>
                  <Input
                    type="date"
                    value={form.wesaS58OrderDate || ""}
                    onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, wesaS58OrderDate: e.target.value })); }}
                    className="text-xs"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Sealed WESA s. 58 order</Label>
                  {form.wesaS58OrderFilePath ? (
                    <div className="flex items-center gap-2 rounded-md border p-2">
                      <FileText className="h-4 w-4 text-primary" />
                      <span className="text-xs flex-1 truncate">Order attached</span>
                      <Button type="button" variant="ghost" size="sm" className="h-7 text-xs" onClick={() => void previewStoredFile(form.wesaS58OrderFilePath)}>View</Button>
                      <Button type="button" variant="ghost" size="sm" className="h-7 text-xs" onClick={() => clearLegalEvidenceMutation.mutate({ estateId, kind: "wesa_s58_order" })}>Remove</Button>
                    </div>
                  ) : (
                    <Input type="file" accept="application/pdf,image/*" className="h-9 text-xs" onChange={(event) => void uploadLegalEvidence("wesa_s58_order", event.target.files?.[0])} />
                  )}
                </div>
                <Alert className="bg-purple-50 dark:bg-purple-950/30 border-purple-200 dark:border-purple-800">
                  <Info className="h-3.5 w-3.5 text-purple-600" />
                  <AlertDescription className="text-[11px] text-purple-700 dark:text-purple-300">
                    <strong>WESA s.58:</strong> The court order must be granted before the estate grant can be filed. Relying on s.58 requires the long-form P4 affidavit; file the order with the submission.
                  </AlertDescription>
                </Alert>
              </>
            )}
          </CardContent>
          </Card>
          </>
        ) : null}
      </SectionHeader>

      {/* ─── RULE 25-3(6) SHORT-FORM CONFIRMATIONS ─── */}
      {form.hasWill ? (
        <SectionHeader title="Short-Form Affidavit Confirmations — Rule 25-3(6)">
          <p className="text-[10px] text-muted-foreground mb-3">These confirmations determine whether the short-form P3 affidavit may be used. All must be affirmatively confirmed for P3; otherwise P4 (long-form) is required.</p>

          {/* (c) Belief this is last BC will */}
          <div className="space-y-2">
            <Label className="text-xs font-medium text-muted-foreground">Rule 25-3(6)(c) — Applicant believes this is the last will dealing with BC property</Label>
            <Select value={form.beliefLastBcWill || ""} onValueChange={(v) => { markDirty(); setForm((prev: any) => ({ ...prev, beliefLastBcWill: v })); }}>
              <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Select..." /></SelectTrigger>
              <SelectContent>
                <SelectItem value="yes">Yes — I believe this is the last will dealing with BC property</SelectItem>
                <SelectItem value="no">No — I am not certain this is the last will</SelectItem>
              </SelectContent>
            </Select>
            {form.beliefLastBcWill === "no" && (
              <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
                <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
                <AlertDescription className="text-[11px] text-amber-700 dark:text-amber-300">
                  <strong>P4 required:</strong> The applicant cannot swear the short-form P3 unless they believe this is the last will dealing with BC property.
                </AlertDescription>
              </Alert>
            )}
          </div>

          {/* (i) Appearance issues — the Rule 25-3(6)(i) question moved up to
              "Information About the Will" beside the alterations questions
              (2026-08-05 intake de-dup); recorded there, checked here. */}
          <p className="text-[10px] text-muted-foreground italic">Rule 25-3(6)(i) appearance issues — recorded with the will details above.</p>

          {/* (j) Documents referred to in the will are attached */}
          <div className="space-y-2">
            <Label className="text-xs font-medium text-muted-foreground">Rule 25-3(6)(j) — Any document referred to in the will is attached to the will</Label>
            {form.referencedDocuments === "no" ? (
              <p className="text-xs text-muted-foreground italic">Auto-resolved: the will does not reference other documents (set above), so this requirement is satisfied (N/A).</p>
            ) : (
              <>
                <Select value={form.willDocumentsAttached || ""} onValueChange={(v) => { markDirty(); setForm((prev: any) => ({ ...prev, willDocumentsAttached: v })); }}>
                  <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Select..." /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="yes">Yes — all referenced documents are attached</SelectItem>
                    <SelectItem value="no">No — referenced documents are missing or not attached</SelectItem>
                    <SelectItem value="na">N/A — the will does not refer to any external documents</SelectItem>
                  </SelectContent>
                </Select>
                {form.willDocumentsAttached === "no" && (
                  <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
                    <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
                    <AlertDescription className="text-[11px] text-amber-700 dark:text-amber-300">
                      <strong>P4 required:</strong> If documents referred to in the will are not attached, the long-form P4 affidavit is required to explain.
                    </AlertDescription>
                  </Alert>
                )}
              </>
            )}
          </div>
        </SectionHeader>
      ) : null}

      {/* ─── VSA CERTIFICATE RESULT — the single wills-search home (Rule 21) ─── */}
      <SectionHeader title="Wills Notice Search Result (from the certificate)">
        <div className="space-y-3">
          {selectField(
            "Result of VSA Wills Notice Search (Form P3 §8 / P4 §4)",
            "vsaCertificateResult",
            [
              { value: "no_notice", label: "No wills notice was found for the deceased" },
              { value: "wills_notice_found", label: "A wills notice was found for the deceased" },
            ],
            undefined,
            {
              label: "VSA wills notice search guidance",
              testId: "vsa-wills-notice-search-guidance-trigger",
              children: <>
                <p>Record the result exactly as shown on the VSA 532 certificate. Track receipt of the certificate itself under Readiness → Required Source Documents.</p>
                {form.vsaCertificateResult === "no_notice" && (
                  <p className="mt-2">
                    P3 §8 will state: "A certificate from the chief executive officer under the Vital Statistics Act indicating the results of a search for a wills notice filed by or on behalf of the deceased is filed with this application, and the certificate indicates that no testamentary document that is dated later than the date of the will has been found." On P4 the certificate result is recorded in §4.
                  </p>
                )}
                {!formFocusedIntake && ["no_notice", "wills_notice_found"].includes(form.vsaCertificateResult || "") && (
                  <p className="mt-2">
                    The search must cover the deceased&apos;s legal name and every recorded alias — readiness checks this list against the recorded names; an omitted alias is a registry rejection risk.
                  </p>
                )}
              </>,
            },
          )}
          {form.vsaCertificateResult === "wills_notice_found" && (
            <div className="pl-4 border-l-2 border-primary/20 space-y-2">
              {field("Date on the Wills Notice", "vsaWillsNoticeDate", "date")}
              <Alert className="bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800">
                <Info className="h-3.5 w-3.5 text-blue-600" />
                <AlertDescription className="text-[11px] text-blue-700 dark:text-blue-300">
                  <strong>Rule 25-3 (6) (e):</strong> The P3 short form is available only if the certificate indicates that no wills notice has been filed in relation to a testamentary document dated later than the date of the will. A wills notice for a later-dated testamentary document defeats the P3 short form — the long-form P4 is required, and P4 §4 records the certificate result.
                </AlertDescription>
              </Alert>
            </div>
          )}
          {!formFocusedIntake && ["no_notice", "wills_notice_found"].includes(form.vsaCertificateResult || "") && (
            field("Names searched (as shown on the VSA 532 certificate)", "vsaNamesSearched", "text", "Comma-separated legal name and every alias searched")
          )}
        </div>
      </SectionHeader>

      {/* Rule 25-2 notice enclosure uploads */}
      {(recordedWillStatus === "will" || requiresForeignGrantCopy(form)) ? <WillUploadSection estateId={estateId} estate={estate} /> : null}

      {/* ─── APPLICATION & APPLICANTS ─── */}
      <SectionHeader title="Application & Applicants">
        <div className="rounded-lg border border-primary/15 bg-primary/[0.035] px-3 py-2.5" role="status">
          <p className="text-xs font-semibold text-foreground">Applicant details come from Contacts</p>
          <p className="mt-0.5 text-[11px] leading-snug text-muted-foreground">Mark the appropriate Executor, Administrator, or Applicant contact as applying. The same contact supplies applicant details across the probate forms and the VSA 532 search.</p>
          {onNavigateToContacts && (
            <Button type="button" size="sm" variant="outline" className="mt-2 h-7 px-2 text-[11px]" onClick={onNavigateToContacts}>
              Open applicant contact
            </Button>
          )}
        </div>
        {/* Rule 25-3(13): only when the PGT is the applicant may it direct that the
            court file be sealed (Form P13). Enables the P13 form on the Forms tab. */}
        {triField("Is the Public Guardian and Trustee the applicant for the grant?", "pgtIsApplicant")}
        {/* Form P13 optional insertion (Rule 25-3 (13) / WESA s.125 (a), Rule 17):
            "[add, if required: including the following related material ...[identify]...]".
            Recorded text prints inside the sealing direction; blank keeps the
            face's base direction (court file alone). */}
        {form.pgtIsApplicant === "yes" && (
          <div className="space-y-1">
            <Label htmlFor="p13SealedMaterial" className="text-xs font-medium text-muted-foreground">Related material to be sealed with the court file (Form P13 — optional)</Label>
            <Textarea id="p13SealedMaterial" value={form.p13SealedMaterial || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, p13SealedMaterial: e.target.value })); }} className="min-h-[60px] text-xs" placeholder="Identify the related material the PGT directs be sealed. Leave blank to direct sealing of the court file alone." />
            <p className="text-[10px] text-muted-foreground italic">Prints on Form P13 as the face's optional insertion: &quot;including the following related material ...&quot; (WESA s.125 (a): the PGT may specify related material to be sealed).</p>
          </div>
        )}
        {/* WESA s.130 priority fields — only for intestate estates */}
        {recordedWillStatus === "no_will" && (() => {
          return (
          <div className="border-l-2 border-blue-300 pl-4 ml-2 space-y-3">
            <div className="flex items-start gap-2 p-2 bg-blue-50 border border-blue-200 rounded text-xs text-blue-800 dark:bg-blue-950/30 dark:border-blue-800 dark:text-blue-300 mb-2">
              <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
              <span>WESA s.130: Applicant must declare their statutory priority to apply for administration without will.</span>
            </div>
            <P5TestamentaryDocumentFields
              status={form.testamentaryDocStatus || ""}
              description={form.laterTestamentaryDescription || ""}
              onChange={(patch) => { markDirty(); setForm((prev: any) => ({ ...prev, ...patch })); }}
            />
            <div className="max-w-[34rem] space-y-1.5" data-testid="p5-priority-control">
              <Label htmlFor="applicantPriorityParagraph" className="text-xs font-medium text-muted-foreground">Applicant's WESA s.130 priority paragraph</Label>
              <Select
                value={form.applicantPriorityParagraph || ""}
                onValueChange={(v) => { markDirty(); setForm((prev: any) => ({ ...prev, applicantPriorityParagraph: v })); }}
              >
                <SelectTrigger
                  id="applicantPriorityParagraph"
                  aria-label={WESA_S130_PRIORITY_OPTIONS.find((option) => option.value === form.applicantPriorityParagraph)?.label || "Applicant's WESA s.130 priority paragraph"}
                  className="h-10 w-full border-border/80 bg-background text-left shadow-sm transition-[border-color,background-color,box-shadow] duration-150 hover:border-primary/45 hover:bg-primary/[0.025] focus-visible:border-primary/60 focus-visible:ring-primary/20"
                  data-testid="p5-priority-trigger"
                >
                  {(() => {
                    const selected = WESA_S130_PRIORITY_OPTIONS.find((option) => option.value === form.applicantPriorityParagraph);
                    return <span className={`min-w-0 truncate ${selected ? "text-foreground" : "text-muted-foreground"}`}>{selected ? `${selected.value} — ${selected.shortLabel}` : "Select statutory priority..."}</span>;
                  })()}
                </SelectTrigger>
                <SelectContent
                  align="start"
                  className="max-h-[min(24rem,var(--radix-select-content-available-height))] w-[min(34rem,calc(100vw-2rem))] rounded-xl border-border/80 p-1.5 shadow-xl duration-150"
                  data-testid="p5-priority-options"
                >
                  {WESA_S130_PRIORITY_OPTIONS.map((option) => (
                    <SelectItem
                      key={option.value}
                      value={option.value}
                      textValue={`${option.value} ${option.shortLabel}`}
                      className="h-auto items-start rounded-lg px-3 py-2.5 pr-9 text-xs leading-snug transition-colors duration-150 hover:bg-primary/[0.06] hover:text-foreground focus:bg-primary/[0.08] focus:text-foreground data-[state=checked]:bg-primary/[0.09]"
                    >
                      <span className="block min-w-0 whitespace-normal">
                        <span className="block font-medium text-foreground">{option.value} · {option.shortLabel}</span>
                        <span className="mt-0.5 block text-[11px] leading-relaxed text-muted-foreground">{option.label}</span>
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs leading-relaxed text-muted-foreground">Choose the applicable statutory row. The menu preserves the full legal wording; this saved choice is the sole source for the paragraph cited in Form P5.</p>
            </div>
            {/* P5-sweep 2026-07-10: prior/equal-right consent is recorded per
                contact (priorityConsent) on the Contacts tab — the legacy
                estate-level priorRightsStatus controls are retired. */}
            <div className="flex items-start gap-2 p-2 bg-muted border rounded text-xs text-muted-foreground">
              <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
              <span>Record each prior/equal-right person's consent status (consented, renounced, or cannot be located) on their contact in the Contacts tab.</span>
            </div>
            {selectField("Consent state of intestate successors", "intestateConsentState", [
              { value: "majority_consent", label: "Majority of the relevant class has consented" },
              { value: "no_majority_consent", label: "No majority consent obtained" },
            ])}
            <div className="flex items-center gap-3 py-1">
              <input
                type="checkbox"
                id="applicantIsNominee"
                checked={!!form.applicantIsNominee}
                onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, applicantIsNominee: e.target.checked ? 1 : 0 })); }}
                className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
              />
              <Label htmlFor="applicantIsNominee" className="text-xs font-medium text-muted-foreground cursor-pointer">
                Applicant is a nominee of an intestate successor (not the successor themselves)
              </Label>
            </div>
            <div className="flex items-center gap-3 py-1">
              <input
                type="checkbox"
                id="applicantIsGovernmentNominee"
                checked={!!form.applicantIsGovernmentNominee}
                onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, applicantIsGovernmentNominee: e.target.checked ? 1 : 0 })); }}
                className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
              />
              <Label htmlFor="applicantIsGovernmentNominee" className="text-xs font-medium text-muted-foreground cursor-pointer">
                Applicant is a nominee of the government of British Columbia (estate would otherwise escheat)
              </Label>
            </div>
          </div>
          );
        })()}
        {!formFocusedIntake && (
          <div className="mt-3 rounded-lg border border-primary/15 bg-primary/[0.035] px-3 py-2.5" role="status" aria-live="polite" data-testid="vsa-applicant-contact-advisory">
            <div className="flex items-start gap-2">
              <CircleCheck className={`mt-0.5 h-4 w-4 shrink-0 ${applyingContactDetails.fullName && applyingContactDetails.postalCode ? "text-emerald-600" : "text-primary"}`} aria-hidden="true" />
              <div className="min-w-0">
                <p className="text-xs font-semibold text-foreground">VSA 532 applicant details come from Contacts</p>
                {applyingContactDetails.fullName ? (
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    <span className="font-medium text-foreground">{applyingContactDetails.fullName}</span>
                    {applyingContactDetails.postalCode ? ` · ${applyingContactDetails.postalCode}` : " · postal code missing"}
                  </p>
                ) : (
                  <p className="mt-0.5 text-xs text-muted-foreground">Add an applying Applicant or Executor contact in the Contacts tab to supply the VSA 532 details.</p>
                )}
                <p className="mt-1 text-[11px] leading-snug text-muted-foreground">Edit the contact card to correct the applicant’s name or postal code. Intake no longer stores a duplicate copy.</p>
                {onNavigateToContacts && (
                  <Button type="button" size="sm" variant="outline" className="mt-2 h-7 px-2 text-[11px]" onClick={onNavigateToContacts}>
                    Open applicant contact
                  </Button>
                )}
              </div>
            </div>
          </div>
        )}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {selectField("Grant Type", "grantType", [
            { value: "unknown", label: "Not yet selected" },
            { value: "grant_of_probate", label: "Grant of Probate" },
            { value: "grant_of_admin_with_will", label: "Administration with Will Annexed" },
            { value: "grant_of_admin", label: "Grant of Administration" },
            { value: "ancillary_probate", label: "Ancillary Grant of Probate" },
            { value: "ancillary_admin_with_will", label: "Ancillary Grant of Admin with Will" },
            { value: "ancillary_admin_no_will", label: "Ancillary Grant of Admin without Will" },
            { value: "resealing", label: "Resealing" },
          ], undefined, {
            label: "grant type definitions",
            testId: "grant-type-definitions-guidance-trigger",
            children: "Probate = named executor in will. Administration with Will = no executor named/available. Administration = no will (intestacy). Ancillary = deceased domiciled outside BC.",
          })}
          {form.grantType && (() => {
            const gt = form.grantType;
            const isAncillaryGrant = gt.includes("ancillary");
            const isIntestacy = gt === "grant_of_admin" || gt === "admin_no_will";
            const hint = isAncillaryGrant
              ? `Ancillary grant: ${primaryApplicantAffidavitForm(form as any)} is the primary applicant affidavit; P3, P4 and P5 do not apply.`
              : isIntestacy
              ? "Intestacy: P5 (Affidavit of Applicant for Admin) will be required instead of P3/P4."
              : null;
            if (!hint) return null;
            return <p className="col-span-full text-[10px] text-blue-600 dark:text-blue-400 italic flex items-center gap-1"><Info className="h-3 w-3 shrink-0" />{hint}</p>;
          })()}
          {/* 2026-08-05 intake de-dup: the applicant count row was removed —
              contacts are the source of truth. The Rule 25-3(2)(c) P8 hint stays. */}
          {applyingApplicantCount > 1 && (
            <p className="col-span-full text-[10px] text-blue-600 dark:text-blue-400 italic flex items-center gap-1"><Info className="h-3 w-3 shrink-0" /><span><strong>Rule 25-3 (2) (c):</strong> {applyingApplicantCount} contacts are applying — each co-applicant after the primary requires a separate Form P8 (Affidavit in Support of Application for Estate Grant).</span></p>
          )}
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Checkbox id="limitedGrant" checked={!!form.limitedGrant} onCheckedChange={(v) => { markDirty(); setForm({ ...form, limitedGrant: v ? 1 : 0 }); }} />
              <Label htmlFor="limitedGrant" className="text-xs font-medium text-muted-foreground">This is a limited grant</Label>
            </div>
          </div>
          {!!form.limitedGrant && (
            !formFocusedIntake && (
              <div className="col-span-full space-y-1">
                <Label className="text-xs font-medium text-muted-foreground">Grant Limitation (describe the limitation)</Label>
                <Textarea value={form.grantLimitation || ""} onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => { markDirty(); setForm({ ...form, grantLimitation: e.target.value }); }} placeholder="e.g., Limited to the real property located at 123 Main St, Vancouver, BC" className="min-h-[60px]" />
                <p className="text-[10px] text-muted-foreground">Case-file reference only — the Form P19 limited-grant clause is controlled by the recorded limited-grant selection.</p>
              </div>
            )
          )}
          {!(form.grantType || "").includes("ancillary") && (
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Checkbox id="useLongFormAffidavit" checked={!!form.useLongFormAffidavit} onCheckedChange={(v) => { markDirty(); setForm({ ...form, useLongFormAffidavit: v ? 1 : 0 }); }} />
                <div className="flex min-w-0 items-center gap-0.5">
                  <Label htmlFor="useLongFormAffidavit" className="text-xs font-medium text-muted-foreground">Use long-form applicant affidavit (P4 instead of P3)</Label>
                  <IntakeGuidanceTooltip
                    label="P4 long-form override guidance"
                    testId="p4-long-form-override-guidance-trigger"
                    className="-my-1"
                  >
                    Override: forces Form P4 even when no Rule 25-3(6) trigger is present. P4 is always required when triggers exist.
                  </IntakeGuidanceTooltip>
                </div>
              </div>
            </div>
          )}
        </div>
        {estateHasNoWillOfRecord(form) && (
          <>
            {selectField("Creditor notice review (claims over $10,000)", "creditorReviewStatus", [
              { value: "unknown", label: "Not yet reviewed" },
              { value: "none_over_10000", label: "No creditor claim over $10,000 identified" },
              { value: "creditors_recorded", label: "Every creditor with a claim over $10,000 is recorded in Contacts" },
            ], undefined, {
              label: "creditor notice review guidance",
              testId: "creditor-notice-review-guidance-trigger",
              children: "Rule 25-2(2)(b)(ii) requires P1 notice to each creditor whose claim exceeds $10,000. Record the review here and the qualifying creditor contacts in Contacts.",
            })}
          </>
        )}
        {!formFocusedIntake && (
          <p className="text-[10px] text-muted-foreground">Citations are recorded per cited person in the Forms tab, including service, response, evidence, and Form P34 eligibility.</p>
        )}
        {selectField("Has another application been made or grant been issued in relation to the deceased?", "otherGrantsStatus", [
          { value: "unknown", label: "Not yet recorded" },
          { value: "no_other_grants", label: "No other application or grant is known" },
          { value: "grants_exist", label: "One or more grants have been issued" },
          { value: "other_applicants", label: "One or more other people have also applied" },
        ])}
        {["grants_exist", "yes_bc", "yes_other", "has_other_grants", "grant_exists"].includes(form.otherGrantsStatus) && (
          <div className="border-l-2 border-amber-300 pl-4 ml-2 space-y-2">
            <div className="space-y-1">
              <Label className="text-xs font-medium text-muted-foreground">Describe the other grant (jurisdiction, date, type)</Label>
              <textarea
                className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 min-h-[80px] resize-y"
                value={form.otherGrantsDescription || ""}
                onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, otherGrantsDescription: e.target.value })); }}
                placeholder="e.g. Grant of Probate issued by the Supreme Court of Ontario, dated January 15, 2025, File No. CV-25-12345"
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs font-medium text-muted-foreground">Why is the other grant not relevant to this application?</Label>
              <Textarea
                value={form.otherGrantsRelevanceReason || ""}
                onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, otherGrantsRelevanceReason: e.target.value })); }}
                placeholder="Briefly state the reasons."
                className="min-h-[60px] text-xs"
              />
            </div>
            <div className="flex items-start gap-2 p-2 bg-amber-50 border border-amber-200 rounded text-xs text-amber-800 dark:bg-amber-950/30 dark:border-amber-800 dark:text-amber-300">
              <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
              <span>Rule 25-3(6)(k): An issued grant requires Form P4 for a probate or administration-with-will application. The description and reason populate the official P4 §9 or P5 §6 branch.</span>
            </div>
          </div>
        )}
        {form.otherGrantsStatus === "other_applicants" && (
          <div className="border-l-2 border-amber-300 pl-4 ml-2 space-y-1">
            <Label className="text-xs font-medium text-muted-foreground">Name each other person who has also applied</Label>
            <Textarea
              value={form.otherGrantApplicants || ""}
              onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, otherGrantApplicants: e.target.value })); }}
              placeholder="Insert name(s)."
              className="min-h-[60px] text-xs"
            />
          </div>
        )}
        {/* B-07: prefillJurats / hideExecutorAddress toggles removed — nothing consumed
            them (dead switches implying behavior); the schema columns remain. */}
      </SectionHeader>

      {/* ─── ANCILLARY GRANTS ─── */}
      {(form.grantType || "").includes("ancillary") || form.grantType === "resealing" ? (
      <SectionHeader title="Ancillary / Foreign Grant Details">
        {(form.grantType || "").includes("ancillary") && (
          <>
            <div className="mt-4 pt-4 border-t border-border">
              <p className="text-xs text-muted-foreground mb-3">Rule 25-3(3)(b)/(c) — Required for P6/P7 affidavit generation:</p>
              {field("Issuing court (for P6/P7 affidavit)", "foreignGrantIssuingCourt")}
              {field("Jurisdiction of issuing court", "foreignGrantIssuingJurisdiction")}
              {field("Date the foreign grant was issued", "foreignGrantIssuedDate", "date")}
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-muted-foreground">People named in the foreign grant</Label>
                <Textarea
                  value={form.foreignGrantGranteeNames || ""}
                  onChange={(event) => {
                    markDirty();
                    setForm((previous: any) => ({ ...previous, foreignGrantGranteeNames: event.target.value }));
                  }}
                  placeholder={"Enter one name per line, exactly as it appears in the foreign grant."}
                  className="min-h-[88px] text-sm"
                />
                <p className="text-[11px] text-muted-foreground">Each listed person must also be recorded as an applying applicant before Form P6 or P7 can be generated.</p>
              </div>
              {form.hasWill ? selectField("Are the will and any codicils attached to and included in the foreign grant?", "foreignGrantIncludesWill", [
                { value: "unknown", label: "Not recorded" },
                { value: "yes", label: "Yes — the will and any codicils form part of the foreign grant" },
                { value: "no", label: "No — separate will documents must be uploaded" },
              ]) : null}
              {selectField("Is the uploaded foreign grant certified by the court that issued it?", "foreignGrantCertifiedByIssuingCourt", [
                { value: "unknown", label: "Not yet confirmed" },
                { value: "yes", label: "Yes — certified by the issuing court" },
                { value: "no", label: "No — not certified by the issuing court" },
              ])}
              {form.hasWill ? selectField("Are the will and every codicil being filed certified by the court that issued the foreign grant?", "ancillaryWillDocumentsCertifiedByIssuingCourt", [
                { value: "unknown", label: "Not yet confirmed" },
                { value: "yes", label: "Yes — every will document is certified" },
                { value: "no", label: "No — one or more will documents are not certified" },
              ]) : null}
              <Alert className="mt-3 bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800">
                <Info className="h-3.5 w-3.5 text-blue-600" />
                <AlertDescription className="text-[11px] text-blue-700 dark:text-blue-300">
                  Rule 25-3(3)(b)/(c) requires issuing-court-certified filing copies. Uploading a copy for P1 notice does not by itself confirm certification.
                </AlertDescription>
              </Alert>
            </div>
          </>
        )}
        {form.grantType === "resealing" && (
          <div className="mt-4 pt-4 border-t border-border">
            {/* Rule 25-6(7) — Form P26 paragraph 1 prints these two slots ("a grant
                issued by the ...[name of issuing court]... on ...[dd/mmm/yyyy]...").
                Without inputs here the p26_foreign_grant_* requirement rows were
                unsatisfiable and the sworn paragraph printed permanently blank. */}
            <p className="text-xs text-muted-foreground mb-3">Rule 25-6(7) — Printed in paragraph 1 of the P26 supplemental affidavit:</p>
            {field("Name of the court that issued the foreign grant (printed in P26 paragraph 1)", "foreignGrantIssuingCourt")}
            {field("Date the foreign grant was issued (printed in P26 paragraph 1)", "foreignGrantIssuedDate", "date")}
          </div>
        )}
        {/* 2026-08-05 intake de-dup + review F5: ancillaryCourt/ancillaryProvince
            removed (duplicated foreignGrant*, printed on nothing) and the
            ancillaryDate control removed too — the date is asked ONCE as
            foreignGrantIssuedDate above; estate.update keeps the legacy
            ancillaryDate twin in lockstep server-side so P19's grant-face
            clause can never contradict P2/P6/P7/P26. */}
      </SectionHeader>
      ) : null}

      {/* ─── NOTICES & PGT ─── */}
      <SectionHeader title="Notices & PGT">
        {triField("Do you need to notify the PGT?", "notifyPGT", undefined, undefined, {
          label: "PGT notification guidance",
          testId: "pgt-notification-guidance-trigger",
          children: "Even if set to \"No\" here, PGT notification is automatically required when any beneficiary is marked as a minor or mentally incapable. The auto-calculation overrides this toggle in that scenario.",
        })}
        {triField("Have all persons entitled to notice been recorded as contacts?", "noticeContactsComplete", undefined, undefined, {
          label: "notice contacts guidance",
          testId: "notice-contacts-guidance-trigger",
          markerClassName: "intake-info-tooltip-marker--contacts",
          children: "Answer \"Yes\" only after every executor, beneficiary and intestate successor is entered on the Contacts tab. With no recipients recorded, Form P2 section 2 checks the \"no one is entitled to notice\" box only on this explicit confirmation, and Form P1 is never treated as inapplicable just because the list is empty.",
        })}
        {!formFocusedIntake && (form.notifyPGT === "yes" || (contacts && requiresPGT(form as any, contacts as any[]).required)) && (
          <div className="mt-2 p-3 rounded-lg border border-amber-200 dark:border-amber-800 bg-amber-50/50 dark:bg-amber-950/30 space-y-2">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-amber-600 dark:text-amber-400" />
              <span className="text-xs font-semibold text-amber-800 dark:text-amber-300">WESA s.124 grant conditions</span>
            </div>
            <p className="text-[10px] text-muted-foreground">No 21-day PGT comment period exists. The grant cannot issue until written PGT comments are provided to the court, unless the court authorizes earlier issuance on a separate application made with reasonable notice to the PGT.</p>
            <div className="flex items-center gap-3">
              <Checkbox
                id="pgtCommentsProvidedToCourt"
                checked={!!form.pgtCommentsProvidedToCourt}
                onCheckedChange={(v) => { markDirty(); setForm((prev: any) => ({ ...prev, pgtCommentsProvidedToCourt: v ? 1 : 0, pgtCommentsProvidedToCourtDate: v ? prev.pgtCommentsProvidedToCourtDate : "" })); }}
              />
              <Label htmlFor="pgtCommentsProvidedToCourt" className="text-xs font-medium cursor-pointer">
                Written PGT comments provided to the court
              </Label>
            </div>
            {!!form.pgtCommentsProvidedToCourt && (
              <div className="space-y-1 max-w-xs">
                <Label className="text-[10px] font-medium text-muted-foreground">Date provided to the court</Label>
                <Input type="date" value={form.pgtCommentsProvidedToCourtDate || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, pgtCommentsProvidedToCourtDate: e.target.value })); }} className="h-8 text-xs" />
              </div>
            )}
            <div className="pt-2 border-t space-y-2">
              <p className="text-[10px] font-medium">Court authorization to issue before comments (WESA s.124(1)(b))</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div className="space-y-1">
                  <Label className="text-[10px] text-muted-foreground">Order date</Label>
                  <Input type="date" value={form.pgtEarlyGrantOrderDate || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, pgtEarlyGrantOrderDate: e.target.value })); }} className="h-8 text-xs" />
                </div>
                <div className="space-y-1">
                  <Label className="text-[10px] text-muted-foreground">Sealed order</Label>
                  {form.pgtEarlyGrantOrderFilePath ? (
                    <div className="flex items-center gap-2 h-8">
                      <span className="text-[10px] text-green-700 dark:text-green-400">Attached</span>
                      <Button type="button" variant="ghost" size="sm" className="h-7 text-xs" onClick={() => void previewStoredFile(form.pgtEarlyGrantOrderFilePath)}>View</Button>
                      <Button type="button" variant="ghost" size="sm" className="h-7 text-xs" onClick={() => clearLegalEvidenceMutation.mutate({ estateId, kind: "pgt_early_grant" })}>Remove</Button>
                    </div>
                  ) : (
                    <Input type="file" accept="application/pdf,image/*" className="h-8 text-xs" onChange={(event) => void uploadLegalEvidence("pgt_early_grant", event.target.files?.[0])} />
                  )}
                </div>
              </div>
            </div>
            {!!form.grantIssuedDate && (
              <div className="pt-2 border-t space-y-1 max-w-xs">
                <Label className="text-[10px] font-medium text-muted-foreground">Date copy of representation grant provided to PGT</Label>
                <Input type="date" value={form.pgtGrantCopyDeliveredDate || ""} onChange={(e) => { markDirty(); setForm((prev: any) => ({ ...prev, pgtGrantCopyDeliveredDate: e.target.value })); }} className="h-8 text-xs" />
                <p className="text-[10px] text-muted-foreground">WESA s.124(2): provide the copy within 45 days after the grant issues.</p>
              </div>
            )}
          </div>
        )}
        {/* 2026-08-05 intake de-dup: the affidavitSworn/affidavitOf/affidavitDate
            manual-tracking block was removed — zero consumers; the app generates
            P9 itself and the deponent comes from the document rows + contacts. */}
        {/* P1 Not Required */}
        <div className="flex items-center gap-2 py-1">
          <Checkbox
            id="p1NotRequired"
            checked={!!form.p1NotRequired}
            onCheckedChange={(checked) => { markDirty(); setForm({ ...form, p1NotRequired: !!checked }); }}
          />
          <Label htmlFor="p1NotRequired" className="text-xs font-normal cursor-pointer">
            P1 Notice not required (no other persons entitled to notice under Rule 25-2(2))
          </Label>
        </div>
        {!formFocusedIntake && !form.p1NotRequired && (
          <div className="mt-3 p-3 rounded-lg border space-y-3">
            <div>
              <p className="text-xs font-medium">Court-ordered earlier application date</p>
              <p className="text-[10px] text-muted-foreground">Complete only if the court ordered an application date earlier than the ordinary Rule 25-2(2.1) date.</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {field("Order date", "p1EarlyApplicationOrderDate", "date")}
              {field("Permitted application date", "p1EarlyApplicationPermittedDate", "date")}
              <div className="space-y-1">
                <Label className="text-xs font-medium text-muted-foreground">Sealed order</Label>
                {form.p1EarlyApplicationOrderFilePath ? (
                  <div className="flex items-center gap-2 h-9">
                    <span className="text-[10px] text-green-700 dark:text-green-400">Attached</span>
                    <Button type="button" variant="ghost" size="sm" className="h-7 text-xs" onClick={() => void previewStoredFile(form.p1EarlyApplicationOrderFilePath)}>View</Button>
                    <Button type="button" variant="ghost" size="sm" className="h-7 text-xs" onClick={() => clearLegalEvidenceMutation.mutate({ estateId, kind: "p1_early_application" })}>Remove</Button>
                  </div>
                ) : (
                  <Input type="file" accept="application/pdf,image/*" className="h-9 text-xs" onChange={(event) => void uploadLegalEvidence("p1_early_application", event.target.files?.[0])} />
                )}
              </div>
            </div>
          </div>
        )}
      </SectionHeader>

      {/* ─── FILING & COURT ─── */}
      <SectionHeader title="Filing & Court">
        {field("Court File Number", "courtFileNumber", "text", "e.g. VAN-S-S-123456", formatCourtFileNumber, "Assigned by the registry after filing. Leave blank until you receive it.")}
        {selectField("Court Registry", "registry", [
          { value: "Vancouver", label: "Vancouver" },
          { value: "Victoria", label: "Victoria" },
          { value: "New Westminster", label: "New Westminster" },
          { value: "Kelowna", label: "Kelowna" },
          { value: "Kamloops", label: "Kamloops" },
          { value: "Prince George", label: "Prince George" },
          { value: "Nanaimo", label: "Nanaimo" },
          { value: "Cranbrook", label: "Cranbrook" },
          { value: "Nelson", label: "Nelson" },
          { value: "Chilliwack", label: "Chilliwack" },
          { value: "Vernon", label: "Vernon" },
          { value: "Penticton", label: "Penticton" },
          { value: "Rossland", label: "Rossland" },
          { value: "Smithers", label: "Smithers" },
          { value: "Dawson Creek", label: "Dawson Creek" },
          { value: "Fort St. John", label: "Fort St. John" },
          { value: "Prince Rupert", label: "Prince Rupert" },
          { value: "Terrace", label: "Terrace" },
          { value: "Williams Lake", label: "Williams Lake" },
          { value: "Quesnel", label: "Quesnel" },
          { value: "Duncan", label: "Duncan" },
          { value: "Courtenay", label: "Courtenay" },
          { value: "Campbell River", label: "Campbell River" },
          { value: "Port Alberni", label: "Port Alberni" },
          { value: "Powell River", label: "Powell River" },
          { value: "Surrey", label: "Surrey" },
        ])}
        {field("Grant Issued Date", "grantIssuedDate", "date")}
        {/* GAP-006: "Use firm's address as address of service?" tri-toggle removed —
            nothing ever read useFirmAsServiceAddress, and the standing lawyer-signing
            ruling (RULES.md / Nick's production rulings) makes the service address
            ALWAYS the firm when the lawyer acts, so honoring a "No" is impermissible.
            The schema column remains (B-07 precedent above). */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {field("P2 Filed Date", "p2FiledDate", "date")}
          {field("P10 Filed Date", "p10FiledDate", "date")}
          {field("P11 Filed Date", "p11FiledDate", "date")}
        </div>
        {normalizeGrantType(form.grantType || "") === "resealing" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* P15PLUS-002 (Nick ruling 2026-07-26): the recorded Form P25 filing
                unlocks P26 — its ¶2 swears the P25 "has been filed" (Rule 25-6(7)). */}
            {field("P25 Filed Date (assets & liabilities for resealing)", "p25FiledDate", "date", "Recording this date makes Form P26 available — P26 swears the P25 has been filed")}
          </div>
        )}
        <div className="space-y-1.5">
          <Label className="text-xs font-medium text-muted-foreground">Certified copies requested</Label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label className="text-[10px] text-muted-foreground">Estate grant</Label>
              <input
                type="number"
                min={0}
                max={20}
                value={form.certifiedCopies ?? 3}
                onChange={(e) => { markDirty(); setForm({ ...form, certifiedCopies: parseInt(e.target.value) || 0 }); }}
                className="h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm shadow-xs"
              />
            </div>
            {/* Authorization-copies input REMOVED (Nick 2026-08-18 P2-audit ruling):
                the product always files P10/P11, so an authorization can never issue
                and the request line contradicted P2's checked election. The estates
                column remains (no migration); nothing reads it. */}
            <div className="space-y-1">
              <Label className="text-[10px] text-muted-foreground">Affidavit of assets & liabilities (domiciled)</Label>
              <input
                type="number"
                min={0}
                max={20}
                value={form.certifiedCopiesP10 ?? 0}
                onChange={(e) => { markDirty(); setForm({ ...form, certifiedCopiesP10: parseInt(e.target.value) || 0 }); }}
                className="h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm shadow-xs"
              />
            </div>
            <div className="space-y-1">
              <Label className="text-[10px] text-muted-foreground">Affidavit of assets & liabilities (non-domiciled)</Label>
              <input
                type="number"
                min={0}
                max={20}
                value={form.certifiedCopiesP11 ?? 0}
                onChange={(e) => { markDirty(); setForm({ ...form, certifiedCopiesP11: parseInt(e.target.value) || 0 }); }}
                className="h-9 w-24 rounded-md border border-input bg-background px-3 py-1 text-sm shadow-xs"
              />
            </div>
          </div>
          <p className="text-[10px] text-muted-foreground italic">Leave 0 for any type you do not need. Certified copies are official court-stamped duplicates used for banks, land titles, and other institutions.</p>
        </div>
        {/* Status & Assignee are case-management metadata, not document fields. */}
        <AnimatePresence initial={false}>
          {!formFocusedIntake && (
            <motion.div
              layout="position"
              initial={prefersReducedMotion ? false : { opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={prefersReducedMotion ? undefined : { opacity: 0, y: -6 }}
              transition={formModeTransition}
              className={`grid grid-cols-1 gap-4 md:grid-cols-2${showFormModeReveal ? " form-focused-field-reveal" : ""}`}
              data-testid="intake-case-management-file-fields"
              data-form-mode-reveal={showFormModeReveal || undefined}
            >
              {selectField("File Status", "status", [
                { value: "incomplete", label: "Incomplete" },
                { value: "ready_to_file", label: "Ready to File" },
                { value: "filed", label: "Filed" },
                { value: "granted", label: "Granted" },
                { value: "complete", label: "Complete" },
              ])}
              {field("Assignee", "assignee")}
            </motion.div>
          )}
        </AnimatePresence>
      </SectionHeader>

      <AnimatePresence initial={false}>
        {!formFocusedIntake && !!form.grantIssuedDate && (
          <motion.div
            layout="position"
            initial={prefersReducedMotion ? false : { opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={prefersReducedMotion ? undefined : { opacity: 0, y: -8 }}
            transition={formModeTransition}
            className={showFormModeReveal ? "form-focused-field-reveal" : undefined}
            data-testid="intake-post-grant-tracking"
            data-form-mode-reveal={showFormModeReveal || undefined}
          >
            <SectionHeader title="Post-grant statutory periods">
              <p className="text-[10px] text-muted-foreground">These are legal-event records used by the deadline engine. Record only events and evidence that actually occurred; the app does not infer a proceeding, consent or court order.</p>

          {!!form.hasWill && (
            <div className="space-y-3 rounded-lg border p-3">
              <div>
                <p className="text-xs font-semibold">Wills-variation proceeding — WESA s.61</p>
                <p className="text-[10px] text-muted-foreground">A proceeding must be commenced within 180 days from the grant date. If commenced, the initiating pleading must be served on the executor no later than 30 days after that period, unless the court extends service time.</p>
              </div>
              {selectField("Proceeding status", "variationProceedingStatus", [
                { value: "unknown", label: "Not yet reviewed" },
                { value: "none", label: "No proceeding recorded" },
                { value: "commenced", label: "Proceeding commenced" },
              ])}
              {form.variationProceedingStatus === "commenced" && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {field("Initiating pleading issued / proceeding commenced (also starts optional CPL window)", "variationProceedingCommencedDate", "date")}
                  {field("Initiating pleading served on executor", "variationExecutorServedDate", "date")}
                  {field("Court-extended service deadline (if ordered)", "variationServiceExtensionDate", "date")}
                  {field("Initiating pleading served on PGT (if required)", "variationPgtServedDate", "date")}
                  {(form.treatyFirstNation === "yes" || form.treatyFirstNation === "nisga") && field("Initiating pleading served on treaty First Nation / Nisg̱a'a Lisims Government", "variationTreatyNationServedDate", "date")}
                  {field("Certificate of pending litigation registered (if used)", "variationCplRegisteredDate", "date")}
                </div>
              )}
            </div>
          )}

          <div className="space-y-3 rounded-lg border p-3">
            <div>
              <p className="text-xs font-semibold">Estate distribution — WESA s.155</p>
              <p className="text-[10px] text-muted-foreground">The estate ordinarily must not be distributed within the 210 days following the grant date. Record an early-distribution basis only when the required order, consents, or protective set-asides actually exist.</p>
            </div>
            {selectField("Early-distribution basis", "distributionExceptionType", [
              { value: "none", label: "None recorded — ordinary 210-day prohibition applies" },
              { value: "court_order", label: "Court order — WESA s.155(1)" },
              { value: "all_required_consents", label: form.hasWill ? "All beneficiaries and all potential wills-variation claimants consent — s.155(1.1)" : "All intestate successors entitled to a share consent — s.155(1.2)" },
              { value: "protected_set_aside", label: "All required gifts, shares and potential claim amount set aside — s.155(1.3)" },
            ])}
            {form.distributionExceptionType && form.distributionExceptionType !== "none" && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {field("Date the early-distribution basis was completed", "distributionExceptionDate", "date")}
                <div className="space-y-1">
                  <Label className="text-xs font-medium text-muted-foreground">Supporting order / consents / set-aside record</Label>
                  {form.distributionExceptionFilePath ? (
                    <div className="flex items-center gap-2 h-9">
                      <span className="text-[10px] text-green-700 dark:text-green-400">Evidence attached</span>
                      <Button type="button" variant="ghost" size="sm" className="h-7 text-xs" onClick={() => void previewStoredFile(form.distributionExceptionFilePath)}>View</Button>
                      <Button type="button" variant="ghost" size="sm" className="h-7 text-xs" onClick={() => clearLegalEvidenceMutation.mutate({ estateId, kind: "distribution_exception" })}>Remove</Button>
                    </div>
                  ) : (
                    <Input type="file" accept="application/pdf,image/*" className="h-9 text-xs" onChange={(event) => void uploadLegalEvidence("distribution_exception", event.target.files?.[0])} />
                  )}
                </div>
              </div>
            )}
            {selectField("Proceeding affecting distribution after the 210-day period", "distributionProceedingStatus", [
              { value: "unknown", label: "Not yet reviewed" },
              { value: "none", label: "No proceeding recorded" },
              { value: "commenced", label: "A proceeding affecting distribution has commenced" },
            ])}
            {form.distributionProceedingStatus === "commenced" && (
              <div className="max-w-md">
                {field("Date of court consent to distribute (if obtained)", "distributionCourtConsentDate", "date")}
                <p className="text-[10px] text-muted-foreground">WESA s.155(2) prohibits distribution after the 210-day period without court consent while a listed proceeding is active.</p>
              </div>
            )}
          </div>
        </SectionHeader>
        </motion.div>
      )}
      </AnimatePresence>

      {/* Sticky save bar: stays visible while scrolling the Intake tab. Must remain
          inside IntakeTab — the unmount autosave and saveStatus state live here. */}
      <div className="sticky bottom-0 z-20 flex flex-col gap-2 border-t bg-background/95 py-3 backdrop-blur-sm sm:flex-row sm:items-center sm:gap-3">
        <div className="flex min-w-0 flex-wrap items-center gap-3">
          <Button onClick={save} disabled={updateMutation.isPending}>
            {updateMutation.isPending ? "Saving..." : "Save Changes"}
          </Button>
          <AnimatePresence mode="wait">
            {saveStatus === 'saving' && (
              <motion.span key="saving" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-1 text-xs text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-amber-500 animate-pulse" /> Saving…
              </motion.span>
            )}
            {saveStatus === 'saved' && (
              <motion.span key="saved" initial={{ opacity: 0, x: -4 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }} className="flex items-center gap-1 text-xs text-green-700 dark:text-green-400">
                <CheckCircle2 className="h-3.5 w-3.5" /> Saved
              </motion.span>
            )}
            {saveStatus === 'unsaved' && (
              <motion.span key="unsaved" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-1 text-xs text-muted-foreground/70">
                <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground/40" /> Unsaved changes
              </motion.span>
            )}
          </AnimatePresence>
        </div>
        <span data-testid="intake-autosave-status" className="min-w-0 text-xs text-muted-foreground sm:ml-auto" role="status" aria-live="polite">
          {lastSavedAt ? (
            <time dateTime={new Date(lastSavedAt).toISOString()}>
              Last auto-saved locally at {new Date(lastSavedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit", second: "2-digit" })}
            </time>
          ) : "Automatic recovery is ready"}
        </span>
      </div>
    </motion.div>
  );
}

const ALLOWED_DOC_TYPES = [
  "application/pdf",
  "image/png", "image/jpeg", "image/jpg", "image/tiff",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
];

function useFileUpload<TUploadResult>(
  onUpload: (base64: string, fileName: string, mimeType: string) => Promise<TUploadResult>,
  onRemove?: (fileName: string, uploadResult: TUploadResult | undefined) => Promise<void>,
) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const latestUploadResultRef = useRef<TUploadResult | undefined>(undefined);
  const [uploading, setUploading] = useState(false);
  const [feedback, setFeedback] = useState<UploadFeedbackState>(IDLE_UPLOAD_FEEDBACK);
  const processFile = async (file: File) => {
    if (!ALLOWED_DOC_TYPES.includes(file.type)) {
      const message = invalidFileTypeMessage(file.name, "a PDF, DOC/DOCX, PNG, JPG, or TIFF file");
      setFeedback({ phase: "error", progress: 0, message });
      toast.error(message);
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      const message = fileTooLargeMessage("20 MB");
      setFeedback({ phase: "error", progress: 0, message });
      toast.error(message);
      return;
    }
    setUploading(true);
    setFeedback({ phase: "reading", progress: 24, message: `Preparing ${file.name}` });
    try {
      const arrayBuf = await file.arrayBuffer();
      const bytes = new Uint8Array(arrayBuf);
      let binary = "";
      for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
      const base64 = btoa(binary);
      setFeedback({ phase: "uploading", progress: 72, message: `Securely uploading ${file.name}` });
      const uploadResult = await onUpload(base64, file.name, file.type);
      latestUploadResultRef.current = uploadResult;
      const localPreviewUrl = file.type.startsWith("image/") ? URL.createObjectURL(file) : undefined;
      setFeedback({
        phase: "complete",
        progress: 100,
        message: `${file.name} uploaded`,
        fileName: file.name,
        mimeType: file.type,
        localPreviewUrl,
      });
    } catch (error) {
      const message = error instanceof Error && error.message ? error.message : `Unable to upload ${file.name}. Please try again.`;
      setFeedback({ phase: "error", progress: 0, message });
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (file) void processFile(file);
  };
  const handleRemovePreview = async () => {
    const { fileName, localPreviewUrl } = feedback;
    if (!fileName) return;
    setUploading(true);
    setFeedback({ phase: "uploading", progress: 64, message: `Removing ${fileName}` });
    try {
      await onRemove?.(fileName, latestUploadResultRef.current);
      if (localPreviewUrl) URL.revokeObjectURL(localPreviewUrl);
      latestUploadResultRef.current = undefined;
      setFeedback(IDLE_UPLOAD_FEEDBACK);
    } catch (error) {
      const message = error instanceof Error && error.message ? error.message : `Unable to remove ${fileName}. Please try again.`;
      setFeedback({ phase: "error", progress: 0, message });
    } finally {
      setUploading(false);
    }
  };
  return { fileInputRef, uploading, feedback, handleFileSelect, handleFileDrop: processFile, handleRemovePreview };
}


// ─── CODICILS SECTION WITH DND ─────────────────────────────────────────
type CodicilBatchItem = {
  id: string;
  file: File;
  feedback: UploadFeedbackState;
  serverIndex?: number;
  extractionStatus?: "processing" | "ready" | "unavailable" | "error";
};

function CodicilsSection({ estateId, expectedRevision, codicils, deleteCodicilMutation, handlePreviewFile }: {
  estateId: string;
  expectedRevision: number;
  codicils: { storageKey: string; fileName: string; mimeType: string; executionDate?: string; aiExtraction?: { details: CodicilFacts; extractedAt: number; model: string } }[];
  deleteCodicilMutation: any;
  handlePreviewFile: (key: string) => void;
}) {
  const utils = trpc.useUtils();
  const codicilInputRef = useRef<HTMLInputElement>(null);
  const [batchItems, setBatchItems] = useState<CodicilBatchItem[]>([]);
  const [batchUploading, setBatchUploading] = useState(false);
  const [clearAllOpen, setClearAllOpen] = useState(false);
  const [clearingAll, setClearingAll] = useState(false);
  const [reorderNotice, setReorderNotice] = useState("");
  const [highlightedCodicilKey, setHighlightedCodicilKey] = useState<string | null>(null);
  const batchRevisionRef = useRef(expectedRevision);
  const batchNextIndexRef = useRef(codicils.length);
  const reorderMessageRef = useRef("");
  const reorderTargetKeyRef = useRef("");
  const reorderHighlightTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const showReorderHighlight = useCallback((storageKey: string) => {
    if (reorderHighlightTimerRef.current) clearTimeout(reorderHighlightTimerRef.current);
    setHighlightedCodicilKey(storageKey);
    reorderHighlightTimerRef.current = setTimeout(() => {
      setHighlightedCodicilKey((current) => current === storageKey ? null : current);
      reorderHighlightTimerRef.current = null;
    }, 1500);
  }, []);
  useEffect(() => () => {
    if (reorderHighlightTimerRef.current) clearTimeout(reorderHighlightTimerRef.current);
  }, []);
  const settingsQuery = (trpc as any).settings?.get?.useQuery?.() as { data?: { showChatbot?: boolean; aiProcessorApprovedAt?: number } } | undefined;
  const settings = settingsQuery?.data;
  const aiProcessingApproved = Boolean(settings?.showChatbot !== false && settings?.aiProcessorApprovedAt && settings.aiProcessorApprovedAt > 0);
  const invalidateWillDerivedState = () => {
    void utils.estate.get.invalidate({ id: estateId });
    void utils.readiness.check.invalidate({ estateId });
    void utils.readiness.timeline.invalidate({ estateId });
    void utils.deadline.list.invalidate();
    void utils.document.preflight.invalidate();
    void utils.document.preflightMany.invalidate();
  };
  const reorderMutation = trpc.estate.reorderCodicils.useMutation({
    onSuccess: () => {
      invalidateWillDerivedState();
      const message = reorderMessageRef.current || "Codicil order saved.";
      setReorderNotice(message);
      toast.success(message);
      if (reorderTargetKeyRef.current) showReorderHighlight(reorderTargetKeyRef.current);
      reorderMessageRef.current = "";
      reorderTargetKeyRef.current = "";
    },
    onError: (err) => {
      invalidateWillDerivedState();
      reorderMessageRef.current = "";
      reorderTargetKeyRef.current = "";
      setReorderNotice("Codicil order could not be saved. The latest document order has been restored.");
      toast.error(err.message || "Reorder failed");
    },
  });
  const updateDateMutation = trpc.estate.updateCodicilDate.useMutation({
    onSuccess: invalidateWillDerivedState,
    onError: (err) => { invalidateWillDerivedState(); toast.error(err.message || "Date update failed"); },
  });
  const batchUploadMutation = trpc.estate.uploadCodicil.useMutation({
    onSuccess: invalidateWillDerivedState,
    onError: (err) => toast.error(err.message || "Codicil upload failed"),
  });
  const extractionProcedure = (trpc as any).estate?.extractCodicilDetails;
  const extractCodicilMutation = extractionProcedure?.useMutation?.() ?? {
    isPending: false,
    mutateAsync: async () => { throw new Error("AI document facts are unavailable. Refresh and try again."); },
  };

  const [dragIdx, setDragIdx] = useState<number | null>(null);
  const [overIdx, setOverIdx] = useState<number | null>(null);

  const canReorder = codicils.length > 1 && !reorderMutation.isPending && !batchUploading && !clearingAll;

  const requestReorder = (fromIndex: number, toIndex: number) => {
    const newOrder = moveCodicilOrder(codicils.length, fromIndex, toIndex);
    if (!newOrder || !canReorder) return;
    const fileName = codicils[fromIndex]?.fileName || "Codicil";
    reorderMessageRef.current = `${fileName} moved to position ${toIndex + 1}.`;
    reorderTargetKeyRef.current = codicils[fromIndex]?.storageKey || "";
    setReorderNotice("Saving codicil order…");
    reorderMutation.mutate({ estateId, expectedRevision, newOrder });
  };

  const handleDragStart = (event: React.DragEvent, idx: number) => {
    if (!canReorder) return;
    event.dataTransfer.effectAllowed = "move";
    event.dataTransfer.setData("text/plain", codicils[idx]?.storageKey || String(idx));
    setDragIdx(idx);
  };

  const handleDragOver = (e: React.DragEvent, idx: number) => {
    e.preventDefault();
    setOverIdx(idx);
  };

  const handleDrop = (e: React.DragEvent, dropIdx: number) => {
    e.preventDefault();
    if (dragIdx === null || dragIdx === dropIdx) {
      setDragIdx(null);
      setOverIdx(null);
      return;
    }
    requestReorder(dragIdx, dropIdx);
    setDragIdx(null);
    setOverIdx(null);
  };

  const handleDragEnd = () => {
    setDragIdx(null);
    setOverIdx(null);
  };

  const updateBatchItem = (id: string, update: Partial<CodicilBatchItem>) => {
    setBatchItems((items) => items.map((item) => item.id === id ? { ...item, ...update } : item));
  };

  const supportsFactExtraction = (mimeType: string) => mimeType === "application/pdf" || mimeType.startsWith("image/");

  const extractCodicilFacts = async (index: number, revision: number, batchItemId?: string) => {
    if (!aiProcessingApproved) {
      if (batchItemId) updateBatchItem(batchItemId, { extractionStatus: "unavailable" });
      return { revision };
    }
    if (batchItemId) updateBatchItem(batchItemId, { extractionStatus: "processing" });
    try {
      const result = await extractCodicilMutation.mutateAsync({ estateId, expectedRevision: revision, index });
      if (batchItemId) updateBatchItem(batchItemId, { extractionStatus: "ready" });
      void invalidateWillDerivedState();
      return { revision: result.revision };
    } catch (error) {
      if (batchItemId) {
        updateBatchItem(batchItemId, { extractionStatus: "error" });
      } else {
        toast.error(error instanceof Error && error.message ? error.message : "AI document facts could not be extracted. Review the original document.");
      }
      return { revision };
    }
  };

  const processCodicilBatch = async (files: File[]) => {
    const newItems = files.map((file, index): CodicilBatchItem => ({
      id: `${file.name}-${file.size}-${file.lastModified}-${index}-${crypto.randomUUID()}`,
      file,
      feedback: { phase: "reading", progress: 4, message: `Queued: ${file.name}`, fileName: file.name, mimeType: file.type },
    }));
    setBatchItems((items) => [...items, ...newItems]);
    setBatchUploading(true);
    let revision = Math.max(batchRevisionRef.current, expectedRevision);
    let serverIndex = Math.max(batchNextIndexRef.current, codicils.length);

    for (const item of newItems) {
      const { file } = item;
      if (!ALLOWED_DOC_TYPES.includes(file.type)) {
        const message = invalidFileTypeMessage(file.name, "a PDF, DOC/DOCX, PNG, JPG, or TIFF file");
        updateBatchItem(item.id, { feedback: { phase: "error", progress: 0, message, fileName: file.name, mimeType: file.type } });
        continue;
      }
      if (file.size > 20 * 1024 * 1024) {
        const message = fileTooLargeMessage("20 MB");
        updateBatchItem(item.id, { feedback: { phase: "error", progress: 0, message, fileName: file.name, mimeType: file.type } });
        continue;
      }

      try {
        updateBatchItem(item.id, { feedback: { phase: "reading", progress: 24, message: `Preparing ${file.name}`, fileName: file.name, mimeType: file.type } });
        const bytes = new Uint8Array(await file.arrayBuffer());
        let binary = "";
        for (let index = 0; index < bytes.length; index += 1) binary += String.fromCharCode(bytes[index]);
        updateBatchItem(item.id, { feedback: { phase: "uploading", progress: 72, message: `Securely uploading ${file.name}`, fileName: file.name, mimeType: file.type } });
        const result = await batchUploadMutation.mutateAsync({
          estateId,
          expectedRevision: revision,
          fileBase64: btoa(binary),
          fileName: file.name,
          mimeType: file.type,
        });
        revision = result.revision;
        const localPreviewUrl = file.type.startsWith("image/") ? URL.createObjectURL(file) : undefined;
        const addedIndex = serverIndex;
        updateBatchItem(item.id, {
          serverIndex: addedIndex,
          extractionStatus: supportsFactExtraction(file.type) ? (aiProcessingApproved ? "processing" : "unavailable") : "unavailable",
          feedback: { phase: "complete", progress: 100, message: `${file.name} uploaded`, fileName: file.name, mimeType: file.type, localPreviewUrl },
        });
        serverIndex += 1;
        if (supportsFactExtraction(file.type) && aiProcessingApproved) {
          const extracted = await extractCodicilFacts(addedIndex, revision, item.id);
          revision = extracted.revision;
        }
      } catch (error) {
        const message = error instanceof Error && error.message ? error.message : `Unable to upload ${file.name}. Please try again.`;
        updateBatchItem(item.id, { feedback: { phase: "error", progress: 0, message, fileName: file.name, mimeType: file.type } });
      }
    }

    batchRevisionRef.current = revision;
    batchNextIndexRef.current = serverIndex;
    setBatchUploading(false);
    void invalidateWillDerivedState();
  };

  const removeBatchItem = async (item: CodicilBatchItem) => {
    if (item.feedback.phase !== "complete" || item.serverIndex === undefined) {
      if (item.feedback.localPreviewUrl) URL.revokeObjectURL(item.feedback.localPreviewUrl);
      setBatchItems((items) => items.filter((candidate) => candidate.id !== item.id));
      return;
    }
    const removedIndex = item.serverIndex;
    updateBatchItem(item.id, { feedback: { phase: "uploading", progress: 64, message: `Removing ${item.file.name}` } });
    try {
      const result = await deleteCodicilMutation.mutateAsync({ estateId, expectedRevision: batchRevisionRef.current, index: removedIndex });
      batchRevisionRef.current = result.revision;
      batchNextIndexRef.current = Math.max(0, batchNextIndexRef.current - 1);
      if (item.feedback.localPreviewUrl) URL.revokeObjectURL(item.feedback.localPreviewUrl);
      setBatchItems((items) => items
        .filter((candidate) => candidate.id !== item.id)
        .map((candidate) => candidate.serverIndex !== undefined && candidate.serverIndex > removedIndex
          ? { ...candidate, serverIndex: candidate.serverIndex - 1 }
          : candidate));
      void invalidateWillDerivedState();
    } catch (error) {
      const message = error instanceof Error && error.message ? error.message : `Unable to remove ${item.file.name}. Please try again.`;
      updateBatchItem(item.id, { feedback: { phase: "error", progress: 0, message, fileName: item.file.name, mimeType: item.file.type, localPreviewUrl: item.feedback.localPreviewUrl } });
    }
  };

  const handleCodicilSelection = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    event.target.value = "";
    if (files.length > 0) void processCodicilBatch(files);
  };

  const clearAllCodicils = async () => {
    const total = Math.max(codicils.length, batchNextIndexRef.current);
    if (total === 0) {
      setClearAllOpen(false);
      return;
    }
    setClearingAll(true);
    let revision = Math.max(batchRevisionRef.current, expectedRevision);
    let cleared = 0;
    try {
      for (const index of codicilClearIndices(total)) {
        const result = await deleteCodicilMutation.mutateAsync({ estateId, expectedRevision: revision, index });
        revision = result.revision;
        cleared += 1;
      }
      batchItems.forEach((item) => {
        if (item.feedback.localPreviewUrl) URL.revokeObjectURL(item.feedback.localPreviewUrl);
      });
      batchRevisionRef.current = revision;
      batchNextIndexRef.current = 0;
      setBatchItems([]);
      toast.success(`Removed all ${cleared} codicil${cleared === 1 ? "" : "s"}`);
      setClearAllOpen(false);
      void invalidateWillDerivedState();
    } catch (error) {
      const reason = error instanceof Error && error.message ? error.message : "Please refresh and try again.";
      batchItems.forEach((item) => {
        if (item.feedback.localPreviewUrl) URL.revokeObjectURL(item.feedback.localPreviewUrl);
      });
      setBatchItems([]);
      void invalidateWillDerivedState();
      toast.error(cleared > 0 ? `Removed ${cleared} codicil${cleared === 1 ? "" : "s"}; ${reason}` : `Could not clear codicils. ${reason}`);
    } finally {
      setClearingAll(false);
    }
  };

  const canClearAll = codicils.length > 0 || batchItems.some((item) => item.feedback.phase === "complete");

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <p className="text-xs font-medium">Codicils ({codicils.length})</p>
        <div className="flex items-center gap-2">
          {canClearAll && (
            <AlertDialog open={clearAllOpen} onOpenChange={setClearAllOpen}>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="sm" className="h-7 px-2 text-xs text-destructive hover:text-destructive" disabled={batchUploading || clearingAll} data-testid="codicil-clear-all">
                  <Trash2 className="mr-1 h-3 w-3" /> Clear all
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Clear all codicils?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will permanently remove every uploaded codicil from this estate. You can upload replacement documents afterward.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel disabled={clearingAll}>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={(event) => { event.preventDefault(); void clearAllCodicils(); }} disabled={clearingAll} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                    {clearingAll ? "Removing..." : "Clear all codicils"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
          <FileDropZone onFilesDrop={(files) => void processCodicilBatch(files)} disabled={batchUploading || clearingAll} label="Drop codicils to upload">
            <Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => codicilInputRef.current?.click()} disabled={batchUploading || clearingAll}>
              <Plus className="h-3 w-3 mr-1" /> {batchUploading ? "Uploading..." : "Add or drop codicils"}
            </Button>
          </FileDropZone>
        </div>
      </div>
      <p className="sr-only" aria-live="polite" aria-atomic="true" data-testid="codicil-reorder-status">{reorderNotice}</p>
      {batchItems.length > 0 && (
        <div className="mb-3 space-y-2 rounded-md border border-primary/10 bg-muted/[0.12] p-2" data-testid="codicil-upload-queue">
          <p className="px-0.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">Current upload batch</p>
          {batchItems.map((item) => (
            <div key={item.id} className="flex min-w-0 items-start gap-1">
              <div className="min-w-0 flex-1">
                <UploadFeedback state={item.feedback} onRemove={() => void removeBatchItem(item)} compact />
                {item.feedback.phase === "complete" && item.extractionStatus && (
                  <p className="mt-1 px-1 text-[10px] text-muted-foreground" data-testid="codicil-extraction-status">
                    {item.extractionStatus === "processing" && "Reading document facts with approved AI processing…"}
                    {item.extractionStatus === "ready" && "AI document facts saved below — review against the original."}
                    {item.extractionStatus === "unavailable" && (supportsFactExtraction(item.file.type) ? "Enable Assistant processing to extract document facts." : "AI facts are available for PDF and image codicils only.")}
                    {item.extractionStatus === "error" && "AI document facts could not be extracted. Review the original or retry below."}
                  </p>
                )}
              </div>
              {item.feedback.phase === "error" && (
                <Button variant="ghost" size="sm" className="h-7 px-1.5 text-[10px] text-muted-foreground" onClick={() => void removeBatchItem(item)}>Clear</Button>
              )}
            </div>
          ))}
        </div>
      )}
      {codicils.length > 0 ? (
        <div className="space-y-2" role="list" aria-label="Uploaded codicils">
          {codicils.map((cod, idx) => (
            <div
              key={`${cod.storageKey}-${idx}`}
              role="listitem"
              draggable={canReorder}
              aria-busy={reorderMutation.isPending}
              data-testid={`codicil-row-${idx}`}
              onDragStart={(event) => handleDragStart(event, idx)}
              onDragOver={(e) => handleDragOver(e, idx)}
              onDrop={(e) => handleDrop(e, idx)}
              onDragEnd={handleDragEnd}
              className={cn(`flex items-center gap-2 p-2 border rounded-md transition-all ${
                dragIdx === idx ? "opacity-50 border-primary" : ""
              } ${overIdx === idx && dragIdx !== idx ? "border-primary/50 bg-primary/5" : "bg-muted/20"}`, highlightedCodicilKey === cod.storageKey && "codicil-reorder-settled")}
            >
              <span className="shrink-0" aria-hidden="true"><GripVertical className="h-4 w-4 text-muted-foreground cursor-grab active:cursor-grabbing" /></span>
              <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium truncate">{cod.fileName}</p>
                <div className="flex items-center gap-1 mt-1">
                  <Input
                    type="date"
                    className="h-6 text-[10px] w-32 px-1"
                    value={cod.executionDate || ""}
                    placeholder="Execution date"
                    onChange={(e) => updateDateMutation.mutate({ estateId, expectedRevision, index: idx, executionDate: e.target.value })}
                  />
                  {cod.executionDate && <span className="text-[10px] text-muted-foreground">executed</span>}
                </div>
                {cod.aiExtraction?.details ? (
                  <CodicilFactsCard details={cod.aiExtraction.details} />
                ) : (
                  <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[10px]">
                    {supportsFactExtraction(cod.mimeType) && aiProcessingApproved ? (
                      <Button variant="ghost" size="sm" className="h-6 px-1.5 text-[10px] text-violet-700 hover:text-violet-800 dark:text-violet-300" onClick={() => void extractCodicilFacts(idx, expectedRevision)} disabled={extractCodicilMutation.isPending}>
                        <Sparkles className="mr-1 h-3 w-3" /> {extractCodicilMutation.isPending ? "Extracting…" : "Extract key facts"}
                      </Button>
                    ) : (
                      <span className="text-muted-foreground">{supportsFactExtraction(cod.mimeType) ? "Enable Assistant processing to extract document facts." : "AI facts are available for PDF and image codicils only."}</span>
                    )}
                  </div>
                )}
              </div>
              <CodicilReorderControls fileName={cod.fileName} index={idx} total={codicils.length} disabled={!canReorder} onMove={requestReorder} />
              <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => handlePreviewFile(cod.storageKey)} title="View">
                <Eye className="h-3.5 w-3.5" />
              </Button>
              <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => deleteCodicilMutation.mutate({ estateId, expectedRevision, index: idx })} disabled={deleteCodicilMutation.isPending}>
                <Trash2 className="h-3.5 w-3.5 text-destructive" />
              </Button>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-xs text-muted-foreground">No codicils uploaded yet.</p>
      )}
      {codicils.length > 1 && (
        <p className="text-[10px] text-muted-foreground mt-1">Drag a document to reorder it, or use Move up and Move down. Order determines sequence in the P2 ZIP.</p>
      )}
      <input
        ref={codicilInputRef}
        type="file"
        className="hidden"
        multiple
        accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.tiff,.tif"
        onChange={handleCodicilSelection}
      />
    </div>
  );
}

function WillUploadSection({ estateId, estate }: { estateId: string; estate: any }) {
  const utils = trpc.useUtils();
  const invalidateWillDerivedState = () => {
    void utils.estate.get.invalidate({ id: estateId });
    void utils.readiness.check.invalidate({ estateId });
    void utils.readiness.timeline.invalidate({ estateId });
    void utils.deadline.list.invalidate();
    void utils.document.preflight.invalidate();
    void utils.document.preflightMany.invalidate();
  };
  const uploadMutation = trpc.estate.uploadWill.useMutation({
    onSuccess: () => { invalidateWillDerivedState(); toast.success("Will uploaded successfully"); },
    onError: (err) => { toast.error(err.message || "Upload failed"); },
  });
  const deleteMutation = trpc.estate.deleteWill.useMutation({
    onSuccess: () => { invalidateWillDerivedState(); toast.success("Will removed"); },
    onError: (err) => { toast.error(err.message || "Delete failed"); },
  });
  const uploadForeignGrantMutation = trpc.estate.uploadForeignGrant.useMutation({
    onSuccess: () => { invalidateWillDerivedState(); toast.success("Foreign grant uploaded successfully"); },
    onError: (err) => { toast.error(err.message || "Upload failed"); },
  });
  const deleteForeignGrantMutation = trpc.estate.deleteForeignGrant.useMutation({
    onSuccess: () => { invalidateWillDerivedState(); toast.success("Foreign grant removed"); },
    onError: (err) => { toast.error(err.message || "Delete failed"); },
  });
  const deleteCodicilMutation = trpc.estate.deleteCodicil.useMutation({
    onSuccess: () => { invalidateWillDerivedState(); toast.success("Codicil removed"); },
    onError: (err) => { toast.error(err.message || "Delete failed"); },
  });

  const hasWill = !!estate.willStorageKey;
  const needsForeignGrant = requiresForeignGrantCopy(estate);
  const needsAncillaryFilingCopies = isAncillary(estate);
  const hasForeignGrant = !!estate.foreignGrantStorageKey;
  const codicils: { storageKey: string; fileName: string; mimeType: string }[] = (() => {
    try { return JSON.parse(estate.codicilFiles || "[]"); } catch { return []; }
  })();

  const willUpload = useFileUpload(
    async (base64, fileName, mimeType) => uploadMutation.mutateAsync({ estateId, fileBase64: base64, fileName, mimeType }),
    async () => { await deleteMutation.mutateAsync({ estateId }); },
  );
  const foreignGrantUpload = useFileUpload(
    async (base64, fileName, mimeType) => uploadForeignGrantMutation.mutateAsync({ estateId, fileBase64: base64, fileName, mimeType }),
    async () => { await deleteForeignGrantMutation.mutateAsync({ estateId }); },
  );

  // Shared with every other "View" affordance (sealed orders, citation
  // evidence, dispensation orders) via lib/utils so behavior stays uniform.
  const handlePreviewFile = (storageKey: string) => void previewStoredFile(storageKey);

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm">{needsAncillaryFilingCopies ? "Notice & Ancillary Filing Documents" : "P1 Notice Enclosures"}</CardTitle>
          {hasWill && !needsAncillaryFilingCopies && <Badge variant="secondary" className="text-[10px]">Delivered with P1</Badge>}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {needsForeignGrant && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs font-medium">Foreign grant</Label>
              {hasForeignGrant && <Badge variant="secondary" className="text-[10px]">
                {needsAncillaryFilingCopies && estate.foreignGrantCertifiedByIssuingCourt === "yes" ? "Certified filing copy" : "Notice copy"}
              </Badge>}
            </div>
            {hasForeignGrant ? (
              <div className="flex items-center gap-2 p-2.5 rounded-lg border bg-muted/20">
                <div className="h-9 w-9 rounded-md bg-primary/10 flex items-center justify-center shrink-0"><FileText className="h-4 w-4 text-primary" /></div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{estate.foreignGrantFileName}</p>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{estate.foreignGrantMimeType?.split("/").pop()}</p>
                </div>
                <div className="flex items-center shrink-0">
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => handlePreviewFile(estate.foreignGrantStorageKey)} title="View"><Eye className="h-3.5 w-3.5" /></Button>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => deleteForeignGrantMutation.mutate({ estateId })} disabled={deleteForeignGrantMutation.isPending}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
                </div>
              </div>
            ) : (
              <>
                <FileDropZone onFileDrop={(file) => void foreignGrantUpload.handleFileDrop(file)} disabled={foreignGrantUpload.uploading} label="Drop foreign grant to upload">
                  <button type="button" className="w-full group relative rounded-lg border border-dashed border-muted-foreground/25 hover:border-primary/50 p-5 text-center transition-all duration-200 hover:bg-muted/30 active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-70" onClick={() => foreignGrantUpload.fileInputRef.current?.click()} disabled={foreignGrantUpload.uploading}>
                    <div className="mx-auto h-10 w-10 rounded-full bg-muted flex items-center justify-center mb-2 group-hover:bg-primary/10 transition-colors"><Upload className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" /></div>
                    <p className="text-sm font-medium text-foreground">{foreignGrantUpload.uploading ? "Uploading..." : "Drop or upload foreign grant"}</p>
                    <p className="text-[11px] text-muted-foreground mt-0.5">{needsAncillaryFilingCopies ? "Drag a document here or browse; required for the ancillary filing." : "Drag a document here or browse; required with P1 for resealing."}</p>
                  </button>
                </FileDropZone>
              </>
            )}
            <UploadFeedback state={foreignGrantUpload.feedback} onRemove={() => void foreignGrantUpload.handleRemovePreview()} compact className="mt-2" />
            <input ref={foreignGrantUpload.fileInputRef} type="file" className="hidden" accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.tiff,.tif" onChange={foreignGrantUpload.handleFileSelect} />
          </div>
        )}
        {/* Will section */}
        {!!estate.hasWill && <div>
          {hasWill ? (
            <div className="flex items-center gap-2 p-2.5 rounded-lg border bg-muted/20">
              <div className="h-9 w-9 rounded-md bg-primary/10 flex items-center justify-center shrink-0">
                <FileText className="h-4 w-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{estate.willFileName}</p>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{estate.willMimeType?.split('/').pop()}</p>
              </div>
              <div className="flex items-center shrink-0">
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => handlePreviewFile(estate.willStorageKey)} title="View">
                  <Eye className="h-3.5 w-3.5" />
                </Button>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => deleteMutation.mutate({ estateId })} disabled={deleteMutation.isPending}>
                  <Trash2 className="h-3.5 w-3.5 text-destructive" />
                </Button>
              </div>
            </div>
          ) : (
            <>
              <FileDropZone onFileDrop={(file) => void willUpload.handleFileDrop(file)} disabled={willUpload.uploading} label="Drop will document to upload">
                <button
                    type="button"
                    className="w-full group relative rounded-lg border border-dashed border-muted-foreground/25 hover:border-primary/50 p-5 text-center transition-all duration-200 hover:bg-muted/30 active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-70"
                    onClick={() => willUpload.fileInputRef.current?.click()}
                    disabled={willUpload.uploading}
                >
                  <div className="mx-auto h-10 w-10 rounded-full bg-muted flex items-center justify-center mb-2 group-hover:bg-primary/10 transition-colors">
                    <Upload className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                  <p className="text-sm font-medium text-foreground">
                    {willUpload.uploading ? "Uploading..." : "Drop or upload will document"}
                  </p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">Drag a PDF, DOC, DOCX, or image here — or browse · max 20 MB</p>
                </button>
              </FileDropZone>
            </>
          )}
          <UploadFeedback state={willUpload.feedback} onRemove={() => void willUpload.handleRemovePreview()} compact className="mt-2" />
          <input
            ref={willUpload.fileInputRef}
            type="file"
            className="hidden"
            accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.tiff,.tif"
            onChange={willUpload.handleFileSelect}
          />
        </div>}

        {/* Codicils section with drag-and-drop */}
        {!!estate.hasWill && <CodicilsSection
          estateId={estateId}
          expectedRevision={estate.revision}
          codicils={codicils}
          deleteCodicilMutation={deleteCodicilMutation}
          handlePreviewFile={handlePreviewFile}
        />}
      </CardContent>
    </Card>
  );
}

// ─── CONTACT FORM (extracted to prevent re-mount on state change) ────
const CONTACT_ROLES = [
  { value: "client_reported_person", label: "Client-reported person (unclassified)" },
  { value: "beneficiary", label: "Beneficiary" },
  { value: "executor", label: "Executor" },
  { value: "alternate_executor", label: "Alternate Executor" },
  { value: "administrator", label: "Administrator" },
  { value: "trustee", label: "Trustee" },
  { value: "applicant", label: "Applicant" },
  { value: "lawyer", label: "Lawyer" },
  { value: "creditor", label: "Creditor" },
  { value: "spouse", label: "Spouse" },
  { value: "guardian", label: "Guardian" },
  { value: "will_witness", label: "Will Witness" },
];

function ContactFieldLabel({
  children,
  guidance,
  label,
  testId,
}: {
  children: React.ReactNode;
  guidance?: React.ReactNode;
  label: string;
  testId?: string;
}) {
  return (
    <div className="contact-field-label flex min-h-5 items-center gap-1">
      <Label className="text-xs font-medium leading-tight">{children}</Label>
      {guidance && (
        <IntakeGuidanceTooltip
          label={label}
          testId={testId}
          markerClassName="contact-info-tooltip-marker"
        >
          {guidance}
        </IntakeGuidanceTooltip>
      )}
    </div>
  );
}

export const contactAddDraftKey = (estateId: string) => `contact_add_${estateId}`;
export const contactEditDraftKey = (estateId: string, contactId: string) => `contact_edit_${estateId}_${contactId}`;

export function ContactFormFields({ contact, setContact, allContacts, formFocusedIntake = false }: { contact: any; setContact: (c: any) => void; allContacts?: any[]; formFocusedIntake?: boolean }) {
  const roles: string[] = contactRoles(contact);
  const [rolesOpen, setRolesOpen] = useState(false);
  const pickerRelationship = normalizeContactRelationshipForPicker(
    contact.relationship || ""
  );

  const setPgtPrintedField = (field: string, value: unknown, extra: Record<string, unknown> = {}) => {
    setContact({ ...contact, [field]: value, ...extra, pgtInfoReviewed: 0 });
  };

  const toggleRole = (role: string) => {
    const current = new Set(roles);
    if (current.has(role)) current.delete(role);
    else current.add(role);
    // A role is an editable fact. Never silently recreate Beneficiary after the
    // user removes it; notice categorization remains independently editable.
    setContact({ ...contact, role: Array.from(current).join(",") });
  };

  return (
    <div className="contact-form-fields space-y-5 pt-1" data-testid="contact-form-fields" data-form-mode={formFocusedIntake ? "form-focused" : "full"}>
      <div className="space-y-1">
        <ContactFieldLabel label="contact roles">Roles</ContactFieldLabel>
        <Popover open={rolesOpen} onOpenChange={setRolesOpen}>
          <PopoverTrigger asChild>
            <button type="button" className="contact-role-trigger flex min-h-11 w-full items-center justify-between rounded-xl border border-input bg-background px-3 py-2.5 text-sm shadow-xs ring-offset-background transition-[background-color,border-color,box-shadow,transform] duration-150 ease-out hover:border-primary/30 hover:bg-accent/40 hover:shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/35 focus-visible:ring-offset-2 active:scale-[0.995]">
              <div className="flex flex-wrap gap-1">
                {roles.length === 0 ? (
                  <span className="text-muted-foreground">Select roles...</span>
                ) : (
                  roles.map((r) => (
                    <Badge key={r} variant="secondary" className="text-[10px] px-1.5 py-0 h-5">
                      {roleLabel(r, contact.relationship)}
                      <X className="h-2.5 w-2.5 ml-0.5 cursor-pointer" onClick={(e) => { e.stopPropagation(); toggleRole(r); }} />
                    </Badge>
                  ))
                )}
              </div>
              <ChevronDown className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
            </button>
          </PopoverTrigger>
          <PopoverContent className="contact-role-menu w-[min(19rem,calc(100vw-2rem))] rounded-xl border-border/80 p-1.5 shadow-[0_16px_36px_-18px_rgba(15,23,42,0.38)]" align="start" sideOffset={8}>
            {CONTACT_ROLES.map((r) => (
              <button
                key={r.value}
                type="button"
                role="menuitemcheckbox"
                aria-checked={roles.includes(r.value)}
                className="flex min-h-9 w-full items-center gap-2 rounded-lg px-2.5 py-2 text-sm transition-[background-color,color,transform] duration-150 ease-out hover:bg-accent focus-visible:bg-accent focus-visible:outline-none active:scale-[0.99]"
                onClick={() => toggleRole(r.value)}
              >
                {/* visual-only check square: a nested Radix Checkbox renders a
                    second <button>, which is invalid HTML and eats row clicks */}
                <span
                  aria-hidden
                  className={`h-3.5 w-3.5 shrink-0 rounded-[4px] border border-primary flex items-center justify-center ${roles.includes(r.value) ? "bg-primary text-primary-foreground" : "bg-background"}`}
                >
                  {roles.includes(r.value) && <Check className="h-3 w-3" />}
                </span>
                <span>{r.label}</span>
              </button>
            ))}
          </PopoverContent>
        </Popover>
      </div>
      <div className="space-y-1.5"><ContactFieldLabel label="contact name">{roles.includes("lawyer") ? "Lawyer Name" : "Name"}</ContactFieldLabel><Input value={contact.name} onChange={(e) => setPgtPrintedField("name", e.target.value)} /></div>
      {/* Hidden only for a PLAIN lawyer contact — a solicitor-executor (lawyer +
          executor/applicant roles) is named in the will and keeps the field. */}
      {(!roles.includes("lawyer") || roles.includes("executor") || roles.includes("alternate_executor") || roles.includes("applicant")) && (
        <div className="space-y-1.5">
          <ContactFieldLabel label="name as shown in will">Name as Shown in Will (if different from current name)</ContactFieldLabel>
          <Input value={contact.nameAsInWill || ""} onChange={(e) => setContact({ ...contact, nameAsInWill: e.target.value })} placeholder="Leave blank if same as current name" className="h-9 text-xs" />
        </div>
      )}
      {roles.includes("lawyer") && (
        <div className="space-y-1.5"><ContactFieldLabel label="law firm name">Firm Name</ContactFieldLabel><Input value={contact.firmName || ""} onChange={(e) => setContact({ ...contact, firmName: e.target.value })} placeholder="e.g. Smith & Associates LLP" /></div>
      )}
      {/* Rule 25-2(13) contact address quartet */}
      <section className="contact-form-section space-y-4 rounded-xl border border-border/70 p-4" aria-labelledby="contact-information-heading">
        <p id="contact-information-heading" className="contact-section-eyebrow">Rule 25-2(13) Contact Information</p>
        <div className="space-y-1"><Label className="text-xs">Residential Address</Label><Textarea value={(contact as any).residentialAddress || contact.address || ""} onChange={(e) => {
          const newAddr = e.target.value;
          const isSame = (contact as any).postalSameAsResidential;
          setPgtPrintedField("residentialAddress", newAddr, { address: newAddr, ...(isSame ? { postalAddress: newAddr } : {}) });
        }} placeholder="Residential address (inside or outside BC)" rows={2} className="text-xs" /></div>
        <div className="space-y-1 flex items-start gap-2">
          <div className="flex-1 space-y-1">
            <Label className="text-xs">Postal Address</Label>
            <Textarea value={(contact as any).postalSameAsResidential ? ((contact as any).residentialAddress || contact.address || "") : ((contact as any).postalAddress || "")} onChange={(e) => setPgtPrintedField("postalAddress", e.target.value, { postalSameAsResidential: false })} placeholder="Postal address (if different from residential)" rows={2} className="text-xs" disabled={(contact as any).postalSameAsResidential} />
          </div>
          <label className="flex items-center gap-1.5 pt-5 text-[10px] text-muted-foreground cursor-pointer whitespace-nowrap">
            <Checkbox checked={!!(contact as any).postalSameAsResidential} onCheckedChange={(checked) => { setPgtPrintedField("postalAddress", checked ? ((contact as any).residentialAddress || contact.address || "") : ((contact as any).postalAddress || ""), { postalSameAsResidential: !!checked }); }} />
            Same as residential
          </label>
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <div className="space-y-1"><Label className="text-xs">Email Address</Label><Input type="email" value={contact.email || ""} onChange={(e) => setPgtPrintedField("email", e.target.value)} placeholder="name@example.com" className="h-9 text-xs" /></div>
          <div className="space-y-1"><Label className="text-xs">Phone</Label><Input type="tel" value={contact.phone || ""} onChange={(e) => setContact({ ...contact, phone: formatPhone(e.target.value) })} placeholder="604-555-1234" className="h-9 text-xs" /></div>
          <div className="space-y-1"><Label className="text-xs">Fax Number</Label><Input type="tel" value={(contact as any).faxNumber || ""} onChange={(e) => setPgtPrintedField("faxNumber", formatPhone(e.target.value))} placeholder="604-555-1234" className="h-9 text-xs" /></div>
        </div>
        {contact.recipientType !== "pgt" && (
          <label className="contact-review-row flex items-start gap-2.5 rounded-xl border border-border/65 bg-background p-3 cursor-pointer">
            <Checkbox
              checked={Number(contact.pgtInfoReviewed) === 1}
              onCheckedChange={(checked) => setContact({ ...contact, pgtInfoReviewed: checked ? 1 : 0 })}
              className="mt-0.5"
            />
            <span className="space-y-0.5">
              <span className="flex items-center gap-1 text-xs font-medium">PGT supplemental information reviewed
                <IntakeGuidanceTooltip label="PGT supplemental information" testId="contact-pgt-information-guidance" markerClassName="contact-info-tooltip-marker">
                  Confirm that the name, residential address, postal address, email, and fax above are complete or intentionally recorded as unknown for the Rule 25-2(13) notice. Editing any printed field clears this confirmation.
                </IntakeGuidanceTooltip>
              </span>
            </span>
          </label>
        )}
      </section>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="space-y-1"><Label className="text-xs">City / Country</Label><Input value={contact.cityCountry || ""} onChange={(e) => setContact({ ...contact, cityCountry: e.target.value })} placeholder="e.g. Vancouver, BC, Canada" /></div>
        <div className="space-y-1">
          <Label className="text-xs">Relationship to Deceased</Label>
          <Select value={pickerRelationship} onValueChange={(v) => setContact({ ...contact, relationship: v })}>
            <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Select relationship" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="spouse">Spouse</SelectItem>
              <SelectItem value="common-law partner">Common-Law Partner</SelectItem>
              <SelectItem value="child">Child (Son/Daughter)</SelectItem>
              <SelectItem value="son">Son</SelectItem>
              <SelectItem value="daughter">Daughter</SelectItem>
              <SelectItem value="grandchild">Grandchild</SelectItem>
              <SelectItem value="grandson">Grandson</SelectItem>
              <SelectItem value="granddaughter">Granddaughter</SelectItem>
              {/* WESA s.23(4)(a): a descendant inherits "even though they are of
                  a greater degree of relationship than the limit imposed by"
                  s.23(3), and s.24(2) recurses without limit. With no label for
                  them, a great-grandchild could only be recorded by mislabelling
                  the kinship — recorded honestly they took nothing, silently. */}
              <SelectItem value="great-grandchild">Great-Grandchild</SelectItem>
              <SelectItem value="parent">Parent (Mother/Father)</SelectItem>
              <SelectItem value="mother">Mother</SelectItem>
              <SelectItem value="father">Father</SelectItem>
              <SelectItem value="sibling">Sibling (Brother/Sister)</SelectItem>
              <SelectItem value="brother">Brother</SelectItem>
              <SelectItem value="sister">Sister</SelectItem>
              {/* s.23(5)(b): "relatives of the half kinship inherit equally with
                  those of the whole kinship in the same degree". The engine's
                  s.23(2)(c) sibling filter has always accepted these labels and
                  the parent-link picker offers them as a niece's parent — but
                  this Select could not produce them, so a half-sibling (and any
                  half-niece below them) could not be recorded at all. */}
              <SelectItem value="half-brother">Half-Brother</SelectItem>
              <SelectItem value="half-sister">Half-Sister</SelectItem>
              <SelectItem value="niece">Niece</SelectItem>
              <SelectItem value="nephew">Nephew</SelectItem>
              {/* s.23(2)(c) reaches these by representation through a
                  predeceased niece/nephew (s.24(2)). They are 4th degree under
                  s.23(5)(a) — up 1 to the parent, down 3 — so s.23(3)'s "5th or
                  greater" cutoff does not reach them. Nothing DEEPER is offered:
                  a great-great-niece is 5th degree and the Act deems her
                  predeceased. */}
              <SelectItem value="great-niece">Great-Niece</SelectItem>
              <SelectItem value="great-nephew">Great-Nephew</SelectItem>
              <SelectItem value="grandparent">Grandparent</SelectItem>
              <SelectItem value="maternal_grandmother">Maternal Grandmother</SelectItem>
              <SelectItem value="maternal_grandfather">Maternal Grandfather</SelectItem>
              <SelectItem value="paternal_grandmother">Paternal Grandmother</SelectItem>
              <SelectItem value="paternal_grandfather">Paternal Grandfather</SelectItem>
              <SelectItem value="aunt">Aunt</SelectItem>
              <SelectItem value="uncle">Uncle</SelectItem>
              {/* s.23(5)(b): "relatives of the half kinship inherit equally
                  with those of the whole kinship in the same degree." A
                  half-aunt is 3rd degree and takes at s.23(2)(d) exactly as a
                  full aunt does, but could not be recorded at all — the same
                  gap 58aff85 closed for half-siblings. */}
              <SelectItem value="half-aunt">Half-Aunt</SelectItem>
              <SelectItem value="half-uncle">Half-Uncle</SelectItem>
              <SelectItem value="great-grandparent">Great-Grandparent</SelectItem>
              <SelectItem value="great-aunt">Great-Aunt</SelectItem>
              <SelectItem value="great-uncle">Great-Uncle</SelectItem>
              {/* Both labels: the engine tier-(d) filter and the parent-link
                  picker accept "cousin" and "first_cousin", but only the
                  former could be recorded from this form. */}
              <SelectItem value="cousin">Cousin</SelectItem>
              <SelectItem value="first_cousin">First Cousin</SelectItem>
              {/* Both of these are 5th degree under s.23(5)(a), so s.23(3)
                  conclusively deems them predeceased and they take nothing.
                  They are offered anyway because the engine already matches
                  them and the P5 lists them as intestate successors for NOTICE
                  under Rule 25-2 — a person who must be served but cannot
                  inherit still has to be recordable, and recording them is what
                  produces the s.23(3) explanation instead of a silent escheat. */}
              <SelectItem value="first_cousin_once_removed">First Cousin Once Removed</SelectItem>
              <SelectItem value="second_cousin">Second Cousin</SelectItem>
              <SelectItem value="friend">Friend (no blood relation)</SelectItem>
              <SelectItem value="business_partner">Business Partner</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {/* Only the relatives whose side the engine actually divides by. The
            old gate was a bare substring match on /grand|aunt|uncle|cousin/,
            so it also offered a Family Side on a grandCHILD and a
            great-grandCHILD — lineal DESCENDANTS, placed at s.23(2)(a), where
            no side is ever read. Asking for a fact that changes nothing trains
            the user to ignore the control on the files where it decides the
            division. Matches the engine's own tier populations, including the
            half- and grand- spellings it now accepts. */}
        {readsFamilySide(contact as any) && (
          <div className="space-y-1.5">
            <ContactFieldLabel
              label="family side"
              testId="contact-family-side-guidance"
              guidance="WESA s.23(2)(d)(ii) and (e)(ii) divide the estate by the number of the deceased's parents whose line has a taker. This decides both the divisor and who is paid from which part; without it, the P10 distribution renders blank."
            >
              Family Side (maternal / paternal line)
            </ContactFieldLabel>
            {/* sideOf() — the same source the engine divides by, so the control
                can never disagree with the distribution. A contact recorded as
                "Paternal Grandfather" shows Paternal here even with the column
                null; the engine reads the label identically. */}
            <Select value={sideOf(contact as any) ?? ""} onValueChange={(v) => setContact({ ...contact, side: v })}>
              <SelectTrigger className="h-9 text-xs"><SelectValue placeholder="Select side" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="maternal">Maternal</SelectItem>
                <SelectItem value="paternal">Paternal</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}
        {/* Every marriage-like label, not just the exact "common-law partner"
            string: MARRIAGE_LIKE_RELATIONSHIPS also holds "partner",
            "marriage-like partner", "marriage-like", "de facto spouse" and the
            unhyphenated "common law partner". All of them route through the
            s.2(1)(b) duration test, so gating the only control that answers it
            on one spelling left the others permanently undetermined with no way
            to resolve them (reachable via imported and legacy contacts). */}
        {isMarriageLikeRelationship(contact.relationship) && (
          <div className="space-y-1.5">
            <ContactFieldLabel
              label="relationship duration"
              testId="contact-relationship-duration-guidance"
              guidance={'At least 2 years (24 months) makes a marriage-like partner a "spouse" under WESA s.2(1)(b). Leave blank only if unknown — the amounts on Form P10 stay blank until it is recorded. A recorded duration under 24 months means they are not a spouse.'}
            >
              Relationship Duration (months) <span className="font-normal text-muted-foreground">(WESA s.2(1)(b))</span>
            </ContactFieldLabel>
            <Input
              type="number"
              // min={1}, not 24: a genuine 12-month relationship is a recordable
              // fact that DISQUALIFIES the partner, and the form must let the
              // user state it rather than only accept the qualifying answer.
              // Not 0 either — 0 is the "unrecorded" sentinel, so typing it
              // clears the field and yields "undetermined". 1 is the smallest
              // value the control can honestly accept.
              min={1}
              value={(contact as any).relationshipDurationMonths || ""}
              onChange={(e) => setContact({ ...contact, relationshipDurationMonths: e.target.value ? Number(e.target.value) : 0 } as any)}
              placeholder="e.g. 36 (3 years)"
              className="h-9 text-xs"
            />
            {/* Was: "A blank, zero, or shorter duration does not qualify." That
                is no longer true of a blank — and it was the same conflation
                that let the engine treat the unrecorded default as a recorded
                "no". A blank leaves spousal status UNDETERMINED (Form P10 shows
                blanks); only a recorded duration under 24 months disqualifies. */}
            {/* WESA s.2(2)(b) — PER-PARTNER termination (migration 0108). The
                estate-level separation flag governs the whole file and carries
                the s.2(2.1) reconciliation exception; this says that THIS
                partner's relationship ended, which matters when a file records
                more than one partner. Unticked means no termination on record,
                which is the Act's own default: s.2(1) makes two people spouses
                "unless subsection (2) applies". */}
            <label className="flex items-start gap-2 text-xs cursor-pointer pt-1">
              <Checkbox
                checked={(contact as any).relationshipTerminated === 1}
                onCheckedChange={(checked) => setContact({ ...contact, relationshipTerminated: checked ? 1 : 0 } as any)}
              />
              <span className="inline-flex items-center gap-1 leading-tight">
                Relationship terminated before death
                <IntakeGuidanceTooltip label="relationship termination" testId="contact-relationship-termination-guidance" markerClassName="contact-info-tooltip-marker">
                  WESA s.2(2)(b) — they cease to be a "spouse" and take no spousal share. Use the estate's Separation fields instead if the whole file is affected.
                </IntakeGuidanceTooltip>
              </span>
            </label>
          </div>
        )}
      </div>

      {/* Predeceased flag — keep the live relationship value (e.g. "spouse") and
          set this flag; a "deceased spouse" relationship string would silently
          break computeIntestacyShares' exact-match filters. */}
      {!roles.includes("lawyer") && (
        <div className="space-y-1.5">
          <label className="flex items-center gap-1.5 text-xs cursor-pointer">
            <Checkbox checked={!!(contact as any).isPredeceased} onCheckedChange={(v) => setContact({ ...contact, isPredeceased: v ? 1 : 0 })} className="h-3.5 w-3.5" data-testid="contact-predeceased" />
            Predeceased (died before the deceased)
            <IntakeGuidanceTooltip label="predeceased status" testId="contact-predeceased-guidance" markerClassName="contact-info-tooltip-marker">
              Deceased family members, including a predeceased spouse or sibling, are excluded from notice and letter recipient lists and drive per-stirpes representation in intestacy.
            </IntakeGuidanceTooltip>
          </label>
        </div>
      )}

      <div className="space-y-1"><Label className="text-xs">Occupation</Label><Input value={contact.occupation || ""} onChange={(e) => setContact({ ...contact, occupation: e.target.value })} placeholder="e.g. Retired, Accountant, Homemaker" className="h-9 text-xs" /></div>

      <div className="space-y-1"><Label className="text-xs">Address for Service (if different)</Label><AddressAutocomplete value={contact.addressForService || ""} onChange={(val) => setContact({ ...contact, addressForService: val })} onSelect={(components) => { setContact((prev: any) => ({ ...prev, addressForService: [components.street, components.unit, components.city, components.province, components.postalCode].filter(Boolean).join(", ") })); }} placeholder="Leave blank to use main address" /></div>
      {(roles.includes("executor") || roles.includes("alternate_executor") || roles.includes("applicant")) && (
        <>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label className="text-xs">Applicant Kind</Label>
            <Select value={contact.applicantKind || "individual"} onValueChange={(v) => setContact({ ...contact, applicantKind: v })}>
              <SelectTrigger className="h-9 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="individual">Individual</SelectItem>
                <SelectItem value="organization">Organization (not an individual)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1"><Label className="text-xs">Fax for Service</Label><Input value={contact.serviceFax || ""} onChange={(e) => setContact({ ...contact, serviceFax: formatPhone(e.target.value) })} placeholder="604-555-0100" className="h-9 text-xs" /></div>
        </div>
        {contact.applicantKind === "organization" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1"><Label className="text-xs">Signatory Name (individual who swears for the organization)</Label><Input value={(contact as any).orgSignatoryName || ""} onChange={(e) => setContact({ ...contact, orgSignatoryName: e.target.value })} placeholder="e.g. Jane Officer" className="h-9 text-xs" /></div>
            <div className="space-y-1"><Label className="text-xs">Signatory's Organizational Title</Label><Input value={(contact as any).orgSignatoryTitle || ""} onChange={(e) => setContact({ ...contact, orgSignatoryTitle: e.target.value })} placeholder="e.g. Trust Officer" className="h-9 text-xs" /></div>
          </div>
        )}
        </>
      )}

      {/* Legislation-driven fields */}
      {(roles.includes("executor") || roles.includes("alternate_executor") || roles.includes("applicant")) && (
        <div className="space-y-3 border-t border-border/50 pt-3 mt-3">
          <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider">Executor Status</p>
          <Select value={contact.executorStatus || ""} onValueChange={(v) => setContact({ ...contact, executorStatus: v })}>
            <SelectTrigger className="h-8 text-xs" data-testid="executor-status-select"><SelectValue placeholder="Select status..." /></SelectTrigger>
            <SelectContent>
              <SelectItem value="applying">Applying (active)</SelectItem>
              <SelectItem value="reserved">Right reserved — not joining this application</SelectItem>
              <SelectItem value="renounced">Renounced</SelectItem>
              <SelectItem value="deemed_renounced">Deemed Renounced (citation)</SelectItem>
              <SelectItem value="deceased">Deceased</SelectItem>
              <SelectItem value="unable">Unable to Act</SelectItem>
            </SelectContent>
          </Select>
          {(contact.executorStatus === "renounced" || contact.executorStatus === "deemed_renounced" || contact.executorStatus === "unable" || contact.executorStatus === "reserved") && (
            <div className="space-y-1"><Label className="text-xs">Reason / Notes</Label><Input value={contact.renunciationReason || ""} onChange={(e) => setContact({ ...contact, renunciationReason: e.target.value })} placeholder="e.g. Conflict of interest" className="h-8 text-xs" /></div>
          )}
          {/* P15PLUS-007 (Nick ruling 2026-07-26): the will may appoint this executor
              trustee too — gates P17's optional "and trustee" face text. Unanswered
              omits the text (never defaulted). */}
          <div className="space-y-1.5">
            <Label className="text-xs">Did the will also appoint this person trustee? (P17 prints "executor and trustee")</Label>
            <TriToggle value={(contact as any).appointedTrustee || ""} onChange={(v) => setContact({ ...contact, appointedTrustee: v } as any)} options={["yes", "no"]} labels={["Yes", "No"]} />
          </div>
          {/* Applicant residence for P3/P4 affidavit */}
          <div className="space-y-3 border-t border-border/50 pt-3 mt-2">
            <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider">Applicant Residence (for sworn affidavit)</p>
            <div className={`flex items-center gap-2 p-2 rounded-md border transition-colors duration-200 ${(contact as any).addressFormatOverride ? "border-amber-300 bg-amber-50 dark:border-amber-700 dark:bg-amber-950/30" : "border-border/50 bg-muted/30"}`}>
              <Switch
                id={`contactAddrOverride-${contact.id}`}
                checked={!!((contact as any).addressFormatOverride)}
                onCheckedChange={(checked) => setContact({ ...contact, addressFormatOverride: checked ? 1 : 0 } as any)}
              />
              <Label htmlFor={`contactAddrOverride-${contact.id}`} className="text-xs font-medium cursor-pointer select-none">Manual formatting override</Label>
              <AnimatePresence>
                {!!((contact as any).addressFormatOverride) && (
                  <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}>
                    <Badge variant="outline" className="text-[10px] h-5 border-amber-400 text-amber-700 dark:text-amber-400 bg-amber-100/50 dark:bg-amber-900/30 font-medium">ACTIVE</Badge>
                  </motion.div>
                )}
              </AnimatePresence>
              <Tooltip>
                <TooltipTrigger asChild><Info className="h-3.5 w-3.5 text-muted-foreground" /></TooltipTrigger>
                <TooltipContent side="right" className="max-w-[260px] text-xs space-y-1.5 p-3">
                  <p className="font-medium">Manual Formatting Override</p>
                  <p>When enabled, this contact's address fields will appear <strong>exactly as typed</strong> in generated documents — no automatic formatting.</p>
                  <p className="text-muted-foreground">Use for foreign addresses, non-standard formatting, or special characters (e.g. “São Paulo”, “Queensland”).</p>
                </TooltipContent>
              </Tooltip>
              <AnimatePresence>
                {!!((contact as any).addressFormatOverride) && (
                  <motion.div initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 8 }} transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }} className="ml-auto">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 px-2 text-[10px] text-amber-700 dark:text-amber-400 hover:text-amber-900 hover:bg-amber-100 dark:hover:bg-amber-900/40"
                      onClick={() => {
                        setContact({
                          ...contact,
                          addressFormatOverride: 0,
                          residenceStreet: titleCaseAddr((contact as any).residenceStreet || ""),
                          residenceCity: titleCaseAddr(contact.residenceCity || ""),
                          residenceProvince: upperProvinceAddr(contact.residenceProvince || ""),
                          residencePostalCode: upperPostalCodeAddr((contact as any).residencePostalCode || ""),
                          residenceCountry: titleCaseAddr(contact.residenceCountry || ""),
                        } as any);
                        toast.info("Automatic formatting restored");
                      }}
                    >
                      <X className="h-3 w-3 mr-0.5" /> Revert to auto
                    </Button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            <div className="space-y-2">
              <div className="space-y-1"><Label className="text-xs">Street Address</Label><Input value={(contact as any).residenceStreet || ""} onChange={(e) => setContact({ ...contact, residenceStreet: e.target.value })} placeholder="e.g. 123 Main Street" className="h-8 text-xs" /></div>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                <div className="space-y-1"><Label className="text-xs">City/Town</Label><Input value={contact.residenceCity || ""} onChange={(e) => setContact({ ...contact, residenceCity: e.target.value })} placeholder="e.g. Vancouver" className="h-8 text-xs" /></div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Province/State <span className="text-destructive">*</span></Label>
                  <Select value={contact.residenceProvince || ""} onValueChange={(v) => setContact({ ...contact, residenceProvince: v })}>
                    <SelectTrigger className="h-8 text-xs" aria-invalid={!contact.residenceProvince && contact.residenceCity ? true : undefined}><SelectValue placeholder="Select..." /></SelectTrigger>
                    <SelectContent>
                      {["AB","BC","MB","NB","NL","NS","NT","NU","ON","PE","QC","SK","YT"].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  {!contact.residenceProvince && contact.residenceCity && (
                    <p className="text-[10px] text-destructive flex items-center gap-1" role="alert">
                      <CircleAlert className="h-2.5 w-2.5 shrink-0" /> Required
                    </p>
                  )}
                  {contact.residenceProvince && (
                    <p className="text-[10px] text-green-700 dark:text-green-400 flex items-center gap-1">
                      <CircleCheck className="h-2.5 w-2.5 shrink-0" /> {contact.residenceProvince}
                    </p>
                  )}
                </div>
                <div className="space-y-1"><Label className="text-xs">Postal Code</Label><Input value={(contact as any).residencePostalCode || ""} onChange={(e) => setContact({ ...contact, residencePostalCode: e.target.value } as any)} placeholder="e.g. V8V 1A1" className="h-8 text-xs" /></div>
                <div className="space-y-1"><Label className="text-xs">Country</Label><Input value={contact.residenceCountry || ""} onChange={(e) => setContact({ ...contact, residenceCountry: e.target.value })} placeholder="e.g. Canada" className="h-8 text-xs" /></div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2">
            <div className="space-y-1">
              <Label className="text-xs">Executor Rank</Label>
              <Select value={contact.executorRank || ""} onValueChange={(v) => setContact({ ...contact, executorRank: v, executorRankNumber: v === "primary" ? 1 : v === "alternate" ? 2 : v === "substituted" ? 3 : 0 })}>
                <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Select rank" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="primary">Primary executor</SelectItem>
                  <SelectItem value="alternate">Alternate executor</SelectItem>
                  <SelectItem value="substituted">Substituted / further alternate</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Priority # (1 = highest)</Label>
              <Input type="number" min={1} value={contact.executorRankNumber ?? 0} onChange={(e) => setContact({ ...contact, executorRankNumber: Number(e.target.value) || 0 })} className="h-8 text-xs" />
            </div>
          </div>
        </div>
      )}

      {/* WESA s.22 — spousalShareBps for multi-spouse estates.
          Same engine predicate as the Distribution card: a qualifying
          common-law partner is a spouse under s.2(1)(b), and hiding this input
          from them made a multi-spouse file permanently unreconcilable. */}
      {isSpouseCandidate(contact as any) && (
        <div className="space-y-1 border-t border-amber-200 dark:border-amber-800 pt-3 mt-3">
          <ContactFieldLabel
            label="agreed spousal share"
            testId="contact-spousal-share-guidance"
            guidance="Only relevant when multiple spouses exist. 10000 = 100%. Every spouse's portion must be recorded and total 10000 — unrecorded portions render as blanks on Form P10, never as an equal split."
          >
            <span className="text-amber-700 dark:text-amber-300">Agreed Spousal Share (WESA s.22, basis points 0–10000 = 0–100%)</span>
          </ContactFieldLabel>
          <Input
            type="number"
            min={0}
            max={10000}
            value={(contact as any).spousalShareBps ?? ""}
            onChange={(e) => setContact({ ...contact, spousalShareBps: e.target.value ? Number(e.target.value) : null } as any)}
            placeholder="Agreed portion in basis points (e.g. 7000 = 70%)"
            className="h-8 text-xs"
          />
          {/* WESA s.22(1) supplies no equal default; the guidance is kept with the label. */}
        </div>
      )}

      {/* Rule 25-2 (8)/(10) reach every notice recipient, not only beneficiaries —
          an executor with prior right, a creditor, a citor or a court-ordered
          recipient can be a minor or under committeeship, and Form P9 section 3
          then swears their representative. */}
      {recipientMayNeedRepresentativeDelivery(contact) && (
        <div className="space-y-3 border-t border-border/50 pt-3 mt-3">
          <p className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider">PGT-Relevant Status</p>
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-1.5 text-xs cursor-pointer">
              <Checkbox checked={!!contact.isMinor} onCheckedChange={(v) => setContact({ ...contact, isMinor: v ? 1 : 0 })} className="h-3.5 w-3.5" />
              Minor (under 19)
            </label>
            <label className="flex items-center gap-1.5 text-xs cursor-pointer">
              <Checkbox checked={!!contact.isMentallyIncapable} onCheckedChange={(v) => setContact({ ...contact, isMentallyIncapable: v ? 1 : 0 })} className="h-3.5 w-3.5" />
              Mentally Incapable
            </label>
          </div>
        </div>
      )}

      {/* Minor delivery fields — Rule 25-2(8)(a) */}
      {!!contact.isMinor && (
        <div className="space-y-2 rounded-md border border-blue-200 dark:border-blue-800 p-2">
          <p className="text-[10px] font-medium text-blue-700 dark:text-blue-300">Rule 25-2(8)(a) — Minor Delivery Branch</p>
          <div className="space-y-1">
            <Label className="text-xs">Delivery Method</Label>
            <Select value={contact.minorDeliveryBranch || ""} onValueChange={(v) => setContact({ ...contact, minorDeliveryBranch: v })}>
              <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Select the recorded branch" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="resides_with_parents">(i) Minor resides with parent(s)</SelectItem>
                <SelectItem value="financial_guardian">(ii) Parent/guardian has financial decision responsibility</SelectItem>
                <SelectItem value="direct_to_minor">(iii) Deliver directly to minor at known address</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {["resides_with_parents", "financial_guardian"].includes(contact.minorDeliveryBranch || "") && (
            <div className="space-y-1">
              <Label className="text-xs">Parent/Guardian Name</Label>
              <Input value={contact.guardianName || ""} onChange={(e) => setContact({ ...contact, guardianName: e.target.value })} placeholder="Name of parent or guardian who received notice" className="h-8 text-xs" />
            </div>
          )}
        </div>
      )}

      {/* Committee fields for mentally incapable — Rule 25-2(11) */}
      {!!contact.isMentallyIncapable && (
        <div className="space-y-2 rounded-md border border-purple-200 dark:border-purple-800 p-2">
          <p className="text-[10px] font-medium text-purple-700 dark:text-purple-300">Rule 25-2(11) — Committee / Representative Details</p>
          <div className="space-y-1">
            <Label className="text-xs">Has Committee Appointed?</Label>
            <Select value={contact.hasCommittee ? "1" : "0"} onValueChange={(v) => setContact({ ...contact, hasCommittee: v === "1" ? 1 : 0 })}>
              <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="0">No committee appointed — Rule 25-2(11)(c)</SelectItem>
                <SelectItem value="1">Committee appointed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {!!contact.hasCommittee && (
            <>
              <div className="space-y-1">
                <Label className="text-xs">Committee Type</Label>
                <Select value={contact.committeeType || "bc_ppa"} onValueChange={(v) => setContact({ ...contact, committeeType: v })}>
                  <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bc_ppa">BC — Patients Property Act — Rule 25-2(11)(a)</SelectItem>
                    <SelectItem value="foreign_equivalent">Foreign equivalent — Rule 25-2(11)(b)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Committee Name</Label>
                <Input value={contact.committeeName || ""} onChange={(e) => setContact({ ...contact, committeeName: e.target.value })} placeholder="Full name of committee member" className="h-8 text-xs" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Committee Address</Label>
                <Input value={contact.committeeAddress || ""} onChange={(e) => setContact({ ...contact, committeeAddress: e.target.value })} placeholder="Address for delivery to committee" className="h-8 text-xs" />
              </div>
              {contact.committeeType === "foreign_equivalent" && !formFocusedIntake && (
                <div className="space-y-1" data-testid="contact-appointing-jurisdiction-field">
                  <Label className="text-xs">Appointing Jurisdiction</Label>
                  <Input value={contact.committeeJurisdiction || ""} onChange={(e) => setContact({ ...contact, committeeJurisdiction: e.target.value })} placeholder="e.g., Ontario, Alberta, Washington State" className="h-8 text-xs" />
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* Representation (WESA s.24): link a representative to their predeceased
          parent. s.24 governs EVERY tier the Act distributes to descendants — the
          children tier (s.23(2)(a): grandchild → child) AND the siblings tier
          (s.23(2)(c): niece/nephew → sibling). This control used to accept only
          grandchildren, so a niece could never be linked to her predeceased
          parent: the engine then saw no sibling root at all and an estate with
          living nieces escheated to the Crown (F1, 2026-07-27). */}
      {/* Any depth of descendant, plus the s.23(2)(c) representative line. The
          exact-label list left a great-grandchild with no way to record the link
          the engine requires, so the honest label was unplaceable and the only
          workable route was to misstate the kinship. */}
      {(/^(great[- ])*grand(child|son|daughter)$/.test((contact.relationship || "").toLowerCase().trim())
        || /^(great[- ])?(niece|nephew)$/.test((contact.relationship || "").toLowerCase().trim())
        || ["cousin", "first_cousin"].includes((contact.relationship || "").toLowerCase())) && allContacts && allContacts.length > 0 && (
        <div className="space-y-1.5">
          <ContactFieldLabel
            label="predeceased parent for representation"
            testId="contact-representation-guidance"
            guidance={(() => {
              const self = (contact.relationship || "").toLowerCase().trim();
              if (["niece", "nephew"].includes(self)) return "If this niece or nephew inherits by representation of a predeceased brother or sister of the deceased, select that sibling here. Without it they receive nothing.";
              if (/^(great|grand)[- ]?(niece|nephew)$/.test(self)) return "If this great-niece or great-nephew inherits by representation of a predeceased niece or nephew of the deceased, select that niece or nephew here. Without it they receive nothing.";
              if (["cousin", "first_cousin"].includes(self)) return "If this cousin inherits by representation of a predeceased aunt or uncle of the deceased, select that aunt or uncle here. Without it they receive nothing.";
              if (/^(great[- ])+grand(child|son|daughter)$/.test(self)) return "Select the predeceased parent one generation above this person — a great-grandchild represents a grandchild of the deceased. Without it they receive nothing.";
              return "If this grandchild inherits by representation of a predeceased child, select the predeceased parent here. Without it they receive nothing.";
            })()}
          >
            Predeceased Parent <span className="font-normal text-muted-foreground">(for representation under WESA s.24)</span>
          </ContactFieldLabel>
          <Select value={contact.parentContactId || "none"} onValueChange={(v) => setContact({ ...contact, parentContactId: v === "none" ? "" : v })}>
            <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Select parent (if taking by representation)" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">None (not taking by representation)</SelectItem>
              {allContacts.filter((c: any) => {
                if (c.id === contact.id) return false;
                // Normalized IDENTICALLY to the gate above (which trims). With
                // the gate trimming and these not, a trailing space opened the
                // selector but silently downgraded the offered parents to the
                // CHILD generation — recreating the two-generation mislabel this
                // change exists to eliminate.
                const rel = (c.relationship || "").toLowerCase().trim();
                const self = (contact.relationship || "").toLowerCase().trim();
                // Each representative's parent sits one tier up: a grandchild
                // represents a CHILD (s.23(2)(a)), a niece/nephew a SIBLING
                // (s.23(2)(c)), a first cousin an AUNT/UNCLE (s.23(2)(d)).
                if (["niece", "nephew"].includes(self)) {
                  return ["sibling", "brother", "sister", "half-brother", "half-sister"].includes(rel);
                }
                // A great-niece/nephew represents a NIECE/NEPHEW (s.24(2) runs
                // the same division one generation further down), not a sibling.
                if (["great-niece", "great-nephew", "great niece", "great nephew"].includes(self)) {
                  return ["niece", "nephew"].includes(rel);
                }
                if (["cousin", "first_cousin"].includes(self)) {
                  return ["aunt", "uncle"].includes(rel);
                }
                // A descendant's parent is one generation up its own line: a
                // great-grandchild represents a GRANDCHILD, a
                // great-great-grandchild a great-grandchild, and so on. Offering
                // only children made a great-grandchild unlinkable.
                const greats = (self.match(/great[- ]/g) || []).length;
                if (/^(great[- ])*grand(child|son|daughter)$/.test(self)) {
                  if (greats === 0) return ["child", "son", "daughter"].includes(rel) || c.recipientType === "child";
                  const parentPattern = new RegExp(`^(great[- ]){${greats - 1}}grand(child|son|daughter)$`);
                  return parentPattern.test(rel);
                }
                return ["child", "son", "daughter"].includes(rel) || c.recipientType === "child";
              }).map((c: any) => (
                <SelectItem key={c.id} value={c.id}>{c.name}{c.isPredeceased === 1 ? " (predeceased)" : ""}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {/* WESA s.130 Priority Consent — per-contact tracking for P5 intestacy */}
      {(contact.recipientType === "intestate_successor" || contact.recipientType === "child" || contact.recipientType === "spouse") && !(roles.includes("executor") || roles.includes("applicant")) && (
        <div className="space-y-2 rounded-md border border-blue-200 dark:border-blue-800 p-2 mt-3">
          <p className="text-[10px] font-medium text-blue-700 dark:text-blue-300">WESA s.130 — Priority Consent (P5 Intestacy)</p>
          <div className="space-y-1">
            <Label className="text-xs">Consent Status</Label>
            <Select value={(contact as any).priorityConsent || "unknown"} onValueChange={(v) => setContact({ ...contact, priorityConsent: v } as any)}>
              <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="unknown">Not yet determined</SelectItem>
                <SelectItem value="consented">Consented in writing</SelectItem>
                <SelectItem value="renounced">Renounced right to apply</SelectItem>
                <SelectItem value="cannot_locate">Cannot be located</SelectItem>
                <SelectItem value="not_required">Not required (lower priority class)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {((contact as any).priorityConsent === "consented" || (contact as any).priorityConsent === "renounced") && (
            <div className="space-y-1.5">
              <ContactFieldLabel label="consent or renunciation document" testId="contact-consent-document-guidance" guidance={'Upload the consent or renunciation letter from the "Beneficiary Consent" panel. The P5 checklist and readiness checks use it; it does not print on Form P5.'}>Consent / Renunciation Document</ContactFieldLabel>
              {(contact as any).priorityConsentDocumentKey ? (
                <a
                  href={`/manus-storage/${(contact as any).priorityConsentDocumentKey}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400 hover:underline"
                >
                  <Paperclip className="h-3 w-3" />
                  <span className="truncate max-w-[180px]">View uploaded document</span>
                </a>
              ) : (
                <p className="text-[10px] text-muted-foreground">No document uploaded yet.</p>
              )}
            </div>
          )}
          {(contact as any).priorityConsent === "cannot_locate" && (
            <div className="space-y-1.5">
              <ContactFieldLabel label="priority consent inquiry details" testId="contact-inquiry-details-guidance" guidance="Record the particulars of reasonable inquiries made to locate this person. The P5 checklist and readiness checks use these details; they do not print on Form P5.">Inquiry Details</ContactFieldLabel>
              <Input value={(contact as any).priorityConsentInquiryDetails || ""} onChange={(e) => setContact({ ...contact, priorityConsentInquiryDetails: e.target.value } as any)} placeholder="e.g. Searched BC Vital Statistics, Canada Post forwarding..." className="h-8 text-xs" />
            </div>
          )}
        </div>
      )}

      {/* Notice recipient categorization per Rule 25-2 */}
      <div className="space-y-1.5">
        <ContactFieldLabel
          label="notice recipient category"
          testId="contact-notice-category-guidance"
          guidance={'Determines who receives P1 notice. Testate: beneficiaries and executors. Intestacy: add creditors over $10,000 and intestate successors. A person the court orders to receive notice under Rule 25-2(14)(a) must use the court-ordered category. Select "Not a P1 Notice Recipient" for lawyers or contacts not entitled to notice. Saving this contact does not record delivery. Record the actual method, delivery date, and any electronic acknowledgement in Forms → P9 delivery checklist (or the P1 Delivery Records panel).'}
        >
          Notice Recipient Category <span className="font-normal text-muted-foreground">(Rule 25-2(2))</span>
        </ContactFieldLabel>
        <Select value={contact.recipientType || "beneficiary"} onValueChange={(v) => {
          const updates: any = { ...contact, recipientType: v };
          // Legacy contact.deliveryMethod is only an eligibility sentinel.
          // Actual method/date evidence lives in canonical deliveries rows.
          if (v === "not_recipient") updates.deliveryMethod = "not_applicable";
          else if (contact.deliveryMethod === "not_applicable") updates.deliveryMethod = "mail";
          setContact(updates);
        }}>
          <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="beneficiary">Beneficiary / Heir</SelectItem>
            <SelectItem value="executor">Executor / Administrator</SelectItem>
            <SelectItem value="spouse">Spouse / Common-law Partner</SelectItem>
            <SelectItem value="child">Child of Deceased</SelectItem>
            <SelectItem value="intestate_successor">Intestate Successor (WESA Part 3)</SelectItem>
            <SelectItem value="creditor">Known Creditor (&gt;$10k, intestacy only)</SelectItem>
            <SelectItem value="citor">Citor (filed citation)</SelectItem>
            <SelectItem value="court_ordered">Court-ordered recipient (Rule 25-2(2)(e))</SelectItem>
            <SelectItem value="pgt">Public Guardian and Trustee</SelectItem>
            <SelectItem value="treaty_fn">Treaty First Nation</SelectItem>
            <SelectItem value="attorney_general">Attorney General (escheat/bona vacantia)</SelectItem>
            <SelectItem value="not_recipient">Not a P1 Notice Recipient</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {(contact.recipientType === "creditor" || contactHasRole(contact, "creditor")) && (
        <div className="space-y-1.5">
          <ContactFieldLabel label="creditor claim amount" testId="contact-creditor-claim-guidance" guidance="Rule 25-2(2)(b) requires P1 notice only for creditors with claims exceeding $10,000. Enter the total amount owed to this creditor at date of death.">Claim Amount ($)</ContactFieldLabel>
          <Input
            type="text"
            inputMode="decimal"
            placeholder="e.g. 15,000"
            value={(contact.claimAmountCents || 0) > 0 ? formatCurrency(((contact.claimAmountCents || 0) / 100).toFixed(2)) : ""}
            onChange={(e) => setContact({ ...contact, claimAmountCents: parseCurrencyToCents(e.target.value || "0") })}
          />
        </div>
      )}
    </div>
  );
}

// ─── CONTACTS TAB ────────────────────────────────────────────────────
function ContactTemplateBar({ estateId, contacts }: { estateId: string; contacts: any[] }) {
  const { data: templates } = trpc.contactTemplate.list.useQuery();
  const utils = trpc.useUtils();
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [templateName, setTemplateName] = useState("");

  const createMutation = trpc.contactTemplate.create.useMutation({
    onSuccess: () => { utils.contactTemplate.list.invalidate(); setSaveDialogOpen(false); setTemplateName(""); toast.success("Template saved"); },
  });
  const deleteMutation = trpc.contactTemplate.delete.useMutation({
    onSuccess: () => { utils.contactTemplate.list.invalidate(); toast.success("Template deleted"); },
  });
  const createContactMutation = trpc.contact.create.useMutation({
    onSuccess: () => {
      void utils.contact.list.invalidate({ estateId });
      void utils.delivery.getRecipients.invalidate({ estateId });
      void utils.distribution.compute.invalidate({ estateId });
      void utils.readiness.check.invalidate({ estateId });
      void utils.readiness.timeline.invalidate({ estateId });
      void utils.deadline.list.invalidate();
      void utils.document.preflight.invalidate();
      void utils.document.preflightMany.invalidate();
    },
  });

  const handleApplyTemplate = async (template: any) => {
    try {
      const parsed = JSON.parse(template.contacts) as any[];
      for (const c of parsed) {
        await createContactMutation.mutateAsync({ estateId, ...c });
      }
      toast.success(`Applied ${parsed.length} contacts from "${template.name}"`);
    } catch { toast.error("Failed to apply template"); }
  };

  const handleSave = () => {
    if (!templateName.trim()) return;
    const serialized = contacts.map(({ id, estateId: _e, ...rest }: any) => rest);
    createMutation.mutate({ name: templateName.trim(), contacts: JSON.stringify(serialized) });
  };

  if (!templates || templates.length === 0) {
    return (
      <div className="flex items-center justify-between p-3 rounded-lg border border-dashed border-muted-foreground/20">
        <p className="text-xs text-muted-foreground">Save contacts as a reusable template for future estates</p>
        <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="ghost" size="sm" disabled={!contacts.length}>
              <Bookmark className="h-3 w-3 mr-1" /> Save as Template
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Save Contact Template</DialogTitle></DialogHeader>
            <p className="text-sm text-muted-foreground">This will save all {contacts.length} contacts as a reusable template.</p>
            <Input placeholder='e.g. "Standard PGT + AG" or "Smith Family"' value={templateName} onChange={(e) => setTemplateName(e.target.value)} />
            <Button onClick={handleSave} disabled={createMutation.isPending || !templateName.trim()}>
              {createMutation.isPending ? "Saving..." : "Save Template"}
            </Button>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2 p-3 rounded-lg border border-dashed border-muted-foreground/20 flex-wrap">
      <span className="text-xs text-muted-foreground mr-1">Templates:</span>
      {templates.map((t) => (
        <div key={t.id} className="flex items-center gap-1">
          <Button variant="outline" size="sm" className="text-xs h-7" onClick={() => handleApplyTemplate(t)}>
            {t.name}
          </Button>
          <button onClick={() => deleteMutation.mutate({ id: t.id })} className="text-muted-foreground/40 hover:text-red-600 dark:hover:text-red-300 transition-colors">
            <X className="h-3 w-3" />
          </button>
        </div>
      ))}
      <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
        <DialogTrigger asChild>
          <Button variant="ghost" size="sm" className="text-xs h-7" disabled={!contacts.length}>
            <Plus className="h-3 w-3 mr-1" /> Save Current
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader><DialogTitle>Save Contact Template</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">This will save all {contacts.length} contacts as a reusable template.</p>
          <Input placeholder='e.g. "Standard PGT + AG" or "Smith Family"' value={templateName} onChange={(e) => setTemplateName(e.target.value)} />
          <Button onClick={handleSave} disabled={createMutation.isPending || !templateName.trim()}>
            {createMutation.isPending ? "Saving..." : "Save Template"}
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export function ContactsTab({ estateId }: { estateId: string }) {
  const { data: contacts, isLoading } = trpc.contact.list.useQuery({ estateId });
  const { data: estate } = trpc.estate.get.useQuery({ id: estateId });
  const { data: settings } = trpc.settings.get.useQuery();
  const formFocusedIntake = useFormFocusedIntakePreference(settings?.formFocusedIntake);
  const utils = trpc.useUtils();
  const invalidateContactDerivedState = () => {
    void utils.contact.list.invalidate({ estateId });
    void utils.delivery.getRecipients.invalidate({ estateId });
    void utils.readiness.check.invalidate({ estateId });
    void utils.readiness.timeline.invalidate({ estateId });
    void utils.deadline.list.invalidate();
    void utils.inventory.list.invalidate({ estateId });
    void utils.distribution.compute.invalidate({ estateId });
    void utils.document.getLetterRecipients.invalidate({ estateId });
    void utils.document.preflight.invalidate();
    void utils.document.preflightMany.invalidate();
  };
  const setServiceContactMutation = trpc.estate.update.useMutation({
    onSuccess: () => {
      void utils.estate.get.invalidate({ id: estateId });
      void utils.readiness.check.invalidate({ estateId });
      void utils.document.preflight.invalidate();
      void utils.document.preflightMany.invalidate();
      toast.success("Address-for-service contact updated");
    },
  });
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingContact, setEditingContact] = useState<any>(null);
  const emptyContact = { role: "beneficiary", name: "", address: "", email: "", phone: "", relationship: "", addressForService: "", cityCountry: "", deliveryMethod: "mail", deliveryDate: "", firmName: "", guardianName: "", occupation: "" };
  const [newContact, setNewContact] = useState(emptyContact);
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("all");

  // Contact drafts intentionally stay local until the user selects Save. This
  // protects a partially completed Add/Edit dialog on close, refresh, or a
  // mobile browser lifecycle event without creating an incomplete Contact row.
  const isNewContactDirty = JSON.stringify(newContact) !== JSON.stringify(emptyContact);
  const {
    pendingDraft: pendingNewContactDraft,
    pendingDraftTime: pendingNewContactDraftTime,
    lastSavedAt: newContactDraftSavedAt,
    acceptDraft: acceptNewContactDraft,
    dismissDraft: dismissNewContactDraft,
    clearDraft: clearNewContactDraft,
    flushDraft: flushNewContactDraft,
  } = useLocalDraft({
    key: contactAddDraftKey(estateId),
    data: newContact,
    isDirty: isNewContactDirty,
  });
  const editingContactId = editingContact?.id as string | undefined;
  const persistedEditingContact = useMemo(
    () => (contacts || []).find((contact: any) => contact.id === editingContactId) || null,
    [contacts, editingContactId],
  );
  const isEditingContactDirty = Boolean(
    editingContact && persistedEditingContact
      && JSON.stringify(editingContact) !== JSON.stringify(persistedEditingContact),
  );
  const {
    pendingDraft: pendingEditingContactDraft,
    pendingDraftTime: pendingEditingContactDraftTime,
    lastSavedAt: editingContactDraftSavedAt,
    acceptDraft: acceptEditingContactDraft,
    dismissDraft: dismissEditingContactDraft,
    clearDraft: clearEditingContactDraft,
    flushDraft: flushEditingContactDraft,
  } = useLocalDraft({
    key: contactEditDraftKey(estateId, editingContactId || "none"),
    data: editingContact || {},
    isDirty: isEditingContactDirty,
  });

  const closeAddContactDialog = (open: boolean) => {
    if (!open && isNewContactDirty) flushNewContactDraft();
    setDialogOpen(open);
  };
  const closeEditContactDialog = (open: boolean) => {
    if (!open && isEditingContactDirty) flushEditingContactDraft();
    setEditDialogOpen(open);
  };
  const restoreNewContactDraft = () => {
    const draft = acceptNewContactDraft();
    if (draft) {
      setNewContact(draft);
      toast.success("Contact draft restored");
    }
  };
  const discardNewContactDraft = () => {
    dismissNewContactDraft();
    setNewContact(emptyContact);
  };
  const restoreEditingContactDraft = () => {
    const draft = acceptEditingContactDraft();
    if (draft) {
      setEditingContact(draft);
      toast.success("Contact draft restored");
    }
  };
  const discardEditingContactDraft = () => {
    dismissEditingContactDraft();
    setEditingContact(persistedEditingContact ? { ...persistedEditingContact } : null);
  };

  const ROLE_FILTERS = ["all", "beneficiary", "executor", "alternate_executor", "applicant", "administrator", "trustee", "lawyer", "creditor", "spouse", "guardian"] as const;

  const filteredContacts = useMemo(() => {
    if (!contacts) return [];
    let filtered = contacts;
    if (roleFilter !== "all") {
      filtered = filtered.filter((c) => contactHasRole(c, roleFilter));
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter((c) =>
        (c.name || "").toLowerCase().includes(q) ||
        (c.email || "").toLowerCase().includes(q) ||
        (c.role || "").toLowerCase().includes(q) ||
        (c.phone || "").toLowerCase().includes(q)
      );
    }
    return filtered;
  }, [contacts, roleFilter, searchQuery]);

  const createMutation = trpc.contact.create.useMutation({
    onSuccess: () => { clearNewContactDraft(); invalidateContactDerivedState(); setDialogOpen(false); setNewContact(emptyContact); toast.success("Contact added"); },
    onError: (err) => { flushNewContactDraft(); toast.error(`${err.message || "Failed to add contact"}. Your draft is safely kept on this device.`); },
  });
  const updateMutation = trpc.contact.update.useMutation({
    onSuccess: () => { clearEditingContactDraft(); invalidateContactDerivedState(); setEditDialogOpen(false); setEditingContact(null); toast.success("Contact updated"); },
    onError: (err) => { flushEditingContactDraft(); toast.error(`${err.message || "Failed to update contact"}. Your draft is safely kept on this device.`); },
  });
  const deleteMutation = trpc.contact.delete.useMutation({
    onSuccess: invalidateContactDerivedState,
    onError: (err) => { toast.error(err.message || "Failed to delete contact"); },
  });

  const pendingDeleteRef = useRef<{ id: string; timer: ReturnType<typeof setTimeout> } | null>(null);

  const handleDeleteContact = (contact: any) => {
    // Cancel any existing pending delete
    if (pendingDeleteRef.current) clearTimeout(pendingDeleteRef.current.timer);

    // Optimistically remove from UI
    utils.contact.list.setData({ estateId }, (old) => (old || []).filter((c) => c.id !== contact.id));

    // Set a timer to actually delete after 5s
    const timer = setTimeout(() => {
      deleteMutation.mutate({ id: contact.id, estateId });
      pendingDeleteRef.current = null;
    }, 5000);
    pendingDeleteRef.current = { id: contact.id, timer };

    toast("Contact removed", {
      action: {
        label: "Undo",
        onClick: () => {
          if (pendingDeleteRef.current && pendingDeleteRef.current.id === contact.id) {
            clearTimeout(pendingDeleteRef.current.timer);
            pendingDeleteRef.current = null;
          }
          utils.contact.list.invalidate({ estateId });
        },
      },
      duration: 5000,
    });
  };


  const toggleRoleMutation = trpc.contact.update.useMutation({
    onSuccess: () => { invalidateContactDerivedState(); toast.success("Role updated"); },
  });

  const uploadConsentMutation = trpc.contact.uploadConsentDocument.useMutation({
    onSuccess: () => { invalidateContactDerivedState(); toast.success("Consent document uploaded"); },
    onError: (err) => { toast.error(err.message || "Failed to upload consent document"); },
  });
  const deleteConsentDocMutation = trpc.contact.deleteConsentDocument.useMutation({
    onSuccess: () => { invalidateContactDerivedState(); toast.success("Consent document removed"); },
    onError: (err) => { toast.error(err.message || "Failed to remove consent document"); },
  });
  const consentFileInputRefs = useRef<Record<string, HTMLInputElement | null>>({});
  const consentAllowedTypes = ["application/pdf", "image/png", "image/jpeg", "image/tiff", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
  const processConsentFile = async (contactId: string, file: File) => {
    if (!consentAllowedTypes.includes(file.type)) { toast.error("Please upload a PDF, DOC/DOCX, or image file"); return; }
    if (file.size > 20 * 1024 * 1024) { toast.error("File too large (max 20 MB)"); return; }
    const arrayBuf = await file.arrayBuffer();
    const bytes = new Uint8Array(arrayBuf);
    let binary = "";
    for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
    const base64 = btoa(binary);
    uploadConsentMutation.mutate({ estateId, contactId, fileBase64: base64, fileName: file.name, mimeType: file.type });
  };
  const handleConsentFileSelect = async (contactId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processConsentFile(contactId, file);
    if (consentFileInputRefs.current[contactId]) consentFileInputRefs.current[contactId]!.value = "";
  };
  const [consentDragOver, setConsentDragOver] = useState<string | null>(null);
  const handleConsentDrop = async (contactId: string, e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setConsentDragOver(null);
    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    await processConsentFile(contactId, file);
  };

  const handleToggleRole = (contact: any, role: string) => {
    const currentRoles = contactRoles(contact);
    let newRoles: string[];
    if (currentRoles.includes(role)) {
      newRoles = currentRoles.filter((r: string) => r !== role);
    } else {
      newRoles = [...currentRoles, role];
    }
    const { id, estateId: _eid, ...data } = contact;
    toggleRoleMutation.mutate({ id, estateId, data: { ...data, role: newRoles.join(",") } });
  };

  return (
    <div className="space-y-4 pt-4">
      {/* Contact Templates */}
      <ContactTemplateBar estateId={estateId} contacts={contacts || []} />

      <div className="flex items-center justify-between">
        <h3 className="font-medium text-sm">Contacts & Parties</h3>
        <Dialog open={dialogOpen} onOpenChange={closeAddContactDialog}>
          <DialogTrigger asChild><Button size="sm"><Plus className="h-3 w-3 mr-1" /> Add Contact</Button></DialogTrigger>
          <DialogContent overlayClassName="contact-dialog-overlay" className="contact-dialog-content flex max-h-[calc(100dvh-1rem)] w-[calc(100%-1rem)] flex-col gap-0 overflow-hidden rounded-2xl border-border/80 p-0 shadow-[0_28px_80px_-34px_rgba(15,23,42,0.52)] dark:shadow-[0_28px_80px_-34px_rgba(0,0,0,0.78)] sm:max-w-4xl">
            <DialogHeader className="contact-dialog-header border-b border-border/70 px-5 py-4 pr-12 sm:px-6 sm:py-5"><DialogTitle className="text-xl font-semibold tracking-[-0.02em]">Add Contact</DialogTitle><DialogDescription className="sr-only">Record a new contact for this estate</DialogDescription></DialogHeader>
            <div className="contact-dialog-scroll-area min-h-0 flex-1 overflow-y-auto px-5 py-5 sm:px-6 sm:py-6">
              {pendingNewContactDraft && (
                <div data-testid="contact-add-draft-recovery" className="mb-5 flex flex-col gap-3 rounded-xl border border-primary/20 bg-primary/[0.045] p-3.5 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex min-w-0 items-start gap-2.5">
                    <History className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                    <p className="text-xs leading-relaxed text-muted-foreground"><span className="font-medium text-foreground">Unsaved contact draft found.</span> It was saved locally {pendingNewContactDraftTime ? `at ${new Date(pendingNewContactDraftTime).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}` : "earlier"}.</p>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <Button size="sm" variant="outline" className="h-8 rounded-lg text-xs" onClick={discardNewContactDraft}>Discard</Button>
                    <Button size="sm" className="h-8 rounded-lg text-xs" onClick={restoreNewContactDraft}>Restore</Button>
                  </div>
                </div>
              )}
              <ContactFormFields contact={newContact} setContact={setNewContact} allContacts={contacts || []} formFocusedIntake={formFocusedIntake} />
            </div>
            <div className="contact-dialog-footer shrink-0 border-t border-border/70 bg-background/95 px-5 py-4 backdrop-blur-sm sm:px-6">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex min-h-5 items-center gap-2">
                  <span data-testid="contact-add-autosave-status" className="contact-draft-status text-xs" role="status" aria-live="polite">
                    {isNewContactDirty ? (newContactDraftSavedAt ? `Draft saved locally at ${new Date(newContactDraftSavedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}` : "Automatic recovery is protecting this draft") : "Automatic recovery is ready"}
                  </span>
                  {isNewContactDirty && <Button size="sm" variant="ghost" className="h-7 rounded-lg px-2 text-xs" onClick={discardNewContactDraft}>Discard changes</Button>}
                </div>
                <Button className="h-11 rounded-xl shadow-sm transition-[transform,box-shadow,background-color] duration-150 ease-out hover:shadow-md active:scale-[0.99] sm:min-w-44" onClick={() => createMutation.mutate({ estateId, ...newContact })} disabled={createMutation.isPending}>
                  {createMutation.isPending ? "Saving..." : "Save Contact"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* P2-2: Edit dialog */}
      <Dialog open={editDialogOpen} onOpenChange={closeEditContactDialog}>
        <DialogContent overlayClassName="contact-dialog-overlay" className="contact-dialog-content flex max-h-[calc(100dvh-1rem)] w-[calc(100%-1rem)] flex-col gap-0 overflow-hidden rounded-2xl border-border/80 p-0 shadow-[0_28px_80px_-34px_rgba(15,23,42,0.52)] dark:shadow-[0_28px_80px_-34px_rgba(0,0,0,0.78)] sm:max-w-4xl">
          <DialogHeader className="contact-dialog-header border-b border-border/70 px-5 py-4 pr-12 sm:px-6 sm:py-5"><DialogTitle className="text-xl font-semibold tracking-[-0.02em]">Edit Contact</DialogTitle><DialogDescription className="sr-only">Edit this contact's details</DialogDescription></DialogHeader>
          {editingContact && (
            <>
              <div className="contact-dialog-scroll-area min-h-0 flex-1 overflow-y-auto px-5 py-5 sm:px-6 sm:py-6">
                {pendingEditingContactDraft && (
                  <div data-testid="contact-edit-draft-recovery" className="mb-5 flex flex-col gap-3 rounded-xl border border-primary/20 bg-primary/[0.045] p-3.5 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex min-w-0 items-start gap-2.5">
                      <History className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      <p className="text-xs leading-relaxed text-muted-foreground"><span className="font-medium text-foreground">Unsaved contact draft found.</span> It was saved locally {pendingEditingContactDraftTime ? `at ${new Date(pendingEditingContactDraftTime).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}` : "earlier"}.</p>
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      <Button size="sm" variant="outline" className="h-8 rounded-lg text-xs" onClick={discardEditingContactDraft}>Discard</Button>
                      <Button size="sm" className="h-8 rounded-lg text-xs" onClick={restoreEditingContactDraft}>Restore</Button>
                    </div>
                  </div>
                )}
                <ContactFormFields contact={editingContact} setContact={setEditingContact} allContacts={contacts || []} formFocusedIntake={formFocusedIntake} />
              </div>
              <div className="contact-dialog-footer shrink-0 border-t border-border/70 bg-background/95 px-5 py-4 backdrop-blur-sm sm:px-6">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex min-h-5 items-center gap-2">
                    <span data-testid="contact-edit-autosave-status" className="contact-draft-status text-xs" role="status" aria-live="polite">
                      {isEditingContactDirty ? (editingContactDraftSavedAt ? `Draft saved locally at ${new Date(editingContactDraftSavedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}` : "Automatic recovery is protecting this draft") : "Automatic recovery is ready"}
                    </span>
                    {isEditingContactDirty && <Button size="sm" variant="ghost" className="h-7 rounded-lg px-2 text-xs" onClick={discardEditingContactDraft}>Discard changes</Button>}
                  </div>
                  <Button className="h-11 rounded-xl shadow-sm transition-[transform,box-shadow,background-color] duration-150 ease-out hover:shadow-md active:scale-[0.99] sm:min-w-44" onClick={() => {
                    const { id, estateId: _eid, ...data } = editingContact;
                    updateMutation.mutate({ id, estateId, data });
                  }} disabled={updateMutation.isPending}>
                    {updateMutation.isPending ? "Saving..." : "Save Changes"}
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Smart suggestions based on current contacts */}
      {!isLoading && contacts && (() => {
        const roles = (contacts || []).flatMap(c => contactRoles(c));
        const suggestions: string[] = [];
        if (!roles.includes("applicant") && !roles.includes("executor")) suggestions.push("Add at least one applicant/executor to generate forms.");
        if (!roles.includes("beneficiary")) suggestions.push("Add beneficiaries to generate P1 notices and letters.");
        const hasAddress = (contacts || []).filter(c => contactRoles(c).includes("beneficiary")).every(c => c.residentialAddress || c.postalAddress || c.addressForService);
        if (roles.includes("beneficiary") && !hasAddress) suggestions.push("Some beneficiaries are missing addresses — needed for P1 delivery.");
        if (suggestions.length === 0) return null;
        return (
          <Alert className="border-blue-200 dark:border-blue-800/50 bg-blue-50/50 dark:bg-blue-950/20">
            <Lightbulb className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-xs text-blue-800 dark:text-blue-300">
              <ul className="space-y-0.5 list-disc pl-3">
                {suggestions.map((s, i) => <li key={i}>{s}</li>)}
              </ul>
            </AlertDescription>
          </Alert>
        );
      })()}

      {/* Search & Filter */}
      <div className="space-y-2">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            placeholder="Search contacts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8 h-8 text-sm"
          />
        </div>
        <div className="flex gap-1 flex-wrap">
          {ROLE_FILTERS.filter(r => r === "all" || (contacts || []).some(c => contactHasRole(c, r))).map((role) => (
            <button
              key={role}
              onClick={() => setRoleFilter(role)}
              className={`px-2 py-0.5 rounded-full text-[11px] font-medium border transition-colors ${
                roleFilter === role
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-background text-muted-foreground border-border hover:border-primary/50"
              }`}
            >
              {role === "all" ? "All" : role.charAt(0).toUpperCase() + role.slice(1)}
              {role !== "all" && <span className="ml-1 opacity-60">{(contacts || []).filter(c => contactHasRole(c, role)).length}</span>}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? <div className="h-20 bg-muted animate-pulse rounded-lg" /> : (
        <div className="space-y-2">
          {filteredContacts.map((c) => (
            <Card key={c.id} className="border group">
              <CardContent className="py-3 px-3">
                <div className="flex items-center gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-medium text-sm truncate">{c.name || "Unnamed"}</span>
                      {contactRoles(c).map((r: string) => (
                        <Badge key={r} variant="outline" className="text-[10px] shrink-0">{roleLabel(r, c.relationship)}</Badge>
                      ))}
                      {contactHasRole(c, "executor", "alternate_executor", "applicant") && c.executorStatus && c.executorStatus !== "applying" && c.executorStatus !== "unknown" && (
                        <Badge variant="secondary" className="text-[10px] shrink-0 bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300">{c.executorStatus.replace("_", " ")}</Badge>
                      )}
                      {contactHasRole(c, "executor", "alternate_executor", "applicant") && (!c.executorStatus || c.executorStatus === "unknown") && (
                        <Badge variant="secondary" className="text-[10px] shrink-0 bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300">status not set</Badge>
                      )}
                      {c.executorRank && contactHasRole(c, "executor", "applicant") && (
                        <Badge variant="secondary" className={`text-[10px] shrink-0 ${c.executorRank === "primary" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300" : "bg-slate-100 text-slate-700 dark:bg-slate-800/50 dark:text-slate-300"}`}>#{c.executorRankNumber || "?"} {c.executorRank}</Badge>
                      )}
                      {c.isMinor ? <Badge variant="secondary" className="text-[10px] shrink-0 bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300">Minor</Badge> : null}
                      {c.isMentallyIncapable ? <Badge variant="secondary" className="text-[10px] shrink-0 bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300">Incapable</Badge> : null}
                      {contactHasRole(c, "intestate_successor_candidate") && <Badge variant="secondary" className="text-[10px] shrink-0 bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300">Intestate successor candidate</Badge>}
                      {contactHasRole(c, "beneficiary") && (c as any).priorityConsent && (c as any).priorityConsent !== "unknown" && (
                        <Badge variant="secondary" className={`text-[10px] shrink-0 ${
                          (c as any).priorityConsent === "consented" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300" :
                          (c as any).priorityConsent === "renounced" ? "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300" :
                          (c as any).priorityConsent === "cannot_locate" ? "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300" :
                          "bg-slate-100 text-slate-700 dark:bg-slate-800/50 dark:text-slate-300"
                        }`}>{(c as any).priorityConsent === "consented" ? "Consented" : (c as any).priorityConsent === "renounced" ? "Renounced" : (c as any).priorityConsent === "cannot_locate" ? "Cannot locate" : (c as any).priorityConsent}</Badge>
                      )}
                      {contactHasRole(c, "lawyer") && (() => {
                        const isServiceContact = estate?.serviceContactId === c.id || (!estate?.serviceContactId && contacts?.filter(ct => contactHasRole(ct, "lawyer"))[0]?.id === c.id);
                        const lawyerCount = contacts?.filter(ct => contactHasRole(ct, "lawyer")).length || 0;
                        return (
                          <>
                            {isServiceContact && <Badge variant="secondary" className="text-[10px] shrink-0 bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300">Address for service</Badge>}
                            {!isServiceContact && lawyerCount > 1 && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (!estate) return;
                                  setServiceContactMutation.mutate({ id: estateId, expectedRevision: estate.revision, data: { serviceContactId: c.id } });
                                }}
                                className="text-[10px] text-muted-foreground hover:text-foreground underline transition-colors"
                              >
                                Use as service address
                              </button>
                            )}
                          </>
                        );
                      })()}
                    </div>
                    {c.firmName && <p className="text-xs text-muted-foreground mt-0.5 truncate">{c.firmName}</p>}
                    <div className="flex items-center gap-1.5 mt-0.5">
                      {c.residentialAddress && <span className="text-[9px] font-medium px-1 py-0.5 rounded bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400" title={`Res: ${c.residentialAddress.split("\n")[0]}`}>RES</span>}
                      {c.postalAddress && <span className="text-[9px] font-medium px-1 py-0.5 rounded bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400" title={`Post: ${c.postalAddress.split("\n")[0]}`}>POST</span>}
                      {c.email && <span className="text-[9px] font-medium px-1 py-0.5 rounded bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400" title={c.email}>EMAIL</span>}
                      {c.faxNumber && <span className="text-[9px] font-medium px-1 py-0.5 rounded bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400" title={c.faxNumber}>FAX</span>}
                      {!c.residentialAddress && !c.postalAddress && !c.email && !c.faxNumber && <span className="text-[9px] text-muted-foreground italic">No address info</span>}
                    </div>
                  </div>
                  <div className="flex items-center shrink-0">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-7 px-1.5 text-[10px] text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">
                          <ChevronDown className="h-3 w-3 mr-0.5" />Roles
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-40">
                        {["beneficiary", "executor", "alternate_executor", "applicant", "administrator", "trustee", "lawyer", "creditor", "spouse", "guardian"].map((role) => {
                          const hasRole = contactHasRole(c, role);
                          return (
                            <DropdownMenuItem key={role} onClick={() => handleToggleRole(c, role)} className="text-xs">
                              <span className={`mr-2 ${hasRole ? "opacity-100" : "opacity-0"}`}>✓</span>
                              {role.charAt(0).toUpperCase() + role.slice(1)}
                            </DropdownMenuItem>
                          );
                        })}
                      </DropdownMenuContent>
                    </DropdownMenu>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0" aria-label={`Edit ${c.name || "contact"}`} onClick={() => { setEditingContact({ ...c }); setEditDialogOpen(true); }}>
                      <Pencil className="h-3.5 w-3.5 text-muted-foreground" />
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => handleDeleteContact(c)}>
                      <Trash2 className="h-3.5 w-3.5 text-destructive" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          {filteredContacts.length === 0 && (contacts || []).length > 0 && <p className="text-sm text-muted-foreground text-center py-8">No contacts match your search.</p>}
          {(contacts || []).length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No contacts yet. Add all persons entitled to P1 notice (applicants, beneficiaries, executors, intestate successors, creditors if intestacy).</p>}
        </div>
      )}
      {(contacts || []).some(c => contactHasRole(c, "lawyer")) && (
        <p className="text-[10px] text-muted-foreground italic mt-2 flex items-center gap-1">
          <Info className="h-3 w-3 shrink-0" />
          A contact with role &ldquo;lawyer&rdquo; will be used as the address for service on filed forms (P1, P2, and cover letters).
        </p>
      )}

      {/* Bulk Consent Management — WESA s.130/s.131 */}
      {(() => {
        const beneficiaries = (contacts || []).filter(c => contactHasRole(c, "beneficiary") && !(c as any).isMinor);
        if (beneficiaries.length < 2) return null;
        const consentCounts = {
          consented: beneficiaries.filter(c => (c as any).priorityConsent === "consented").length,
          renounced: beneficiaries.filter(c => (c as any).priorityConsent === "renounced").length,
          cannot_locate: beneficiaries.filter(c => (c as any).priorityConsent === "cannot_locate").length,
          unknown: beneficiaries.filter(c => !(c as any).priorityConsent || (c as any).priorityConsent === "unknown").length,
        };
        return (
          <Card className="mt-4 border-blue-200 dark:border-blue-800/50">
            <CardContent className="py-3 px-4">
              <p className="text-xs font-medium mb-2">Beneficiary Consent — WESA s.130/s.131</p>
              <div className="flex gap-3 text-[10px] mb-3">
                <span className="text-emerald-700 dark:text-emerald-400">{consentCounts.consented} consented</span>
                <span className="text-red-700 dark:text-red-400">{consentCounts.renounced} renounced</span>
                <span className="text-orange-700 dark:text-orange-400">{consentCounts.cannot_locate} cannot locate</span>
                <span className="text-muted-foreground">{consentCounts.unknown} pending</span>
              </div>
              <div className="space-y-2">
                {beneficiaries.map(c => (
                  <div key={c.id} className="py-1.5 px-2 rounded border border-border/50 bg-muted/30">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium flex-1 min-w-0 truncate">{c.name || "Unnamed"}</span>
                      <Select
                        value={(c as any).priorityConsent || "unknown"}
                        onValueChange={(v) => {
                          updateMutation.mutate({ id: c.id, estateId, data: { priorityConsent: v } });
                        }}
                      >
                        <SelectTrigger className="h-6 w-[130px] text-[10px] shrink-0"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="unknown">Pending</SelectItem>
                          <SelectItem value="consented">Consented</SelectItem>
                          <SelectItem value="renounced">Renounced</SelectItem>
                          <SelectItem value="cannot_locate">Cannot locate</SelectItem>
                          <SelectItem value="not_required">Not required</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    {/* File upload for consent/renunciation letter */}
                    {((c as any).priorityConsent === "consented" || (c as any).priorityConsent === "renounced") && (
                      <div className="mt-1.5 flex items-center gap-1.5">
                        {(c as any).priorityConsentDocumentKey ? (
                          <>
                            <a
                              href={`/manus-storage/${(c as any).priorityConsentDocumentKey}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-[10px] text-blue-600 dark:text-blue-400 hover:underline"
                            >
                              <Paperclip className="h-3 w-3" />
                              <span className="truncate max-w-[140px]">View document</span>
                            </a>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-5 w-5 text-destructive hover:text-destructive"
                              onClick={() => deleteConsentDocMutation.mutate({ estateId, contactId: c.id })}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </>
                        ) : (
                          <>
                            <input
                              type="file"
                              ref={(el) => { consentFileInputRefs.current[c.id] = el; }}
                              className="hidden"
                              accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.tiff"
                              onChange={(e) => handleConsentFileSelect(c.id, e)}
                            />
                            <div
                              className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded border border-dashed cursor-pointer transition-colors ${
                                consentDragOver === c.id
                                  ? "border-blue-500 bg-blue-50 dark:bg-blue-950/30"
                                  : "border-border/70 hover:border-blue-400 hover:bg-muted/50"
                              }`}
                              onClick={() => consentFileInputRefs.current[c.id]?.click()}
                              onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); setConsentDragOver(c.id); }}
                              onDragEnter={(e) => { e.preventDefault(); e.stopPropagation(); setConsentDragOver(c.id); }}
                              onDragLeave={(e) => { e.preventDefault(); e.stopPropagation(); setConsentDragOver(null); }}
                              onDrop={(e) => handleConsentDrop(c.id, e)}
                            >
                              <Upload className="h-3 w-3 text-muted-foreground" />
                              <span className="text-[10px] text-muted-foreground">
                                {uploadConsentMutation.isPending ? "Uploading..." : consentDragOver === c.id ? "Drop file here" : "Drop or click to attach letter"}
                              </span>
                            </div>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
              <p className="text-[10px] text-muted-foreground mt-2">Recording consent here satisfies the s.131(a) majority-in-interest check for admin-with-will grants (P3 eligibility) and the s.130 priority-consent requirement for intestacy (P5).</p>
            </CardContent>
          </Card>
        );
      })()}
    </div>
  );
}

// ─── INVENTORY TAB ───────────────────────────────────────────────────
type BankAccountReview = {
  id?: string;
  description?: string;
  subcategory?: string;
  accountHolder?: string;
  accountNumber?: string;
  bankAddress?: string;
};

function normalizeAccountNumber(value: unknown): string {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

function hasValidAccountNumberFormat(value: unknown): boolean {
  const raw = String(value || "").trim();
  const normalized = normalizeAccountNumber(raw);
  return normalized.length >= 4 && /^[a-z0-9\s-]+$/i.test(raw);
}

function bankAccountReviewFrom(item: any): BankAccountReview {
  return {
    id: item.id,
    description: item.description || "",
    subcategory: item.subcategory || "",
    accountHolder: item.accountHolder || "",
    accountNumber: item.accountNumber || "",
    bankAddress: item.bankAddress || "",
  };
}

function bankAccountKey(item: any): string {
  const branchAddress = String(item?.bankAddress || "").trim().toLowerCase().replace(/\s+/g, " ");
  if (branchAddress) return `branch:${branchAddress}`;
  return `description:${String(item?.description || "").trim().toLowerCase().replace(/\s+/g, " ")}`;
}

function bankInstitutionLabel(item: any): string {
  const description = String(item?.description || "").trim();
  if (description) return description;

  const branchAddress = String(item?.bankAddress || "").trim();
  return branchAddress ? `Bank branch — ${branchAddress}` : "Financial accounts";
}

function financialAccountLabel(item: any, ordinal?: number): string {
  const description = String(item?.description || "").trim();
  return description || (ordinal ? `Account ${ordinal}` : "Account");
}

function accountReviewDetail(account: BankAccountReview): string {
  const type = account.subcategory
    ? account.subcategory.replace(/_/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase())
    : "Account";
  const suffix = account.accountNumber ? `••••${account.accountNumber.replace(/\s/g, "").slice(-4)}` : "number pending";
  return `${type} · ${suffix}`;
}

type SpreadsheetPreviewField = "category" | "description" | "location" | "value" | "accountNumber";

const SPREADSHEET_PREVIEW_CATEGORIES = ["real_property", "tangible", "financial", "liability"] as const;
const SPREADSHEET_PREVIEW_LOCATIONS = ["in_bc", "outside_bc"] as const;

function previewCategoryLabel(category: SpreadsheetInventoryItem["category"]): string {
  return category === "unknown" ? "Choose type" : category.replace(/_/g, " ");
}

function previewLocationLabel(location: SpreadsheetInventoryItem["location"]): string {
  return location === "in_bc" ? "In BC" : location === "outside_bc" ? "Outside BC" : "Choose location";
}

export function InventoryFormFields({ item, setItem, allItems = [], creditorContacts = [], onCreateCreditor, supplementalAvailable = false, isAdditionalBankAccount = false, accountOrdinal, duplicateAccountNumber = false }: { item: any; setItem: (i: any) => void; allItems?: any[]; creditorContacts?: any[]; onCreateCreditor?: () => void; supplementalAvailable?: boolean; isAdditionalBankAccount?: boolean; accountOrdinal?: number; duplicateAccountNumber?: boolean }) {
  const isFinancial = item.category === "financial";
  const isRealProperty = item.category === "real_property";
  const isLiability = item.category === "liability";
  const accountNumberEntered = Boolean(String(item.accountNumber || "").trim());
  const accountNumberFormatValid = accountNumberEntered && hasValidAccountNumberFormat(item.accountNumber);
  const accountNumberFormatInvalid = accountNumberEntered && !accountNumberFormatValid;
  const linkableAssets = allItems.filter((candidate) =>
    candidate.id !== item.id
    && candidate.category !== "liability"
    && passesToPersonalRepresentative(candidate)
  );

  return (
    <div className={isAdditionalBankAccount ? "grid grid-cols-1 gap-3 pt-2 sm:grid-cols-2" : "space-y-3 pt-2"}>
      {!isAdditionalBankAccount && <div className="space-y-1">
        <Label className="text-xs">Category</Label>
        <Select value={item.category} onValueChange={(v) => {
          // Preserve common fields (description, value, location) but clear category-specific fields
          const next = {
            ...item,
            category: v,
            // subcategory is category-specific (financial account type OR the
            // tangible household/personal-effects flag) — ALWAYS reset on a
            // category change so a stale value can't leak onto the new category
            // (e.g. "household_personal_effects" rendering as a financial group).
            subcategory: "",
            householdFurnishings: "",
            // Clear financial-specific fields when switching away from financial
            ...(v !== "financial" ? { bankAddress: "", accountHolder: "", accountNumber: "", accruedInterest: "", dateOfDeathValue: "" } : {}),
            // Clear real-property-specific fields when switching away from real_property
            ...(v !== "real_property" ? { pid: "", legalDescription: "", assessedMarketValue: "", registeredOwner: "", ownershipDetails: "" } : {}),
            // A debt's secured/unsecured status and linked asset apply only to liabilities.
            ...(v !== "liability" ? { securityStatus: "unknown", securedAssetId: "", creditorContactId: "" } : { securityStatus: item.securityStatus || "unknown", creditorContactId: item.creditorContactId || "" }),
            // Passage through the estate is an independent legal fact. Clear it
            // when crossing the asset/liability boundary; never infer it from
            // the new category or carry a liability's non-answer onto property.
            passesToPersonalRepresentative: v === "liability" || item.category === "liability"
              ? ""
              : (item.passesToPersonalRepresentative || ""),
          };
          setItem({ ...next, valueRecorded: inventoryValueRecordedFromForm(next) });
        }}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="unknown">Not yet classified</SelectItem>
            <SelectItem value="real_property">Real Property</SelectItem>
            <SelectItem value="tangible">Tangible Personal Property</SelectItem>
            <SelectItem value="financial">Financial Assets</SelectItem>
            <SelectItem value="liability">Liability</SelectItem>
          </SelectContent>
        </Select>
      </div>}

      {!isLiability && item.category !== "unknown" && (
        <div className={`space-y-1 ${isAdditionalBankAccount ? "sm:col-span-2" : ""}`}>
          <Label className="text-xs">Does this property pass to the applicant in the applicant&apos;s capacity as the deceased&apos;s personal representative?</Label>
          <Select
            value={item.passesToPersonalRepresentative || ""}
            onValueChange={(v) => setItem({ ...item, passesToPersonalRepresentative: v })}
          >
            <SelectTrigger data-testid="inventory-passes-to-personal-representative">
              <SelectValue placeholder="Not yet recorded" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="yes">Yes</SelectItem>
              <SelectItem value="no">No</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-[10px] text-muted-foreground leading-tight">
            Record the legal destination of this item. Property passing by survivorship or a beneficiary designation may not pass to the personal representative. Until this is answered, it is excluded from estate totals, probate-fee estimates and court-form exhibits.
          </p>
        </div>
      )}
      <div className={`space-y-1 ${isAdditionalBankAccount ? "sm:col-span-2" : ""}`}><Label htmlFor="inventory-description" className="text-xs">Description</Label><Input id="inventory-description" data-testid="inventory-description" value={item.description} onChange={(e) => setItem({ ...item, description: e.target.value })} placeholder={isFinancial ? "e.g. TD Bank chequing account" : isRealProperty ? "e.g. 123 Main St, Vancouver" : ""} /></div>
      <div className={`grid grid-cols-1 gap-3 sm:grid-cols-2 ${isAdditionalBankAccount ? "sm:col-span-2" : ""}`}>
        <div className="space-y-1">
          <Label className="text-xs">Location</Label>
          <Select value={item.location} onValueChange={(v) => setItem({ ...item, location: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="unknown">Not yet determined</SelectItem>
              <SelectItem value="in_bc">In BC</SelectItem>
              <SelectItem value="outside_bc">Outside BC</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {!isRealProperty && (
          <div className="space-y-1"><Label className="text-xs">Value (dollars)</Label><Input type="text" inputMode="decimal" value={item.value} onChange={(e) => setItem(updateInventoryValueInput(item, "value", e.target.value))} placeholder="0.00" /></div>
        )}
      </div>

      {/* Financial subcategory dropdown */}
      {isFinancial && (
        <div className={`space-y-1 ${isAdditionalBankAccount ? "max-w-sm" : ""}`}>
          <Label id="inventory-account-type-label" className="text-xs">Account Type</Label>
          <Select value={item.subcategory || ""} onValueChange={(v) => setItem({ ...item, subcategory: v })}>
            <SelectTrigger aria-labelledby="inventory-account-type-label" data-testid="inventory-account-type"><SelectValue placeholder="Select type..." /></SelectTrigger>
            <SelectContent>
              <SelectItem value="chequing">Chequing Account</SelectItem>
              <SelectItem value="savings">Savings Account</SelectItem>
              <SelectItem value="gic">GIC / Term Deposit</SelectItem>
              <SelectItem value="rrsp">RRSP</SelectItem>
              <SelectItem value="rrif">RRIF</SelectItem>
              <SelectItem value="tfsa">TFSA</SelectItem>
              <SelectItem value="investment">Investment / Brokerage</SelectItem>
              <SelectItem value="pension">Pension</SelectItem>
              <SelectItem value="insurance">Life Insurance</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}

      {/* Tangible subcategory — the "household/personal effects" rows fold into
          the standing P10 Part II line (Nick UAT E4). */}
      {item.category === "tangible" && (
        <div className="space-y-1">
          <Label className="text-xs">Tangible Type</Label>
          <Select value={item.subcategory || ""} onValueChange={(v) => setItem({ ...item, subcategory: v === "__none" ? "" : v })}>
            <SelectTrigger><SelectValue placeholder="Select type..." /></SelectTrigger>
            <SelectContent>
              <SelectItem value="household_personal_effects">Personal effects, clothing, furniture &amp; household items</SelectItem>
              <SelectItem value="__none">Other tangible item (list individually)</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-[10px] text-muted-foreground leading-tight">Household/personal-effects items combine into the standing "Personal effects…" line on P10 Part II.</p>
        </div>
      )}

      {/* WESA s.21(1)/(2)(a) — asked in the Act's own words, and deliberately
          NOT folded into the Tangible Type above. That control answers a P10
          Exhibit A grouping question; this one answers a legal question that
          decides who inherits. On an intestacy leaving a spouse and surviving
          descendants the furnishings pass to the spouse outright and come off
          the estate before the preferential share, which moves the s.21(5)/(6)
          boundary. Unanswered is a real state: the engine blanks the shares and
          warns rather than guessing (Rule 9 — it never blocks generation). */}
      {item.category === "tangible" && (
        <div className="space-y-1">
          <Label className="text-xs">Household furnishings (WESA s.21(1))</Label>
          <Select value={(item as any).householdFurnishings || ""} onValueChange={(v) => setItem({ ...item, householdFurnishings: v } as any)}>
            <SelectTrigger><SelectValue placeholder="Not yet answered" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="yes">Yes — usually associated with enjoyment of the spousal home</SelectItem>
              <SelectItem value="no">No</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-[10px] text-muted-foreground leading-tight">WESA s.21(1) defines household furnishings as “personal property usually associated with the enjoyment by the spouses of the spousal home”. Furniture and appliances usually qualify; jewellery, clothing, a vehicle or a boat usually do not. Only needed on an intestacy leaving a spouse and descendants — until it is answered there, Form P10 leaves the shares blank.</p>
        </div>
      )}

      {/* Bank / Financial detail fields */}
      {isFinancial && (
        <div className={`space-y-3 border-t pt-3 mt-2 ${isAdditionalBankAccount ? "sm:col-span-2" : ""}`}>
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Bank Details</p>
          <div className={isAdditionalBankAccount ? "grid grid-cols-1 gap-3 sm:grid-cols-2" : "space-y-3"}>
            <div className={`space-y-1 ${isAdditionalBankAccount ? "sm:col-span-2" : ""}`}><Label htmlFor="inventory-bank-address" className="text-xs">Bank Address</Label><Input id="inventory-bank-address" data-testid="inventory-bank-address" value={item.bankAddress || ""} onChange={(e) => setItem({ ...item, bankAddress: e.target.value })} placeholder="Branch address" /></div>
            <div className="space-y-1"><Label htmlFor="inventory-account-holder" className="text-xs">Account in the Name of</Label><Input id="inventory-account-holder" data-testid="inventory-account-holder" value={item.accountHolder || ""} onChange={(e) => setItem({ ...item, accountHolder: e.target.value })} placeholder="Account holder name(s)" /></div>
            <div className="space-y-1">
              <Label htmlFor="inventory-account-number" className="text-xs">{isAdditionalBankAccount ? `Account ${accountOrdinal || 1} number` : "Account Number"}</Label>
              <div className="relative">
                <Input
                  id="inventory-account-number"
                  autoFocus={isAdditionalBankAccount}
                  aria-describedby={[
                    duplicateAccountNumber ? "inventory-account-number-duplicate" : "",
                    accountNumberFormatInvalid ? "inventory-account-number-format" : "",
                  ].filter(Boolean).join(" ") || undefined}
                  aria-invalid={duplicateAccountNumber || accountNumberFormatInvalid || undefined}
                  data-testid="inventory-account-number"
                  value={item.accountNumber || ""}
                  onChange={(e) => setItem({ ...item, accountNumber: e.target.value })}
                  placeholder="Account number"
                  className={cn(
                    accountNumberFormatValid && !duplicateAccountNumber && "border-emerald-600/60 pr-9 focus-visible:border-emerald-600 focus-visible:ring-emerald-600/25",
                    (duplicateAccountNumber || accountNumberFormatInvalid) && "border-destructive/70 focus-visible:border-destructive focus-visible:ring-destructive/25",
                  )}
                />
                {accountNumberFormatValid && !duplicateAccountNumber && (
                  <CheckCircle2
                    aria-label="Account number format looks valid"
                    className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-emerald-600 dark:text-emerald-400"
                    data-testid="inventory-account-number-valid"
                  />
                )}
              </div>
              {accountNumberFormatInvalid && <p id="inventory-account-number-format" className="text-[11px] font-medium leading-snug text-destructive" role="alert">Use at least 4 letters or numbers. Spaces and hyphens are allowed.</p>}
              {duplicateAccountNumber && <p id="inventory-account-number-duplicate" className="text-[11px] font-medium leading-snug text-destructive" role="alert">This account number is already recorded for this estate. Enter the other account&apos;s number.</p>}
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1"><Label className="text-xs">Accrued Interest ($)</Label><Input type="text" inputMode="decimal" value={item.accruedInterest || ""} onChange={(e) => setItem({ ...item, accruedInterest: formatCurrency(e.target.value) })} placeholder="0.00" /></div>
            <div className="space-y-1">
              <Label className="text-xs">Date of Death Value ($)</Label>
              <Input type="text" inputMode="decimal" value={item.dateOfDeathValue || ""} onChange={(e) => setItem(updateInventoryValueInput(item, "dateOfDeathValue", e.target.value))} placeholder="0.00" />
              <p className="text-[10px] text-muted-foreground leading-tight">Value at date of death — include accrued interest to the date of death.</p>
            </div>
          </div>
        </div>
      )}

      {/* Real Property detail fields */}
      {isRealProperty && (
        <div className="space-y-3 border-t pt-3 mt-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Property Details</p>
          <div className="space-y-1"><Label className="text-xs">PID (Parcel Identifier)</Label><Input value={item.pid || ""} onChange={(e) => setItem({ ...item, pid: e.target.value })} placeholder="e.g. 012-345-678" /></div>
          <div className="space-y-1"><Label className="text-xs">Legal Description</Label><Textarea value={item.legalDescription || ""} onChange={(e) => setItem({ ...item, legalDescription: e.target.value })} placeholder="Lot, Plan, District Lot, etc." className="min-h-[60px]" /></div>
          <div className="space-y-1">
            <Label className="text-xs">Date-of-death FMV (appraisal or assessment)</Label>
            <Input
              type="text"
              inputMode="decimal"
              value={realPropertyFmvInput(item) || ""}
              onChange={(e) => setItem(updateRealPropertyFmvInput(item, e.target.value))}
              placeholder="Leave blank if pending"
              data-testid="inventory-real-property-fmv"
            />
            <p className="text-[10px] text-muted-foreground leading-tight" data-testid="inventory-real-property-fmv-guidance">
              Leave blank if the date-of-death fair market value is pending or unknown. You can save this property and link its mortgage now; Form P10 remains incomplete and shows no value or totals until FMV is recorded. Enter $0 only when that is the actual value.
            </p>
          </div>
          <div className="space-y-1"><Label className="text-xs">Registered in the Name of</Label><Input value={item.registeredOwner || ""} onChange={(e) => setItem({ ...item, registeredOwner: e.target.value })} placeholder="Name(s) on title" /></div>
          <div className="space-y-1">
            <Label className="text-xs">Ownership and Fractional Interest Details</Label>
            <Textarea
              value={item.ownershipDetails || ""}
              onChange={(e) => setItem({ ...item, ownershipDetails: e.target.value })}
              placeholder="List every registered owner and each owner's fractional interest, including the deceased"
              className="min-h-[70px]"
              data-testid="inventory-ownership-details"
            />
          </div>
        </div>
      )}

      {isLiability && (
        <div className="space-y-3 border-t pt-3 mt-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Debt Security Details</p>
          <div className="space-y-1">
            <div className="flex items-center justify-between gap-2">
              <Label className="text-xs">Creditor Contact</Label>
              {onCreateCreditor && <Button type="button" variant="ghost" size="sm" className="h-6 px-1.5 text-[11px]" onClick={onCreateCreditor}>Add creditor</Button>}
            </div>
            <select
              className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
              value={item.creditorContactId || ""}
              onChange={(e) => setItem({ ...item, creditorContactId: e.target.value })}
              data-testid="inventory-creditor-contact"
            >
              <option value="">Not yet linked to a creditor contact</option>
              {creditorContacts.map((creditor) => (
                <option key={creditor.id} value={creditor.id}>{creditor.name || "Unnamed creditor"}</option>
              ))}
            </select>
            <p className="text-[10px] text-muted-foreground leading-tight">Link the recorded lender or creditor. A liability alone never creates a recipient; a linked creditor with a recorded claim over $10,000 is included in the Rule 25-2 notice and P9 delivery workflow.</p>
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Security Status</Label>
            <select
              className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
              value={item.securityStatus || "unknown"}
              onChange={(e) => setItem({
                ...item,
                securityStatus: e.target.value,
                securedAssetId: e.target.value === "secured" ? (item.securedAssetId || "") : "",
              })}
              data-testid="inventory-security-status"
            >
              <option value="unknown">Not yet determined</option>
              <option value="secured">Secured debt</option>
              <option value="unsecured">Unsecured debt</option>
            </select>
          </div>
          {item.securityStatus === "secured" && (
            <div className="space-y-1">
              <Label className="text-xs">Asset Charged or Encumbered</Label>
              <select
                className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
                value={item.securedAssetId || ""}
                onChange={(e) => setItem({ ...item, securedAssetId: e.target.value })}
                data-testid="inventory-secured-asset"
              >
                <option value="">Select an asset...</option>
                {linkableAssets.map((asset) => (
                  <option key={asset.id} value={asset.id}>
                    {asset.description || "Unnamed asset"} — {asset.location === "in_bc" ? "In B.C." : asset.location === "outside_bc" ? "Outside B.C." : "Location pending"}
                  </option>
                ))}
              </select>
              {linkableAssets.length === 0 && <p className="text-[10px] text-amber-700 dark:text-amber-300">Add the charged asset before linking this secured debt.</p>}
            </div>
          )}
        </div>
      )}

      {/* Rule 25-3(9) provenance — only meaningful once an earlier affidavit of
          assets and liabilities (P10/P11) has actually been filed; on an ordinary
          pre-filing estate this control is noise. Default is unset: the P14 face
          swears Exhibit A discloses only property omitted or misstated earlier,
          so an unrecorded item is sworn on no supplemental (fails closed). */}
      {supplementalAvailable && (
        <div className="space-y-3 border-t pt-3 mt-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Supplemental disclosure (Rule 25-3(9))</p>
          <div className="space-y-1">
            <Label className="text-xs">How was this item disclosed in the earlier affidavit?</Label>
            <select
              className="w-full h-9 rounded-md border border-input bg-background px-3 text-sm"
              value={item.supplementalStatus || ""}
              onChange={(e) => setItem({ ...item, supplementalStatus: e.target.value })}
              data-testid="inventory-supplemental-status"
            >
              <option value="">Not yet recorded</option>
              <option value="original">Disclosed in the earlier affidavit</option>
              <option value="not_disclosed">Not disclosed in the earlier affidavit</option>
              <option value="inaccurately_disclosed">Disclosed inaccurately in the earlier affidavit</option>
            </select>
            <p className="text-[10px] text-muted-foreground leading-tight">
              Only items not disclosed, or disclosed inaccurately, are sworn on a supplemental (Form P14/P15). Items left unrecorded appear on no supplemental.
            </p>
          </div>
          {item.supplementalFiledDate && (
            <p className="text-[10px] text-muted-foreground leading-tight" data-testid="inventory-supplemental-filed-note">
              Disclosed by a supplemental filed {item.supplementalFiledDate} — it will not appear on any later supplemental.
            </p>
          )}
        </div>
      )}
    </div>
  );
}

export function InventoryTab({ estateId, estate }: { estateId: string; estate?: any }) {
  const { data: items, isLoading } = trpc.inventory.list.useQuery({ estateId });
  const { data: contacts = [] } = trpc.contact.list.useQuery({ estateId });
  const { data: totalsData } = trpc.inventory.totals.useQuery({ estateId });
  const utils = trpc.useUtils();
  const creditorContacts = useMemo(() => contacts.filter((contact) => isCreditorContact(contact)), [contacts]);
  // A supplemental (P14/P15/P26) is only possible once an earlier affidavit of
  // assets and liabilities has been filed — the same gate formStatus("P14"/"P15")
  // reads. A resealing estate files its affidavit of assets and liabilities FOR
  // RESEALING with the application itself (Rule 25-6(2)(g)), never a P10/P11, so
  // formStatus("P26") keys on the grant type alone and so does this unlock.
  const supplementalAvailable = Boolean(estate?.p10FiledDate || estate?.p11FiledDate || normalizeGrantType(estate?.grantType || "") === "resealing");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [quickCreditorTarget, setQuickCreditorTarget] = useState<"new" | "edit" | null>(null);
  const [quickCreditor, setQuickCreditor] = useState({ name: "", address: "", claimAmount: "" });
  const [newItem, setNewItem] = useState<any>({ category: "unknown", description: "", location: "unknown", value: "", valueRecorded: 0, passesToPersonalRepresentative: "", subcategory: "", bankAddress: "", accountHolder: "", accountNumber: "", accruedInterest: "", dateOfDeathValue: "", pid: "", legalDescription: "", assessedMarketValue: "", registeredOwner: "", ownershipDetails: "", securityStatus: "unknown", securedAssetId: "", supplementalStatus: "" });
  const [sameBankAccountContext, setSameBankAccountContext] = useState(false);
  const [sameBankAccountReview, setSameBankAccountReview] = useState<BankAccountReview[]>([]);
  const [bankAccountReviewOpen, setBankAccountReviewOpen] = useState(false);
  const openAnotherAccountAtBank = (source: any, reviewOverride?: BankAccountReview[]) => {
    const accountReview = reviewOverride || (items || [])
      .filter((item: any) => item.category === "financial" && bankAccountKey(item) === bankAccountKey(source))
      .map(bankAccountReviewFrom);
    setNewItem({
      category: "financial",
      // Only the bank-level details stay. Every account-specific fact needs to
      // be recorded separately; copying any of them risks a duplicate account.
      description: "",
      location: source.location || "unknown",
      value: "",
      valueRecorded: 0,
      passesToPersonalRepresentative: "",
      subcategory: "",
      householdFurnishings: "",
      bankAddress: source.bankAddress || "",
      accountHolder: "",
      accountNumber: "",
      accruedInterest: "",
      dateOfDeathValue: "",
      pid: "",
      legalDescription: "",
      assessedMarketValue: "",
      registeredOwner: "",
      ownershipDetails: "",
      securityStatus: "unknown",
      securedAssetId: "",
      supplementalStatus: "",
    });
    setSameBankAccountReview(accountReview);
    setBankAccountReviewOpen(false);
    setSameBankAccountContext(true);
    setDialogOpen(true);
  };
  const normalizedNewAccountNumber = normalizeAccountNumber(newItem.accountNumber);
  const hasDuplicateAccountNumber = sameBankAccountContext
    && Boolean(normalizedNewAccountNumber)
    && [...(items || []), ...sameBankAccountReview].some((account: any) => normalizeAccountNumber(account.accountNumber) === normalizedNewAccountNumber);
  const hasInvalidNewAccountNumber = sameBankAccountContext
    && Boolean(String(newItem.accountNumber || "").trim())
    && !hasValidAccountNumberFormat(newItem.accountNumber);
  const currentAccountOrdinal = sameBankAccountReview.length + 1;
  const hasPendingP10Value = (items || []).some((item: any) =>
    (item.category === "liability" || passesToPersonalRepresentative(item))
    && !isInventoryValueRecorded(item),
  );
  const invalidateInventoryDerivedState = () => {
    void utils.inventory.list.invalidate({ estateId });
    void utils.inventory.totals.invalidate({ estateId });
    void utils.distribution.compute.invalidate({ estateId });
    void utils.readiness.check.invalidate({ estateId });
    void utils.document.preflight.invalidate();
    void utils.document.preflightMany.invalidate();
  };
  const quickCreditorMutation = trpc.contact.create.useMutation({
    onSuccess: ({ id }) => {
      if (quickCreditorTarget === "new") setNewItem((current: any) => ({ ...current, creditorContactId: id }));
      if (quickCreditorTarget === "edit") setEditingItem((current: any) => current ? ({ ...current, creditorContactId: id }) : current);
      void utils.contact.list.invalidate({ estateId });
      void utils.delivery.getRecipients.invalidate({ estateId });
      void utils.document.getLetterRecipients.invalidate({ estateId });
      void utils.document.preflight.invalidate();
      void utils.document.preflightMany.invalidate();
      setQuickCreditorTarget(null);
      setQuickCreditor({ name: "", address: "", claimAmount: "" });
      toast.success("Creditor contact added and linked to this liability");
    },
    onError: (error) => toast.error(error.message || "Creditor contact could not be added"),
  });
  const openQuickCreditor = (target: "new" | "edit") => {
    setQuickCreditorTarget(target);
    const liability = target === "new" ? newItem : editingItem;
    setQuickCreditor({ name: "", address: "", claimAmount: String(liability?.value || "") });
  };

  const createMutation = trpc.inventory.create.useMutation({
    onSuccess: () => { invalidateInventoryDerivedState(); setDialogOpen(false); setSameBankAccountContext(false); setSameBankAccountReview([]); setBankAccountReviewOpen(false); setNewItem({ category: "unknown", description: "", location: "unknown", value: "", valueRecorded: 0, passesToPersonalRepresentative: "", subcategory: "", bankAddress: "", accountHolder: "", accountNumber: "", accruedInterest: "", dateOfDeathValue: "", pid: "", legalDescription: "", assessedMarketValue: "", registeredOwner: "", ownershipDetails: "", securityStatus: "unknown", securedAssetId: "", supplementalStatus: "" }); toast.success("Item added"); },

    // A rejected write must SAY so. Without this the server's validation (e.g. a
    // negative liability, whose value is the amount owed) failed silently: no
    // toast, dialog still open, the item simply never appeared.
    onError: (err) => { toast.error(err.message); },
  });
  const updateMutation = trpc.inventory.update.useMutation({
    onSuccess: () => { invalidateInventoryDerivedState(); setEditDialogOpen(false); setEditingItem(null); toast.success("Item updated"); },
    onError: (err) => { toast.error(err.message); },
  });
  const deleteMutation = trpc.inventory.delete.useMutation({
    onSuccess: invalidateInventoryDerivedState,
    onError: (err) => {
      invalidateInventoryDerivedState();
      toast.error(err.message || "Item could not be deleted");
    },
  });
  // Separate instance from updateMutation: that one's onSuccess closes the edit
  // dialog and toasts per item, which is wrong for a bulk write.
  const markSupplementalFiledMutation = trpc.inventory.update.useMutation();
  const [supplementalFiledOpen, setSupplementalFiledOpen] = useState(false);
  const [supplementalFiledDate, setSupplementalFiledDate] = useState("");
  // The set a supplemental filed *now* would disclose — the same predicate docgen
  // uses to build Exhibit A, so what you mark is exactly what was sworn.
  const pendingSupplementalItems = (items || []).filter((it: any) =>
    (it.category === "liability" || passesToPersonalRepresentative(it))
    && isSupplementalDisclosure(it));
  const reorderMutation = trpc.inventory.reorder.useMutation({
    onSuccess: () => { utils.inventory.list.invalidate({ estateId }); },
  });
  const [deleteConfirmItem, setDeleteConfirmItem] = useState<any>(null);
  const [inventorySearch, setInventorySearch] = useState("");
  const [collapsedBanks, setCollapsedBanks] = useState<Set<string>>(new Set());
  const [isPreparingInventoryTemplate, setIsPreparingInventoryTemplate] = useState(false);
  const [isReadingSpreadsheet, setIsReadingSpreadsheet] = useState(false);
  const [spreadsheetPreviewItems, setSpreadsheetPreviewItems] = useState<SpreadsheetInventoryItem[]>([]);
  const [spreadsheetPreviewFileName, setSpreadsheetPreviewFileName] = useState<string | null>(null);
  const spreadsheetInputRef = useRef<HTMLInputElement>(null);
  const spreadsheetPreviewIssues = useMemo(
    () => spreadsheetPreviewItems.map((item) => validateSpreadsheetInventoryItem(item)),
    [spreadsheetPreviewItems],
  );
  const spreadsheetInvalidRowCount = spreadsheetPreviewIssues.filter((issues) => issues.length > 0).length;
  const hasSpreadsheetPreviewIssues = spreadsheetInvalidRowCount > 0;
  const updateSpreadsheetPreviewItem = (index: number, field: SpreadsheetPreviewField, value: string) => {
    setSpreadsheetPreviewItems((previous) => previous.map((item, itemIndex) => {
      if (itemIndex !== index) return item;

      if (field === "category") {
        const category = (SPREADSHEET_PREVIEW_CATEGORIES.includes(value as (typeof SPREADSHEET_PREVIEW_CATEGORIES)[number])
          ? value
          : "unknown") as SpreadsheetInventoryItem["category"];
        return {
          ...item,
          category,
          dateOfDeathValue: category === "financial" ? item.value : item.dateOfDeathValue,
          assessedMarketValue: category === "real_property" ? item.value : item.assessedMarketValue,
        };
      }
      if (field === "location") {
        return {
          ...item,
          location: (SPREADSHEET_PREVIEW_LOCATIONS.includes(value as (typeof SPREADSHEET_PREVIEW_LOCATIONS)[number])
            ? value
            : "unknown") as SpreadsheetInventoryItem["location"],
        };
      }
      if (field === "value") {
        const valueInCents = parseCurrencyToCents(value.replace(/[$\s,]/g, ""));
        const valueRecorded = value.trim() ? 1 : 0;
        return {
          ...item,
          value: valueInCents,
          valueInput: value,
          valueRecorded,
          dateOfDeathValue: item.category === "financial" ? valueInCents : item.dateOfDeathValue,
          assessedMarketValue: item.category === "real_property" ? valueInCents : item.assessedMarketValue,
        };
      }

      return { ...item, [field]: value };
    }));
  };
  const toggleBankCollapse = (bankName: string) => setCollapsedBanks(prev => { const next = new Set(prev); if (next.has(bankName)) next.delete(bankName); else next.add(bankName); return next; });
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }), useSensor(KeyboardSensor));
  const bulkCreateMutation = trpc.inventory.bulkCreate.useMutation({
    onSuccess: (data) => {
      invalidateInventoryDerivedState();
      setSpreadsheetPreviewItems([]);
      setSpreadsheetPreviewFileName(null);
      toast.success(`Imported ${data.count} items`);
    },
    onError: (err) => { toast.error(`Import failed: ${err.message}`); },
  });

  const clearSpreadsheetSelection = () => {
    setSpreadsheetPreviewItems([]);
    setSpreadsheetPreviewFileName(null);
    if (spreadsheetInputRef.current) spreadsheetInputRef.current.value = "";
  };

  const discardSpreadsheetPreview = () => {
    clearSpreadsheetSelection();
    toast.info("Import preview discarded. Nothing was added to the inventory.");
  };

  const stageSpreadsheetFile = async (file: File) => {
    const isExcelWorkbook = file.name.toLowerCase().endsWith(".xlsx") || file.type === XLSX_MIME_TYPE;
    if (!isExcelWorkbook) {
      toast.error("Choose an Excel (.xlsx) workbook");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast.error("The Excel workbook must be 10 MB or smaller");
      return;
    }

    setIsReadingSpreadsheet(true);
    try {
      const rows = await readFirstXlsxWorksheetRows(file);
      const importedItems = inventorySpreadsheetRowsToItems(rows);
      if (importedItems.length === 0) {
        toast.error("No inventory rows were found in the Excel workbook");
        return;
      }
      if (importedItems.length > 1_000) {
        toast.error("Import up to 1,000 inventory rows at a time");
        return;
      }
      setSpreadsheetPreviewItems(importedItems);
      setSpreadsheetPreviewFileName(file.name);
    } catch {
      toast.error("The Excel workbook could not be read. Start from the Excel template and try again.");
    } finally {
      setIsReadingSpreadsheet(false);
      // Allow a corrected version of the same workbook to be selected again.
      if (spreadsheetInputRef.current) spreadsheetInputRef.current.value = "";
    }
  };

  const handleSpreadsheetImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) void stageSpreadsheetFile(file);
  };

  const confirmSpreadsheetImport = () => {
    if (spreadsheetPreviewItems.length === 0 || bulkCreateMutation.isPending || hasSpreadsheetPreviewIssues) return;
    bulkCreateMutation.mutate({
      estateId,
      items: spreadsheetPreviewItems.map(({ valueInput: _valueInput, ...item }) => item),
    });
  };

  const downloadInventoryTemplate = async () => {
    setIsPreparingInventoryTemplate(true);
    try {
      const blob = await createInventorySpreadsheetTemplate();
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = "inventory_template.xlsx";
      anchor.click();
      URL.revokeObjectURL(url);
    } catch {
      toast.error("The Excel template could not be created. Please try again.");
    } finally {
      setIsPreparingInventoryTemplate(false);
    }
  };

  const pendingItemDeleteRef = useRef<{ id: string; timer: ReturnType<typeof setTimeout> } | null>(null);

  const handleDeleteItem = (item: any) => {
    setDeleteConfirmItem(item);
  };

  const handleDeleteFromEdit = () => {
    if (!editingItem) return;
    const item = editingItem;
    setEditDialogOpen(false);
    setEditingItem(null);
    handleDeleteItem(item);
  };

  const confirmDelete = () => {
    if (!deleteConfirmItem) return;
    const item = deleteConfirmItem;
    setDeleteConfirmItem(null);
    if (pendingItemDeleteRef.current) clearTimeout(pendingItemDeleteRef.current.timer);

    // Optimistically remove from UI
    utils.inventory.list.setData({ estateId }, (old) => (old || []).filter((i) => i.id !== item.id));

    const timer = setTimeout(() => {
      deleteMutation.mutate({ id: item.id, estateId });
      pendingItemDeleteRef.current = null;
    }, 5000);
    pendingItemDeleteRef.current = { id: item.id, timer };

    toast("Inventory item removed", {
      description: "Undo is available for five seconds.",
      classNames: {
        toast: "rounded-2xl border border-border/80 bg-popover text-popover-foreground shadow-[0_18px_42px_-24px_rgba(15,23,42,0.44)] dark:shadow-[0_18px_42px_-24px_rgba(0,0,0,0.72)]",
        title: "font-semibold tracking-[-0.01em]",
        description: "text-muted-foreground",
        actionButton: "rounded-lg bg-primary px-3 font-semibold text-primary-foreground shadow-sm transition-colors hover:bg-primary/90",
      },
      action: {
        label: "Undo",
        onClick: () => {
          if (pendingItemDeleteRef.current && pendingItemDeleteRef.current.id === item.id) {
            clearTimeout(pendingItemDeleteRef.current.timer);
            pendingItemDeleteRef.current = null;
          }
          utils.inventory.list.invalidate({ estateId });
          utils.inventory.totals.invalidate({ estateId });
        },
      },
      duration: 5000,
    });
  };

  // InventoryFormFields moved outside to prevent re-mount

  return (
    <div className="space-y-4 pt-4">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <h3 className="font-medium text-sm">Assets & Liabilities</h3>
        <div className="flex items-center gap-2 flex-wrap">
          <Button
            size="sm"
            variant="ghost"
            className="text-xs text-muted-foreground h-7 px-2"
            onClick={downloadInventoryTemplate}
            disabled={isPreparingInventoryTemplate}
            aria-busy={isPreparingInventoryTemplate}
          >
            {isPreparingInventoryTemplate ? <Loader2 className="mr-1 h-3 w-3 animate-spin" aria-hidden="true" /> : <FileDown className="mr-1 h-3 w-3" />}
            {isPreparingInventoryTemplate ? "Preparing..." : "Excel template"}
          </Button>
          <input
            ref={spreadsheetInputRef}
            type="file"
            accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            className="hidden"
            onChange={handleSpreadsheetImport}
            disabled={bulkCreateMutation.isPending}
            aria-label="Import Excel inventory workbook"
          />
          <Button size="sm" variant="outline" onClick={() => spreadsheetInputRef.current?.click()} disabled={bulkCreateMutation.isPending}>
            <Upload className="h-3 w-3 mr-1" />{bulkCreateMutation.isPending ? "Importing..." : "Import Excel"}
          </Button>
        <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) { setSameBankAccountContext(false); setSameBankAccountReview([]); setBankAccountReviewOpen(false); } }}>
          <DialogTrigger asChild><Button size="sm" onClick={() => { setSameBankAccountContext(false); setSameBankAccountReview([]); setBankAccountReviewOpen(false); }}><Plus className="h-3 w-3 mr-1" /> Add Item</Button></DialogTrigger>
          <DialogContent className={sameBankAccountContext ? "sm:max-w-4xl rounded-2xl border-border/80 shadow-[0_24px_70px_-28px_rgba(15,23,42,0.46)] dark:shadow-[0_24px_70px_-28px_rgba(0,0,0,0.72)]" : undefined} aria-describedby={undefined}>
            <DialogHeader className={sameBankAccountContext ? "border-b border-border/70 pb-3" : undefined}>
              <DialogTitle>{sameBankAccountContext ? `Add Account ${currentAccountOrdinal}` : "Add Inventory Item"}</DialogTitle>
              <DialogDescription className={sameBankAccountContext ? "text-xs leading-relaxed" : "sr-only"}>
                {sameBankAccountContext ? "Enter the details for this distinct account. Account type, number, holder and value are specific to this account." : "Record a new asset or liability for this estate"}
              </DialogDescription>
            </DialogHeader>
            <InventoryFormFields item={newItem} setItem={setNewItem} allItems={items || []} creditorContacts={creditorContacts} onCreateCreditor={() => openQuickCreditor("new")} supplementalAvailable={supplementalAvailable} isAdditionalBankAccount={sameBankAccountContext} accountOrdinal={sameBankAccountContext ? currentAccountOrdinal : undefined} duplicateAccountNumber={hasDuplicateAccountNumber} />
            {(() => {
              const payload = () => ({
                estateId, category: newItem.category, description: newItem.description, location: newItem.location,
                value: parseCurrencyToCents(newItem.value || "0"),
                valueRecorded: inventoryValueRecordedFromForm(newItem),
                passesToPersonalRepresentative: newItem.category === "liability" ? "" : (newItem.passesToPersonalRepresentative || ""),
                subcategory: newItem.subcategory || "",
                householdFurnishings: newItem.householdFurnishings || "",
                bankAddress: newItem.bankAddress || "",
                accountHolder: newItem.accountHolder || "",
                accountNumber: newItem.accountNumber || "",
                accruedInterest: parseCurrencyToCents(newItem.accruedInterest || "0"),
                dateOfDeathValue: parseCurrencyToCents(String(newItem.category === "financial" ? inventoryEffectiveValueInput(newItem) || "0" : newItem.dateOfDeathValue || "0")),
                pid: newItem.pid || "",
                legalDescription: newItem.legalDescription || "",
                assessedMarketValue: parseCurrencyToCents(String(newItem.category === "real_property" ? inventoryEffectiveValueInput(newItem) || "0" : newItem.assessedMarketValue || "0")),
                registeredOwner: newItem.registeredOwner || "",
                ownershipDetails: newItem.ownershipDetails || "",
                securityStatus: newItem.securityStatus || "unknown",
                securedAssetId: newItem.securedAssetId || "",
                creditorContactId: newItem.category === "liability" ? newItem.creditorContactId || "" : "",
                // This payload is an explicit whitelist — omitting a field here
                // silently drops it on save regardless of what the form shows.
                supplementalStatus: newItem.supplementalStatus || "",
              });
              return (
                <div className="space-y-2">
                  {sameBankAccountContext && sameBankAccountReview.length > 0 && (
                    <Collapsible open={bankAccountReviewOpen} onOpenChange={setBankAccountReviewOpen}>
                      <div className="rounded-lg border border-border/70 bg-muted/[0.22] px-3 py-2.5" data-testid="inventory-bank-account-review" aria-live="polite">
                        <CollapsibleTrigger className="group flex w-full items-center justify-between gap-3 text-left outline-none">
                          <span className="flex min-w-0 items-center gap-2">
                            <span className="text-xs font-semibold text-foreground">Review saved accounts</span>
                            <span className="rounded-md bg-background px-1.5 py-0.5 text-[10px] font-semibold tabular-nums text-muted-foreground">{sameBankAccountReview.length}</span>
                          </span>
                          <span className="flex items-center gap-1 text-[11px] font-medium text-muted-foreground transition-colors group-hover:text-foreground group-focus-visible:text-foreground">
                            {bankAccountReviewOpen ? "Hide" : "View"}
                            <ChevronDown className="h-3.5 w-3.5 transition-transform duration-200 group-data-[state=open]:rotate-180" />
                          </span>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="bank-account-review-content overflow-hidden">
                          <ol className="mt-2.5 grid max-h-36 grid-cols-1 gap-1.5 overflow-y-auto pr-1 sm:grid-cols-2">
                            {sameBankAccountReview.map((account, index) => (
                              <li key={`${account.id || account.accountNumber || "account"}-${index}`} className="flex min-w-0 items-center gap-2 rounded-md border border-border/60 bg-background/75 px-2.5 py-2">
                                <span className="inline-flex h-5 min-w-5 shrink-0 items-center justify-center rounded-md bg-muted px-1 text-[10px] font-semibold tabular-nums text-muted-foreground">{index + 1}</span>
                                <span className="min-w-0 truncate text-[11px] font-medium text-foreground">{accountReviewDetail(account)}</span>
                              </li>
                            ))}
                          </ol>
                        </CollapsibleContent>
                      </div>
                    </Collapsible>
                  )}
                  <Button className="w-full" onClick={() => createMutation.mutate(payload())} disabled={createMutation.isPending || hasDuplicateAccountNumber || hasInvalidNewAccountNumber} aria-busy={createMutation.isPending}>
                    {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />}
                    {createMutation.isPending ? "Adding account…" : "Add Item"}
                  </Button>
                  {/* Save one account, then collect a distinct account at the same bank.
                      Only location and branch address carry over; the identity and values
                      of the new account must be entered separately. */}
                  {newItem.category === "financial" && (
                    <Button variant="outline" className="w-full" disabled={createMutation.isPending || hasDuplicateAccountNumber || hasInvalidNewAccountNumber} aria-busy={createMutation.isPending} onClick={() => {
                      createMutation.mutate(payload(), { onSuccess: () => {
                        openAnotherAccountAtBank(newItem, [...sameBankAccountReview, bankAccountReviewFrom(newItem)]);
                      } });
                    }}>
                      {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />}
                      {sameBankAccountContext ? (createMutation.isPending ? `Saving Account ${currentAccountOrdinal}…` : `Save Account ${currentAccountOrdinal} & add Account ${currentAccountOrdinal + 1}`) : (createMutation.isPending ? "Saving account…" : "+ Save & add a distinct account at this bank")}
                    </Button>
                  )}
                </div>
              );
            })()}
          </DialogContent>
        </Dialog>
        </div>
      </div>

      <FileDropZone
        onFileDrop={(file) => void stageSpreadsheetFile(file)}
        disabled={isReadingSpreadsheet || bulkCreateMutation.isPending}
        label="Release to review the Excel workbook"
        className="rounded-xl"
        activeClassName="border-primary bg-primary/[0.06] shadow-[0_14px_30px_-22px_hsl(var(--primary)/0.7)]"
      >
        <div className="rounded-xl border border-dashed border-border/80 bg-card/50 p-1.5">
          <button
            type="button"
            className="group flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left transition-[background-color,box-shadow,transform] duration-200 hover:bg-primary/[0.025] hover:shadow-sm focus-visible:bg-primary/[0.025] focus-visible:ring-2 focus-visible:ring-primary/30 focus-visible:outline-none active:scale-[0.995] disabled:pointer-events-none disabled:opacity-60 motion-reduce:transition-none"
            onClick={() => spreadsheetInputRef.current?.click()}
            disabled={isReadingSpreadsheet || bulkCreateMutation.isPending}
            aria-describedby="inventory-excel-import-help"
            data-testid="inventory-excel-drop-zone"
          >
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-border/70 bg-background shadow-sm transition-colors group-hover:border-primary/35 group-hover:bg-primary/5">
              {isReadingSpreadsheet ? <Loader2 className="h-4 w-4 animate-spin text-primary" aria-hidden="true" /> : <Upload className="h-4 w-4 text-muted-foreground transition-colors group-hover:text-primary" aria-hidden="true" />}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-semibold text-foreground">
                {isReadingSpreadsheet ? "Reading Excel workbook…" : spreadsheetPreviewItems.length > 0 ? "Replace workbook for review" : "Drop an Excel workbook here"}
              </span>
              <span id="inventory-excel-import-help" className="mt-0.5 block text-xs leading-relaxed text-muted-foreground">
                {isReadingSpreadsheet ? "Preparing a safe preview of the first worksheet." : "Or browse for an .xlsx file. Review the rows before anything is added to this estate."}
              </span>
            </span>
            <span className="hidden shrink-0 rounded-md border border-border/70 bg-background px-2.5 py-1 text-xs font-medium text-muted-foreground sm:inline-flex">
              Browse
            </span>
          </button>
          <div className="ml-[54px] flex items-center gap-1.5 pb-1 pt-0.5 text-xs text-muted-foreground">
            <FileDown className="h-3.5 w-3.5" aria-hidden="true" />
            <button
              type="button"
              className="font-medium text-primary underline-offset-4 transition-colors hover:text-primary/80 hover:underline focus-visible:rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30"
              onClick={() => void downloadInventoryTemplate()}
              disabled={isPreparingInventoryTemplate}
            >
              {isPreparingInventoryTemplate ? "Preparing template…" : "Download template"}
            </button>
            <span>to match the required columns.</span>
          </div>
        </div>
      </FileDropZone>

      {isReadingSpreadsheet && (
        <div className="flex items-center gap-2 px-1 text-xs text-muted-foreground" role="status" aria-live="polite" data-testid="inventory-excel-reading-status">
          <Loader2 className="h-3.5 w-3.5 animate-spin text-primary" aria-hidden="true" />
          Reading workbook and checking rows…
        </div>
      )}

      {spreadsheetPreviewItems.length > 0 && (
        <Card className="overflow-hidden border-border/80 shadow-[0_16px_32px_-28px_rgba(15,23,42,0.62)]" data-testid="inventory-excel-preview">
          <CardHeader className="gap-2 border-b border-border/70 bg-muted/[0.16] px-4 py-3 sm:flex-row sm:items-start sm:justify-between">
            <div className="min-w-0 space-y-0.5">
              <CardTitle className="text-sm">Review import</CardTitle>
              <CardDescription className="truncate text-xs">
                {spreadsheetPreviewFileName} · {spreadsheetPreviewItems.length} row{spreadsheetPreviewItems.length === 1 ? "" : "s"} ready to import
              </CardDescription>
            </div>
            <Badge variant="secondary" className="w-fit shrink-0 rounded-md font-medium tabular-nums">
              {spreadsheetPreviewItems.length} item{spreadsheetPreviewItems.length === 1 ? "" : "s"}
            </Badge>
          </CardHeader>
          <CardContent className="space-y-3 px-4 py-3">
            <p className="text-xs leading-relaxed text-muted-foreground">
              Edit any cell below before importing. Nothing has been added yet; use <span className="font-medium text-foreground">Import {spreadsheetPreviewItems.length} item{spreadsheetPreviewItems.length === 1 ? "" : "s"}</span> only when the details are correct.
            </p>
            {hasSpreadsheetPreviewIssues && (
              <div className="flex items-start gap-2 rounded-lg border border-destructive/35 bg-destructive/[0.055] px-3 py-2 text-xs leading-relaxed text-destructive" role="alert" data-testid="inventory-excel-preview-errors">
                <CircleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                <span><span className="font-semibold">{spreadsheetInvalidRowCount} row{spreadsheetInvalidRowCount === 1 ? " needs" : "s need"} attention.</span> Rows marked in red have missing or malformed basics. Correct them before importing.</span>
              </div>
            )}
            <div className="max-w-full overflow-x-auto rounded-lg border border-border/70">
              <Table className="min-w-[890px] text-xs">
                <TableHeader className="sticky top-0 z-10 bg-muted/85 backdrop-blur-sm">
                  <TableRow>
                    <TableHead className="h-8 w-10 px-3 text-[10px] font-semibold uppercase tracking-[0.08em]">#</TableHead>
                    <TableHead className="h-8 px-3 text-[10px] font-semibold uppercase tracking-[0.08em]">Type</TableHead>
                    <TableHead className="h-8 px-3 text-[10px] font-semibold uppercase tracking-[0.08em]">Description</TableHead>
                    <TableHead className="h-8 px-3 text-[10px] font-semibold uppercase tracking-[0.08em]">Location</TableHead>
                    <TableHead className="h-8 px-3 text-right text-[10px] font-semibold uppercase tracking-[0.08em]">Value</TableHead>
                    <TableHead className="h-8 px-3 text-[10px] font-semibold uppercase tracking-[0.08em]">Account</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {spreadsheetPreviewItems.map((item, index) => {
                    const issues = spreadsheetPreviewIssues[index];
                    const issueByField = new Map(issues.map((issue) => [issue.field, issue.message]));
                    const rowIsInvalid = issues.length > 0;
                    return (
                      <TableRow
                        key={`${item.category}-${item.description}-${item.accountNumber}-${index}`}
                        className={cn(rowIsInvalid && "bg-destructive/[0.055] hover:bg-destructive/[0.08]")}
                        data-invalid={rowIsInvalid ? "true" : undefined}
                      >
                        <TableCell className="px-3 py-2 font-medium tabular-nums text-muted-foreground">{index + 1}</TableCell>
                        <TableCell className="px-2 py-1.5">
                          <select
                            aria-label={`Row ${index + 1} type`}
                            value={item.category}
                            onChange={(event) => updateSpreadsheetPreviewItem(index, "category", event.target.value)}
                            aria-invalid={Boolean(issueByField.get("category"))}
                            title={issueByField.get("category")}
                            className={cn("h-8 min-w-[7.75rem] rounded-md border border-input bg-background px-2 text-xs capitalize outline-none transition-colors focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/25", issueByField.get("category") && "border-destructive text-destructive")}
                          >
                            <option value="unknown">{previewCategoryLabel("unknown")}</option>
                            {SPREADSHEET_PREVIEW_CATEGORIES.map((category) => <option key={category} value={category}>{previewCategoryLabel(category)}</option>)}
                          </select>
                        </TableCell>
                        <TableCell className="px-2 py-1.5">
                          <Input
                            aria-label={`Row ${index + 1} description`}
                            value={item.description}
                            onChange={(event) => updateSpreadsheetPreviewItem(index, "description", event.target.value)}
                            aria-invalid={Boolean(issueByField.get("description"))}
                            className={cn("h-8 min-w-[13.5rem] text-xs", issueByField.get("description") && "border-destructive focus-visible:ring-destructive/25")}
                          />
                        </TableCell>
                        <TableCell className="px-2 py-1.5">
                          <select
                            aria-label={`Row ${index + 1} location`}
                            value={item.location}
                            onChange={(event) => updateSpreadsheetPreviewItem(index, "location", event.target.value)}
                            aria-invalid={Boolean(issueByField.get("location"))}
                            title={issueByField.get("location")}
                            className={cn("h-8 min-w-[7.5rem] rounded-md border border-input bg-background px-2 text-xs outline-none transition-colors focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/25", issueByField.get("location") && "border-destructive text-destructive")}
                          >
                            <option value="unknown">{previewLocationLabel("unknown")}</option>
                            {SPREADSHEET_PREVIEW_LOCATIONS.map((location) => <option key={location} value={location}>{previewLocationLabel(location)}</option>)}
                          </select>
                        </TableCell>
                        <TableCell className="px-2 py-1.5">
                          <Input
                            aria-label={`Row ${index + 1} value`}
                            inputMode="decimal"
                            value={item.valueInput}
                            onChange={(event) => updateSpreadsheetPreviewItem(index, "value", event.target.value)}
                            aria-invalid={Boolean(issueByField.get("value"))}
                            placeholder="Pending"
                            className={cn("h-8 min-w-[6.5rem] text-right font-mono text-xs tabular-nums", issueByField.get("value") && "border-destructive focus-visible:ring-destructive/25")}
                          />
                        </TableCell>
                        <TableCell className="px-2 py-1.5">
                          <Input
                            aria-label={`Row ${index + 1} account number`}
                            value={item.accountNumber}
                            onChange={(event) => updateSpreadsheetPreviewItem(index, "accountNumber", event.target.value)}
                            aria-invalid={Boolean(issueByField.get("accountNumber"))}
                            placeholder="Optional"
                            className={cn("h-8 min-w-[8.5rem] font-mono text-xs", issueByField.get("accountNumber") && "border-destructive focus-visible:ring-destructive/25")}
                          />
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
            <div className="flex flex-col-reverse gap-2 border-t border-border/70 pt-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-wrap items-center gap-1">
                <Button type="button" variant="ghost" size="sm" onClick={clearSpreadsheetSelection} disabled={bulkCreateMutation.isPending}>
                  Choose another workbook
                </Button>
                <Button type="button" variant="ghost" size="sm" className="text-muted-foreground hover:bg-destructive/[0.06] hover:text-destructive" onClick={discardSpreadsheetPreview} disabled={bulkCreateMutation.isPending}>
                  <Trash2 className="mr-1.5 h-3.5 w-3.5" aria-hidden="true" />
                  Discard import
                </Button>
              </div>
              <Button type="button" size="sm" onClick={confirmSpreadsheetImport} disabled={bulkCreateMutation.isPending || hasSpreadsheetPreviewIssues} aria-busy={bulkCreateMutation.isPending} aria-describedby={hasSpreadsheetPreviewIssues ? "inventory-excel-preview-errors" : undefined}>
                {bulkCreateMutation.isPending && <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" aria-hidden="true" />}
                {bulkCreateMutation.isPending ? "Importing…" : `Import ${spreadsheetPreviewItems.length} item${spreadsheetPreviewItems.length === 1 ? "" : "s"}`}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Lineage (P14/P15 face ¶4): once the supplemental disclosing these items
          is filed they ARE disclosed, so they must drop off every later
          supplemental. Recorded as one action because one P14 is filed on one
          date covering all of them — per-item entry invites a missed item, which
          would re-swear it was never disclosed. */}
      {supplementalAvailable && pendingSupplementalItems.length > 0 && (
        <div className="flex items-center justify-between gap-3 rounded-md border border-input bg-muted/40 px-3 py-2">
          <p className="text-[11px] text-muted-foreground leading-tight">
            <span className="font-medium text-foreground">{pendingSupplementalItems.length} item{pendingSupplementalItems.length === 1 ? "" : "s"}</span> will be sworn on the next supplemental (Form P14/P15). Record the filing date once it is filed so they drop off later supplementals.
          </p>
          <Dialog open={supplementalFiledOpen} onOpenChange={setSupplementalFiledOpen}>
            <DialogTrigger asChild>
              <Button size="sm" variant="outline" className="shrink-0 text-xs" data-testid="mark-supplemental-filed">Mark supplemental as filed</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Mark supplemental as filed</DialogTitle>
                <DialogDescription className="text-xs">
                  Records the filing date on the {pendingSupplementalItems.length} item{pendingSupplementalItems.length === 1 ? "" : "s"} this supplemental discloses. They stay in the inventory but will not be sworn on any later supplemental.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-1">
                <Label className="text-xs" htmlFor="supplemental-filed-date">Date the supplemental was filed</Label>
                <Input
                  id="supplemental-filed-date"
                  type="date"
                  value={supplementalFiledDate}
                  onChange={(e) => setSupplementalFiledDate(e.target.value)}
                  data-testid="supplemental-filed-date"
                />
              </div>
              <Button
                className="w-full"
                disabled={!supplementalFiledDate || markSupplementalFiledMutation.isPending}
                onClick={async () => {
                  await Promise.all(pendingSupplementalItems.map((it: any) =>
                    markSupplementalFiledMutation.mutateAsync({ id: it.id, estateId, data: { supplementalFiledDate } })
                  ));
                  invalidateInventoryDerivedState();
                  setSupplementalFiledOpen(false);
                  setSupplementalFiledDate("");
                  toast.success(`Marked ${pendingSupplementalItems.length} item(s) as disclosed by the supplemental`);
                }}
              >
                {markSupplementalFiledMutation.isPending ? "Recording..." : "Record filing date"}
              </Button>
            </DialogContent>
          </Dialog>
        </div>
      )}

      {/* P2-2: Edit dialog for inventory */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Edit Inventory Item</DialogTitle><DialogDescription className="sr-only">Edit this asset or liability's details and values</DialogDescription></DialogHeader>
          {editingItem && (
            <>
              <InventoryFormFields item={editingItem} setItem={setEditingItem} allItems={items || []} creditorContacts={creditorContacts} onCreateCreditor={() => openQuickCreditor("edit")} supplementalAvailable={supplementalAvailable} />
              <Button className="w-full" onClick={() => {
                const { id, estateId: _eid, ...data } = editingItem;
                updateMutation.mutate({ id, estateId, data: {
                  ...data,
                  value: parseCurrencyToCents(data.value || "0"),
                  valueRecorded: inventoryValueRecordedFromForm(data),
                  accruedInterest: parseCurrencyToCents(data.accruedInterest || "0"),
                  dateOfDeathValue: parseCurrencyToCents(String(data.category === "financial" ? inventoryEffectiveValueInput(data) || "0" : data.dateOfDeathValue || "0")),
                  assessedMarketValue: parseCurrencyToCents(String(data.category === "real_property" ? inventoryEffectiveValueInput(data) || "0" : data.assessedMarketValue || "0")),
                } });
              }} disabled={updateMutation.isPending}>
                {updateMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
              <Button
                type="button"
                variant="ghost"
                className="w-full text-destructive hover:bg-destructive/10 hover:text-destructive"
                onClick={handleDeleteFromEdit}
                disabled={updateMutation.isPending}
              >
                <Trash2 className="mr-2 h-3.5 w-3.5" />
                {editingItem.category === "financial" ? "Delete account" : "Delete item"}
              </Button>
            </>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={quickCreditorTarget !== null} onOpenChange={(open) => { if (!open) setQuickCreditorTarget(null); }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Add creditor contact</DialogTitle>
            <DialogDescription className="text-xs leading-relaxed">Record the lender or creditor once, then link it to this liability. The Inventory description is not used as a recipient name.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1">
              <Label className="text-xs" htmlFor="quick-creditor-name">Legal name</Label>
              <Input id="quick-creditor-name" value={quickCreditor.name} onChange={(event) => setQuickCreditor((current) => ({ ...current, name: event.target.value }))} placeholder="e.g. TD Bank" autoFocus />
            </div>
            <div className="space-y-1">
              <Label className="text-xs" htmlFor="quick-creditor-address">Mailing address</Label>
              <Textarea id="quick-creditor-address" value={quickCreditor.address} onChange={(event) => setQuickCreditor((current) => ({ ...current, address: event.target.value }))} placeholder="Address for the notice, if known" className="min-h-[72px]" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs" htmlFor="quick-creditor-claim">Claim amount (dollars)</Label>
              <Input id="quick-creditor-claim" inputMode="decimal" value={quickCreditor.claimAmount} onChange={(event) => setQuickCreditor((current) => ({ ...current, claimAmount: formatCurrency(event.target.value) }))} placeholder="Confirm the amount owed" />
              <p className="text-[10px] leading-tight text-muted-foreground">A recorded creditor claim over $10,000 is included in the Rule 25-2 notice and P9 delivery workflow. Confirm the amount before saving.</p>
            </div>
          </div>
          <Button
            className="w-full"
            disabled={!quickCreditor.name.trim() || quickCreditorMutation.isPending}
            onClick={() => quickCreditorMutation.mutate({
              estateId,
              role: "creditor",
              recipientType: "creditor",
              name: quickCreditor.name.trim(),
              address: quickCreditor.address.trim(),
              claimAmountCents: parseCurrencyToCents(quickCreditor.claimAmount || "0"),
            })}
          >
            {quickCreditorMutation.isPending ? "Adding creditor..." : "Add and link creditor"}
          </Button>
        </DialogContent>
      </Dialog>

      {totalsData && (
        <>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <Card className="border"><CardContent className="py-3 px-4"><p className="text-xs text-muted-foreground">Gross Assets</p><p className="font-semibold text-sm">{hasPendingP10Value ? "Pending" : formatMoney(totalsData.grossAssetsCents)}</p></CardContent></Card>
          <Card className="border"><CardContent className="py-3 px-4"><p className="text-xs text-muted-foreground">Liabilities</p><p className="font-semibold text-sm">{formatMoney(totalsData.liabilitiesCents)}</p></CardContent></Card>
          <Card className="border"><CardContent className="py-3 px-4"><p className="text-xs text-muted-foreground">Net Estate</p><p className="text-[9px] text-muted-foreground">(Gross − Liabilities)</p><p className="font-semibold text-sm">{hasPendingP10Value ? "Pending" : formatMoney(totalsData.netCents)}</p></CardContent></Card>
          <Card className="border"><CardContent className="py-3 px-4"><p className="text-xs text-muted-foreground">Fee Basis</p><p className="text-[9px] text-muted-foreground">(PFA s.1 value)</p><p className="font-semibold text-sm" data-testid="probate-fee-basis-value">{hasPendingP10Value ? "Pending" : totalsData.fee ? formatMoney(totalsData.fee.grossCents) : "Pending"}</p></CardContent></Card>
          <Card className="border"><CardContent className="py-3 px-4"><p className="text-xs text-muted-foreground">Probate Fee</p><p className="font-semibold text-sm" data-testid="probate-fee-value">{hasPendingP10Value ? "Pending" : totalsData.fee ? (totalsData.fee.exempt ? "Exempt" : formatMoney(totalsData.fee.totalCents)) : "Pending"}</p></CardContent></Card>
        </div>
        {totalsData.fee ? (
          <p className="text-[10px] text-muted-foreground italic">
            {totalsData.fee.exempt
              ? "Estates valued at $25,000 or less are exempt from probate fees (BC Probate Fee Act s. 2(2)(b)). The separate $200 court filing fee is not a Probate Fee Act charge; this estimate omits it here — confirm it with the registry."
              : `Fee basis = real and tangible personal property in British Columbia${totalsData.ordinarilyResidentInBc ? " + intangible personal property wherever situated" : " only — intangible property is excluded because the deceased was not ordinarily resident in BC immediately before death"} (Probate Fee Act s. 1). Probate fee: first $25K exempt, $6 per $1,000 on $25K–$50K, $14 per $1,000 on amount over $50K. Filing fee: $200.`}
          </p>
        ) : (
          <p
            className="text-[10px] text-amber-700 dark:text-amber-300 italic"
            data-testid={totalsData.feeBasisStatus === "inventory_passing_status_required" ? "inventory-passing-status-required" : "probate-fee-residence-required"}
          >
            {totalsData.feeBasisStatus === "inventory_passing_status_required"
              ? `Fee basis and probate fee are pending. Record whether each of the ${totalsData.passingStatusPendingCount} unanswered asset${totalsData.passingStatusPendingCount === 1 ? "" : "s"} passes to the personal representative; unanswered property is excluded rather than guessed.`
              : "Fee basis and probate fee are pending. Record whether the deceased was ordinarily resident in British Columbia immediately before death in Intake; Probate Fee Act s. 1 uses that fact to determine whether intangible property is included at all."}
          </p>
        )}
        </>
      )}

      {/* Search input for inventory */}
      {!isLoading && items && items.length > 0 && (
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            placeholder="Filter by institution, account, or description..."
            value={inventorySearch}
            onChange={(e) => setInventorySearch(e.target.value)}
            className="pl-8 h-8 text-xs"
          />
          {inventorySearch && (
            <Button variant="ghost" size="sm" className="absolute right-1 top-1/2 -translate-y-1/2 h-6 w-6 p-0" onClick={() => setInventorySearch("")}>
              <X className="h-3 w-3" />
            </Button>
          )}
        </div>
      )}

      {isLoading ? <div className="h-20 bg-muted animate-pulse rounded-lg" /> : (
        <div className="space-y-2">
          {(() => {
            const searchLower = inventorySearch.toLowerCase().trim();
            const allItems = (items || []).filter(it => {
              if (!searchLower) return true;
              return (
                (it.description || "").toLowerCase().includes(searchLower) ||
                (it.accountNumber || "").toLowerCase().includes(searchLower) ||
                (it.accountHolder || "").toLowerCase().includes(searchLower) ||
                (it.bankAddress || "").toLowerCase().includes(searchLower) ||
                (it.subcategory || "").toLowerCase().includes(searchLower)
              );
            });
            // Group financial items by the same stable bank key used by the
            // "add another account" flow. A separate account intentionally
            // begins with a blank description, so grouping by description would
            // incorrectly strand it under "Unknown Institution".
            const financialItems = allItems.filter(it => it.category === "financial");
            const nonFinancialItems = allItems.filter(it => it.category !== "financial");
            const bankGroups = new Map<string, typeof financialItems>();
            for (const it of financialItems) {
              const key = bankAccountKey(it);
              if (!bankGroups.has(key)) bankGroups.set(key, []);
              bankGroups.get(key)!.push(it);
            }

            const renderItemCard = (it: any, showAddAccount: boolean, isDraggable: boolean, accountOrdinal?: number) => {
              const cardContent = (
              <Card className="border">
                <CardContent className="py-3 px-3">
                  <div className="flex items-center gap-2">
                    {isDraggable && <GripVertical className="h-3.5 w-3.5 text-muted-foreground shrink-0 cursor-grab active:cursor-grabbing" />}
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{it.category === "financial" ? financialAccountLabel(it, accountOrdinal) : it.description || "No description"}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-xs text-muted-foreground">{it.category === "unknown" ? "category pending" : it.category.replace(/_/g, " ")}{it.subcategory ? ` (${it.subcategory.toUpperCase()})` : ""} · {it.location === "in_bc" ? "In BC" : it.location === "outside_bc" ? "Outside BC" : "location pending"}</span>
                        <span className="font-mono text-xs font-semibold ml-auto">{isInventoryValueRecorded(it) ? formatMoney(probateItemValue(it)) : ""}</span>
                      </div>
                      {it.category !== "liability" && (
                        <p className={`text-[10px] mt-0.5 ${it.passesToPersonalRepresentative === "yes" ? "text-muted-foreground" : it.passesToPersonalRepresentative === "no" ? "text-sky-700 dark:text-sky-300" : "text-amber-700 dark:text-amber-300"}`}>
                          {it.passesToPersonalRepresentative === "yes" ? "Passes to personal representative" : it.passesToPersonalRepresentative === "no" ? "Does not pass to personal representative — excluded from estate forms and totals" : "Pass-to-personal-representative answer required"}
                        </p>
                      )}
                      {it.category === "real_property" && !isInventoryValueRecorded(it) && (
                        <p className="text-[10px] mt-0.5 text-amber-700 dark:text-amber-300" data-testid={`inventory-pending-fmv-${it.id}`}>
                          FMV pending — property is saved, but P10 remains incomplete until its date-of-death FMV is recorded.
                        </p>
                      )}
                    </div>
                    <div className="flex items-center shrink-0">
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0" aria-label="Edit inventory item" onClick={() => { setEditingItem(hydrateInventoryItemForEdit(it)); setEditDialogOpen(true); }}>
                        <Pencil className="h-3.5 w-3.5 text-muted-foreground" />
                      </Button>
                      {showAddAccount && (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0" aria-label="Add a distinct account at this bank" onClick={() => openAnotherAccountAtBank(it)}>
                              <Plus className="h-3.5 w-3.5 text-primary" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent side="top"><p className="text-xs">Add a distinct account at this bank</p></TooltipContent>
                        </Tooltip>
                      )}
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => handleDeleteItem(it)}>
                        <Trash2 className="h-3.5 w-3.5 text-destructive" />
                      </Button>
                    </div>
                  </div>
                  {it.category === "financial" && (it.accountNumber || it.accountHolder) && (
                    <div className="mt-1.5 text-[11px] text-muted-foreground space-y-0.5 border-t pt-1.5">
                      {it.accountHolder && <p>Account holder: {it.accountHolder}</p>}
                      {it.accountNumber && <p>Acct #: {it.accountNumber}</p>}
                      {it.bankAddress && <p>Bank: {it.bankAddress}</p>}
                    </div>
                  )}
                  {it.category === "real_property" && (it.pid || it.registeredOwner) && (
                    <div className="mt-1.5 text-[11px] text-muted-foreground space-y-0.5 border-t pt-1.5">
                      {it.pid && <p>PID: {it.pid}</p>}
                      {it.registeredOwner && <p>Registered to: {it.registeredOwner}</p>}
                      {it.legalDescription && <p className="truncate">Legal: {it.legalDescription}</p>}
                    </div>
                  )}
                </CardContent>
              </Card>
              );
              return cardContent;
            };

            const SortableAccountCard = ({ it, showAddAccount, accountOrdinal }: { it: any; showAddAccount: boolean; accountOrdinal?: number }) => {
              const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: it.id });
              const style = { transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.5 : 1, zIndex: isDragging ? 10 : undefined };
              return (
                <div ref={setNodeRef} style={style} {...attributes}>
                  <Card className="border">
                    <CardContent className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <div {...listeners} className="shrink-0 cursor-grab active:cursor-grabbing touch-none">
                          <GripVertical className="h-3.5 w-3.5 text-muted-foreground" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{financialAccountLabel(it, accountOrdinal)}</p>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-xs text-muted-foreground">{it.category === "unknown" ? "category pending" : it.category.replace(/_/g, " ")}{it.subcategory ? ` (${it.subcategory.toUpperCase()})` : ""} · {it.location === "in_bc" ? "In BC" : it.location === "outside_bc" ? "Outside BC" : "location pending"}</span>
                            <span className="font-mono text-xs font-semibold ml-auto">{isInventoryValueRecorded(it) ? formatMoney(probateItemValue(it)) : ""}</span>
                          </div>
                          <p className={`text-[10px] mt-0.5 ${it.passesToPersonalRepresentative === "yes" ? "text-muted-foreground" : it.passesToPersonalRepresentative === "no" ? "text-sky-700 dark:text-sky-300" : "text-amber-700 dark:text-amber-300"}`}>
                            {it.passesToPersonalRepresentative === "yes" ? "Passes to personal representative" : it.passesToPersonalRepresentative === "no" ? "Does not pass to personal representative — excluded from estate forms and totals" : "Pass-to-personal-representative answer required"}
                          </p>
                        </div>
                        <div className="flex items-center shrink-0">
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0" aria-label="Edit inventory item" onClick={() => { setEditingItem(hydrateInventoryItemForEdit(it)); setEditDialogOpen(true); }}>
                            <Pencil className="h-3.5 w-3.5 text-muted-foreground" />
                          </Button>
                          {showAddAccount && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="sm" className="h-8 w-8 p-0" aria-label="Add a distinct account at this bank" onClick={() => openAnotherAccountAtBank(it)}>
                                  <Plus className="h-3.5 w-3.5 text-primary" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent side="top"><p className="text-xs">Add a distinct account at this bank</p></TooltipContent>
                            </Tooltip>
                          )}
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => handleDeleteItem(it)}>
                            <Trash2 className="h-3.5 w-3.5 text-destructive" />
                          </Button>
                        </div>
                      </div>
                      {it.category === "financial" && (it.accountNumber || it.accountHolder) && (
                        <div className="mt-1.5 text-[11px] text-muted-foreground space-y-0.5 border-t pt-1.5">
                          {it.accountHolder && <p>Account holder: {it.accountHolder}</p>}
                          {it.accountNumber && <p>Acct #: {it.accountNumber}</p>}
                          {it.bankAddress && <p>Bank: {it.bankAddress}</p>}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              );
            };

            const handleDragEnd = (bankName: string, accounts: any[]) => (event: DragEndEvent) => {
              const { active, over } = event;
              if (!over || active.id === over.id) return;
              const oldIndex = accounts.findIndex(a => a.id === active.id);
              const newIndex = accounts.findIndex(a => a.id === over.id);
              if (oldIndex === -1 || newIndex === -1) return;
              const reordered = arrayMove(accounts, oldIndex, newIndex);
              // Optimistically update the cache
              utils.inventory.list.setData({ estateId }, (old) => {
                if (!old) return old;
                const updated = [...old];
                const ids = reordered.map(a => a.id);
                let sortBase = Math.min(...reordered.map(a => a.sortOrder || 0));
                for (const id of ids) {
                  const idx = updated.findIndex(i => i.id === id);
                  if (idx !== -1) updated[idx] = { ...updated[idx], sortOrder: sortBase++ };
                }
                return updated.sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0));
              });
              reorderMutation.mutate({ estateId, itemIds: reordered.map(a => a.id) });
            };

            const multiAccountGroups = Array.from(bankGroups.entries()).filter(([, accts]) => accts.length > 1);

            return (
              <>
                {/* Expand All / Collapse All buttons */}
                {multiAccountGroups.length > 1 && (
                  <div className="flex items-center gap-2 mb-1">
                    <Button variant="ghost" size="sm" className="h-6 px-2 text-[11px] text-muted-foreground" onClick={() => setCollapsedBanks(new Set())}>
                      Expand All
                    </Button>
                    <Button variant="ghost" size="sm" className="h-6 px-2 text-[11px] text-muted-foreground" onClick={() => setCollapsedBanks(new Set(multiAccountGroups.map(([name]) => name)))}>
                      Collapse All
                    </Button>
                  </div>
                )}
                {/* Financial items grouped by their bank-level branch key. */}
                {Array.from(bankGroups.entries()).map(([bankKey, accounts]) => {
                  const bankHeadingSource = accounts.find((account) => String(account.description || "").trim()) || accounts[0];
                  const bankHeading = bankInstitutionLabel(bankHeadingSource);
                  return (
                  <div key={`bank-${bankKey}`} className="space-y-1">
                    {accounts.length > 1 && (
                      <div className="flex items-center gap-2 px-1 pt-1">
                        <span className="min-w-0 truncate text-xs font-semibold uppercase tracking-wide text-muted-foreground" title={bankHeading}>{bankHeading}</span>
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-4 cursor-pointer select-none hover:bg-accent transition-colors" onClick={() => toggleBankCollapse(bankKey)}>
                          {accounts.length} {collapsedBanks.has(bankKey) ? "▶" : "▼"}
                        </Badge>
                      </div>
                    )}
                    {accounts.length > 1 ? (
                      <AnimatePresence initial={false}>
                        {!collapsedBanks.has(bankKey) && (
                          <motion.div
                            key={`bank-content-${bankKey}`}
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
                            style={{ overflow: "hidden" }}
                          >
                            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd(bankKey, accounts)}>
                              <SortableContext items={accounts.map(a => a.id)} strategy={verticalListSortingStrategy}>
                                {accounts.map((it, index) => <SortableAccountCard key={it.id} it={it} showAddAccount={true} accountOrdinal={index + 1} />)}
                              </SortableContext>
                            </DndContext>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    ) : (
                      accounts.map((it, index) => <div key={it.id}>{renderItemCard(it, true, false, index + 1)}</div>)
                    )}
                  </div>
                  );
                })}
                {/* Non-financial items */}
                {nonFinancialItems.map((it) => <div key={it.id}>{renderItemCard(it, false, false)}</div>)}
                {allItems.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No inventory items. Add assets and liabilities for the P10 affidavit.</p>}
              </>
            );
          })()}
        </div>
      )}

      {/* Delete confirmation dialog */}
      <AlertDialog open={!!deleteConfirmItem} onOpenChange={(open) => { if (!open) setDeleteConfirmItem(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this item?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deleteConfirmItem?.description || 'this item'}"?
              {deleteConfirmItem?.subcategory && ` (${deleteConfirmItem.subcategory.toUpperCase()})`}
              {deleteConfirmItem?.accountNumber && ` — Acct #${deleteConfirmItem.accountNumber}`}
              <br /><br />
              This action can be undone within 5 seconds via the toast notification.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ─── DOCUMENTS TAB (required source docs + AI import) ────────────────
// RULES.md Rule 24 (Nick, 2026-08-17): the Documents tab was removed. Its two
// live pieces relocated — this checklist card into the Readiness tab, the AI
// import card + proposals into the Intake tab. Nothing was deleted: this card
// remains the sole writer of requiredDoc rows (readiness + P2 preflight read
// them), and the wills_notice_result row remains Rule 21's certificate tracker.
export function RequiredSourceDocumentsCard({ estateId }: { estateId: string }) {
  const { data: reqDocs } = trpc.requiredDoc.list.useQuery({ estateId });
  const { data: estate } = trpc.estate.get.useQuery({ id: estateId });
  const utils = trpc.useUtils();
  // RULES.md Rule 21 (Nick, 2026-08-05): the wills-search workflow card was
  // removed — the certificate result is recorded once, in Intake, and
  // certificate receipt is the wills_notice_result required-document below.
  const upsertMutation = trpc.requiredDoc.upsert.useMutation({
    onMutate: async (newData) => {
      // Cancel outgoing refetches
      await utils.requiredDoc.list.cancel({ estateId });
      // Snapshot previous value
      const previousDocs = utils.requiredDoc.list.getData({ estateId });
      // Optimistically update the cache
      utils.requiredDoc.list.setData({ estateId }, (old) => {
        if (!old) return old;
        const exists = old.find((d) => d.docKey === newData.docKey);
        if (exists) {
          return old.map((d) => d.docKey === newData.docKey ? { ...d, received: newData.received ? 1 : 0 } : d);
        }
        return [...old, { id: `temp-${newData.docKey}`, estateId, docKey: newData.docKey, received: newData.received ? 1 : 0, userId: 0, updatedAt: Date.now() } as any];
      });
      return { previousDocs };
    },
    onError: (_err, _newData, context) => {
      // Rollback on error
      if (context?.previousDocs) {
        utils.requiredDoc.list.setData({ estateId }, context.previousDocs);
      }
    },
    onSettled: () => {
      void utils.requiredDoc.list.invalidate({ estateId });
      void utils.readiness.check.invalidate({ estateId });
      void utils.readiness.timeline.invalidate({ estateId });
      void utils.document.preflight.invalidate();
      void utils.document.preflightMany.invalidate();
    },
  });
  const receivedKeys = new Set((reqDocs || []).filter((d) => d.received).map((d) => d.docKey));

  return (
    <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Required Source Documents</CardTitle>
          <CardDescription className="text-xs">Track which physical documents you have gathered. These feed into the Readiness checklist.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          {/* items-start: the box belongs beside the document NAME, not floating in
              the middle of a description that wraps to three lines at narrow width. */}
          {requiredDocumentsForEstate((estate || { hasWill: false }) as any, REQUIRED_DOCUMENTS).map((doc) => (
            <div key={doc.key} className="flex min-w-0 items-start gap-3 py-2">
              <Checkbox
                className="mt-0.5"
                id={`required-doc-${doc.key}`}
                checked={receivedKeys.has(doc.key)}
                onCheckedChange={(checked) => upsertMutation.mutate({ estateId, docKey: doc.key, received: !!checked })}
              />
              <div className="min-w-0 flex-1">
                <Label htmlFor={`required-doc-${doc.key}`} className="block min-w-0 cursor-pointer break-words text-sm font-medium leading-snug">{doc.name} {!doc.required && <span className="text-xs font-normal text-muted-foreground">(not required for this estate)</span>}</Label>
                <p className="break-words text-xs leading-relaxed text-muted-foreground">{doc.description}</p>
              </div>
            </div>
          ))}
        </CardContent>
    </Card>
  );
}

export function AiImportCard({ estateId }: { estateId: string }) {
  const { data: aiFeatures } = trpc.system.aiFeatures.useQuery();
  const aiProcessorEnabled = aiFeatures?.enabled === true;
  const utils = trpc.useUtils();
  const [importText, setImportText] = useState("");
  const [importFileName, setImportFileName] = useState("");
  const [processorDisclosureAcknowledged, setProcessorDisclosureAcknowledged] = useState(false);
  const processMutation = trpc.aiImport.process.useMutation({
    onSuccess: () => {
      void utils.aiImport.list.invalidate({ estateId });
      toast.success("AI import processed. Review the proposal in the AI Import section.");
      setImportText("");
      setImportFileName("");
      setProcessorDisclosureAcknowledged(false);
    },
    onError: (err) => { toast.error("Import failed: " + err.message); },
  });

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setProcessorDisclosureAcknowledged(false);
    if (!file.name.toLowerCase().endsWith(".txt") || (file.type && file.type !== "text/plain")) {
      toast.error("AI import currently accepts plain-text (.txt) files only.");
      e.target.value = "";
      return;
    }
    if (file.size > 100_000) {
      toast.error("AI import text must be 100 KB or smaller.");
      e.target.value = "";
      return;
    }
    setImportFileName(file.name);
    const text = await file.text();
    setImportText(text.slice(0, 10000));
    e.target.value = "";
  };

  return (
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">AI-Assisted Document Import</CardTitle>
          <CardDescription className="text-xs">Upload a plain-text document and AI will propose contacts, estate details, and inventory entries for your review. The stored, server-validated proposal—not browser-supplied fields—is what Apply uses.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Alert>
            <ShieldCheck className="h-4 w-4" />
            <AlertDescription className="text-xs space-y-2">
              <p>
                File text is sent to two third-party AI models through the hosting platform's
                Forge AI service. Send only information needed for this import and verify every
                proposal before applying it. <a href="/privacy" target="_blank" rel="noopener noreferrer" className="underline">Privacy Policy</a>
              </p>
              {aiProcessorEnabled ? (
                <label className="flex items-start gap-2 text-foreground">
                  <Checkbox
                    checked={processorDisclosureAcknowledged}
                    onCheckedChange={(checked) => setProcessorDisclosureAcknowledged(checked === true)}
                    aria-label="Confirm authorization to send this document to the AI providers"
                  />
                  <span>I confirm I am authorized to send this document to the AI providers for this import.</span>
                </label>
              ) : (
                <p role="status" className="font-medium text-amber-700 dark:text-amber-300">
                  {aiFeatures?.reason || "AI features are unavailable pending processor and privacy approval."}
                </p>
              )}
            </AlertDescription>
          </Alert>
          <div className="flex items-center gap-3">
            <Input type="file" accept=".txt,text/plain" onChange={handleFileUpload} className="flex-1" disabled={!aiProcessorEnabled} />
            <Button
              size="sm"
              disabled={!aiProcessorEnabled || !processorDisclosureAcknowledged || !importText || processMutation.isPending}
              onClick={() => processMutation.mutate({
                estateId,
                fileContent: importText,
                fileName: importFileName,
                processorDisclosureAcknowledged: true,
              })}
            >
              <Upload className="h-3.5 w-3.5 mr-1" />
              {processMutation.isPending ? "Processing..." : "Import"}
            </Button>
          </div>
          {importFileName && <p className="text-xs text-muted-foreground">File: {importFileName} ({importText.length} chars)</p>}
        </CardContent>
      </Card>
  );
}

export function AiImportsSection({ estateId, intakeDraftPending = false }: {
  estateId: string;
  intakeDraftPending?: boolean;
}) {
  const { data: imports } = trpc.aiImport.list.useQuery({ estateId });
  const utils = trpc.useUtils();
  const applyMutation = trpc.aiImport.applyImport.useMutation({
    onSuccess: () => {
      void utils.aiImport.list.invalidate({ estateId });
      void utils.estate.get.invalidate({ id: estateId });
      void utils.contact.list.invalidate({ estateId });
      void utils.inventory.list.invalidate({ estateId });
      void utils.distribution.compute.invalidate({ estateId });
      void utils.readiness.check.invalidate({ estateId });
      void utils.readiness.timeline.invalidate({ estateId });
      void utils.deadline.list.invalidate();
      void utils.document.preflight.invalidate();
      void utils.document.preflightMany.invalidate();
      toast.success("Import applied");
    },
  });
  const dismissMutation = trpc.aiImport.dismiss.useMutation({
    onSuccess: () => {
      void utils.aiImport.list.invalidate({ estateId });
      toast.success("Import proposal dismissed");
    },
    onError: (error) => toast.error(error.message || "Could not dismiss the proposal"),
  });

  if (!imports || imports.length === 0) return null;

  const applyImport = (importId: string): void => {
    // Defense in depth for a click queued just as Intake became dirty. The
    // disabled button is the visible gate; this guard protects the mutation.
    if (intakeDraftPending) {
      toast.error("Save Intake changes before applying an import.");
      return;
    }
    applyMutation.mutate({ importId, estateId });
  };

  return (
    <Card>
      <CardHeader className="pb-3"><CardTitle className="text-sm">Import Proposals</CardTitle></CardHeader>
      <CardContent className="space-y-3">
        {intakeDraftPending && (
          <p className="text-xs text-amber-700 dark:text-amber-300" role="status" data-testid="ai-import-intake-draft-warning">
            Save Intake changes before applying an import. This prevents the import and your draft from overwriting each other.
          </p>
        )}
        {imports.map((imp) => {
          let proposal: any = null;
          try { proposal = JSON.parse(imp.proposal || "{}"); } catch {}
          return (
            <div key={imp.id} className="border rounded-lg p-3 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <Badge variant="outline" className="text-xs">{imp.status}</Badge>
                  <span className="text-xs text-muted-foreground ml-2">{imp.fileNames}</span>
                </div>
                {imp.status === "proposed" && proposal && (
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" onClick={() => applyImport(imp.id)} disabled={intakeDraftPending || applyMutation.isPending || dismissMutation.isPending}>
                      Apply All
                    </Button>
                    <Button size="sm" variant="ghost" className="text-muted-foreground" onClick={() => dismissMutation.mutate({ importId: imp.id, estateId })} disabled={applyMutation.isPending || dismissMutation.isPending}>
                      Dismiss
                    </Button>
                  </div>
                )}
              </div>
              {proposal && imp.status === "proposed" && (
                <pre className="text-xs bg-muted p-2 rounded overflow-auto max-h-40">{JSON.stringify(proposal, null, 2)}</pre>
              )}
              {imp.error && <p className="text-xs text-destructive">{imp.error}</p>}
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}

// ─── FORM PREVIEW MODAL ──────────────────────────────────────────────

/** The one overrides channel every single-form render path shares (Rule 22). */
type PreflightRenderContext = {
  selectedContactId?: string;
  targetContactId?: string;
  targetDeliveryId?: string;
  targetCitationRecordId?: string;
  packageMode?: boolean;
  forceMany?: boolean;
  overrides?: Record<string, unknown>;
  generateAnyway?: boolean;
  /**
   * Set ONLY by call sites whose doMutate consumes the effectiveOverrides
   * parameter. Gates the PreGenerateDialog's inline field editors: without it,
   * typed values could clear a gap on re-check and then be silently dropped by
   * a mutation that ignores them — a blank the user was told they had filled.
   * Never set on package/bulk paths (Rule 22 §6).
   */
  supportsOverrides?: boolean;
  /**
   * Task 13 "Review and generate again": open the review dialog even when every check passes, so nothing is
   * regenerated until the user's own Generate. An inline re-check of the open dialog proceeds as before.
   */
  reviewBeforeGenerate?: boolean;
  /** Task 13: the retained signing date a replayed review checks (the date its generation prints). */
  signatureDate?: string;
  /** Task 13 r3: what a "Review and generate again" review shows it will replay (display only). */
  retainedChoices?: ReadonlyArray<{ label: string; value: string }>;
  /** Task 13 r3.1: the replayed form is a primary affidavit (P3–P7), which replaces whichever one is current. */
  retainedPrimaryAffidavit?: boolean;
};
/**
 * A pending mutation gated by runWithPreflight. It receives the CURRENT
 * renderContext overrides at invocation time — not the ones captured when the
 * thunk was built — so an inline-fill re-check can merge typed values in
 * without rebuilding every call site's closure. Callers that accept no
 * overrides (package/bulk) simply ignore the argument.
 */
type PreflightProceedOptions = {
  /** Explicit P4-only opt-in emitted by the missing-information popup. */
  generateAnyway?: boolean;
};

type PreflightMutate = (
  effectiveOverrides?: Record<string, unknown>,
  proceedOptions?: PreflightProceedOptions,
) => unknown | Promise<unknown>;

/**
 * Task 13: what "Review and generate again" replays, in memory only — a single-form run exactly as it was invoked
 * (its continuation closes over every original choice) or a consent's exact answers. Never persisted or logged.
 */
type Regeneration =
  | { kind: "gate"; formCodes: ReadonlyArray<string>; formName: string; doMutate: PreflightMutate; renderContext?: PreflightRenderContext; signatureDate: string; sent?: Parameters<typeof retainedChoicesOf>[0] }
  | { kind: "consent-nomination"; beneficiaryId: string; nomineeContactId: string; relationshipToNominee: string; share: number; signatoryType?: string; signatureDate?: string }
  | { kind: "consent-administrator"; beneficiaryId: string; administratorContactId: string; signatoryType?: string; signatureDate?: string };

// The builders of these forms never print the signing date the request carries (docgen buildP13 / buildP19).
const DATE_NOT_PRINTED: ReadonlySet<string> = new Set(["P13", "P19"]);
/**
 * Task 13 r3 (Nick, 2026-10-24): the choices a "Review and generate again" review shows, read from the request that
 * was actually sent; names come from the contacts as refreshed for the review (r3.1). The signatory appears only
 * where the form offers that choice, or for VSA532 when "lawyer" was sent (its other boxes depend on the applicant);
 * the date for every form whose builder prints it (r3.2); the affidavit number only when one was typed.
 */
export function retainedChoicesOf(
  input: { formCode: string; deponentId?: string | null; selectedContactId?: string | null; targetBeneficiaryId?: string | null; affidavitOrdinal?: string | null; signatureDate?: string | null; signatoryType?: string | null },
  contacts: ReadonlyArray<{ id: unknown; name?: string | null }> | undefined,
): ReadonlyArray<{ label: string; value: string }> {
  const choices: Array<{ label: string; value: string }> = [];
  const personId = [input.deponentId, input.selectedContactId, input.targetBeneficiaryId].find((id) => id != null && id !== "");
  const person = personId === undefined ? undefined : contacts?.find((contact) => String(contact.id) === String(personId))?.name;
  if (person) choices.push({ label: "For", value: person });
  if (input.affidavitOrdinal) choices.push({ label: "Affidavit number", value: input.affidavitOrdinal });
  if (input.signatureDate && !DATE_NOT_PRINTED.has(input.formCode)) choices.push({ label: "Date", value: input.signatureDate });
  const signatory = input.signatoryType === "lawyer" ? "Lawyer" : input.signatoryType === "executor" ? "Executor (applicant)" : undefined;
  if (signatory && (FORM_DETAILS[input.formCode]?.some((field) => field.kind === "signatory") || (input.formCode === "VSA532" && input.signatoryType === "lawyer"))) choices.push({ label: "Signatory", value: signatory });
  return choices;
}

// A manual single-form P5 action requests a reviewable draft, including when
// its current answers make it Required. Bulk/package calls never use this.
function manualP5DraftOptions(formCode: string): { generateAnyway?: true } {
  return formCode === "P5" ? { generateAnyway: true } : {};
}

function p4GenerationFailureMessage(cause: string, missingAttachment = false): string {
  const detail = cause.trim();
  if (missingAttachment) {
    return "P4 was not generated because no DOCX download was returned. No document was created. Select Review P4 & retry to check the missing-information answers and generate again.";
  }
  return `P4 was not generated. ${detail || "The generation service did not provide a reason."} The P4 answers remain available. Select Review P4 & retry to return to the form, then use Apply & re-check or Generate anyway.`;
}

export function FormPreviewModal({ estateId, formCode, formName, signatoryType, signatureDate, targetBeneficiaryId, deponentId, selectedContactId, deliveryId, citationRecordId, affidavitOrdinal, consentNomination, consentAppointAdministrator, overrides, generateAnyway, open, onOpenChange, runWithPreflight, p17AddressCity, p17AddressProvince }: {
  estateId: string;
  formCode: string;
  formName: string;
  signatoryType: string;
  signatureDate: string;
  targetBeneficiaryId?: string;
  deponentId?: string;
  selectedContactId?: string;
  deliveryId?: string;
  citationRecordId?: string;
  affidavitOrdinal?: string;
  consentNomination?: { nomineeContactId: string; relationshipToNominee: string; beneficiarySharePercentage: number };
  consentAppointAdministrator?: { administratorContactId: string };
  /** Per-document answers from the Optional-form popup; never persisted. */
  overrides?: Record<string, unknown>;
  /** The canonical last-residential-address location used to prefill P17 only. */
  p17AddressCity?: string;
  p17AddressProvince?: string;
  /** The user's explicit opt-in to produce a form this estate does not require. */
  generateAnyway?: boolean;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** FormsTab's preflight gate — the download must run through the same gap dialog as Generate. */
  runWithPreflight?: (
    formCodes: ReadonlyArray<string>,
    formName: string,
    doMutate: PreflightMutate,
    renderContext?: PreflightRenderContext,
    action?: "generate" | "preview" | "download",
  ) => Promise<boolean>;
}) {
  const isP17 = formCode === "P17";
  const effectiveGenerateAnyway = manualP5DraftOptions(formCode).generateAnyway ?? generateAnyway;
  const initialP17City = String(overrides?.addressCity ?? p17AddressCity ?? "");
  const initialP17Province = String(overrides?.addressProvince ?? p17AddressProvince ?? "");
  const [p17AddressEditorOpen, setP17AddressEditorOpen] = useState(false);
  const [p17CityDraft, setP17CityDraft] = useState(initialP17City);
  const [p17ProvinceDraft, setP17ProvinceDraft] = useState(initialP17Province);
  useEffect(() => {
    if (!open || !isP17) {
      if (!open) setP17AddressEditorOpen(false);
      return;
    }
    setP17CityDraft(initialP17City);
    setP17ProvinceDraft(initialP17Province);
    setP17AddressEditorOpen(false);
    // Reset only when this preview opens for a different P17 source; never
    // overwrite an in-progress adjustment during a query re-render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, formCode]);
  const effectivePreviewOverrides = useMemo(() => {
    if (!isP17) return overrides;
    return {
      ...(overrides || {}),
      addressCity: p17CityDraft.trim(),
      addressProvince: p17ProvinceDraft.trim(),
    };
  }, [isP17, overrides, p17CityDraft, p17ProvinceDraft]);
  const previewQuery = trpc.document.preview.useQuery(
    {
      estateId, formCode, signatoryType, signatureDate, targetBeneficiaryId, deponentId, selectedContactId, deliveryId, citationRecordId, affidavitOrdinal, consentNomination, consentAppointAdministrator,
      overrides: effectivePreviewOverrides as Record<string, string | number | boolean> | undefined,
      generateAnyway: effectiveGenerateAnyway,
    },
    {
      enabled: open,
      subscribed: open,
      networkMode: "offlineFirst",
      retry: previewRetry,
      queryKeyHashFn: previewQueryKeyHash,
      trpc: { abortOnUnmount: true },
    }
  );
  const { isLoading } = previewQuery;
  const data = previewQuery.isError ? undefined : previewQuery.data; // Task 12: usable data only from a non-error, non-refusal result
  const generateDocxMutation = trpc.document.generate.useMutation();
  const [downloadPending, setDownloadPending] = useState(false);
  // Task 13: a download's feedback belongs to this open preview; closing it drops a late result.
  const previewFeedback = useDeliveryFeedbackOwner(`preview:${estateId}`, open);

  // Zoom and full-screen state
  const [zoom, setZoom] = useState(100);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const zoomIn = () => setZoom((z) => Math.min(z + 25, 200));
  const zoomOut = () => setZoom((z) => Math.max(z - 25, 50));
  const zoomReset = () => setZoom(100);

  const handleDownloadDocx = async () => {
    // Preflight first — a preview download must not bypass the gap dialog
    if (runWithPreflight) {
      await runWithPreflight(
        [formCode],
        `${formCode} — ${formName}`,
        // Download with the overrides the gate hands back — after an
        // inline-fill re-check they are a superset of this modal's prop.
        (effectiveOverrides) => doDownloadDocx(effectiveOverrides ?? effectivePreviewOverrides),
        { selectedContactId: selectedContactId ?? (formCode === "P8" ? deponentId : undefined), targetContactId: targetBeneficiaryId, targetDeliveryId: deliveryId, targetCitationRecordId: citationRecordId, overrides: effectivePreviewOverrides, generateAnyway: effectiveGenerateAnyway, supportsOverrides: true },
        "download",
      );
      return;
    }
    // doDownloadDocx rethrows for the gated path above; here the toast it
    // already fired is the whole story.
    try { await doDownloadDocx(effectivePreviewOverrides); } catch { /* toast shown */ }
  };

  const doDownloadDocx = async (effectiveOverrides?: Record<string, unknown>) => {
    setDownloadPending(true);
    // Feedback begins once the transport has run, so its own checks come first and a session the generate
    // response rotated is the one that hears the result; closing the preview still drops it.
    let feedback: DeliveryFeedback | null = null;
    try {
      // The route streams only a render document.generate recorded (Nick,
      // 2026-10-20): generate first, then post the delivery it returns. The
      // downloaded DOCX must match the previewed one — carry the deponent
      // selection (popup's selectedContactId / P8-P17's deponentId) and the
      // popup's per-document answers to that render.
      const generated = await generateDocxMutation.mutateAsync({
        estateId,
        formCode,
        signatoryType,
        signatureDate,
        targetBeneficiaryId: targetBeneficiaryId || undefined,
        deponentId: deponentId || undefined,
        selectedContactId: selectedContactId || undefined,
        deliveryId: deliveryId || undefined,
        citationRecordId: citationRecordId || undefined,
        affidavitOrdinal: affidavitOrdinal || undefined,
        consentNomination,
        consentAppointAdministrator,
        overrides: effectiveOverrides && Object.keys(effectiveOverrides).length > 0
          ? effectiveOverrides as Record<string, string | number | boolean>
          : undefined,
        generateAnyway: effectiveGenerateAnyway || undefined,
      });
      if (!isPostDelivery(generated.delivery)) throw new Error("Download failed");
      // One bounded, validated fetch (Task 9); a Bearer fallback token rides only in Authorization.
      const outcome = await fetchDeliveryAttachment(generated.delivery);
      feedback = previewFeedback.begin("preview");
      if (outcome.kind !== "handed-off") throw new Error("message" in outcome ? outcome.message : "Download failed");
      // A handoff, not a saved file; a form with evidence arrives as a ZIP.
      feedback.success(outcome.filename.toLowerCase().endsWith(".zip") ? "ZIP download started." : "DOCX download started.");
    } catch (err: any) {
      (feedback ?? previewFeedback.begin("preview")).error(err.message || "Download failed");
      // Rethrow so the preflight/proceed path sees the failure — swallowing it
      // here made handlePgProceed mark success and the popup announce
      // "Download started!" for a download that never happened (2026-08-21
      // goal loop; pre-existing truthfulness break).
      throw err;
    } finally {
      setDownloadPending(false);
    }
  };

  const openPrintWindow = (sections: any[]) => {
    const w = window.open("", "_blank");
    if (!w) { toast.error("Please allow popups"); return null; }
    renderPrintDocument(w.document, `${formCode} — ${formName}`, sections, window.location.origin);
    w.opener = null;
    return w;
  };

  const [pdfLoading, setPdfLoading] = useState(false);
  const handleSavePdf = async () => {
    if (!data?.sections) return;
    setPdfLoading(true);
    try {
      const { jsPDF } = await import("jspdf");
      const doc = new jsPDF({ unit: "pt", format: "letter" });
      const pageWidth = doc.internal.pageSize.getWidth();
      const margin = 50;
      const maxWidth = pageWidth - margin * 2;
      let y = margin;
      const lineHeight = 14;
      const checkPage = (needed: number) => {
        if (y + needed > doc.internal.pageSize.getHeight() - margin) {
          doc.addPage();
          y = margin;
        }
      };
      for (const s of data.sections as any[]) {
        if (s.type === "letterhead_image" && s.imageUrl) {
          // Skip letterhead image in PDF — it's complex to embed; show text fallback
          checkPage(20);
          doc.setFont("helvetica", "italic");
          doc.setFontSize(9);
          doc.text("[Letterhead image — see printed/DOCX version]", pageWidth / 2, y, { align: "center" });
          y += 20;
        } else if (s.type === "letterhead_docx") {
          checkPage(20);
          doc.setFont("helvetica", "italic");
          doc.setFontSize(9);
          doc.text(`[DOCX letterhead template: ${s.text || "configured template"} — header/footer appear in generated DOCX]`, pageWidth / 2, y, { align: "center", maxWidth });
          y += 20;
        } else if (s.type === "heading") {
          checkPage(24);
          doc.setFont("helvetica", "bold");
          doc.setFontSize(13);
          const lines = doc.splitTextToSize(s.text || "", maxWidth);
          if (s.center) {
            for (const line of lines) {
              doc.text(line, pageWidth / 2, y, { align: "center" });
              y += 16;
            }
          } else {
            doc.text(lines, margin, y);
            y += lines.length * 16;
          }
          y += 4;
        } else if (s.type === "separator") {
          checkPage(12);
          doc.setDrawColor(180);
          doc.line(margin, y, pageWidth - margin, y);
          y += 12;
        } else if (s.type === "pagebreak") {
          doc.addPage();
          y = margin;
        } else if (s.type === "letter_recipient_block") {
          const recipientLines = s.recipientLines?.length ? s.recipientLines : String(s.text || "").split("\n").slice(0, -2);
          const deliveryMethod = s.deliveryMethod || "Regular Mail";
          const blockLineHeight = lineHeight;
          const blockHeight = Math.max(recipientLines.length, 2) * blockLineHeight;
          checkPage(blockHeight + 10);
          doc.setFont("times", "normal");
          doc.setFontSize(11);
          recipientLines.forEach((line: string) => {
            doc.text(line, margin, y);
            y += blockLineHeight;
          });
          const blockStartY = y - recipientLines.length * blockLineHeight;
          doc.text("Delivery Method", pageWidth - margin, blockStartY, { align: "right" });
          doc.setFont("times", "bold");
          doc.text(deliveryMethod, pageWidth - margin, blockStartY + blockLineHeight, { align: "right" });
          y = blockStartY + blockHeight + 10;
        } else if (s.type === "checkbox") {
          checkPage(lineHeight);
          doc.setFont("courier", "normal");
          doc.setFontSize(10);
          const mark = s.hideMarker ? "" : s.checked ? "[X]" : s.hideUnchecked ? "" : "[  ]";
          if (mark) doc.text(mark, margin + 10, y);
          doc.setFont("times", "normal");
          const textX = s.hideMarker ? margin : margin + 35;
          const cbLines = doc.splitTextToSize(s.text || "", maxWidth - (textX - margin));
          for (let li = 0; li < cbLines.length; li++) {
            doc.text(cbLines[li], textX, y);
            y += lineHeight;
          }
        } else if (s.type === "signature") {
          checkPage(40);
          if (!s.suppressRule) {
            doc.setDrawColor(100);
            doc.line(margin, y, margin + 200, y);
            y += 14;
          }
          doc.setFont("times", "normal");
          doc.setFontSize(9);
          doc.text(s.text || "", margin, y);
          y += 20;
        } else if (s.type === "table" && s.rows) {
          doc.setFontSize(9);
          for (const row of s.rows) {
            const spans = row.cells.map((_cell: string, ci: number) => row.colSpans?.[ci] ?? 1);
            const totalSpans = Math.max(spans.reduce((sum: number, span: number) => sum + span, 0), 1);
            if (row.header) doc.setFont("helvetica", "bold");
            else if (row.italic) doc.setFont("times", "italic");
            else doc.setFont("times", "normal");

            const cellPadding = 4;
            const wrappedCells: { cellWidth: number; lines: string[] }[] = row.cells.map((cell: string, ci: number) => {
              const cellWidth = maxWidth * spans[ci] / totalSpans;
              const contentWidth = Math.max(cellWidth - cellPadding * 2, 1);
              const lines = String(cell).split("\n").flatMap((explicitLine) => {
                const wrapped = doc.splitTextToSize(explicitLine || " ", contentWidth);
                return (Array.isArray(wrapped) ? wrapped : [wrapped]).map(String);
              });
              return { cellWidth, lines: lines.length > 0 ? lines : [""] };
            });
            const rowHeight = Math.max(
              lineHeight + cellPadding * 2,
              ...wrappedCells.map((cell: { cellWidth: number; lines: string[] }) => cell.lines.length * lineHeight + cellPadding * 2),
            );
            checkPage(rowHeight);

            let usedSpans = 0;
            wrappedCells.forEach(({ cellWidth, lines }: { cellWidth: number; lines: string[] }, ci: number) => {
              const x = margin + maxWidth * usedSpans / totalSpans;
              const align = row.cellAligns?.[ci] ?? (ci > 0 ? "right" : "left");
              const textX = align === "center"
                ? x + cellWidth / 2
                : align === "right"
                  ? x + cellWidth - cellPadding
                  : x + cellPadding;
              doc.setDrawColor(210);
              doc.rect(x, y, cellWidth, rowHeight);
              lines.forEach((line: string, lineIndex: number) => {
                doc.text(line, textX, y + cellPadding + lineHeight * (lineIndex + 0.75), { align });
              });
              usedSpans += spans[ci];
            });
            y += rowHeight;
          }
          y += 6;
        } else {
          // paragraph
          doc.setFontSize(11);
          if (s.bold) doc.setFont("times", "bold");
          else if (s.italic) { doc.setFont("times", "italic"); doc.setFontSize(9); }
          else doc.setFont("times", "normal");
          const indent = s.indent ? 20 : 0;
          const lines = doc.splitTextToSize(s.text || "", maxWidth - indent);
          checkPage(lines.length * lineHeight);
          if (s.center) {
            for (const line of lines) {
              doc.text(line, pageWidth / 2, y, { align: "center" });
              y += lineHeight;
            }
          } else {
            doc.text(lines, margin + indent, y);
            y += lines.length * lineHeight;
          }
          y += 2;
        }
      }
      doc.save(`${formCode}_${formName.replace(/[^a-zA-Z0-9]/g, "_")}.pdf`);
      toast.success("PDF downloaded");
    } catch (err: any) {
      toast.error("Failed to generate PDF: " + (err.message || "Unknown error"));
    } finally {
      setPdfLoading(false);
    }
  };

  const handlePrint = () => {
    if (!data?.sections) return;
    const w = openPrintWindow(data.sections);
    if (w) setTimeout(() => { w.print(); }, 250);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) setIsFullScreen(false); onOpenChange(v); }}>
      <DialogContent className={cn(
        "flex flex-col transition-all duration-200",
        isFullScreen
          ? "sm:max-w-[calc(100%-2rem)] max-h-[calc(100vh-2rem)] w-full"
          : "sm:max-w-2xl max-h-[85vh]"
      )}>
        <DialogHeader>
          <div className="flex items-center justify-between min-w-0 gap-2">
            <DialogTitle className="text-sm truncate min-w-0" title={`${formCode} — ${formName}`}>{formCode} — {formName}</DialogTitle>
            <DialogDescription className="sr-only">Preview of the generated document</DialogDescription>
              <div className="flex items-center gap-1 mr-6 shrink-0">
                {isP17 && data?.sections && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 px-2 text-xs"
                    onClick={() => setP17AddressEditorOpen((value) => !value)}
                    aria-expanded={p17AddressEditorOpen}
                    aria-controls="p17-preview-address-editor"
                    data-testid="p17-preview-edit-address"
                  >
                    <Pencil className="mr-1 h-3.5 w-3.5" /> Edit address
                  </Button>
                )}
              {/* Zoom controls */}
              {data?.sections && (
                <>
                  <div className="flex items-center gap-0.5 border rounded-md px-1 py-0.5 mr-1">
                    <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={zoomOut} disabled={zoom <= 50} title="Zoom out">
                      <ZoomOut className="h-3.5 w-3.5" />
                    </Button>
                    <button
                      className="text-[10px] font-medium w-9 text-center hover:bg-muted rounded px-0.5 transition-colors"
                      onClick={zoomReset}
                      title="Reset zoom"
                    >
                      {zoom}%
                    </button>
                    <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={zoomIn} disabled={zoom >= 200} title="Zoom in">
                      <ZoomIn className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                  {/* Full-screen toggle */}
                  <Button variant="ghost" size="sm" className="h-7 w-7 p-0 mr-1" onClick={() => setIsFullScreen((f) => !f)} title={isFullScreen ? "Exit full screen" : "Full screen"}>
                    {isFullScreen ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
                  </Button>
                </>
              )}
              {/* Download / Print buttons */}
              {data?.sections && (
                <>
                  <Button variant="outline" size="sm" className="h-7 px-2 text-xs" onClick={handleDownloadDocx} disabled={downloadPending} data-testid="preview-download-docx">
                    <Download className="h-3.5 w-3.5 mr-1" /> {downloadPending ? "..." : formCode === "P34" ? "ZIP + evidence" : "DOCX"}
                  </Button>
                  {formCode !== "P34" && (
                    <>
                      <Button variant="outline" size="sm" className="h-7 px-2 text-xs" onClick={handleSavePdf} disabled={pdfLoading}>
                        <Download className="h-3.5 w-3.5 mr-1" /> {pdfLoading ? "..." : "PDF"}
                      </Button>
                      <Button variant="outline" size="sm" className="h-7 px-2 text-xs" onClick={handlePrint}>
                        <Printer className="h-3.5 w-3.5 mr-1" /> Print
                      </Button>
                    </>
                  )}
                </>
              )}
            </div>
          </div>
        </DialogHeader>
        {isP17 && p17AddressEditorOpen && (
          <section id="p17-preview-address-editor" className="rounded-lg border border-primary/20 bg-primary/[0.035] px-3 py-3 space-y-3" aria-label="Edit Form P17 location">
            <div className="min-w-0">
              <p className="text-xs font-semibold">Form P17 location</p>
              <p className="mt-0.5 text-[11px] leading-relaxed text-muted-foreground">Pre-filled from the deceased&apos;s last residential address. These adjustments apply only to this preview and its downloads; the Intake record is not changed.</p>
            </div>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              <div className="space-y-1">
                <Label className="text-xs" htmlFor="p17-preview-address-city">City</Label>
                <Input id="p17-preview-address-city" value={p17CityDraft} onChange={(event) => setP17CityDraft(event.target.value)} className="h-9" data-testid="p17-preview-address-city" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs" htmlFor="p17-preview-address-province">Province or state</Label>
                <Input id="p17-preview-address-province" value={p17ProvinceDraft} onChange={(event) => setP17ProvinceDraft(event.target.value)} className="h-9" data-testid="p17-preview-address-province" />
              </div>
            </div>
          </section>
        )}
        <ScrollArea className="flex-1 min-h-0">
          <div className="pr-4 pb-4" style={{ transform: `scale(${zoom / 100})`, transformOrigin: "top left", width: `${10000 / zoom}%` }}>
            {isLoading ? (
              <div className="space-y-3 py-4">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="h-4 bg-muted animate-pulse rounded" style={{ width: `${60 + Math.random() * 35}%` }} />
                ))}
              </div>
            ) : previewQuery.isError ? (
              <Alert variant="destructive" role="alert" className="my-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <p className="font-medium">Preview could not be generated</p>
                  <p className="mt-1">{previewErrorMessage(previewQuery.error)}</p>
                  <Button variant="outline" size="sm" className="mt-3" onClick={() => void previewQuery.refetch()}>Retry preview</Button>
                </AlertDescription>
              </Alert>
            ) : data?.sections ? (
              <div className="space-y-2 font-serif text-sm leading-relaxed overflow-x-hidden break-words">
                {data.sections.map((s, i) => {
                  if (s.type === "letterhead_image" && (s as any).imageUrl) return (
                    <div key={i} className="text-center mb-3">
                      <img src={(s as any).imageUrl} alt="Letterhead" className="max-w-full h-auto mx-auto" style={{ maxHeight: 100 }} />
                    </div>
                  );
                  if (s.type === "letterhead_docx") return (
                    <div key={i} className="text-center mb-3 rounded border border-dashed border-muted-foreground/40 px-3 py-2 text-[10px] text-muted-foreground font-sans">
                      DOCX letterhead template: {s.text || "configured template"}. Header and footer appear in the generated DOCX.
                    </div>
                  );
                  if (s.type === "letter_recipient_block") {
                    const recipientLines = s.recipientLines?.length ? s.recipientLines : String(s.text || "").split("\n").slice(0, -2);
                    return (
                      <div key={i} className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-x-8" data-testid="letter-recipient-block">
                        <div className="min-w-0 leading-snug">
                          {recipientLines.map((line, lineIndex) => <p key={lineIndex} className="m-0">{line}</p>)}
                        </div>
                        <div className="shrink-0 text-right leading-snug" data-testid="letter-delivery-method">
                          <p className="m-0">Delivery Method</p>
                          <p className="m-0 font-semibold">{s.deliveryMethod || "Regular Mail"}</p>
                        </div>
                      </div>
                    );
                  }
                  if (s.type === "heading") return (
                    <p key={i} className={`font-bold text-base ${s.center ? "text-center" : ""}`}>{s.text}</p>
                  );
                  if (s.type === "separator") return (
                    <hr key={i} className="my-3 border-border" />
                  );
                  {/* On screen a page break renders as a labelled divider; print/PDF get a real break */}
                  if (s.type === "pagebreak") return (
                    <div key={i} className="my-4 flex items-center gap-2 text-[10px] uppercase tracking-wide text-muted-foreground/60">
                      <hr className="flex-1 border-dashed border-border" /> page break <hr className="flex-1 border-dashed border-border" />
                    </div>
                  );
                  if (s.type === "checkbox") return (
                    <div key={i} className={s.hideMarker ? "" : "flex items-start pl-10"}>
                      {!s.hideMarker && <span className="font-mono text-xs mt-0.5 flex-shrink-0 w-6">{s.checked ? "[X]" : s.hideUnchecked ? "" : "[  ]"}</span>}
                      <span className="flex-1">{s.text}</span>
                    </div>
                  );
                  if (s.type === "signature") return (
                    <div key={i} className={s.suppressRule ? "mt-6" : "mt-6 pt-4 border-t"}>
                      {!s.suppressRule && <p className="text-xs text-muted-foreground">________________________________</p>}
                      <p className="text-xs text-muted-foreground">{s.text}</p>
                    </div>
                  );
                  if (s.type === "table" && s.rows) return (
                    <table key={i} className="w-full text-xs border-collapse my-2">
                      <tbody>
                        {s.rows.map((row, ri) => (
                          <tr key={ri} className={[row.header ? "bg-muted font-semibold" : "border-b border-border/50", row.italic ? "italic text-muted-foreground" : ""].filter(Boolean).join(" ")}>
                            {row.cells.map((cell, ci) => (
                              <td
                                key={ci}
                                colSpan={row.colSpans?.[ci] ?? 1}
                                className={`py-1 px-2 whitespace-pre-line ${row.cellAligns?.[ci] === "center" ? "text-center" : row.cellAligns?.[ci] === "right" || (!row.cellAligns?.[ci] && ci > 0) ? "text-right" : "text-left"}`}
                              >{cell}</td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  );
                  // paragraph
                  return (
                    <p key={i} className={[
                      s.bold ? "font-semibold" : "",
                      s.italic ? "italic text-muted-foreground text-xs" : "",
                      s.center ? "text-center" : "",
                      s.indent ? "pl-6" : "",
                    ].filter(Boolean).join(" ")}>{s.text}</p>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground py-4">Unable to load preview.</p>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

// ─── FORMS TAB ───────────────────────────────────────────────────────
// ── P19 — Grant Certificate card ──────────────────────────────────────
// P19 remains court-issued, but practitioners may generate a working draft.
// Its final seal date stays a highlighted fill until the registry date is
// recorded; missing data warns through the shared preflight path, never blocks.
// Exported for tests (house pattern: FormsTab itself is not renderable in jsdom).
export function P19GrantCard({ estateId, estate, updateGrantDate, onGenerateP19, onPreviewP19, isGenerating = false }: {
  estateId: string;
  estate: any;
  updateGrantDate: {
    mutate: (
      args: { id: string; expectedRevision: number; data: { grantIssuedDate: string } },
      opts?: { onSuccess?: () => void; onError?: (error: { message?: string }) => void }
    ) => void;
  };
  onGenerateP19: () => void;
  onPreviewP19: () => void;
  isGenerating?: boolean;
}) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm">P19 — Grant Certificate</CardTitle>
          <div className="flex items-center gap-2">
            <Input
              type="date"
              value={estate?.grantIssuedDate || ""}
              onChange={(e) => updateGrantDate.mutate({ id: estateId, expectedRevision: estate.revision, data: { grantIssuedDate: e.target.value } })}
              className="h-8 w-36 text-xs"
              title="Grant issued date"
            />
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                if (!estate?.grantIssuedDate) {
                  const today = todayIn("America/Vancouver");
                  updateGrantDate.mutate(
                    { id: estateId, expectedRevision: estate.revision, data: { grantIssuedDate: today } },
                    {
                      onSuccess: () => toast.success("Grant issued date set to today"),
                      onError: (error) => toast.error(error.message || "Could not set the grant issued date"),
                    }
                  );
                }
              }}
              disabled={!!estate?.grantIssuedDate}
              className="shrink-0"
            >
              <CheckCircle2 className="h-3.5 w-3.5 mr-1.5" />
              {estate?.grantIssuedDate ? "Grant Issued" : "Mark Grant Issued"}
            </Button>
            {estate?.grantIssuedDate && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  updateGrantDate.mutate(
                    { id: estateId, expectedRevision: estate.revision, data: { grantIssuedDate: "" } },
                    {
                      onSuccess: () => toast.success("Grant issued date cleared"),
                      onError: (error) => toast.error(error.message || "Could not clear the grant issued date"),
                    }
                  );
                }}
                className="shrink-0 text-muted-foreground hover:text-destructive"
                title="Clear grant issued date"
              >
                <X className="h-3.5 w-3.5" />
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        <p className="text-xs text-muted-foreground">Generate a working P19 draft as needed. The registry issues the sealed final grant; record the grant-issued date above once it arrives.</p>
        <div className="flex items-center gap-2" data-testid="p19-actions">
          <Button variant="outline" size="sm" disabled={isGenerating} data-testid="p19-generate" onClick={onGenerateP19}>
            <FileText className="h-3.5 w-3.5 mr-1.5" />
            {isGenerating ? "Generating..." : "Generate P19"}
          </Button>
          <Button variant="ghost" size="sm" disabled={isGenerating} data-testid="p19-preview" onClick={onPreviewP19}>
            <Eye className="h-3.5 w-3.5 mr-1.5" />
            Preview
          </Button>
        </div>
        {!estate?.grantIssuedDate && <p className="text-[10px] text-muted-foreground">The blank seal-date space is highlighted in the generated P19 until the grant-issued date is recorded.</p>}
      </CardContent>
    </Card>
  );
}

export function FormsTab({ estateId, estate, onNavigateToTab, feedbackOwner }: { estateId: string; estate: any; onNavigateToTab?: (tab: string) => void; feedbackOwner?: DeliveryFeedbackOwner }) {
  const { data: docs } = trpc.document.list.useQuery({ estateId });
  const { data: versions } = trpc.document.versions.useQuery({ estateId });
  const { data: retainedFiles } = trpc.document.retainedFiles.useQuery({ estateId });
  const { data: contacts } = trpc.contact.list.useQuery({ estateId });
  const { data: inventory = [] } = trpc.inventory.list.useQuery({ estateId });
  const { data: settings } = trpc.settings.get.useQuery();
  const formFocusedIntake = useFormFocusedIntakePreference(settings?.formFocusedIntake);
  const { data: readinessReport } = trpc.readiness.check.useQuery({ estateId });
  // Rule 15 (2026-08-04): the P8 rows derive from the applicant who ACTUALLY
  // swore the retained primary affidavit — the same document rows the render
  // paths read — not from the ranked primary.
  const p8PrimaryHistory = useMemo(
    () => primaryAffidavitDeponentFromDocuments(docs ?? []),
    [docs],
  );
  const utils = trpc.useUtils();
  const [showVersions, setShowVersions] = useState(false);
  const deleteVersionMutation = trpc.document.deleteVersion.useMutation({
    onSuccess: () => {
      void utils.document.versions.invalidate({ estateId });
      void utils.document.retainedFiles.invalidate({ estateId });
    },
  });
  const invalidateEstateDocumentState = () => {
    void utils.estate.get.invalidate({ id: estateId });
    void utils.readiness.check.invalidate({ estateId });
    void utils.readiness.timeline.invalidate({ estateId });
    void utils.deadline.list.invalidate();
    void utils.document.preflight.invalidate();
    void utils.document.preflightMany.invalidate();
  };
  const updateWillDateMutation = trpc.estate.update.useMutation({
    onSuccess: invalidateEstateDocumentState,
  });
  // The Contact card is canonical for the applicant. The retired
  // estate.applicantType value remains only for historic-record compatibility.
  const contactDefaultSignatoryType = useMemo(() => {
    const primaryApplicant = findPrimaryApplicant(contacts || []);
    return primaryApplicant && contactHasRole(primaryApplicant as any, "lawyer") ? "lawyer" : "executor";
  }, [contacts]);
  const [signatoryType, setSignatoryType] = useState(contactDefaultSignatoryType);
  const signatoryTypeChosenByUser = useRef(false);
  const chooseSignatoryType = (value: string) => {
    if (value !== "lawyer" && value !== "executor") return;
    signatoryTypeChosenByUser.current = true;
    setSignatoryType(value);
  };
  // Use persisted default if saved, otherwise today's date for convenience.
  // The per-form dialog still lets users change it before generating.
  const [signatureDate, setSignatureDate] = useState(
    () => (estate as any)?.defaultSignatureDate || todayIn("America/Vancouver")
  );
  // Track the last form the user clicked so the signatory select can hide "Lawyer"
  // for affidavit forms where the address-for-service must remain the applicant/executor
  // (P3/P4/P5/P6/P7/P8/P9/P10/P11). Rule 8 (2026-07-16) keeps P14/P15/P26 deponents
  // choosable (including lawyer), so those forms are excluded from this auto-switch.
  const [lastFormCode, setLastFormCode] = useState<string | null>(null);
  const affidavitFormCodes = new Set(["P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10", "P11"]);
  const hideLawyerSignatory = lastFormCode ? affidavitFormCodes.has(lastFormCode) : false;

  // Track whether the signatory was auto-switched to executor for an affidavit form.
  const [autoSwitchedToExecutor, setAutoSwitchedToExecutor] = useState(false);

  // For the affidavit forms above, force the address-for-service select back to
  // executor; P14/P15/P26 are excluded because their deponent (and thus service
  // address) may be the lawyer under Rule 8.
  // When switching back to a non-affidavit form, restore to "lawyer" only if we auto-switched.
  useEffect(() => {
    if (hideLawyerSignatory && signatoryType === "lawyer") {
      setSignatoryType("executor");
      setAutoSwitchedToExecutor(true);
    } else if (!hideLawyerSignatory && autoSwitchedToExecutor && signatoryType === "executor" && contactDefaultSignatoryType === "lawyer") {
      setSignatoryType("lawyer");
      setAutoSwitchedToExecutor(false);
    } else if (!hideLawyerSignatory && !signatoryTypeChosenByUser.current) {
      setSignatoryType(contactDefaultSignatoryType);
    }
  }, [hideLawyerSignatory, contactDefaultSignatoryType]);
  const [previewForm, setPreviewForm] = useState<{ code: string; name: string; targetBeneficiaryId?: string; deponentId?: string; selectedContactId?: string; deliveryId?: string; citationRecordId?: string; affidavitOrdinal?: string; consentNomination?: { nomineeContactId: string; relationshipToNominee: string; beneficiarySharePercentage: number }; consentAppointAdministrator?: { administratorContactId: string }; overrides?: Record<string, unknown>; generateAnyway?: boolean } | null>(null);
  // Form-details dialog state — one instance serves signed and affidavit forms.
  // An Optional P44 confirmation carries its document-only applicability context
  // here so the required signing choice does not silently drop it.
  const [detailsForm, setDetailsForm] = useState<{
    code: string;
    name: string;
    deponentId?: string;
    /** P46 is generated for one recorded delivery recipient. */
    deliveryId?: string;
    /** P34 is generated for one recorded citation. */
    citationRecordId?: string;
    optionalContext?: {
      overrides?: Record<string, string | number | boolean>;
      generateAnyway: boolean;
      selectedContactId?: string;
    };
  } | null>(null);
  const [p8CoApplicantIntakeOpen, setP8CoApplicantIntakeOpen] = useState(false);
  const [p8GenerationError, setP8GenerationError] = useState("");
  // Task 13: `refusal` replaces a link that can never succeed unchanged; `regeneration` lets it be reviewed again.
  const [p8DownloadReady, setP8DownloadReady] = useState<{ delivery: PostDelivery; refusal?: string; regeneration?: Regeneration } | null>(null);
  // Browser attachment navigation has no completion callback. Preserve a
  // durable in-page recovery for every non-P8 form so an interrupted download
  // cannot look like a completed “Preparing…” state.
  const [documentGenerationRecovery, setDocumentGenerationRecovery] = useState<{
    formCode: string;
    formName: string;
    message: string;
    delivery?: PostDelivery;
    refusal?: string;
    regeneration?: Regeneration;
  } | null>(null);
  // Task 13: delivery feedback belongs to the estate page's owner when one is passed (r3: it survives a tab switch),
  // else to this Forms tab; a recovery button shows its own delivery in flight.
  const deliveryFeedback = useEstateFeedbackOwner(feedbackOwner, `forms:${estateId}`);
  const p8DownloadPending = useDeliveryPending(p8DownloadReady?.delivery);
  const recoveryDownloadPending = useDeliveryPending(documentGenerationRecovery?.delivery);
  // A link the server refuses for good (D6) is replaced by its refusal; any other outcome keeps it.
  const keepUsableLink = (formCode: string, delivery: PostDelivery) => (outcome: DeliveryOutcome) => {
    const refusal = unusableLinkMessage(outcome);
    if (refusal === null) return;
    if (formCode === "P8") setP8DownloadReady((current) => (current?.delivery === delivery ? { ...current, refusal } : current));
    else setDocumentGenerationRecovery((current) => (current?.delivery === delivery ? { ...current, refusal } : current));
  };
  // The single-form generation runs in flight (memory only), for "Review and generate again". A new link keeps
  // its run only when exactly one was in flight, so overlapping runs can never attach the wrong choices.
  const retainedRunsRef = useRef(new Set<Extract<Regeneration, { kind: "gate" }>>());
  // The panel whose "Review and generate again" is refreshing: it locks that button only, never on unrelated work.
  const [regeneratingSlot, setRegeneratingSlot] = useState<string | null>(null);
  const regeneratingSlotRef = useRef<string | null>(null);
  // A refusal removes the Download button a keyboard user just pressed: keep their place in that panel.
  const p8RecoveryFocusRef = useRef<HTMLButtonElement>(null);
  const recoveryFocusRef = useRef<HTMLButtonElement>(null);
  const p8Refusal = p8DownloadReady?.refusal;
  const recoveryRefusal = documentGenerationRecovery?.refusal;
  useEffect(() => {
    if (p8Refusal && (!document.activeElement || document.activeElement === document.body)) p8RecoveryFocusRef.current?.focus();
  }, [p8Refusal]);
  useEffect(() => {
    if (recoveryRefusal && (!document.activeElement || document.activeElement === document.body)) recoveryFocusRef.current?.focus();
  }, [recoveryRefusal]);
  // Optional-form popup state — Generate or Preview on any Optional row opens
  // the dialog with the intake questions that drive that form, answered for
  // THIS document only (RULES.md Rule 22; nothing is written to the estate).
  const [fixForm, setFixForm] = useState<{ code: string; name: string; intent: "generate" | "preview"; fromNaOverride?: boolean; estateSnapshot?: any; deponentSelectedContactId?: string } | null>(null);
  // Addendum 24.8: once a form dialog closes, the span until the server's
  // preflight/generate answer must show visible progress — a blank screen for
  // several seconds reads as a silent failure and invites a second click.
  // Depth-counted because an inline-fill re-check re-enters runWithPreflight.
  const [preflightBusy, setPreflightBusy] = useState<string | null>(null);
  const preflightBusyDepthRef = useRef(0);

  const [consentNominationDraft, setConsentNominationDraft] = useState<{
    beneficiaryId: string;
    beneficiaryName: string;
    intent: "preview" | "generate";
    nomineeContactId: string;
    relationshipToNominee: string;
    beneficiarySharePercentage: string;
    statutoryShareNote?: string;
    /** Task 13: a reopened consent keeps its original signing choices. */
    signatoryType?: string;
    signatureDate?: string;
  } | null>(null);
  const [consentAppointAdministratorDraft, setConsentAppointAdministratorDraft] = useState<{
    beneficiaryId: string;
    beneficiaryName: string;
    intent: "preview" | "generate";
    administratorContactId: string;
    signatoryType?: string;
    signatureDate?: string;
  } | null>(null);

  const beneficiaries = (contacts || []).filter(c => contactHasRole(c, "beneficiary"));
  const consentNominees = (contacts || []).filter((contact) => Boolean(contact.name?.trim()) && isLivingContact(contact));
  const consentAdministrators = (contacts || []).filter((contact) => Boolean(contact.name?.trim()) && isConsentAdministratorCandidate(contact));
  const administratorConsentAvailable = estateWillStatus(estate as any) === "no_will";
  const { data: allRecipients } = trpc.document.getLetterRecipients.useQuery({ estateId });
  const { data: consentDistribution } = trpc.distribution.compute.useQuery({ estateId });
  const consentNominationSharePrefill = (beneficiary: any) => {
    const storedPercentage = beneficiary?.shareType === "percentage"
      ? String(beneficiary.share || "").replace(/%$/, "")
      : "";
    // A consent must not turn an unfinished statutory distribution into a zero.
    // When the canonical, recorded no-will calculation has actually selected the
    // WESA s.21(6) half-residue path for this signer, use that result instead of
    // a stale/default manual 0. Other paths retain their recorded per-document
    // percentage for the signer to confirm.
    const halfResidueShare = estateWillStatus(estate as any) === "no_will"
      ? (consentDistribution?.shares || []).find((share: any) =>
        String(share.contactId) === String(beneficiary?.id)
        && isDeterminedOneHalfResidueDescendantShare(share, contacts || []),
      )
      : undefined;
    return halfResidueShare
      ? {
        percentage: "50",
        note: "The recorded WESA calculation gives the signer one-half of the residue. The source template’s percentage variable is prefilled as 50 for confirmation; it does not change the estate record.",
      }
      : { percentage: storedPercentage, note: undefined };
  };

  const generateMutation = trpc.document.generate.useMutation({
    onSuccess: (data, variables) => {
      utils.document.list.invalidate({ estateId });
      const formName = FORM_CATALOG.find((form) => form.code === variables.formCode)?.name || variables.formCode;
      const slot = variables.formCode === "P8" ? "p8-recovery" : "form-recovery";
      if (!isPostDelivery(data.delivery)) {
        deliveryFeedback.retire(slot);
        const message = variables.formCode === "P4"
          ? p4GenerationFailureMessage("", true)
          : variables.formCode === "P3"
          ? "The form response did not include a download link. Please try again."
          : `${variables.formCode} was not generated because no download link was returned. Try again. If the problem continues, report it from Settings.`;
        if (variables.formCode === "P8") {
          setP8DownloadReady(null);
          setP8GenerationError(`Form P8 was not generated. ${message}`);
          // TanStack invokes onError for callback failures. Reject here so the
          // existing pre-generation continuation remains open and retryable,
          // rather than treating an absent attachment URL as a completed P8.
          throw new Error(message);
        } else {
          setDocumentGenerationRecovery({ formCode: variables.formCode, formName, message });
          // Preserve the established P3 dialog retry contract: the response
          // lacks a usable file, so it must not be treated as a success.
          // A response without an attachment is never a completed generation.
          // Reject for every form so the preflight popup stays retryable instead
          // of reporting a false success after Generate Anyway.
          throw new Error(message);
        }
        return;
      }
      // Task 13: what a refused link can replay — the consent's exact answers, or the one run in flight.
      const runs = Array.from(retainedRunsRef.current);
      const run = runs.length === 1 ? runs[0] : undefined;
      const regeneration: Regeneration | undefined = variables.formCode === "CONSENT_NOMINATION" && variables.consentNomination && variables.targetBeneficiaryId
        ? {
          kind: "consent-nomination",
          beneficiaryId: variables.targetBeneficiaryId,
          nomineeContactId: variables.consentNomination.nomineeContactId,
          relationshipToNominee: variables.consentNomination.relationshipToNominee,
          share: variables.consentNomination.beneficiarySharePercentage,
          signatoryType: variables.signatoryType,
          signatureDate: variables.signatureDate,
        }
        : variables.formCode === "CONSENT_APPOINT_ADMINISTRATOR" && variables.consentAppointAdministrator && variables.targetBeneficiaryId
        ? {
          kind: "consent-administrator",
          beneficiaryId: variables.targetBeneficiaryId,
          administratorContactId: variables.consentAppointAdministrator.administratorContactId,
          signatoryType: variables.signatoryType,
          signatureDate: variables.signatureDate,
        }
        : run && run.formCodes[0] === variables.formCode ? { ...run, sent: variables } : undefined;
      if (variables.formCode === "P8") {
        // Navigation has no completion callback: retain an explicit, durable
        // second download action so a browser-level attachment failure never
        // leaves P8 at “Preparing…” with no usable recovery.
        setP8GenerationError("");
        setP8DownloadReady({ delivery: data.delivery, regeneration });
      } else {
        setDocumentGenerationRecovery({
          formCode: variables.formCode,
          formName,
          message: `${variables.formCode} is ready. If the download did not start, use Download ${variables.formCode}.`,
          delivery: data.delivery,
          regeneration,
        });
      }
      deliverAndAnnounce(data.delivery, "Form generated", {
        feedback: { owner: deliveryFeedback, slot },
        onOutcome: keepUsableLink(variables.formCode, data.delivery),
      });
    },
    onError: (err, variables) => {
      deliveryFeedback.retire(variables.formCode === "P8" ? "p8-recovery" : "form-recovery");
      const rawMessage = err.message || "Generation failed. Please try again.";
      const message = variables.formCode === "P4"
        ? (rawMessage.startsWith("P4 was not generated because no DOCX download was returned")
          ? rawMessage
          : p4GenerationFailureMessage(rawMessage))
        : rawMessage;
      const formName = FORM_CATALOG.find((form) => form.code === variables.formCode)?.name || variables.formCode;
      if (variables.formCode === "P8") {
        setP8DownloadReady(null);
        setP8GenerationError(`Form P8 was not generated. ${message}`);
      } else {
        setDocumentGenerationRecovery({
          formCode: variables.formCode,
          formName,
          message: `${variables.formCode} was not generated. ${message}`,
        });
      }
      if (variables.formCode === "P4" || variables.formCode === "P7" || variables.formCode === "P10") {
        toast.error(message, { duration: Infinity });
      } else {
        toast.error(message);
      }
    },
  });
  // Persists inline-filled blank fields from the PreGenerateDialog ("Also save
  // these to the intake"). Same invalidation set the applicability dialog used
  // when it still persisted (2026-08-05 review, MEDIUM): these columns can move
  // form buckets, deadlines/readiness, the PFA fee basis, notice recipients,
  // and distribution.
  const inlineFillSaveMutation = trpc.estate.update.useMutation({
    onSuccess: () => {
      void utils.estate.get.invalidate({ id: estateId });
      void utils.readiness.check.invalidate({ estateId });
      void utils.readiness.timeline.invalidate({ estateId });
      void utils.deadline.list.invalidate();
      void utils.document.preflight.invalidate();
      void utils.document.preflightMany.invalidate();
      void utils.inventory.totals.invalidate({ estateId });
      void utils.delivery.getRecipients.invalidate({ estateId });
      void utils.distribution.compute.invalidate({ estateId });
      void utils.document.getLetterRecipients.invalidate({ estateId });
    },
    onError: (err) => {
      toast.error(`Failed to save to intake: ${err.message}`);
    },
  });
  // Inline "Mark received" checkboxes in the PreGenerateDialog (Rule 24):
  // receipt is a real record persisted through the same requiredDoc.upsert the
  // checklist card uses — never an override.
  const requiredDocInlineMutation = trpc.requiredDoc.upsert.useMutation({
    onError: (err) => {
      toast.error(err.message || "Could not record the document as received.");
    },
  });
  // Inline row edits from the PreGenerateDialog (wave 2, Nick 2026-08-21):
  // contact/inventory values PERSIST through the same mutations the
  // Contacts/Inventory tabs use — there is no override channel for them
  // (shared/formOverrides.ts is estate-only), and document.generate re-reads
  // the DB, so persistence is how a row value reaches the render.
  const pgContactInlineMutation = trpc.contact.update.useMutation({
    onError: (err) => { toast.error(err.message || "Could not save the contact field."); },
  });
  const pgP1ContactCreateMutation = trpc.contact.create.useMutation({
    onError: (err) => { toast.error(err.message || "Could not add the P1 contact."); },
  });
  const pgP1WillUploadMutation = trpc.estate.uploadWill.useMutation({
    onError: (err) => { toast.error(err.message || "Could not upload the will."); },
  });
  const pgP1ForeignGrantUploadMutation = trpc.estate.uploadForeignGrant.useMutation({
    onError: (err) => { toast.error(err.message || "Could not upload the foreign grant."); },
  });
  const pgP1CodicilUploadMutation = trpc.estate.uploadCodicil.useMutation({
    onError: (err) => { toast.error(err.message || "Could not upload the codicil."); },
  });
  const pgInventoryInlineMutation = trpc.inventory.update.useMutation({
    onError: (err) => { toast.error(err.message || "Could not save the inventory field."); },
  });
  const pgInventoryCreateMutation = trpc.inventory.create.useMutation({
    onError: (err) => { toast.error(err.message || "Could not add the inventory item."); },
  });
  const packageMutation = trpc.document.generatePackage.useMutation({
    onSuccess: (data) => {
      void utils.document.list.invalidate({ estateId });
      void utils.document.versions.invalidate({ estateId });
      // Validate, download, THEN announce - never a success toast over a
      // missing download (same shape as allP8Mutation below).
      if (!isPostDelivery(data.delivery)) {
        throw new Error("Package generation did not return a download. Please try again.");
      }
      deliverAndAnnounce(data.delivery, "Grant package generated", { feedback: { owner: deliveryFeedback, slot: "package" } });
    },
    onError: (err) => { toast.error(err.message || "Package generation failed. Please try again."); },
  });
  const allLettersMutation = trpc.document.generateAllLetters.useMutation({
    onSuccess: (data) => {
      if (!isPostDelivery(data.delivery)) {
        throw new Error("Letter generation did not return a download. Please try again.");
      }
      deliverAndAnnounce(data.delivery, "Generated letters", { feedback: { owner: deliveryFeedback, slot: "letters" } });
    },
    onError: (err) => { toast.error(err.message || "Letter generation failed. Please try again."); },
  });
  const allP8Mutation = trpc.document.generateAllP8.useMutation({
    onSuccess: (data) => {
      if (!isPostDelivery(data.delivery) || data.count < 1) {
        throw new Error("P8 generation did not return a download. Please try again.");
      }
      deliverAndAnnounce(data.delivery, `Generated ${data.count} P8 affidavit${data.count === 1 ? "" : "s"}`, { feedback: { owner: deliveryFeedback, slot: "p8-all" } });
    },
    onError: (err) => { toast.error(err.message || "P8 generation failed. Please try again."); },
  });

  // Pre-generate dialog state — a single dialog serves every Generate call site.
  const [pgOpen, setPgOpen] = useState(false);
  const [pgFormName, setPgFormName] = useState<string>("");
  const [pgReports, setPgReports] = useState<FormGapReport[]>([]);
  const [pgProceeding, setPgProceeding] = useState(false);
  const [pgSucceeded, setPgSucceeded] = useState(false);
  const [pgAction, setPgAction] = useState<"generate" | "preview" | "download">("generate");
  const pgProceedRef = useRef<null | PreflightMutate>(null);
  // The pending single-form generation, kept so the dialog's inline-fill
  // "Apply & re-check" can re-enter runWithPreflight with the typed values
  // merged into the SAME overrides channel the pending mutation will use.
  // Null for package/bulk runs — those accept no overrides (Rule 22 §6), so
  // the dialog never offers inline editing for them.
  const pgPendingRef = useRef<null | {
    formCodes: ReadonlyArray<string>;
    formName: string;
    renderContext?: PreflightRenderContext;
    action: "generate" | "preview" | "download";
    /** Task 13: the signing date this dialog's check used (the one its continuation prints). */
    checkedSignatureDate?: string;
  }>(null);
  // Covers the WHOLE apply (save + gap re-check), not just the save mutation —
  // the re-check is the longer half, and an un-disabled button there allows a
  // second apply to interleave with the first.
  const pgApplyingRef = useRef(false);
  // Retry-only state is scoped to the exact pending single-form operation and
  // contains no document bytes. A replacement/cancelled pending object cannot
  // consume it; acknowledged keys clear only their superseded draft answers.
  const pgCanonicalRetryRef = useRef(new WeakMap<object, { savedKeys: Set<string> }>());
  // Loop 3 (Nick 2026-09-02): "Generate anyway" now applies unsaved inline
  // values first. When that apply's re-check comes back all-green,
  // runWithPreflight runs the action itself and consumes the refs — the
  // dialog's follow-on onProceed must then be a quiet no-op, not the XC-12
  // "Nothing is pending" error (the document WAS produced).
  const pgCompletedInApplyRef = useRef(false);
  const [pgApplying, setPgApplying] = useState(false);
  // Invalidates every suspended preflight/proceed continuation when the user
  // closes, cancels, jumps, or starts a newer dialog. A hidden dialog must never
  // generate later when an awaited save/preflight resumes.
  const pgAttemptRef = useRef(0);
  // One-shot guard for quick-add inventory creates (wave 2): the dialog clears
  // its addDraft only on a CONFIRMED apply, so a retry after
  // create-succeeded-then-re-check-failed would re-send the same createInventory
  // row and record a duplicate sworn asset. Keyed by the row payload; cleared
  // when a FRESH gap dialog begins (runWithPreflight's show branch, where
  // pgPendingRef is null — a re-check re-entry preserves it). No close-path
  // clearing: a closed dialog can run no applies, and the next open resets.
  const pgCreatedRowKeysRef = useRef<Set<string>>(new Set());

  /**
   * Gate a generate action behind the pre-flight gap check.
   * - `formCodes`: single-element for one form, multi-element for package / all-letters / all-P8s.
   * - `formName`: human label shown in the dialog title.
   * - `doMutate`: the existing mutation invocation, called only after the user confirms.
   *
   * P19 (externally issued grant certificate) is excluded from generation and
   * never routed through this helper.
   */
  // Returns true when the flow completed (mutation fired or the gap dialog
  // was shown); false when the preflight fetch itself failed. Most callers
  // ignore it — handlePgApplyInline needs it to avoid banking values that
  // never reached the pending context (Addendum 24.1).
  async function runWithPreflight(...args: Parameters<typeof runWithPreflightInner>): Promise<boolean> {
    preflightBusyDepthRef.current += 1;
    setPreflightBusy(args[1]);
    try {
      return await runWithPreflightInner(...args);
    } finally {
      if (--preflightBusyDepthRef.current === 0) setPreflightBusy(null);
    }
  }
  async function runWithPreflightInner(
    formCodes: ReadonlyArray<string>,
    formName: string,
    doMutate: PreflightMutate,
    renderContext?: PreflightRenderContext,
    action: "generate" | "preview" | "download" = "generate",
    continuationIsCurrent: () => boolean = () => true,
    onRechecked?: () => void,
    hasNewerInlineEdits?: () => boolean,
  ): Promise<boolean> {
    // Overrides ride the single-form check only. preflightMany backs the
    // package and bulk buttons, which are hard-gated by design — a one-off
    // answer must not reshape a filing package (RULES.md Rule 22).
    const singleForm = formCodes.length === 1 && !renderContext?.forceMany;
    if (singleForm && renderContext?.supportsOverrides === true && !renderContext.packageMode && formCodes[0] === "P5") {
      renderContext = { ...renderContext, ...manualP5DraftOptions("P5") };
    }
    // Task 13: a replayed review checks its retained date; every other check uses the current one.
    const checkedSignatureDate = renderContext?.signatureDate ?? signatureDate;
    let reports: FormGapReport[];
    try {
      reports = singleForm
        ? [await utils.document.preflight.fetch({
            estateId,
            formCode: formCodes[0],
            signatureDate: checkedSignatureDate,
            selectedContactId: renderContext?.selectedContactId,
            targetContactId: renderContext?.targetContactId,
            targetDeliveryId: renderContext?.targetDeliveryId,
            citationRecordId: renderContext?.targetCitationRecordId,
            overrides: renderContext?.overrides as Record<string, string | number | boolean> | undefined,
            generateAnyway: renderContext?.generateAnyway,
          })]
        : await utils.document.preflightMany.fetch({
            estateId,
            formCodes: [...formCodes],
            signatureDate,
            packageMode: renderContext?.packageMode === true,
          });
    } catch (error: any) {
      toast.error(error?.message || `Unable to check ${formName} requirements. Try again.`);
      return false;
    }

    if (!continuationIsCurrent()) return false;
    onRechecked?.();
    const allOk = reports.every((r) => r.ok);
    // Manual P16 always reviews page, line, exact words, and presence once:
    // populated text can still need correction. A successful inline re-check
    // uses the open dialog's existing continuation and does not reopen it.
    const reviewP16 = singleForm && formCodes[0] === "P16"
      && renderContext?.supportsOverrides === true && !renderContext.packageMode && !pgOpen;
    // Task 13: a regeneration is always reviewed first; an inline re-check of the open dialog proceeds as before.
    const reviewFirst = renderContext?.reviewBeforeGenerate === true && !pgOpen;
    // A completed check describes the submitted snapshot, not newer typing in
    // the still-open popup. Preserve that input for review without changing any
    // server gap, applicability rule, or bulk/package behavior.
    if (allOk && !reviewP16 && !reviewFirst && !hasNewerInlineEdits?.()) {
      // Close the dialog BEFORE mutating: an inline-fill re-check re-enters
      // this function with the dialog open, and firing the mutation while it
      // showed would leave a live "Generate anyway" pointing at a consumed
      // thunk (latent since PROMPT 40; harmless only while re-entry didn't exist).
      const dialogWasOpen = pgOpen;
      const attempt = pgAttemptRef.current;
      setPgOpen(false);
      pgProceedRef.current = null;
      pgPendingRef.current = null;
      const run = retainedRun(formCodes, formName, doMutate, renderContext, action, checkedSignatureDate);
      if (run) retainedRunsRef.current.add(run);
      try {
        await doMutate(renderContext?.overrides);
        return true;
      } catch {
        // mutateAsync invokes the mutation's existing onError toast. Returning
        // false prevents an unhandled rejection and tells inline Apply not to
        // bank a continuation whose render failed.
        //
        // 2026-08-21 goal loop: when this all-green run came FROM the open gap
        // dialog (an inline-fill re-check), a failed generation used to close
        // everything and drop the merged overrides — with save-to-intake
        // unchecked the user lost their typed answers entirely. Restore the
        // continuation and reopen the (now all-green) dialog so Proceed is a
        // real retry carrying the same merged context. Direct first-click
        // paths (no dialog was open) keep the old toast-only behavior, and a
        // NEWER dialog started meanwhile (attempt token moved) is never
        // clobbered.
        if (dialogWasOpen && pgAttemptRef.current === attempt) {
          pgProceedRef.current = doMutate;
          pgPendingRef.current = singleForm && renderContext?.supportsOverrides === true
            ? { formCodes, formName, renderContext, action, checkedSignatureDate }
            : null;
          setPgReports(reports);
          setPgFormName(formName);
          setPgAction(action);
          pgAttemptRef.current += 1;
          setPgProceeding(false);
          setPgSucceeded(false);
          setPgOpen(true);
        }
        return false;
      } finally {
        if (run) retainedRunsRef.current.delete(run);
      }
    }

    // Show the dialog; store the mutate thunk in a ref so onProceed can invoke
    // it, and the full pending call so an inline-fill re-check can re-enter
    // with merged overrides (single-form only — bulk accepts none).
    setPgReports(reports);
    setPgFormName(formName);
    setPgAction(action);
    pgAttemptRef.current += 1;
    // A fresh gap dialog starts a fresh quick-add ledger — but only when this
    // is a NEW dialog, not the inline-fill re-check re-entering the open one
    // (pgPendingRef survives a re-check; see handlePgApplyInline).
    if (pgPendingRef.current === null) pgCreatedRowKeysRef.current = new Set();
    pgCompletedInApplyRef.current = false;
    setPgProceeding(false);
    setPgSucceeded(false);
    pgProceedRef.current = doMutate;
    pgPendingRef.current = singleForm && renderContext?.supportsOverrides === true
      ? { formCodes, formName, renderContext, action, checkedSignatureDate }
      : null;
    setPgOpen(true);
    return true;
  }

  async function handlePgProceed(proceedOptions?: PreflightProceedOptions): Promise<void> {
    const fn = pgProceedRef.current;
    const pending = pgPendingRef.current;
    const pendingOverrides = pgPendingRef.current?.renderContext?.overrides;
    pgProceedRef.current = null;
    pgPendingRef.current = null;
    if (fn !== null) {
      const attempt = ++pgAttemptRef.current;
      setPgProceeding(true);
      setPgSucceeded(false);
      const run = pending ? retainedRun(pending.formCodes, pending.formName, fn, pending.renderContext, pending.action, pending.checkedSignatureDate) : null;
      if (run) retainedRunsRef.current.add(run);
      try {
        const affidavitDraftProceed = proceedOptions?.generateAnyway === true || (pgReports.length === 1
          && ["P3", "P4"].includes(pgReports[0]?.formCode || "")
          && pgReports[0]?.ok === false);
        await fn(pendingOverrides, affidavitDraftProceed ? { generateAnyway: true } : undefined);
        if (pgAttemptRef.current === attempt) {
          setPgProceeding(false);
          setPgSucceeded(true);
        }
      } catch {
        if (pgAttemptRef.current === attempt) {
          // The mutation's onError owns user-facing copy. Restore the consumed
          // continuation so the still-open dialog offers a real retry.
          pgProceedRef.current = fn;
          pgPendingRef.current = pending;
          setPgProceeding(false);
          setPgSucceeded(false);
        }
      } finally {
        if (run) retainedRunsRef.current.delete(run);
      }
    } else if (pgCompletedInApplyRef.current) {
      // The apply that "Generate anyway" ran first came back all-green and
      // already produced the document (loop 3) — nothing left to do.
      pgCompletedInApplyRef.current = false;
      setPgOpen(false);
    } else {
      // XC-12 (Nick 2026-09-01): a consumed continuation must never leave a
      // live-looking Generate button — close the dialog and say so instead of
      // a silent no-op on every further click.
      setPgOpen(false);
      toast.error("Nothing is pending to generate — reopen the form and try again.");
    }
  }

  // Task 13: only a single-form generation that takes per-run answers is replayable — never a preview, package or
  // bulk run. The continuation keeps every original choice; the date is the one this run's check used.
  function retainedRun(
    formCodes: ReadonlyArray<string>,
    formName: string,
    doMutate: PreflightMutate,
    renderContext: PreflightRenderContext | undefined,
    action: "generate" | "preview" | "download",
    checkedSignatureDate: string | undefined,
  ): Extract<Regeneration, { kind: "gate" }> | null {
    return action === "generate" && formCodes.length === 1 && renderContext?.supportsOverrides === true && !renderContext.forceMany && !renderContext.packageMode
      ? { kind: "gate", formCodes, formName, doMutate, renderContext, signatureDate: checkedSignatureDate ?? renderContext.signatureDate ?? signatureDate }
      : null;
  }

  // Task 13 "Review and generate again": refresh the facts, then review the retained run (nothing is generated
  // until the user acts in that review) or reopen the consent with its retained answers.
  async function regenerate(slot: string, regeneration: Regeneration): Promise<void> {
    // Only this panel's own refresh locks its button; a second press while it runs does nothing.
    if (regeneratingSlotRef.current === slot) return;
    regeneratingSlotRef.current = slot;
    setRegeneratingSlot(slot);
    // A dialog the user opens meanwhile wins: the review never takes it over.
    const attempt = pgAttemptRef.current;
    const stillCurrent = () => pgAttemptRef.current === attempt;
    preflightBusyDepthRef.current += 1;
    setPreflightBusy(regeneration.kind === "gate" ? regeneration.formName : regeneration.kind === "consent-nomination" ? "Consent and Nomination" : "Consent to Appointment of an Administrator");
    try {
      // A failed refresh never blocks the review: the review's own check is always fetched fresh.
      await Promise.all([
        utils.estate.get.invalidate({ id: estateId }),
        utils.contact.list.invalidate({ estateId }),
        utils.document.list.invalidate({ estateId }),
        utils.inventory.list.invalidate({ estateId }),
        utils.delivery.list.invalidate({ estateId }),
        utils.delivery.getRecipients.invalidate({ estateId }),
        utils.citation.list.invalidate({ estateId }),
        utils.document.getLetterRecipients.invalidate({ estateId }),
      ]).catch(() => undefined);
      if (!stillCurrent()) return;
      if (regeneration.kind === "gate") {
        await runWithPreflight(
          regeneration.formCodes,
          regeneration.formName,
          regeneration.doMutate,
          {
            ...regeneration.renderContext,
            reviewBeforeGenerate: true,
            signatureDate: regeneration.signatureDate,
            // r3.1: names from the contacts just refreshed, so a renamed deponent reads as it will print.
            retainedChoices: regeneration.sent ? retainedChoicesOf(regeneration.sent, utils.contact.list.getData({ estateId })) : [],
            retainedPrimaryAffidavit: (PRIMARY_AFFIDAVIT_FORMS as readonly string[]).includes(regeneration.formCodes[0]),
          },
          "generate",
          stillCurrent,
        );
        return;
      }
      const refreshed = utils.contact.list.getData({ estateId }) ?? [];
      const nameOf = (contactId: string) => refreshed.find((contact) => String(contact.id) === contactId)?.name || "this beneficiary";
      // A retained person no longer offered for this consent is cleared, so the user chooses again.
      const offered = (contactId: string, eligible: (contact: (typeof refreshed)[number]) => boolean) =>
        refreshed.some((contact) => String(contact.id) === contactId && Boolean(contact.name?.trim()) && eligible(contact)) ? contactId : "";
      if (regeneration.kind === "consent-nomination") {
        setConsentNominationDraft((current) => current ?? {
          beneficiaryId: regeneration.beneficiaryId,
          beneficiaryName: nameOf(regeneration.beneficiaryId),
          intent: "generate",
          nomineeContactId: offered(regeneration.nomineeContactId, isLivingContact),
          relationshipToNominee: regeneration.relationshipToNominee,
          beneficiarySharePercentage: String(regeneration.share),
          signatoryType: regeneration.signatoryType,
          signatureDate: regeneration.signatureDate,
        });
      } else {
        setConsentAppointAdministratorDraft((current) => current ?? {
          beneficiaryId: regeneration.beneficiaryId,
          beneficiaryName: nameOf(regeneration.beneficiaryId),
          intent: "generate",
          administratorContactId: offered(regeneration.administratorContactId, isConsentAdministratorCandidate),
          signatoryType: regeneration.signatoryType,
          signatureDate: regeneration.signatureDate,
        });
      }
    } finally {
      if (regeneratingSlotRef.current === slot) {
        regeneratingSlotRef.current = null;
        setRegeneratingSlot(null);
      }
      if (--preflightBusyDepthRef.current === 0) setPreflightBusy(null);
    }
  }

  function handlePgCancel(): void {
    pgCompletedInApplyRef.current = false;
    pgAttemptRef.current += 1;
    pgProceedRef.current = null;
    pgPendingRef.current = null;
    setPgOpen(false);
    setPgSucceeded(false);
    setPgProceeding(false);
  }

  function handlePgJumpToTab(tab: ReadinessTab): void {
    if (onNavigateToTab) {
      onNavigateToTab(tab);
    }
    handlePgCancel();
  }

  /**
   * Rule 24 escape hatch: the not-applicable hard block on a user-initiated
   * single-form action re-routes through the applicability popup instead of
   * dead-ending on a disabled "Blocked" button. The popup re-enters the
   * unchanged pipeline with generateAnyway, so the server-side default gate
   * (assertFormApplicable) is untouched. Download re-routes as a generate and
   * starts the browser download through the same established success path.
   *
   * Post-validation fix (Addendum 24.1): the handler requires the pending
   * single-form ref — pgReports.length was a false proxy ("All P8" takes the
   * single-report branch and "All Letters" always merges to one report, so a
   * bulk click could reach the escape, crossing Rule 22 §6). fromNaOverride
   * rides to the fix dialog so a stale client-side verdict cannot drop
   * generateAnyway and loop the user back into the same hard block.
   */
  async function handlePgOverrideNotApplicable(): Promise<void> {
    const pending = pgPendingRef.current;
    const code = pgReports[0]?.formCode;
    if (!pending || !code) return;
    const name = FORM_CATALOG.find((f) => f.code === code)?.name || code;
    const intent = pgAction === "preview" ? "preview" : "generate";
    // The user's deponent choice (FormDetailsDialog selectedContactId) rides
    // the re-route — the escape must not silently swap the sworn deponent for
    // the server default (2026-08-21 goal loop, P4 dead-end finding).
    const deponentSelectedContactId = pending.renderContext?.selectedContactId;
    handlePgCancel();
    try {
      // Invalidate first: the server's preflight verdict was fresh, while the
      // mounted estate prop may be stale. Seed the answer dialog from the same
      // authoritative record, then send every displayed answer as overrides.
      await utils.estate.get.invalidate({ id: estateId });
      const estateSnapshot = await utils.estate.get.fetch({ id: estateId });
      setFixForm({ code, name, intent, fromNaOverride: true, estateSnapshot, deponentSelectedContactId });
    } catch (error: any) {
      toast.error(error?.message || "Unable to refresh the estate facts. Try again.");
    }
  }

  /**
   * Inline-fill continuation from the PreGenerateDialog: the user typed values
   * for blank required fields and asked to re-check. The values merge into the
   * SAME per-document overrides channel the pending mutation will use, and the
   * gap check re-runs against them — so what cleared the gap is exactly what
   * the document will print (Rule 22's one-merge principle, client side).
   *
   * `saveToIntake` additionally persists the typed values through the normal
   * estate.update path (CAS-guarded). Blank fields are missing DATA, not
   * overrides of a wrong value — the lawyer should not have to retype the
   * deceased's name on every form. Applicability answers never take this path;
   * they stay transient (Rule 22 §3).
   */
  async function handlePgApplyInline(
    values: Record<string, string | number>,
    saveToIntake: boolean,
    docKeysReceived?: string[],
    rowEdits?: PreGenerateRowEdits,
    p1Actions?: P1InlineActions,
    canonicalEstate?: Record<string, string | number>,
    canonicalObserver?: CanonicalPopupApplyObserver,
  ): Promise<boolean> {
    // A filing-type answer can establish the will's physical/electronic medium.
    // Couple it before BOTH persistence and the transient render override so
    // the re-check and every downstream form read the same complete fact set.
    const effectiveValues = coupleWillFilingTypeFacts({ ...values, ...(p1Actions?.estate ?? {}) });
    const pending = pgPendingRef.current;
    const fn = pgProceedRef.current;
    const anyDocs = Array.isArray(docKeysReceived) && docKeysReceived.length > 0;
    const anyRows = rowEdits !== undefined
      && (rowEdits.contacts.length > 0 || rowEdits.inventory.length > 0 || rowEdits.createInventory.length > 0);
    const anyP1Actions = p1Actions !== undefined && (p1Actions.contacts.length > 0 || p1Actions.uploads.length > 0);
    const anyCanonicalEstate = Object.keys(canonicalEstate ?? {}).length > 0;
    const canonicalRetry = pending !== null && canonicalEstate !== undefined && pgCanonicalRetryRef.current.has(pending);
    if (!pending || !fn || (Object.keys(effectiveValues).length === 0 && !anyDocs && !anyRows && !anyP1Actions && !anyCanonicalEstate && !canonicalRetry)) return false;
    if (pgApplyingRef.current) return false; // re-entrancy: one apply at a time

    // This function suspends twice (the save, then the gap re-check). In that
    // window the user can still hit Generate anyway, Cancel, or a jump — each
    // of which consumes or clears the pending refs. Resuming blind would fire
    // the mutation a SECOND time, producing two filed drafts where the first
    // one silently lacked the typed values. The token is the guard: the refs
    // must still be the ones this call captured when it resumes.
    pgApplyingRef.current = true;
    setPgApplying(true);
    const stillCurrent = (): boolean =>
      pgPendingRef.current === pending && pgProceedRef.current === fn;
    if (anyCanonicalEstate && !pgCanonicalRetryRef.current.has(pending)) {
      pgCanonicalRetryRef.current.set(pending, { savedKeys: new Set() });
    }
    try {
      // Addendum 24.1: a doc-only apply must not call estate.update with an
      // empty patch — that bumps the CAS revision and writes an empty audit
      // row for nothing (and a concurrent editor's save would 409 against it).
      let intakeValues = Object.fromEntries(
        Object.entries({ ...(saveToIntake ? effectiveValues : {}), ...canonicalEstate })
          .filter(([key]) => !key.startsWith("p8PrimaryAffidavit")),
      );
      if (Object.keys(intakeValues).length > 0) {
        try {
          const currentEstate = utils.estate.get.getData({ id: estateId }) ?? estate;
          const currentRevision = currentEstate?.revision;
          // Match the existing API boundary on the complete mixed patch before
          // acknowledging it; no new coupling or rule is introduced here.
          if (anyCanonicalEstate) intakeValues = coupleWillFilingTypeFacts(intakeValues, currentEstate);
          const result = await inlineFillSaveMutation.mutateAsync({
            id: estateId,
            expectedRevision: currentRevision,
            data: intakeValues,
          });
          // A write acknowledgement is independent of later cache/invalidation,
          // other-record saves and preflight success. Do not lose its revision.
          if (anyCanonicalEstate || canonicalObserver) {
            const retry = pgCanonicalRetryRef.current.get(pending) ?? { savedKeys: new Set<string>() };
            for (const key of Object.keys(canonicalEstate ?? {})) retry.savedKeys.add(key);
            // A filing-only write still has an offered canonical observer.
            // Bank its actual acknowledgement and permit a write-free recheck.
            pgCanonicalRetryRef.current.set(pending, retry);
            if (stillCurrent()) canonicalObserver?.onSaved({
              estateId, revision: result.revision,
              record: { ...currentEstate, ...intakeValues, revision: result.revision },
            });
          }
          // Publish the patch + returned CAS revision to the mounted estate query
          // immediately so a follow-on write cannot reuse the stale revision.
          utils.estate.get.setData({ id: estateId }, (current) => current
            ? ({ ...current, ...intakeValues, revision: result.revision } as typeof current)
            : current);
        } catch {
          // Toast fired in onError. Keep the dialog open with the typed values
          // intact — a failed save must not silently downgrade to override-only,
          // because the user was told these values would reach the intake.
          // Refetch first: a CAS conflict means the cached revision is stale,
          // and without this the retry replays the same losing revision forever.
          void utils.estate.get.invalidate({ id: estateId });
          return false;
        }
      }

      // Document receipts are records, not overrides — persist each through
      // requiredDoc.upsert, then drop the cached preflight so the re-check
      // below reads the fresh receipt (same query input = same cache key).
      if (anyDocs) {
        try {
          for (const docKey of docKeysReceived!) {
            await requiredDocInlineMutation.mutateAsync({ estateId, docKey, received: true });
          }
          void utils.requiredDoc.list.invalidate({ estateId });
          void utils.readiness.check.invalidate({ estateId });
          await utils.document.preflight.invalidate();
        } catch {
          return false; // toast fired in onError; keep the dialog open
        }
      }

      // Contact/inventory row edits are records too (wave 2) — persist through
      // the tabs' own mutations, replicate the tabs' derived-state
      // invalidations (their helpers live inside ContactsTab/InventoryTab and
      // are unreachable here), then drop the cached preflight: a persisted row
      // edit leaves the preflight query key unchanged, exactly like a receipt.
      if (anyRows) {
        try {
          for (const edit of rowEdits!.contacts) {
            await pgContactInlineMutation.mutateAsync({ id: edit.id, estateId, data: edit.data });
          }
          for (const edit of rowEdits!.inventory) {
            await pgInventoryInlineMutation.mutateAsync({ id: edit.id, estateId, data: edit.data });
          }
          for (const row of rowEdits!.createInventory) {
            // Skip a row this dialog already persisted on an earlier Apply
            // whose re-check then failed — the dialog keeps the draft pending,
            // but re-creating it would duplicate a sworn asset.
            const createdKey = JSON.stringify(row);
            if (pgCreatedRowKeysRef.current.has(createdKey)) continue;
            await pgInventoryCreateMutation.mutateAsync({
              estateId,
              // Idempotency id minted by the dialog: a retry after a
              // committed-but-rejected create replays it and the server
              // resolves to the committed row (2026-08-21 goal loop).
              ...(typeof row.id === "string" && row.id ? { id: row.id } : {}),
              category: String(row.category) as "real_property" | "tangible" | "financial",
              description: String(row.description ?? ""),
              location: (["unknown", "in_bc", "outside_bc"].includes(String(row.location))
                ? String(row.location) : "unknown") as "unknown" | "in_bc" | "outside_bc",
              value: Number(row.value ?? 0),
              valueRecorded: row.valueRecorded === 1 ? 1 : 0,
              passesToPersonalRepresentative: (["", "yes", "no"].includes(String(row.passesToPersonalRepresentative ?? ""))
                ? String(row.passesToPersonalRepresentative ?? "") : "") as "" | "yes" | "no",
            });
            pgCreatedRowKeysRef.current.add(createdKey);
          }
          void utils.contact.list.invalidate({ estateId });
          void utils.delivery.getRecipients.invalidate({ estateId });
          void utils.inventory.list.invalidate({ estateId });
          void utils.inventory.totals.invalidate({ estateId });
          void utils.distribution.compute.invalidate({ estateId });
          void utils.readiness.check.invalidate({ estateId });
          void utils.readiness.timeline.invalidate({ estateId });
          void utils.deadline.list.invalidate();
          void utils.document.getLetterRecipients.invalidate({ estateId });
          await utils.document.preflight.invalidate();
          void utils.document.preflightMany.invalidate();
        } catch {
          return false; // toast fired in onError; keep the dialog open
        }
      }

      // P1 completion actions are intentionally canonical records, never
      // document-local overrides: contact roles decide notice/application
      // eligibility and uploaded files are legal evidence. Every procedure is
      // owner-scoped server-side; re-check only starts after all writes finish.
      if (anyP1Actions) {
        try {
          for (const action of p1Actions!.contacts) {
            const name = String(action.name || "").trim();
            const residentialAddress = String(action.residentialAddress || "").trim();
            if (action.mode === "update") {
              if (!action.id) throw new Error("The contact record is unavailable.");
              const data: Record<string, string | number> = {};
              if (name) data.name = name;
              if (residentialAddress) {
                // Mirrors the Contacts editor's canonical residential write:
                // retain the legacy address compatibility value in lockstep.
                data.residentialAddress = residentialAddress;
                data.address = residentialAddress;
              }
              if (String(action.postalAddress || "").trim()) data.postalAddress = String(action.postalAddress).trim();
              if (String(action.occupation || "").trim()) data.occupation = String(action.occupation).trim();
              if (action.relationshipDurationMonths !== undefined) {
                const months = Number(action.relationshipDurationMonths);
                if (Number.isFinite(months) && months >= 0) data.relationshipDurationMonths = months;
              }
              if (["consented", "renounced", "cannot_locate"].includes(String(action.priorityConsent))) {
                data.priorityConsent = String(action.priorityConsent);
              }
              if (String(action.priorityConsentInquiryDetails || "").trim()) {
                data.priorityConsentInquiryDetails = String(action.priorityConsentInquiryDetails).trim();
              }
              if (String(action.residenceStreet || "").trim()) data.residenceStreet = String(action.residenceStreet).trim();
              if (String(action.residenceCity || "").trim()) data.residenceCity = String(action.residenceCity).trim();
              if (String(action.residenceProvince || "").trim()) data.residenceProvince = String(action.residenceProvince).trim();
              if (String(action.residencePostalCode || "").trim()) data.residencePostalCode = String(action.residencePostalCode).trim();
              if (String(action.residenceCountry || "").trim()) data.residenceCountry = String(action.residenceCountry).trim();
              if (String(action.orgSignatoryName || "").trim()) data.orgSignatoryName = String(action.orgSignatoryName).trim();
              if (String(action.orgSignatoryTitle || "").trim()) data.orgSignatoryTitle = String(action.orgSignatoryTitle).trim();
              if (action.pgtInfoReviewed === true) data.pgtInfoReviewed = 1;
              if (Object.keys(data).length > 0) await pgContactInlineMutation.mutateAsync({ id: action.id, estateId, data });
              continue;
            }
            if (action.mode === "designateIntestateSuccessor") {
              if (!action.id) throw new Error("Select an existing contact to mark as an intestate successor.");
              await pgContactInlineMutation.mutateAsync({
                id: action.id,
                estateId,
                data: { role: "intestate_successor", recipientType: "intestate_successor" },
              });
              continue;
            }
            if (action.mode === "createIntestateSuccessor") {
              if (!name) throw new Error("Name an intestate successor before applying this correction.");
              await pgP1ContactCreateMutation.mutateAsync({
                estateId,
                role: "intestate_successor",
                recipientType: "intestate_successor",
                name,
                ...(residentialAddress ? { residentialAddress, address: residentialAddress } : {}),
              });
              continue;
            }
            if (!name || (action.mode !== "createSpouse" && !residentialAddress)) {
              throw new Error("Name and residential address are required before adding this contact.");
            }
            if (action.mode === "createApplicant") {
              await pgP1ContactCreateMutation.mutateAsync({
                estateId, role: "applicant", executorStatus: "applying", name,
                residentialAddress, address: residentialAddress,
                ...(String(action.postalAddress || "").trim() ? { postalAddress: String(action.postalAddress).trim() } : {}),
                ...(String((action as any).occupation || "").trim() ? { occupation: String((action as any).occupation).trim() } : {}),
              });
            } else if (action.mode === "createRenouncer") {
              // Nick 2026-09-01 directive (P17): a renouncing executor is a real
              // contact — executor role with a recorded renunciation — never the
              // applicant defaulted into the renouncer slot.
              await pgP1ContactCreateMutation.mutateAsync({
                estateId, role: "executor", executorStatus: "renounced", name,
                residentialAddress, address: residentialAddress,
                ...(String((action as any).occupation || "").trim() ? { occupation: String((action as any).occupation).trim() } : {}),
              });
            } else if (action.mode === "createSpouse") {
              await pgP1ContactCreateMutation.mutateAsync({
                estateId, role: "spouse", recipientType: "spouse", name,
                ...(residentialAddress ? { residentialAddress, address: residentialAddress } : {}),
                relationship: "spouse",
                // Nick 2026-09-02 (P2-05): a widowed file's late spouse is recorded
                // predeceased so Schedule §2(a) prints the name with "(deceased)".
                ...(action.isPredeceased ? { isPredeceased: 1 } : {}),
              });
            } else {
              const recipientType = String(action.recipientType || "beneficiary");
              await pgP1ContactCreateMutation.mutateAsync({
                estateId, role: recipientType, recipientType, name,
                residentialAddress, address: residentialAddress,
              });
            }
          }

          let codicilRevision = Number((utils.estate.get.getData({ id: estateId }) as any)?.revision ?? estate?.revision ?? 1);
          for (const upload of p1Actions!.uploads) {
            const bytes = new Uint8Array(await upload.file.arrayBuffer());
            let binary = "";
            for (let index = 0; index < bytes.length; index += 1) binary += String.fromCharCode(bytes[index]);
            const payload = {
              estateId,
              fileBase64: btoa(binary),
              fileName: upload.file.name,
              mimeType: upload.file.type || "application/octet-stream",
            };
            if (upload.kind === "will") await pgP1WillUploadMutation.mutateAsync(payload);
            else if (upload.kind === "foreignGrant") await pgP1ForeignGrantUploadMutation.mutateAsync(payload);
            else {
              const result = await pgP1CodicilUploadMutation.mutateAsync({ ...payload, expectedRevision: codicilRevision });
              codicilRevision = result.revision;
              utils.estate.get.setData({ id: estateId }, (current) => current ? ({ ...current, revision: result.revision } as typeof current) : current);
            }
          }
          void utils.contact.list.invalidate({ estateId });
          void utils.delivery.getRecipients.invalidate({ estateId });
          void utils.document.getLetterRecipients.invalidate({ estateId });
          invalidateEstateDocumentState();
          await utils.document.preflight.invalidate();
        } catch (error: any) {
          toast.error(error?.message || "Could not save the form information.");
          return false;
        }
      }

      if (!stillCurrent()) return false; // proceeded/cancelled while the save ran

      if (anyCanonicalEstate || canonicalRetry) {
        // Canonical answers do not change the query's override key. Evict the
        // previous verdict so generation cannot reuse a pre-save response.
        try {
          invalidateEstateDocumentState();
          await utils.document.preflight.invalidate();
          void utils.document.preflightMany.invalidate();
        } catch {
          toast.error("Answers saved, but the form could not be re-checked. Please retry.");
          return false;
        }
        if (!stillCurrent()) return false;
      }
      const mergedOverrides = { ...pending.renderContext?.overrides, ...effectiveValues };
      // An explicit canonical correction wins over an earlier document-only
      // answer to the same field. All other pending choices stay unchanged.
      for (const key of Object.keys(canonicalEstate ?? {})) delete mergedOverrides[key];
      for (const key of Array.from(pgCanonicalRetryRef.current.get(pending)?.savedKeys ?? [])) delete mergedOverrides[key];
      const mergedContext: PreflightRenderContext = {
        ...pending.renderContext,
        overrides: mergedOverrides,
      };
      // Addendum 24.1: bank the applied values only if the re-check actually
      // completed — a failed preflight fetch leaves the OLD pending context
      // (without the typed values), and reporting success would let a
      // subsequent "Generate anyway" silently drop them.
      const reChecked = await runWithPreflight(pending.formCodes, pending.formName, fn, mergedContext, pending.action, stillCurrent, canonicalObserver?.onRechecked, canonicalObserver?.hasNewerEdits);
      // All-green re-check → the action already ran and the refs were consumed;
      // tell handlePgProceed so a proceed-driven apply ends quietly.
      if (reChecked && pgProceedRef.current === null) pgCompletedInApplyRef.current = true;
      return reChecked;
    } finally {
      pgApplyingRef.current = false;
      setPgApplying(false);
    }
  }

  // Form-details dialog resume handlers. Generate still routes through
  // runWithPreflight, so the PreGenerateDialog gap gate is unchanged downstream.
  async function handleDetailsGenerate(extra: { selectedContactId?: string; deponentId?: string; affidavitOrdinal?: string }): Promise<void> {
    const currentDetailsForm = detailsForm;
    if (!currentDetailsForm) return;
    const { code, name } = currentDetailsForm;
    const optionalContext = currentDetailsForm.optionalContext;
    const deliveryId = currentDetailsForm.deliveryId;
    const citationRecordId = currentDetailsForm.citationRecordId;
    const selectedContactId = extra.selectedContactId ?? extra.deponentId ?? optionalContext?.selectedContactId;
    const generateAnyway = optionalContext?.generateAnyway ?? manualP5DraftOptions(code).generateAnyway;
    // Close FormDetailsDialog so PreGenerateDialog can mount cleanly.
    // Nick's z-[60] stacking on PreGenerateDialog ensures it renders above
    // any residual FormDetailsDialog overlay, but we still close first to
    // avoid two overlays competing for body pointer-events.
    setDetailsForm(null);
    // Yield TWO frames: the first lets React commit the state change, the
    // second lets Radix's exit animation release body pointer-events. A single
    // requestAnimationFrame is unreliable on mobile Safari.
    await new Promise<void>((resolve) => setTimeout(() => setTimeout(resolve, 50), 0));
    const handoffCompleted = await runWithPreflight(
      [code],
      `${code} — ${name}`,
      (ov, proceedOptions) => generateMutation.mutateAsync({
        estateId,
        formCode: code,
        signatoryType,
        signatureDate,
        ...(deliveryId ? { deliveryId } : {}),
        ...(citationRecordId ? { citationRecordId } : {}),
        ...extra,
        ...manualP5DraftOptions(code),
        ...(generateAnyway ? { generateAnyway: true } : {}),
        ...(proceedOptions?.generateAnyway ? { generateAnyway: true } : {}),
        overrides: ov as Record<string, string | number | boolean> | undefined,
      }),
      {
        selectedContactId,
        ...(deliveryId ? { targetDeliveryId: deliveryId } : {}),
        ...(citationRecordId ? { targetCitationRecordId: citationRecordId } : {}),
        supportsOverrides: true,
        overrides: optionalContext?.overrides,
        ...manualP5DraftOptions(code),
        ...(generateAnyway ? { generateAnyway: true } : {}),
      },
    );
    // If preflight failed (e.g. server error), re-open the form details so the
    // user has a visible retry path instead of a blank page.
    if (!handoffCompleted) setDetailsForm(currentDetailsForm);
  }

  async function handleDetailsPreview(extra: { selectedContactId?: string; deponentId?: string; affidavitOrdinal?: string }): Promise<void> {
    const currentDetailsForm = detailsForm;
    if (!currentDetailsForm) return;
    const { code, name } = currentDetailsForm;
    const optionalContext = currentDetailsForm.optionalContext;
    const deliveryId = currentDetailsForm.deliveryId;
    const citationRecordId = currentDetailsForm.citationRecordId;
    const selectedContactId = extra.selectedContactId ?? extra.deponentId ?? optionalContext?.selectedContactId;
    const generateAnyway = optionalContext?.generateAnyway ?? manualP5DraftOptions(code).generateAnyway;
    setDetailsForm(null);
    await new Promise<void>((resolve) => setTimeout(() => setTimeout(resolve, 50), 0));
    const handoffCompleted = await runWithPreflight(
      [code],
      `${code} — ${name}`,
      (ov, proceedOptions) => setPreviewForm({
        code,
        name,
        ...extra,
        ...(deliveryId ? { deliveryId } : {}),
        ...(citationRecordId ? { citationRecordId } : {}),
        overrides: ov,
        ...manualP5DraftOptions(code),
        ...(generateAnyway ? { generateAnyway: true } : {}),
        ...(proceedOptions?.generateAnyway ? { generateAnyway: true } : {}),
      }),
      {
        selectedContactId,
        ...(deliveryId ? { targetDeliveryId: deliveryId } : {}),
        ...(citationRecordId ? { targetCitationRecordId: citationRecordId } : {}),
        supportsOverrides: true,
        overrides: optionalContext?.overrides,
        ...manualP5DraftOptions(code),
        ...(generateAnyway ? { generateAnyway: true } : {}),
      },
      "preview",
    );
    if (!handoffCompleted) setDetailsForm(currentDetailsForm);
  }

  // Continuation after the Optional-form popup collected its answers. The
  // EXISTING pipeline runs unchanged — the preflight gap gate, then generate or
  // preview — with the answers attached as per-document overrides. The server
  // merges them once, at load, so the facts that authorize the document are the
  // facts printed on it, and the estate record is never written.
  //
  // An Optional-form answer can establish why a form is requested, but it does
  // not replace the document's own printed choices (deponent, delivery,
  // signatory, oath, date, or form-specific facts). Always hand a form that
  // has registered detail controls to that same popup next. This keeps every
  // document-facing answer in a generation dialog rather than sending the
  // user to Forms or silently applying a default. The optional answers remain
  // document-local overrides and ride through the existing preflight pipeline.
  function handleFixProceed(
    code: string,
    overrides: Record<string, unknown>,
    opts: { notApplicable: boolean; intent: "generate" | "preview" },
  ): void {
    const name = FORM_CATALOG.find((f) => f.code === code)?.name || code;
    // The na-escape route preserves the user's deponent selection (2026-08-21
    // goal loop): read it BEFORE clearing the dialog state. Undefined on the
    // ordinary Optional-form path — every spread below is a no-op then.
    const deponentSelectedContactId = fixForm?.deponentSelectedContactId;
    setFixForm(null);
    setLastFormCode(code);
    const hasOverrides = Object.keys(overrides).length > 0;
    const generateAnyway = manualP5DraftOptions(code).generateAnyway ?? opts.notApplicable;
    if (FORM_DETAILS[code]) {
      const optionalContext = {
        overrides: hasOverrides ? overrides as Record<string, string | number | boolean> : undefined,
        generateAnyway,
        selectedContactId: deponentSelectedContactId,
      };
      // Let Radix release the Optional-form dialog's mobile overlay before
      // mounting the signing dialog, matching the established two-frame handoff.
      setTimeout(() => setTimeout(() => setDetailsForm({ code, name, optionalContext }), 50), 0);
      return;
    }
    const renderContext = {
      overrides: hasOverrides ? overrides : undefined,
      generateAnyway,
      supportsOverrides: true,
      selectedContactId: deponentSelectedContactId,
    };
    void runWithPreflight(
      [code],
      `${code} — ${name}`,
      // The overrides come from the gate, not this closure: after an
      // inline-fill re-check they are the popup's answers PLUS the typed
      // field values, and the mutation must carry the merged set.
      (ov) => {
        const effective = ov && Object.keys(ov).length > 0
          ? (ov as Record<string, string | number | boolean>)
          : undefined;
        if (opts.intent === "preview") {
          setPreviewForm({
            code,
            name,
            selectedContactId: deponentSelectedContactId,
            deponentId: code === "P8" ? deponentSelectedContactId : undefined,
            overrides: effective,
            generateAnyway,
          });
          return;
        }
        return generateMutation.mutateAsync({
          estateId,
          formCode: code,
          signatoryType,
          signatureDate,
          selectedContactId: deponentSelectedContactId,
          deponentId: code === "P8" ? deponentSelectedContactId : undefined,
          overrides: effective,
          generateAnyway,
        });
      },
      renderContext,
      opts.intent,
    );
  }

  function openP34Details(citationRecordId: string, citedName: string): void {
    // P34 uses the citor's actual signature date. Do not silently reuse a
    // previous form's date; preserve the canonical citation through the shared
    // details → preflight → preview/generation pipeline.
    setSignatureDate("");
    setLastFormCode("P34");
    setDetailsForm({
      code: "P34",
      name: `Affidavit of Deemed Renunciation${citedName ? ` — ${citedName}` : ""}`,
      citationRecordId,
    });
  }

  function handlePreviewP19(): void {
    setLastFormCode("P19");
    void runWithPreflight(
      ["P19"],
      "P19 — Grant Certificate",
      (ov) => setPreviewForm({ code: "P19", name: "Grant Certificate", overrides: ov }),
      { supportsOverrides: true },
      "preview",
    );
  }

  function handleGenerateP19(): void {
    setLastFormCode("P19");
    void runWithPreflight(
      ["P19"],
      "P19 — Grant Certificate",
      (ov) => generateMutation.mutateAsync({
        estateId,
        formCode: "P19",
        signatoryType,
        signatureDate,
        overrides: ov as Record<string, string | number | boolean> | undefined,
      }),
      { supportsOverrides: true },
    );
  }

  const renderRecipientDocuments = () => (
    <Card className="overflow-hidden border-border/80 shadow-sm">
      <CardHeader className="border-b bg-muted/20 px-4 py-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="min-w-0">
            <CardTitle className="text-sm">Recipient documents</CardTitle>
            <p className="mt-0.5 text-xs text-muted-foreground">Letters, consents, and administrator appointments for recorded recipients.</p>
          </div>
          {beneficiaries.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              className="h-8"
              onClick={() => { void runWithPreflight(["LETTER"], "All Letters", () => allLettersMutation.mutateAsync({ estateId, signatureDate }), { forceMany: true }); }}
              disabled={allLettersMutation.isPending}
            >
              <Package className="mr-1.5 h-3.5 w-3.5" />
              {allLettersMutation.isPending ? "Generating..." : "Generate all letters"}
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3 p-4">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-2 border-b pb-3">
          <Label className="text-xs whitespace-nowrap">Date of will</Label>
          <Input
            type="date"
            value={estate?.willDate || ""}
            onChange={(e) => updateWillDateMutation.mutate({ id: estateId, expectedRevision: estate.revision, data: { willDate: e.target.value } })}
            className="h-8 w-40 text-xs"
          />
          {!estate?.willDate && <span className="text-[11px] text-muted-foreground">Used only for will-based letters.</span>}
        </div>
        {(!allRecipients || allRecipients.length === 0) ? (
          <p className="py-2 text-xs text-muted-foreground">No recipient documents are available yet. Add beneficiaries or other contacts in Contacts to prepare letters and consents.</p>
        ) : (
          <div className="space-y-2">
            <p className="text-[11px] text-muted-foreground">{allRecipients.length} recipient{allRecipients.length !== 1 ? "s" : ""} for notice documents</p>
            {allRecipients.map((recip, idx) => (
              <div key={recip.contactId || `recip-${idx}`} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 rounded-md border border-border/80 px-3 py-2.5">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{recip.name}{recip.isPGT ? " (PGT)" : ""}</p>
                  {recip.address && <p className="mt-0.5 truncate text-[11px] text-muted-foreground">{recip.address.split("\n")[0]}</p>}
                </div>
                <div className="flex max-w-[19rem] flex-wrap items-center justify-end gap-1.5">
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => void runWithPreflight(["LETTER"], `Letter to ${recip.name}`, (ov) => setPreviewForm({ code: "LETTER", name: `Cover Letter to ${recip.name}`, targetBeneficiaryId: recip.contactId, overrides: ov }), { targetContactId: String(recip.contactId), supportsOverrides: true }, "preview")} title="Preview letter">
                    <Eye className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="outline" size="sm" className="h-8" onClick={() => { void runWithPreflight(["LETTER"], `Letter to ${recip.name}`, (ov) => generateMutation.mutateAsync({ estateId, formCode: "LETTER", signatoryType, signatureDate, targetBeneficiaryId: recip.contactId, overrides: ov as Record<string, string | number | boolean> | undefined }), { targetContactId: String(recip.contactId), supportsOverrides: true }); }} disabled={generateMutation.isPending}>
                    <FileText className="mr-1.5 h-3.5 w-3.5" />Letter
                  </Button>
                  {recip.isBeneficiary && (() => {
                    const storedBeneficiary = (contacts || []).find((contact) => String(contact.id) === String(recip.contactId));
                    if (!storedBeneficiary || !isLivingContact(storedBeneficiary)) return null;
                    const hasAdministratorConsentCandidate = consentAdministrators.some((contact) => String(contact.id) !== String(recip.contactId));
                    const administratorConsentUnavailableReason = !administratorConsentAvailable
                      ? "Available only after the estate is recorded as no will."
                      : !hasAdministratorConsentCandidate
                        ? "Add a living recorded administrator or applying applicant in Contacts."
                        : undefined;
                    return (
                    <>
                      <Button variant="secondary" size="sm" className="h-8" onClick={() => {
                        const sharePrefill = consentNominationSharePrefill(storedBeneficiary);
                        setConsentNominationDraft({ beneficiaryId: String(recip.contactId), beneficiaryName: recip.name, intent: "generate", nomineeContactId: "", relationshipToNominee: "", beneficiarySharePercentage: sharePrefill.percentage, statutoryShareNote: sharePrefill.note });
                      }} disabled={generateMutation.isPending || consentNominees.filter((contact) => String(contact.id) !== String(recip.contactId)).length === 0}>
                        <FileText className="mr-1.5 h-3.5 w-3.5" />Consent
                      </Button>
                      <Button variant="secondary" size="sm" className="h-8 whitespace-nowrap" onClick={() => setConsentAppointAdministratorDraft({ beneficiaryId: String(recip.contactId), beneficiaryName: recip.name, intent: "generate", administratorContactId: "" })} disabled={generateMutation.isPending || !administratorConsentAvailable || !hasAdministratorConsentCandidate} title={administratorConsentUnavailableReason}>
                        <FileText className="mr-1.5 h-3.5 w-3.5" />Consent to Appoint
                      </Button>
                    </>
                    );
                  })()}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6 pt-4">
      <div className="flex flex-wrap items-end gap-3">
        <div className="space-y-1">
          <Tooltip>
            <TooltipTrigger asChild>
              <Label className="text-xs text-muted-foreground cursor-help border-b border-dotted border-muted-foreground/40">Signature Date</Label>
            </TooltipTrigger>
            <TooltipContent side="top" className="max-w-xs text-xs">
              <p className="font-medium">Used by the Grant Package and Letters</p>
              <p className="mt-1 text-muted-foreground">This date prints on P1, P2, and all cover letters. Individual affidavits (P3–P11) set their own date in the per-form dialog. Defaults to today.</p>
            </TooltipContent>
          </Tooltip>
          <Input type="date" value={signatureDate} onChange={(e) => setSignatureDate(e.target.value)} className="h-9 w-44" />
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="h-9 text-xs text-muted-foreground"
          onClick={() => {
            updateWillDateMutation.mutate(
              { id: estateId, expectedRevision: estate.revision, data: { defaultSignatureDate: signatureDate } },
              {
                onSuccess: () => toast.success("Signature date saved as default for this estate"),
                onError: (error) => toast.error(error.message || "Could not save the default signature date"),
              }
            );
          }}
          disabled={signatureDate === ((estate as any)?.defaultSignatureDate || "")}
        >
          Save as default
        </Button>
        <Button variant="outline" onClick={() => { setLastFormCode(null); void runWithPreflight(grantPackageCodes(estate as any, contacts || []), "Grant Package", () => packageMutation.mutateAsync({ estateId, signatoryType, signatureDate }), { packageMode: true }); }} disabled={packageMutation.isPending} className="h-9">
          <Package className="h-4 w-4 mr-2" />
          {packageMutation.isPending ? "Generating..." : "Generate Grant Package (ZIP)"}
        </Button>
      </div>

      <p className="text-[10px] text-muted-foreground -mt-2">
        Bulk actions (Grant Package, Generate All) produce DOCX files only — preview each form individually from its row below.
      </p>

      {/* Smart notices about missing data */}
      {(() => {
        const notices: string[] = [];
        if (!estate?.deceasedFirstName || !estate?.deceasedLastName) notices.push("Deceased name is required for all forms.");
        if (!estate?.dateOfDeath) notices.push("Date of death is required for P2 and P10/P11.");
        if (!estate?.registry) notices.push("Registry must be set before filing.");
        if (estate && requiresSeparateWillCopy(estate as any) && !estate.willStorageKey) notices.push(isAncillary(estate as any)
          ? "Upload the separate will copy in the Intake Tab — it is required for the ancillary filing and accompanies P1 when notice is required."
          : "Upload the will in the Intake Tab — it will be bundled with P1 (delivered with the notice per Rule 25-2 (3)).");
        // WESA s.1: "will" includes a codicil, so every recorded codicil is
        // delivered with P1 too. Warn only — P1 still generates with whatever is
        // uploaded (RULES.md Rule 14).
        if (estate && requiresSeparateWillCopy(estate as any) && codicilUploadShortfall(estate as any)) {
          // codicilUploadShortfall is also true for an unreadable saved list, which
          // can happen at a recorded count of 0 — never print "0 recorded" there.
          const recorded = Number(estate.codicilCount || 0);
          const detail = recorded > 0 ? `${recorded} recorded` : "the saved codicil list could not be read";
          notices.push(isAncillary(estate as any)
            ? `Upload a copy of every recorded codicil in the Intake Tab — ${detail}. They are required for the ancillary filing and accompany P1 when notice is required.`
            : `Upload a copy of every recorded codicil in the Intake Tab — ${detail}. Each is part of the will (WESA s. 1) and is delivered with P1 per Rule 25-2 (1.1).`);
        }
        if (estate && requiresForeignGrantCopy(estate as any) && !estate.foreignGrantStorageKey) notices.push(isAncillary(estate as any)
          ? "Upload the foreign grant in the Intake Tab — it is required for the ancillary filing and accompanies P1 when notice is required."
          : "Upload the foreign grant in the Intake Tab — it must be delivered with P1.");
        if (estate && requiresForeignGrantCopy(estate as any) && estate.hasWill && !["yes", "no"].includes(estate.foreignGrantIncludesWill || "")) notices.push("Record whether the will and any codicils form part of the foreign grant.");
        if (estate && isAncillary(estate as any) && estate.foreignGrantCertifiedByIssuingCourt !== "yes") notices.push("Confirm that the foreign-grant filing copy is certified by the issuing court before generating P2 or the grant package.");
        if (estate && isAncillary(estate as any) && estate.hasWill && estate.ancillaryWillDocumentsCertifiedByIssuingCourt !== "yes") notices.push("Confirm that the will and every codicil being filed are certified by the issuing court.");
        if (notices.length === 0) return null;
        return (
          <Alert className="border-amber-200 dark:border-amber-800/50 bg-amber-50/50 dark:bg-amber-950/20">
            <Info className="h-4 w-4 text-amber-600" />
            <AlertDescription className="text-xs text-amber-800 dark:text-amber-300">
              <p className="font-medium mb-1">Before generating forms:</p>
              <ul className="space-y-0.5 list-disc pl-3">
                {notices.map((n, i) => <li key={i}>{n}</li>)}
              </ul>
            </AlertDescription>
          </Alert>
        );
      })()}

      {/* P2 21-day countdown — shows remaining days until P2 can be filed */}
      {(() => {
        const clockItem = readinessReport?.items.find(i => i.id === "p1_21day_clock");
        if (!clockItem || clockItem.level !== "fail") return null;
        // Extract remaining days from label: "21-day notice period not elapsed (X day(s) remaining)"
        const match = clockItem.label.match(/(\d+) day/);
        const remaining = match ? parseInt(match[1], 10) : null;
        return (
          <Alert className="border-red-200 dark:border-red-800/50 bg-red-50/50 dark:bg-red-950/20">
            <Clock className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-xs text-red-800 dark:text-red-300">
              <p className="font-medium">{remaining !== null ? `${remaining} day${remaining === 1 ? "" : "s"} until P2 can be filed` : "21-day notice period not elapsed"}</p>
              <p className="text-[10px] mt-0.5 opacity-80">{clockItem.detail}</p>
            </AlertDescription>
          </Alert>
        );
      })()}

      {/* P4 Explainer — shows why long-form affidavit is required. XC-11 (Nick
          2026-09-01): the banner keys on formStatus — the single requiredness
          source — so it can never contradict the Forms tab buckets. */}
      {estate && formStatus("P4", estate as any, (contacts as any[]) || [], inventory).applicability === "required" && (() => {
        const p4result = shouldUseP4(estate as any, contacts || []);
        if (!p4result.required) return null;
        return (
          <Card className="border-amber-200 dark:border-amber-800/50 bg-amber-50/50 dark:bg-amber-950/20">
            <CardContent className="py-3 px-4">
              <p className="text-xs font-medium text-amber-800 dark:text-amber-300 mb-1.5">P4 (Long-Form Affidavit) Required</p>
              <ul className="space-y-0.5">
                {p4result.reasons.map((r, i) => (
                  <li key={i} className="text-[11px] text-amber-700 dark:text-amber-300 flex items-start gap-1.5">
                    <span className="mt-0.5 shrink-0 h-1 w-1 rounded-full bg-amber-500" />
                    {r.ruleLetter && r.ruleLetter !== "extra" ? `(${r.ruleLetter}) ` : ""}{r.reason}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        );
      })()}

      {/* WESA s.131 standing warning — admin with will only */}
      {estate && normalizeGrantType(estate.grantType) === "admin_with_will" && contacts && contacts.length > 0 && (() => {
        const s131 = validateAdminWithWillEligibility(estate as any, contacts);
        if (s131.eligible) return null;
        return (
          <Alert className="border-red-200 dark:border-red-800/50 bg-red-50/50 dark:bg-red-950/20">
            <AlertTriangle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-xs text-red-800 dark:text-red-300">
              <p className="font-medium mb-1">WESA s.131 Standing Unconfirmed</p>
              <p className="text-[11px] leading-relaxed">{s131.reason}{s131.paragraph ? ` (s.131(${s131.paragraph}))` : ""}</p>
              <p className="text-[10px] mt-1.5 opacity-80">Record beneficiary consent in the Contacts tab before swearing P3. P4 remains available on demand and becomes required only when a recorded long-form condition applies.</p>
            </AlertDescription>
          </Alert>
        );
      })()}

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">Individual Forms</CardTitle></CardHeader>
        <CardContent className="space-y-1.5">
          {(() => {
            const allForms = FORM_CATALOG
              .filter((f) => !(FORMS_TAB_EXCLUDED_FORMS as readonly string[]).includes(f.code))
              .map((f) => ({ f, status: formStatus(f.code, estate as any, contacts || [], inventory) }));
            // The streamlined catalog intentionally omits the separate VSA
            // search-request workflow. It remains fully available in standard
            // Forms view and no form status, generation, or preflight logic is changed.
            const formFocusedForms = allForms
              .filter(({ f }) => f.code !== "VSA532")
              .sort(({ f: left }, { f: right }) => {
                const leftNumber = /^P(\d+)$/.exec(left.code)?.[1];
                const rightNumber = /^P(\d+)$/.exec(right.code)?.[1];
                if (leftNumber && rightNumber) return Number(leftNumber) - Number(rightNumber);
                if (leftNumber) return -1;
                if (rightNumber) return 1;
                return left.code.localeCompare(right.code);
              });
            // Two buckets, not three. Required is what this estate's recorded
            // facts call for; everything else is Optional and generatable on
            // demand through the popup (RULES.md Rule 22). Forms the engine
            // marks "na" sort last within Optional — still available, just the
            // least likely to be wanted.
            const requiredForms = allForms.filter(({ status }) => status.applicability === "required");
            // P3 and P4 are mutually exclusive primary-affidavit faces for the
            // recorded facts, but both remain available as Optional forms. A
            // practitioner must be able to generate either on demand when the
            // recorded applicability determination needs review.
            const optionalForms = [
              ...allForms.filter(({ status }) => status.applicability === "conditional"),
              ...allForms.filter(({ status }) => status.applicability === "na"),
            ];

            const renderFormRow = ({ f, status }: { f: typeof FORM_CATALOG[number]; status: FormStatus }) => {
              const codCount = (() => { try { return requiresSeparateWillCopy(estate as any) ? JSON.parse(estate?.codicilFiles || "[]").length : 0; } catch { return 0; } })();
              // Rule 25-2(3): the will copy is delivered WITH the notice — attachments ride with P1
              const hasP1Attachments = f.code === "P1" && (estate?.foreignGrantStorageKey || (requiresSeparateWillCopy(estate as any) && estate?.willStorageKey) || codCount > 0);
              const badgeLabel = f.code === "P1" ? [estate?.foreignGrantStorageKey ? "Foreign Grant" : "", requiresSeparateWillCopy(estate as any) && estate?.willStorageKey ? "Will" : "", codCount > 0 ? `${codCount} Codicil${codCount > 1 ? "s" : ""}` : ""].filter(Boolean).join(" + ") : "";
              const applicability: FormApplicability = status.applicability;
              // Every form is generatable (RULES.md Rule 22). `optional` only
              // decides the ROUTE: Required forms go straight down the existing
              // pipeline, Optional forms collect their answers in the popup
              // first. No row is ever disabled or painted as dead.
              const optional = applicability !== "required";
              const badgeVariant: "default" | "outline" | "secondary" =
                applicability === "required" ? "default" : applicability === "conditional" ? "outline" : "secondary";
              const rowClass = "p-2 rounded-md border transition-colors hover:bg-muted/40";
              // Same vocabulary as the applicability popup this card opens
              // (Nick 2026-09-02): one shared helper, so the badge and the
              // popup's "With these answers … is …" line can never disagree.
              const badgeText = applicabilityLabel(applicability);
              // Opening the popup is how BOTH actions start on an Optional form —
              // preview must render the same answers the download would.
              const openFixDialog = (intent: "generate" | "preview") => setFixForm({ code: f.code, name: f.name, intent });

              // P8 gets special rendering: one row per co-applicant (Rule 25-3(2)(c))
              if (f.code === "P8") {
                // This must precede the optional-form gate. A single-applicant
                // estate cannot truthfully draft a blank-deponent P8; offer the
                // real Contacts intake immediately, rather than a warning that
                // proceeds into a server rejection after “Preparing P8…”.
                const p8Resolved = p8ApplyingCoApplicants(
                  contacts || [],
                  p8PrimaryHistory.ambiguous ? undefined : p8PrimaryHistory.deponentId ?? undefined,
                );
                const p8CoApplicants = p8Resolved.coApplicants;
                if (!p8Resolved.blocked && p8CoApplicants.length === 0) {
                  return (
                    <div key={f.code} className={`${rowClass} space-y-2`} data-testid="form-row-P8">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-medium truncate">{f.code} — {f.name}</p>
                          <p className="text-[10px] text-muted-foreground">Add an applying co-applicant before preparing this affidavit.</p>
                        </div>
                        <Badge variant="secondary" className="text-[10px]">Needs co-applicant</Badge>
                      </div>
                      <div className="flex flex-wrap gap-2 pl-6">
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 text-xs"
                          onClick={() => { setLastFormCode("P8"); setP8GenerationError(""); setP8CoApplicantIntakeOpen(true); }}
                          data-testid="form-generate-P8"
                        >
                          Generate P8
                        </Button>
                        {onNavigateToTab && <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => onNavigateToTab("contacts")}>Go to Contacts</Button>}
                      </div>
                    </div>
                  );
                }
                if (optional) {
                  return (
                    <div key={f.code} className={rowClass} data-testid="form-row-P8">
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <div className="flex items-center gap-2">
                            <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium truncate">{f.code} — {f.name}</p>
                              <p className="text-[10px] text-muted-foreground truncate">{f.rule}</p>
                            </div>
                            {!formFocusedIntake && <Badge variant={badgeVariant} className="text-[10px]">{badgeText}</Badge>}
                            <Button variant="ghost" size="sm" className="shrink-0 h-7 w-7 p-0" onClick={() => openFixDialog("preview")} title="Preview" aria-label={`Preview ${f.code}`}>
                              <Eye className="h-3.5 w-3.5" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-7 text-xs shrink-0"
                              onClick={() => openFixDialog("generate")}
                              data-testid="form-generate-P8"
                            >
                              Generate
                            </Button>
                          </div>
                        </TooltipTrigger>
                        <TooltipContent side="top" className="max-w-xs text-xs">{status?.reason ?? "Not required for this estate"}</TooltipContent>
                      </Tooltip>
                    </div>
                  );
                }
                // Rule 15 (2026-08-04): exclude the retained primary affidavit's
                // ACTUAL deponent; before one exists, the ranked-primary
                // prediction permits a draft with blank primary references.
                return (
                  <div key={f.code} className="p-2 rounded-md border hover:bg-muted/40 transition-colors space-y-2" data-testid="form-row-P8">
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-medium truncate">{f.code} — {f.name}</p>
                            <p className="text-[10px] text-muted-foreground truncate">{f.rule} — One per co-applicant (×{p8CoApplicants.length})</p>
                          </div>
                          {!formFocusedIntake && <Badge variant={badgeVariant} className="text-[10px]">Required</Badge>}
                        </div>
                      </TooltipTrigger>
                      <TooltipContent side="top" className="max-w-xs text-xs">{status?.reason ?? ""}</TooltipContent>
                    </Tooltip>
                    {p8Resolved.blocked && (
                      <p className="text-[10px] text-amber-700 dark:text-amber-300 pl-6" data-testid="p8-primary-non-applicant-note">
                        The primary affidavit on file was sworn by someone who is not an applying applicant — regenerate P3/P4/P5/P6/P7 with an applicant deponent, then generate P8 (Rule 25-3 (2)(b)).
                      </p>
                    )}
                    {!p8Resolved.blocked && !p8PrimaryHistory.ambiguous && !p8PrimaryHistory.deponentId && (
                      <p className="text-[10px] text-muted-foreground pl-6" data-testid="p8-primary-missing-note">
                        No primary affidavit is recorded. You can generate a P8 draft now; its primary-affidavit references stay blank until P3/P4/P5/P6/P7 is recorded (Rule 25-3 (2)(c)).
                      </p>
                    )}
                    <div className="space-y-1.5 pl-6">
                      {p8CoApplicants.length === 0 && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 text-xs"
                          onClick={() => { setLastFormCode("P8"); setDetailsForm({ code: "P8", name: f.name }); }}
                          data-testid="form-generate-P8"
                        >
                          Generate
                        </Button>
                      )}
                      {p8CoApplicants.map(coApp => (
                        <div key={coApp.id} className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground flex-1 truncate">{coApp.name || "Unnamed"}</span>
                          <Button variant="ghost" size="sm" className="shrink-0 h-7 w-7 p-0" onClick={() => { setLastFormCode("P8"); setDetailsForm({ code: "P8", name: f.name, deponentId: coApp.id }); }} title="Preview" aria-label={`Preview P8 for ${coApp.name || "Unnamed"}`}>
                            <Eye className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            size="sm"
                            className="h-7 text-xs shrink-0"
                            disabled={generateMutation.isPending}
                            onClick={() => { setLastFormCode("P8"); setDetailsForm({ code: "P8", name: f.name, deponentId: coApp.id }); }}
                          >
                            Generate
                          </Button>
                        </div>
                      ))}
                      {p8CoApplicants.length > 1 && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 text-xs w-full"
                          disabled={allP8Mutation.isPending}
                          onClick={() => { setLastFormCode("P8"); void runWithPreflight(["P8"], "All P8 Affidavits", () => allP8Mutation.mutateAsync({ estateId, signatoryType, signatureDate }), { forceMany: true }); }}
                        >
                          Generate All P8 ({p8CoApplicants.length})
                        </Button>
                      )}
                    </div>
                  </div>
                );
              }

              // P17 gets special rendering: one row per renouncing executor (Rule 25-3(2)(i)(i))
              if (f.code === "P17") {
                if (optional) {
                  return (
                    <div key={f.code} className={rowClass} data-testid={`form-row-${f.code}`}>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <div className="flex items-center gap-2">
                            <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium truncate">{f.code} — {f.name}</p>
                              <p className="text-[10px] text-muted-foreground truncate">{f.rule}</p>
                            </div>
                            {!formFocusedIntake && <Badge variant={badgeVariant} className="text-[10px]">{badgeText}</Badge>}
                            <Button variant="ghost" size="sm" className="shrink-0 h-7 w-7 p-0" onClick={() => openFixDialog("preview")} title="Preview" aria-label={`Preview ${f.code}`}>
                              <Eye className="h-3.5 w-3.5" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-7 text-xs shrink-0"
                              onClick={() => openFixDialog("generate")}
                              data-testid="form-generate-P17"
                            >
                              Generate
                            </Button>
                          </div>
                        </TooltipTrigger>
                        <TooltipContent side="top" className="max-w-xs text-xs">{status?.reason ?? "Not required for this estate"}</TooltipContent>
                      </Tooltip>
                    </div>
                  );
                }
                const p17Execs = (contacts || []).filter(isExecutorContact);
                const p17Renouncers = p17Execs.filter(c => c.executorStatus === "renounced");
                return (
                  <div key={f.code} className="p-2 rounded-md border hover:bg-muted/40 transition-colors space-y-2" data-testid={`form-row-${f.code}`}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-medium truncate">{f.code} — {f.name}</p>
                            <p className="text-[10px] text-muted-foreground truncate">{f.rule} — One per renouncing executor (×{p17Renouncers.length})</p>
                          </div>
                          {!formFocusedIntake && <Badge variant={badgeVariant} className="text-[10px]">Required</Badge>}
                        </div>
                      </TooltipTrigger>
                      <TooltipContent side="top" className="max-w-xs text-xs">{status?.reason ?? ""}</TooltipContent>
                    </Tooltip>
                    <div className="space-y-1.5 pl-6">
                      {p17Renouncers.map(ren => (
                        <div key={ren.id} className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground flex-1 truncate">{ren.name || "Unnamed"}</span>
                          <Button variant="ghost" size="sm" className="shrink-0 h-7 w-7 p-0" onClick={() => void runWithPreflight(["P17"], `P17 — ${ren.name || "Renouncer"}`, (ov) => setPreviewForm({ code: "P17", name: f.name, deponentId: ren.id, overrides: ov }), { targetContactId: String(ren.id), supportsOverrides: true }, "preview")} title="Preview" aria-label={`Preview P17 for ${ren.name || "Unnamed"}`}>
                            <Eye className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            size="sm"
                            className="h-7 text-xs shrink-0"
                            disabled={generateMutation.isPending}
                            onClick={() => { void runWithPreflight(["P17"], `P17 — ${ren.name || "Renouncer"}`, (ov) => generateMutation.mutateAsync({ estateId, formCode: "P17", signatoryType, signatureDate, deponentId: ren.id, overrides: ov as Record<string, string | number | boolean> | undefined }), { targetContactId: String(ren.id), supportsOverrides: true }); }}
                          >
                            Generate
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              }

              // Generic form row with tooltip showing reason
              return (
                <div
                  key={f.code}
                  className={rowClass}
                  data-testid={`form-row-${f.code}`}
                >
                  <div className="flex items-center gap-2">
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-medium truncate">
                              {f.code} — {f.name}
                              {hasP1Attachments && <span className="ml-1 text-[10px] text-muted-foreground">({badgeLabel})</span>}
                            </p>
                            <p className="text-[10px] text-muted-foreground truncate">{f.rule}</p>
                          </div>
                        </div>
                      </TooltipTrigger>
                      <TooltipContent side="top" className="max-w-xs text-xs">{status?.reason ?? ""}</TooltipContent>
                      </Tooltip>
                    {!formFocusedIntake && (
                      <Badge variant={badgeVariant} className="text-[10px] shrink-0" data-testid={`form-badge-${f.code}`}>
                        {badgeText}
                      </Badge>
                    )}
                    <Button variant="ghost" size="sm" className="shrink-0 h-7 w-7 p-0" onClick={() => {
                      if (optional) { openFixDialog("preview"); return; }
                      setLastFormCode(f.code);
                      if (FORM_DETAILS[f.code]) {
                        setDetailsForm({ code: f.code, name: f.name });
                      } else {
                        void runWithPreflight([f.code], `${f.code} — ${f.name}`, (ov) => setPreviewForm({ code: f.code, name: f.name, overrides: ov, ...manualP5DraftOptions(f.code) }), { supportsOverrides: true, ...manualP5DraftOptions(f.code) }, "preview");
                      }
                    }} title="Preview" aria-label={`Preview ${f.code}`}>
                      <Eye className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      size="sm"
                      variant={optional ? "outline" : "default"}
                      className="h-7 text-xs shrink-0"
                      disabled={generateMutation.isPending}
                      onClick={() => { if (optional) { openFixDialog("generate"); return; } setLastFormCode(f.code); if (FORM_DETAILS[f.code]) { setDetailsForm({ code: f.code, name: f.name }); } else { void runWithPreflight([f.code], `${f.code} — ${f.name}`, (ov) => generateMutation.mutateAsync({ estateId, formCode: f.code, signatoryType, signatureDate, ...manualP5DraftOptions(f.code), overrides: ov as Record<string, string | number | boolean> | undefined }), { supportsOverrides: true, ...manualP5DraftOptions(f.code) }); } }}
                      data-testid={`form-generate-${f.code}`}
                    >
                      Generate
                    </Button>
                  </div>
                </div>
              );
            };

            if (formFocusedIntake) {
              return (
                <div className="space-y-1.5" data-testid="form-focused-forms-list">
                  <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider px-1">All forms ({formFocusedForms.length})</p>
                  <p className="text-[10px] text-muted-foreground px-1 -mt-0.5" data-testid="form-focused-forms-help">
                    Core probate forms are listed in numeric form-code order. VSA 532 remains available in the standard Forms view; generation and form-specific prompts work exactly as before.
                  </p>
                  {formFocusedForms.map(renderFormRow)}
                </div>
              );
            }

            return (
              <>
                {/* Required forms */}
                {requiredForms.length > 0 && (
                  <div className="space-y-1.5">
                    <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider px-1">Required ({requiredForms.length})</p>
                    {requiredForms.map(renderFormRow)}
                  </div>
                )}

                {/* Everything this estate does not require — still generatable
                    on demand; the popup collects what each form needs. */}
                {optionalForms.length > 0 && (
                  <div className="space-y-1.5 mt-4">
                    <p className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider px-1">Optional ({optionalForms.length})</p>
                    <p className="text-[10px] text-muted-foreground px-1 -mt-0.5" data-testid="optional-forms-help">
                      These are not required by what you have entered in Intake. Generate any of them on demand — you will be asked for the details that form needs, and your intake record stays as it is.
                    </p>
                    {optionalForms.map(renderFormRow)}
                  </div>
                )}
              </>
            );
          })()}
        </CardContent>
      </Card>

      {renderRecipientDocuments()}

      <P19GrantCard
        estateId={estateId}
        estate={estate}
        updateGrantDate={updateWillDateMutation}
        onGenerateP19={handleGenerateP19}
        onPreviewP19={handlePreviewP19}
        isGenerating={generateMutation.isPending || preflightBusy === "P19"}
      />

      {/* P9 — Delivery Records (per-recipient attestation) */}
      {estate && isP1NoticeRequired(estate as any, contacts || []) && <DeliveriesCard
        estateId={estateId}
        feedbackOwner={feedbackOwner}
        estate={estate}
        signatureDate={signatureDate}
        runWithPreflight={runWithPreflight}
        onPreviewP46={(deliveryId, recipientName) => setPreviewForm({ code: "P46", name: `P46 — Demand for ${recipientName}`, deliveryId })}
        onOpenP46Details={(deliveryId, recipientName) => {
          // A P46 must carry the demandant's actual signature date. Do not reuse
          // the last date selected for another form; open the ordinary generation
          // details for this specific delivery recipient instead.
          setSignatureDate("");
          setLastFormCode("P46");
          setDetailsForm({ code: "P46", name: `Demand for ${recipientName}`, deliveryId });
        }}
      />}

      {/* Nick-approved supplementary P10 Distribution section (not an official "Part 3") */}
      <DistributionCard estateId={estateId} estate={estate} />

      <CitationTracker
        estateId={estateId}
        onOpenP34Details={openP34Details}
      />

      {/* P14 — Supplemental Affidavit of Assets and Liabilities (post-filing) */}
      {estate && formStatus("P14", estate as any, contacts || [], inventory).applicability !== "na" && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm">P14 — {FORM_CATALOG.find((f) => f.code === "P14")?.name}</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="text-xs text-muted-foreground">Filed after the initial application (P10) to disclose previously undisclosed assets/liabilities or correct errors. Only available after P10 has been filed.</p>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => { setLastFormCode("P14"); setDetailsForm({ code: "P14", name: FORM_CATALOG.find((f) => f.code === "P14")?.name || "Supplemental Affidavit of Assets and Liabilities" }); }}
                disabled={generateMutation.isPending || !estate?.p10FiledDate}
              >
                <FileText className="h-3.5 w-3.5 mr-1.5" />
                Generate P14
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => { setLastFormCode("P14"); setDetailsForm({ code: "P14", name: FORM_CATALOG.find((f) => f.code === "P14")?.name || "Supplemental Affidavit of Assets and Liabilities" }); }}
                disabled={!estate?.p10FiledDate}
              >
                <Eye className="h-3.5 w-3.5 mr-1.5" />
                Preview
              </Button>
            </div>
            {!estate?.p10FiledDate && (
              <p className="text-[10px] text-amber-700 dark:text-amber-300">Form P10 must be filed before generating a supplemental affidavit.</p>
            )}
          </CardContent>
        </Card>
      )}

      {estate && (estate.notifyPGT === "yes" || requiresPGT(estate as any, contacts || []).required) && (
        <PgtDocumentDeliveryTracker estateId={estateId} />
      )}

      <Dialog open={!!consentNominationDraft} onOpenChange={(open) => { if (!open) setConsentNominationDraft(null); }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Consent and Nomination</DialogTitle>
            <DialogDescription>
              Generate the firm-approved consent document for {consentNominationDraft?.beneficiaryName || "this beneficiary"}. The execution city and date remain blank for the signer, exactly as in the source template.
            </DialogDescription>
          </DialogHeader>
          {consentNominationDraft && (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="consent-nominee">Nominated personal representative</Label>
                <Select value={consentNominationDraft.nomineeContactId || "__none__"} onValueChange={(value) => setConsentNominationDraft((current) => current ? { ...current, nomineeContactId: value === "__none__" ? "" : value } : current)}>
                  <SelectTrigger id="consent-nominee"><SelectValue placeholder="Select a recorded contact" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">Select a recorded contact</SelectItem>
                    {consentNominees.filter((contact) => String(contact.id) !== consentNominationDraft.beneficiaryId).map((contact) => (
                      <SelectItem key={contact.id} value={String(contact.id)}>{contact.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="consent-relationship">Nominee’s relationship to the signer</Label>
                <Input id="consent-relationship" value={consentNominationDraft.relationshipToNominee} onChange={(event) => setConsentNominationDraft((current) => current ? { ...current, relationshipToNominee: event.target.value } : current)} placeholder="e.g., father" maxLength={128} />
                <p className="text-xs text-muted-foreground">This will read: “I nominate my [relationship], [nominee].” Confirm the relationship from the signer’s perspective.</p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="consent-share">Signer’s beneficiary percentage</Label>
                <Input id="consent-share" type="number" min="0" max="100" step="0.01" value={consentNominationDraft.beneficiarySharePercentage} onChange={(event) => setConsentNominationDraft((current) => current ? { ...current, beneficiarySharePercentage: event.target.value } : current)} placeholder="0" />
              </div>
              {consentNominationDraft.statutoryShareNote && (
                <p className="text-xs text-muted-foreground">{consentNominationDraft.statutoryShareNote}</p>
              )}
              <p className="text-xs text-muted-foreground">This does not save or alter beneficiary shares, nominee information, or signing facts in the estate record.</p>
              <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
                <Button variant="outline" onClick={() => setConsentNominationDraft(null)}>Cancel</Button>
                <Button variant="outline" onClick={() => {
                  const shareText = consentNominationDraft.beneficiarySharePercentage.trim();
                  const share = Number(shareText);
                  if (!consentNominationDraft.nomineeContactId || !consentNominationDraft.relationshipToNominee.trim() || !shareText || !Number.isFinite(share) || share < 0 || share > 100) {
                    toast.error("Select a nominee, enter the relationship, and enter a beneficiary percentage from 0 to 100.");
                    return;
                  }
                  setPreviewForm({ code: "CONSENT_NOMINATION", name: "Consent and Nomination", targetBeneficiaryId: consentNominationDraft.beneficiaryId, consentNomination: { nomineeContactId: consentNominationDraft.nomineeContactId, relationshipToNominee: consentNominationDraft.relationshipToNominee.trim(), beneficiarySharePercentage: share } });
                  setConsentNominationDraft(null);
                }}>Preview</Button>
                <Button onClick={() => {
                  const shareText = consentNominationDraft.beneficiarySharePercentage.trim();
                  const share = Number(shareText);
                  if (!consentNominationDraft.nomineeContactId || !consentNominationDraft.relationshipToNominee.trim() || !shareText || !Number.isFinite(share) || share < 0 || share > 100) {
                    toast.error("Select a nominee, enter the relationship, and enter a beneficiary percentage from 0 to 100.");
                    return;
                  }
                  void generateMutation.mutateAsync({ estateId, formCode: "CONSENT_NOMINATION", signatoryType: consentNominationDraft.signatoryType ?? signatoryType, signatureDate: consentNominationDraft.signatureDate ?? signatureDate, targetBeneficiaryId: consentNominationDraft.beneficiaryId, consentNomination: { nomineeContactId: consentNominationDraft.nomineeContactId, relationshipToNominee: consentNominationDraft.relationshipToNominee.trim(), beneficiarySharePercentage: share } }).catch(() => undefined);
                  setConsentNominationDraft(null);
                }} disabled={generateMutation.isPending}>{generateMutation.isPending ? "Generating..." : "Generate DOCX"}</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={!!consentAppointAdministratorDraft} onOpenChange={(open) => { if (!open) setConsentAppointAdministratorDraft(null); }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Consent to Appointment of an Administrator</DialogTitle>
            <DialogDescription>
              Generate the uploaded consent document for {consentAppointAdministratorDraft?.beneficiaryName || "this beneficiary"}. It uses only recorded estate/contact facts and leaves execution and witness fields blank for signing.
            </DialogDescription>
          </DialogHeader>
          {consentAppointAdministratorDraft && (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="consent-administrator">Administrator or applying applicant to be appointed</Label>
                <Select value={consentAppointAdministratorDraft.administratorContactId || "__none__"} onValueChange={(value) => setConsentAppointAdministratorDraft((current) => current ? { ...current, administratorContactId: value === "__none__" ? "" : value } : current)}>
                  <SelectTrigger id="consent-administrator"><SelectValue placeholder="Select a living recorded administrator or applicant" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">Select a living recorded administrator or applicant</SelectItem>
                    {consentAdministrators.filter((contact) => String(contact.id) !== consentAppointAdministratorDraft.beneficiaryId).map((contact) => (
                      <SelectItem key={contact.id} value={String(contact.id)}>{contact.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <p className="text-xs text-muted-foreground">This source template states that the deceased died intestate. The recorded no-will status, execution location/date, and witness fields are not changed by this action.</p>
              <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
                <Button variant="outline" onClick={() => setConsentAppointAdministratorDraft(null)}>Cancel</Button>
                <Button variant="outline" onClick={() => {
                  if (!consentAppointAdministratorDraft.administratorContactId) {
                    toast.error("Select the living recorded administrator or applying applicant to be appointed.");
                    return;
                  }
                  setPreviewForm({
                    code: "CONSENT_APPOINT_ADMINISTRATOR",
                    name: "Consent to Appointment of an Administrator",
                    targetBeneficiaryId: consentAppointAdministratorDraft.beneficiaryId,
                    consentAppointAdministrator: { administratorContactId: consentAppointAdministratorDraft.administratorContactId },
                  });
                  setConsentAppointAdministratorDraft(null);
                }}>Preview</Button>
                <Button onClick={() => {
                  if (!consentAppointAdministratorDraft.administratorContactId) {
                    toast.error("Select the living recorded administrator or applying applicant to be appointed.");
                    return;
                  }
                  void generateMutation.mutateAsync({
                    estateId,
                    formCode: "CONSENT_APPOINT_ADMINISTRATOR",
                    signatoryType: consentAppointAdministratorDraft.signatoryType ?? signatoryType,
                    signatureDate: consentAppointAdministratorDraft.signatureDate ?? signatureDate,
                    targetBeneficiaryId: consentAppointAdministratorDraft.beneficiaryId,
                    consentAppointAdministrator: { administratorContactId: consentAppointAdministratorDraft.administratorContactId },
                  }).catch(() => undefined);
                  setConsentAppointAdministratorDraft(null);
                }} disabled={generateMutation.isPending}>{generateMutation.isPending ? "Generating..." : "Generate DOCX"}</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Form Preview Modal */}
      <FormPreviewModal
        estateId={estateId}
        formCode={previewForm?.code || "P1"}
        formName={previewForm?.name || ""}
        signatoryType={signatoryType}
        signatureDate={signatureDate}
        targetBeneficiaryId={previewForm?.targetBeneficiaryId}
        deponentId={previewForm?.deponentId}
        selectedContactId={previewForm?.selectedContactId}
        deliveryId={previewForm?.deliveryId}
        citationRecordId={previewForm?.citationRecordId}
        affidavitOrdinal={previewForm?.affidavitOrdinal}
        consentNomination={previewForm?.consentNomination}
        consentAppointAdministrator={previewForm?.consentAppointAdministrator}
        overrides={previewForm?.overrides}
        p17AddressCity={estate?.addressCity}
        p17AddressProvince={estate?.addressProvince}
        generateAnyway={previewForm?.generateAnyway}
        open={!!previewForm}
        onOpenChange={(open) => {
          if (!open) {
            // Use requestAnimationFrame to avoid racing with a new setPreviewForm
            // from another preview button click that fires in the same event loop tick
            requestAnimationFrame(() => {
              setPreviewForm((current) => {
                // Only clear if the form hasn't already been replaced by another click
                if (current === previewForm) return null;
                return current;
              });
            });
          }
        }}
        runWithPreflight={runWithPreflight}
      />

      {/* Version History */}
      {versions && versions.length > 0 && (
        <Card>
          <CardHeader className="pb-3 cursor-pointer" onClick={() => setShowVersions(!showVersions)}>
            <CardTitle className="text-sm flex items-center gap-2">
              <History className="h-4 w-4" />
              Version History ({versions.length})
              <ChevronDown className={`h-3.5 w-3.5 ml-auto transition-transform ${showVersions ? 'rotate-180' : ''}`} />
            </CardTitle>
          </CardHeader>
          {showVersions && (
            <CardContent className="space-y-2 pt-0">
              {versions.map((v) => (
                <div key={v.id} className="flex items-center justify-between py-2 border-b last:border-0">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{v.formCode} — {v.documentName}</p>
                    <p className="text-xs text-muted-foreground">{fmtDisplayDate(v.createdAt)} {new Date(v.createdAt).toLocaleTimeString()} · {v.generatedBy}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    {v.storageUrl ? (
                      <Button variant="ghost" size="sm" onClick={() => downloadFromUrl(v.storageUrl, v.documentName + "." + v.format)}>
                        <Download className="h-3.5 w-3.5" />
                      </Button>
                    ) : null}
                    <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={() => deleteVersionMutation.mutate({ id: v.id, estateId })}>
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          )}
        </Card>
      )}

      {retainedFiles && retainedFiles.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <ShieldCheck className="h-4 w-4" />
              Retained Client-File Records ({retainedFiles.length})
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-1">Files removed or replaced in the active workflow remain available as client-file records until the estate is lawfully disposed.</p>
          </CardHeader>
          <CardContent className="space-y-2 pt-0">
            {retainedFiles.map((file) => (
              <div key={file.storageKey} className="flex items-center justify-between gap-3 py-2 border-b last:border-0">
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{file.originalFileName || file.storageKey.split('/').pop()}</p>
                  <p className="text-xs text-muted-foreground">{file.category.replace(/_/g, " ")} · retained {fmtDisplayDate(file.updatedAt)}</p>
                  {file.deletionReason && <p className="text-xs text-muted-foreground truncate">{file.deletionReason}</p>}
                </div>
                <Button variant="ghost" size="sm" onClick={() => void previewStoredFile(file.storageKey)} title="View retained file">
                  <Eye className="h-3.5 w-3.5" />
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Pre-generate gap dialog (single instance for all call sites) */}
      <PreGenerateDialog
        open={pgOpen}
        onOpenChange={(open) => { if (open) setPgOpen(true); else handlePgCancel(); }}
        formName={pgFormName}
        reports={pgReports}
        onProceed={(proceedOptions) => { void handlePgProceed(proceedOptions); }}
        onJumpToTab={handlePgJumpToTab}
        onCancel={handlePgCancel}
        proceeding={pgProceeding}
        action={pgAction}
        estate={estate}
        renderOverrides={pgPendingRef.current?.renderContext?.overrides}
        contacts={contacts as Array<Record<string, unknown>> | undefined}
        documents={docs}
        selectedContactId={pgPendingRef.current?.renderContext?.selectedContactId ?? null}
        retainedChoices={pgPendingRef.current?.renderContext?.retainedChoices}
        retainedPrimaryAffidavit={pgPendingRef.current?.renderContext?.retainedPrimaryAffidavit}
        // Inline editing exists only where the pending mutation consumes the
        // overrides channel — never for package/bulk runs (Rule 22 §6).
        inlineEditingEnabled={pgPendingRef.current !== null}
        onApplyInline={handlePgApplyInline}
        applying={pgApplying || inlineFillSaveMutation.isPending || requiredDocInlineMutation.isPending
          || pgContactInlineMutation.isPending || pgP1ContactCreateMutation.isPending
          || pgP1WillUploadMutation.isPending || pgP1ForeignGrantUploadMutation.isPending || pgP1CodicilUploadMutation.isPending
          || pgInventoryInlineMutation.isPending || pgInventoryCreateMutation.isPending}
        succeeded={pgSucceeded}
        // Addendum 24.1: the escape exists ONLY for the pending single-form
        // overrides-capable run (same invariant as inlineEditingEnabled) —
        // bulk/package never set the ref (Rule 22 §6). Target-scoped runs
        // (a specific letter recipient, delivery, or citation) are excluded:
        // their na verdicts are record-driven, the fix dialog cannot cure
        // them, and re-routing would drop the target. selectedContactId is
        // DIFFERENT (2026-08-21 goal loop): it is a DEPONENT selection, not a
        // record target — a P4 whose sole na cause the user just answered
        // inline must not dead-end on Blocked, so the escape stays offered and
        // handlePgOverrideNotApplicable carries the deponent through the
        // override flow instead of suppressing it.
        onOverrideNotApplicable={
          pgPendingRef.current !== null
            && !pgPendingRef.current.renderContext?.targetContactId
            && !pgPendingRef.current.renderContext?.targetDeliveryId
            && !pgPendingRef.current.renderContext?.targetCitationRecordId
            ? () => { void handlePgOverrideNotApplicable(); }
            : undefined
        }
      />

      {preflightBusy && (
        <div role="status" aria-live="polite" className="fixed bottom-4 right-4 z-[70] flex items-center gap-2 rounded-md border bg-background px-3 py-2 text-xs shadow-md" data-testid="preflight-busy">
          <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
          <span>Preparing {preflightBusy}…</span>
        </div>
      )}

      {(p8GenerationError || p8DownloadReady) && (
        <Alert className="border-primary/20 bg-primary/[0.03]" data-testid="p8-download-recovery" role={p8GenerationError || p8DownloadReady?.refusal ? "alert" : "status"}>
          <AlertTriangle className="h-4 w-4 text-primary" aria-hidden="true" />
          <AlertDescription className="flex flex-wrap items-center justify-between gap-3">
            <span>{p8GenerationError || p8DownloadReady?.refusal || "Form P8 is ready. If the download did not start, use Download Form P8."}</span>
            <span className="flex shrink-0 gap-2">
              {p8DownloadReady && !p8DownloadReady.refusal && (
                <Button size="sm" disabled={p8DownloadPending} onClick={(event) => { void deliverAttachment(p8DownloadReady.delivery, event.currentTarget, { owner: deliveryFeedback, slot: "p8-recovery" }, keepUsableLink("P8", p8DownloadReady.delivery)); }} data-testid="p8-download-retry">
                  {p8DownloadPending
                    ? <><Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" aria-hidden="true" />Downloading…</>
                    : <><Download className="mr-1.5 h-3.5 w-3.5" />Download Form P8</>}
                </Button>
              )}
              {p8DownloadReady?.refusal && p8DownloadReady.regeneration && (
                <Button ref={p8RecoveryFocusRef} size="sm" variant="outline" aria-disabled={regeneratingSlot === "p8-recovery" || undefined} onClick={() => { void regenerate("p8-recovery", p8DownloadReady.regeneration!); }} data-testid="p8-download-regenerate">Review and generate again</Button>
              )}
              <Button ref={p8DownloadReady?.refusal && !p8DownloadReady.regeneration ? p8RecoveryFocusRef : undefined} size="sm" variant="ghost" onClick={() => { deliveryFeedback.retire("p8-recovery"); setP8GenerationError(""); setP8DownloadReady(null); }}>Dismiss</Button>
            </span>
          </AlertDescription>
        </Alert>
      )}

      {documentGenerationRecovery && (
        <Alert className="border-primary/20 bg-primary/[0.03]" data-testid="document-generation-recovery" role={documentGenerationRecovery.delivery && !documentGenerationRecovery.refusal ? "status" : "alert"}>
          <AlertTriangle className="h-4 w-4 text-primary" aria-hidden="true" />
          <AlertDescription className="flex flex-wrap items-center justify-between gap-3">
            <span><strong>{documentGenerationRecovery.formCode}</strong> — {documentGenerationRecovery.refusal ?? documentGenerationRecovery.message}</span>
            <span className="flex shrink-0 flex-wrap gap-2">
              {documentGenerationRecovery.delivery && !documentGenerationRecovery.refusal && (
                <Button size="sm" disabled={recoveryDownloadPending} onClick={(event) => { void deliverAttachment(documentGenerationRecovery.delivery!, event.currentTarget, { owner: deliveryFeedback, slot: "form-recovery" }, keepUsableLink(documentGenerationRecovery.formCode, documentGenerationRecovery.delivery!)); }} data-testid="document-generation-download-retry">
                  {recoveryDownloadPending
                    ? <><Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" aria-hidden="true" />Downloading…</>
                    : <><Download className="mr-1.5 h-3.5 w-3.5" />Download {documentGenerationRecovery.formCode}</>}
                </Button>
              )}
              {documentGenerationRecovery.refusal && documentGenerationRecovery.regeneration && (
                <Button ref={recoveryFocusRef} size="sm" variant="outline" aria-disabled={regeneratingSlot === "form-recovery" || undefined} onClick={() => { void regenerate("form-recovery", documentGenerationRecovery.regeneration!); }} data-testid="document-generation-regenerate">Review and generate again</Button>
              )}
              {!documentGenerationRecovery.delivery && (
                <Button size="sm" variant="outline" onClick={() => {
                  setLastFormCode(documentGenerationRecovery.formCode);
                  setDetailsForm({ code: documentGenerationRecovery.formCode, name: documentGenerationRecovery.formName });
                  setDocumentGenerationRecovery(null);
                }} data-testid="document-generation-review-retry">
                  {documentGenerationRecovery.formCode === "P4" ? "Review P4 & retry" : "Review & retry"}
                </Button>
              )}
              <Button ref={documentGenerationRecovery.refusal && !documentGenerationRecovery.regeneration ? recoveryFocusRef : undefined} size="sm" variant="ghost" onClick={() => { deliveryFeedback.retire("form-recovery"); setDocumentGenerationRecovery(null); }}>Dismiss</Button>
            </span>
          </AlertDescription>
        </Alert>
      )}

      <P8CoApplicantIntakeDialog
        open={p8CoApplicantIntakeOpen}
        estateId={estateId}
        onOpenChange={setP8CoApplicantIntakeOpen}
        onGoToContacts={onNavigateToTab ? () => { setP8CoApplicantIntakeOpen(false); onNavigateToTab("contacts"); } : undefined}
        onCreated={(contactId) => {
          // Return to the existing P8 details stage with the real saved contact
          // selected; oath/date remain deliberate user choices before download.
          setLastFormCode("P8");
          setDetailsForm({ code: "P8", name: "Affidavit in Support of Application for Estate Grant", deponentId: contactId });
        }}
      />

      {/* Form-details dialog (single instance for all P1–P10 Generate/Preview clicks) */}
      <FormDetailsDialog
        open={!!detailsForm}
        onOpenChange={(open) => { if (!open) setDetailsForm(null); }}
        formCode={detailsForm?.code || "P1"}
        formName={detailsForm?.name || ""}
        estateId={estateId}
        estate={estate}
        contacts={contacts || []}
        signatoryType={signatoryType}
        onSignatoryTypeChange={chooseSignatoryType}
        signatureDate={signatureDate}
        onSignatureDateChange={setSignatureDate}
        initialDeponentId={detailsForm?.deponentId}
        primaryAffidavitDeponentId={p8PrimaryHistory.ambiguous ? null : p8PrimaryHistory.deponentId}
        onGenerate={handleDetailsGenerate}
        onPreview={handleDetailsPreview}
        onCancel={() => setDetailsForm(null)}
        generating={generateMutation.isPending}
      />

      {/* Optional-form popup — Generate or Preview on any Optional row lands here */}
      <FixApplicabilityDialog
        open={!!fixForm}
        onOpenChange={(open) => { if (!open) setFixForm(null); }}
        formCode={fixForm?.code || "P13"}
        formName={fixForm?.name || ""}
        intent={fixForm?.intent || "generate"}
        estate={fixForm?.estateSnapshot ?? estate}
        contacts={contacts || []}
        selectedContactId={fixForm?.deponentSelectedContactId}
        onGoToContacts={onNavigateToTab ? () => onNavigateToTab("contacts") : undefined}
        onGoToIntake={onNavigateToTab ? () => onNavigateToTab("intake") : undefined}
        onProceed={handleFixProceed}
        // Addendum 24.1: entered via the na escape hatch — the SERVER said na,
        // so generateAnyway must ride even if the client's (possibly stale)
        // estate computes applicable; otherwise the user loops back into the
        // same hard block.
        forceNotApplicable={fixForm?.fromNaOverride === true}
      />
    </div>
  );
}

// ─── DELIVERIES CARD (P9 per-recipient attestation) ──────────────────
export function DeliveriesCard({ estateId, estate, signatureDate, runWithPreflight, onPreviewP46, onOpenP46Details, feedbackOwner }: {
  estateId: string;
  estate: any;
  signatureDate: string;
  runWithPreflight?: (
    formCodes: ReadonlyArray<string>,
    formName: string,
    doMutate: PreflightMutate,
    renderContext?: PreflightRenderContext,
    action?: "generate" | "preview" | "download",
  ) => Promise<boolean>;
  onPreviewP46?: (deliveryId: string, recipientName: string) => void;
  /** Opens the shared form-details dialog so the demandant chooses P46's date. */
  onOpenP46Details?: (deliveryId: string, recipientName: string) => void;
  /** Task 13 r3: the estate page's delivery-feedback owner, forwarded by the Forms tab. */
  feedbackOwner?: DeliveryFeedbackOwner;
}) {
  const { data: deliveries, isLoading: loadingDeliveries } = trpc.delivery.list.useQuery({ estateId });
  const { data: recipients } = trpc.delivery.getRecipients.useQuery({ estateId });
  const utils = trpc.useUtils();
  const invalidateDeliveryDerivedState = () => {
    void utils.delivery.list.invalidate({ estateId });
    void utils.readiness.check.invalidate({ estateId });
    void utils.readiness.timeline.invalidate({ estateId });
    void utils.deadline.list.invalidate();
    void utils.document.preflight.invalidate();
    void utils.document.preflightMany.invalidate();
  };

  const upsertMutation = trpc.delivery.upsert.useMutation({
    onSuccess: invalidateDeliveryDerivedState,
  });
  const deleteMutation = trpc.delivery.delete.useMutation({
    onSuccess: invalidateDeliveryDerivedState,
    onError: (err) => toast.error(err.message || "Delivery record could not be deleted"),
  });
  const bulkCreateMutation = trpc.delivery.bulkCreate.useMutation({
    onSuccess: (data) => {
      invalidateDeliveryDerivedState();
      toast.success(`Created ${data.created} delivery record${data.created === 1 ? "" : "s"} (${data.total} total recipients)`);
    },
  });
  // Bulk records feed sworn P9 delivery dates + the 21-day clock, so the user
  // must explicitly record the date.
  const [bulkDeliveryDate, setBulkDeliveryDate] = useState("");

  // P46 Demand generation for electronic wills
  const isElectronicWill = estate?.willType === "electronic" || !!estate?.isElectronicWill;
  // Task 13: this card's delivery feedback belongs to the estate page's owner when one is passed (r3), else to the
  // mounted card (it remounts with the Forms tab).
  const p46Feedback = useEstateFeedbackOwner(feedbackOwner, `deliveries:${estateId}`);
  const p46Mutation = trpc.document.generate.useMutation({
    onSuccess: (data) => {
      void utils.document.list.invalidate({ estateId });
      void utils.document.versions.invalidate({ estateId });
      // Validate, download, THEN announce: never a success toast over a missing download.
      if (!isPostDelivery(data.delivery)) throw new Error("P46 generation failed.");
      deliverAndAnnounce(data.delivery, "P46 Demand generated", { feedback: { owner: p46Feedback, slot: "p46" } });
    },
    onError: (err) => { toast.error(err.message || "P46 generation failed."); },
  });
  const markP44Mutation = trpc.delivery.markP44.useMutation({
    onError: (err: any) => toast.error(err?.message || "P44 delivery could not be saved"),
  });
  const updateP46Mutation = trpc.delivery.updateP46.useMutation({
    onSuccess: invalidateDeliveryDerivedState,
    onError: (err) => toast.error(err.message || "P46 tracking could not be saved"),
  });

  const [editingId, setEditingId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  // Form state for add/edit
  const [formContactId, setFormContactId] = useState("");
  const [formName, setFormName] = useState("");
  const [formAddress, setFormAddress] = useState("");
  const [formMethod, setFormMethod] = useState<"" | "ordinary_mail" | "personal" | "electronic">("");
  const [formDate, setFormDate] = useState("");
  const [formTracking, setFormTracking] = useState("");
  const [formEmail, setFormEmail] = useState("");
  const [formAckDate, setFormAckDate] = useState("");
  const [formDispensed, setFormDispensed] = useState(false);
  const [formOrderDate, setFormOrderDate] = useState("");
  const [formOrderRegNo, setFormOrderRegNo] = useState("");
  const [formOrderFile, setFormOrderFile] = useState("");
  const [pendingDispensationOrder, setPendingDispensationOrder] = useState<{
    fileBase64: string;
    fileName: string;
    mimeType: string;
  } | null>(null);
  // P15PLUS-021: per-recipient Rule 25-3.2(1) P44 withdrawal-delivery date.
  const [formP44Date, setFormP44Date] = useState("");
  // 2026-07-26 review fix: the p44DeliveryMethod column (migration 0103,
  // accepted by delivery.markP44) had no UI writer — record it alongside.
  const [formP44Method, setFormP44Method] = useState<"" | "ordinary_mail" | "personal" | "electronic">("");
  const [formP46Status, setFormP46Status] = useState<"unknown" | "no_demand" | "demand_received" | "complied">("unknown");
  const [formP46DemandReceivedDate, setFormP46DemandReceivedDate] = useState("");
  const [formP46CompliedDate, setFormP46CompliedDate] = useState("");
  const [formP46ComplianceMethod, setFormP46ComplianceMethod] = useState<"" | "original_electronic_form" | "repository_access">("");
  const [formP46Notes, setFormP46Notes] = useState("");

  // Dispensation order file upload
  const dispensationOrderInputRef = useRef<HTMLInputElement>(null);
  const [dispensationOrderUploading, setDispensationOrderUploading] = useState(false);
  const [dispensationOrderFeedback, setDispensationOrderFeedback] = useState<UploadFeedbackState>(IDLE_UPLOAD_FEEDBACK);
  const ALLOWED_DOC_TYPES_DO = ["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "image/png", "image/jpeg", "image/tiff"];
  const handleDispensationOrderFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!ALLOWED_DOC_TYPES_DO.includes(file.type)) {
      const message = invalidFileTypeMessage(file.name, "a PDF, DOC/DOCX, PNG, JPG, or TIFF file");
      setDispensationOrderFeedback({ phase: "error", progress: 0, message });
      toast.error(message);
      e.target.value = "";
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      const message = fileTooLargeMessage("20 MB");
      setDispensationOrderFeedback({ phase: "error", progress: 0, message });
      toast.error(message);
      e.target.value = "";
      return;
    }
    setDispensationOrderUploading(true);
    setDispensationOrderFeedback({ phase: "reading", progress: 24, message: `Preparing ${file.name}` });
    try {
      const arrayBuf = await file.arrayBuffer();
      const bytes = new Uint8Array(arrayBuf);
      let binary = "";
      for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
      const base64 = btoa(binary);
      // Keep the bytes local until Save. The server then commits the delivery
      // row and its durable storage reference as one lifecycle operation, so
      // Cancel cannot leave a provider object under a temporary delivery id.
      setPendingDispensationOrder({
        fileBase64: base64,
        fileName: file.name,
        mimeType: file.type,
      });
      setDispensationOrderFeedback({ phase: "complete", progress: 100, message: `${file.name} is ready to upload when you save this delivery.` });
      toast.success(`Dispensation order selected: ${file.name}. Save the delivery to upload it.`);
    } catch (err: any) {
      const message = err.message || `Unable to prepare ${file.name}. Please try again.`;
      setDispensationOrderFeedback({ phase: "error", progress: 0, message });
      toast.error(message);
    }
    setDispensationOrderUploading(false);
    if (dispensationOrderInputRef.current) dispensationOrderInputRef.current.value = "";
  };

  const handleRemoveDispensationOrder = () => {
    setFormOrderFile("");
    setPendingDispensationOrder(null);
  };

  const resetForm = () => {
    setFormContactId(""); setFormName(""); setFormAddress("");
    setFormMethod(""); setFormDate("");
    setFormTracking(""); setFormEmail(""); setFormAckDate("");
    setFormDispensed(false); setFormOrderDate(""); setFormOrderRegNo(""); setFormOrderFile(""); setPendingDispensationOrder(null);
    setFormP46Status("unknown"); setFormP46DemandReceivedDate(""); setFormP46CompliedDate(""); setFormP46ComplianceMethod(""); setFormP46Notes("");
    setFormP44Date(""); setFormP44Method("");
    setEditingId(null); setShowAddForm(false);
  };

  // The P9 details dialog edits the same deliveries rows. If the row being
  // edited here is deleted elsewhere (e.g. unchecked in the dialog's checklist),
  // close this editor — otherwise its Save would resurrect the deleted row
  // under its old id (upsert accepts client ids).
  // ponytail: guards only the deleted-row case; a stale open editor can still
  // overwrite newer field edits on Save — add an updatedAt conflict check if it bites.
  useEffect(() => {
    if (editingId && deliveries && !deliveries.some((d) => d.id === editingId)) {
      toast.info("This delivery record was removed elsewhere — editor closed");
      resetForm();
    }
  }, [deliveries, editingId]);

  const startEdit = (d: any) => {
    setEditingId(d.id);
    setFormContactId(d.contactId || "");
    setFormName(d.recipientName);
    setFormAddress(d.recipientAddress || "");
    setFormMethod(d.deliveryMethod || "");
    setFormDate(d.deliveryDate || "");
    setFormTracking(d.trackingNumber || "");
    setFormEmail(d.emailAddress || "");
    setFormAckDate(d.ackDate || "");
    setFormDispensed(d.dispensedByOrder === 1);
    setFormOrderDate(d.dispensationOrderDate || "");
    setFormOrderRegNo(d.dispensationOrderRegistryFileNumber || "");
    setFormOrderFile(d.dispensationOrderFilePath || "");
    setPendingDispensationOrder(null);
    setFormP44Date((d as any).p44DeliveryDate || "");
    setFormP44Method((d as any).p44DeliveryMethod || "");
    setFormP46Status(d.p46DemandStatus || "unknown");
    setFormP46DemandReceivedDate(d.p46DemandReceivedDate || "");
    setFormP46CompliedDate(d.p46CompliedDate || "");
    setFormP46ComplianceMethod(d.p46ComplianceMethod || "");
    setFormP46Notes(d.p46ComplianceNotes || "");
    setShowAddForm(true);
  };

  const startAddFromRecipient = (r: { contactId: string; name: string; address: string; email: string }) => {
    resetForm();
    setFormContactId(r.contactId);
    setFormName(r.name);
    setFormAddress(r.address);
    setFormEmail(r.email);
    setShowAddForm(true);
  };

  const handleSave = async () => {
    if (!formName.trim()) { toast.error("Recipient name is required"); return; }
    if (formDispensed && formIsPgt) { toast.error("Delivery to the Public Guardian and Trustee cannot be dispensed."); return; }
    if (formDispensed && (!formOrderDate || (!formOrderFile && !pendingDispensationOrder))) { toast.error("Attach the sealed order and record its date."); return; }
    if (!formDispensed && (!formMethod || !formDate)) { toast.error("Select an official Form P9 delivery method and record the delivery date."); return; }
    const deliveryMethod: "ordinary_mail" | "personal" | "electronic" = formDispensed ? "ordinary_mail" : formMethod as "ordinary_mail" | "personal" | "electronic";
    const id = editingId || `del_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    try {
      await upsertMutation.mutateAsync({
        id,
        estateId,
        contactId: formContactId,
        recipientName: formName.trim(),
        recipientAddress: formAddress.trim(),
        deliveryMethod,
        deliveryDate: formDispensed ? "" : formDate,
        trackingNumber: "",
        emailAddress: formMethod === "electronic" && !formDispensed ? formEmail : "",
        ackDate: formMethod === "electronic" && !formDispensed ? formAckDate : "",
        dispensedByOrder: formDispensed ? 1 : 0,
        dispensationOrderDate: formDispensed ? formOrderDate : "",
        dispensationOrderFilePath: formDispensed ? formOrderFile : "",
        dispensationOrderRegistryFileNumber: formDispensed ? formOrderRegNo : "",
        dispensationOrderUpload: formDispensed ? pendingDispensationOrder || undefined : undefined,
      });
      if (editingId && (formP46Eligible || originalP46Tracked)) {
        await updateP46Mutation.mutateAsync({
          id,
          estateId,
          status: formP46Status,
          demandReceivedDate: formP46DemandReceivedDate,
          compliedDate: formP46CompliedDate,
          complianceMethod: formP46ComplianceMethod,
          notes: formP46Notes,
        });
      }
      // P15PLUS-021: persist the P44 withdrawal-delivery date/method when either changed.
      if (editingId) {
        const currentRow = (deliveries || []).find((row) => row.id === editingId);
        if (formP44Date !== String((currentRow as any)?.p44DeliveryDate || "")
          || formP44Method !== String((currentRow as any)?.p44DeliveryMethod || "")) {
          await markP44Mutation.mutateAsync({ id, estateId, p44DeliveryDate: formP44Date, p44DeliveryMethod: formP44Method });
        }
      }
      invalidateDeliveryDerivedState();
      resetForm();
      toast.success(editingId ? "Delivery and P46 tracking saved" : "Delivery saved");
    } catch (err: any) {
      toast.error(err?.message || "Delivery could not be saved");
    }
  };

  // Recipients not yet in deliveries table
  const existingContactIds = new Set((deliveries || []).map(d => d.contactId).filter(Boolean));
  const unrecordedRecipients = (recipients || []).filter(r => r.contactId && !existingContactIds.has(r.contactId));
  const formIsPgt = (recipients || []).some((recipient) => recipient.contactId === formContactId && recipient.isPgt);
  const formP46Eligible = isElectronicWill
    && (recipients || []).some((recipient) => recipient.contactId === formContactId && recipient.p46Eligible);
  const originalP46Tracked = !!editingId && (deliveries || []).some((delivery) =>
    delivery.id === editingId && delivery.p46DemandStatus !== "unknown");

  const methodLabel = deliveryMethodLabel;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm">P9 — Delivery Records</CardTitle>
          <Button variant="outline" size="sm" onClick={() => { resetForm(); setShowAddForm(true); }}>
            <Plus className="h-3.5 w-3.5 mr-1.5" />
            Add Delivery
          </Button>
        </div>
        <p className="text-[10px] text-muted-foreground">Record how and when the P1 notice was delivered to each recipient. These records populate Form P9 (Affidavit of Delivery).</p>
      </CardHeader>
      <CardContent className="space-y-3">
        {loadingDeliveries && <div className="h-16 bg-muted animate-pulse rounded-lg" />}

        {/* Existing delivery records */}
        {(deliveries || []).length > 0 && (
          <div className="space-y-2">
            {(deliveries || []).map((d) => (
              <div key={d.id} className="flex items-center justify-between py-2 px-3 border rounded-lg">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium truncate">{d.recipientName}</p>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="secondary" className="text-[9px] px-1 py-0 h-4">
                      {d.dispensedByOrder === 1 ? "Dispensed" : methodLabel(d.deliveryMethod)}
                    </Badge>
                    {d.deliveryDate && <span className="text-[10px] text-muted-foreground">{d.deliveryDate}</span>}
                    {d.trackingNumber && <span className="text-[10px] text-muted-foreground">Track: {d.trackingNumber}</span>}
                    {d.dispensedByOrder === 1 && d.dispensationOrderDate && <span className="text-[10px] text-muted-foreground">Order: {d.dispensationOrderDate}</span>}
                    {d.deliveryMethod === "electronic" && d.ackDate && <span className="text-[10px] text-muted-foreground">Ack: {d.ackDate}</span>}
                    {d.p46DemandStatus && d.p46DemandStatus !== "unknown" && (
                      <Badge variant="outline" className="text-[9px] px-1 py-0 h-4">
                        P46: {d.p46DemandStatus === "no_demand" ? "No demand recorded" : d.p46DemandStatus === "demand_received" ? "Demand received" : "Complied"}
                      </Badge>
                    )}
                    {d.p46DemandReceivedDate && <span className="text-[10px] text-muted-foreground">Demand received: {d.p46DemandReceivedDate}</span>}
                    {d.p46CompliedDate && <span className="text-[10px] text-muted-foreground">Complied: {d.p46CompliedDate}</span>}
                    {(d as any).p44DeliveryDate && (
                      <Badge variant="outline" className="text-[9px] px-1 py-0 h-4">
                        P44 delivered: {(d as any).p44DeliveryDate}{(d as any).p44DeliveryMethod ? ` (${methodLabel((d as any).p44DeliveryMethod)})` : ""}
                      </Badge>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0 ml-2">
                  {isElectronicWill && (recipients || []).some((recipient) => recipient.contactId === d.contactId && recipient.p46Eligible) && (
                    <>
                    {onPreviewP46 && (
                    <Tooltip>
                      <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 w-7 p-0"
                        onClick={() => {
                          if (onOpenP46Details) {
                            onOpenP46Details(d.id, d.recipientName);
                            return;
                          }
                          const doPreview = () => onPreviewP46(d.id, d.recipientName);
                          if (runWithPreflight) void runWithPreflight(["P46"], `P46 — Demand for ${d.recipientName}`, doPreview, { targetDeliveryId: d.id }, "preview");
                          else doPreview();
                        }}
                        disabled={!signatureDate && !onOpenP46Details}
                      >
                        <Eye className="h-3 w-3" />
                      </Button>
                      </TooltipTrigger>
                      <TooltipContent side="top" className="max-w-[220px] text-center">
                        <p className="text-xs">Preview P46 Demand for Electronic Will. Choose the demandant's actual signature date in the next step.</p>
                      </TooltipContent>
                    </Tooltip>
                    )}
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 px-1.5 text-xs gap-1"
                          data-testid={`p46-generate-${d.id}`}
                          onClick={() => {
                            if (onOpenP46Details) {
                              onOpenP46Details(d.id, d.recipientName);
                              return;
                            }
                            const doMutate = (ov?: Record<string, unknown>) => p46Mutation.mutateAsync({ estateId, formCode: "P46", signatoryType: "executor", signatureDate, deliveryId: d.id, overrides: ov as Record<string, string | number | boolean> | undefined });
                            if (runWithPreflight) {
                              // A generation (its download is announced separately), so the dialog never claims a download.
                              void runWithPreflight(["P46"], `P46 — Demand for ${d.recipientName}`, doMutate, { targetDeliveryId: d.id, supportsOverrides: true }, "generate");
                            } else {
                              void doMutate();
                            }
                          }}
                          disabled={p46Mutation.isPending || (!signatureDate && !onOpenP46Details)}
                        >
                          <FileDown className="h-3 w-3" />
                          <span className="hidden sm:inline">P46</span>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent side="top" className="max-w-[220px] text-center">
                        <p className="text-xs">Generate P46 Demand for Electronic Will. Choose the demandant's actual signature date in the next step; the applicant must comply within 7 days after receiving the demand (Rule 25-2(1.4)).</p>
                      </TooltipContent>
                    </Tooltip>
                    </>
                  )}
                  <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => startEdit(d)} title="Edit">
                    <Pencil className="h-3 w-3" />
                  </Button>
                  <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-destructive" onClick={() => deleteMutation.mutate({ id: d.id, estateId })} title="Delete">
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Quick-add from unrecorded recipients */}
        {unrecordedRecipients.length > 0 && !showAddForm && (
          <div className="border border-dashed rounded-lg p-3 space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-[10px] text-muted-foreground font-medium">Recipients without delivery records:</p>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="default"
                    size="sm"
                    className="h-7 text-xs"
                    disabled={bulkCreateMutation.isPending}
                  >
                    <Send className="h-3 w-3 mr-1" />
                    {bulkCreateMutation.isPending ? "Creating..." : `Mark All Delivered (${unrecordedRecipients.length})`}
                    <ChevronDown className="h-3 w-3 ml-1 opacity-60" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-56 p-2">
                  <p className="text-[10px] text-muted-foreground font-medium mb-1 px-1">Delivery date (sworn on P9; starts the 21-day clock):</p>
                  <Input
                    type="date"
                    className="h-7 text-xs mb-2"
                    value={bulkDeliveryDate}
                    max={todayIn("America/Vancouver")}
                    onChange={(e) => setBulkDeliveryDate(e.target.value)}
                    data-testid="bulk-delivery-date"
                  />
                  <p className="text-[10px] text-muted-foreground font-medium mb-1.5 px-1">Delivery method:</p>
                  {/* No registered mail — the P9 face has no box for it, so bulk-created
                      registered rows would swear deliveries that never print. */}
                  {([
                    { value: "ordinary_mail", label: "Ordinary Mail" },
                    { value: "personal", label: "Personal Delivery" },
                  ] as const).map((method) => (
                    <button
                      key={method.value}
                      className="w-full text-left text-xs px-2 py-1.5 rounded hover:bg-accent transition-colors disabled:opacity-50"
                      disabled={!bulkDeliveryDate}
                      onClick={() => bulkCreateMutation.mutate({ estateId, deliveryMethod: method.value, deliveryDate: bulkDeliveryDate })}
                    >
                      {method.label}
                    </button>
                  ))}
                </PopoverContent>
              </Popover>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {unrecordedRecipients.map((r) => (
                <Button key={r.contactId} variant="outline" size="sm" className="h-7 text-xs max-w-full" onClick={() => startAddFromRecipient(r)} title={r.name}>
                  <Plus className="h-3 w-3 mr-1 shrink-0" />
                  <span className="truncate">{r.name}</span>
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Add/Edit form */}
        {showAddForm && (
          <div className="border rounded-lg p-3 space-y-3 bg-muted/30">
            <div className="flex items-center justify-between">
              <p className="text-xs font-medium">{editingId ? "Edit Delivery" : "Add Delivery Record"}</p>
              <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={resetForm}>
                <X className="h-3.5 w-3.5" />
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="sm:col-span-2">
                <Label className="text-[10px]">Recipient Name</Label>
                <Input className="h-8 text-xs mt-1" value={formName} onChange={(e) => setFormName(e.target.value)} placeholder="Full name" />
              </div>
              <div className="sm:col-span-2">
                <Label className="text-[10px]">Address</Label>
                <Input className="h-8 text-xs mt-1" value={formAddress} onChange={(e) => setFormAddress(e.target.value)} placeholder="Mailing address" />
              </div>

              {/* Dispensed by court order toggle */}
              <div className="sm:col-span-2 flex items-center gap-2">
                <Checkbox id="dispensed" checked={formDispensed} disabled={formIsPgt} onCheckedChange={(v) => setFormDispensed(!!v)} />
                <Label htmlFor="dispensed" className="text-xs cursor-pointer">Delivery dispensed by court order</Label>
                {formIsPgt && <span className="text-[10px] text-muted-foreground">Not available for the PGT</span>}
              </div>

              {formDispensed ? (
                <div className="sm:col-span-2 space-y-2">
                  <div>
                    <Label className="text-[10px]">Court Order Date</Label>
                    <Input type="date" className="h-8 text-xs mt-1" value={formOrderDate} onChange={(e) => setFormOrderDate(e.target.value)} />
                  </div>
                  <div>
                    <Label className="text-[10px]">Registry File Number</Label>
                    <Input className="h-8 text-xs mt-1" placeholder="e.g. VAN-S-12345" value={formOrderRegNo} onChange={(e) => setFormOrderRegNo(e.target.value)} />
                  </div>
                  <div>
                    <Label className="text-[10px]">Sealed Court Order (PDF)</Label>
                    {formOrderFile || pendingDispensationOrder ? (
                      <div className="flex items-center gap-2 mt-1 p-1.5 rounded border bg-muted/20">
                        <FileText className="h-3.5 w-3.5 text-primary shrink-0" />
                        <span className="text-[10px] truncate flex-1">{pendingDispensationOrder?.fileName || formOrderFile.split('/').pop()}</span>
                        {!pendingDispensationOrder && formOrderFile && (
                          <Button type="button" variant="ghost" size="sm" className="h-6 w-6 p-0" title="View" onClick={() => void previewStoredFile(formOrderFile)}>
                            <Eye className="h-3 w-3" />
                          </Button>
                        )}
                        <Button type="button" variant="ghost" size="sm" className="h-6 w-6 p-0" title="Remove" onClick={handleRemoveDispensationOrder}>
                          <Trash2 className="h-3 w-3 text-destructive" />
                        </Button>
                      </div>
                    ) : (
                      <div>
                        <Button type="button" variant="outline" size="sm" className="h-7 text-[10px] mt-1 w-full" onClick={() => dispensationOrderInputRef.current?.click()} disabled={dispensationOrderUploading}>
                          <Upload className="h-3 w-3 mr-1" />
                          {dispensationOrderUploading ? "Uploading..." : "Upload sealed order"}
                        </Button>
                        <UploadFeedback state={dispensationOrderFeedback} compact className="mt-2" />
                        <input ref={dispensationOrderInputRef} type="file" className="hidden" accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.tiff,.tif" onChange={handleDispensationOrderFileSelect} />
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <>
                  <div>
                    <Label htmlFor="delivery-record-method" className="text-[10px]">Delivery Method</Label>
                    <select
                      id="delivery-record-method"
                      data-testid="delivery-method-select"
                      className="h-8 text-xs mt-1 w-full rounded-md border border-input bg-transparent px-2"
                      value={formMethod}
                      onChange={(e) => setFormMethod(e.target.value as "ordinary_mail" | "personal" | "electronic")}
                    >
                      <option value="">Select method</option>
                      <option value="ordinary_mail">Ordinary Mail</option>
                      <option value="personal">Personal Delivery</option>
                      <option value="electronic">Electronic (Email/Fax)</option>
                    </select>
                  </div>
                  <div>
                    <Label htmlFor="delivery-record-date" className="text-[10px]">Delivery Date</Label>
                    <Input id="delivery-record-date" type="date" className="h-8 text-xs mt-1" value={formDate} onChange={(e) => setFormDate(e.target.value)} />
                  </div>

                  {formMethod === "electronic" && (
                    <>
                      <div>
                        <Label className="text-[10px]">Email Address</Label>
                        <Input className="h-8 text-xs mt-1" value={formEmail} onChange={(e) => setFormEmail(e.target.value)} placeholder="recipient@example.com" />
                      </div>
                      <div>
                        <Label className="text-[10px]">Acknowledgement Date</Label>
                        <Input type="date" className="h-8 text-xs mt-1" value={formAckDate} onChange={(e) => setFormAckDate(e.target.value)} />
                      </div>
                    </>
                  )}
                </>
              )}
            </div>

            {editingId && (
              <div className="space-y-1 rounded-md border p-3">
                <Label className="text-[10px]">P44 withdrawal notice delivered (Rule 25-3.2(1)) — if the application is withdrawn, a copy must go to every person entitled to notice under the original application</Label>
                <input
                  type="date"
                  data-testid="delivery-p44-date"
                  value={formP44Date}
                  onChange={(e) => setFormP44Date(e.target.value)}
                  className="h-9 w-full rounded-md border bg-transparent px-2 text-xs"
                />
                <select
                  data-testid="delivery-p44-method"
                  className="h-9 w-full rounded-md border bg-transparent px-2 text-xs"
                  value={formP44Method}
                  onChange={(e) => setFormP44Method(e.target.value as "ordinary_mail" | "personal" | "electronic")}
                >
                  <option value="">P44 delivery method (optional)</option>
                  <option value="ordinary_mail">Ordinary Mail</option>
                  <option value="personal">Personal Delivery</option>
                  <option value="electronic">Electronic (Email/Fax)</option>
                </select>
              </div>
            )}
            {formP46Eligible && editingId && (
              <div className="space-y-3 rounded-md border border-blue-200 bg-blue-50/40 p-3 dark:border-blue-900 dark:bg-blue-950/20">
                <div>
                  <p className="text-xs font-semibold">P46 demand tracking</p>
                  <p className="text-[10px] text-muted-foreground">If this notice recipient serves a Form P46 demand, the applicant must provide the original electronic will or repository access within 7 days after receipt (Rule 25-2(1.4)).</p>
                </div>
                <div className="space-y-1">
                  <Label className="text-[10px]">Demand status</Label>
                  <Select value={formP46Status} onValueChange={(value: "unknown" | "no_demand" | "demand_received" | "complied") => setFormP46Status(value)}>
                    <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="unknown">Not yet recorded</SelectItem>
                      <SelectItem value="no_demand">No demand received</SelectItem>
                      <SelectItem value="demand_received">Demand received — compliance outstanding</SelectItem>
                      <SelectItem value="complied">Demand received and complied with</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {(formP46Status === "demand_received" || formP46Status === "complied") && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label className="text-[10px]">Date applicant received the demand *</Label>
                      <Input type="date" className="h-8 text-xs" value={formP46DemandReceivedDate} onChange={(e) => setFormP46DemandReceivedDate(e.target.value)} />
                    </div>
                    {formP46Status === "complied" && (
                      <div className="space-y-1">
                        <Label className="text-[10px]">Date the applicant complied *</Label>
                        <Input type="date" className="h-8 text-xs" value={formP46CompliedDate} onChange={(e) => setFormP46CompliedDate(e.target.value)} />
                      </div>
                    )}
                  </div>
                )}
                {formP46Status === "complied" && (
                  <div className="space-y-1">
                    <Label className="text-[10px]">How the will was provided *</Label>
                    <Select value={formP46ComplianceMethod || ""} onValueChange={(value: "original_electronic_form" | "repository_access") => setFormP46ComplianceMethod(value)}>
                      <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Select method" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="original_electronic_form">Original electronic form provided</SelectItem>
                        <SelectItem value="repository_access">Third-party repository access provided</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
                <div className="space-y-1">
                  <Label className="text-[10px]">P46 notes</Label>
                  <Textarea className="min-h-16 text-xs" value={formP46Notes} onChange={(e) => setFormP46Notes(e.target.value)} placeholder="Delivery method, confirmation, or follow-up details" />
                </div>
              </div>
            )}

            {editingId && !formP46Eligible && originalP46Tracked && (
              <Alert className="border-amber-300 bg-amber-50/60 dark:bg-amber-950/20">
                <AlertDescription className="space-y-2 text-xs">
                  <p>This row is no longer eligible for Form P46 tracking. Clear the obsolete state before deleting the delivery or changing the estate workflow.</p>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="h-7 text-xs"
                    disabled={updateP46Mutation.isPending}
                    onClick={async () => {
                      await updateP46Mutation.mutateAsync({
                        id: editingId,
                        estateId,
                        status: "unknown",
                        demandReceivedDate: "",
                        compliedDate: "",
                        complianceMethod: "",
                        notes: "",
                      });
                      resetForm();
                      toast.success("Obsolete P46 tracking cleared");
                    }}
                  >
                    Clear obsolete P46 tracking
                  </Button>
                </AlertDescription>
              </Alert>
            )}

            <div className="flex justify-end gap-2 pt-1">
              <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={resetForm}>Cancel</Button>
              <Button size="sm" className="h-7 text-xs" onClick={() => void handleSave()} disabled={upsertMutation.isPending || updateP46Mutation.isPending}>
                {(upsertMutation.isPending || updateP46Mutation.isPending) ? "Saving…" : editingId ? "Update" : "Save"}
              </Button>
            </div>
          </div>
        )}

        {/* Empty state */}
        {!loadingDeliveries && (!deliveries || deliveries.length === 0) && !showAddForm && unrecordedRecipients.length === 0 && (
          <p className="text-xs text-muted-foreground py-2">No delivery records yet. Add P1 recipients in the Contacts tab first, then record deliveries here.</p>
        )}
      </CardContent>
    </Card>
  );
}

// ─── DISTRIBUTION CARD (supplementary P10 section) ────────────────────
export function DistributionCard({ estateId, estate }: { estateId: string; estate: any }) {
  const { data: distResult, isLoading } = trpc.distribution.compute.useQuery({ estateId });
  const { data: contacts } = trpc.contact.list.useQuery({ estateId });
  const utils = trpc.useUtils();
  const invalidateDistributionDerivedState = () => {
    void utils.distribution.compute.invalidate({ estateId });
    void utils.estate.get.invalidate({ id: estateId });
    void utils.contact.list.invalidate({ estateId });
    void utils.readiness.check.invalidate({ estateId });
    void utils.readiness.timeline.invalidate({ estateId });
    void utils.deadline.list.invalidate();
    void utils.document.preflight.invalidate();
    void utils.document.preflightMany.invalidate();
  };
  const updateShareMutation = trpc.distribution.updateShare.useMutation({
    onSuccess: () => {
      invalidateDistributionDerivedState();
      toast.success("Share updated");
    },
  });
  const updateContactMutation = trpc.contact.update.useMutation({
    onSuccess: invalidateDistributionDerivedState,
  });
  const splitEquallyMutation = trpc.distribution.splitEqually.useMutation({
    // The route reports refusals in its payload rather than throwing (no beneficiaries,
    // every beneficiary predeceased), so the error branch lives here as well as in
    // onError — a resolved promise can still mean nothing was written.
    onSuccess: (data) => {
      invalidateDistributionDerivedState();
      if (!data.success) {
        toast.error(data.error);
        return;
      }
      toast.success(
        `Shares split equally — ${data.updated} beneficiar${data.updated === 1 ? "y" : "ies"} updated`
        + (data.skipped.length ? `, ${data.skipped.length} skipped as predeceased (${data.skipped.join(", ")})` : "")
        + (data.staleShares.length ? `. ${data.staleShares.join(", ")} still carry a recorded share that was not changed` : "")
      );
    },
    // The route writes N contacts sequentially and untransacted; without this a failure
    // partway through would leave a half-rewritten distribution with no feedback at all.
    onError: (err) => toast.error(err.message || "Could not split shares"),
  });

  const updateEstateMutation = trpc.estate.update.useMutation({
    onSuccess: invalidateDistributionDerivedState,
  });
  const addGrandchildMutation = trpc.contact.create.useMutation({
    onSuccess: () => {
      invalidateDistributionDerivedState();
      toast.success("Grandchild added");
    },
  });
  const [addingGrandchildFor, setAddingGrandchildFor] = useState<string | null>(null);
  const [gcName, setGcName] = useState("");

  const gt = normalizeGrantType(estate?.grantType || "");
  const isIntestacy = gt === "admin_no_will";
  const isPartialIntestacy = !!estate?.partialIntestacy;

  // Identify descendants for the common-descendant toggle and the Per Stirpes card.
  // Uses the SHARED engine predicate rather than a hand-copy: a duplicated filter
  // is exactly how computePreferentialShareCents drifted out of step with
  // computeIntestacyShares. The engine asks for an answer from every descendant it
  // scans (including a grandchild taking by representation), so this list must
  // never be narrower than isDescendantContact or a file could not be reconciled.
  const descendants = (contacts || []).filter((c: any) => isDescendantContact(c));
  // The generation immediately below a descendant, in that descendant's OWN line:
  // a child's issue are grandchildren, a grandchild's issue are great-grandchildren,
  // and so on without limit (WESA s.24(2) recurses "in the same manner").
  //
  // The "Add" button below renders under ANY predeceased descendant row, so
  // hard-coding "grandchild" stamped that label on the child of a predeceased
  // GRANDCHILD — this control was the production source of the very kinship
  // mislabel the recursion test had encoded, and it wrote a false relationship
  // onto a contact whose share is sworn on Form P10.
  const issueRelationshipOf = (d: any): string => {
    // Separators are normalized to hyphens before prefixing, so a stored
    // "great grandchild" yields "great-great-grandchild" rather than the mixed
    // "great-great grandchild" — the label is sworn verbatim on Form P10.
    const rel = String(d?.relationship || "").toLowerCase().trim().replace(/\s+/g, "-");
    if (/^(great-)*grand(child|son|daughter)$/.test(rel)) {
      return `great-${rel.replace(/(son|daughter)$/, "child")}`;
    }
    return "grandchild"; // the issue of a child
  };
  // Uses the engine's own spouse set, for the reason the comment above gives:
  // this filter WAS a hand-copy, the engine moved to WESA s.2(1) via
  // spousalStatus(), and the copy stayed behind — so a qualifying common-law
  // partner was a spouse to the engine and not to the UI, which deadlocked the
  // file (engine demands the common-descendant answer, UI hides the control).
  const spouseContacts = (contacts || []).filter((c: any) => isSpouseCandidate(c));
  const hasSpouse = spouseContacts.length > 0;
  // Partial intestacy (WESA s.25) runs the SAME s.21 computation on the undisposed
  // portion, so the answer is required there too. Gating on isIntestacy alone left
  // a probate + partialIntestacy file demanding an answer with no control to give
  // it — permanently unreconcilable from the UI.
  const showCommonToggle = (isIntestacy || isPartialIntestacy) && hasSpouse && descendants.length > 0;

  // Debounced testate portion input
  const [localTestatePortion, setLocalTestatePortion] = useState<string>(
    ((estate?.testatePortionCents || 0) / 100).toFixed(2)
  );
  const testateDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    setLocalTestatePortion(((estate?.testatePortionCents || 0) / 100).toFixed(2));
  }, [estate?.testatePortionCents]);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editShare, setEditShare] = useState("");
  const [editShareType, setEditShareType] = useState<"percentage" | "specific_bequest" | "">("percentage");
  const [editValue, setEditValue] = useState("");

  // finding-12: the "Split equally" button was gated on `distResult.shares.length >= 0`
  // — always true — so it showed on every testate file. `shares` is not the beneficiary
  // count either: buildTestateDistribution filters on `b.share || b.estimatedValue`, so
  // gating on it would hide the button precisely when nothing has been recorded yet.
  // Gate and describe the action using the SAME predicate the route overwrites
  // (contactHasRole "beneficiary"), so the dialog cannot misreport what will change.
  const [splitConfirmOpen, setSplitConfirmOpen] = useState(false);
  const splitBeneficiaries = ((contacts as any[]) || []).filter((c: any) => contactHasRole(c, "beneficiary"));
  const splitPredeceased = splitBeneficiaries.filter((c: any) => c.isPredeceased === 1);
  const splitLiving = splitBeneficiaries.filter((c: any) => c.isPredeceased !== 1);
  const splitOverwrites = splitLiving.filter((c: any) => c.share || c.estimatedValue);
  // A predeceased beneficiary who already carries a share is NOT "left unallocated":
  // buildTestateDistribution applies no isPredeceased filter, so that stale share keeps
  // printing on the sworn P10 next to the new equal split. Say so rather than implying
  // the app cleared it.
  const splitStaleShares = splitPredeceased.filter((c: any) => c.share || c.estimatedValue);
  const splitPct = splitBeneficiaries.length
    ? (100 / splitBeneficiaries.length).toFixed(2).replace(/\.?0+$/, "")
    : "";
  const contactLabel = (c: any) => c.name || "(unnamed contact)";
  const confirmSplitEqually = () => {
    setSplitConfirmOpen(false);
    splitEquallyMutation.mutate({ estateId });
  };

  // Read the STORED contact record, never the derived shareDescription.
  // shareDescription is engine-authored prose that now carries explanatory
  // suffixes ("— estimated value at death not recorded", "— spousal status not
  // determined …"). Reverse-engineering the edit form out of it was already
  // fragile — `.replace(/%$/, "")` stopped matching the moment a suffix was
  // appended — and it round-tripped: saving wrote the whole sentence into
  // contacts.share, which the engine re-rendered and re-suffixed, so the text
  // compounded on every edit and printed verbatim in the Share column of the
  // sworn P10. The blanked row is precisely the row the warning tells the user
  // to click ("Distribution card → edit"), so this was on the remediation path.
  // estimatedValue likewise comes from the record, not from the blanked row.
  const startEdit = (share: any) => {
    const stored: any = (contacts || []).find((c: any) => String(c.id) === String(share.contactId));
    setEditingId(share.contactId);
    setEditShare(String(stored?.share ?? ""));
    setEditShareType(String(stored?.shareType || "") === "specific_bequest" ? "specific_bequest" : "percentage");
    setEditValue(((Number(stored?.estimatedValue) || 0) / 100).toFixed(2));
  };

  const saveEdit = (contactId: string) => {
    updateShareMutation.mutate({
      estateId,
      contactId,
      share: editShare,
      shareType: editShareType,
      estimatedValue: parseCurrencyToCents(editValue || "0"),
    });
    setEditingId(null);
  };

  if (isLoading) return <Card><CardContent className="py-6"><div className="h-12 bg-muted animate-pulse rounded" /></CardContent></Card>;

  return (
    <Card id="distribution-section">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm">Distribution (P10 supplement)</CardTitle>
          <div className="flex items-center gap-2">
            {!isIntestacy && splitBeneficiaries.length > 0 && (
              <Button
                size="sm"
                variant="outline"
                className="h-6 text-[10px] px-2"
                onClick={() => setSplitConfirmOpen(true)}
                disabled={splitEquallyMutation.isPending}
              >
                Split equally
              </Button>
            )}
            <AlertDialog open={splitConfirmOpen} onOpenChange={(open) => { if (!open && !splitEquallyMutation.isPending) setSplitConfirmOpen(false); }}>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Set affected beneficiaries to an equal split?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This replaces the share, share type and estimated value of{" "}
                    {splitLiving.length} affected living beneficiar{splitLiving.length === 1 ? "y" : "ies"} from{" "}
                    {splitBeneficiaries.length} beneficiary record{splitBeneficiaries.length === 1 ? "" : "s"}{" "}
                    with {splitPct}% each. Only do this if the will actually directs an equal
                    division — the app cannot read that from the will, and an equal split it
                    does not direct would be sworn on the Form P10 distribution supplement.
                    <br /><br />
                    This is an action count, not a Form P10 row count. Form P10 can include
                    additional recorded shares, gifts, or beneficiaries that this action leaves unchanged;
                    review the distribution supplement after applying the split.
                    {splitOverwrites.length > 0 && (<>
                      <br /><br />
                      Shares already recorded, which will be replaced:{" "}
                      {splitOverwrites.map(contactLabel).join(", ")}.
                    </>)}
                    {splitPredeceased.length > 0 && (<>
                      <br /><br />
                      Skipped as recorded predeceased: {splitPredeceased.map(contactLabel).join(", ")}.
                      No new share is written to them, and their portion is not reallocated —
                      this app does not determine the WESA s.46 gift-over, so resolve it yourself.
                    </>)}
                    {splitStaleShares.length > 0 && (<>
                      <br /><br />
                      Note: {splitStaleShares.map(contactLabel).join(", ")} already{" "}
                      {splitStaleShares.length === 1 ? "carries" : "carry"} a recorded share.
                      That share is left exactly as it is and will still print on Form P10
                      alongside the new equal split, so the distribution will not total 100%
                      until you resolve it.
                    </>)}
                    <br /><br />
                    This cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel disabled={splitEquallyMutation.isPending}>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={confirmSplitEqually}
                    disabled={splitEquallyMutation.isPending}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    Overwrite shares
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
            {distResult && (
              <Badge variant={distResult.isReconciled ? "default" : "destructive"} className="text-[10px]">
                {distResult.isReconciled ? "Reconciled" : "Not Reconciled"}
              </Badge>
            )}
          </div>
        </div>
        {isIntestacy && (
          <p className="text-xs text-muted-foreground">WESA {distResult?.wesaSection} — auto-computed</p>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        {isIntestacy && (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription className="text-xs">
              Intestacy shares are auto-computed under WESA Part 3 Division 1 (ss.20–25). Verify with counsel before filing — the computation does not account for: (i) property outside BC that passes under foreign law (WESA s.122(1)(b)(i)-(iii)); (ii) survivorship presumptions; (iii) disclaimers or advancements; (iv) common-law spouse validity determinations.
            </AlertDescription>
          </Alert>
        )}

        {/* Partial Intestacy Toggle (WESA s.25) — only for testate estates */}
        {!isIntestacy && (
          <div className="border rounded-lg p-3 space-y-2 bg-muted/20">
            <label className="flex items-center gap-2 text-xs cursor-pointer">
              <Checkbox
                checked={isPartialIntestacy}
                onCheckedChange={(checked) => {
                  updateEstateMutation.mutate({
                    id: estateId,
                    expectedRevision: estate.revision,
                    data: { partialIntestacy: checked ? 1 : 0 },
                  });
                }}
              />
              <span className="font-medium">Partial intestacy (WESA s.25)</span>
            </label>
            <p className="text-[10px] text-muted-foreground">Check if the will does not dispose of the entire estate. The undisposed portion will pass under intestacy rules.</p>
            {isPartialIntestacy && (
              <div className="flex items-center gap-2 pt-1">
                <Label className="text-xs whitespace-nowrap">Testate portion ($):</Label>
                <Input
                  className="h-7 text-xs w-40"
                  type="number"
                  step="0.01"
                  min="0"
                  value={localTestatePortion}
                  onChange={(e) => {
                    const val = e.target.value;
                    setLocalTestatePortion(val);
                    if (testateDebounceRef.current) clearTimeout(testateDebounceRef.current);
                    testateDebounceRef.current = setTimeout(() => {
                      const cents = parseCurrencyToCents(val || "0");
                      updateEstateMutation.mutate({
                        id: estateId,
                        expectedRevision: estate.revision,
                        data: { testatePortionCents: cents },
                      });
                    }, 500);
                  }}
                />
                <span className="text-[10px] text-muted-foreground">Amount disposed by will</span>
              </div>
            )}
          </div>
        )}

        {/* The per-spouse INPUT was never hidden (it keys on isSpouseCandidate),
            so the file could always be fixed — but only by a user who already
            knew what to do. See showsMultiSpouseGuidance. */}
        {showsMultiSpouseGuidance({ isIntestacy, isPartialIntestacy, spouseCount: spouseContacts.length, isSeparated: !!estate && isSpouseSeparated(estate as any) }) && (
          <div className="border border-amber-300 dark:border-amber-700 rounded-lg p-3 space-y-1 bg-amber-50 dark:bg-amber-950/30">
            <p className="text-xs font-medium text-amber-800 dark:text-amber-200">WESA s.22 — Multiple Spouses ({spouseContacts.length})</p>
            <p className="text-[10px] text-amber-700 dark:text-amber-300">This estate has {spouseContacts.length} spouses per WESA s.2. Under s.22(1) they share the spousal portion <strong>in the portions to which they agree, or if they cannot agree, as determined by the court</strong> — the Act supplies no equal default. Record each spouse's agreed portion in basis points (they must total 10000 = 100%) in their contact editor. Until every portion is recorded, the spousal rows render as blanks on Form P10.</p>
          </div>
        )}

        {showCommonToggle && (
          <div className="border rounded-lg p-3 space-y-2 bg-muted/20">
            <p className="text-xs font-medium">Descendant Relationship to Spouse</p>
            <p className="text-[10px] text-muted-foreground">Is each descendant a common descendant of BOTH the intestate and the surviving spouse? All common → the preferential share is $300,000 (s.21(3)); any not common → $150,000 (s.21(4)).</p>
            {/* finding-3 (2026-07-27): tri-state, not a checkbox. An unanswered
                descendant highlights neither option and leaves the preferential
                share undetermined — no branch is chosen from a blank (Rule 11). */}
            <div className="space-y-1.5">
              {descendants.map((d: any) => (
                <div key={d.id} className="flex items-center justify-between gap-3 text-xs">
                  <span className="min-w-0 truncate">
                    {d.name}
                    {!d.commonDescendantStatus && <span className="ml-1.5 text-amber-700 dark:text-amber-300">— not answered</span>}
                  </span>
                  <div className="w-32 shrink-0">
                    <TriToggle
                      value={d.commonDescendantStatus || ""}
                      onChange={(v) => {
                        updateContactMutation.mutate({
                          id: d.id,
                          estateId,
                          data: { commonDescendantStatus: v },
                        });
                      }}
                      options={["yes", "no"]}
                      labels={["Yes", "No"]}
                    />
                  </div>
                </div>
              ))}
            </div>
            {descendants.some((d: any) => !d.commonDescendantStatus) && (
              <p className="text-[10px] text-amber-700 dark:text-amber-300">
                ⚠️ Until every descendant is answered, the spousal preferential share and the residue print as blanks on Form P10 — the $300,000 and $150,000 branches cannot be told apart.
              </p>
            )}
          </div>
        )}

        {/* Per Stirpes (Representation) — mark children as predeceased + link grandchildren */}
        {/* Same reasoning as showCommonToggle: s.25 runs the s.24 representation
            rules on the undisposed portion, so the per-stirpes links are needed on a
            partial-intestacy file too. */}
        {(isIntestacy || isPartialIntestacy) && descendants.length > 0 && (
          <div className="border rounded-lg p-3 space-y-2 bg-muted/20">
            <p className="text-xs font-medium">Per Stirpes — Representation (WESA s.24)</p>
            <p className="text-[10px] text-muted-foreground">Mark a descendant as predeceased if they died before the intestate. Their share passes to their own children by representation (WESA s.24(2)), to any depth. Use the button below — it records the correct relationship for that generation automatically — or add the person in the Contacts tab and link them to their predeceased parent.</p>
            <div className="space-y-2">
              {descendants.map((d: any) => {
                const grandchildren = (contacts || []).filter((c: any) => c.parentContactId === d.id);
                return (
                  <div key={d.id} className="space-y-1">
                    <label className="flex items-center gap-2 text-xs cursor-pointer">
                      <Checkbox
                        checked={d.isPredeceased === 1}
                        onCheckedChange={(checked) => {
                          updateContactMutation.mutate({
                            id: d.id,
                            estateId,
                            data: { isPredeceased: checked ? 1 : 0 },
                          });
                        }}
                      />
                      <span className={d.isPredeceased === 1 ? "line-through text-muted-foreground" : ""}>{d.name}</span>
                      {d.isPredeceased === 1 && <Badge variant="secondary" className="text-[9px] h-4">Predeceased</Badge>}
                    </label>
                    {d.isPredeceased === 1 && (
                      <div className="ml-6 space-y-1">
                        {grandchildren.length > 0 ? (
                          grandchildren.map((gc: any) => (
                            <div key={gc.id} className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                              <span className="w-3 h-3 border-l border-b border-border" />
                              <span>{gc.name}</span>
                              <span>— takes by representation</span>
                            </div>
                          ))
                        ) : (
                          <p className="text-[10px] text-muted-foreground italic">No grandchildren linked yet.</p>
                        )}
                        {addingGrandchildFor === d.id ? (
                          <div className="flex items-center gap-1.5 mt-1">
                            <Input
                              className="h-6 text-xs w-40"
                              placeholder="Grandchild name"
                              value={gcName}
                              onChange={(e) => setGcName(e.target.value)}
                              autoFocus
                              onKeyDown={(e) => {
                                if (e.key === "Enter" && gcName.trim()) {
                                  addGrandchildMutation.mutate({
                                    estateId,
                                    name: gcName.trim(),
                                    role: "beneficiary",
                                    relationship: issueRelationshipOf(d),
                                    recipientType: "intestate_successor",
                                    parentContactId: d.id,
                                    address: "", email: "", phone: "",
                                  } as any);
                                  setGcName("");
                                  setAddingGrandchildFor(null);
                                } else if (e.key === "Escape") {
                                  setGcName("");
                                  setAddingGrandchildFor(null);
                                }
                              }}
                            />
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-6 px-2 text-[10px]"
                              disabled={!gcName.trim() || addGrandchildMutation.isPending}
                              onClick={() => {
                                if (gcName.trim()) {
                                  addGrandchildMutation.mutate({
                                    estateId,
                                    name: gcName.trim(),
                                    role: "beneficiary",
                                    relationship: issueRelationshipOf(d),
                                    recipientType: "intestate_successor",
                                    parentContactId: d.id,
                                    address: "", email: "", phone: "",
                                  } as any);
                                  setGcName("");
                                  setAddingGrandchildFor(null);
                                }
                              }}
                            >
                              Add
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-6 w-6 p-0"
                              onClick={() => { setGcName(""); setAddingGrandchildFor(null); }}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                        ) : (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-5 px-2 text-[10px] text-primary"
                            onClick={() => setAddingGrandchildFor(d.id)}
                          >
                            <Plus className="h-3 w-3 mr-0.5" /> Add {issueRelationshipOf(d) === "grandchild" ? "Grandchild" : "Descendant"}
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {distResult && distResult.shares.length > 0 ? (
          // overflow-x-auto (not overflow-hidden): the 5 columns plus the inline
          // w-20/w-24 edit inputs exceed a phone's width and were being clipped
          // with no way to reach them.
          <div className="border rounded-lg overflow-x-auto">
            <table className="w-full min-w-[520px] text-xs">
              <thead>
                <tr className="bg-muted/50">
                  <th className="text-left px-3 py-2 font-medium">Beneficiary</th>
                  <th className="text-left px-3 py-2 font-medium">Relationship</th>
                  <th className="text-left px-3 py-2 font-medium">Share</th>
                  <th className="text-right px-3 py-2 font-medium">Est. Value</th>
                  {!isIntestacy && <th className="px-2 py-2 w-16" />}
                </tr>
              </thead>
              <tbody>
                {distResult.shares.map((share) => (
                  <tr key={share.contactId || share.name} className="border-t border-border/50">
                    {editingId === share.contactId ? (
                      <>
                        <td className="px-3 py-2 font-medium">{share.name}</td>
                        <td className="px-3 py-2">{share.relationship}</td>
                        <td className="px-3 py-1">
                          <div className="flex items-center gap-1">
                            <Select value={editShareType} onValueChange={(v: any) => setEditShareType(v)}>
                              <SelectTrigger className="h-7 w-20 text-[10px]">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="percentage">%</SelectItem>
                                <SelectItem value="specific_bequest">Bequest</SelectItem>
                              </SelectContent>
                            </Select>
                            <Input
                              className="h-7 w-20 text-xs"
                              value={editShare}
                              onChange={(e) => setEditShare(e.target.value)}
                              placeholder={editShareType === "percentage" ? "50" : "Description"}
                            />
                          </div>
                        </td>
                        <td className="px-3 py-1">
                          {/* Saving this field RECORDS the value, including 0.00 —
                              that is how a keepsake or a nominal legacy becomes a
                              recorded $0 that reconciles, rather than an
                              unanswered blank (migration 0107). The title makes
                              the consequence visible before the click. */}
                          <Input
                            className="h-7 w-24 text-xs text-right"
                            value={editValue}
                            onChange={(e) => setEditValue(e.target.value)}
                            placeholder="0.00"
                            type="number"
                            step="0.01"
                            title="Saving records this value on the contact, including 0.00. Leave the row unsaved if the value is not yet known — Form P10 shows a blank until it is recorded."
                          />
                        </td>
                        <td className="px-2 py-1">
                          <div className="flex gap-1">
                            <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => saveEdit(share.contactId)}>
                              <CheckCircle2 className="h-3.5 w-3.5 text-green-600" />
                            </Button>
                            <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => setEditingId(null)}>
                              <X className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </td>
                      </>
                    ) : (
                      <>
                        <td className="px-3 py-2 font-medium">{share.name}</td>
                        <td className="px-3 py-2 text-muted-foreground">{share.relationship}</td>
                        <td className="px-3 py-2">{share.shareDescription}</td>
                        {/* An unallocated share renders the blank fill, mirroring the
                            P10 DOCX and preview exactly. Printing formatMoney(0) here
                            put a fabricated "$0.00" on screen while the sworn form
                            showed a blank (adr-no-fabricated-sworn-facts). */}
                        <td className="px-3 py-2 text-right font-mono">{share.isUnallocated ? "" : formatMoney(share.estimatedValueCents)}</td>
                        {!isIntestacy && (
                          <td className="px-2 py-2">
                            <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => startEdit(share)}>
                              <Pencil className="h-3 w-3" />
                            </Button>
                          </td>
                        )}
                      </>
                    )}
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t bg-muted/30 font-medium">
                  <td colSpan={isIntestacy ? 3 : 3} className="px-3 py-2 text-right">Total Distribution</td>
                  {/* Blank whenever any share is unallocated — the total of a set
                      containing an undetermined amount is itself undetermined. */}
                  <td className="px-3 py-2 text-right font-mono">{distResult.shares.some((s: any) => s.isUnallocated) ? "" : formatMoney(distResult.totalDistributionCents)}</td>
                  {!isIntestacy && <td />}
                </tr>
                <tr className="border-t">
                  <td colSpan={isIntestacy ? 3 : 3} className="px-3 py-2 text-right text-muted-foreground">Net Estate Value</td>
                  {/* Blank until the inventory is fully valued. The share rows
                      and the Total already blank on isUnallocated, but this
                      footer reads netEstateCents directly — and when the values
                      are incomplete that number is the placeholder 0 the engine
                      was fed, exactly as the sworn P10 blanks its own summary
                      rows. Printing "$0.00" here would be a figure the form
                      refuses to state. */}
                  <td className="px-3 py-2 text-right font-mono text-muted-foreground">{(distResult as any).valuesRecorded === false ? "" : formatMoney(distResult.netEstateCents)}</td>
                  {!isIntestacy && <td />}
                </tr>
              </tfoot>
            </table>
            {/* WESA s.21(1) defines the "net value of an intestate estate" the
                preferential-share tests run against. Nothing on this surface
                told the user what that figure is supposed to exclude, so an
                unrecorded funeral bill or a mis-typed tangible silently moved
                the s.21(5)/(6) boundary. Intestacy only — s.21(1) does not
                define anything for a testate distribution. */}
            {isIntestacy && (
              <p className="text-[10px] text-muted-foreground leading-tight mt-2">
                WESA s.21(1): the net value of an intestate estate is taken after deducting the household furnishings passing to the spouse under s.21(2)(a), and charges, debts, funeral and administration expenses and Probate Fee Act fees. Record each of those in Inventory — furnishings as “Personal effects, clothing, furniture &amp; household items”, expenses as liabilities.
              </p>
            )}
          </div>
        ) : (
          <p className="text-xs text-muted-foreground text-center py-4">
            {isIntestacy
              ? "Add intestate successors in the Contacts tab to compute distribution."
              : "Add beneficiaries with share information in the Contacts tab, or edit shares here."}
          </p>
        )}

        {/* An undetermined distribution is NOT a reconciliation error: reporting
            "total $0.00, difference $1,000,000.00" invented a discrepancy out of an
            unrecorded answer and told the user to hunt a bug that does not exist.
            Name the actual cause instead, and never print the fabricated $0.00. */}
        {!distResult?.isReconciled && distResult && distResult.shares.length > 0 && (
          distResult.shares.some((s: any) => s.isUnallocated) ? (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="text-xs">
                The distribution cannot be totalled yet — the amounts above depend on an answer that has not been recorded, or on a legal question the Act leaves unresolved, so they render as blanks on Form P10. The warnings below name the cause.
              </AlertDescription>
            </Alert>
          ) : (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="text-xs">
                Total distribution ({formatMoney(distResult.totalDistributionCents)}) does not equal net estate value ({formatMoney(distResult.netEstateCents)}). Difference: {formatMoney(Math.abs(distResult.totalDistributionCents - distResult.netEstateCents))}.
              </AlertDescription>
            </Alert>
          )
        )}

        {distResult?.warnings && distResult.warnings.length > 0 && (
          <div className="space-y-1">
            {distResult.warnings.map((w, i) => (
              <p key={i} className="text-xs text-amber-700 dark:text-amber-300">⚠️ {w}</p>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ─── READINESS TAB ───────────────────────────────────────────────────
function ReadinessTabContent({ estateId, onNavigateToTab }: { estateId: string; onNavigateToTab: (tab: string) => void }) {
  const readinessQuery = trpc.readiness.check.useQuery({ estateId });
  const { data: report, isLoading } = readinessQuery;

  // Addendum 24.1: the checklist card renders in EVERY readiness-query state —
  // it is the sole writer of requiredDoc rows, and hiding it behind a failed
  // or loading readiness check would make those records unrecordable.
  const checklistCard = <RequiredSourceDocumentsCard estateId={estateId} />;

  if (isLoading) return (
    <div className="space-y-5 pt-4">
      {checklistCard}
      <div className="h-20 bg-muted animate-pulse rounded-lg" />
    </div>
  );
  if (readinessQuery.isError) return (
    <div className="space-y-5 pt-4">
      {checklistCard}
      <Alert variant="destructive" role="alert">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          <p className="font-medium">Readiness could not be loaded</p>
          <p className="mt-1">{readinessQuery.error.message}</p>
          <Button variant="outline" size="sm" className="mt-3" onClick={() => void readinessQuery.refetch()}>Retry readiness check</Button>
        </AlertDescription>
      </Alert>
    </div>
  );
  if (!report) return <div className="space-y-5 pt-4">{checklistCard}</div>;

  const icons: Record<string, React.ReactNode> = { pass: <CheckCircle2 className="h-4 w-4 text-green-600" />, warn: <AlertTriangle className="h-4 w-4 text-amber-500" />, fail: <XCircle className="h-4 w-4 text-red-500" />, info: <Info className="h-4 w-4 text-blue-500" /> };

  const tabDisplayName = (tab: string) => {
    return tab.charAt(0).toUpperCase() + tab.slice(1);
  };

  // Info items don't count toward pass/fail progress
  const actionableItems = report.items.filter(i => i.level !== "info");
  const totalChecks = actionableItems.length;
  const progressPct = totalChecks > 0 ? Math.round((report.passCount / totalChecks) * 100) : 0;

  // Group items by level for better organization
  const blockers = report.items.filter(i => i.level === "fail");
  const warnings = report.items.filter(i => i.level === "warn");
  const advisories = report.items.filter(i => i.level === "info");
  const passed = report.items.filter(i => i.level === "pass");

  // Determine the most impactful next step
  const nextStep = blockers[0] || warnings[0];

  return (
    <div className="space-y-5 pt-4">
      {/* Rule 24: relocated from the removed Documents tab — the checklist
          card is the only writer of the requiredDoc rows the checks below
          (and P2 preflight) read. */}
      {checklistCard}

      {/* Progress summary card */}
      <Card className="border bg-gradient-to-r from-background to-muted/30">
        <CardContent className="py-4 px-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <Badge variant={report.ready ? "default" : "destructive"} className="text-xs">
                {report.ready ? "Ready to File" : "Not Ready"}
              </Badge>
              <span className="text-sm font-medium">{progressPct}% complete</span>
            </div>
            <span className="text-xs text-muted-foreground">
              {report.passCount}/{totalChecks} checks passed{report.infoCount > 0 ? ` · ${report.infoCount} advisor${report.infoCount === 1 ? "y" : "ies"}` : ""}
            </span>
          </div>
          <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${report.ready ? "bg-green-500" : progressPct > 60 ? "bg-amber-500" : "bg-red-500"}`}
              style={{ width: `${progressPct}%` }}
            />
          </div>
          {nextStep && !report.ready && (
            <div className="mt-3 flex items-center gap-2 text-xs">
              <Lightbulb className="h-3.5 w-3.5 text-amber-500 shrink-0" />
              <span className="text-muted-foreground">
                <strong>Next step:</strong> {nextStep.detail}
              </span>
              {nextStep.tab && (
                <Button variant="link" size="sm" className="h-auto p-0 text-xs" onClick={() => onNavigateToTab(nextStep.tab)}>
                  Fix now
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Blockers section */}
      {blockers.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-red-600 dark:text-red-300 uppercase tracking-wide flex items-center gap-1.5">
            <XCircle className="h-3.5 w-3.5" /> Blockers ({blockers.length})
          </h4>
          {blockers.map((item) => (
            <Card key={item.id} className="border border-red-200 bg-red-50/30 dark:bg-red-950/10">
              <CardContent className="flex items-center gap-3 py-3 px-4">
                <div className="mt-0.5 shrink-0">{icons[item.level]}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.detail}</p>
                </div>
                {item.tab && (
                  <Button variant="ghost" size="sm" className="shrink-0 text-xs text-primary hover:text-primary" onClick={() => onNavigateToTab(item.tab)}>
                    Go to {tabDisplayName(item.tab)}
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Warnings section */}
      {warnings.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-amber-700 dark:text-amber-300 uppercase tracking-wide flex items-center gap-1.5">
            <AlertTriangle className="h-3.5 w-3.5" /> Warnings ({warnings.length})
          </h4>
          {warnings.map((item) => (
            <Card key={item.id} className="border border-amber-200 bg-amber-50/30 dark:bg-amber-950/10">
              <CardContent className="flex items-center gap-3 py-3 px-4">
                <div className="mt-0.5 shrink-0">{icons[item.level]}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.detail}</p>
                </div>
                {item.tab && (
                  <Button variant="ghost" size="sm" className="shrink-0 text-xs text-primary hover:text-primary" onClick={() => onNavigateToTab(item.tab)}>
                    Go to {tabDisplayName(item.tab)}
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Advisories section - blue info cards */}
      {advisories.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-blue-700 dark:text-blue-300 uppercase tracking-wide flex items-center gap-1.5">
            <Info className="h-3.5 w-3.5" /> Practice Advisories ({advisories.length})
          </h4>
          {advisories.map((item) => (
            <Card key={item.id} className="border border-blue-200 bg-blue-50/30 dark:bg-blue-950/10">
              <CardContent className="flex items-start gap-3 py-3 px-4">
                <div className="mt-0.5 shrink-0">{icons[item.level]}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-blue-900 dark:text-blue-100">{item.label}</p>
                  <p className="text-xs text-blue-700/80 dark:text-blue-300/70 mt-0.5">{item.detail}</p>
                </div>
                {item.tab && (
                  <Button variant="ghost" size="sm" className="shrink-0 text-xs text-blue-700 dark:text-blue-300 hover:text-blue-800 dark:hover:text-blue-200" onClick={() => onNavigateToTab(item.tab)}>
                    Go to {tabDisplayName(item.tab)}
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Passed section - collapsible */}
      {passed.length > 0 && (
        <details className="group">
          <summary className="text-xs font-semibold text-green-700 dark:text-green-400 uppercase tracking-wide flex items-center gap-1.5 cursor-pointer list-none">
            <CheckCircle2 className="h-3.5 w-3.5" /> Passed ({passed.length})
            <span className="text-muted-foreground font-normal ml-1 group-open:hidden">— click to expand</span>
          </summary>
          <div className="space-y-2 mt-2">
            {passed.map((item) => (
              <Card key={item.id} className="border border-green-100 bg-green-50/20 dark:bg-green-950/10">
                <CardContent className="flex items-center gap-3 py-2.5 px-4">
                  <div className="mt-0.5 shrink-0">{icons[item.level]}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-muted-foreground">{item.label}</p>
                    <p className="text-xs text-muted-foreground/70">{item.detail}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </details>
      )}

      {/* Filing checklist reminder */}
      {report.ready && (
        <Alert className="border-green-200 bg-green-50/50 dark:bg-green-950/10">
          <CheckCircle2 className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-sm">
            <strong>This estate is ready to file.</strong> Generate the grant package from the Forms tab, then file at the registry. Remember to bring: the original will (if applicable), the death certificate, and the filing fee.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}

// ─── NOTES TAB (timestamped feed, per-user privacy, pin/flag, tags, attachments) ──────────
const NOTE_TAGS = [
  { value: "general", label: "General", color: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300" },
  { value: "client_call", label: "Client Call", color: "bg-violet-50 text-violet-600 dark:bg-violet-900/30 dark:text-violet-300" },
  { value: "filing_reminder", label: "Filing Reminder", color: "bg-sky-50 text-sky-600 dark:bg-sky-900/30 dark:text-sky-300" },
  { value: "court_instruction", label: "Court", color: "bg-rose-50 text-rose-600 dark:bg-rose-900/30 dark:text-rose-300" },
  { value: "research", label: "Research", color: "bg-emerald-50 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-300" },
];

export function NotesTab({ estateId, feedbackOwner }: { estateId: string; estate: any; feedbackOwner?: DeliveryFeedbackOwner }) {
  const utils = trpc.useUtils();
  // Task 13: the export's error feedback belongs to the estate page's owner when one is passed (r3), else to this
  // estate's Notes tab.
  const notesFeedback = useEstateFeedbackOwner(feedbackOwner, `notes:${estateId}`);
  const [newNote, setNewNote] = useState("");
  const [selectedTag, setSelectedTag] = useState<string>("general");
  const [filterTag, setFilterTag] = useState<string | undefined>(undefined);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState("");
  const [editTag, setEditTag] = useState<string>("general");
  const [attachment, setAttachment] = useState<{ key: string; url: string; name: string; type: string } | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [attachmentUploadFeedback, setAttachmentUploadFeedback] = useState<UploadFeedbackState>(IDLE_UPLOAD_FEEDBACK);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: notesList = [], isLoading } = trpc.notes.list.useQuery({ estateId, tag: filterTag });

  const createMutation = trpc.notes.create.useMutation({
    onSuccess: () => {
      setNewNote("");
      setAttachment(null);
      setSelectedTag("general");
      utils.notes.list.invalidate({ estateId });
      utils.notes.pinned.invalidate({ estateId });
    },
  });

  const updateMutation = trpc.notes.update.useMutation({
    onSuccess: () => {
      setEditingId(null);
      setEditContent("");
      utils.notes.list.invalidate({ estateId });
      utils.notes.pinned.invalidate({ estateId });
    },
  });

  const deleteMutation = trpc.notes.delete.useMutation({
    onSuccess: () => {
      utils.notes.list.invalidate({ estateId });
      utils.notes.pinned.invalidate({ estateId });
    },
  });

  const togglePinMutation = trpc.notes.togglePin.useMutation({
    onSuccess: () => {
      utils.notes.list.invalidate({ estateId });
      utils.notes.pinned.invalidate({ estateId });
    },
  });

  const uploadMutation = trpc.notes.uploadAttachment.useMutation({
    onSuccess: (data) => {
      setAttachment({ key: data.key, url: data.url, name: data.fileName, type: data.mimeType });
      setUploading(false);
      setAttachmentUploadFeedback({ phase: "complete", progress: 100, message: `${data.fileName} attached` });
      window.setTimeout(() => setAttachmentUploadFeedback(IDLE_UPLOAD_FEEDBACK), 2200);
    },
    onError: (err) => {
      setUploading(false);
      const message = err.message || "Unable to upload the attachment. Please try again.";
      setAttachmentUploadFeedback({ phase: "error", progress: 0, message });
      toast.error(message);
    },
  });

  const [isDragging, setIsDragging] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const dragCounter = useRef(0);

  const NOTE_TEMPLATES = [
    { label: "Client Call", tag: "client_call", body: "Call with [client name]\n\nDiscussed:\n- \n\nAction items:\n- " },
    { label: "Filing Reminder", tag: "filing_reminder", body: "Deadline: [date]\nTask: \nNotes: " },
    { label: "Court Instruction", tag: "court_instruction", body: "Registry: \nInstruction: \nReceived from: \nDate: " },
    { label: "Research Note", tag: "research", body: "Topic: \nSource: \nFindings:\n- " },
  ];

  const processFile = (file: File) => {
    if (file.size > 10 * 1024 * 1024) {
      const message = fileTooLargeMessage("10 MB");
      setAttachmentUploadFeedback({ phase: "error", progress: 0, message });
      toast.error(message);
      return;
    }
    const allowed = new Set([
      "application/pdf", "image/png", "image/jpeg", "image/tiff", "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "text/plain",
    ]);
    if (!allowed.has(file.type.toLowerCase())) {
      const message = invalidFileTypeMessage(file.name, "a PDF, DOC/DOCX, PNG, JPG, TIFF, XLS/XLSX, or TXT file");
      setAttachmentUploadFeedback({ phase: "error", progress: 0, message });
      toast.error(message);
      return;
    }
    setUploading(true);
    setAttachmentUploadFeedback({ phase: "reading", progress: 26, message: `Preparing ${file.name}` });
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(",")[1];
      setAttachmentUploadFeedback({ phase: "uploading", progress: 72, message: `Securely uploading ${file.name}` });
      uploadMutation.mutate({ estateId, fileName: file.name, fileBase64: base64, mimeType: file.type });
    };
    reader.onerror = () => {
      const message = `Unable to read ${file.name}. Please select the file again.`;
      setUploading(false);
      setAttachmentUploadFeedback({ phase: "error", progress: 0, message });
      toast.error(message);
    };
    reader.readAsDataURL(file);
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processFile(file);
    e.target.value = "";
  };

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current++;
    if (e.dataTransfer.types.includes("Files")) setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current--;
    if (dragCounter.current === 0) setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    dragCounter.current = 0;
    const file = e.dataTransfer.files?.[0];
    if (file) processFile(file);
  };

  const applyTemplate = (template: typeof NOTE_TEMPLATES[0]) => {
    setNewNote(template.body);
    setSelectedTag(template.tag);
    setShowTemplates(false);
    textareaRef.current?.focus();
  };

  const handleSubmit = () => {
    if (!newNote.trim() && !attachment) return;
    createMutation.mutate({
      estateId,
      content: newNote.trim() || (attachment ? `Attached: ${attachment.name}` : ""),
      tag: selectedTag || undefined,
      attachmentKey: attachment?.key,
      attachmentUrl: attachment?.url,
      attachmentName: attachment?.name,
      attachmentType: attachment?.type,
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const startEdit = (note: any) => {
    setEditingId(note.id);
    setEditContent(note.content);
    setEditTag(note.tag || "general");
  };

  const saveEdit = () => {
    if (!editingId || !editContent.trim()) return;
    updateMutation.mutate({ id: editingId, content: editContent.trim(), tag: editTag });
  };

  const pinned = notesList.filter((n: any) => n.pinned === 1);
  const unpinned = notesList.filter((n: any) => n.pinned !== 1);

  // B19: single relative-time source — Notes and Activity must age identically.
  const formatNoteTime = (ts: number) => {
    return formatRelativeTime(ts);
  };

  const getTagMeta = (tag: string | null) => NOTE_TAGS.find(t => t.value === tag) || NOTE_TAGS[0];

  const isImage = (type: string | null) => type?.startsWith("image/");
  const isPdf = (type: string | null) => type === "application/pdf";

  const NoteCard = ({ note }: { note: any }) => {
    const tagMeta = getTagMeta(note.tag);
    return (
      <motion.div
        layout
        initial={{ opacity: 0, y: 6 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -4 }}
        transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
        className={`group relative rounded-md border transition-colors duration-150 ${
          note.pinned ? "border-amber-200/80 bg-amber-50/20 dark:bg-amber-950/5 dark:border-amber-800/30" : "border-border/60 hover:border-border"
        }`}
      >
        <div className="px-3.5 py-3">
          {editingId === note.id ? (
            <div className="space-y-2.5">
              <Textarea
                value={editContent}
                onChange={(e) => setEditContent(e.target.value)}
                className="min-h-[72px] text-[13px] leading-relaxed border-0 bg-transparent p-0 shadow-none focus-visible:ring-0 resize-none"
                autoFocus
              />
              <div className="flex items-center gap-2">
                <select
                  value={editTag}
                  onChange={(e) => setEditTag(e.target.value)}
                  className="text-[11px] h-6 px-1.5 rounded border border-border bg-transparent"
                >
                  {NOTE_TAGS.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
                <div className="flex-1" />
                <Button size="sm" variant="ghost" className="h-6 text-xs" onClick={() => setEditingId(null)}>Cancel</Button>
                <Button size="sm" className="h-6 text-xs" onClick={saveEdit} disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? "Saving..." : "Save"}
                </Button>
              </div>
            </div>
          ) : (
            <>
              <p className="text-[13px] whitespace-pre-wrap leading-[1.6] text-foreground/90">{note.content}</p>
              {/* Attachment preview */}
              {note.attachmentUrl && (
                <div className="mt-2.5">
                  {isImage(note.attachmentType) ? (
                    <button
                      onClick={() => setPreviewUrl(note.attachmentUrl)}
                      className="block rounded overflow-hidden border border-border/40 hover:border-border transition-colors max-w-[280px]"
                    >
                      <img src={note.attachmentUrl} alt={note.attachmentName || ""} className="w-full h-auto max-h-[200px] object-cover" />
                    </button>
                  ) : isPdf(note.attachmentType) ? (
                    <button
                      onClick={() => setPreviewUrl(note.attachmentUrl)}
                      className="flex items-center gap-2 px-2.5 py-1.5 rounded border border-border/40 hover:border-border hover:bg-muted/30 transition-colors text-xs text-muted-foreground"
                    >
                      <FileText className="h-3.5 w-3.5 text-red-500" />
                      <span className="truncate max-w-[200px]">{note.attachmentName || "Document.pdf"}</span>
                      <Eye className="h-3 w-3 ml-auto opacity-60" />
                    </button>
                  ) : (
                    <a
                      href={note.attachmentUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-2.5 py-1.5 rounded border border-border/40 hover:border-border hover:bg-muted/30 transition-colors text-xs text-muted-foreground"
                    >
                      <Paperclip className="h-3.5 w-3.5" />
                      <span className="truncate max-w-[200px]">{note.attachmentName || "Attachment"}</span>
                      <Download className="h-3 w-3 ml-auto opacity-60" />
                    </a>
                  )}
                </div>
              )}
              {/* Footer: time + tag + actions */}
              <div className="flex items-center gap-2 mt-2.5 pt-2 border-t border-border/30">
                <span className="text-[11px] text-muted-foreground/70 tabular-nums">{formatNoteTime(note.createdAt)}</span>
                {note.tag && note.tag !== "general" && (
                  <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${tagMeta.color}`}>{tagMeta.label}</span>
                )}
                {note.pinned === 1 && <Pin className="h-2.5 w-2.5 text-amber-500 fill-amber-500" />}
                <div className="flex-1" />
                <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity duration-150">
                  <button onClick={() => togglePinMutation.mutate({ id: note.id })} className="p-1 rounded hover:bg-muted transition-colors" title={note.pinned ? "Unpin" : "Pin"}>
                    {note.pinned ? <PinOff className="h-3 w-3 text-muted-foreground" /> : <Pin className="h-3 w-3 text-muted-foreground" />}
                  </button>
                  <button onClick={() => startEdit(note)} className="p-1 rounded hover:bg-muted transition-colors" title="Edit">
                    <Pencil className="h-3 w-3 text-muted-foreground" />
                  </button>
                  <button onClick={() => { if (confirm("Delete this note?")) deleteMutation.mutate({ id: note.id }); }} className="p-1 rounded hover:bg-red-50 dark:hover:bg-red-950/20 transition-colors" title="Delete">
                    <Trash2 className="h-3 w-3 text-muted-foreground hover:text-red-500" />
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </motion.div>
    );
  };

  return (
    <div className="pt-5 space-y-5">
      {/* Header row */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold tracking-tight">Notes</h3>
          <p className="text-[11px] text-muted-foreground/70 mt-0.5">Private to you • {notesList.length} entr{notesList.length === 1 ? "y" : "ies"}</p>
        </div>
        <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={(event) => { void deliverAttachment({ method: "POST", action: "/api/notes/export-pdf", fields: { estateId } }, event.currentTarget, { owner: notesFeedback, slot: "notes" }); }}>
          <FileDown className="h-3 w-3" /> Export PDF
        </Button>
      </div>

      {/* Compose area with drag-and-drop */}
      <div
        className={`relative rounded-lg border transition-all duration-150 ${
          isDragging
            ? "border-primary/50 bg-primary/[0.02] ring-2 ring-primary/10"
            : "border-border/60 focus-within:border-border focus-within:ring-1 focus-within:ring-ring/20"
        }`}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
      >
        {/* Drag overlay */}
        {isDragging && (
          <div className="absolute inset-0 z-10 flex items-center justify-center rounded-lg bg-primary/[0.03] pointer-events-none">
            <div className="flex flex-col items-center gap-1">
              <Paperclip className="h-5 w-5 text-primary/60" />
              <span className="text-xs text-primary/70 font-medium">Drop file to attach</span>
            </div>
          </div>
        )}
        <Textarea
          ref={textareaRef}
          value={newNote}
          onChange={(e) => setNewNote(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Write a note..."
          className="min-h-[72px] border-0 shadow-none focus-visible:ring-0 resize-none text-[13px] leading-relaxed rounded-b-none"
        />
        {/* Attachment preview in compose */}
        {attachment && (
          <div className="px-3 pb-2">
            <div className="flex items-center gap-2 text-xs text-muted-foreground bg-muted/40 rounded px-2 py-1">
              {isImage(attachment.type) ? <Image className="h-3 w-3" /> : <Paperclip className="h-3 w-3" />}
              <span className="truncate">{attachment.name}</span>
              <button onClick={() => setAttachment(null)} className="ml-auto p-0.5 hover:text-foreground"><X className="h-3 w-3" /></button>
            </div>
          </div>
        )}
        <UploadFeedback state={attachmentUploadFeedback} compact className="mx-3 mb-2" />
        {/* Toolbar */}
        <div className="flex items-center gap-1.5 px-3 py-2 border-t border-border/30">
          <select
            value={selectedTag}
            onChange={(e) => setSelectedTag(e.target.value)}
            className="text-[11px] h-6 px-1.5 rounded border border-border/60 bg-transparent text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
          >
            {NOTE_TAGS.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
          </select>
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="p-1 rounded text-muted-foreground/70 hover:text-foreground hover:bg-muted transition-colors"
            title="Attach file or drag & drop (max 10 MB)"
          >
            {uploading ? <span className="h-3.5 w-3.5 block border-2 border-muted-foreground/30 border-t-muted-foreground rounded-full animate-spin" /> : <Paperclip className="h-3.5 w-3.5" />}
          </button>
          <input ref={fileInputRef} type="file" className="hidden" onChange={handleFileSelect} accept=".png,.jpg,.jpeg,.tif,.tiff,.pdf,.doc,.docx,.xls,.xlsx,.txt" />
          {/* Templates popover */}
          <div className="relative">
            <button
              onClick={() => setShowTemplates(!showTemplates)}
              className="p-1 rounded text-muted-foreground/70 hover:text-foreground hover:bg-muted transition-colors"
              title="Use a template"
            >
              <FileText className="h-3.5 w-3.5" />
            </button>
            {showTemplates && (
              <div className="absolute bottom-full left-0 mb-1 w-48 rounded-md border border-border bg-popover text-popover-foreground shadow-md z-20">
                <div className="p-1">
                  <p className="px-2 py-1 text-[10px] font-medium text-muted-foreground uppercase tracking-wider">Templates</p>
                  {NOTE_TEMPLATES.map(t => (
                    <button
                      key={t.tag}
                      onClick={() => applyTemplate(t)}
                      className="w-full text-left px-2 py-1.5 text-[12px] rounded hover:bg-muted transition-colors"
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
          <div className="flex-1" />
          <span className="text-[10px] text-muted-foreground/50 mr-2 hidden sm:inline">{shortcutLabel("↵")}</span>
          <Button
            size="sm"
            className="h-6 px-2.5 text-xs"
            onClick={handleSubmit}
            disabled={(!newNote.trim() && !attachment) || createMutation.isPending}
          >
            {createMutation.isPending ? "Adding..." : "Add"}
          </Button>
        </div>
      </div>

      {/* Filter chips */}
      <div className="flex items-center gap-1.5 flex-wrap">
        <button
          onClick={() => setFilterTag(undefined)}
          className={`text-[11px] px-2 py-1 rounded-full border transition-colors ${!filterTag ? "bg-foreground text-background border-foreground" : "border-border/60 text-muted-foreground hover:text-foreground hover:border-border"}`}
        >
          All
        </button>
        {NOTE_TAGS.filter(t => t.value !== "general").map(t => (
          <button
            key={t.value}
            onClick={() => setFilterTag(filterTag === t.value ? undefined : t.value)}
            className={`text-[11px] px-2 py-1 rounded-full border transition-colors ${filterTag === t.value ? "bg-foreground text-background border-foreground" : "border-border/60 text-muted-foreground hover:text-foreground hover:border-border"}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Notes feed */}
      {isLoading ? (
        <div className="space-y-2.5">
          {[1, 2, 3].map(i => <div key={i} className="h-[72px] rounded-md bg-muted/30 animate-pulse" style={{ animationDelay: `${i * 100}ms` }} />)}
        </div>
      ) : notesList.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="w-10 h-10 rounded-full bg-muted/50 flex items-center justify-center mb-3">
            <FileText className="h-4 w-4 text-muted-foreground/50" />
          </div>
          <p className="text-sm text-muted-foreground">No notes{filterTag ? " with this tag" : " yet"}</p>
          <p className="text-[11px] text-muted-foreground/60 mt-1 max-w-[240px]">
            {filterTag ? "Try a different filter or add a new note." : "Notes you add here are private and visible only to you."}
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          <AnimatePresence mode="popLayout">
            {pinned.length > 0 && pinned.map((note: any) => <NoteCard key={note.id} note={note} />)}
            {unpinned.map((note: any) => <NoteCard key={note.id} note={note} />)}
          </AnimatePresence>
        </div>
      )}

      {/* Full-screen attachment preview modal */}
      {previewUrl && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setPreviewUrl(null)}>
          <div className="relative max-w-4xl w-full max-h-[90vh] bg-card rounded-lg overflow-hidden shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-4 py-2.5 border-b">
              <span className="text-xs text-muted-foreground">Preview</span>
              <div className="flex items-center gap-2">
                <a href={previewUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-muted-foreground hover:text-foreground transition-colors">Open in new tab</a>
                <button onClick={() => setPreviewUrl(null)} className="p-1 rounded hover:bg-muted"><X className="h-4 w-4" /></button>
              </div>
            </div>
            <div className="overflow-auto max-h-[calc(90vh-48px)]">
              {previewUrl.match(/\.(jpg|jpeg|png|gif|webp|svg)/i) || previewUrl.includes("image") ? (
                <img src={previewUrl} alt="Preview" className="w-full h-auto" />
              ) : (
                <iframe src={previewUrl} className="w-full h-[80vh] border-0" title="Document preview" />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── ACTIVITY TAB ────────────────────────────────────────────────────
function formatRelativeTime(timestamp: number): string {
  const now = Date.now();
  const diff = now - timestamp;
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return fmtDisplayDate(timestamp);
}

function ActivityTab({ estateId }: { estateId: string }) {
  const PAGE_SIZE = 20;
  const [allItems, setAllItems] = useState<any[]>([]);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);

  const { data, isLoading, isFetching } = trpc.activity.list.useQuery(
    { estateId, limit: PAGE_SIZE, offset }
  );

  // Append new page data when it arrives
  useEffect(() => {
    if (data) {
      if (offset === 0) {
        setAllItems(data);
      } else {
        setAllItems((prev) => {
          const existingIds = new Set(prev.map((i) => i.id));
          const newItems = data.filter((i: any) => !existingIds.has(i.id));
          return [...prev, ...newItems];
        });
      }
      setHasMore(data.length === PAGE_SIZE);
    }
  }, [data, offset]);

  if (isLoading && allItems.length === 0) return <div className="h-20 bg-muted animate-pulse rounded-lg mt-4" />;

  return (
    <div className="space-y-2 pt-4">
      {allItems.map((a) => (
        <div key={a.id} className="flex items-start gap-3 py-2 border-b last:border-0">
          {/* P2-5: Actor avatar/initials */}
          <div className="h-7 w-7 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
            <span className="text-[10px] font-medium text-primary">
              {a.actor ? a.actor.split(" ").map((w: string) => w[0]).join("").slice(0, 2).toUpperCase() : "?"}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm">{a.summary}</p>
            <p className="text-xs text-muted-foreground">
              {a.actor ? `${a.actor} · ` : ""}{formatRelativeTime(a.createdAt)}
            </p>
          </div>
        </div>
      ))}
      {/* P3-5: Load more with server-side pagination */}
      {hasMore && (
        <div className="text-center pt-2">
          <Button variant="ghost" size="sm" onClick={() => setOffset((o) => o + PAGE_SIZE)} className="text-xs" disabled={isFetching}>
            {isFetching ? "Loading..." : "Load more"}
          </Button>
        </div>
      )}
      {allItems.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No activity yet.</p>}
    </div>
  );
}
