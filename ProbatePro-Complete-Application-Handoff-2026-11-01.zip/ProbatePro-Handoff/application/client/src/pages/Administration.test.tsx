import { afterEach, describe, expect, it, vi } from "vitest";
import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import React from "react";
import Administration from "./Administration";

const mocks = vi.hoisted(() => ({
  role: "admin", suspendedAt: null as number | null, users: [] as Array<Record<string, unknown>>, reports: [] as Array<Record<string, unknown>>, reportQueryOptions: undefined as Record<string, unknown> | undefined, suspend: vi.fn(), updateStatus: vi.fn(), updatePriority: vi.fn(), bulkResolve: vi.fn(), undoBulkResolve: vi.fn(), toast: vi.fn(), refetch: vi.fn(), invalidate: vi.fn(), navigate: vi.fn(),
}));

vi.mock("@/_core/hooks/useAuth", () => ({ useAuth: () => ({ user: { id: 9, role: mocks.role, suspendedAt: mocks.suspendedAt } }) }));
vi.mock("@/lib/trpc", () => ({ trpc: {
  administration: { listUsers: { useQuery: () => ({ data: mocks.users, isLoading: false, refetch: mocks.refetch }) }, setUserSuspension: { useMutation: () => ({ mutate: mocks.suspend, isPending: false }) } },
  support: { listAllReports: { useQuery: (_input: unknown, options: Record<string, unknown>) => { mocks.reportQueryOptions = options; return { data: mocks.reports, isLoading: false, refetch: mocks.refetch }; } }, updateIssueStatus: { useMutation: (options: any) => ({ mutate: (input: any) => { mocks.updateStatus(input); options?.onSuccess?.({}, input); }, isPending: false }) }, updatePriority: { useMutation: (options: any) => ({ mutate: (input: any) => { mocks.updatePriority(input); options?.onSuccess?.({}, input); }, isPending: false }) }, resolveReports: { useMutation: (options: any) => ({ mutate: (input: unknown) => { mocks.bulkResolve(input); options?.onSuccess?.({ updatedCount: 1, undoRecords: [{ id: "pending", issueStatus: "pending", resolvedAt: 42 }] }); }, isPending: false }) }, undoResolvedReports: { useMutation: (options: any) => ({ mutate: (input: unknown) => { mocks.undoBulkResolve(input); options?.onSuccess?.({ restoredCount: 1 }); }, isPending: false }) }, getReportDetail: { invalidate: mocks.invalidate } },
  useUtils: () => ({ support: { getReportDetail: { invalidate: mocks.invalidate } } }),
} }));
vi.mock("wouter", () => ({ useLocation: () => ["/administration", mocks.navigate] }));
vi.mock("@/components/PageHeader", () => ({ PageHeader: ({ title }: { title: string }) => <h1>{title}</h1> }));
vi.mock("sonner", () => ({ toast: Object.assign(mocks.toast, { success: mocks.toast }) }));

afterEach(() => { cleanup(); vi.useRealTimers(); mocks.role = "admin"; mocks.suspendedAt = null; mocks.users = []; mocks.reports = []; mocks.reportQueryOptions = undefined; mocks.suspend.mockReset(); mocks.updateStatus.mockReset(); mocks.updatePriority.mockReset(); mocks.bulkResolve.mockReset(); mocks.undoBulkResolve.mockReset(); mocks.toast.mockReset(); mocks.navigate.mockReset(); });

describe("Administration", () => {
  it("renders the guarded-operations command header for active administrators", () => {
    render(<Administration />);
    expect(screen.getByText("Guarded operations")).toBeTruthy();
    expect(screen.getByLabelText("Administrator workspace status").textContent).toMatch(/MonitoredPrivate access/);
  });

  it("shows account safety controls and lets an administrator suspend or restore other users", () => {
    mocks.users = [{ id: 9, name: "Nick", email: "nick@kairo.chat", role: "admin", lastSignedIn: 1, suspendedAt: null }, { id: 22, name: "Taylor", email: "taylor@example.com", role: "user", lastSignedIn: 1, suspendedAt: null }];
    render(<Administration />);
    expect(screen.getByText(/access safeguards/i)).toBeTruthy();
    fireEvent.change(screen.getAllByLabelText("Pause reason (optional)")[1], { target: { value: "Account review" } });
    fireEvent.click(screen.getByRole("button", { name: "Pause access" }));
    fireEvent.click(screen.getByRole("button", { name: "Suspend user" }));
    expect(mocks.suspend).toHaveBeenCalledWith({ userId: 22, suspended: true, reason: "Account review" });
    expect((screen.getByRole("button", { name: "Your account" }) as HTMLButtonElement).disabled).toBe(true);
  });

  it("refreshes the active administrator queue at a short interval and on window focus", () => {
    render(<Administration />);
    expect(mocks.reportQueryOptions).toMatchObject({ enabled: true, refetchInterval: 15_000, refetchOnWindowFocus: true });
  });

  it("shows no administration controls to a non-administrator", () => {
    mocks.role = "user";
    render(<Administration />);
    expect(screen.getByText(/administrator access required/i)).toBeTruthy();
  });

  it("does not render the workspace for a suspended administrator account", () => {
    mocks.suspendedAt = Date.now();
    render(<Administration />);
    expect(screen.getByText(/administrator access required/i)).toBeTruthy();
  });

  it("filters the support queue to unresolved work and provides deliberate ordering controls", () => {
    mocks.users = [{ id: 9, name: "Nick", email: "nick@kairo.chat", role: "admin", lastSignedIn: 1, suspendedAt: null }, { id: 22, name: "Taylor", email: "taylor@example.com", role: "user", lastSignedIn: 1, suspendedAt: null }];
    mocks.reports = [
      { id: "report-resolved", userId: 22, reporterEmail: "resolved@example.com", subject: "Resolved document issue", details: "The form issue is complete.", category: "documents", createdAt: Date.UTC(2025, 0, 10), issueStatus: "resolved", priority: "low" },
      { id: "report-pending", userId: 23, reporterEmail: "portal@example.com", subject: "Pending portal issue", details: "The access link does not open.", category: "access", createdAt: Date.UTC(2025, 1, 20), issueStatus: "pending", priority: "high" },
    ];
    render(<Administration />);
    expect(screen.getByLabelText("Administration summary").textContent).toMatch(/Pending reports1Requires reviewResolved issues1Closed with a recordActive users2Authorized access/);
    expect(screen.getByText("Unresolved, then newest")).toBeTruthy();
    fireEvent.change(screen.getByLabelText("From date"), { target: { value: "2025-02-01" } });
    expect(screen.getByText("Pending portal issue")).toBeTruthy();
    expect(screen.queryByText("Resolved document issue")).toBeNull();
    fireEvent.click(screen.getByLabelText("Filter support reports by issue state"));
    fireEvent.click(screen.getByRole("option", { name: "Pending" }));
    expect(screen.getByText("Pending portal issue")).toBeTruthy();
    expect(screen.queryByText("Resolved document issue")).toBeNull();
    fireEvent.click(screen.getByLabelText("Sort support reports"));
    expect(screen.getByRole("option", { name: "Date: newest first" })).toBeTruthy();
    expect(screen.getByRole("option", { name: "Priority: high to low" })).toBeTruthy();
    expect(screen.getByRole("option", { name: "Priority: low to high" })).toBeTruthy();
    fireEvent.change(screen.getByLabelText("Find a report"), { target: { value: "portal@example.com" } });
    expect(screen.getByText("Pending portal issue")).toBeTruthy();
    expect(screen.queryByText("Resolved document issue")).toBeNull();
  });

  it("visualizes recent report activity and paginates a large queue without rendering every row at once", () => {
    mocks.users = [{ id: 9, name: "Nick", email: "nick@kairo.chat", role: "admin", lastSignedIn: 1, suspendedAt: null }];
    mocks.reports = Array.from({ length: 13 }, (_, index) => ({
      id: `report-${index + 1}`,
      userId: 22,
      reporterEmail: `reporter-${index + 1}@example.com`,
      subject: `Report ${index + 1}`,
      details: "A report detail for queue pagination.",
      category: "technical",
      createdAt: Date.now() - index * 86_400_000,
      issueStatus: index === 0 ? "resolved" : "pending", priority: index === 1 ? "high" : "normal",
      statusUpdatedAt: index === 0 ? Date.now() : null,
    }));
    render(<Administration />);
    expect(screen.getByRole("group", { name: /30-day incoming and resolved report activity/i })).toBeTruthy();
    expect(screen.getByText("Report 2")).toBeTruthy();
    expect(screen.getByText("Page 1 of 2")).toBeTruthy();
    vi.useFakeTimers();
    fireEvent.click(screen.getByRole("button", { name: "Next report page" }));
    expect(screen.getByText("Page 2 of 2")).toBeTruthy();
    expect(screen.getByLabelText("Loading report page")).toBeTruthy();
    act(() => { vi.advanceTimersByTime(220); });
    expect(screen.getByText("Report 1")).toBeTruthy();
    expect((screen.getByRole("button", { name: "Next report page" }) as HTMLButtonElement).disabled).toBe(true);
  });

  it("reveals exact daily chart values and only bulk-resolves selected unresolved reports after confirmation", () => {
    mocks.users = [{ id: 9, name: "Nick", email: "nick@kairo.chat", role: "admin", lastSignedIn: 1, suspendedAt: null }];
    mocks.reports = [
      { id: "pending", userId: 22, reporterEmail: "pending@example.com", subject: "Pending issue", details: "Needs a reply", category: "technical", createdAt: Date.now(), issueStatus: "pending", statusUpdatedAt: null },
      { id: "resolved", userId: 23, reporterEmail: "resolved@example.com", subject: "Resolved issue", details: "Already done", category: "technical", createdAt: Date.now(), issueStatus: "resolved", statusUpdatedAt: Date.now() },
    ];
    render(<Administration />);
    fireEvent.pointerEnter(screen.getByRole("button", { name: /incoming, 1 resolved/i }));
    expect(screen.getByRole("tooltip").textContent).toMatch(/Incoming: 2Resolved: 1/);
    fireEvent.click(screen.getByLabelText("Select Pending issue for bulk resolution"));
    expect((screen.getByLabelText("Resolved issue is already resolved") as HTMLButtonElement).disabled).toBe(true);
    fireEvent.click(screen.getByRole("button", { name: "Resolve 1 selected" }));
    fireEvent.click(screen.getByRole("button", { name: "Resolve reports" }));
    expect(mocks.bulkResolve).toHaveBeenCalledWith({ ids: ["pending"] });
    const undoConfig = mocks.toast.mock.calls.find(([, options]) => options?.action?.label === "Undo")?.[1];
    undoConfig.action.onClick();
    expect(mocks.undoBulkResolve).toHaveBeenCalledWith({ records: [{ id: "pending", issueStatus: "pending", resolvedAt: 42 }] });
  });

  it("shows and updates durable report priority controls", () => {
    mocks.users = [{ id: 9, name: "Nick", email: "nick@kairo.chat", role: "admin", lastSignedIn: 1, suspendedAt: null }];
    mocks.reports = [{ id: "priority-report", userId: 22, reporterEmail: "priority@example.com", subject: "Priority issue", details: "Needs attention", category: "technical", createdAt: Date.now(), issueStatus: "pending", priority: "high" }];
    render(<Administration />);
    expect(screen.getByText("Priority · High")).toBeTruthy();
    fireEvent.click(screen.getByLabelText("Priority for Priority issue"));
    fireEvent.click(screen.getByRole("option", { name: "Low priority" }));
    expect(mocks.updatePriority).not.toHaveBeenCalled();
    fireEvent.click(screen.getByRole("button", { name: "Confirm priority update" }));
    expect(mocks.updatePriority).toHaveBeenCalledWith({ id: "priority-report", priority: "low" });
  });

  it("requires confirmation and provides success feedback before applying individual report changes", () => {
    mocks.users = [{ id: 9, name: "Nick", email: "nick@kairo.chat", role: "admin", lastSignedIn: 1, suspendedAt: null }];
    mocks.reports = [{ id: "guarded-report", userId: 22, reporterEmail: "guarded@example.com", subject: "Guarded report", details: "Requires deliberate updates", category: "technical", createdAt: Date.now(), issueStatus: "pending", priority: "normal" }];
    render(<Administration />);

    fireEvent.click(screen.getByLabelText("Issue status for Guarded report"));
    fireEvent.click(screen.getByRole("option", { name: "Resolved" }));
    expect(screen.getByText("Change issue status for Guarded report?")).toBeTruthy();
    expect(mocks.updateStatus).not.toHaveBeenCalled();
    fireEvent.click(screen.getByRole("button", { name: "Cancel" }));
    expect(mocks.updateStatus).not.toHaveBeenCalled();

    fireEvent.click(screen.getByLabelText("Issue status for Guarded report"));
    fireEvent.click(screen.getByRole("option", { name: "Resolved" }));
    fireEvent.click(screen.getByRole("button", { name: "Confirm status update" }));
    expect(mocks.updateStatus).toHaveBeenCalledWith({ id: "guarded-report", issueStatus: "resolved" });
    expect(mocks.toast).toHaveBeenCalledWith("Report marked Resolved");

    fireEvent.click(screen.getByLabelText("Priority for Guarded report"));
    fireEvent.click(screen.getByRole("option", { name: "High priority" }));
    expect(mocks.updatePriority).not.toHaveBeenCalled();
    fireEvent.click(screen.getByRole("button", { name: "Confirm priority update" }));
    expect(mocks.updatePriority).toHaveBeenCalledWith({ id: "guarded-report", priority: "high" });
    expect(mocks.toast).toHaveBeenCalledWith("Report priority set to High");
  });

  it("opens the exact queue report for the administrator response workflow", () => {
    mocks.users = [{ id: 9, name: "Nick", email: "nick@kairo.chat", role: "admin", lastSignedIn: 1, suspendedAt: null }];
    mocks.reports = [{ id: "report-open", userId: 22, reporterEmail: "reporter@example.com", subject: "Open this report", details: "Needs an administrator response", category: "technical", createdAt: Date.now(), issueStatus: "pending", priority: "normal" }];
    render(<Administration />);
    fireEvent.click(screen.getByRole("button", { name: "Open report" }));
    expect(mocks.navigate).toHaveBeenCalledWith("/report-a-problem?reportId=report-open");
  });
  it("uses distinct labelled priority badges and composes priority filtering with issue filtering", () => {
    mocks.users = [{ id: 9, name: "Nick", email: "nick@kairo.chat", role: "admin", lastSignedIn: 1, suspendedAt: null }];
    mocks.reports = [
      { id: "high-pending", userId: 22, reporterEmail: "high@example.com", subject: "Urgent pending report", details: "Needs urgent attention", category: "technical", createdAt: Date.now(), issueStatus: "pending", priority: "high" },
      { id: "high-resolved", userId: 23, reporterEmail: "closed@example.com", subject: "Urgent resolved report", details: "Already addressed", category: "technical", createdAt: Date.now(), issueStatus: "resolved", priority: "high" },
      { id: "normal-pending", userId: 24, reporterEmail: "normal@example.com", subject: "Routine pending report", details: "Normal request", category: "technical", createdAt: Date.now(), issueStatus: "pending", priority: "normal" },
      { id: "low-resolved", userId: 25, reporterEmail: "low@example.com", subject: "Deferred report", details: "Low urgency", category: "technical", createdAt: Date.now(), issueStatus: "resolved", priority: "low" },
    ];
    render(<Administration />);
    expect(screen.getAllByText("Priority · High")[0].className).toContain("bg-destructive");
    expect(screen.getByText("Priority · Normal").className).toContain("text-foreground");
    expect(screen.getByText("Priority · Low").className).toContain("bg-secondary");

    fireEvent.click(screen.getByLabelText("Filter support reports by priority"));
    fireEvent.click(screen.getByRole("option", { name: "High priority" }));
    expect(screen.getByText("Urgent pending report")).toBeTruthy();
    expect(screen.getByText("Urgent resolved report")).toBeTruthy();
    expect(screen.queryByText("Routine pending report")).toBeNull();

    fireEvent.click(screen.getByLabelText("Filter support reports by issue state"));
    fireEvent.click(screen.getByRole("option", { name: "Pending" }));
    expect(screen.getByText("Urgent pending report")).toBeTruthy();
    expect(screen.queryByText("Urgent resolved report")).toBeNull();

    fireEvent.click(screen.getByLabelText("Filter support reports by priority"));
    fireEvent.click(screen.getByRole("option", { name: "Low priority" }));
    expect(screen.getByText(/no reports match this view/i)).toBeTruthy();
    fireEvent.click(screen.getByLabelText("Filter support reports by priority"));
    fireEvent.click(screen.getByRole("option", { name: "All priorities" }));
    expect(screen.getByText("Routine pending report")).toBeTruthy();
  });

  it("combines priority and inclusive date filters, orders the active set, and clears the queue controls", () => {
    mocks.users = [{ id: 9, name: "Nick", email: "nick@kairo.chat", role: "admin", lastSignedIn: 1, suspendedAt: null }];
    mocks.reports = [
      { id: "low", userId: 22, reporterEmail: "low@example.com", subject: "Low February report", details: "Low priority", category: "technical", createdAt: new Date(2025, 1, 10, 12).getTime(), issueStatus: "pending", priority: "low" },
      { id: "normal", userId: 23, reporterEmail: "normal@example.com", subject: "Normal February report", details: "Normal priority", category: "technical", createdAt: new Date(2025, 1, 5, 12).getTime(), issueStatus: "pending", priority: "normal" },
      { id: "high", userId: 24, reporterEmail: "high@example.com", subject: "High February report", details: "High priority", category: "technical", createdAt: new Date(2025, 1, 1, 12).getTime(), issueStatus: "pending", priority: "high" },
    ];
    render(<Administration />);
    fireEvent.change(screen.getByLabelText("From date"), { target: { value: "2025-02-01" } });
    fireEvent.change(screen.getByLabelText("To date"), { target: { value: "2025-02-05" } });
    fireEvent.click(screen.getByLabelText("Filter support reports by priority"));
    fireEvent.click(screen.getByRole("option", { name: "High priority" }));
    expect(screen.getByText("High February report")).toBeTruthy();
    expect(screen.queryByText("Normal February report")).toBeNull();

    fireEvent.click(screen.getByLabelText("Filter support reports by priority"));
    fireEvent.click(screen.getByRole("option", { name: "All priorities" }));
    expect(screen.getByText("Normal February report")).toBeTruthy();
    fireEvent.click(screen.getByLabelText("Sort support reports"));
    fireEvent.click(screen.getByRole("option", { name: "Date: oldest first" }));
    expect(screen.getAllByRole("button", { name: "Open report" })[0]?.closest(".admin-glass-row")?.textContent).toMatch(/High February report/);

    fireEvent.click(screen.getByRole("button", { name: "Clear queue controls" }));
    expect((screen.getByLabelText("From date") as HTMLInputElement).value).toBe("");
    expect((screen.getByLabelText("To date") as HTMLInputElement).value).toBe("");
    expect(screen.getByText("Low February report")).toBeTruthy();
    expect((screen.getByRole("button", { name: "Clear queue controls" }) as HTMLButtonElement).disabled).toBe(true);
  });
});
