import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

// Heavy jsdom file: each test imports EstateDetail (a very large module) inside the
// test body. Same ceiling as the sibling audit specs.
vi.setConfig({ testTimeout: 45000 }); // 2026-08-21: jsdom EstateDetail suites breached 15-20s under full-suite worker contention (flake class, memory probatepro-test-flakiness) — headroom, not speed, keeps the gate reproducible

// tsconfig sets jsx:"preserve", so esbuild under vitest emits the classic
// React.createElement transform; vitest.config.ts has no react() plugin to supply the
// automatic runtime the app gets from vite.config.ts. IntakeTab renders ui/collapsible,
// which annotates React.ComponentProps without importing React — fine in the app, but
// undefined here. ponytail: harness gap, not a product bug — drop this line once
// vitest.config.ts sets esbuild.jsx:"automatic" (out of scope for this change).
(globalThis as any).React = React;

const mocks = vi.hoisted(() => ({
  contacts: [] as any[],
  estateUpdate: vi.fn(),
}));

vi.mock("sonner", () => ({
  toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }),
}));

vi.mock("@/lib/trpc", () => {
  const idleMutation = () => ({ mutate: vi.fn(), mutateAsync: vi.fn(async () => ({})), isPending: false });
  const invalidator = () => ({ invalidate: vi.fn() });
  return {
    trpc: {
      inventory: {
        list: { useQuery: () => ({ data: [], isLoading: false }) },
        totals: { useQuery: () => ({ data: undefined }) },
        create: { useMutation: idleMutation },
        update: { useMutation: idleMutation },
        delete: { useMutation: idleMutation },
        reorder: { useMutation: idleMutation },
        bulkCreate: { useMutation: idleMutation },
      },
      contact: { list: { useQuery: () => ({ data: mocks.contacts }) } },
      settings: { get: { useQuery: () => ({ data: { formFocusedIntake: false } }) } },
      notes: { pinned: { useQuery: () => ({ data: [] }) } },
      estate: {
        update: { useMutation: () => ({ mutate: mocks.estateUpdate, isPending: false, isSuccess: false }) },
        uploadWill: { useMutation: idleMutation },
        deleteWill: { useMutation: idleMutation },
        uploadCodicil: { useMutation: idleMutation },
        deleteCodicil: { useMutation: idleMutation },
        reorderCodicils: { useMutation: idleMutation },
        updateCodicilDate: { useMutation: idleMutation },
        uploadForeignGrant: { useMutation: idleMutation },
        deleteForeignGrant: { useMutation: idleMutation },
        uploadLegalEvidence: { useMutation: idleMutation },
        clearLegalEvidence: { useMutation: idleMutation },
      },
      useUtils: () => ({
        inventory: { list: invalidator(), totals: invalidator() },
        distribution: { compute: invalidator() },
        readiness: { check: invalidator(), timeline: invalidator() },
        deadline: { list: invalidator() },
        delivery: { getRecipients: invalidator() },
        estate: { get: invalidator(), list: invalidator() },
        document: { preflight: invalidator(), preflightMany: invalidator() },
      }),
    },
  };
});

const ESTATE_BASE = { id: "estate-1", p10FiledDate: "", p11FiledDate: "" };

const COURT_LABEL = "Name of the court that issued the foreign grant (printed in P26 paragraph 1)";
const DATE_LABEL = "Date the foreign grant was issued (printed in P26 paragraph 1)";

async function components() {
  const estateDetail = await import("./EstateDetail");
  const { TooltipProvider } = await import("@/components/ui/tooltip");
  return { ...estateDetail, TooltipProvider };
}

beforeEach(() => {
  mocks.contacts = [];
  mocks.estateUpdate.mockReset();
  // Radix pointer interactions need these in jsdom.
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
  window.localStorage.clear();
});

// Rule 25-6(7) / Form P26 paragraph 1: "a grant issued by the ...[name of
// issuing court]... on ...[dd/mmm/yyyy]...". The section opened for resealing
// estates but the only foreignGrantIssuingCourt/foreignGrantIssuedDate inputs
// sat behind the includes("ancillary") guard, so the sworn slots printed
// permanently blank and p26_foreign_grant_* stayed unsatisfiable (ARC-P26 #1).
describe("Rule 25-6(7) resealing — P26 paragraph-1 foreign-grant inputs", () => {
  it("renders both inputs on a resealing estate and persists them via estate.update (markDirty class)", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const { unmount } = render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE, grantType: "resealing" }} />
      </TooltipProvider>,
    );

    fireEvent.change(screen.getByLabelText(COURT_LABEL), { target: { value: "Superior Court of Justice for Ontario" } });
    fireEvent.change(screen.getByLabelText(DATE_LABEL), { target: { value: "2024-03-05" } });
    // Intake persists on unmount (tab switch).
    unmount();

    expect(mocks.estateUpdate).toHaveBeenCalledWith(expect.objectContaining({
      id: "estate-1",
      data: expect.objectContaining({
        foreignGrantIssuingCourt: "Superior Court of Justice for Ontario",
        foreignGrantIssuedDate: "2024-03-05",
      }),
    }));
  });

  it("keeps the ancillary-only Rule 25-3(3) block hidden and the case-file trio intact on a resealing estate", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE, grantType: "resealing" }} />
      </TooltipProvider>,
    );

    expect(screen.getByLabelText(COURT_LABEL)).toBeTruthy();
    expect(screen.getByLabelText(DATE_LABEL)).toBeTruthy();
    // The ancillary P6/P7 block must not leak into a resealing estate.
    expect(screen.queryByText(/Required for P6\/P7 affidavit generation/)).toBeNull();
    expect(screen.queryByLabelText("Issuing court (for P6/P7 affidavit)")).toBeNull();
    // 2026-08-05 intake de-dup + review F5: the whole case-file trio is gone.
    // The date is asked ONCE (foreignGrantIssuedDate); estate.update keeps the
    // legacy ancillaryDate twin in lockstep server-side for P19's clause.
    expect(screen.queryByLabelText("Name of the court that issued the foreign estate grant")).toBeNull();
    expect(screen.queryByLabelText("Province or country that issued the foreign estate grant")).toBeNull();
    expect(screen.queryByLabelText("Date the foreign estate grant was issued")).toBeNull();
  });

  it("keeps the ancillary layout on an ancillary estate and does not add the P26-labelled duplicates", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE, grantType: "ancillary_probate" }} />
      </TooltipProvider>,
    );

    expect(screen.getByLabelText("Issuing court (for P6/P7 affidavit)")).toBeTruthy();
    expect(screen.getByLabelText("Date the foreign grant was issued")).toBeTruthy();
    expect(screen.queryByLabelText(COURT_LABEL)).toBeNull();
    expect(screen.queryByLabelText(DATE_LABEL)).toBeNull();
  });

  it("renders no foreign-grant section at all on a domestic estate grant", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE_BASE, grantType: "grant_of_probate" }} />
      </TooltipProvider>,
    );

    expect(screen.queryByLabelText(COURT_LABEL)).toBeNull();
    expect(screen.queryByLabelText(DATE_LABEL)).toBeNull();
    expect(screen.queryByLabelText("Issuing court (for P6/P7 affidavit)")).toBeNull();
  });
});
