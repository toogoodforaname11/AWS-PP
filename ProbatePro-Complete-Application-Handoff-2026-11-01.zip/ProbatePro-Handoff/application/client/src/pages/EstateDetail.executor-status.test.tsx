import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ContactFormFields } from "./EstateDetail";

vi.mock("@/lib/trpc", () => ({
  trpc: {
    useUtils: () => ({
      maps: {
        autocomplete: { fetch: vi.fn(async () => ({ suggestions: [] })) },
        placeDetails: { fetch: vi.fn(async () => ({ details: null })) },
      },
    }),
  },
}));

describe("executor status contact control", () => {
  it("shows an honest blank placeholder and offers the reserved-right status", async () => {
    Object.defineProperties(HTMLElement.prototype, {
      hasPointerCapture: { configurable: true, value: () => false },
      setPointerCapture: { configurable: true, value: () => undefined },
      releasePointerCapture: { configurable: true, value: () => undefined },
      scrollIntoView: { configurable: true, value: () => undefined },
    });
    const setContact = vi.fn();
    const contact = { id: "executor-1", name: "Executor", role: "executor", executorStatus: "" };

    render(
      <TooltipProvider>
        <ContactFormFields contact={contact} setContact={setContact} allContacts={[]} />
      </TooltipProvider>,
    );

    const trigger = screen.getByTestId("executor-status-select");
    expect(screen.getByText("Select status...")).toBeTruthy();

    fireEvent.keyDown(trigger, { key: "Enter", code: "Enter" });
    const reserved = await screen.findByText("Right reserved — not joining this application");
    fireEvent.click(reserved);

    expect(setContact).toHaveBeenCalledWith(expect.objectContaining({ executorStatus: "reserved" }));
  });
});
