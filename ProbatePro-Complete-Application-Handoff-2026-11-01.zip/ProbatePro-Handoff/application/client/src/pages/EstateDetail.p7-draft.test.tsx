/** P7 optional draft: actual applicability, gap engine, dialogs and download helper. */
import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.setConfig({ testTimeout: 45000 });
(globalThis as any).React = React;

vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }) }));
import { toast } from "sonner";

const mocks = vi.hoisted(() => ({
  generateCalls: [] as any[],
  preflightCalls: [] as any[],
  estateUpdateCalls: [] as any[],
  contactUpdateCalls: [] as any[],
  estate: {} as any,
  generationFailure: "" as string,
  /** document.generate's POST delivery (Nick, 2026-10-20), never a GET URL. */
  delivery: {
    method: "POST",
    action: "/api/download/form",
    fields: { estateId: "estate-19", formCode: "P7", documentId: "doc_p7_1", signatoryType: "lawyer", signatureDate: "2026-07-12", generateAnyway: "true" },
  },
}));

vi.mock("@/lib/trpc", () => {
  const mutation = (path: string, options?: any) => {
    const mutateAsync = async (input: any) => {
      if (path === "contact.update") {
        mocks.contactUpdateCalls.push(input);
        Object.assign(applicant, input.data);
      }
      if (path === "estate.update") {
        mocks.estateUpdateCalls.push(input);
        mocks.estate = { ...mocks.estate, ...input.data, revision: mocks.estate.revision + 1 };
      }
      try {
        if (path === "document.generate") {
          mocks.generateCalls.push(input);
          if (!input.generateAnyway) throw new Error("Confirm optional P7 generation first.");
          if (mocks.generationFailure === input.formCode) throw new Error("A controlled generation failure occurred.");
        }
        const result = path === "document.generate"
          ? { id: "doc_p7_1", delivery: mocks.delivery, filename: "P7_Helen_Calder-Quay.docx", format: "docx" }
          : mocks.estate;
        await options?.onSuccess?.(result, input, undefined);
        return result;
      } catch (error) {
        await options?.onError?.(error, input, undefined);
        throw error;
      }
    };
    return { mutateAsync, mutate: (input: any) => { void mutateAsync(input).catch(() => undefined); }, isPending: false };
  };
  function utils(path: string[]): any {
    return new Proxy({}, {
      get(_target, property: string) {
        if (["invalidate", "setData", "cancel"].includes(property)) return () => undefined;
        if (property === "getData") return () => mocks.estate;
        if (property === "fetch") return async (input: any) => {
          if (path.join(".") === "document.preflight") {
            mocks.preflightCalls.push(input);
            const { checkFormRequirements } = await import("@shared/formRequirements");
            const { applyEstateOverrides } = await import("@shared/formOverrides");
            const { formStatus } = await import("@shared/types");
            const estate = applyEstateOverrides(mocks.estate, input.overrides);
            const status = formStatus("P7", estate, [applicant] as any);
            const report = checkFormRequirements("P7", {
              estate, contacts: [applicant], inventory: [], liabilities: [], deliveries: [], documents: [],
              requiredDocuments: [{ docKey: "wills_notice_result", received: 1 }],
            } as any);
            if (status.applicability === "na") report.gaps.unshift({
              requirementId: "p7_applicability", label: status.reason,
              missingFields: [], tab: "forms", source: "Form P7",
              ...(input.generateAnyway ? {} : { blocker: "hard" as const }),
            });
            return {
              ...report, ok: report.gaps.length === 0,
              notApplicable: status.applicability === "na",
              hardBlocked: report.gaps.some((gap) => gap.blocker === "hard"),
            };
          }
          if (path.join(".") === "document.preflightMany") return [];
          if (path.join(".") === "estate.get") return mocks.estate;
          return undefined;
        };
        return utils([...path, property]);
      },
    });
  }
  function node(path: string[]): any {
    return new Proxy({}, {
      get(_target, property: string) {
        if (property === "useQuery") return () => {
          const key = path.join(".");
          const lists = ["document.list", "document.versions", "document.retainedFiles", "document.getLetterRecipients", "citation.list", "delivery.list", "delivery.getRecipients"];
          return { data: key === "contact.list" ? [applicant] : lists.includes(key) ? [] : undefined, isLoading: false, error: null };
        };
        if (property === "useMutation") return (options: any) => mutation(path.join("."), options);
        if (property === "useUtils") return () => utils([]);
        return node([...path, property]);
      },
    });
  }
  return { trpc: node([]) };
});

const applicant = {
  id: "applicant-1", role: "applicant,executor", executorStatus: "applying", executorRank: "primary",
  name: "Alex Applicant", relationship: "child", occupation: "Teacher",
  applicantKind: "individual", residenceStreet: "10 Main Street", residentialAddress: "10 Main Street",
  residenceCity: "Victoria", residenceProvince: "BC", residenceCountry: "Canada", residencePostalCode: "V8V 1A1",
};
const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
/** Each same-tab form POST the page submits; the browser's attachment download follows it. */
const downloads: Array<{ method: string; action: string | null; fields: Record<string, string> }> = [];
const posted = (fields: Record<string, string>) => ({ method: "post", action: "/api/download/form", fields: { ...fields, attemptId: expect.stringMatching(UUID_V4) } });

beforeEach(() => {
  vi.clearAllMocks();
  mocks.generateCalls.length = 0;
  mocks.preflightCalls.length = 0;
  mocks.estateUpdateCalls.length = 0;
  mocks.contactUpdateCalls.length = 0;
  applicant.residencePostalCode = "V8V 1A1";
  applicant.residenceCity = "Victoria";
  mocks.generationFailure = "";
  mocks.estate = {
    id: "estate-19", revision: 1, grantType: "grant_of_probate", willStatus: "will", hasWill: 1,
    deceasedFirstName: "Helen Rose", deceasedLastName: "Calder-Quay", registry: "Victoria",
    applicantType: "executor", deceasedDomiciledInBC: "yes", deceasedOrdinarilyResidentInBC: "yes",
    testamentaryDocStatus: "none_found", notifyPGT: "no", p1NotRequired: 1,
    vsaCertificateResult: "no_notice", oathType: "affirmed", juratCity: "Victoria",
    foreignGrantGranteeNames: "", foreignGrantIssuingCourt: "", foreignGrantIssuingJurisdiction: "", foreignGrantIssuedDate: "",
  };
  downloads.length = 0;
  vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) {
    downloads.push({ method: this.method, action: this.getAttribute("action"), fields: Object.fromEntries(new FormData(this)) as Record<string, string> });
  });
});
afterEach(() => vi.restoreAllMocks());

async function openP7() {
  const { FormsTab } = await import("./EstateDetail");
  render(<FormsTab estateId="estate-19" estate={mocks.estate} onNavigateToTab={vi.fn()} />);
  expect(screen.getByTestId("form-badge-P7").textContent).toBe("Optional");
  fireEvent.click(screen.getByTestId("form-generate-P7"));
  expect(screen.getByTestId("fix-still-na").textContent).toMatch(/ancillary/i);
  expect(screen.getByTestId("fix-question-grantType").textContent).toBe("Grant of Probate");
  expect((screen.getByTestId("fix-confirm") as HTMLButtonElement).disabled).toBe(false);
  fireEvent.click(screen.getByTestId("fix-confirm"));
  await waitFor(() => expect(screen.getByTestId("form-details-dialog")).toBeTruthy());
  expect(screen.getByTestId("form-details-date")).toBeTruthy();
  fireEvent.click(screen.getByTestId("form-details-generate"));
  await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());
  expect(mocks.generateCalls).toHaveLength(0);
  const proceed = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
  expect(proceed.disabled).toBe(false);
  expect(proceed.textContent).toMatch(/Generate anyway/i);
  return proceed;
}

describe("P7 draft on a domestic probate estate", () => {
  it("acknowledges the mismatch and downloads without changing grant type or inventing foreign facts", async () => {
    const proceed = await openP7();
    expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/ancillary/i);
    expect(screen.queryByTestId("pre-generate-editor-foreignGrantGranteeNames")).toBeNull();
    expect(screen.getByTestId("pre-generate-editor-foreignGrantIssuingCourt")).toBeTruthy();
    expect(screen.getByTestId("pre-generate-p7-foreign-grant-date-input")).toBeTruthy();
    fireEvent.click(proceed);
    await waitFor(() => expect(downloads).toEqual([posted(mocks.delivery.fields)]));
    expect(screen.getByTestId("document-generation-recovery").textContent).toMatch(/P7 is ready/i);
    expect(screen.getByTestId("document-generation-download-retry").textContent).toMatch(/Download P7/i);
    expect(mocks.preflightCalls[0]).toMatchObject({ formCode: "P7", generateAnyway: true });
    expect(mocks.generateCalls).toHaveLength(1);
    expect(mocks.generateCalls[0]).toMatchObject({ formCode: "P7", generateAnyway: true });
    expect(mocks.generateCalls[0].overrides).toBeUndefined();
    expect(mocks.estateUpdateCalls).toEqual([]);
    expect(mocks.estate).toMatchObject({ grantType: "grant_of_probate", hasWill: 1, foreignGrantGranteeNames: "" });
    expect(toast.info).toHaveBeenCalledWith("Form generated — download requested. Check your browser's downloads.");
    expect(toast.error).not.toHaveBeenCalled();

    // The durable retry re-posts the same delivery once per click window, with a fresh attemptId.
    const retry = screen.getByTestId("document-generation-download-retry") as HTMLButtonElement;
    fireEvent.click(retry);
    fireEvent.click(retry);
    expect(downloads).toEqual([posted(mocks.delivery.fields), posted(mocks.delivery.fields)]);
    expect(downloads[1].fields.attemptId).not.toBe(downloads[0].fields.attemptId);
    expect(retry.disabled).toBe(true);
    expect(mocks.generateCalls).toHaveLength(1);
  });

  it("collects only P7-rendered foreign-grant fields and retains the draft choice through recheck and download", async () => {
    const proceed = await openP7();
    const fields = {
      foreignGrantIssuingCourt: "High Court",
      foreignGrantIssuingJurisdiction: "England and Wales",
    };
    for (const [column, value] of Object.entries(fields)) {
      const input = screen.getByTestId(`pre-generate-editor-${column}`).querySelector("input, textarea")!;
      fireEvent.change(input, { target: { value } });
    }
    fireEvent.change(screen.getByTestId("pre-generate-p7-foreign-grant-date-input"), { target: { value: "2025-08-10" } });
    fireEvent.click(proceed);
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(mocks.preflightCalls).toHaveLength(2);
    expect(mocks.preflightCalls[1]).toMatchObject({ formCode: "P7", generateAnyway: true, overrides: fields });
    expect(mocks.generateCalls).toHaveLength(1);
    expect(mocks.generateCalls[0]).toMatchObject({ formCode: "P7", generateAnyway: true, overrides: fields });
    expect(mocks.estate).toMatchObject({ ...fields, foreignGrantIssuedDate: "2025-08-10", grantType: "grant_of_probate", hasWill: 1 });
    expect(mocks.estateUpdateCalls.every((call) => !Object.hasOwn(call.data, "grantType"))).toBe(true);
    expect(toast.error).not.toHaveBeenCalled();
  });

  it("keeps a failed P7 generation visibly actionable instead of leaving only a preparation state", async () => {
    mocks.generationFailure = "P7";
    const proceed = await openP7();
    fireEvent.click(proceed);
    await waitFor(() => expect(screen.getByTestId("document-generation-recovery").textContent).toMatch(/P7 was not generated/i));
    expect(screen.getByTestId("document-generation-review-retry")).toBeTruthy();
    expect(downloads).toEqual([]);
    expect(toast.error).toHaveBeenCalledWith("A controlled generation failure occurred.", { duration: Infinity });
  });
});


describe("P7 popup postal-code persistence regression", () => {
  it("persists the entered residence postal code before the recheck and generation", async () => {
    applicant.residencePostalCode = "";
    applicant.residenceCity = ""; // makes the actual residence requirement incomplete
    const proceed = await openP7();
    const input = screen.getByTestId("pre-generate-p7-residence-postal-applicant-1") as HTMLInputElement;
    expect(input.value).toBe("");
    fireEvent.change(input, { target: { value: "V8V 2B2" } });
    fireEvent.change(screen.getByTestId("pre-generate-p7-residence-city-applicant-1"), { target: { value: "Victoria" } });
    fireEvent.click(proceed);
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(mocks.contactUpdateCalls).toEqual([{ id: applicant.id, estateId: "estate-19", data: { residenceCity: "Victoria", residencePostalCode: "V8V 2B2" } }]);
    expect(applicant.residencePostalCode).toBe("V8V 2B2");
    expect(mocks.preflightCalls).toHaveLength(2);
    expect(mocks.generateCalls).toHaveLength(1);
    expect(mocks.generateCalls[0]).toMatchObject({ formCode: "P7", generateAnyway: true, selectedContactId: applicant.id });
  });
});
