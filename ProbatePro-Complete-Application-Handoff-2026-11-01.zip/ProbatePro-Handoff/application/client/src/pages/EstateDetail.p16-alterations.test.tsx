import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

// Heavy jsdom file: each test imports EstateDetail (a very large module) inside the
// test body. Same ceiling as the sibling audit specs.
vi.setConfig({ testTimeout: 45000 }); // 2026-08-21: jsdom EstateDetail suites breached 15-20s under full-suite worker contention (flake class, memory probatepro-test-flakiness) — headroom, not speed, keeps the gate reproducible

// tsconfig sets jsx:"preserve", so esbuild under vitest emits the classic
// React.createElement transform; vitest.config.ts has no react() plugin to supply the
// automatic runtime the app gets from vite.config.ts. IntakeTab renders ui/collapsible,
// which annotates React.ComponentProps without importing React — fine in the app, but
// undefined here. ponytail: harness gap, not a product bug — drop this line once
// vitest.config.ts sets esbuild.jsx:"automatic" (out of scope for this change).
(globalThis as any).React = React;

const mocks = vi.hoisted(() => ({
  estateUpdate: vi.fn(),
}));

vi.mock("sonner", () => ({
  toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }),
}));

vi.mock("@/lib/trpc", () => {
  const idleMutation = () => ({ mutate: vi.fn(), mutateAsync: vi.fn(async () => ({})), isPending: false });
  const invalidator = () => ({ invalidate: vi.fn() });
  return {
    trpc: {
      inventory: {
        list: { useQuery: () => ({ data: [], isLoading: false }) },
        totals: { useQuery: () => ({ data: undefined }) },
        create: { useMutation: idleMutation },
        update: { useMutation: idleMutation },
        delete: { useMutation: idleMutation },
        reorder: { useMutation: idleMutation },
        bulkCreate: { useMutation: idleMutation },
      },
      contact: { list: { useQuery: () => ({ data: [] }) } },
      settings: { get: { useQuery: () => ({ data: { formFocusedIntake: false } }) } },
      notes: { pinned: { useQuery: () => ({ data: [] }) } },
      estate: {
        update: { useMutation: () => ({ mutate: mocks.estateUpdate, isPending: false, isSuccess: false }) },
        uploadWill: { useMutation: idleMutation },
        deleteWill: { useMutation: idleMutation },
        uploadCodicil: { useMutation: idleMutation },
        deleteCodicil: { useMutation: idleMutation },
        reorderCodicils: { useMutation: idleMutation },
        updateCodicilDate: { useMutation: idleMutation },
        uploadForeignGrant: { useMutation: idleMutation },
        deleteForeignGrant: { useMutation: idleMutation },
        uploadLegalEvidence: { useMutation: idleMutation },
        clearLegalEvidence: { useMutation: idleMutation },
      },
      useUtils: () => ({
        inventory: { list: invalidator(), totals: invalidator() },
        distribution: { compute: invalidator() },
        readiness: { check: invalidator(), timeline: invalidator() },
        deadline: { list: invalidator() },
        delivery: { getRecipients: invalidator() },
        estate: { get: invalidator(), list: invalidator() },
        document: { preflight: invalidator(), preflightMany: invalidator() },
      }),
    },
  };
});

// A will-based estate with the alterations flag set so the P16 intake block renders.
const ESTATE = { id: "estate-1", hasWill: 1, willAlterations: "has_alterations" };

async function components() {
  const estateDetail = await import("./EstateDetail");
  const { TooltipProvider } = await import("@/components/ui/tooltip");
  return { ...estateDetail, TooltipProvider };
}

beforeEach(() => {
  mocks.estateUpdate.mockReset();
  Object.defineProperty(Element.prototype, "hasPointerCapture", { value: () => false, configurable: true });
  Object.defineProperty(Element.prototype, "setPointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "releasePointerCapture", { value: () => {}, configurable: true });
  Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
  window.localStorage.clear();
});

describe("P16 alterations intake block (Rule 25-3(20))", () => {
  // willAlterationsWhen / willAlterationsBy print on NO form and gate NO
  // requirement row — the inputs were orphans that persisted dead data.
  it("no longer renders the orphaned when/by-whom inputs", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE }} />
      </TooltipProvider>,
    );
    expect(screen.queryByText("When were alterations made?")).toBeNull();
    expect(screen.queryByText("By whom?")).toBeNull();
  });

  // P16 ¶1 composes its location "by reference to page number and line number
  // or by other exact reference" — since Nick's 2026-09-01 directive the slot
  // is collected structured (page/line/type/quoted words) with the free-text
  // exact reference as fallback; every control must promise the ¶1 slot, never
  // a prose description.
  it("labels the detail field as the P16 ¶1 location slot, not a prose description", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE }} />
      </TooltipProvider>,
    );
    expect(screen.getByText("Page")).toBeTruthy();
    expect(screen.getByText("Line")).toBeTruthy();
    expect(screen.getByText("Type of alteration")).toBeTruthy();
    expect(screen.getByText("Exact words added or affected (quoted on P16 ¶1)")).toBeTruthy();
    expect(screen.getByText("Other exact reference (used when page/line above are blank; for P16 ¶1)")).toBeTruthy();
    expect(screen.queryByText("Detailed description of alteration(s) (for P16 affidavit)")).toBeNull();
  });

  it("shows the P16 detail/route/presence controls for a supported legacy positive", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE, willAlterations: "interlineation" }} />
      </TooltipProvider>,
    );
    expect(screen.getByPlaceholderText("e.g. 1")).toBeTruthy();
    expect(screen.getByTestId("will-alteration-route")).toBeTruthy();
    expect(screen.getByText(/Was the person who will swear P16 present/)).toBeTruthy();
    const positiveRadio = document.querySelector('input[name="willAlterations"][value="has_alterations"]') as HTMLInputElement;
    expect(positiveRadio.checked).toBe(true);
  });

  // markDirty class: the remaining field must still persist end-to-end.
  it("persists an edited alteration location to estate.update on unmount", async () => {
    const { IntakeTab, TooltipProvider } = await components();
    const { unmount } = render(
      <TooltipProvider>
        <IntakeTab estateId="estate-1" estate={{ ...ESTATE }} />
      </TooltipProvider>,
    );

    fireEvent.change(screen.getByPlaceholderText("e.g. 1"), {
      target: { value: "3" },
    });
    fireEvent.change(screen.getByPlaceholderText("e.g., the margin beside clause 4"), {
      target: { value: "the margin beside clause 4" },
    });
    // Intake persists on unmount (tab switch).
    unmount();

    expect(mocks.estateUpdate).toHaveBeenCalledWith(expect.objectContaining({
      id: "estate-1",
      data: expect.objectContaining({
        p16AlterationPage: "3",
        willAlterationsDetail: "the margin beside clause 4",
      }),
    }));
  });
});
