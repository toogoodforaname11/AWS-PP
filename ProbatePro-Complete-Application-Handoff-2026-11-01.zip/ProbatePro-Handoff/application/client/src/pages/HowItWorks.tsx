import React, { useEffect } from "react";
import { motion } from "framer-motion";
import { Bot, ClipboardCheck, FileCheck2, FileText, FolderLock, HelpCircle, ListChecks, ShieldCheck, UsersRound } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Seo } from "@/components/Seo";

const workflow = [
  {
    number: "01",
    icon: ClipboardCheck,
    title: "Create and complete the file",
    text: "Start an estate file, then record the deceased, the proposed grant, will information, contacts, inventory, notices, and documents. The readiness view shows the recorded facts that still need attention.",
  },
  {
    number: "02",
    icon: UsersRound,
    title: "Collect client information safely",
    text: "Use a secure Estate Portal access token when you need client input. The client can submit a self-contained intake form, while the lawyer reviews each submitted fact before applying selected details to the estate record.",
  },
  {
    number: "03",
    icon: FileCheck2,
    title: "Review readiness before generation",
    text: "The form preflight checks the recorded estate facts and calls out missing information. Where an answer is not recorded, the workflow asks for it rather than silently filling in a legal conclusion.",
  },
  {
    number: "04",
    icon: FileText,
    title: "Generate and review the court documents",
    text: "Generate the supported form package from the reviewed estate record, inspect the preview, then download or print the resulting documents. The lawyer remains responsible for reviewing the final filing materials.",
  },
];

const faqs = [
  {
    question: "What does the Assistant do?",
    answer: "The Assistant can help you navigate the file, explain recorded workflow status, summarize information already available in the workspace, and assist with authorized, grounded tasks. It is a drafting and workflow aid—not a substitute for legal judgment or advice.",
  },
  {
    question: "When does the Assistant process information?",
    answer: "Assistant processing stays off until an authorized user enables it from the sidebar control. When enabled, the Assistant uses the approved processor for its authorized work. You can turn that control off again whenever you do not want to use Assistant processing.",
  },
  {
    question: "How does the client portal work?",
    answer: "A lawyer provides an estate-specific access token. The client uses that token to view permitted information and complete the intake form. Submitted facts do not change the estate automatically: the lawyer selects and approves the individual facts to apply in the estate Intake tab.",
  },
  {
    question: "Where do I manage Executor Portal access?",
    answer: "Use the Executor Portal tab in the sidebar, immediately above How It Works. From there, staff can grant estate-scoped access, copy or email a newly issued one-time link, extend an eligible link, and revoke access. Each link is limited to its selected estate; it does not give a client access to other files.",
  },
  {
    question: "How do Executor Portal search and status filters work?",
    answer: "The Executor Portal search can match an executor or client name, email, estate name, or estate ID. The adjacent status filter can show active, redeemed, expired, or revoked links. These filters only change the staff list view; they do not issue, renew, revoke, or otherwise change portal access.",
  },
  {
    question: "What can I configure in Settings?",
    answer: "Settings is for firm and application preferences, including firm contact details, letter content and closing, image or DOCX letterhead templates, and form checkbox presentation. Assistant processing is controlled from the sidebar control. Review saved settings and generated documents before relying on them for a particular estate.",
  },
  {
    question: "How are court forms chosen and generated?",
    answer: "ProbatePro uses the estate facts you have recorded to show the supported forms that may apply and to identify missing information before generation. A generated document is a working filing document that must be reviewed for the particular estate before it is filed.",
  },
  {
    question: "Why is a form blocked or asking me for more information?",
    answer: "A readiness or preflight message means a required recorded fact, contact, delivery detail, document, or confirmation is missing or inconsistent. Resolve the indicated item in the estate record, then run the preflight again.",
  },
  {
    question: "Are uploads and estate files separated?",
    answer: "Estate records, documents, notes, and generated files are checked against the current estate and authorized user before they are shown or changed. File uploads pass through the platform’s document validation and protected storage flow.",
  },
  {
    question: "What happens if two people edit the same estate?",
    answer: "Important updates use a current-record revision check. If the file changes while you are reviewing a client submission or saving a change, the workflow asks you to refresh and review the latest estate information instead of silently overwriting it.",
  },
];

const guideSections = [
  { id: "workflow", label: "Workflow" },
  { id: "assistant", label: "Assistant" },
  { id: "forms", label: "Forms" },
  { id: "documents", label: "Documents" },
  { id: "faq", label: "FAQs" },
] as const;

export function guideScrollBehavior(prefersReducedMotion: boolean) {
  return prefersReducedMotion ? "auto" : "smooth";
}

export function scrollToGuideSection(id: string) {
  const target = document.getElementById(id);
  if (!target) return;

  const prefersReducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
  target.scrollIntoView({ behavior: guideScrollBehavior(prefersReducedMotion), block: "start" });
  target.focus({ preventScroll: true });
}

export default function HowItWorks() {
  useEffect(() => {
    let frame: number | undefined;
    const scrollFromLocationHash = () => {
      const targetId = window.location.hash.replace("#", "");
      if (!guideSections.some((section) => section.id === targetId)) return;

      if (frame !== undefined) window.cancelAnimationFrame(frame);
      frame = window.requestAnimationFrame(() => scrollToGuideSection(targetId));
    };

    scrollFromLocationHash();
    window.addEventListener("hashchange", scrollFromLocationHash);
    return () => {
      if (frame !== undefined) window.cancelAnimationFrame(frame);
      window.removeEventListener("hashchange", scrollFromLocationHash);
    };
  }, []);

  const handleSectionLink = (event: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    event.preventDefault();
    window.history.pushState(null, "", `#${id}`);
    scrollToGuideSection(id);
  };
  return (
    <main className="mx-auto max-w-6xl space-y-8 pb-12">
      <Seo
        title="How It Works | ProbatePro"
        description="Private ProbatePro product guide."
        path="/how-it-works"
        index={false}
      />
      <motion.section
        className="relative overflow-hidden rounded-2xl border border-primary/15 bg-[radial-gradient(circle_at_top_right,hsl(var(--primary)/0.16),transparent_46%),linear-gradient(135deg,hsl(var(--card)),hsl(var(--muted)/0.52))] p-6 shadow-sm sm:p-9"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.28, ease: [0.23, 1, 0.32, 1] }}
      >
        <div className="relative max-w-3xl space-y-4">
          <Badge className="bg-primary/10 text-primary hover:bg-primary/10">Product guide</Badge>
          <div className="space-y-2">
            <h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">How ProbatePro works</h1>
            <p className="max-w-2xl text-base leading-7 text-muted-foreground sm:text-lg">
              A practical guide to moving a BC probate estate from intake through reviewed filing documents—with clear client collaboration, readiness checks, and professional control at every decision point.
            </p>
          </div>
          <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-2 rounded-full border bg-background/70 px-3 py-1.5"><FolderLock className="h-3.5 w-3.5 text-primary" /> Estate-scoped records</span>
            <span className="inline-flex items-center gap-2 rounded-full border bg-background/70 px-3 py-1.5"><ShieldCheck className="h-3.5 w-3.5 text-primary" /> Lawyer review before filing</span>
          </div>
        </div>
      </motion.section>

      <nav aria-label="Guide sections" className="sticky top-3 z-10 -mt-3 rounded-xl border border-border/70 bg-background/90 p-2 shadow-sm backdrop-blur supports-[backdrop-filter]:bg-background/80">
        <div className="flex flex-wrap items-center gap-1">
          <span className="shrink-0 px-2 text-xs font-medium text-muted-foreground">Jump to</span>
          {guideSections.map((section) => (
            <a
              key={section.id}
              href={`#${section.id}`}
              onClick={(event) => handleSectionLink(event, section.id)}
              className="rounded-lg px-2.5 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 sm:px-3 sm:text-sm"
            >
              {section.label}
            </a>
          ))}
        </div>
      </nav>

      <section id="workflow" tabIndex={-1} aria-labelledby="workflow-heading" className="scroll-mt-6 space-y-4 focus:outline-none">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-primary">The core workflow</p>
            <h2 id="workflow-heading" className="text-2xl font-semibold tracking-tight">From intake to a reviewed filing package</h2>
          </div>
          <ListChecks className="hidden h-7 w-7 text-primary/60 sm:block" aria-hidden="true" />
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {workflow.map((step, index) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={step.number}
                id={step.number === "04" ? "forms" : undefined}
                tabIndex={step.number === "04" ? -1 : undefined}
                className={step.number === "04" ? "scroll-mt-6 focus:outline-none" : undefined}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.24, delay: index * 0.045, ease: [0.23, 1, 0.32, 1] }}
              >
                <Card className="h-full border-border/70 transition-shadow duration-200 hover:shadow-md">
                  <CardHeader className="flex flex-row items-start gap-4 space-y-0">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary text-sm font-semibold text-primary-foreground">{step.number}</span>
                    <div className="space-y-1">
                      <CardTitle className="flex items-center gap-2 text-lg"><Icon className="h-4 w-4 text-primary" />{step.title}</CardTitle>
                      <CardDescription className="leading-6">{step.text}</CardDescription>
                    </div>
                  </CardHeader>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-2" aria-label="Assistant and document guidance">
        <Card id="assistant" tabIndex={-1} className="scroll-mt-6 border-primary/15 bg-primary/[0.025] focus:outline-none">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Bot className="h-5 w-5 text-primary" /> Using the Assistant responsibly</CardTitle>
            <CardDescription>The Assistant is optional, consent-gated, and designed to support—not replace—professional review.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 text-sm leading-6 text-muted-foreground">
            <p>Enable Assistant processing from the sidebar only when you want to use it. It can help explain what is recorded, guide you to the right workspace, and perform authorized assistance, but it does not decide legal validity, entitlement, filing strategy, or professional obligations.</p>
            <p className="rounded-lg border border-primary/15 bg-background/70 p-3 text-foreground"><strong>Always verify:</strong> the original estate records, uploaded documents, readiness items, generated output, and any Assistant response before relying on it.</p>
          </CardContent>
        </Card>
        <Card id="documents" tabIndex={-1} className="scroll-mt-6 focus:outline-none">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><FolderLock className="h-5 w-5 text-primary" /> Records, documents, and review</CardTitle>
            <CardDescription>The estate file is the working source of record; uploads support it but do not replace legal review.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 text-sm leading-6 text-muted-foreground">
            <p>Each estate keeps its own contacts, documents, notices, inventory, notes, generated files, and client submissions. Uploaded materials are validated before entering the protected document flow.</p>
            <p>When a client sends intake information, their submission remains separate until a lawyer chooses which nonblank facts to apply. A current-record check prevents an old review from overwriting newer Intake work.</p>
          </CardContent>
        </Card>
      </section>

      <section id="faq" tabIndex={-1} className="scroll-mt-6 grid gap-4 lg:grid-cols-[0.75fr_1.25fr] focus:outline-none" aria-labelledby="faq-heading">
        <Card className="bg-muted/35">
          <CardHeader>
            <HelpCircle className="mb-2 h-6 w-6 text-primary" aria-hidden="true" />
            <CardTitle>Frequently asked questions</CardTitle>
            <CardDescription>Quick answers for the team using the estate workspace, the dedicated Executor Portal, settings, and clients using the portal.</CardDescription>
          </CardHeader>
          <CardContent className="text-sm leading-6 text-muted-foreground">
            This guide explains the product workflow. It is not legal advice and does not replace professional review, the governing rules, or filing requirements.
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-2">
            <h2 id="faq-heading" className="sr-only">Frequently asked questions</h2>
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem key={faq.question} value={`faq-${index}`}>
                  <AccordionTrigger className="text-left text-sm font-medium hover:no-underline">{faq.question}</AccordionTrigger>
                  <AccordionContent className="faq-accordion-content pr-2 text-sm leading-6 text-muted-foreground">{faq.answer}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
      </section>
    </main>
  );
}
