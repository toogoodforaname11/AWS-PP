/**
 * P3 remains accessible with the long-form preference checked. Applicability
 * and missing receipt warnings lead to Generate anyway, then the real download
 * helper must initiate a file download before the page reports success. The
 * mock awaits mutation callbacks so missing or invalid deliveries and download
 * failures exercise the same rejection/retry path as a generation error.
 */
import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { describe, expect, it, vi, beforeEach, afterEach } from "vitest";

vi.setConfig({ testTimeout: 45000 });

(globalThis as any).React = React;

vi.mock("sonner", () => ({
  toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }),
}));
import { toast as mockedToast } from "sonner";

const mocks = vi.hoisted(() => ({
  generateCalls: [] as any[],
  estateUpdateCalls: [] as any[],
  receiptUpdateCalls: [] as any[],
  preflightCalls: [] as any[],
  contacts: [] as any[],
  /** What the server's document.preflight returns for the next call(s). */
  preflightReport: null as null | ((input: any) => any),
  /** When set, document.generate rejects with this error (after onError). */
  generateError: null as null | Error,
  generateResponse: {} as { id?: string; delivery?: unknown; filename?: string; format?: string },
  /** document.generate's POST delivery (Nick, 2026-10-20), never a GET URL. */
  delivery: {
    method: "POST",
    action: "/api/download/form",
    fields: { estateId: "estate-1", formCode: "P3", documentId: "doc_p3_1", signatoryType: "lawyer", signatureDate: "2026-07-12", generateAnyway: "true" },
  },
}));

vi.mock("@/lib/trpc", () => {
  const queryDataFor = (key: string): any => {
    if (key === "contact.list") return mocks.contacts;
    if (key === "document.list" || key === "document.versions" || key === "document.retainedFiles") return [];
    if (key === "document.getLetterRecipients") return [];
    if (key === "citation.list" || key === "delivery.list" || key === "delivery.getRecipients") return [];
    return undefined;
  };
  const mutationFor = (key: string, opts?: any) => {
    const mutateAsync = async (input: any) => {
      if (key === "estate.update") mocks.estateUpdateCalls.push(input);
      if (key === "requiredDoc.upsert") mocks.receiptUpdateCalls.push(input);
      try {
        if (key === "document.generate") {
          mocks.generateCalls.push(input);
          if (mocks.generateError) throw mocks.generateError;
        }
        const result = key === "document.generate" ? mocks.generateResponse : {};
        // TanStack awaits onSuccess; a callback rejection also invokes onError
        // and rejects mutateAsync, keeping the preflight continuation retryable.
        await opts?.onSuccess?.(result, input, undefined);
        return result;
      } catch (error) {
        await opts?.onError?.(error, input, undefined);
        throw error;
      }
    };
    return {
      mutate: (input: any) => { void mutateAsync(input).catch(() => undefined); },
      mutateAsync,
      isPending: false,
    };
  };
  function utilsNode(path: string[]): any {
    return new Proxy({} as any, {
      get(_t, prop: string) {
        if (prop === "invalidate" || prop === "setData" || prop === "cancel") return () => undefined;
        if (prop === "getData") return () => undefined;
        if (prop === "fetch") {
          return async (input: any) => {
            const key = path.join(".");
            if (key === "document.preflight") {
              mocks.preflightCalls.push(input);
              return mocks.preflightReport ? mocks.preflightReport(input) : { formCode: input.formCode, ok: true, gaps: [] };
            }
            if (key === "document.preflightMany") return [];
            if (key === "estate.get") return longFormEstate();
            return undefined;
          };
        }
        return utilsNode([...path, prop]);
      },
    });
  }
  function node(path: string[]): any {
    return new Proxy({} as any, {
      get(_t, prop: string) {
        if (prop === "useQuery") {
          return () => ({ data: queryDataFor(path.join(".")), isLoading: false, error: null });
        }
        if (prop === "useMutation") {
          return (opts?: any) => mutationFor(path.join("."), opts);
        }
        if (prop === "useUtils") return () => utilsNode([]);
        return node([...path, prop]);
      },
    });
  }
  return { trpc: node([]) };
});

const applicant = {
  id: "applicant-1",
  role: "applicant,executor",
  executorStatus: "applying",
  executorRank: "primary",
  name: "Alex Applicant",
};

/** A confirmed P4-required probate estate — P3 is its hidden alternate. */
function longFormEstate(overrides: Record<string, unknown> = {}) {
  return {
    id: "estate-1",
    grantType: "grant_of_probate",
    hasWill: 1,
    willType: "physical",
    isElectronicWill: 0,
    testamentaryDocStatus: "none_found",
    beliefLastBcWill: "yes",
    specialCircumstances: "none",
    willFilingType: "physical_original",
    foreignWillStatus: "made_in_bc",
    wesaS58Reliance: "no",
    ordersAffectingWill: "no",
    vsaCertificateResult: "no_notice",
    isMilitaryWill: "no",
    executionIssues: "no_issues",
    willAlterations: "unauthorized",
    willAppearanceIssues: "no",
    referencedDocuments: "no",
    willDocumentsAttached: "yes",
    otherGrantsStatus: "no_other_grants",
    notifyPGT: "no",
    pgtIsApplicant: "no",
    p1NotRequired: 0,
    deceasedDomiciledInBC: "yes",
    deceasedFirstName: "Alex",
    deceasedLastName: "North",
    willDate: "2024-01-15",
    codicilFiles: "[]",
    applicantType: "executor",
    useLongFormAffidavit: 0,
    ...overrides,
  };
}

/** A confirmed P3-required probate estate for the still-selected primary-affidavit path. */
function shortFormEstate(overrides: Record<string, unknown> = {}) {
  return longFormEstate({ willAlterations: "no_alterations", ...overrides });
}

/** The regular required-P3 preflight retains a P3 face-content warning without an applicability escape. */
function serverP3Preflight(input: any) {
  return {
    formCode: "P3",
    ok: false,
    hardBlocked: false,
    gaps: [{
      requirementId: "p3_notify_pgt_answered",
      label: "PGT notification determination (yes/no)",
      missingFields: ["estate.notifyPGT"],
      tab: "intake",
      source: "SCCR Rule 25-2(8)(b) + Rule 25-2(11); Form P3 paragraph 3",
    }],
    notApplicable: false,
  };
}

async function renderFormsTab(estate = longFormEstate()) {
  const { FormsTab } = await import("./EstateDetail");
  render(<FormsTab estateId="estate-1" estate={estate} onNavigateToTab={vi.fn()} />);
}

const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
/** Each same-tab form POST the page submits; the browser's attachment download follows it. */
const downloads: Array<{ method: string; action: string | null; fields: Record<string, string> }> = [];
const posted = (fields: Record<string, string>) => ({ method: "post", action: "/api/download/form", fields: { ...fields, attemptId: expect.stringMatching(UUID_V4) } });
let formSubmit: ReturnType<typeof vi.spyOn>;

beforeEach(() => {
  vi.clearAllMocks();
  mocks.generateCalls.length = 0;
  mocks.estateUpdateCalls.length = 0;
  mocks.receiptUpdateCalls.length = 0;
  mocks.preflightCalls.length = 0;
  mocks.contacts = [applicant];
  mocks.preflightReport = serverP3Preflight;
  mocks.generateError = null;
  mocks.generateResponse = { id: "doc_p3_1", delivery: mocks.delivery, filename: "P3_Alex_North.docx", format: "docx" };
  Object.defineProperty(HTMLElement.prototype, "scrollIntoView", { value: () => {}, configurable: true });
  downloads.length = 0;
  formSubmit = vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) {
    downloads.push({ method: this.method, action: this.getAttribute("action"), fields: Object.fromEntries(new FormData(this)) as Record<string, string> });
  });
});

afterEach(() => {
  vi.restoreAllMocks();
  // Never let a regressed helper's temporary form leak into the next test.
  document.querySelectorAll('form[action^="/api/download/"]').forEach((form) => form.remove());
});

async function openP3Warnings() {
  await renderFormsTab(shortFormEstate());
  fireEvent.click(screen.getByTestId("form-generate-P3"));
  await waitFor(() => expect(screen.getByTestId("form-details-generate")).toBeTruthy());
  fireEvent.click(screen.getByTestId("form-details-generate"));
  await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());
  const proceed = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
  expect(proceed.disabled).toBe(false);
  expect(proceed.textContent).toMatch(/Generate anyway/i);
  return proceed;
}

describe("P3/P4 mutually exclusive Forms-tab cards", () => {
  it("shows required P4 and retains P3 as an Optional on-demand alternative", async () => {
    await renderFormsTab();
    expect(screen.getByTestId("form-row-P4")).toBeTruthy();
    expect(screen.getByTestId("form-badge-P4").textContent).toBe("Required");
    expect(screen.getByTestId("form-row-P3")).toBeTruthy();
    expect(screen.getByTestId("form-badge-P3").textContent).toBe("Optional");
    expect((screen.getByTestId("form-generate-P3") as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(screen.getByTestId("form-generate-P3"));
    expect(screen.getByTestId("fix-applicability-dialog")).toBeTruthy();
  });

  it("P3's required row warns, then Generate anyway downloads P3 without changing intake", async () => {
    const proceed = await openP3Warnings();
    expect(mocks.preflightCalls[0]).toMatchObject({ formCode: "P3" });
    const dialogText = screen.getByTestId("pre-generate-dialog").textContent || "";
    expect(dialogText).toContain("PGT notification determination");
    expect(mocks.generateCalls).toEqual([]);
    expect(downloads).toEqual([]);

    fireEvent.click(proceed);
    await waitFor(() => expect(downloads).toEqual([posted(mocks.delivery.fields)]));
    expect(mocks.generateCalls).toHaveLength(1);
    expect(mocks.generateCalls[0]).toMatchObject({ formCode: "P3", generateAnyway: true });
    expect(mocks.generateCalls[0].overrides?.useLongFormAffidavit).toBeUndefined();
    await waitFor(() => expect(mockedToast.info).toHaveBeenCalledWith("Form generated — download requested. Check your browser's downloads."));
    expect(formSubmit.mock.invocationCallOrder[0]).toBeLessThan(vi.mocked(mockedToast.info).mock.invocationCallOrder[0]);
    expect(mockedToast.error).not.toHaveBeenCalled();
    expect(mocks.estateUpdateCalls).toEqual([]);
    expect(mocks.receiptUpdateCalls).toEqual([]);
    expect(screen.getByTestId("form-badge-P3").textContent).toBe("Required");
  });

  it("P3's required row opens evidence warnings directly, without an applicability dialog", async () => {
    const proceed = await openP3Warnings();
    expect(screen.queryByTestId("fix-applicability-dialog")).toBeNull();
    expect(screen.getByTestId("pre-generate-dialog").textContent).toContain("PGT notification determination");
    fireEvent.click(proceed);
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(mocks.generateCalls[0]).toMatchObject({ formCode: "P3" });
    expect(mockedToast.error).not.toHaveBeenCalled();
    expect(mockedToast.info).toHaveBeenCalledTimes(1);
    expect(mocks.estateUpdateCalls).toEqual([]);
    expect(mocks.receiptUpdateCalls).toEqual([]);
  });

  it("shows required P3 and retains P4 as an Optional on-demand alternative", async () => {
    await renderFormsTab(shortFormEstate());
    expect(screen.getByTestId("form-row-P3")).toBeTruthy();
    expect(screen.getByTestId("form-badge-P3").textContent).toBe("Required");
    expect(screen.getByTestId("form-row-P4")).toBeTruthy();
    expect(screen.getByTestId("form-badge-P4").textContent).toBe("Optional");
    expect((screen.getByTestId("form-generate-P4") as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(screen.getByTestId("form-generate-P4"));
    expect(screen.getByTestId("fix-applicability-dialog")).toBeTruthy();
  });

  it("keeps P3 required when a short-form confirmation is unanswered and leaves P4 optional", async () => {
    await renderFormsTab(shortFormEstate({ testamentaryDocStatus: "" }));
    expect(screen.getByTestId("form-badge-P3").textContent).toBe("Required");
    expect(screen.getByTestId("form-badge-P4").textContent).toBe("Optional");
    expect((screen.getByTestId("form-generate-P3") as HTMLButtonElement).disabled).toBe(false);
  });

  it("hides an unanswered non-face P3 short-form fact and generates an explicit draft", async () => {
    mocks.preflightReport = () => ({
      formCode: "P3",
      ok: false,
      hardBlocked: false,
      gaps: [{
        requirementId: "p3_rule_25_3_6_belief_last_bc_will_unconfirmed",
        label: "Record the applicant's belief that this is the last will dealing with BC property before swearing Form P3",
        missingFields: [],
        tab: "intake",
        source: "SCCR Rule 25-3(2)(b) + Rule 25-3(6); Form P3",
      }],
    });

    await renderFormsTab(shortFormEstate({ beliefLastBcWill: "" }));
    expect(screen.getByTestId("form-badge-P3").textContent).toBe("Required");
    expect(screen.getByTestId("form-badge-P4").textContent).toBe("Optional");
    fireEvent.click(screen.getByTestId("form-generate-P3"));
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());
    expect(screen.queryByTestId("pre-generate-gap-p3_rule_25_3_6_belief_last_bc_will_unconfirmed")).toBeNull();
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(mocks.generateCalls[0]).toMatchObject({ formCode: "P3", generateAnyway: true });
    expect(mocks.generateCalls[0].overrides).toBeUndefined();
    expect(mocks.estateUpdateCalls).toEqual([]);
  });

  it.each(["generation", "missing delivery", "query-string delivery", "download initiation"])("%s failure shows an error, never succeeds, and allows retry", async (failure) => {
    const expectedError = failure === "generation" ? "Upload failed. Try again."
      : failure === "download initiation" ? "Download could not start."
      : "The form response did not include a download link. Please try again.";
    if (failure === "generation") mocks.generateError = new Error(expectedError);
    else if (failure === "missing delivery") delete mocks.generateResponse.delivery;
    else if (failure === "query-string delivery") mocks.generateResponse.delivery = { ...mocks.delivery, action: "/api/download/form?documentId=doc_p3_1" };
    else formSubmit.mockImplementationOnce(() => { throw new Error(expectedError); });

    const proceed = await openP3Warnings();
    fireEvent.click(proceed);
    await waitFor(() => expect(mockedToast.error).toHaveBeenCalledWith(expectedError));
    expect(downloads).toEqual([]);
    expect(document.querySelector("form")).toBeNull();
    expect(mockedToast.success).not.toHaveBeenCalled();
    expect(mockedToast.info).not.toHaveBeenCalled();
    expect(screen.queryByText("Document generated!")).toBeNull();
    expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy();
    await waitFor(() => expect((screen.getByTestId("pre-generate-proceed") as HTMLButtonElement).disabled).toBe(false));

    mocks.generateError = null;
    mocks.generateResponse.delivery = mocks.delivery;
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(mocks.generateCalls).toHaveLength(2);
    expect(mocks.generateCalls[1]).toEqual(mocks.generateCalls[0]);
    expect(mockedToast.info).toHaveBeenCalledTimes(1);
    expect(mocks.estateUpdateCalls).toEqual([]);
  });
});
