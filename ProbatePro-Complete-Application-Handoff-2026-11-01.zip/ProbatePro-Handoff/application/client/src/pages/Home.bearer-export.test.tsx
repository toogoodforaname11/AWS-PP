/**
 * Task 9: the dashboard estate export for a cookie-blocked session holding the Preview Bearer
 * fallback. One same-origin fetch carries Authorization (never a header-less native form), the
 * validated ZIP is handed to the browser, and the existing toast follows the handoff only.
 * Fictional data only.
 */
import React from "react";
import JSZip from "jszip";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { toast } from "sonner";
import { browserResponse } from "@/lib/browserResponse.testkit";

(globalThis as any).React = React;

const TOKEN = "fictional.bearer.task9-home";
const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;

const mocks = vi.hoisted(() => ({
  exportResult: null as any,
  navigate: vi.fn(),
}));

vi.mock("wouter", () => ({ useLocation: () => ["/", mocks.navigate], useSearch: () => "" }));
vi.mock("sonner", () => ({ toast: { success: vi.fn(), error: vi.fn(), info: vi.fn(), loading: vi.fn(), dismiss: vi.fn() } }));

vi.mock("@/lib/trpc", () => {
  const idleMutation = () => ({ mutate: vi.fn(), isPending: false });
  const invalidate = vi.fn();
  return {
    trpc: {
      estate: {
        list: { useQuery: () => ({
          data: [{
            id: "estate-1", estateName: "Smith Estate", deceasedFirstName: "Alex", deceasedMiddleNames: "",
            deceasedSecondMiddleName: "", deceasedLastName: "Smith", fileNumber: 42, status: "incomplete",
            registry: "Vancouver", dateOfDeath: "", domicileCity: "", willStorageKey: "", hasWill: 1, grantType: "probate",
          }],
          isLoading: false, isError: false, refetch: vi.fn(),
        }) },
        dispositions: { useQuery: () => ({ data: [] }) },
        witnessStats: { useQuery: () => ({ data: {} }) },
        letterStats: { useQuery: () => ({ data: {} }) },
        distributionStats: { useQuery: () => ({ data: {} }) },
        create: { useMutation: idleMutation },
        update: { useMutation: idleMutation },
        duplicate: { useMutation: idleMutation },
        // Like TanStack: mutate runs the caller's onSuccess with the server result.
        export: { useMutation: (options: any) => ({ mutate: (input: any) => { options?.onSuccess?.(mocks.exportResult, input); }, isPending: false }) },
        delete: { useMutation: idleMutation },
      },
      deadline: { list: { useQuery: () => ({ data: { events: [] }, isError: false }) } },
      notes: { search: { useQuery: () => ({ data: [] }) } },
      clientIntake: { dashboardStatus: { useQuery: () => ({ data: {} }) } },
      settings: { get: { useQuery: () => ({ data: { accountPurpose: "unselected" } }) } },
      useUtils: () => ({
        estate: { list: { invalidate }, dispositions: { invalidate } },
        deadline: { list: { invalidate } },
      }),
    },
  };
});

import Home from "./Home";

let zipBytes: Uint8Array;
const fetchSpy = vi.fn<(input: RequestInfo | URL, init?: RequestInit) => Promise<Response>>();
const nativeSubmits: string[] = [];
const anchorClicks: Array<{ href: string; download: string }> = [];

beforeAll(async () => {
  zipBytes = await new JSZip().file("records.json", "{}").generateAsync({ type: "uint8array" });
});

beforeEach(() => {
  vi.clearAllMocks();
  mocks.exportResult = {
    delivery: { method: "POST", action: "/api/download/export", fields: { type: "estate", estateId: "estate-1" } },
    fileCount: 2,
  };
  nativeSubmits.length = 0;
  anchorClicks.length = 0;
  fetchSpy.mockReset();
  vi.stubGlobal("fetch", fetchSpy);
  sessionStorage.setItem("manus-cookie", `app_session_id=${TOKEN}`);
  vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) {
    nativeSubmits.push(this.getAttribute("action") ?? "");
  });
  vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(function (this: HTMLAnchorElement) {
    anchorClicks.push({ href: this.href, download: this.download });
  });
  Object.defineProperty(URL, "createObjectURL", { configurable: true, writable: true, value: vi.fn(() => "blob:http://localhost/task9-home") });
  Object.defineProperty(URL, "revokeObjectURL", { configurable: true, writable: true, value: vi.fn() });
});

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  sessionStorage.clear();
  delete (URL as any).createObjectURL;
  delete (URL as any).revokeObjectURL;
});

function exportEstate() {
  render(<Home />);
  fireEvent.pointerDown(screen.getByRole("button", { name: "More actions for Smith Estate" }), { button: 0, ctrlKey: false });
  fireEvent.click(screen.getByText("Export estate copy"));
}

describe("Task 9: dashboard estate export with the Bearer fallback", () => {
  it("sends one Bearer fetch with the native envelope, hands off the ZIP, then shows its handoff toast", async () => {
    fetchSpy.mockResolvedValueOnce(browserResponse(zipBytes, {
      status: 200,
      headers: { "content-type": "application/zip", "content-disposition": 'attachment; filename="ProbatePro_Estate_Export_Smith_Estate_1.zip"', "content-length": String(zipBytes.length) },
    }));
    exportEstate();

    await waitFor(() => expect(anchorClicks).toHaveLength(1));
    expect(fetchSpy).toHaveBeenCalledTimes(1);
    const [url, init] = fetchSpy.mock.calls[0] as [string, RequestInit];
    expect(url).toBe("/api/download/export");
    expect(init).toMatchObject({ method: "POST", credentials: "include", redirect: "manual" });
    expect(init.headers).toEqual({ "Content-Type": "application/x-www-form-urlencoded", Authorization: `Bearer ${TOKEN}` });
    expect(Object.fromEntries(new URLSearchParams(String(init.body)))).toEqual({ type: "estate", estateId: "estate-1", attemptId: expect.stringMatching(UUID_V4) });
    expect(anchorClicks[0]).toEqual({ href: "blob:http://localhost/task9-home", download: "ProbatePro_Estate_Export_Smith_Estate_1.zip" });
    expect(toast.loading).toHaveBeenCalledWith("Estate export (2 stored files) — preparing the download…");
    await waitFor(() => expect(toast.success).toHaveBeenCalledWith("Estate export (2 stored files) — download started."));
    expect(toast.error).not.toHaveBeenCalled();
    expect(nativeSubmits).toEqual([]);
  });

  it("a refused export shows only its sentence and never claims the download", async () => {
    fetchSpy.mockResolvedValueOnce(browserResponse(JSON.stringify({ error: "Estate exports are busy. Please try again in a moment." }), {
      status: 503, headers: { "content-type": "application/json; charset=utf-8" },
    }));
    exportEstate();

    await waitFor(() => expect(toast.error).toHaveBeenCalledWith("Estate exports are busy. Please try again in a moment."));
    expect(toast.success).not.toHaveBeenCalled();
    expect(anchorClicks).toEqual([]);
    expect(nativeSubmits).toEqual([]);
    expect(fetchSpy).toHaveBeenCalledTimes(1);
  });
});
