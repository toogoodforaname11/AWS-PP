/**
 * Integration tests for the runWithPreflight helper wiring in FormsTab.
 * These tests verify the contract between the FormsTab component and the
 * PreGenerateDialog component. They do NOT render the full EstateDetail page.
 *
 * The tests verify:
 * 1. When preflight returns ok=true, the mutation fires immediately (no dialog).
 * 2. When preflight returns gaps, the dialog opens with the correct reports.
 * 3. P19 has no live Generate/Preview (court-issued; buttons render disabled —
 *    see EstateDetail.p19-court-issued.test.tsx).
 */
import { afterEach, describe, it, expect, vi } from "vitest";
import React from "react";
import { cleanup, render, screen, fireEvent, waitFor } from "@testing-library/react";
import { browserResponse } from "@/lib/browserResponse.testkit";

/** A delivery route's JSON refusal as a browser hands it to page code (Task 9: the bounded reader needs a real body). */
const jsonRefusal = (error: string, status = 500) => browserResponse(JSON.stringify({ error }), { status, headers: { "content-type": "application/json; charset=utf-8" } });

// We test the PreGenerateDialog directly since FormsTab has too many tRPC dependencies.
// These tests validate the dialog behavior that the wiring relies on.
import { PreGenerateDialog } from "@/components/PreGenerateDialog";
import type { FormGapReport } from "@shared/formRequirements";

// Later tests do `await import("./EstateDetail")` (a very large module) inside the test
// body; that first transform+render sits near vitest's 5000ms default testTimeout. Raise
// the per-file ceiling so parallel-load contention can't tip it over. ponytail: bump to
// 20000 if CI still flakes.
vi.setConfig({ testTimeout: 45000 }); // 2026-08-21: jsdom EstateDetail suites breached 15-20s under full-suite worker contention (flake class, memory probatepro-test-flakiness) — headroom, not speed, keeps the gate reproducible
afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
  vi.useRealTimers();
  // Every document.generate call lands in p46Mutate (the preview's DOCX
  // download generates first too); start each test from a clean record.
  mocks.p46Mutate.mockClear();
  mocks.generateResult = previewGenerated;
  mocks.generateError = null;
  mocks.runGenerateOnSuccess = false;
});

const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;

/** The preview's DOCX fetch posts the generated delivery as JSON: its fields plus a per-click attemptId, no query string. */
function expectDeliveryFetch(fetchSpy: ReturnType<typeof vi.fn>) {
  const [url, init] = fetchSpy.mock.calls[0] as [string, RequestInit];
  expect(url).toBe("/api/download/form");
  expect(init).toMatchObject({ method: "POST", credentials: "include", headers: { "Content-Type": "application/json" } });
  expect(JSON.parse(String(init.body))).toEqual({ ...previewGenerated.delivery.fields, attemptId: expect.stringMatching(UUID_V4) });
}

describe("EstateDetail preflight integration", () => {
  it("PreGenerateDialog calls onProceed when user clicks Generate Anyway", () => {
    const onProceed = vi.fn();
    const onCancel = vi.fn();
    const onJumpToTab = vi.fn();

    const reports: FormGapReport[] = [
      {
        formCode: "P1",
        ok: false,
        gaps: [
          { requirementId: "p1_deceased_name", label: "Deceased name is missing", missingFields: ["estate.deceasedLastName"], tab: "intake", source: "Rule 25-2(2)" },
        ],
      },
    ];

    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="P1 — Notice"
        reports={reports}
        onProceed={onProceed}
        onJumpToTab={onJumpToTab}
        onCancel={onCancel}
      />,
    );

    const proceedBtn = screen.getByTestId("pre-generate-proceed");
    fireEvent.click(proceedBtn);
    expect(onProceed).toHaveBeenCalledTimes(1);
  });

  it("PreGenerateDialog calls onJumpToTab with correct tab when jump button clicked", () => {
    const onProceed = vi.fn();
    const onCancel = vi.fn();
    const onJumpToTab = vi.fn();

    const reports: FormGapReport[] = [
      {
        formCode: "P3",
        ok: false,
        gaps: [
          { requirementId: "p3_executor_address", label: "Executor address missing", missingFields: ["contacts[0].address"], tab: "contacts", source: "Rule 25-3(2)(d)" },
        ],
      },
    ];

    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="P3 — Affidavit"
        reports={reports}
        onProceed={onProceed}
        onJumpToTab={onJumpToTab}
        onCancel={onCancel}
      />,
    );

    const jumpBtn = screen.getByTestId("pre-generate-jump-p3_executor_address");
    fireEvent.click(jumpBtn);
    expect(onJumpToTab).toHaveBeenCalledWith("contacts");
  });

  it("PreGenerateDialog calls onCancel when cancel button clicked", () => {
    const onProceed = vi.fn();
    const onCancel = vi.fn();
    const onJumpToTab = vi.fn();

    const reports: FormGapReport[] = [
      {
        formCode: "P10",
        ok: false,
        gaps: [
          { requirementId: "p10_date_of_death", label: "Date of death missing", missingFields: ["estate.dateOfDeath"], tab: "intake", source: "Rule 25-3(2)(e)" },
        ],
      },
    ];

    render(
      <PreGenerateDialog
        open={true}
        onOpenChange={() => {}}
        formName="P10 — Affidavit"
        reports={reports}
        onProceed={onProceed}
        onJumpToTab={onJumpToTab}
        onCancel={onCancel}
      />,
    );

    const cancelBtn = screen.getByTestId("pre-generate-cancel");
    fireEvent.click(cancelBtn);
    expect(onCancel).toHaveBeenCalledTimes(1);
  });
});

/**
 * 2026-07-06 audit C-09 — the FormPreviewModal DOCX download must run through
 * the same runWithPreflight gate as Generate, not fetch /api/download/form
 * directly. We render the exported FormPreviewModal with a stubbed trpc client
 * and assert the Download click is routed through the injected preflight fn.
 */
// What document.generate resolves to (Nick, 2026-10-20): a POST delivery
// descriptor, never a GET URL.
const previewGenerated = vi.hoisted(() => ({
  id: "doc_preview_1",
  delivery: {
    method: "POST",
    action: "/api/download/form",
    fields: { estateId: "e1", formCode: "P3", documentId: "doc_preview_1", signatoryType: "executor", signatureDate: "2026-07-11" },
  },
  format: "docx",
  filename: "P3_North.docx",
  documentName: "Affidavit of Applicant",
}));
const mocks = vi.hoisted(() => ({
  p46Mutate: vi.fn(),
  generateResult: previewGenerated as any,
  generateError: null as Error | null,
  /** Run the mutation's onSuccess like TanStack (only the P46 delivery test needs it). */
  runGenerateOnSuccess: false,
  previewSections: [{ type: "paragraph", text: "Preview body" }] as any[],
  previewInputs: [] as any[],
  pdfDoc: {
    internal: { pageSize: { getWidth: () => 612, getHeight: () => 792 } },
    addPage: vi.fn(),
    setFont: vi.fn(),
    setFontSize: vi.fn(),
    setDrawColor: vi.fn(),
    line: vi.fn(),
    rect: vi.fn(),
    splitTextToSize: vi.fn((text: string) => String(text).split("\n")),
    text: vi.fn(),
    save: vi.fn(),
  },
}));

vi.mock("jspdf", () => ({
  jsPDF: vi.fn(() => mocks.pdfDoc),
}));

vi.mock("@/lib/trpc", () => {
  const idleMutation = () => ({ mutate: vi.fn(), isPending: false });
  return {
    trpc: {
      document: {
        preview: {
          useQuery: (input: unknown) => {
            mocks.previewInputs.push(input);
            return {
              data: { sections: mocks.previewSections },
              isLoading: false,
            };
          },
        },
        generate: {
          useMutation: (options?: any) => ({
            mutate: mocks.p46Mutate,
            mutateAsync: async (input: unknown) => {
              mocks.p46Mutate(input);
              if (mocks.generateError) throw mocks.generateError;
              if (mocks.runGenerateOnSuccess) await options?.onSuccess?.(mocks.generateResult, input, undefined);
              return mocks.generateResult;
            },
            isPending: false,
          }),
        },
      },
      delivery: {
        list: {
          useQuery: () => ({
            data: [
              { id: "d1", estateId: "e1", contactId: "c1", recipientName: "Recipient One", deliveryMethod: "electronic", deliveryDate: "2026-07-01", trackingNumber: "", dispensedByOrder: 0, ackDate: "" },
            ],
            isLoading: false,
          }),
        },
        getRecipients: { useQuery: () => ({ data: [{ contactId: "c1", name: "Recipient One", p46Eligible: true, isPgt: false }] }) },
        upsert: { useMutation: idleMutation },
        delete: { useMutation: idleMutation },
        bulkCreate: { useMutation: idleMutation },
        uploadDispensationOrder: { useMutation: idleMutation },
        deleteDispensationOrder: { useMutation: idleMutation },
        updateP46: { useMutation: idleMutation },
        markP44: { useMutation: idleMutation },
      },
      useUtils: () => ({
        delivery: { list: { invalidate: vi.fn() } },
        readiness: { check: { invalidate: vi.fn() }, timeline: { invalidate: vi.fn() } },
        deadline: { list: { invalidate: vi.fn() } },
        document: { preflight: { invalidate: vi.fn() }, preflightMany: { invalidate: vi.fn() }, list: { invalidate: vi.fn() }, versions: { invalidate: vi.fn() } },
      }),
    },
  };
});

/**
 * 2026-07-11 Arc 2 — contacts dialog: nameAsInWill is editable for every
 * non-lawyer contact (was trapped in the executor-only block), and the
 * isPredeceased checkbox writes the real column that drives the notice guards.
 */
describe("ContactFormFields — alias-in-will + predeceased", () => {
  it("shows Name and Name-as-in-Will side by side for a beneficiary; predeceased checkbox writes isPredeceased", async () => {
    const { ContactFormFields } = await import("./EstateDetail");
    const { TooltipProvider } = await import("@/components/ui/tooltip");
    const setContact = vi.fn();
    const contact = { id: "c1", name: "Bob", role: "beneficiary", relationship: "sibling", isPredeceased: 0 };
    render(
      <TooltipProvider>
        <ContactFormFields contact={contact} setContact={setContact} allContacts={[]} />
      </TooltipProvider>,
    );
    expect(screen.getByText("Name as Shown in Will (if different from current name)")).toBeTruthy();
    fireEvent.click(screen.getByTestId("contact-predeceased"));
    expect(setContact).toHaveBeenCalledWith(expect.objectContaining({ isPredeceased: 1 }));
  });

  it("hides Name-as-in-Will and the predeceased checkbox for lawyer contacts", async () => {
    const { ContactFormFields } = await import("./EstateDetail");
    const { TooltipProvider } = await import("@/components/ui/tooltip");
    render(
      <TooltipProvider>
        <ContactFormFields contact={{ id: "c2", name: "Kevin", role: "lawyer" }} setContact={vi.fn()} allContacts={[]} />
      </TooltipProvider>,
    );
    expect(screen.queryByText("Name as Shown in Will (if different from current name)")).toBeNull();
    expect(screen.queryByTestId("contact-predeceased")).toBeNull();
  });

  it("allows the only Beneficiary role to clear instead of silently restoring it", async () => {
    const { ContactFormFields } = await import("./EstateDetail");
    const { TooltipProvider } = await import("@/components/ui/tooltip");
    const setContact = vi.fn();
    render(
      <TooltipProvider>
        <ContactFormFields contact={{ id: "c-clear", name: "Clear Casey", role: "beneficiary", recipientType: "beneficiary" }} setContact={setContact} allContacts={[]} />
      </TooltipProvider>,
    );
    fireEvent.click(screen.getByRole("button", { name: "Beneficiary" }));
    fireEvent.click(screen.getByRole("menuitemcheckbox", { name: "Beneficiary" }));
    expect(setContact).toHaveBeenCalledWith(expect.objectContaining({ role: "" }));
  });
});

/**
 * 2026-07-11 adversarial review — the downloaded DOCX must match the previewed
 * one: doDownloadDocx must carry the popup's deponent selection
 * (selectedContactId / deponentId) to the render. Since 2026-10-20 the route
 * streams only a generation, so that render is document.generate's and the
 * download posts the delivery it returns.
 */
describe("FormPreviewModal Download DOCX deponent params", () => {
  it("manual P5 preview and its DOCX download always carry the explicit draft flag and selected deponent", async () => {
    const { FormPreviewModal } = await import("./EstateDetail");
    mocks.previewInputs.length = 0;
    const runWithPreflight = vi.fn(async (_codes: ReadonlyArray<string>, _name: string, doMutate: (overrides?: Record<string, unknown>) => unknown) => {
      try { await doMutate({ willStatus: "no_will", hasWill: 0 }); } catch { /* request assertion only: storage response intentionally fails */ }
      return true;
    });
    const fetchSpy = vi.fn(async (_url: string, _init?: RequestInit) => jsonRefusal("Download failed"));
    vi.stubGlobal("fetch", fetchSpy);
    render(<FormPreviewModal estateId="e1" formCode="P5" formName="Applicant affidavit" signatoryType="executor" signatureDate="2026-09-04" selectedContactId="second-applicant" open={true} onOpenChange={() => {}} runWithPreflight={runWithPreflight} />);
    expect(mocks.previewInputs.at(-1)).toMatchObject({ formCode: "P5", generateAnyway: true, selectedContactId: "second-applicant" });
    fireEvent.click(screen.getByTestId("preview-download-docx"));
    await waitFor(() => expect(fetchSpy).toHaveBeenCalledTimes(1));
    expect(runWithPreflight).toHaveBeenCalledWith(["P5"], "P5 — Applicant affidavit", expect.any(Function), expect.objectContaining({ generateAnyway: true, selectedContactId: "second-applicant" }), "download");
    expect(mocks.p46Mutate).toHaveBeenCalledTimes(1);
    expect(mocks.p46Mutate).toHaveBeenCalledWith(expect.objectContaining({
      estateId: "e1",
      formCode: "P5",
      signatoryType: "executor",
      signatureDate: "2026-09-04",
      generateAnyway: true,
      selectedContactId: "second-applicant",
      overrides: { willStatus: "no_will", hasWill: 0 },
    }));
    expectDeliveryFetch(fetchSpy);
  });

  it("the generated download carries selectedContactId and deponentId", async () => {
    const { FormPreviewModal } = await import("./EstateDetail");
    // Clean preflight: invoke doMutate so the download actually fires. Await
    // and swallow like the real runWithPreflight does — doDownloadDocx
    // RETHROWS on failure since the 2026-08-21 truthful-download fix, and this
    // stubbed fetch fails by design.
    const runWithPreflight = vi.fn(async (_codes: ReadonlyArray<string>, _name: string, doMutate: () => void | Promise<unknown>) => {
      try { await doMutate(); } catch { /* expected: stubbed fetch responds !ok */ }
    });
    const fetchSpy = vi.fn(async (_url: string, _init?: RequestInit) => jsonRefusal("stub"));
    vi.stubGlobal("fetch", fetchSpy);

    render(
      <FormPreviewModal
        estateId="e1"
        formCode="P3"
        formName="Affidavit of Applicant"
        signatoryType="executor"
        signatureDate="2026-07-11"
        selectedContactId="c-peter"
        deponentId="c-two"
        open={true}
        onOpenChange={() => {}}
        runWithPreflight={runWithPreflight}
      />,
    );

    fireEvent.click(screen.getByTestId("preview-download-docx"));

    await waitFor(() => expect(fetchSpy).toHaveBeenCalledTimes(1));
    // The render context gained the Rule 22 addendum fields: this download's
    // doMutate consumes the effectiveOverrides argument, so it declares
    // `supportsOverrides` and the PreGenerateDialog may offer inline editors.
    expect(runWithPreflight).toHaveBeenCalledWith(
      ["P3"],
      "P3 — Affidavit of Applicant",
      expect.any(Function),
      expect.objectContaining({
        selectedContactId: "c-peter",
        targetContactId: undefined,
        supportsOverrides: true,
      }),
      "download",
    );
    expect(mocks.p46Mutate).toHaveBeenCalledTimes(1);
    expect(mocks.p46Mutate).toHaveBeenCalledWith(expect.objectContaining({ formCode: "P3", selectedContactId: "c-peter", deponentId: "c-two" }));
    expectDeliveryFetch(fetchSpy);

    vi.unstubAllGlobals();
  });
});

describe("FormPreviewModal P17 address editor", () => {
  it("prefills from the last residential address and re-renders P17 with a transient manual location adjustment", async () => {
    const { FormPreviewModal } = await import("./EstateDetail");
    mocks.previewInputs.length = 0;
    render(
      <FormPreviewModal
        estateId="e1"
        formCode="P17"
        formName="Notice of Renunciation"
        signatoryType="executor"
        signatureDate="2026-07-11"
        p17AddressCity="Victoria"
        p17AddressProvince="BC"
        open={true}
        onOpenChange={() => {}}
      />,
    );

    fireEvent.click(screen.getByTestId("p17-preview-edit-address"));
    expect((screen.getByTestId("p17-preview-address-city") as HTMLInputElement).value).toBe("Victoria");
    expect((screen.getByTestId("p17-preview-address-province") as HTMLInputElement).value).toBe("BC");
    expect(screen.getByText(/Intake record is not changed/i)).toBeTruthy();

    fireEvent.change(screen.getByTestId("p17-preview-address-city"), { target: { value: "Duncan" } });
    await waitFor(() => expect(mocks.previewInputs.some((input) => (input as any).overrides?.addressCity === "Duncan" && (input as any).overrides?.addressProvince === "BC")).toBe(true));
  });
});

describe("FormPreviewModal preflight (audit C-09)", () => {
  it("Download DOCX routes through runWithPreflight instead of fetching directly", async () => {
    const { FormPreviewModal } = await import("./EstateDetail");
    const runWithPreflight = vi.fn(async (_codes: ReadonlyArray<string>, _name: string, _doMutate: () => void) => {
      // Simulate a preflight that found gaps: do NOT invoke doMutate.
    });
    const fetchSpy = vi.fn();
    vi.stubGlobal("fetch", fetchSpy);

    render(
      <FormPreviewModal
        estateId="e1"
        formCode="P9"
        formName="Affidavit of Delivery"
        signatoryType="executor"
        signatureDate="2026-07-07"
        open={true}
        onOpenChange={() => {}}
        runWithPreflight={runWithPreflight}
      />,
    );

    fireEvent.click(screen.getByTestId("preview-download-docx"));

    await waitFor(() => expect(runWithPreflight).toHaveBeenCalledTimes(1));
    expect(runWithPreflight).toHaveBeenCalledWith(
      ["P9"],
      "P9 — Affidavit of Delivery",
      expect.any(Function),
      // Rule 22 addendum: this download consumes the overrides argument, so
      // its render context declares supportsOverrides.
      expect.objectContaining({ selectedContactId: undefined, targetContactId: undefined, supportsOverrides: true }),
      "download",
    );
    // The gap dialog withheld approval — no direct download may have fired,
    // and nothing was generated either.
    expect(fetchSpy).not.toHaveBeenCalled();
    expect(mocks.p46Mutate).not.toHaveBeenCalled();

    vi.unstubAllGlobals();
  });
});

/**
 * 2026-08-21 goal loop (F4, truthful download): doDownloadDocx RETHROWS after
 * its error toast, so through the preflight path a failed download REJECTS
 * doMutate — handlePgProceed's catch then restores the continuation and never
 * sets the success state (that restore-on-rejection path is already pinned in
 * EstateDetail.inline-fill.test.tsx "shows success only after a real
 * generation resolves and restores a failed attempt for retry"). The
 * non-preflight fallback call site catches locally so nothing floats.
 */
describe("FormPreviewModal failed download is truthful (2026-08-21 goal loop)", () => {
  it("REJECTS doMutate through the preflight path when the download fetch fails", async () => {
    const { FormPreviewModal } = await import("./EstateDetail");
    let outcome: Promise<string> | null = null;
    const runWithPreflight = vi.fn(async (_codes: ReadonlyArray<string>, _name: string, doMutate: () => void | Promise<unknown>) => {
      // Capture the settled state instead of floating the rejection — the
      // real gate's allOk branch awaits doMutate in a try/catch, and this
      // rejection is exactly what routes it into the failure path.
      outcome = Promise.resolve(doMutate()).then(() => "resolved", () => "rejected");
      return true;
    });
    const fetchSpy = vi.fn(async (_url: string, _init?: RequestInit) => jsonRefusal("boom", 500));
    vi.stubGlobal("fetch", fetchSpy);

    render(
      <FormPreviewModal
        estateId="e1"
        formCode="P3"
        formName="Affidavit of Applicant"
        signatoryType="executor"
        signatureDate="2026-08-21"
        open={true}
        onOpenChange={() => {}}
        runWithPreflight={runWithPreflight}
      />,
    );
    fireEvent.click(screen.getByTestId("preview-download-docx"));

    await waitFor(() => expect(fetchSpy).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(outcome).not.toBeNull());
    // Pre-fix this resolved: doDownloadDocx swallowed the failure and the
    // proceed path announced "Download started!" for a download that never
    // happened.
    await expect(outcome!).resolves.toBe("rejected");

    vi.unstubAllGlobals();
  });

  it("the non-preflight fallback catches locally — a failed download floats no rejection", async () => {
    const { FormPreviewModal } = await import("./EstateDetail");
    const fetchSpy = vi.fn(async (_url: string, _init?: RequestInit) => jsonRefusal("boom", 500));
    vi.stubGlobal("fetch", fetchSpy);

    render(
      <FormPreviewModal
        estateId="e1"
        formCode="P3"
        formName="Affidavit of Applicant"
        signatoryType="executor"
        signatureDate="2026-08-21"
        open={true}
        onOpenChange={() => {}}
        // No runWithPreflight: handleDownloadDocx takes the fallback branch,
        // which must contain the rethrow (toast already told the story).
      />,
    );
    fireEvent.click(screen.getByTestId("preview-download-docx"));

    await waitFor(() => expect(fetchSpy).toHaveBeenCalledTimes(1));
    // Let the rejection (if any escaped) reach the environment before the
    // test ends — an uncaught one fails the run as an unhandled error.
    await new Promise((resolve) => setTimeout(resolve, 25));

    vi.unstubAllGlobals();
  });

  it.each(["refused generation", "missing delivery"])("a %s REJECTS doMutate and posts nothing", async (failure) => {
    const { FormPreviewModal } = await import("./EstateDetail");
    if (failure === "refused generation") mocks.generateError = new Error("Cannot generate P3: the deponent is not an applying applicant.");
    else mocks.generateResult = { ...previewGenerated, delivery: undefined };
    let outcome: Promise<string> | null = null;
    const runWithPreflight = vi.fn(async (_codes: ReadonlyArray<string>, _name: string, doMutate: () => void | Promise<unknown>) => {
      outcome = Promise.resolve(doMutate()).then(() => "resolved", () => "rejected");
      return true;
    });
    const fetchSpy = vi.fn();
    vi.stubGlobal("fetch", fetchSpy);

    render(
      <FormPreviewModal
        estateId="e1"
        formCode="P3"
        formName="Affidavit of Applicant"
        signatoryType="executor"
        signatureDate="2026-08-21"
        open={true}
        onOpenChange={() => {}}
        runWithPreflight={runWithPreflight}
      />,
    );
    fireEvent.click(screen.getByTestId("preview-download-docx"));

    await waitFor(() => expect(outcome).not.toBeNull());
    await expect(outcome!).resolves.toBe("rejected");
    expect(mocks.p46Mutate).toHaveBeenCalledTimes(1);
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it.each([
    [403, "Access denied"],
    [409, "This download link is out of date. Generate the document again."],
    [500, "Failed to generate document. Please try again."],
  ])("a %i refusal of the delivery POST shows its sentence and REJECTS doMutate", async (status, sentence) => {
    const { FormPreviewModal } = await import("./EstateDetail");
    const { toast } = await import("sonner");
    const toastError = vi.spyOn(toast, "error");
    let outcome: Promise<string> | null = null;
    const runWithPreflight = vi.fn(async (_codes: ReadonlyArray<string>, _name: string, doMutate: () => void | Promise<unknown>) => {
      outcome = Promise.resolve(doMutate()).then(() => "resolved", () => "rejected");
      return true;
    });
    const fetchSpy = vi.fn(async (_url: string, _init?: RequestInit) => jsonRefusal(sentence, status));
    vi.stubGlobal("fetch", fetchSpy);

    try {
      render(
        <FormPreviewModal
          estateId="e1"
          formCode="P3"
          formName="Affidavit of Applicant"
          signatoryType="executor"
          signatureDate="2026-08-21"
          open={true}
          onOpenChange={() => {}}
          runWithPreflight={runWithPreflight}
        />,
      );
      fireEvent.click(screen.getByTestId("preview-download-docx"));

      await waitFor(() => expect(outcome).not.toBeNull());
      await expect(outcome!).resolves.toBe("rejected");
      expect(toastError).toHaveBeenCalledWith(sentence);
      expectDeliveryFetch(fetchSpy);
    } finally {
      toastError.mockRestore();
    }
  });
});

/**
 * 2026-07-06 audit C-20 — the P46 button in DeliveriesCard must route through
 * runWithPreflight like every other generate call site, so the gap dialog can
 * appear when P46 requirements are unmet.
 */
describe("DeliveriesCard P46 preflight (audit C-20)", () => {
  it("opens the P46 details popup instead of using an inherited signature date when the parent provides that handoff", async () => {
    const { DeliveriesCard } = await import("./EstateDetail");
    const { TooltipProvider } = await import("@/components/ui/tooltip");
    const onOpenP46Details = vi.fn();

    render(
      <TooltipProvider>
        <DeliveriesCard
          estateId="e1"
          estate={{ id: "e1", willType: "electronic" }}
          signatureDate=""
          onOpenP46Details={onOpenP46Details}
        />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByTestId("p46-generate-d1"));

    expect(onOpenP46Details).toHaveBeenCalledWith("d1", "Recipient One");
    expect(mocks.p46Mutate).not.toHaveBeenCalled();
  });

  it("P46 generation routes through runWithPreflight; a gap-withholding preflight blocks the mutation", async () => {
    const { DeliveriesCard } = await import("./EstateDetail");
    const { TooltipProvider } = await import("@/components/ui/tooltip");
    mocks.p46Mutate.mockClear();
    const runWithPreflight = vi.fn(async (_codes: ReadonlyArray<string>, _name: string, _doMutate: () => void) => {
      // Simulate a preflight that found gaps: do NOT invoke doMutate (the gap dialog owns it).
    });

    render(
      <TooltipProvider>
        <DeliveriesCard estateId="e1" estate={{ id: "e1", willType: "electronic" }} signatureDate="2026-07-14" runWithPreflight={runWithPreflight} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByTestId("p46-generate-d1"));

    await waitFor(() => expect(runWithPreflight).toHaveBeenCalledTimes(1));
    expect(runWithPreflight).toHaveBeenCalledWith(
      ["P46"],
      "P46 — Demand for Recipient One",
      expect.any(Function),
      expect.objectContaining({ targetDeliveryId: "d1", supportsOverrides: true }),
      // Task 13: the card's own (test-only) fallback reports generation, not a download it has not seen.
      "generate",
    );
    // Preflight withheld approval — the generate mutation must not have fired.
    expect(mocks.p46Mutate).not.toHaveBeenCalled();
  });

  it("proceeding after preflight fires the P46 mutation with the trusted delivery id", async () => {
    const { DeliveriesCard } = await import("./EstateDetail");
    const { TooltipProvider } = await import("@/components/ui/tooltip");
    mocks.p46Mutate.mockClear();
    // Simulate a clean preflight (or the user clicking Generate Anyway): invoke doMutate.
    const runWithPreflight = vi.fn(async (_codes: ReadonlyArray<string>, _name: string, doMutate: () => void) => {
      doMutate();
    });

    render(
      <TooltipProvider>
        <DeliveriesCard estateId="e1" estate={{ id: "e1", willType: "electronic" }} signatureDate="2026-07-14" runWithPreflight={runWithPreflight} />
      </TooltipProvider>,
    );

    fireEvent.click(screen.getByTestId("p46-generate-d1"));

    await waitFor(() => expect(mocks.p46Mutate).toHaveBeenCalledTimes(1));
    expect(mocks.p46Mutate).toHaveBeenCalledWith(expect.objectContaining({
      estateId: "e1",
      formCode: "P46",
      deliveryId: "d1",
      signatureDate: "2026-07-14",
    }));
  });

  it("downloads P46 by posting its generated delivery; a response without one rejects and posts nothing", async () => {
    const { DeliveriesCard } = await import("./EstateDetail");
    const { TooltipProvider } = await import("@/components/ui/tooltip");
    const p46Fields = { estateId: "e1", formCode: "P46", documentId: "doc_p46_1", signatoryType: "executor", signatureDate: "2026-07-14", deliveryId: "d1" };
    mocks.runGenerateOnSuccess = true;
    mocks.generateResult = { ...previewGenerated, id: "doc_p46_1", delivery: { method: "POST", action: "/api/download/form", fields: p46Fields } };
    const posts: Array<{ method: string; action: string | null; fields: Record<string, string> }> = [];
    const submit = vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) {
      posts.push({ method: this.method, action: this.getAttribute("action"), fields: Object.fromEntries(new FormData(this)) as Record<string, string> });
    });
    const outcomes: Promise<string>[] = [];
    const runWithPreflight = vi.fn(async (_codes: ReadonlyArray<string>, _name: string, doMutate: () => void | Promise<unknown>) => {
      outcomes.push(Promise.resolve(doMutate()).then(() => "resolved", () => "rejected"));
      return true;
    });

    try {
      render(
        <TooltipProvider>
          <DeliveriesCard estateId="e1" estate={{ id: "e1", willType: "electronic" }} signatureDate="2026-07-14" runWithPreflight={runWithPreflight} />
        </TooltipProvider>,
      );

      fireEvent.click(screen.getByTestId("p46-generate-d1"));
      await waitFor(() => expect(outcomes).toHaveLength(1));
      await expect(outcomes[0]).resolves.toBe("resolved");
      expect(posts).toEqual([{ method: "post", action: "/api/download/form", fields: { ...p46Fields, attemptId: expect.stringMatching(UUID_V4) } }]);
      expect(document.querySelectorAll("form")).toHaveLength(0);

      mocks.generateResult = { ...previewGenerated, delivery: undefined };
      fireEvent.click(screen.getByTestId("p46-generate-d1"));
      await waitFor(() => expect(outcomes).toHaveLength(2));
      await expect(outcomes[1]).resolves.toBe("rejected");
      expect(posts).toHaveLength(1);
    } finally {
      submit.mockRestore();
    }
  });
});

describe("FormPreviewModal P11 official signature rules", () => {
  it("does not add a third rule when P11 supplies its two official signature lines", async () => {
    const { FormPreviewModal } = await import("./EstateDetail");
    const originalSections = mocks.previewSections;
    mocks.previewSections = [
      { type: "signature", text: "SWORN (OR AFFIRMED) BEFORE ME", suppressRule: true },
      { type: "paragraph", text: "________________________________" },
      { type: "paragraph", text: "Commissioner" },
      { type: "paragraph", text: "________________________________" },
    ];

    try {
      render(
        <FormPreviewModal
          estateId="e1"
          formCode="P11"
          formName="Non-Domiciled Estate Grant"
          signatoryType="executor"
          signatureDate="2026-07-12"
          open={true}
          onOpenChange={() => {}}
        />,
      );

      expect(screen.getAllByText("________________________________")).toHaveLength(2);
    } finally {
      mocks.previewSections = originalSections;
    }
  });

  it("preserves P11 merged rows and complete multiline text in modal, print, and PDF previews", async () => {
    const { FormPreviewModal } = await import("./EstateDetail");
    const originalSections = mocks.previewSections;
    const print = vi.fn();
    const printDocument = document.implementation.createHTMLDocument("");
    const fakeWindow = { document: printDocument, print, opener: window } as any;
    const open = vi.spyOn(window, "open").mockReturnValue(fakeWindow);
    const instruction = "List item details and then list secured debt details below those items. If the deceased only has a partial interest in the property, list the names of all registered owners, including the deceased, and specify the interest that each owner has in the property as a fraction expressed in numerals.";
    for (const method of ["addPage", "setFont", "setFontSize", "setDrawColor", "line", "rect", "splitTextToSize", "text", "save"] as const) {
      mocks.pdfDoc[method].mockClear();
    }
    mocks.pdfDoc.splitTextToSize.mockImplementation((text: string) => {
      if (text === instruction) return [
        "List item details and then list secured debt details below those items.",
        "If the deceased only has a partial interest in the property, list every owner.",
        "fraction expressed in numerals.",
      ];
      return [String(text)];
    });
    mocks.previewSections = [{
      type: "table",
      rows: [
        { cells: ["Part I\nReal Property within British Columbia", "Value at Death"], header: true, colSpans: [2, 1], cellAligns: ["left", "center"] },
        { cells: [instruction, ""], italic: true, colSpans: [2, 1], cellAligns: ["left", "center"] },
        { cells: ["Asset details\nLess: secured debt", "$10,000.00\n− $2,000.00", "$8,000.00"], cellAligns: ["left", "center", "center"] },
      ],
    }];

    try {
      render(
        <FormPreviewModal
          estateId="e1"
          formCode="P11"
          formName="Non-Domiciled Estate Grant"
          signatoryType="executor"
          signatureDate="2026-07-12"
          open={true}
          onOpenChange={() => {}}
        />,
      );

      const detailCell = screen.getByText((_, element) =>
        element?.tagName === "TD" && element.textContent === "Asset details\nLess: secured debt");
      expect(detailCell.className).toContain("whitespace-pre-line");
      const partCell = screen.getByText((_, element) =>
        element?.tagName === "TD" && element.textContent === "Part I\nReal Property within British Columbia") as HTMLTableCellElement;
      expect(partCell.colSpan).toBe(2);

      fireEvent.click(screen.getByRole("button", { name: "Print" }));
      expect(open).toHaveBeenCalled();
      const printHtml = printDocument.documentElement.outerHTML;
      expect(printHtml).toContain("white-space: pre-line");
      expect(printHtml).toContain('colspan="2"');
      expect(printHtml).toContain(instruction);
      expect(printHtml).toContain("Asset details\nLess: secured debt");

      fireEvent.click(screen.getByRole("button", { name: "PDF" }));
      await waitFor(() => expect(mocks.pdfDoc.save).toHaveBeenCalledTimes(1));
      expect(mocks.pdfDoc.splitTextToSize).toHaveBeenCalledWith(instruction, expect.any(Number));
      expect(mocks.pdfDoc.text).toHaveBeenCalledWith("fraction expressed in numerals.", expect.any(Number), expect.any(Number), { align: "left" });
      const instructionTailY = mocks.pdfDoc.text.mock.calls.find((call) => call[0] === "fraction expressed in numerals.")![2] as number;
      const assetY = mocks.pdfDoc.text.mock.calls.find((call) => call[0] === "Asset details")![2] as number;
      expect(assetY).toBeGreaterThan(instructionTailY);
      expect(mocks.pdfDoc.rect).toHaveBeenCalled();
    } finally {
      mocks.previewSections = originalSections;
      open.mockRestore();
    }
  });
});

describe("P11 inventory detail controls", () => {
  it("asks the official passage question for assets, starts unanswered, and records an explicit answer", async () => {
    const { InventoryFormFields } = await import("./EstateDetail");

    function Harness() {
      const [item, setItem] = React.useState<any>({
        id: "financial-1", category: "financial", description: "Account", location: "in_bc",
        value: "", passesToPersonalRepresentative: "",
      });
      return (
        <>
          <InventoryFormFields item={item} setItem={setItem} allItems={[]} />
          <output data-testid="passage-state">{JSON.stringify(item)}</output>
        </>
      );
    }

    render(<Harness />);
    expect(screen.getByText(/Does this property pass to the applicant in the applicant's capacity as the deceased's personal representative\?/)).toBeTruthy();
    const trigger = screen.getByTestId("inventory-passes-to-personal-representative");
    expect(trigger.textContent).toContain("Not yet recorded");
    Object.defineProperty(Element.prototype, "scrollIntoView", { value: () => {}, configurable: true });
    fireEvent.click(trigger);
    fireEvent.click(await screen.findByRole("option", { name: "No" }));
    expect(screen.getByTestId("passage-state").textContent).toContain('"passesToPersonalRepresentative":"no"');
  });

  it("captures real-property ownership and fractional-interest detail", async () => {
    const { InventoryFormFields } = await import("./EstateDetail");

    function Harness() {
      const [item, setItem] = React.useState<any>({
        id: "real-1", category: "real_property", description: "BC home", location: "in_bc", value: "", ownershipDetails: "",
      });
      return (
        <>
          <InventoryFormFields item={item} setItem={setItem} allItems={[]} />
          <output data-testid="inventory-state">{JSON.stringify(item)}</output>
        </>
      );
    }

    render(<Harness />);
    fireEvent.change(screen.getByTestId("inventory-ownership-details"), {
      target: { value: "Deceased 1/2; Co-owner 1/2" },
    });
    expect(screen.getByTestId("inventory-state").textContent).toContain("Deceased 1/2; Co-owner 1/2");
  });

  it("keeps a pending real-property FMV blank, then records it without using $0 as a placeholder", async () => {
    const { InventoryFormFields } = await import("./EstateDetail");

    function Harness() {
      const [item, setItem] = React.useState<any>({
        id: "real-1", category: "real_property", description: "BC home", location: "in_bc",
        value: "", assessedMarketValue: "", valueRecorded: 0, passesToPersonalRepresentative: "yes",
      });
      return (
        <>
          <InventoryFormFields item={item} setItem={setItem} allItems={[]} />
          <output data-testid="inventory-state">{JSON.stringify(item)}</output>
        </>
      );
    }

    render(<Harness />);
    const fmv = screen.getByTestId("inventory-real-property-fmv") as HTMLInputElement;
    expect(fmv.value).toBe("");
    expect(screen.getByTestId("inventory-real-property-fmv-guidance").textContent).toContain("Leave blank");

    fireEvent.change(fmv, { target: { value: "650000" } });
    expect(screen.getByTestId("inventory-state").textContent).toContain('"value":"650,000"');
    expect(screen.getByTestId("inventory-state").textContent).toContain('"assessedMarketValue":"650,000"');
    expect(screen.getByTestId("inventory-state").textContent).toContain('"valueRecorded":1');

    fireEvent.change(fmv, { target: { value: "" } });
    expect(screen.getByTestId("inventory-state").textContent).toContain('"value":""');
    expect(screen.getByTestId("inventory-state").textContent).toContain('"assessedMarketValue":""');
    expect(screen.getByTestId("inventory-state").textContent).toContain('"valueRecorded":0');
  });

  it("links a secured liability to either a B.C. or outside-B.C. asset and clears the link when unsecured", async () => {
    const { InventoryFormFields } = await import("./EstateDetail");
    const allItems = [
      { id: "bc-asset", category: "real_property", location: "in_bc", description: "BC home", passesToPersonalRepresentative: "yes" },
      { id: "foreign-asset", category: "real_property", location: "outside_bc", description: "Foreign home", passesToPersonalRepresentative: "yes" },
    ];

    function Harness() {
      const [item, setItem] = React.useState<any>({
        id: "debt-1", category: "liability", description: "Mortgage", location: "in_bc", value: "", securityStatus: "unknown", securedAssetId: "",
      });
      return (
        <>
          <InventoryFormFields item={item} setItem={setItem} allItems={allItems} />
          <output data-testid="liability-state">{JSON.stringify(item)}</output>
        </>
      );
    }

    render(<Harness />);
    fireEvent.change(screen.getByTestId("inventory-security-status"), { target: { value: "secured" } });
    const linkedAsset = screen.getByTestId("inventory-secured-asset") as HTMLSelectElement;
    expect(Array.from(linkedAsset.options).map((o) => o.value)).toEqual(["", "bc-asset", "foreign-asset"]);
    expect(Array.from(linkedAsset.options).map((o) => o.textContent)).toEqual([
      "Select an asset...",
      "BC home — In B.C.",
      "Foreign home — Outside B.C.",
    ]);
    fireEvent.change(linkedAsset, { target: { value: "foreign-asset" } });
    expect(screen.getByTestId("liability-state").textContent).toContain('"securedAssetId":"foreign-asset"');

    fireEvent.change(screen.getByTestId("inventory-security-status"), { target: { value: "unsecured" } });
    expect(screen.queryByTestId("inventory-secured-asset")).toBeNull();
    expect(screen.getByTestId("liability-state").textContent).toContain('"securedAssetId":""');
  });
});
