import { PageHeader } from "@/components/PageHeader";
import { Seo } from "@/components/Seo";
import { PortalAccessSection } from "@/pages/Settings";
import { motion, useReducedMotion } from "framer-motion";
import React from "react";

export default function ExecutorPortal() {
  const reduceMotion = useReducedMotion();
  return (
    <motion.main
      data-testid="executor-portal-route"
      className="space-y-6"
      initial={reduceMotion ? false : { opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={reduceMotion ? { duration: 0 } : { duration: 0.24, ease: [0.23, 1, 0.32, 1] }}
    >
      <Seo
        title="Executor Portal | ProbatePro"
        description="Private client-intake link and lawyer review management."
        path="/executor-portal"
        index={false}
      />
      <PageHeader
        title="Executor Portal"
        description="Issue secure client-intake links and review submitted facts before applying selected details to an estate file."
      />
      <motion.div
        className="space-y-6"
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.3, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] }}
      >
        <PortalAccessSection />
      </motion.div>
    </motion.main>
  );
}
