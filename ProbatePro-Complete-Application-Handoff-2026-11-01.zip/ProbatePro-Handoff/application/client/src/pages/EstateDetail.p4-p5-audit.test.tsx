import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { P5TestamentaryDocumentFields, WESA_S130_PRIORITY_OPTIONS, WESA_S80_OPTIONS } from "./EstateDetail";

describe("P4/P5 recovered-audit intake controls", () => {
  it("uses the exact WESA s.130(e), (e.1), and (f) legal-choice labels", () => {
    const labels = new Map(WESA_S130_PRIORITY_OPTIONS.map((option) => [option.value, option.label]));
    expect(labels.get("e")).toBe("(e) an intestate successor other than the spouse or child of the deceased person, having the consent of the intestate successors representing a majority in interest of the estate, including the intestate successor who applies for a grant of administration");
    expect(labels.get("e.1")).toBe("(e.1) a person, other than the spouse or child of the deceased person, nominated by an intestate successor of the deceased person if that person has the consent of the intestate successors representing a majority in interest of the estate, including the intestate successor who nominated the person to apply for a grant of administration");
    expect(labels.get("f")).toBe("(f) an intestate successor other than the spouse or child of the deceased person, not having the consent of the intestate successors representing a majority in interest of the estate, including the intestate successor who applies for a grant of administration");
  });

  it("uses the verbatim WESA s.80(a)-(h) legal-choice labels", () => {
    expect(WESA_S80_OPTIONS.map((option) => option.label)).toEqual([
      "(a) with the law of the place where the will is made,",
      "(b) with the law of the will-maker's domicile, either at the date the will is made or at the date of the will-maker's death,",
      "(c) with the law of the will-maker's ordinary residence, either at the date the will is made or at the date of the will-maker's death,",
      "(d) with the law of a country of which the will-maker was a citizen, either at the date the will is made or at the date of the will-maker's death,",
      "(e) with the law of British Columbia, but the will is made outside British Columbia,",
      "(f) with the law of the place where the will-maker's property is situated at the date the will is made or at the date of the will-maker's death,",
      "(g) in the case of a will made on board a vessel or aircraft of any description, with the law of the place with which, having regard to the registration, if any, of a vessel or aircraft, the vessel or aircraft is most closely connected, or",
      "(h) to the extent that the will exercises a power of appointment, with the law governing the essential validity of that power.",
    ]);
  });

  it("exposes the no-will P5 §4 choices and persists status/reasons through the estate-field callback", () => {
    const onChange = vi.fn();
    const { rerender } = render(
      <P5TestamentaryDocumentFields status="" description="" onChange={onChange} />,
    );

    fireEvent.click(screen.getByText("One or more testamentary documents have been found."));
    expect(onChange).toHaveBeenCalledWith({ testamentaryDocStatus: "found" });

    rerender(<P5TestamentaryDocumentFields status="found" description="" onChange={onChange} />);
    fireEvent.change(screen.getByPlaceholderText("Briefly state the reasons."), { target: { value: "Unsigned draft." } });
    expect(onChange).toHaveBeenCalledWith({ laterTestamentaryDescription: "Unsigned draft." });
  });
});
