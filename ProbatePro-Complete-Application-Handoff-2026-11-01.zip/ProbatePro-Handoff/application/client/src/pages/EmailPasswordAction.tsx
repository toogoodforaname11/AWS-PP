import { KeyRound, Loader2, Scale, ShieldCheck } from "lucide-react";
import React, { useEffect, useState } from "react";
import { useLocation } from "wouter";

type Action = "verify" | "reset";

function getToken() {
  return new URLSearchParams(window.location.search).get("token") || "";
}

export default function EmailPasswordAction({ action }: { action: Action }) {
  const [, setLocation] = useLocation();
  const [token] = useState(getToken);
  const [password, setPassword] = useState("");
  const [state, setState] = useState<"working" | "ready" | "success" | "error">(action === "verify" ? "working" : "ready");
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (action !== "verify") return;
    if (!token) { setState("error"); setMessage("This verification link is invalid or has expired."); return; }
    let cancelled = false;
    void fetch("/api/auth/verify-email", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "same-origin", body: JSON.stringify({ token }) })
      .then(async (response) => ({ ok: response.ok, body: await response.json().catch(() => ({})) }))
      .then(({ ok, body }) => {
        if (cancelled) return;
        if (!ok) { setState("error"); setMessage(typeof body.error === "string" ? body.error : "This verification link is invalid or has expired."); return; }
        setState("success");
        setMessage("Your email is verified. Taking you to your workspace…");
        window.setTimeout(() => setLocation("/", { replace: true }), 550);
      })
      .catch(() => { if (!cancelled) { setState("error"); setMessage("We could not verify this link. Please try again later."); } });
    return () => { cancelled = true; };
  }, [action, setLocation, token]);

  const resetPassword = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!token) { setState("error"); setMessage("This reset link is invalid or has expired."); return; }
    setState("working"); setMessage("");
    try {
      const response = await fetch("/api/auth/reset-password", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "same-origin", body: JSON.stringify({ token, password }) });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) { setState("ready"); setMessage(typeof body.error === "string" ? body.error : "This reset link is invalid or has expired."); return; }
      setState("success"); setMessage("Your password is updated. Taking you to your workspace…");
      window.setTimeout(() => setLocation("/", { replace: true }), 550);
    } catch {
      setState("ready"); setMessage("We could not update your password. Please try again later.");
    }
  };

  const isError = state === "error" || (action === "reset" && Boolean(message) && state === "ready");
  return (
    <main className="grid min-h-dvh place-items-center bg-[radial-gradient(circle_at_50%_0%,#f4f8fc,white_52%)] px-5 py-10 text-[#18293e]">
      <section className="w-full max-w-md rounded-2xl border border-[#1e3a5f]/15 bg-white p-6 shadow-[0_28px_70px_-46px_rgba(30,58,95,0.76),inset_0_1px_0_rgba(255,255,255,0.9)] sm:p-8">
        <div className="flex items-center gap-2 text-[#1e3a5f]"><span className="grid size-9 place-items-center rounded-xl border border-[#1e3a5f]/15 bg-[#1e3a5f]/[0.06]"><Scale className="size-5" aria-hidden="true" /></span><span className="font-semibold">ProbatePro</span></div>
        <div className="mt-7"><span className="grid size-10 place-items-center rounded-xl border border-[#1e3a5f]/15 bg-[#f7faff] text-[#1e3a5f]">{action === "verify" ? <ShieldCheck className="size-5" aria-hidden="true" /> : <KeyRound className="size-5" aria-hidden="true" />}</span>
          <h1 className="mt-4 text-2xl font-semibold tracking-[-0.03em]">{action === "verify" ? "Verify your email" : "Choose a new password"}</h1>
          <p className="mt-2 text-sm leading-6 text-[#657286]">{action === "verify" ? "Confirming your ProbatePro email address." : "Use 14+ characters with upper- and lower-case letters, a number, and a symbol."}</p>
        </div>
        {action === "reset" ? <form className="mt-6 space-y-4" onSubmit={resetPassword} noValidate><label className="block text-sm font-semibold">New password<input type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="new-password" required placeholder="At least 14 characters" className="mt-1.5 h-11 w-full rounded-lg border border-[#1e3a5f]/18 px-3 text-sm outline-none focus:border-[#1e3a5f] focus:ring-2 focus:ring-[#1e3a5f]/15" /></label><button type="submit" disabled={state === "working"} className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-[#1e3a5f] text-sm font-semibold text-white shadow-[0_3px_0_rgba(15,42,70,0.38)] transition-transform hover:-translate-y-px active:translate-y-px disabled:cursor-wait disabled:opacity-70 motion-reduce:transform-none">{state === "working" ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : null}{state === "working" ? "Updating…" : "Update password"}</button></form> : <div className="mt-6 flex min-h-11 items-center text-sm text-[#526171]">{state === "working" ? <><Loader2 className="mr-2 size-4 animate-spin text-[#1e3a5f]" aria-hidden="true" />Checking your link…</> : null}</div>}
        {message ? <p role={isError ? "alert" : "status"} className={`mt-4 rounded-lg border px-3 py-2.5 text-sm leading-5 ${isError ? "border-[#d9a8af] bg-[#fff8f8] text-[#721521]" : "border-[#9ab9a9] bg-[#f5fbf7] text-[#1c5b37]"}`}>{message}</p> : null}
        {state === "error" ? <a href="/" className="mt-5 inline-flex text-sm font-semibold text-[#1e3a5f] hover:underline">Return to sign in</a> : null}
      </section>
    </main>
  );
}
