import { describe, expect, it } from "vitest";
import { showsMultiSpouseGuidance } from "./EstateDetail";

/**
 * WESA s.22 multi-spouse guidance — which files see it.
 *
 * s.22(1), capture verbatim: multiple spouses share the spousal portion "in the
 * portions to which they agree, or if they cannot agree, as determined by the
 * court". The Act supplies NO equal default (finding-2, 6a092b0), so until every
 * spouse's portion is recorded the spousal rows render blank on Form P10.
 *
 * The card that explains how to record them was gated on `isIntestacy`, which is
 * `admin_no_will` and nothing else. A partial-intestacy file HAS a will, so the
 * card was hidden on exactly the class that needs it — while the engine applied
 * the same s.22 logic to that file's intestate portion and blanked it.
 */
describe("s.22 multi-spouse guidance applies wherever the engine applies s.22", () => {
  it("shows on a plain intestacy with more than one spouse", () => {
    expect(showsMultiSpouseGuidance({ isIntestacy: true, isPartialIntestacy: false, spouseCount: 2, isSeparated: false })).toBe(true);
  });

  it("shows on a PARTIAL intestacy — the case it was hidden on", () => {
    // A s.25 file has a will, so isIntestacy is false. Its intestate portion
    // still runs the s.22 spousal-share rule.
    expect(showsMultiSpouseGuidance({ isIntestacy: false, isPartialIntestacy: true, spouseCount: 2, isSeparated: false })).toBe(true);
  });

  it("stays hidden where s.22 cannot apply", () => {
    // Fully testate: no intestate portion, so no spousal share to divide.
    expect(showsMultiSpouseGuidance({ isIntestacy: false, isPartialIntestacy: false, spouseCount: 2, isSeparated: false })).toBe(false);
    // One spouse: s.22 governs the split BETWEEN spouses and needs at least two.
    expect(showsMultiSpouseGuidance({ isIntestacy: true, isPartialIntestacy: false, spouseCount: 1, isSeparated: false })).toBe(false);
    expect(showsMultiSpouseGuidance({ isIntestacy: false, isPartialIntestacy: true, spouseCount: 1, isSeparated: false })).toBe(false);
    expect(showsMultiSpouseGuidance({ isIntestacy: true, isPartialIntestacy: false, spouseCount: 0, isSeparated: false })).toBe(false);
  });
});

describe("WESA s.2(2)(a) separation divests every spouse, so the card must not fire", () => {
  it("hides on a separated estate even with two spouse contacts", () => {
    // The engine's spouse set carries `!isSpouseSeparated(estate)`; the client's
    // isSpouseCandidate does not. Without this term the card asserted "this
    // estate has 2 spouses per WESA s.2" and sent the user to record basis
    // points — on a file the engine escheats whole to the Crown.
    expect(showsMultiSpouseGuidance({ isIntestacy: true, isPartialIntestacy: false, spouseCount: 2, isSeparated: true })).toBe(false);
    expect(showsMultiSpouseGuidance({ isIntestacy: false, isPartialIntestacy: true, spouseCount: 2, isSeparated: true })).toBe(false);
  });

  it("still shows when the estate is not separated", () => {
    expect(showsMultiSpouseGuidance({ isIntestacy: true, isPartialIntestacy: false, spouseCount: 2, isSeparated: false })).toBe(true);
  });
});
