import { describe, expect, it } from "vitest";
import { segmentDeadlineEvents } from "./Deadlines";

describe("segmentDeadlineEvents", () => {
  it("places urgent statutory work ahead of ordinary upcoming and reference dates", () => {
    const overdue = { id: "overdue", kind: "obligation", status: "overdue", daysRemaining: -2 };
    const upcoming = { id: "upcoming", kind: "limitation", status: "open", daysRemaining: 14 };
    const reference = { id: "reference", kind: "eligibility", status: "eligible" };

    expect(segmentDeadlineEvents([overdue, upcoming, reference])).toEqual({
      needsAttention: [overdue],
      upcoming: [upcoming],
      reference: [reference],
    });
  });
});
