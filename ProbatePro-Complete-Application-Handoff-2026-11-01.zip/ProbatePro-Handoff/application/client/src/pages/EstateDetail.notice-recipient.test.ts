import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";

const source = readFileSync(join(process.cwd(), "client/src/pages/EstateDetail.tsx"), "utf8");

describe("Rule 25-2 notice-recipient UI connection", () => {
  it("offers the court-ordered category with the exact governing paragraph", () => {
    expect(source).toContain(
      '<SelectItem value="court_ordered">Court-ordered recipient (Rule 25-2(2)(e))</SelectItem>',
    );
    expect(source).toContain("court orders to receive notice under Rule 25-2(14)(a)");
    expect(source).toContain("Saving this contact does not record delivery");
    expect(source).toContain("Forms → P9 delivery checklist");
    expect(source).not.toContain("<Label className=\"text-xs\">P1 Delivery Method</Label>");
    expect(source).not.toContain("<Label className=\"text-xs\">Delivery Date</Label>");
  });

  it("contact mutations invalidate every recipient-dependent query", () => {
    for (const invalidation of [
      "utils.delivery.getRecipients.invalidate({ estateId })",
      "utils.readiness.check.invalidate({ estateId })",
      "utils.document.preflight.invalidate()",
      "utils.document.preflightMany.invalidate()",
    ]) {
      expect(source).toContain(invalidation);
    }
  });

  it("lets a liability link an existing creditor or add one without inferring identity", () => {
    expect(source).toContain('data-testid="inventory-creditor-contact"');
    expect(source).toContain("Not yet linked to a creditor contact");
    expect(source).toContain("Add creditor");
    expect(source).toContain('role: "creditor"');
    expect(source).toContain('recipientType: "creditor"');
    expect(source).toContain("The Inventory description is not used as a recipient name.");
    expect(source).toContain("creditorContactId: newItem.category === \"liability\"");
  });

  it("invalidates recipient-dependent views after a creditor is created from inventory", () => {
    for (const invalidation of [
      "utils.contact.list.invalidate({ estateId })",
      "utils.delivery.getRecipients.invalidate({ estateId })",
      "utils.document.getLetterRecipients.invalidate({ estateId })",
    ]) {
      expect(source).toContain(invalidation);
    }
  });

  // 2026-08-06: was pinned to estateRecordsNoWill (hasWill === 0) alone. That
  // hid the creditor review on { hasWill: 1, grantType: "grant_of_admin" } — the
  // Rule 10 estate #17 shape — while Rule 25-2(2)(b)(ii) still entitled a
  // >$10,000 creditor to notice there, so the app required notice to a creditor
  // it never asked the user to identify. The control now shares the single
  // estateHasNoWillOfRecord predicate with the notice entitlement and the
  // readiness review. Changed deliberately.
  it("keys the creditor review control to the shared no-will-of-record predicate", () => {
    expect(source).toMatch(/estateHasNoWillOfRecord\(form\)\s*&&\s*\(/);
    expect(source).toContain('selectField("Creditor notice review (claims over $10,000)"');
    expect(source.match(/estateHasNoWillOfRecord\(form\)/g)).toHaveLength(1);
    // The narrower predicate must not creep back into this control.
    expect(source).not.toContain("estateRecordsNoWill(form)");
  });
});
