import { motion, AnimatePresence } from "framer-motion";
import { getLoginUrlAsync } from "@/const";
import { Seo } from "@/components/Seo";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Scale, FileText, Clock, Users, Shield, StickyNote, Download, CheckCircle2, AlertTriangle, XCircle, KeyRound, Loader2, Play, ChevronDown } from "lucide-react";
import React, { useState, useEffect, useCallback, useRef } from "react";
import { FORM_CATALOG } from "@shared/types";

const NAVY = "#1e3a5f";
const NAVY_HOVER = "#163050";
const NAVY_LIGHT = "#2a4d72";
const LANDING_TITLE = "BC Probate Software for Lawyers & Executors | ProbatePro";
const LANDING_DESCRIPTION = "ProbatePro helps BC lawyers and personal executors organize probate files, prepare court forms, track deadlines, and manage estate contacts.";
const WALKTHROUGH_VIDEO_SRC = "/media/probatepro-walkthrough.mp4";
const WALKTHROUGH_DOWNLOAD_SRC = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663647848961/YdpWSznnyuuGwRFI.mp4";
const WALKTHROUGH_POSTER_SRC = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663647848961/TbwxSmxxANQPXVEI.jpg";

const LANDING_CORE_FORM_CODES = ["P1", "P2", "P9", "VSA532", "LETTER"] as const;
const LANDING_CORE_FORM_CODE_SET = new Set<string>(LANDING_CORE_FORM_CODES);

// The public form section is deliberately derived from the application catalogue.
// It must never become a second, incomplete inventory of forms that ProbatePro supports.
const LANDING_CORE_FORMS = FORM_CATALOG.filter((form) => LANDING_CORE_FORM_CODE_SET.has(form.code));
const LANDING_CONDITIONAL_FORMS = FORM_CATALOG.filter((form) => !LANDING_CORE_FORM_CODE_SET.has(form.code));

const LANDING_FORM_CONDITIONS: Record<string, string> = {
  CONSENT_NOMINATION: "Beneficiary nomination, prepared on demand",
  CONSENT_APPOINT_ADMINISTRATOR: "No-will estate; beneficiary consent, prepared on demand",
  P3: "Standard will-based application",
  P4: "Will issue, alteration, or attestation concern",
  P5: "Administration without a will",
  P6: "Ancillary grant with a will",
  P7: "Ancillary administration without a will",
  P8: "More than one applying applicant",
  P10: "Domiciled estate assets and liabilities",
  P11: "Eligible non-domiciled estate",
  P12: "Non-English document requires a translation affidavit",
  P13: "Public Guardian and Trustee is the applicant",
  P14: "Supplement to a filed Form P10",
  P15: "Supplement to a filed Form P11",
  P26: "Supplement to a filed resealing assets affidavit",
  PGT_INFO: "Minor or incapable notice recipient",
  P16: "Will has an alteration, erasure, or obliteration",
  P17: "Named executor renounces",
  P34: "Eligible citation record for deemed renunciation",
  P44: "Application is withdrawn before a grant is issued",
  P45: "Electronic will circumstances require it",
  P46: "Electronic-will demand by a notice recipient",
  P19: "Court-issued grant tracked in the estate file",
};

function landingFormCode(code: string) {
  if (code === "VSA532") return "VSA 532";
  if (code === "LETTER") return "Letter";
  if (code === "PGT_INFO") return "PGT information";
  return code;
}

const LANDING_FAQS = [
  {
    question: "Who is ProbatePro designed for?",
    answer: "ProbatePro is designed for British Columbia lawyers and personal executors who need a structured place to prepare and manage probate files. Lawyer and personal-executor accounts use workflows tailored to their role.",
  },
  {
    question: "How does the workflow move from intake to documents?",
    answer: "Start with the estate record, contacts, inventory, and supporting documents. ProbatePro uses that information to show supported forms and document options, while readiness checks identify information that still needs attention before filing.",
  },
  {
    question: "What can I configure in Settings?",
    answer: "Settings includes account-purpose preferences, letter templates and closing blocks, uploaded letterhead, form-focused intake, document checkbox appearance, assistant preferences, and sign-in controls. Letter settings are available to both lawyers and personal executors.",
  },
  {
    question: "What is the Executor Portal?",
    answer: "The Executor Portal gives a lawyer a secure estate-specific link to send to a client. The client completes a guided intake questionnaire, and submitted answers stay separate until the lawyer selects and approves the individual facts to apply to the estate record.",
  },
  {
    question: "Does ProbatePro provide legal advice?",
    answer: "No. ProbatePro is a document-preparation and workflow tool, not a provider of legal advice or representation. The user remains responsible for the accuracy of entered information and for appropriate professional review before any court filing.",
  },
] as const;

const LANDING_STRUCTURED_DATA = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "SoftwareApplication",
      "@id": "https://probate-pro.com/#software",
      name: "ProbatePro",
      url: "https://probate-pro.com/",
      applicationCategory: "BusinessApplication",
      operatingSystem: "Web",
      description: LANDING_DESCRIPTION,
      audience: [
        { "@type": "Audience", audienceType: "British Columbia lawyers" },
        { "@type": "Audience", audienceType: "British Columbia personal executors" },
      ],
    },
    {
      "@type": "Organization",
      "@id": "https://probate-pro.com/#organization",
      name: "Kairo",
      url: "https://probate-pro.com/",
      brand: { "@type": "Brand", name: "ProbatePro" },
    },
    {
      "@type": "FAQPage",
      mainEntity: LANDING_FAQS.map(({ question, answer }) => ({
        "@type": "Question",
        name: question,
        acceptedAnswer: { "@type": "Answer", text: answer },
      })),
    },
  ],
};

export default function Landing() {
  const [signingIn, setSigningIn] = useState(false);
  const [signInError, setSignInError] = useState<string | null>(null);
  const [showAccountRecovery, setShowAccountRecovery] = useState(false);
  const [showConditionalForms, setShowConditionalForms] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const authError = params.get("authError");
    if (authError !== "oauth_expired" && authError !== "oauth_unavailable") return;

    setSignInError(authError === "oauth_unavailable"
      ? "The secure account service could not finish sign-in. Please try again."
      : "Your sign-in session expired or was interrupted. Please try again.");
    params.delete("authError");
    const query = params.toString();
    window.history.replaceState(window.history.state, "", `${window.location.pathname}${query ? `?${query}` : ""}${window.location.hash}`);
  }, []);

  const handleSignIn = async () => {
    if (signingIn) return;
    setSigningIn(true);
    setSignInError(null);
    try {
      const url = await getLoginUrlAsync();
      window.location.href = url;
    } catch {
      setSigningIn(false);
      setSignInError("We couldn’t start sign-in. Please check your connection and try again.");
    }
  };

  return (
    <div className="min-h-dvh bg-white text-[#1d1d1f] overflow-x-hidden antialiased">
      <Seo
        title={LANDING_TITLE}
        description={LANDING_DESCRIPTION}
        path="/"
        index
        structuredData={LANDING_STRUCTURED_DATA}
      />
      {/* ─── Navigation ─────────────────────────────────────────── */}
      <nav className="fixed top-0 inset-x-0 z-50 bg-white/80 backdrop-blur-md border-b border-[#f0f0f0]">
        <div className="max-w-[1200px] mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Scale className="h-[18px] w-[18px] text-[#1e3a5f]" strokeWidth={2.2} />
            <span className="font-semibold text-[15px] tracking-[-0.02em] text-[#1d1d1f]">
              ProbatePro
            </span>
          </div>
          <button
            onClick={handleSignIn}
            disabled={signingIn}
            aria-busy={signingIn}
            className="inline-flex h-11 items-center gap-1.5 px-4 text-[13px] font-medium text-white rounded-md transition-all duration-150 active:scale-[0.97] disabled:cursor-wait disabled:opacity-70 sm:h-8"
            style={{ backgroundColor: NAVY }}
            onMouseEnter={e => (e.currentTarget.style.backgroundColor = NAVY_HOVER)}
            onMouseLeave={e => (e.currentTarget.style.backgroundColor = NAVY)}
          >
            {signingIn && <Loader2 aria-hidden="true" className="h-3.5 w-3.5 animate-spin" />}
            {signingIn ? "Opening secure sign-in…" : "Sign in"}
          </button>
        </div>
      </nav>

      {/* ─── Hero ───────────────────────────────────────────────── */}
      <section className="pt-28 pb-14 sm:pt-[130px] sm:pb-20 px-6">
        <div className="max-w-[1200px] mx-auto">
          <div className="grid items-center gap-10 lg:grid-cols-[minmax(0,0.82fr)_minmax(0,1.18fr)] lg:gap-14">
            <motion.div
              className="max-w-[600px]"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
            >
              {signInError && (
                <div id="landing-sign-in-error" role="alert" className="relative z-[60] mb-5 w-full max-w-xl rounded-lg border border-[#d9a8af] bg-white px-4 py-3 text-sm leading-5 text-[#721521] shadow-lg sm:fixed sm:inset-x-6 sm:top-16 sm:mx-auto sm:mb-0">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <span className="min-w-0 flex-1">{signInError}</span>
                    <div className="flex w-full flex-wrap items-center justify-end gap-2 sm:w-auto sm:shrink-0">
                      <button type="button" aria-expanded={showAccountRecovery} aria-controls="landing-account-recovery" onClick={() => setShowAccountRecovery((open) => !open)} className="rounded-md border border-[#1e3a5f]/25 px-3 py-1.5 text-sm font-medium text-[#1e3a5f] transition-colors hover:bg-[#1e3a5f]/[0.06] active:scale-[0.97]">
                        Sign-in help
                      </button>
                      <button type="button" onClick={handleSignIn} disabled={signingIn} className="inline-flex items-center gap-2 rounded-md bg-[#1e3a5f] px-3 py-1.5 text-sm font-medium text-white transition-colors hover:bg-[#163050] active:scale-[0.97] disabled:cursor-wait disabled:opacity-70">
                        {signingIn && <Loader2 aria-hidden="true" className="h-4 w-4 animate-spin" />}
                        {signingIn ? "Opening…" : "Try again"}
                      </button>
                    </div>
                  </div>
                  {showAccountRecovery && (
                    <section id="landing-account-recovery" aria-label="Account recovery guidance" className="mt-3 rounded-md border border-[#1e3a5f]/15 bg-[#f8fbff] p-3 text-[#26384d]">
                      <div className="flex items-start gap-2">
                        <KeyRound aria-hidden="true" className="mt-0.5 h-4 w-4 shrink-0 text-[#1e3a5f]" />
                        <div className="min-w-0">
                          <h2 className="font-semibold text-[#1e3a5f]">Account recovery</h2>
                          <p className="mt-1 text-sm">ProbatePro uses your managed identity account. Choose <strong>Use another account</strong> on the secure sign-in screen, or use your identity provider’s password-recovery option if it asks for a password.</p>
                          <p className="mt-2 text-xs text-[#526171]">ProbatePro never stores passwords, so a reset is completed securely by your identity provider.</p>
                          <a href="https://help.manus.im" target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex text-sm font-medium text-[#1e3a5f] underline decoration-[#1e3a5f]/35 underline-offset-2 hover:decoration-[#1e3a5f]">Identity-provider account help</a>
                        </div>
                      </div>
                    </section>
                  )}
                </div>
              )}
              <p className="mb-4 text-[12px] font-semibold uppercase tracking-[0.12em] text-[#1e3a5f]/65">Organize the file. Prepare the record.</p>
              <h1 className="text-[32px] sm:text-[38px] md:text-[50px] font-semibold leading-[1.1] tracking-[-0.03em] text-[#1e3a5f]">
                BC probate software<br />
                {" "}for lawyers and personal executors.
              </h1>
              <p className="mt-5 text-[17px] text-[#4a4a4a] leading-[1.6] max-w-[460px]">
                Organize probate files, prepare supported court forms, track deadlines, and manage estate contacts from intake to grant.
              </p>
              <div className="mt-8 flex flex-wrap items-center gap-x-5 gap-y-4">
                <button
                  onClick={handleSignIn}
                  disabled={signingIn}
                  aria-busy={signingIn}
                  className="group inline-flex h-11 items-center gap-2.5 rounded-lg px-6 text-[14px] font-medium text-white transition-all duration-150 active:scale-[0.97] disabled:cursor-wait disabled:opacity-70"
                  style={{ backgroundColor: NAVY }}
                  onMouseEnter={e => (e.currentTarget.style.backgroundColor = NAVY_HOVER)}
                  onMouseLeave={e => (e.currentTarget.style.backgroundColor = NAVY)}
                >
                  {signingIn ? <><Loader2 aria-hidden="true" className="h-4 w-4 animate-spin" /> Opening secure sign-in…</> : <span>Get started</span>}
                </button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 28 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.12, ease: [0.23, 1, 0.32, 1] }}
            >
              <WalkthroughFrame />
            </motion.div>
          </div>
        </div>
      </section>

      {/* ─── Audience and product scope ─────────────────────────── */}
      <section className="py-16 sm:py-20 px-6 border-t border-[#eef0f2]" aria-labelledby="probate-workspace-heading">
        <div className="max-w-[1200px] mx-auto">
          <div className="max-w-[660px]">
            <p className="text-[12px] font-semibold uppercase tracking-[0.08em] text-[#1e3a5f]/65">Built around the file</p>
            <h2 id="probate-workspace-heading" className="mt-3 text-[26px] md:text-[30px] font-semibold tracking-[-0.02em] text-[#1e3a5f]">
              A practical probate workspace
            </h2>
            <p className="mt-4 text-[15px] leading-[1.65] text-[#4a4a4a]">
              ProbatePro keeps the operational record, document choices, and filing preparation together without replacing professional judgment. Each feature is organized around the information that belongs in an estate file.
            </p>
          </div>

          <div className="mt-10 grid gap-5 md:grid-cols-3">
            <AudienceCard
              title="For lawyers"
              description="Organize active files, set office and letter preferences, track document readiness, and prepare supported BC probate forms from one working record."
            />
            <AudienceCard
              title="For personal executors"
              description="Use the full-intake workflow to collect estate facts, track contacts and inventory, prepare beneficiary communications, and see what requires attention."
            />
            <AudienceCard
              title="For controlled collaboration"
              description="Send a secure estate-specific link so a client can complete the intake questions. Submitted answers stay separate until you select and approve details to apply to the estate."
            />
          </div>
        </div>
      </section>

      {/* ─── Capabilities ───────────────────────────────────────── */}
      <section className="py-16 sm:py-24 px-6 bg-[#f9fafb] border-t border-[#eef0f2]">
        <div className="max-w-[1200px] mx-auto">
          <motion.h2
            className="text-[26px] md:text-[30px] font-semibold tracking-[-0.02em] text-[#1e3a5f]"
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
          >
            Everything you need to file.
          </motion.h2>

          <div className="mt-14 grid md:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-12">
            <Capability
              icon={<FileText className="h-[18px] w-[18px]" />}
              title="Court-ready forms"
              description="Generates the supported BC Supreme Court probate forms from your estate data. Preview in-browser, download DOCX, or print directly."
              delay={0}
            />
            <Capability
              icon={<Clock className="h-[18px] w-[18px]" />}
              title="Deadlines & readiness"
              description="21-day notice periods, 210-day holdback advisories, and custom deadlines. The readiness panel shows exactly what's blocking a filing."
              delay={0.05}
            />
            <Capability
              icon={<StickyNote className="h-[18px] w-[18px]" />}
              title="Private notes"
              description="Per-estate note log with categories, file attachments, in-app preview, drag-and-drop, templates, and PDF export. Private to you."
              delay={0.1}
            />
            <Capability
              icon={<Users className="h-[18px] w-[18px]" />}
              title="Contacts & inventory"
              description="Track executors, beneficiaries, creditors with delivery methods. Property values flow into P10 schedules and fee calculations."
              delay={0.15}
            />
            <Capability
              icon={<Shield className="h-[18px] w-[18px]" />}
              title="Executor portal"
              description="Send a secure link for a client to complete a guided intake. Review selected answers before applying them to the estate record."
              delay={0.2}
            />
            <Capability
              icon={<Download className="h-[18px] w-[18px]" />}
              title="Grant package"
              description="One click generates a ZIP with all applicable forms, will, and codicils — ready to file at the registry."
              delay={0.25}
            />
          </div>
        </div>
      </section>

      {/* ─── Forms Section with Mockup ──────────────────────────── */}
      <section className="py-16 sm:py-24 px-6 border-t border-[#eef0f2]">
        <div className="max-w-[1200px] mx-auto">
          {/* min-w-0 on both children: grid items default to min-width:auto, so the
              mockup's min-content width (≈393px) would otherwise widen BOTH columns
              past a 375px viewport and get clipped by the page's overflow-x-hidden. */}
          <div className="grid lg:grid-cols-[1fr_1.3fr] gap-10 sm:gap-14 items-start">
            <motion.div
              className="min-w-0"
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
            >
              <h2 className="text-[26px] md:text-[30px] font-semibold tracking-[-0.02em] leading-[1.2] text-[#1e3a5f]">
                Every supported form,<br />when it applies.
              </h2>
              <p className="mt-4 text-[15px] text-[#4a4a4a] leading-[1.65]">
                Forms are populated from your estate data and follow Part 25 and Appendix A.1 of the BC Supreme Court Civil Rules. The system determines which forms apply based on your estate's circumstances.
              </p>

              {/* Application workflow forms */}
              <div className="mt-8">
                <h3 className="text-[13px] font-semibold uppercase tracking-[0.04em] text-[#1e3a5f]/70 mb-3">
                  Core application forms
                </h3>
                <div className="space-y-2">
                  {LANDING_CORE_FORMS.map((form) => (
                    <FormItem key={form.code} code={landingFormCode(form.code)} name={form.name} />
                  ))}
                </div>
              </div>

              {/* Conditional forms */}
              <div className="mt-7">
                <h3>
                  <button
                    type="button"
                    aria-expanded={showConditionalForms}
                    aria-controls="landing-conditional-forms"
                    onClick={() => setShowConditionalForms((open) => !open)}
                    className="group flex h-11 w-full items-center justify-between gap-3 rounded-lg border border-[#dce3ea] bg-[#fbfcfd] px-3 text-left text-[13px] font-semibold uppercase tracking-[0.04em] text-[#1e3a5f]/75 transition-[background-color,border-color,box-shadow] duration-150 hover:border-[#becbd8] hover:bg-white hover:shadow-[0_3px_10px_-8px_rgba(30,58,95,0.5)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1e3a5f] focus-visible:ring-offset-2"
                  >
                    <span>Conditional forms <span className="normal-case tracking-normal">(auto-determined)</span></span>
                    <span className="flex shrink-0 items-center gap-1.5 text-[12px] font-medium normal-case tracking-normal text-[#526171]">
                      {showConditionalForms ? "Hide" : `Show ${LANDING_CONDITIONAL_FORMS.length}`}
                      <ChevronDown aria-hidden="true" className={`h-4 w-4 transition-transform duration-150 ${showConditionalForms ? "rotate-180" : ""}`} />
                    </span>
                  </button>
                </h3>
                {showConditionalForms && (
                  <div id="landing-conditional-forms" role="region" aria-label="Conditional forms" className="mt-3 space-y-2 border-l border-[#dce3ea] pl-3 sm:pl-4">
                    {LANDING_CONDITIONAL_FORMS.map((form) => (
                      <FormItem
                        key={form.code}
                        code={landingFormCode(form.code)}
                        name={form.name}
                        condition={LANDING_FORM_CONDITIONS[form.code] || "Available when applicable"}
                      />
                    ))}
                  </div>
                )}
              </div>
            </motion.div>

            {/* Forms Mockup */}
            <motion.div
              className="min-w-0 lg:sticky lg:top-24"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.6, delay: 0.1, ease: [0.23, 1, 0.32, 1] }}
            >
              <FormsMockup />
            </motion.div>
          </div>
        </div>
      </section>

      {/* ─── Workflow Steps ──────────────────────────────────────── */}
      <section className="py-16 sm:py-24 px-6 bg-[#f9fafb] border-t border-[#eef0f2]">
        <div className="max-w-[1200px] mx-auto">
          <motion.h2
            className="text-[26px] md:text-[30px] font-semibold tracking-[-0.02em] text-[#1e3a5f]"
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
          >
            Intake to grant in three steps.
          </motion.h2>

          <div className="mt-14 grid md:grid-cols-3 gap-10">
            <Step
              number="01"
              title="Create the file"
              description="Enter deceased information, registry, and grant type. AI-assisted import can extract data from existing documents."
              delay={0}
            />
            <Step
              number="02"
              title="Build the record"
              description="Add contacts, inventory, upload the will and codicils. The readiness panel shows what's missing before you can file."
              delay={0.08}
            />
            <Step
              number="03"
              title="Generate & file"
              description="Produce the supported court forms with one click. Download individually or as a complete grant package ZIP."
              delay={0.16}
            />
          </div>
        </div>
      </section>

      {/* ─── Readiness & Notes Mockups ──────────────────────────── */}
      <section className="py-16 sm:py-24 px-6 border-t border-[#eef0f2]">
        <div className="max-w-[1200px] mx-auto">
          <motion.h2
            className="text-[26px] md:text-[30px] font-semibold tracking-[-0.02em] text-[#1e3a5f] mb-4"
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
          >
            Know what's ready. Keep track of everything.
          </motion.h2>
          <p className="text-[15px] text-[#4a4a4a] leading-[1.65] max-w-[520px] mb-14">
            The readiness panel shows exactly what's blocking a filing. Private notes keep your file memos, call logs, and reminders in one place.
          </p>

          <div className="grid md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
            >
              <ReadinessMockup />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.6, delay: 0.1, ease: [0.23, 1, 0.32, 1] }}
            >
              <NotesMockup />
            </motion.div>
          </div>
        </div>
      </section>

      {/* ─── Product answers ────────────────────────────────────── */}
      <section className="py-16 sm:py-24 px-6 bg-[#f9fafb] border-t border-[#eef0f2]" aria-labelledby="probatepro-faq-heading">
        <div className="max-w-[1200px] mx-auto">
          <div className="max-w-[680px]">
            <p className="text-[12px] font-semibold uppercase tracking-[0.08em] text-[#1e3a5f]/65">Before you sign in</p>
            <h2 id="probatepro-faq-heading" className="mt-3 text-[26px] md:text-[30px] font-semibold tracking-[-0.02em] text-[#1e3a5f]">
              Clear answers about the workspace
            </h2>
            <p className="mt-4 text-[15px] leading-[1.65] text-[#4a4a4a]">
              A concise overview of the product’s intended use, controls, and legal boundary.
            </p>
          </div>
          <Accordion type="single" collapsible className="landing-faq-accordion mt-10 grid gap-x-10 gap-y-3 md:grid-cols-2">
            {LANDING_FAQS.map((faq) => <PublicFaq key={faq.question} {...faq} />)}
          </Accordion>
        </div>
      </section>

      {/* ─── CTA ────────────────────────────────────────────────── */}
      <section className="py-14 sm:py-20 px-6 border-t border-[#eef0f2]">
        <div className="max-w-[1200px] mx-auto">
          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
          >
            <h2 className="text-[24px] md:text-[28px] font-semibold tracking-[-0.02em] text-[#1e3a5f]">
              Start managing your estate files.
            </h2>
            <p className="mt-3 text-[15px] text-[#4a4a4a]">
              Free to use. No credit card required.
            </p>
            <button
              onClick={handleSignIn}
              disabled={signingIn}
              aria-busy={signingIn}
              className="mt-7 group h-11 px-6 text-[14px] font-medium text-white rounded-lg transition-all duration-150 active:scale-[0.97] disabled:cursor-wait disabled:opacity-70 inline-flex items-center gap-2.5"
              style={{ backgroundColor: NAVY }}
              onMouseEnter={e => (e.currentTarget.style.backgroundColor = NAVY_HOVER)}
              onMouseLeave={e => (e.currentTarget.style.backgroundColor = NAVY)}
            >
              {signingIn ? <><Loader2 aria-hidden="true" className="h-4 w-4 animate-spin" /> Opening secure sign-in…</> : <span>Get started</span>}
            </button>
          </motion.div>
        </div>
      </section>

      {/* ─── Footer ─────────────────────────────────────────────── */}
      <footer className="py-6 px-6 border-t border-[#eef0f2]">
        {/* py-3 -my-3 on the links grows the tap area to ~40px without changing the
            footer's visual height. */}
        <div className="max-w-[1200px] mx-auto flex items-center justify-between gap-4 text-[12px] text-[#999]">
          <div className="flex items-center gap-1.5 min-w-0">
            <Scale className="h-3 w-3 shrink-0" />
            <span className="truncate">&copy; {new Date().getFullYear()} <a href="https://kairo.chat/" target="_blank" rel="noopener noreferrer" className="py-3 -my-3 hover:text-[#555] transition-colors">Kairo</a></span>
          </div>
          <div className="flex items-center gap-4 shrink-0">
            <a href="/terms" className="py-3 -my-3 hover:text-[#555] transition-colors">Terms</a>
            <a href="/privacy" className="py-3 -my-3 hover:text-[#555] transition-colors">Privacy</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

/* ─── Public content components ─────────────────────────────────── */

function AudienceCard({ title, description }: { title: string; description: string }) {
  return (
    <article className="rounded-xl border border-[#e4e8ed] bg-white p-6 shadow-[0_12px_30px_-24px_rgba(30,58,95,0.45)] transition-[border-color,box-shadow,transform] duration-200 hover:-translate-y-0.5 hover:border-[#cbd6e0] hover:shadow-[0_16px_34px_-24px_rgba(30,58,95,0.5)]">
      <h3 className="text-[16px] font-semibold tracking-[-0.01em] text-[#1e3a5f]">{title}</h3>
      <p className="mt-3 text-[14px] leading-[1.65] text-[#4a4a4a]">{description}</p>
    </article>
  );
}

function PublicFaq({ question, answer }: { question: string; answer: string }) {
  return (
    <AccordionItem value={question} className="landing-faq-item">
      <AccordionTrigger className="landing-faq-trigger hover:no-underline">
        {question}
      </AccordionTrigger>
      <AccordionContent className="landing-faq-content faq-accordion-content">
        <div className="landing-faq-answer"><p>{answer}</p></div>
      </AccordionContent>
    </AccordionItem>
  );
}

function WalkthroughFrame() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const startPlayback = () => {
    void videoRef.current?.play().catch(() => undefined);
  };

  return (
    <section id="walkthrough" aria-labelledby="walkthrough-heading" className="landing-walkthrough-stage">
      <h2 id="walkthrough-heading" className="landing-walkthrough-title">Product Demo Walkthrough</h2>
      <div className="landing-walkthrough-media">
        <video
          ref={videoRef}
          aria-label="ProbatePro product walkthrough"
          className="landing-walkthrough-video"
          controls
          onEnded={() => setIsPlaying(false)}
          onPause={() => setIsPlaying(false)}
          onPlay={() => setIsPlaying(true)}
          playsInline
          preload="metadata"
          poster={WALKTHROUGH_POSTER_SRC}
          src={WALKTHROUGH_VIDEO_SRC}
        >
          Your browser does not support video playback. <a href={WALKTHROUGH_DOWNLOAD_SRC}>Download the walkthrough</a>.
        </video>
        <div
          aria-hidden={isPlaying || undefined}
          className="landing-walkthrough-play-overlay"
          data-playing={isPlaying}
          data-testid="walkthrough-play-overlay"
        >
          <button
            aria-label="Play product demo walkthrough"
            className="landing-walkthrough-play-button"
            onClick={startPlayback}
            tabIndex={isPlaying ? -1 : 0}
            type="button"
          >
            <Play aria-hidden="true" className="h-5 w-5 fill-current" />
          </button>
        </div>
      </div>
    </section>
  );
}

/* ─── Tooltip Component ─────────────────────────────────────────── */

function Tooltip({ text, children }: { text: string; children: React.ReactNode }) {
  const [show, setShow] = useState(false);
  return (
    <span
      className="relative inline-flex"
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}
    >
      {children}
      <AnimatePresence>
        {show && (
          <motion.span
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 4 }}
            transition={{ duration: 0.15 }}
            className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2.5 py-1.5 text-[11px] text-white bg-[#1d1d1f] rounded-md whitespace-nowrap z-50 pointer-events-none shadow-lg"
          >
            {text}
            <span className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-l-[4px] border-r-[4px] border-t-[4px] border-l-transparent border-r-transparent border-t-[#1d1d1f]" />
          </motion.span>
        )}
      </AnimatePresence>
    </span>
  );
}

/* ─── Carousel Component ────────────────────────────────────────── */

function MockupCarousel() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const views = ["Dashboard", "Forms", "Readiness", "Notes"];

  const advance = useCallback(() => {
    setActiveIndex(i => (i + 1) % views.length);
  }, [views.length]);

  useEffect(() => {
    if (paused) return;
    const timer = setInterval(advance, 5000);
    return () => clearInterval(timer);
  }, [advance, paused]);

  return (
    <div
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {/* Tab indicators — four tabs exceed a 320px viewport, so the row scrolls
          horizontally on the smallest phones instead of being clipped. */}
      <div className="flex items-center gap-2 mb-4 overflow-x-auto -mx-1 px-1">
        {views.map((label, i) => (
          <button
            key={label}
            onClick={() => setActiveIndex(i)}
            aria-pressed={i === activeIndex}
            className={`shrink-0 h-11 sm:h-7 px-3 text-[12px] font-medium rounded-md transition-all duration-200 ${
              i === activeIndex
                ? "bg-[#1e3a5f] text-white"
                : "bg-[#f0f0f0] text-[#666] hover:bg-[#e4e4e4]"
            }`}
          >
            {label}
          </button>
        ))}
        {/* Progress bar — dropped on phones so the four tabs keep their full width */}
        <div className="ml-auto hidden sm:flex items-center gap-1.5">
          {views.map((_, i) => (
            <div key={i} className="w-6 h-1 rounded-full bg-[#e4e4e4] overflow-hidden">
              {i === activeIndex && (
                <motion.div
                  className="h-full bg-[#1e3a5f] rounded-full"
                  initial={{ width: "0%" }}
                  animate={{ width: paused ? undefined : "100%" }}
                  transition={{ duration: 5, ease: "linear" }}
                  key={`progress-${activeIndex}-${paused}`}
                  style={paused ? { animationPlayState: "paused" } : undefined}
                />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Carousel content */}
      <div className="relative overflow-hidden rounded-xl border border-[#e4e4e4] shadow-[0_4px_40px_-8px_rgba(30,58,95,0.08)] bg-white">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeIndex}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
          >
            {activeIndex === 0 && <DashboardMockupContent />}
            {activeIndex === 1 && <FormsMockupContent />}
            {activeIndex === 2 && <ReadinessMockupContent />}
            {activeIndex === 3 && <NotesMockupContent />}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

/* ─── HTML Mockup Components ─────────────────────────────────────── */

function BrowserFrame({ title, children }: { title?: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-[#e4e4e4] shadow-[0_4px_40px_-8px_rgba(30,58,95,0.08)] overflow-hidden bg-white">
      <div className="flex items-center gap-1.5 px-4 py-3 border-b border-[#f0f0f0] bg-[#fafafa]">
        <div className="w-[10px] h-[10px] rounded-full bg-[#e0e0e0]" />
        <div className="w-[10px] h-[10px] rounded-full bg-[#e0e0e0]" />
        <div className="w-[10px] h-[10px] rounded-full bg-[#e0e0e0]" />
        {title && <span className="ml-3 text-[11px] text-[#999] font-medium">{title}</span>}
      </div>
      <div className="p-0">{children}</div>
    </div>
  );
}

function DashboardMockupContent() {
  const estates = [
    { num: 1, name: "Thompson Estate", deceased: "Margaret A. Thompson", city: "Vancouver", date: "2026-03-15", status: "Ready to File", statusColor: "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/30 dark:text-blue-300 dark:border-blue-800", progress: 100 },
    { num: 2, name: "Chen Estate", deceased: "David W. Chen", city: "Victoria", date: "2026-02-28", status: "Incomplete", statusColor: "bg-slate-50 text-slate-700 border-slate-300 dark:bg-slate-900/70 dark:text-slate-100 dark:border-slate-700", progress: 60 },
    { num: 3, name: "Patel Estate", deceased: "Anita R. Patel", city: "New Westminster", date: "2026-04-02", status: "Filed", statusColor: "bg-purple-50 text-purple-700 border-purple-200", progress: 100 },
    { num: 4, name: "O'Brien Estate", deceased: "James P. O'Brien", city: "Kelowna", date: "2026-01-20", status: "Granted", statusColor: "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-300 dark:border-emerald-800", progress: 100 },
    { num: 5, name: "Williams Estate", deceased: "Susan M. Williams", city: "Vancouver", date: "2026-05-10", status: "Intake", statusColor: "bg-sky-50 text-sky-700 border-sky-200", progress: 20 },
  ];

  return (
    <div className="flex min-h-[420px]">
      {/* Sidebar */}
      <div className="w-[200px] border-r border-[#f0f0f0] bg-[#fafafa] p-4 hidden md:block">
        <div className="flex items-center gap-2 mb-6">
          <Scale className="h-4 w-4 text-[#1e3a5f]" />
          <span className="text-[13px] font-semibold text-[#1d1d1f]">ProbatePro</span>
        </div>
        <div className="space-y-1">
          <div className="flex items-center gap-2 px-3 py-2 rounded-md bg-[#1e3a5f]/[0.06] text-[#1e3a5f]">
            <FileText className="h-3.5 w-3.5" />
            <span className="text-[13px] font-medium">Estate Files</span>
          </div>
          <div className="flex items-center gap-2 px-3 py-2 rounded-md text-[#666] hover:bg-[#f0f0f0] transition-colors cursor-pointer">
            <Clock className="h-3.5 w-3.5" />
            <span className="text-[13px]">Deadlines</span>
            <span className="ml-auto text-[10px] bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-300 px-1.5 py-0.5 rounded-full font-medium">3</span>
          </div>
          <div className="flex items-center gap-2 px-3 py-2 rounded-md text-[#666] hover:bg-[#f0f0f0] transition-colors cursor-pointer">
            <Shield className="h-3.5 w-3.5" />
            <span className="text-[13px]">Settings</span>
          </div>
        </div>
      </div>

      {/* Main content — min-w-0 lets this flex item shrink below its content's
          min-content width; index.css's global .flex{min-width:0} only covers
          flex *containers*, not items like this one. */}
      <div className="flex-1 min-w-0 p-4 sm:p-5">
        <div className="flex items-center justify-between gap-3 mb-5">
          <div className="min-w-0">
            <h2 className="text-[16px] font-semibold text-[#1d1d1f]">Estate Files</h2>
            <p className="text-[12px] text-[#888] truncate">Manage BC Supreme Court probate applications</p>
          </div>
          <Tooltip text="Create a new estate file">
            <div className="shrink-0 h-8 px-3 text-[12px] font-medium text-white rounded-md flex items-center gap-1.5 whitespace-nowrap cursor-pointer hover:opacity-90 transition-opacity active:scale-[0.97]" style={{ backgroundColor: NAVY }}>
              <span className="text-[14px]">+</span> New Estate
            </div>
          </Tooltip>
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
          <Tooltip text="Total estate files in your account">
            <div className="p-3 rounded-lg border border-[#eee] bg-[#fafafa] hover:border-[#d0d0d0] hover:shadow-sm transition-all cursor-default w-full">
              <div className="text-[18px] font-semibold text-[#1d1d1f]">5</div>
              <div className="text-[11px] text-[#888] uppercase tracking-wide">Total Files</div>
            </div>
          </Tooltip>
          <Tooltip text="Estates with all readiness checks passed">
            <div className="p-3 rounded-lg border border-[#eee] bg-blue-50/50 hover:border-blue-300 hover:shadow-sm transition-all cursor-default w-full">
              <div className="text-[18px] font-semibold text-blue-700 dark:text-blue-300">1</div>
              <div className="text-[11px] text-[#888] uppercase tracking-wide">Ready to File</div>
            </div>
          </Tooltip>
          <Tooltip text="Deadlines due within the next 7 days">
            <div className="p-3 rounded-lg border border-[#eee] bg-amber-50/50 hover:border-amber-300 hover:shadow-sm transition-all cursor-default w-full">
              <div className="text-[18px] font-semibold text-amber-700 dark:text-amber-300">2</div>
              <div className="text-[11px] text-[#888] uppercase tracking-wide">Deadlines (7d)</div>
            </div>
          </Tooltip>
          <Tooltip text="Estates currently in progress">
            <div className="p-3 rounded-lg border border-[#eee] bg-purple-50/50 hover:border-purple-300 hover:shadow-sm transition-all cursor-default w-full">
              <div className="text-[18px] font-semibold text-purple-700">3</div>
              <div className="text-[11px] text-[#888] uppercase tracking-wide">Active Files</div>
            </div>
          </Tooltip>
        </div>

        {/* Estate list */}
        <div className="space-y-2.5">
          {estates.map((e) => (
            <div key={e.num} className="group flex items-center gap-2.5 sm:gap-4 p-3 rounded-lg border border-[#eee] hover:border-[#c0c8d0] hover:bg-[#fafcff] hover:shadow-sm transition-all duration-150 cursor-pointer">
              <span className="shrink-0 text-[12px] font-mono text-[#aaa] w-5">#{e.num}</span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-[13px] font-medium text-[#1d1d1f] truncate group-hover:text-[#1e3a5f] transition-colors">{e.name} - {e.deceased}</span>
                </div>
                <span className="text-[11px] text-[#888]">{e.city} · d. {e.date}</span>
              </div>
              <Tooltip text={`Status: ${e.status}`}>
                <span className={`shrink-0 whitespace-nowrap text-[11px] font-medium px-2 py-1 rounded border ${e.statusColor}`}>
                  {e.status}
                </span>
              </Tooltip>
              <Tooltip text={`Filing progress: ${e.progress}% complete`}>
                <div className="w-16 hidden sm:block">
                  <div className="h-1.5 rounded-full bg-[#eee] overflow-hidden">
                    <div className="h-full rounded-full bg-[#1e3a5f]/60 transition-all duration-300" style={{ width: `${e.progress}%` }} />
                  </div>
                  <span className="text-[10px] text-[#aaa]">{e.progress}%</span>
                </div>
              </Tooltip>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function DashboardMockup() {
  return (
    <BrowserFrame>
      <DashboardMockupContent />
    </BrowserFrame>
  );
}

function FormsMockupContent() {
  const forms = [
    { code: "P1", name: "Notice of Proposed Application", status: "ready" },
    { code: "P2", name: "Submission for Estate Grant", status: "ready" },
    { code: "P3", name: "Affidavit of Applicant", status: "ready" },
    { code: "P9", name: "Affidavit of Delivery", status: "pending" },
    { code: "P10", name: "Assets & Liabilities", status: "ready" },
    { code: "VSA 532", name: "Application for Search of Wills Notice", status: "ready" },
    { code: "Letter", name: "Letter to Beneficiaries", status: "pending" },
  ];

  return (
    <div className="p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-[14px] font-semibold text-[#1d1d1f]">Court Forms</h3>
        <Tooltip text="Download all forms as a single ZIP file">
          <div className="h-7 px-3 text-[11px] font-medium text-white rounded-md flex items-center gap-1.5 cursor-pointer hover:opacity-90 transition-opacity active:scale-[0.97]" style={{ backgroundColor: NAVY }}>
            <Download className="h-3 w-3" /> Grant Package (ZIP)
          </div>
        </Tooltip>
      </div>

      <div className="space-y-2">
        {forms.map((f) => (
          <div key={f.code} className="group flex items-center gap-3 p-3 rounded-lg border border-[#eee] hover:border-[#c0c8d0] hover:bg-[#fafcff] hover:shadow-sm transition-all duration-150">
            <span className="shrink-0 text-[11px] font-mono font-medium text-[#1e3a5f] bg-[#1e3a5f]/[0.06] px-2 py-1 rounded">
              {f.code}
            </span>
            <span className="flex-1 min-w-0 text-[13px] text-[#1d1d1f]">{f.name}</span>
            <Tooltip text={f.status === "ready" ? "Form is ready to generate" : "Waiting for required data"}>
              <span>
                {f.status === "ready" ? (
                  <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                ) : (
                  <Clock className="h-4 w-4 text-amber-500" />
                )}
              </span>
            </Tooltip>
            {/* The action pills have a 142px min-content width — too wide to sit
                beside the form name on a phone, so they appear from sm up. */}
            <div className="hidden sm:flex items-center gap-1.5">
              <span aria-hidden="true" className="inline-flex items-center h-6 px-2.5 text-[11px] font-medium text-[#1e3a5f] border border-[#ddd] rounded select-none">
                Preview
              </span>
              <span aria-hidden="true" className="inline-flex items-center h-6 px-2.5 text-[11px] font-medium text-white rounded select-none" style={{ backgroundColor: NAVY }}>
                Download
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-5 pt-4 border-t border-[#f0f0f0]">
        <h4 className="text-[12px] font-semibold text-[#888] uppercase tracking-wide mb-3">Individual Letters</h4>
        <div className="space-y-1.5">
          {["Sarah J. Thompson", "Michael R. Thompson", "Emily K. Chen"].map((name) => (
            <div key={name} className="group flex items-center gap-3 px-3 py-2 rounded border border-[#eee] hover:border-[#c0c8d0] hover:bg-[#fafcff] transition-all duration-150">
              <Users className="h-3.5 w-3.5 text-[#aaa] group-hover:text-[#1e3a5f] transition-colors" />
              <span className="flex-1 text-[12px] text-[#555]">{name}</span>
              <span aria-hidden="true" className="text-[11px] text-[#1e3a5f] font-medium select-none">Generate</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function FormsMockup() {
  return (
    <BrowserFrame title="Forms — Thompson Estate">
      <FormsMockupContent />
    </BrowserFrame>
  );
}

function ReadinessMockupContent() {
  const items = [
    { label: "Deceased information complete", status: "pass", tooltip: "All required fields filled: name, dates, addresses" },
    { label: "At least one applicant added", status: "pass", tooltip: "Executor or administrator designated" },
    { label: "Will uploaded", status: "pass", tooltip: "Original will scanned and attached" },
    { label: "Wills notice search filed", status: "pass", tooltip: "VSA 532 submitted to Vital Statistics" },
    { label: "21-day notice period elapsed", status: "warn", detail: "12 days remaining", tooltip: "Wait at least 21 days after P1 notice is delivered before filing, unless the court orders an earlier date" },
    { label: "All beneficiaries have delivery method", status: "fail", detail: "2 contacts missing", tooltip: "Each beneficiary needs mail, personal, or electronic delivery" },
    { label: "Inventory values entered", status: "pass", tooltip: "Asset and liability values populated for P10" },
  ];

  return (
    <div className="p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-[14px] font-semibold text-[#1d1d1f]">Filing Readiness</h3>
        <Tooltip text="5 of 7 readiness checks passed">
          <span className="text-[12px] font-medium text-amber-700 bg-amber-50 dark:text-amber-300 dark:bg-amber-950/30 px-2 py-1 rounded border border-amber-200 dark:border-amber-800 cursor-default">5/7 passed</span>
        </Tooltip>
      </div>
      <div className="space-y-2">
        {items.map((item, i) => (
          <Tooltip key={i} text={item.tooltip}>
            <div className={`flex items-start gap-2.5 py-2 px-3 rounded-lg border transition-all duration-150 cursor-default w-full ${
              item.status === "fail" ? "border-red-100 hover:border-red-200 hover:bg-red-50/30" :
              item.status === "warn" ? "border-amber-100 hover:border-amber-200 hover:bg-amber-50/30" :
              "border-[#eee] hover:border-[#d0d0d0] hover:bg-[#fafcff]"
            }`}>
              {item.status === "pass" && <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5 shrink-0" />}
              {item.status === "warn" && <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />}
              {item.status === "fail" && <XCircle className="h-4 w-4 text-red-500 mt-0.5 shrink-0" />}
              <div className="min-w-0">
                <span className="text-[13px] text-[#1d1d1f]">{item.label}</span>
                {item.detail && <span className="block text-[11px] text-[#888] mt-0.5">{item.detail}</span>}
              </div>
            </div>
          </Tooltip>
        ))}
      </div>
    </div>
  );
}

function ReadinessMockup() {
  return (
    <BrowserFrame title="Readiness — Thompson Estate">
      <ReadinessMockupContent />
    </BrowserFrame>
  );
}

function NotesMockupContent() {
  const notes = [
    { date: "Jun 12, 2026", category: "Call", text: "Spoke with Sarah Thompson re: will location. Original in safety deposit box at TD, Main & Broadway branch.", color: "bg-blue-50 text-blue-700 dark:bg-blue-950/30 dark:text-blue-300" },
    { date: "Jun 10, 2026", category: "Task", text: "Request death certificate from Vital Statistics — submitted online, expect 5-7 business days.", color: "bg-purple-50 text-purple-700" },
    { date: "Jun 8, 2026", category: "Memo", text: "Executor confirmed: no known debts other than mortgage on 1420 Oak St property. Bank will provide payoff statement.", color: "bg-slate-50 text-slate-700" },
    { date: "Jun 5, 2026", category: "Reminder", text: "Follow up with CRA for clearance certificate after grant issued.", color: "bg-amber-50 text-amber-700 dark:bg-amber-950/30 dark:text-amber-300" },
  ];

  return (
    <div className="p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-[14px] font-semibold text-[#1d1d1f]">File Notes</h3>
        <div className="h-7 px-3 text-[11px] font-medium text-[#1e3a5f] border border-[#ddd] rounded-md flex items-center gap-1.5 hover:bg-[#f5f5f5] hover:border-[#bbb] transition-all cursor-pointer active:scale-[0.97]">
          <span className="text-[13px]">+</span> Add Note
        </div>
      </div>
      <div className="space-y-3">
        {notes.map((note, i) => (
          <div key={i} className="p-3 rounded-lg border border-[#eee] hover:border-[#d0d0d0] hover:shadow-sm transition-all duration-150 cursor-default">
            <div className="flex items-center gap-2 mb-1.5">
              <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${note.color}`}>{note.category}</span>
              <span className="text-[11px] text-[#aaa]">{note.date}</span>
            </div>
            <p className="text-[12px] text-[#444] leading-[1.5]">{note.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function NotesMockup() {
  return (
    <BrowserFrame title="Notes — Thompson Estate">
      <NotesMockupContent />
    </BrowserFrame>
  );
}

/* ─── Sub-components ──────────────────────────────────────────── */

function Capability({ icon, title, description, delay }: { icon: React.ReactNode; title: string; description: string; delay: number }) {
  return (
    <motion.div
      className="space-y-3"
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.4, delay, ease: [0.23, 1, 0.32, 1] }}
    >
      <div className="flex items-center gap-2.5">
        <span className="text-[#1e3a5f]">{icon}</span>
        <h3 className="text-[15px] font-semibold tracking-[-0.01em] text-[#1d1d1f]">{title}</h3>
      </div>
      <p className="text-[14px] text-[#555] leading-[1.65] pl-0 sm:pl-[30px]">{description}</p>
    </motion.div>
  );
}

function Step({ number, title, description, delay }: { number: string; title: string; description: string; delay: number }) {
  return (
    <motion.div
      className="space-y-3"
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.4, delay, ease: [0.23, 1, 0.32, 1] }}
    >
      <span className="inline-block text-[12px] font-mono text-[#1e3a5f]/50 tracking-wider">{number}</span>
      <h3 className="text-[16px] font-semibold tracking-[-0.01em] text-[#1d1d1f]">{title}</h3>
      <p className="text-[14px] text-[#555] leading-[1.65]">{description}</p>
    </motion.div>
  );
}

function FormItem({ code, name, condition }: { code: string; name: string; condition?: string }) {
  const stacksCode = code.length > 10;

  return (
    <div
      data-form-code={code}
      data-form-layout={stacksCode ? "stacked" : "inline"}
      className="grid grid-cols-[max-content_minmax(0,1fr)] items-start gap-x-2.5 py-1.5"
    >
      <span className={`w-fit text-[12px] font-mono font-medium text-[#1e3a5f] bg-[#1e3a5f]/[0.06] px-1.5 py-0.5 rounded mt-[1px] ${stacksCode ? "col-span-2" : ""}`}>
        {code}
      </span>
      <div className={`min-w-0 ${stacksCode ? "col-start-2 mt-1" : ""}`}>
        <span className="text-[14px] text-[#1d1d1f]">{name}</span>
        {condition && (
          <span data-form-description="true" className="block text-[12px] text-[#888] mt-0.5 leading-[1.4]">
            {condition}
          </span>
        )}
      </div>
    </div>
  );
}
