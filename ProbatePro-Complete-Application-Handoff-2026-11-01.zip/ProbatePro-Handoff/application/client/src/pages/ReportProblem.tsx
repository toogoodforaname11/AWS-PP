import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Bug, CheckCircle2, Clock3, FileText, History, LifeBuoy, Loader2, MessageSquare, Paperclip, ShieldCheck, Upload, X } from "lucide-react";
import { motion, useReducedMotion } from "framer-motion";
import React, { useEffect, useMemo, useState } from "react";

const DRAFT_KEY = "probatepro:report-problem-draft:v1";
const MAX_ATTACHMENT_BYTES = 5 * 1024 * 1024;
const acceptedEvidenceTypes = ["image/png", "image/jpeg", "application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/plain"];
const categories = [
  { value: "access", label: "Access or sign-in" },
  { value: "data", label: "Estate data" },
  { value: "documents", label: "Documents or forms" },
  { value: "performance", label: "Performance or display" },
  { value: "other", label: "Other" },
] as const;
const quickReplies = [
  { value: "acknowledge", label: "Acknowledge receipt", message: "Thank you for reporting this. We have received your report and are reviewing the details." },
  { value: "investigating", label: "Investigation underway", message: "Thank you for the additional context. Our team is investigating this issue and will update you when we have more information." },
  { value: "need-details", label: "Request more detail", message: "Thank you for your report. To help us investigate, please reply with the steps you took, what you expected to happen, and what you saw instead." },
  { value: "resolved", label: "Confirm resolution", message: "We have applied a fix for this issue. Please try the action again and let us know through a new report if the problem continues." },
] as const;
const issueStatusMeta = {
  pending: { label: "Pending", className: "bg-slate-500/10 text-slate-700 dark:text-slate-300" },
  in_progress: { label: "In Progress", className: "bg-blue-500/10 text-blue-700 dark:text-blue-300" },
  resolved: { label: "Resolved", className: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300" },
} as const;
type Category = (typeof categories)[number]["value"];
type ReportDraft = { category: Category; subject: string; details: string };
type PendingAttachment = { fileName: string; mimeType: string; size: number; fileBase64: string };

function readDraft(): ReportDraft {
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    if (!raw) return { category: "other", subject: "", details: "" };
    const parsed = JSON.parse(raw) as Partial<ReportDraft>;
    const category = categories.some((item) => item.value === parsed.category) ? parsed.category as Category : "other";
    return { category, subject: typeof parsed.subject === "string" ? parsed.subject.slice(0, 180) : "", details: typeof parsed.details === "string" ? parsed.details.slice(0, 5000) : "" };
  } catch { return { category: "other", subject: "", details: "" }; }
}

function fileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("The selected file could not be read."));
    reader.onload = () => { const result = String(reader.result ?? ""); resolve(result.includes(",") ? result.split(",", 2)[1] : result); };
    reader.readAsDataURL(file);
  });
}

function categoryLabel(category: string) { return categories.find((item) => item.value === category)?.label ?? category; }
function issueMeta(status: string) { return issueStatusMeta[status as keyof typeof issueStatusMeta] ?? issueStatusMeta.pending; }
function formatDate(value: number) { return new Date(value).toLocaleString(); }
function actionLabel(action: string) { return ({ status_changed: "Issue status updated", priority_changed: "Priority updated", bulk_resolved: "Resolved in bulk", resolution_undone: "Resolution undone" } as Record<string, string>)[action] ?? "Report updated"; }
function actionValueLabel(value: string) { return value.replace(/_/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase()); }

type ReplyTemplate = { id: string; name: string; message: string };

function AdminResponseComposer({
  templates, quickReply, onQuickReplyChange, templateName, onTemplateNameChange, responseMessage, onResponseMessageChange,
  onSaveTemplate, onDeleteTemplate, onSend, templatePending, responsePending,
}: {
  templates: ReplyTemplate[]; quickReply: string; onQuickReplyChange: (value: string) => void; templateName: string;
  onTemplateNameChange: (value: string) => void; responseMessage: string; onResponseMessageChange: (value: string) => void;
  onSaveTemplate: () => void; onDeleteTemplate: () => void; onSend: () => void; templatePending: boolean; responsePending: boolean;
}) {
  const isCustom = quickReply.startsWith("custom:");
  const canSave = templateName.trim().length >= 2 && responseMessage.trim().length >= 2 && !templatePending;
  const [previewOpen, setPreviewOpen] = useState(false);
  return <div className="space-y-3 border-t pt-4"><div className="grid gap-2 sm:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]"><div><Label htmlFor="support-quick-reply">Reply starting point</Label><Select value={quickReply} onValueChange={(value) => { setPreviewOpen(false); onQuickReplyChange(value); }}><SelectTrigger id="support-quick-reply" aria-label="Choose an editable quick reply"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="none">Start from scratch</SelectItem>{quickReplies.map((template) => <SelectItem key={template.value} value={template.value}>{template.label}</SelectItem>)}{templates.map((template) => <SelectItem key={template.id} value={`custom:${template.id}`}>{template.name}</SelectItem>)}</SelectContent></Select></div><div><Label htmlFor="support-template-name">Save as template</Label><Input id="support-template-name" value={templateName} onChange={(event) => onTemplateNameChange(event.target.value)} maxLength={80} placeholder="e.g. Needs more detail" /></div></div><p className="text-xs text-muted-foreground">Every reply remains editable. Save a clear starting point for your own future support work; it never sends automatically.</p><div className="space-y-2"><Label htmlFor="support-response">Add a support response</Label><Textarea id="support-response" value={responseMessage} onChange={(event) => { setPreviewOpen(false); onResponseMessageChange(event.target.value); }} className="min-h-24 resize-y" placeholder="Write a concise update that the report submitter can see." maxLength={4000} /></div>{previewOpen && <div aria-label="Support response preview" className="rounded-lg border border-primary/15 bg-muted/30 p-3"><p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Support response preview</p><p className="mt-2 whitespace-pre-wrap break-words text-sm leading-6">{responseMessage}</p><p className="mt-2 text-xs text-muted-foreground">This is a preview only. The response is not sent until you choose Send response.</p></div>}<div className="flex flex-wrap items-center gap-2"><Button type="button" variant="outline" disabled={!canSave} onClick={onSaveTemplate}>{templatePending ? "Saving template…" : isCustom ? "Update template" : "Save template"}</Button>{isCustom && <Button type="button" variant="ghost" disabled={templatePending} onClick={onDeleteTemplate}>Delete template</Button>}<Button type="button" variant="outline" disabled={responseMessage.trim().length < 2} onClick={() => setPreviewOpen((open) => !open)}>{previewOpen ? "Hide preview" : "Preview reply"}</Button><Button type="button" disabled={responseMessage.trim().length < 2 || responsePending} onClick={onSend}>{responsePending ? "Sending response…" : "Send response"}</Button></div></div>;
}

export default function ReportProblem() {
  const reduceMotion = useReducedMotion();
  const selectedReportFromQueue = useMemo(() => new URLSearchParams(window.location.search).get("reportId")?.trim().slice(0, 36) || null, []);
  const initialDraft = useMemo(readDraft, []);
  const [category, setCategory] = useState<Category>(initialDraft.category);
  const [subject, setSubject] = useState(initialDraft.subject);
  const [details, setDetails] = useState(initialDraft.details);
  const [attachment, setAttachment] = useState<PendingAttachment | null>(null);
  const [attachmentError, setAttachmentError] = useState("");
  const [draftSaved, setDraftSaved] = useState(Boolean(initialDraft.subject || initialDraft.details));
  const [submissionStatus, setSubmissionStatus] = useState<"delivered" | "delivery_failed" | null>(null);
  const [selectedReportId, setSelectedReportId] = useState<string | null>(selectedReportFromQueue);
  const [responseMessage, setResponseMessage] = useState("");
  const [quickReply, setQuickReply] = useState("none");
  const [templateName, setTemplateName] = useState("");
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const reportsQuery = trpc.support.listReports.useQuery();
  const allReportsQuery = trpc.support.listAllReports.useQuery(undefined, { enabled: isAdmin, refetchInterval: 15_000, refetchOnWindowFocus: true });
  const replyTemplatesQuery = trpc.support.listReplyTemplates.useQuery(undefined, { enabled: isAdmin });
  const detailQuery = trpc.support.getReportDetail.useQuery({ id: selectedReportId ?? "" }, { enabled: Boolean(selectedReportId), refetchInterval: isAdmin && selectedReportId ? 15_000 : false, refetchOnWindowFocus: true });
  const statusMutation = trpc.support.updateIssueStatus.useMutation({ onSuccess: () => { void reportsQuery.refetch(); void allReportsQuery.refetch(); void detailQuery.refetch(); } });
  const responseMutation = trpc.support.addResponse.useMutation({ onSuccess: () => { setResponseMessage(""); void detailQuery.refetch(); } });
  const createReplyTemplateMutation = trpc.support.createReplyTemplate.useMutation({ onSuccess: (result) => { setQuickReply(`custom:${result.template.id}`); setTemplateName(result.template.name); void replyTemplatesQuery.refetch(); } });
  const updateReplyTemplateMutation = trpc.support.updateReplyTemplate.useMutation({ onSuccess: () => { void replyTemplatesQuery.refetch(); } });
  const deleteReplyTemplateMutation = trpc.support.deleteReplyTemplate.useMutation({ onSuccess: () => { setQuickReply("none"); setTemplateName(""); void replyTemplatesQuery.refetch(); } });
  const reportMutation = trpc.support.reportProblem.useMutation({
    onSuccess: (result) => {
      setSubmissionStatus(result.deliveryStatus);
      if (result.success) { setCategory("other"); setSubject(""); setDetails(""); setAttachment(null); setDraftSaved(false); localStorage.removeItem(DRAFT_KEY); }
      void reportsQuery.refetch();
    },
  });

  useEffect(() => {
    const isEmpty = !subject.trim() && !details.trim() && category === "other";
    if (isEmpty) { localStorage.removeItem(DRAFT_KEY); setDraftSaved(false); return; }
    localStorage.setItem(DRAFT_KEY, JSON.stringify({ category, subject, details } satisfies ReportDraft));
    setDraftSaved(true);
  }, [category, subject, details]);

  const canSubmit = subject.trim().length >= 3 && details.trim().length >= 10 && !attachmentError;
  const reports = isAdmin ? allReportsQuery.data ?? [] : reportsQuery.data ?? [];
  const reportsLoading = isAdmin ? allReportsQuery.isLoading : reportsQuery.isLoading;
  const selected = detailQuery.data;
  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!canSubmit || reportMutation.isPending) return;
    setSubmissionStatus(null);
    reportMutation.mutate({ category, subject: subject.trim(), details: details.trim(), page: window.location.pathname, ...(attachment ? { attachment } : {}) });
  };
  const selectAttachment = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]; event.target.value = "";
    if (!file) return;
    setAttachmentError("");
    if (!acceptedEvidenceTypes.includes(file.type) || file.size > MAX_ATTACHMENT_BYTES) { setAttachment(null); setAttachmentError("Choose a PNG, JPEG, PDF, Word document, or text file no larger than 5 MB."); return; }
    try { setAttachment({ fileName: file.name, mimeType: file.type, size: file.size, fileBase64: await fileAsBase64(file) }); }
    catch (error) { setAttachment(null); setAttachmentError(error instanceof Error ? error.message : "The selected file could not be read."); }
  };
  const addResponse = () => {
    if (!selectedReportId || responseMessage.trim().length < 2 || responseMutation.isPending) return;
    responseMutation.mutate({ reportId: selectedReportId, message: responseMessage.trim() });
  };
  const applyQuickReply = (value: string) => {
    setQuickReply(value);
    const builtIn = quickReplies.find((item) => item.value === value);
    const custom = (replyTemplatesQuery.data ?? []).find((item) => `custom:${item.id}` === value);
    if (builtIn) { setResponseMessage(builtIn.message); setTemplateName(""); }
    if (custom) { setResponseMessage(custom.message); setTemplateName(custom.name); }
  };
  const selectedCustomTemplateId = quickReply.startsWith("custom:") ? quickReply.slice("custom:".length) : null;
  const saveCustomTemplate = () => {
    const name = templateName.trim();
    const message = responseMessage.trim();
    if (name.length < 2 || message.length < 2) return;
    if (selectedCustomTemplateId) updateReplyTemplateMutation.mutate({ id: selectedCustomTemplateId, name, message });
    else createReplyTemplateMutation.mutate({ name, message });
  };

  return <motion.main data-testid="report-problem-route" className="space-y-6" initial={reduceMotion ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={reduceMotion ? { duration: 0 } : { duration: 0.24, ease: [0.23, 1, 0.32, 1] }}>
    <PageHeader title="Report a Problem" description="Send a concise issue report to the ProbatePro support team so they can investigate." />
    <div className="grid gap-5 lg:grid-cols-[1fr_0.7fr]">
      <Card className="border-primary/15"><CardHeader><CardTitle className="flex items-center gap-2 text-lg"><Bug className="h-5 w-5 text-primary" /> Tell us what happened</CardTitle><CardDescription>Include the page, expected result, and what you saw. Do not include portal tokens, passwords, or other secret credentials.</CardDescription></CardHeader><CardContent>
        <form className="space-y-4" onSubmit={submit}>
          <div className="space-y-2"><Label htmlFor="report-category">Problem type</Label><Select value={category} onValueChange={(value: Category) => setCategory(value)}><SelectTrigger id="report-category" aria-label="Problem type"><SelectValue /></SelectTrigger><SelectContent>{categories.map((item) => <SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>)}</SelectContent></Select></div>
          <div className="space-y-2"><Label htmlFor="report-subject">Problem summary</Label><Input id="report-subject" value={subject} onChange={(event) => setSubject(event.target.value)} placeholder="For example, a form preview does not open" maxLength={180} /></div>
          <div className="space-y-2"><div className="flex items-center justify-between gap-3"><Label htmlFor="report-details">What happened?</Label>{draftSaved && <span role="status" className="text-xs text-muted-foreground">Draft saved to this browser</span>}</div><Textarea id="report-details" value={details} onChange={(event) => setDetails(event.target.value)} placeholder="Describe the steps you took, what you expected, and what happened instead." className="min-h-32 resize-y" maxLength={5000} /></div>
          <div className="space-y-2"><Label htmlFor="report-attachment">Screenshot or file (optional)</Label><div className="flex flex-col gap-2 sm:flex-row sm:items-center"><Button type="button" variant="outline" className="w-full sm:w-auto" onClick={() => document.getElementById("report-attachment")?.click()}><Upload className="mr-2 h-4 w-4" /> Add evidence</Button><Input id="report-attachment" className="sr-only" type="file" accept="image/png,image/jpeg,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain" onChange={selectAttachment} /><span className="text-xs text-muted-foreground">PNG, JPEG, PDF, Word, or text — up to 5 MB.</span></div>{attachment && <div className="flex min-w-0 items-center gap-2 rounded-lg border border-primary/15 bg-muted/30 px-3 py-2 text-sm"><Paperclip className="h-4 w-4 shrink-0 text-primary" /><span className="min-w-0 flex-1 truncate">{attachment.fileName}</span><span className="shrink-0 text-xs text-muted-foreground">{Math.ceil(attachment.size / 1024)} KB</span><Button type="button" variant="ghost" size="icon" aria-label={`Remove ${attachment.fileName}`} onClick={() => setAttachment(null)}><X className="h-4 w-4" /></Button></div>}{attachmentError && <p role="alert" className="text-sm text-destructive">{attachmentError}</p>}</div>
          {reportMutation.error && <p role="alert" className="text-sm text-destructive">{reportMutation.error.message}</p>}{submissionStatus && <p role="status" className={`flex items-center gap-2 text-sm ${submissionStatus === "delivered" ? "text-emerald-700 dark:text-emerald-300" : "text-amber-700 dark:text-amber-300"}`}><CheckCircle2 className="h-4 w-4" /> {submissionStatus === "delivered" ? "Your report has been sent to support." : "Your report was saved, but support delivery is pending."}</p>}
          <Button type="submit" disabled={!canSubmit || reportMutation.isPending} className="w-full sm:w-auto">{reportMutation.isPending ? "Sending report…" : "Send report"}</Button>
        </form>
      </CardContent></Card>
      <Card className="bg-muted/30"><CardHeader><CardTitle className="flex items-center gap-2 text-lg"><LifeBuoy className="h-5 w-5 text-primary" /> What support receives</CardTitle></CardHeader><CardContent className="space-y-4 text-sm leading-6 text-muted-foreground"><p>Your selected category, summary, description, current in-app page, and optional evidence metadata are sent to the project support owner for review.</p><p className="rounded-lg border border-primary/15 bg-background/70 p-3 text-foreground"><ShieldCheck className="mr-2 inline h-4 w-4 text-primary" /> Keep secret tokens, passwords, payment information, and private document contents out of the report.</p><p>For urgent file or filing decisions, use your firm’s established professional escalation process rather than relying on this technical support channel.</p></CardContent></Card>
    </div>
    <Card><CardHeader><CardTitle className="flex items-center gap-2 text-lg"><History className="h-5 w-5 text-primary" /> View Previous Reports</CardTitle><CardDescription>{isAdmin ? "Support queue for administrators. Select a report to review details, issue progress, and responses." : "Select a report to view its full submitted details and any support response."}</CardDescription></CardHeader><CardContent>{reportsLoading ? <div role="status" className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading reports…</div> : reports.length === 0 ? <p className="text-sm text-muted-foreground">No reports have been submitted from this account yet.</p> : <div className="space-y-3">{reports.map((report) => { const issue = issueMeta(report.issueStatus); return <div key={report.id} className="rounded-lg border border-border/70 p-3"><div className="flex flex-wrap items-start justify-between gap-2"><div className="min-w-0"><Button type="button" variant="link" className="h-auto max-w-full justify-start p-0 text-left font-medium break-words" onClick={() => setSelectedReportId(report.id)} aria-label={`View details for ${report.subject}`}>{report.subject}</Button><p className="mt-1 text-xs text-muted-foreground">{categoryLabel(report.category)} · {formatDate(report.createdAt)}{isAdmin ? ` · Reporter #${report.userId}` : ""}</p></div><div className="flex flex-wrap items-center justify-end gap-2"><span aria-label={`Issue status: ${issue.label}`} className={`inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-1 text-xs ${issue.className}`}><Clock3 className="h-3.5 w-3.5" />{issue.label}</span><span aria-label={report.deliveryStatus === "delivered" ? "Delivery status: Delivered to support" : "Delivery status: Delivery pending"} className={`inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-1 text-xs ${report.deliveryStatus === "delivered" ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300" : "bg-amber-500/10 text-amber-700 dark:text-amber-300"}`}><CheckCircle2 className="h-3.5 w-3.5" />{report.deliveryStatus === "delivered" ? "Delivered" : "Delivery pending"}</span></div></div><p className="mt-2 line-clamp-2 whitespace-pre-wrap break-words text-sm text-muted-foreground">{report.details}</p><Button type="button" variant="ghost" size="sm" className="mt-2 -ml-2" onClick={() => setSelectedReportId(report.id)}>View details</Button></div>; })}</div>}</CardContent></Card>
    <Dialog open={Boolean(selectedReportId)} onOpenChange={(open) => { if (!open) { setSelectedReportId(null); setResponseMessage(""); setQuickReply("none"); setTemplateName(""); } }}><DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-2xl"><DialogHeader><DialogTitle>{detailQuery.isLoading ? "Loading report…" : selected ? selected.report.subject : "Report details"}</DialogTitle><DialogDescription>Private support-report details are visible only to the report submitter and authorized support administrators.</DialogDescription></DialogHeader>{detailQuery.isLoading ? <div role="status" className="flex items-center gap-2 py-8 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading report details…</div> : detailQuery.error ? <p role="alert" className="text-sm text-destructive">{detailQuery.error.message}</p> : selected ? <div className="space-y-5"><div className="grid gap-3 text-sm sm:grid-cols-2"><div><p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Category</p><p className="mt-1">{categoryLabel(selected.report.category)}</p></div><div><p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Submitted</p><p className="mt-1">{formatDate(selected.report.createdAt)}</p></div><div><p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Issue progress</p><span className={`mt-1 inline-flex rounded-full px-2 py-1 text-xs ${issueMeta(selected.report.issueStatus).className}`}>{issueMeta(selected.report.issueStatus).label}</span></div><div><p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Delivery</p><p className="mt-1">{selected.report.deliveryStatus === "delivered" ? "Delivered to support" : "Delivery pending"}</p></div></div><div><p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Page context</p><p className="mt-1 break-all text-sm text-muted-foreground">{selected.report.page}</p></div><div><p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Submitted details</p><p className="mt-1 whitespace-pre-wrap break-words text-sm leading-6">{selected.report.details}</p></div>{selected.report.attachmentStorageKey && <a className="inline-flex max-w-full items-center gap-2 text-sm text-primary underline-offset-4 hover:underline" href={`/manus-storage/${selected.report.attachmentStorageKey}`} target="_blank" rel="noreferrer"><FileText className="h-4 w-4 shrink-0" /><span className="truncate">{selected.report.attachmentName || "View attached evidence"}</span></a>}<div className="border-t pt-4"><p className="flex items-center gap-2 font-medium"><MessageSquare className="h-4 w-4 text-primary" /> Support responses</p>{selected.responses.length === 0 ? <p className="mt-2 text-sm text-muted-foreground">No response has been added yet.</p> : <div className="mt-3 space-y-3">{selected.responses.map((response) => <div key={response.id} className="rounded-lg border border-primary/15 bg-muted/30 p-3"><p className="whitespace-pre-wrap break-words text-sm leading-6">{response.message}</p><p className="mt-2 text-xs text-muted-foreground">Support response · {formatDate(response.createdAt)}</p></div>)}</div>}</div>{isAdmin && <section aria-label="Administrator action history" className="border-t pt-4"><p className="flex items-center gap-2 font-medium"><History className="h-4 w-4 text-primary" /> Administrator action history</p><p className="mt-1 text-xs text-muted-foreground">Private to administrators. This records report progress and priority changes.</p>{(selected.actionHistory ?? []).length === 0 ? <p className="mt-3 text-sm text-muted-foreground">No administrator action has been recorded yet.</p> : <div className="mt-3 space-y-2">{selected.actionHistory.map((action: { id: string; action: string; previousValue: string; nextValue: string; actorName?: string | null; createdAt: number }) => <div key={action.id} className="rounded-lg border border-primary/15 bg-muted/30 p-3"><p className="text-sm font-medium">{actionLabel(action.action)}</p><p className="mt-1 text-sm text-muted-foreground">{actionValueLabel(action.previousValue)} → {actionValueLabel(action.nextValue)}</p><p className="mt-2 text-xs text-muted-foreground">{action.actorName || "Administrator"} · {formatDate(action.createdAt)}</p></div>)}</div>}</section>}{isAdmin && <AdminResponseComposer templates={replyTemplatesQuery.data ?? []} quickReply={quickReply} onQuickReplyChange={applyQuickReply} templateName={templateName} onTemplateNameChange={setTemplateName} responseMessage={responseMessage} onResponseMessageChange={setResponseMessage} onSaveTemplate={saveCustomTemplate} onDeleteTemplate={() => { if (selectedCustomTemplateId) deleteReplyTemplateMutation.mutate({ id: selectedCustomTemplateId }); }} onSend={addResponse} templatePending={createReplyTemplateMutation.isPending || updateReplyTemplateMutation.isPending || deleteReplyTemplateMutation.isPending} responsePending={responseMutation.isPending} />}</div> : null}</DialogContent></Dialog>
  </motion.main>;
}
