import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import Settings from "./Settings";
import { LEGACY_FORM_P1_NOTICE_LETTER_TEMPLATE } from "@shared/letter-template";
import {
  FORM_FOCUSED_INTAKE_ACTIVATED_EVENT,
  FORM_FOCUSED_INTAKE_ONBOARDING_STORAGE_KEY,
  FORM_FOCUSED_INTAKE_STORAGE_KEY,
} from "@/hooks/useFormFocusedIntakePreference";

const { getLoginUrlAsync } = vi.hoisted(() => ({ getLoginUrlAsync: vi.fn() }));

const mocks = vi.hoisted(() => ({
  update: vi.fn(),
  deleteAccount: vi.fn(),
  authSetData: vi.fn(),
  invalidate: vi.fn(),
  toastSuccess: vi.fn(),
  toastError: vi.fn(),
  shouldFail: false,
  accountDeletionShouldFail: false,
  accountDeletionPending: false,
}));

const settings = {
  accountPurpose: "lawyer",
  lawyerName: "Alex Counsel",
  firmName: "Counsel Law",
  firmAddress: "101 Court Street\nVictoria BC V8W 1A1",
  firmCity: "Victoria",
  firmPhone: "250-555-0100",
  firmFax: "",
  showFirmFax: true,
  firmEmail: "alex@example.com",
  letterBodyTemplate: "",
  letterClosing: "Yours truly,",
  letterShowPerLine: true,
  hideBeneficiaryLetterSigningContact: false,
  suppressFirmText: false,
  checkboxSize: 0,
  checkboxBold: 1,
  checkboxTextOnly: false,
  formFocusedIntake: false,
};

vi.mock("@/lib/trpc", () => {
  const mutation = (callbacks?: { onSuccess?: (data?: unknown, variables?: unknown) => void; onError?: (error: { message: string }) => void }) => ({
    mutate: (input: unknown, options?: { onSuccess?: () => void; onError?: (error: { message: string }) => void }) => {
      mocks.update(input);
      if (mocks.shouldFail) {
        const error = { message: "Settings service is unavailable" };
        callbacks?.onError?.(error);
        options?.onError?.(error);
        return;
      }
      callbacks?.onSuccess?.(undefined, input);
      options?.onSuccess?.();
    },
    isPending: false,
  });
  const accountDeletionMutation = (callbacks?: { onSuccess?: (result: { queuedFirmAssets: number }) => void; onError?: (error: { message: string }) => void }) => ({
    mutate: (input: unknown) => {
      mocks.deleteAccount(input);
      if (mocks.accountDeletionShouldFail) {
        callbacks?.onError?.({ message: "Remove estate files before deleting this account" });
        return;
      }
      callbacks?.onSuccess?.({ queuedFirmAssets: 0 });
    },
    isPending: mocks.accountDeletionPending,
  });
  return {
    trpc: {
      settings: {
        get: { useQuery: () => ({ data: settings, isLoading: false }) },
        update: { useMutation: mutation },
        uploadLetterhead: { useMutation: mutation },
        deleteLetterhead: { useMutation: mutation },
        uploadLetterheadDocx: { useMutation: mutation },
        deleteLetterheadDocx: { useMutation: mutation },
      },
      auth: { deleteAccount: { useMutation: accountDeletionMutation } },
      useUtils: () => ({ settings: { get: { invalidate: mocks.invalidate } }, auth: { me: { setData: mocks.authSetData } } }),
    },
  };
});
vi.mock("@/const", () => ({ getLoginUrlAsync }));
vi.mock("@/components/PageHeader", () => ({ PageHeader: ({ title, description }: { title: string; description: string }) => <header><h1>{title}</h1><p>{description}</p></header> }));
vi.mock("@/components/AddressAutocomplete", () => ({ AddressAutocomplete: ({ value, onChange }: { value: string; onChange: (value: string) => void }) => <input aria-label="Street Address" value={value} onChange={(event) => onChange(event.target.value)} /> }));
vi.mock("@/hooks/useLocalDraft", () => ({ useLocalDraft: () => ({ pendingDraft: null, pendingDraftTime: null, acceptDraft: () => null, dismissDraft: vi.fn(), clearDraft: vi.fn() }) }));
vi.mock("@/components/UploadFeedback", () => ({ UploadFeedback: () => null, IDLE_UPLOAD_FEEDBACK: { phase: "idle", progress: 0, message: "" }, invalidFileTypeMessage: () => "Invalid file", fileTooLargeMessage: () => "Too large" }));
vi.mock("@/lib/formatters", () => ({ formatPhone: (value: string) => value }));
vi.mock("@/lib/labels", () => ({ fmtDisplayDate: () => "Aug 24, 2026" }));
vi.mock("sonner", () => ({ toast: { success: mocks.toastSuccess, error: mocks.toastError, info: vi.fn() } }));
vi.mock("framer-motion", () => ({
  motion: {
    div: ({ children, ...props }: React.HTMLAttributes<HTMLDivElement>) => <div {...props}>{children}</div>,
    span: ({ children, ...props }: React.HTMLAttributes<HTMLSpanElement>) => <span {...props}>{children}</span>,
  },
  AnimatePresence: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}));

beforeEach(() => {
  Object.defineProperty(globalThis, "ResizeObserver", {
    configurable: true,
    value: class {
      observe() {}
      unobserve() {}
      disconnect() {}
    },
  });
});

afterEach(() => {
  mocks.update.mockReset();
  mocks.deleteAccount.mockReset();
  mocks.authSetData.mockReset();
  mocks.invalidate.mockReset();
  mocks.toastSuccess.mockReset();
  mocks.toastError.mockReset();
  getLoginUrlAsync.mockReset();
  mocks.shouldFail = false;
  mocks.accountDeletionShouldFail = false;
  mocks.accountDeletionPending = false;
  settings.letterBodyTemplate = "";
  settings.accountPurpose = "lawyer";
  settings.firmFax = "";
  settings.showFirmFax = true;
  settings.hideBeneficiaryLetterSigningContact = false;
  (settings as any).letterheadDocxName = "";
  window.localStorage.removeItem(FORM_FOCUSED_INTAKE_STORAGE_KEY);
  window.localStorage.removeItem(FORM_FOCUSED_INTAKE_ONBOARDING_STORAGE_KEY);
});

describe("Settings workspace", () => {
  it("marks private workspace preferences as non-indexable", () => {
    render(<Settings />);

    expect(document.title).toBe("Settings | ProbatePro");
    expect(document.head.querySelector('meta[name="robots"]')?.getAttribute("content")).toBe("noindex, nofollow");
    expect(document.head.querySelector('link[rel="canonical"]')?.getAttribute("href")).toBe("https://probate-pro.com/settings");
  });

  it("lets a personal executor configure beneficiary-letter output without professional profile fields", () => {
    settings.accountPurpose = "personal_executor";
    (settings as any).letterheadDocxName = "executor-letterhead.docx";
    render(<Settings />);

    expect(screen.getByTestId("account-purpose-settings")).toBeTruthy();
    expect(screen.getByText(/Current workspace:/i)).toBeTruthy();
    expect(screen.queryByRole("button", { name: "Save Firm Details" })).toBeNull();
    expect(screen.queryByLabelText("Lawyer Name")).toBeNull();
    expect(screen.getByRole("link", { name: "Account purpose" }).getAttribute("href")).toBe("#account-purpose");
    expect(screen.getByRole("link", { name: "Letters" }).getAttribute("href")).toBe("#letter-settings");
    expect(screen.getByRole("link", { name: "Letter template" }).getAttribute("href")).toBe("#letter-template");
    expect(screen.getByRole("link", { name: "Closing block" }).getAttribute("href")).toBe("#letter-closing");
    expect(document.getElementById("letter-settings")).toBeTruthy();

    fireEvent.change(screen.getByPlaceholderText("Enter your custom letter body..."), { target: { value: "Personal executor letter body." } });
    fireEvent.click(screen.getByRole("button", { name: "Save Template" }));
    expect(mocks.update).toHaveBeenCalledWith({ letterBodyTemplate: "Personal executor letter body." });

    fireEvent.change(screen.getByDisplayValue("Yours truly,"), { target: { value: "Respectfully," } });
    fireEvent.click(screen.getByRole("button", { name: "Save Closing" }));
    expect(mocks.update).toHaveBeenCalledWith({ letterClosing: "Respectfully,", letterShowPerLine: true });

    fireEvent.click(screen.getByRole("checkbox", { name: "Hide address, phone, and email in beneficiary-letter signing blocks" }));
    expect(mocks.update).toHaveBeenCalledWith({ hideBeneficiaryLetterSigningContact: true });

    fireEvent.click(screen.getByRole("switch", { name: "Hide sender information in letters" }));
    expect(mocks.update).toHaveBeenCalledWith({ suppressFirmText: true });
    expect(screen.getByRole("link", { name: "Intake view" })).toBeTruthy();
  });

  it("lets an account correct its workspace type without changing estate access or stored firm details", () => {
    settings.accountPurpose = "personal_executor";
    render(<Settings />);

    fireEvent.click(screen.getByTestId("change-account-type"));
    expect(screen.getByTestId("account-type-dialog")).toBeTruthy();
    expect((screen.getByTestId("account-type-personal_executor") as HTMLInputElement).checked).toBe(true);
    expect((screen.getByTestId("confirm-account-type") as HTMLButtonElement).disabled).toBe(true);

    fireEvent.click(screen.getByTestId("account-type-lawyer"));
    expect((screen.getByTestId("confirm-account-type") as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(screen.getByTestId("confirm-account-type"));

    expect(mocks.update).toHaveBeenCalledWith({ accountPurpose: "lawyer", formFocusedIntake: true });
    expect(mocks.toastSuccess).toHaveBeenCalledWith("Account type updated");
    expect(mocks.update.mock.calls[0][0]).not.toHaveProperty("estateId");
    expect(mocks.update.mock.calls[0][0]).not.toHaveProperty("firmName");
  });

  it("explains the lawyer and personal-executor workspace features without selecting a different account type", async () => {
    settings.accountPurpose = "personal_executor";
    render(<Settings />);
    fireEvent.click(screen.getByTestId("change-account-type"));

    const lawyerHelp = screen.getByRole("button", { name: "About the Lawyer workspace" });
    fireEvent.focus(lawyerHelp);
    await waitFor(() => expect(screen.getAllByText(/Firm details, letterhead, and form preferences remain available/i).length).toBeGreaterThan(0));
    expect((screen.getByTestId("account-type-personal_executor") as HTMLInputElement).checked).toBe(true);

    const executorHelp = screen.getByRole("button", { name: "About the Personal executor workspace" });
    fireEvent.focus(executorHelp);
    await waitFor(() => expect(screen.getAllByText(/same form-generation checks/i).length).toBeGreaterThan(0));
    expect((screen.getByTestId("account-type-personal_executor") as HTMLInputElement).checked).toBe(true);
  });

  it("provides in-page navigation to every persisted settings section", () => {
    render(<Settings />);
    const navigation = screen.getByRole("navigation", { name: "Settings sections" });
    expect(navigation).toBeTruthy();
    expect(screen.getByRole("link", { name: "Firm details" }).getAttribute("href")).toBe("#firm-details");
    expect(screen.getByRole("link", { name: "Letter template" }).getAttribute("href")).toBe("#letter-template");
    expect(screen.getByRole("link", { name: "Closing block" }).getAttribute("href")).toBe("#letter-closing");
    expect(screen.getByRole("link", { name: "Intake view" }).getAttribute("href")).toBe("#intake-view");
    expect(screen.getByRole("link", { name: "Assistant" }).getAttribute("href")).toBe("#assistant-preferences");
    expect(screen.getByRole("link", { name: "Checkbox appearance" }).getAttribute("href")).toBe("#checkbox-appearance");
    expect(screen.getByRole("link", { name: "Password & sign-in" }).getAttribute("href")).toBe("#account-recovery");
    expect(screen.getByRole("link", { name: "Account" }).getAttribute("href")).toBe("#account-danger-zone");
    expect(document.getElementById("firm-details")).toBeTruthy();
    expect(document.getElementById("letter-template")).toBeTruthy();
    expect(document.getElementById("letter-closing")).toBeTruthy();
    expect(document.getElementById("intake-view")).toBeTruthy();
    expect(document.getElementById("assistant-preferences")).toBeTruthy();
    expect(document.getElementById("checkbox-appearance")).toBeTruthy();
    expect(document.getElementById("account-danger-zone")).toBeTruthy();
    const recovery = document.getElementById("account-recovery")!;
    const dangerZone = document.getElementById("account-danger-zone")!;
    expect(recovery).toBeTruthy();
    expect(recovery.compareDocumentPosition(dangerZone) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
  });

  it("places managed password recovery above deletion without offering a local reset", () => {
    render(<Settings />);
    const recovery = screen.getByTestId("account-recovery");
    expect(recovery.textContent).toMatch(/never stores your password/i);
    expect(screen.getByRole("link", { name: /Identity-provider account help/i }).getAttribute("href")).toBe("https://help.manus.im");
    expect(screen.queryByLabelText(/new password/i)).toBeNull();
    const responsiveContent = screen.getByTestId("account-recovery-content");
    expect(responsiveContent.className).toContain("grid");
    expect(responsiveContent.className).toContain("sm:grid-cols-[minmax(0,1fr)_auto]");
    expect(recovery.querySelector(".min-w-0")).toBeTruthy();
  });

  it("shows secure-opening feedback while opening managed sign-in help", () => {
    getLoginUrlAsync.mockReturnValueOnce(new Promise(() => undefined));
    render(<Settings />);
    fireEvent.click(screen.getByRole("button", { name: "Open sign-in help" }));
    const loadingAction = screen.getByRole("button", { name: /Opening secure sign-in/i });
    expect((loadingAction as HTMLButtonElement).disabled).toBe(true);
  });

  it("keeps a retryable managed recovery action when secure sign-in cannot open", async () => {
    getLoginUrlAsync.mockRejectedValueOnce(new Error("temporary failure"));
    render(<Settings />);
    fireEvent.click(screen.getByRole("button", { name: "Open sign-in help" }));
    await waitFor(() => expect(screen.getByRole("alert").textContent).toContain("couldn’t open secure sign-in"));
    expect((screen.getByRole("button", { name: "Open sign-in help" }) as HTMLButtonElement).disabled).toBe(false);
  });

  it("confirms a section save beside the action that completed", () => {
    render(<Settings />);
    fireEvent.click(screen.getByRole("button", { name: "Save Template" }));
    expect(mocks.update).toHaveBeenCalledWith(expect.objectContaining({ letterBodyTemplate: expect.any(String) }));
    expect(screen.getByText("Saved")).toBeTruthy();
    expect(mocks.toastSuccess).toHaveBeenCalledWith("Letter template saved");
  });

  it("shows the current shared beneficiary-letter body when no custom template is stored", () => {
    settings.letterBodyTemplate = "";
    render(<Settings />);
    const editor = screen.getByPlaceholderText("Enter your custom letter body...") as HTMLTextAreaElement;
    expect(editor.value).toContain("We act for {{applicant_name}} in connection with the estate of the late {{deceased_name}} who died on {{date_of_death}}. {{will_statement}}");
    expect(editor.value).toContain("Please keep the enclosed in your personal records.");
  });

  it("replaces a saved prior built-in body in the Settings editor without requiring the firm to reset it manually", () => {
    settings.letterBodyTemplate = LEGACY_FORM_P1_NOTICE_LETTER_TEMPLATE;
    render(<Settings />);
    const editor = screen.getByPlaceholderText("Enter your custom letter body...") as HTMLTextAreaElement;
    expect(editor.value).toContain("We act for {{applicant_name}} in connection with the estate of the late {{deceased_name}}");
    expect(editor.value).not.toContain("You have a right to oppose");
  });

  it("reports checkbox preference persistence near its save controls", () => {
    render(<Settings />);
    fireEvent.click(screen.getByRole("button", { name: "Save Checkbox Preferences" }));
    expect(mocks.update).toHaveBeenCalledWith({ checkboxSize: 0, checkboxBold: 1, checkboxTextOnly: false });
    expect(mocks.toastSuccess).toHaveBeenCalledWith("Checkbox preferences saved");
    expect(screen.getByText("Saved")).toBeTruthy();
  });

  it("persists the relevant-text-only checkbox preference", () => {
    render(<Settings />);
    fireEvent.click(screen.getByRole("switch", { name: "Show relevant text only" }));
    fireEvent.click(screen.getByRole("button", { name: "Save Checkbox Preferences" }));
    expect(mocks.update).toHaveBeenCalledWith({ checkboxSize: 0, checkboxBold: 1, checkboxTextOnly: true });
  });

  it("persists the default-off form-focused Intake preference and explains its workspace effects", async () => {
    Object.defineProperty(globalThis, "ResizeObserver", {
      configurable: true,
      value: class {
        observe() {}
        unobserve() {}
        disconnect() {}
      },
    });
    const activationListener = vi.fn();
    window.addEventListener(FORM_FOCUSED_INTAKE_ACTIVATED_EVENT, activationListener);
    render(<Settings />);
    const control = screen.getByRole("switch", { name: "Use form-focused intake" });
    expect(control.getAttribute("data-state")).toBe("unchecked");
    const explain = screen.getByRole("button", { name: "Explain form-focused intake" });
    fireEvent.focus(explain);
    await waitFor(() => expect(screen.getAllByText("What changes").length).toBeGreaterThan(0));
    expect(screen.getAllByText(/separates Forms into Required and Optional/i).length).toBeGreaterThan(0);
    expect(screen.getAllByText(/never changes form requirements, warnings, or generation/i).length).toBeGreaterThan(0);
    fireEvent.click(control);
    expect(mocks.update).toHaveBeenCalledWith({ formFocusedIntake: true });
    expect(mocks.toastSuccess).toHaveBeenCalledWith("Intake view preference saved");
    expect(window.localStorage.getItem(FORM_FOCUSED_INTAKE_STORAGE_KEY)).toBe("true");
    expect(activationListener).toHaveBeenCalledTimes(1);
    window.removeEventListener(FORM_FOCUSED_INTAKE_ACTIVATED_EVENT, activationListener);
  });

  it("persists the adjacent firm fax document-display checkbox without clearing the saved fax number", () => {
    render(<Settings />);

    fireEvent.change(screen.getByPlaceholderText("604-555-1235 (optional)"), { target: { value: "604-555-1235" } });
    fireEvent.click(screen.getByRole("checkbox", { name: "Include firm fax in documents" }));
    fireEvent.click(screen.getByRole("button", { name: "Save Firm Details" }));

    expect(mocks.update).toHaveBeenCalledWith(expect.objectContaining({
      firmFax: "604-555-1235",
      showFirmFax: false,
    }));
  });

  it("persists the beneficiary-letter-only signing contact preference beside an uploaded DOCX template", () => {
    (settings as any).letterheadDocxName = "firm-letterhead.docx";
    render(<Settings />);

    fireEvent.click(screen.getByRole("checkbox", { name: "Hide address, phone, and email in beneficiary-letter signing blocks" }));

    expect(mocks.update).toHaveBeenCalledWith({ hideBeneficiaryLetterSigningContact: true });
    expect(screen.getByText("Saved")).toBeTruthy();
  });

  it("keeps retry guidance beside a section when its save cannot complete", () => {
    mocks.shouldFail = true;
    render(<Settings />);
    fireEvent.click(screen.getByRole("button", { name: "Save Template" }));
    expect(screen.getByText("Couldn’t save — try again")).toBeTruthy();
    expect(mocks.toastError).toHaveBeenCalledWith("Settings service is unavailable");
  });

  it("requires typed confirmation before deleting the account and clears local authentication state on success", () => {
    render(<Settings />);
    fireEvent.click(screen.getByRole("button", { name: "Delete account" }));
    const destructiveAction = screen.getByRole("button", { name: "Permanently delete account" });
    expect((destructiveAction as HTMLButtonElement).disabled).toBe(true);
    fireEvent.change(screen.getByLabelText(/Type DELETE MY ACCOUNT to confirm/i), { target: { value: "DELETE MY ACCOUNT" } });
    expect((destructiveAction as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(destructiveAction);
    expect(mocks.deleteAccount).toHaveBeenCalledWith({ confirmation: "DELETE MY ACCOUNT", deletionReason: undefined });
    expect(mocks.authSetData).toHaveBeenCalledWith(undefined, null);
    expect(screen.getByText("Account deleted")).toBeTruthy();
  });

  it("uses an accessible confirmation dialog and allows cancellation without calling the destructive mutation", () => {
    render(<Settings />);
    fireEvent.click(screen.getByRole("button", { name: "Delete account" }));
    expect(screen.getByRole("alertdialog", { name: "Delete your account?" })).toBeTruthy();
    const keepAccount = screen.getByRole("button", { name: "Keep account" });
    expect(keepAccount.className).toContain("shadow-");
    expect(keepAccount.className).toContain("sm:min-w-40");
    fireEvent.click(keepAccount);
    expect(screen.queryByRole("alertdialog")).toBeNull();
    expect(mocks.deleteAccount).not.toHaveBeenCalled();
  });

  it("keeps the confirmation dialog open with visible recovery guidance when deletion is blocked", () => {
    mocks.accountDeletionShouldFail = true;
    render(<Settings />);
    fireEvent.click(screen.getByRole("button", { name: "Delete account" }));
    fireEvent.change(screen.getByLabelText(/Type DELETE MY ACCOUNT to confirm/i), { target: { value: "DELETE MY ACCOUNT" } });
    fireEvent.click(screen.getByRole("button", { name: "Permanently delete account" }));
    expect(mocks.deleteAccount).toHaveBeenCalledWith({ confirmation: "DELETE MY ACCOUNT", deletionReason: undefined });
    expect(screen.getByRole("alert").textContent).toMatch(/Remove estate files before deleting this account/i);
    expect(screen.getByRole("alertdialog", { name: "Delete your account?" })).toBeTruthy();
    expect(mocks.authSetData).not.toHaveBeenCalled();
  });

  it("shows a reduced-motion-safe spinner and processing status while account deletion is pending", () => {
    mocks.accountDeletionPending = true;
    render(<Settings />);
    fireEvent.click(screen.getByRole("button", { name: "Delete account" }));
    const destructiveAction = screen.getByRole("button", { name: /Deleting account/i });
    expect((destructiveAction as HTMLButtonElement).disabled).toBe(true);
    expect((screen.getByRole("button", { name: "Keep account" }) as HTMLButtonElement).disabled).toBe(true);
    const status = screen.getByRole("status");
    expect(status.textContent).toMatch(/Deleting account/i);
    const spinner = status.querySelector("svg");
    expect(spinner?.className.baseVal).toContain("motion-reduce:animate-none");
  });

  it("presents an optional anonymous reason survey without accepting free-text account feedback", () => {
    render(<Settings />);
    fireEvent.click(screen.getByRole("button", { name: "Delete account" }));
    const reasonSelector = screen.getByLabelText("Optional reason for deleting account");
    expect(reasonSelector).toBeTruthy();
    expect(reasonSelector.className).toContain("transition-");
    expect(reasonSelector.className).toContain("focus-visible:ring-rose-500");
    expect(reasonSelector.className).toContain("motion-reduce:transition-none");
    expect(screen.getByText(/anonymous category/i)).toBeTruthy();
    expect(screen.queryByRole("textbox", { name: /reason for leaving/i })).toBeNull();
  });

  it("selects a bounded survey category through the refined selector before deletion", () => {
    render(<Settings />);
    fireEvent.click(screen.getByRole("button", { name: "Delete account" }));
    fireEvent.click(screen.getByLabelText("Optional reason for deleting account"));
    fireEvent.click(screen.getByText("Cost or billing considerations"));
    fireEvent.change(screen.getByLabelText(/Type DELETE MY ACCOUNT to confirm/i), { target: { value: "DELETE MY ACCOUNT" } });
    fireEvent.click(screen.getByRole("button", { name: "Permanently delete account" }));
    expect(mocks.deleteAccount).toHaveBeenCalledWith({ confirmation: "DELETE MY ACCOUNT", deletionReason: "cost" });
  });

  it("reveals a local-only Other feedback field without adding free text to deletion input", () => {
    render(<Settings />);
    fireEvent.click(screen.getByRole("button", { name: "Delete account" }));
    fireEvent.click(screen.getByLabelText("Optional reason for deleting account"));
    fireEvent.click(screen.getByText("Another reason"));
    const feedback = screen.getByLabelText(/Additional feedback/i);
    fireEvent.change(feedback, { target: { value: "A private note that must not leave the dialog." } });
    expect(screen.getByText(/not transmitted, stored, logged/i)).toBeTruthy();
    fireEvent.change(screen.getByLabelText(/Type DELETE MY ACCOUNT to confirm/i), { target: { value: "DELETE MY ACCOUNT" } });
    fireEvent.click(screen.getByRole("button", { name: "Permanently delete account" }));
    expect(mocks.deleteAccount).toHaveBeenCalledWith({ confirmation: "DELETE MY ACCOUNT", deletionReason: "other" });
    expect(mocks.deleteAccount.mock.calls[0][0]).not.toHaveProperty("otherFeedback");
  });

  it("uses combobox, listbox, and option semantics with keyboard selection under reduced motion", () => {
    const priorMatchMedia = window.matchMedia;
    const priorScrollIntoView = HTMLElement.prototype.scrollIntoView;
    Object.defineProperty(window, "matchMedia", {
      configurable: true,
      value: vi.fn().mockImplementation(() => ({
        matches: true,
        addEventListener: vi.fn(),
        removeEventListener: vi.fn(),
        addListener: vi.fn(),
        removeListener: vi.fn(),
      })),
    });
    Object.defineProperty(HTMLElement.prototype, "scrollIntoView", { configurable: true, value: vi.fn() });

    try {
      render(<Settings />);
      fireEvent.click(screen.getByRole("button", { name: "Delete account" }));
      const selector = screen.getByLabelText("Optional reason for deleting account");
      expect(selector.getAttribute("role")).toBe("combobox");
      expect(selector.className).toContain("motion-reduce:transition-none");

      fireEvent.keyDown(selector, { key: "ArrowDown" });
      const listbox = screen.getByRole("listbox");
      expect(listbox).toBeTruthy();
      const options = screen.getAllByRole("option");
      expect(options).toHaveLength(6);
      expect(options.map((option) => option.textContent)).toContain("Cost or billing considerations");

      fireEvent.keyDown(options[4], { key: "Enter" });
      expect(selector.textContent).toMatch(/Cost or billing considerations/i);
      fireEvent.change(screen.getByLabelText(/Type DELETE MY ACCOUNT to confirm/i), { target: { value: "DELETE MY ACCOUNT" } });
      fireEvent.click(screen.getByRole("button", { name: "Permanently delete account" }));
      expect(mocks.deleteAccount).toHaveBeenCalledWith({ confirmation: "DELETE MY ACCOUNT", deletionReason: "cost" });
    } finally {
      Object.defineProperty(window, "matchMedia", { configurable: true, value: priorMatchMedia });
      Object.defineProperty(HTMLElement.prototype, "scrollIntoView", { configurable: true, value: priorScrollIntoView });
    }
  });
});
