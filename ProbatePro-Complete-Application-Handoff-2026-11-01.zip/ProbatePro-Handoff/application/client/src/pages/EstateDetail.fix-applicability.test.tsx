/**
 * FormsTab ↔ Optional-form popup wiring (RULES.md Rule 22).
 *
 * Renders the real FormsTab (exported like P19GrantCard) over a proxy-based
 * tRPC auto-mock and exercises the glue the dialog/server tests cannot see:
 *   - the Forms list has exactly TWO groups, Required and Optional, and no
 *     "Not Applicable" group at all
 *   - EVERY Generate button on the tab is enabled — the state that used to
 *     disable them is gone
 *   - the full chain: Optional row → popup → preflight → document.generate
 *     carrying `overrides` and `generateAnyway`
 *   - preview from an Optional row routes through the same popup
 *   - NOTHING is written: estate.update is never called from this tab
 *
 * Nothing here bypasses a gate — generation still routes through preflight
 * client-side, and assertFormApplicable still runs server-side (it honours the
 * explicit `generateAnyway` opt-in rather than being skipped).
 */
import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { describe, expect, it, vi, beforeEach } from "vitest";

vi.setConfig({ testTimeout: 45000 }); // 2026-08-21: jsdom EstateDetail suites breached 15-20s under full-suite worker contention (flake class, memory probatepro-test-flakiness) — headroom, not speed, keeps the gate reproducible

// Same shim as the sibling EstateDetail specs (jsx:"preserve" under esbuild).
(globalThis as any).React = React;

vi.mock("sonner", () => ({
  toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }),
}));

const mocks = vi.hoisted(() => ({
  generateCalls: [] as any[],
  estateUpdateCalls: [] as any[],
  preflightCalls: [] as any[],
  contacts: [] as any[],
  documents: [] as any[],
  settings: { formFocusedIntake: false } as any,
  formFocusedCompletionReports: undefined as any,
}));

// Proxy auto-mock: any trpc.<path>.useQuery returns harmless empty data, any
// useMutation records into per-procedure logs, and useUtils supplies the
// preflight fetch runWithPreflight needs. Keeps this test independent of the
// full FormsTab query surface.
vi.mock("@/lib/trpc", () => {
  const queryDataFor = (key: string): any => {
    if (key === "contact.list") return mocks.contacts;
    if (key === "settings.get") return mocks.settings;
    if (key === "document.list") return mocks.documents;
    if (key === "document.preflightMany") return mocks.formFocusedCompletionReports;
    if (key === "document.versions" || key === "document.retainedFiles") return [];
    if (key === "document.getLetterRecipients") return [];
    if (key === "citation.list" || key === "delivery.list" || key === "delivery.getRecipients") return [];
    return undefined;
  };
  const mutationFor = (key: string, _opts?: any) => ({
    mutate: (input: any) => {
      if (key === "document.generate") mocks.generateCalls.push(input);
    },
    mutateAsync: async (input: any) => {
      if (key === "document.generate") mocks.generateCalls.push(input);
      if (key === "estate.update") mocks.estateUpdateCalls.push(input);
      return { success: true };
    },
    isPending: false,
  });
  function utilsNode(path: string[]): any {
    return new Proxy({} as any, {
      get(_t, prop: string) {
        if (prop === "invalidate" || prop === "setData" || prop === "cancel") return () => undefined;
        if (prop === "fetch") {
          return async (input: any) => {
            const key = path.join(".");
            if (key === "document.preflight") {
              mocks.preflightCalls.push(input);
              return { formCode: input.formCode, ok: true, gaps: [] };
            }
            if (key === "document.preflightMany") return [];
            return undefined;
          };
        }
        return utilsNode([...path, prop]);
      },
    });
  }
  function node(path: string[]): any {
    return new Proxy({} as any, {
      get(_t, prop: string) {
        if (prop === "useQuery") {
          return () => ({ data: queryDataFor(path.join(".")), isLoading: false, error: null });
        }
        if (prop === "useMutation") {
          return (opts?: any) => mutationFor(path.join("."), opts);
        }
        if (prop === "useUtils") return () => utilsNode([]);
        return node([...path, prop]);
      },
    });
  }
  return { trpc: node([]) };
});

const applicant = {
  id: "applicant-1",
  role: "applicant,executor",
  executorStatus: "applying",
  executorRank: "primary",
  name: "Alex Applicant",
};

/** Clean probate estate — P13, P45 and P8 are all Optional (engine says "na"). */
function cleanEstate(overrides: Record<string, unknown> = {}) {
  return {
    id: "estate-1",
    grantType: "grant_of_probate",
    hasWill: 1,
    willType: "physical",
    isElectronicWill: 0,
    testamentaryDocStatus: "none_found",
    beliefLastBcWill: "yes",
    specialCircumstances: "none",
    willFilingType: "physical_original",
    foreignWillStatus: "made_in_bc",
    wesaS58Reliance: "no",
    ordersAffectingWill: "no",
    vsaCertificateResult: "no_notice",
    isMilitaryWill: "no",
    executionIssues: "no_issues",
    willAlterations: "no_alterations",
    willAppearanceIssues: "no",
    referencedDocuments: "no",
    willDocumentsAttached: "yes",
    otherGrantsStatus: "no_other_grants",
    notifyPGT: "no",
    pgtIsApplicant: "no",
    p1NotRequired: 1,
    deceasedDomiciledInBC: "yes",
    deceasedFirstName: "Alex",
    deceasedLastName: "North",
    willDate: "2024-01-15",
    codicilFiles: "[]",
    applicantType: "executor",
    ...overrides,
  };
}

async function renderFormsTab(estateOverrides: Record<string, unknown> = {}) {
  const { FormsTab } = await import("./EstateDetail");
  return render(
    <FormsTab estateId="estate-1" estate={cleanEstate(estateOverrides)} onNavigateToTab={vi.fn()} />,
  );
}

beforeEach(() => {
  mocks.generateCalls.length = 0;
  mocks.estateUpdateCalls.length = 0;
  mocks.preflightCalls.length = 0;
  mocks.contacts = [applicant];
  mocks.documents = [];
  mocks.settings = { formFocusedIntake: false };
  mocks.formFocusedCompletionReports = undefined;
});

describe("two buckets, nothing dead", () => {
  it("renders Required and Optional and no Not Applicable group", async () => {
    await renderFormsTab();
    expect(screen.getByText(/^Required \(\d+\)$/)).toBeTruthy();
    expect(screen.getByText(/^Optional \(\d+\)$/)).toBeTruthy();
    expect(screen.queryByText(/Not Applicable/i)).toBeNull();
    expect(screen.getByTestId("form-row-VSA532")).toBeTruthy();
  });

  it("explains that Optional forms are generatable and leave the intake alone", async () => {
    await renderFormsTab();
    const help = screen.getByTestId("optional-forms-help").textContent || "";
    expect(help).toMatch(/not required by what you have entered in Intake/i);
    expect(help).toMatch(/intake record stays as it is/i);
  });

  it("has no disabled Generate button anywhere on the tab", async () => {
    await renderFormsTab();
    const generateButtons = Array.from(document.querySelectorAll<HTMLButtonElement>('[data-testid^="form-generate-"]'));
    expect(generateButtons.length).toBeGreaterThan(0);
    const disabled = generateButtons.filter((b) => b.disabled).map((b) => b.getAttribute("data-testid"));
    expect(disabled).toEqual([]);
  });

  it("badges an engine-'na' form as Optional, never N/A", async () => {
    await renderFormsTab();
    expect(screen.getByTestId("form-badge-P13").textContent).toBe("Optional");
  });
});

describe("form-focused Intake mode", () => {
  it("replaces legacy status badges and readiness counts with one numeric form-code list", async () => {
    mocks.settings = { formFocusedIntake: true };
    mocks.formFocusedCompletionReports = [
      { formCode: "P1", ok: false, gaps: [], completion: { total: 6, complete: 4 } },
      { formCode: "P13", ok: true, gaps: [], completion: { total: 0, complete: 0 } },
    ];
    await renderFormsTab();

    expect(screen.queryByTestId("form-focused-forms-banner")).toBeNull();
    expect(screen.getByTestId("form-focused-forms-list")).toBeTruthy();
    expect(screen.getByText(/^All forms \(\d+\)$/)).toBeTruthy();
    expect(screen.queryByText(/^Required \(\d+\)$/)).toBeNull();
    expect(screen.queryByText(/^Optional \(\d+\)$/)).toBeNull();
    expect(screen.queryByTestId("form-row-VSA532")).toBeNull();
    expect(document.querySelectorAll("[data-testid^='form-badge-']")).toHaveLength(0);
    expect(document.querySelectorAll("[data-testid^='form-completion-']")).toHaveLength(0);
    expect(screen.getByTestId("form-focused-forms-help").textContent).not.toMatch(/badge|completion/i);

    const listedCodes = Array.from(document.querySelectorAll("[data-testid^='form-row-']"))
      .map((node) => node.getAttribute("data-testid")?.replace("form-row-", ""));
    expect(listedCodes).toEqual([
      "P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10",
      "P11", "P12", "P13", "P15", "P16", "P17", "P26", "P44", "P45", "PGT_INFO",
    ]);
  });
});

describe("shared Forms workflow layout", () => {
  it.each([false, true])("puts P19, P9, and Distribution before Citation Tracker in %s mode without generated-document history", async (formFocusedIntake) => {
    mocks.settings = { formFocusedIntake };
    mocks.documents = [{ id: "doc-1", formCode: "P1", documentName: "Prior notice", createdAt: "2026-10-01", generatedBy: "staff", storageUrl: "https://example.test/P1.docx", format: "docx" }];
    const { unmount } = await renderFormsTab({ p1NotRequired: 0 });

    const citation = screen.getByText("Citation tracker");
    for (const title of ["P19 — Grant Certificate", "P9 — Delivery Records", "Distribution (P10 supplement)"]) {
      const cardTitle = screen.getByText(title);
      expect(cardTitle.compareDocumentPosition(citation) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
    }
    expect(screen.queryByText("Generated Documents")).toBeNull();
    unmount();
  });
});

describe("Optional row → popup → generate", () => {
  it("carries the answers as overrides and the explicit opt-in, writing nothing", async () => {
    await renderFormsTab();

    const generateBtn = screen.getByTestId("form-generate-P13") as HTMLButtonElement;
    expect(generateBtn.disabled).toBe(false);
    fireEvent.click(generateBtn);

    expect(screen.getByTestId("fix-applicability-dialog")).toBeTruthy();

    const tri = screen.getByTestId("fix-question-pgtIsApplicant");
    fireEvent.click(Array.from(tri.querySelectorAll("button")).find((b) => b.textContent === "Yes")!);
    fireEvent.click(screen.getByTestId("fix-confirm"));

    await waitFor(() => expect(mocks.generateCalls.length).toBe(1));
    expect(mocks.generateCalls[0]).toMatchObject({
      estateId: "estate-1",
      formCode: "P13",
      overrides: { pgtIsApplicant: "yes" },
      // These answers make P13 applicable, so no opt-in is claimed.
      generateAnyway: false,
    });
    // The whole point of Rule 22: the intake is untouched.
    expect(mocks.estateUpdateCalls).toEqual([]);
  });

  it("sends the same overrides to preflight, so the gap check judges the same facts", async () => {
    await renderFormsTab();
    fireEvent.click(screen.getByTestId("form-generate-P13"));
    const tri = screen.getByTestId("fix-question-pgtIsApplicant");
    fireEvent.click(Array.from(tri.querySelectorAll("button")).find((b) => b.textContent === "Yes")!);
    fireEvent.click(screen.getByTestId("fix-confirm"));

    await waitFor(() => expect(mocks.preflightCalls.length).toBe(1));
    expect(mocks.preflightCalls[0]).toMatchObject({
      formCode: "P13",
      overrides: { pgtIsApplicant: "yes" },
    });
  });

  it("routes P8 Generate to real co-applicant intake instead of a warning-only optional-form popup", async () => {
    await renderFormsTab();
    fireEvent.click(screen.getByTestId("form-generate-P8"));
    expect(await screen.findByTestId("p8-co-applicant-intake-dialog")).toBeTruthy();
    expect(screen.queryByTestId("fix-applicability-dialog")).toBeNull();
    expect(mocks.generateCalls).toEqual([]);
    expect(mocks.estateUpdateCalls).toEqual([]);
  });

  it("couples willType to isElectronicWill in the overrides that reach the server", async () => {
    await renderFormsTab();
    fireEvent.click(screen.getByTestId("form-generate-P45"));
    const willTypeTri = screen.getByTestId("fix-question-willType");
    fireEvent.click(Array.from(willTypeTri.querySelectorAll("button")).find((b) => b.textContent === "Electronic")!);
    fireEvent.click(screen.getByTestId("fix-confirm"));

    expect(await screen.findByTestId("form-details-dialog")).toBeTruthy();
    fireEvent.click(screen.getByTestId("form-details-generate"));

    await waitFor(() => expect(mocks.generateCalls.length).toBe(1));
    expect(mocks.generateCalls[0]).toMatchObject({
      formCode: "P45",
      selectedContactId: "applicant-1",
    });
    expect(mocks.generateCalls[0].overrides).toMatchObject({
      willType: "electronic",
      isElectronicWill: 1,
    });
    expect(mocks.estateUpdateCalls).toEqual([]);
  });

  it("routes every optional form with document-facing details through the same popup controls", async () => {
    await renderFormsTab();

    fireEvent.click(screen.getByTestId("form-generate-P16"));
    expect(screen.getByTestId("fix-applicability-dialog")).toBeTruthy();
    fireEvent.click(screen.getByTestId("fix-confirm"));

    expect(await screen.findByTestId("form-details-dialog")).toBeTruthy();
    expect(screen.getByTestId("form-details-date")).toBeTruthy();
    expect(screen.queryByText("Go to Forms")).toBeNull();
  });

  it("routes optional P44 through the signature details before generation, retaining the lawyer selection", async () => {
    await renderFormsTab();

    fireEvent.click(screen.getByTestId("form-generate-P44"));
    expect(screen.getByTestId("fix-applicability-dialog")).toBeTruthy();

    fireEvent.click(screen.getByTestId("fix-confirm"));

    expect(await screen.findByTestId("form-details-dialog")).toBeTruthy();
    fireEvent.click(screen.getByTestId("form-details-signatory"));
    fireEvent.click(screen.getByRole("option", { name: "Lawyer" }));
    fireEvent.click(screen.getByTestId("form-details-generate"));

    await waitFor(() => expect(mocks.generateCalls).toContainEqual(expect.objectContaining({
      estateId: "estate-1",
      formCode: "P44",
      signatoryType: "lawyer",
    })));
    expect(mocks.estateUpdateCalls).toEqual([]);
  });
});

describe("Optional row → popup → preview", () => {
  it("routes the eye button through the same popup and preserves the preview intent", async () => {
    await renderFormsTab();
    const previewBtn = screen.getByLabelText("Preview P13");
    fireEvent.click(previewBtn);

    expect(screen.getByTestId("fix-applicability-dialog")).toBeTruthy();
    const confirm = screen.getByTestId("fix-confirm") as HTMLButtonElement;
    expect(confirm.textContent).toBe("Preview");

    fireEvent.click(confirm);
    // Preview opens the modal rather than generating a stored document.
    await waitFor(() => expect(mocks.preflightCalls.length).toBe(1));
    expect(mocks.generateCalls.length).toBe(0);
    expect(mocks.estateUpdateCalls).toEqual([]);
  });
});
