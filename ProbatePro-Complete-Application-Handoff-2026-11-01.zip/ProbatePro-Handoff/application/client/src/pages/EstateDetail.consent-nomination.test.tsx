import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

(globalThis as any).React = React;
vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }) }));

const contacts = [
  { id: "applicant-1", name: "Alex Applicant", role: "applicant,executor", executorStatus: "applying", executorRank: "primary", isPredeceased: 0 },
  { id: "beneficiary-1", name: "Blair Beneficiary", role: "beneficiary", relationship: "child", share: "0", shareType: "percentage", isPredeceased: 0 },
];
let distribution: any;

vi.mock("@/lib/trpc", () => {
  const mutation = (_path: string, options?: any) => ({
    mutateAsync: async (input: any) => {
      const result = { url: "/consent.docx", filename: "CONSENT_NOMINATION.docx", format: "docx" };
      await options?.onSuccess?.(result, input, undefined);
      return result;
    },
    mutate: () => undefined,
    isPending: false,
  });
  function node(path: string[]): any {
    return new Proxy({}, {
      get(_target, property: string) {
        if (property === "useQuery") return () => {
          const key = path.join(".");
          if (key === "contact.list") return { data: contacts, isLoading: false, error: null };
          if (key === "document.getLetterRecipients") return { data: [{ contactId: "beneficiary-1", name: "Blair Beneficiary", address: "", isBeneficiary: true }], isLoading: false, error: null };
          if (key === "distribution.compute") return { data: distribution, isLoading: false, error: null };
          if (["document.list", "document.versions", "document.retainedFiles", "citation.list", "delivery.list", "delivery.getRecipients"].includes(key)) return { data: [], isLoading: false, error: null };
          return { data: undefined, isLoading: false, error: null };
        };
        if (property === "useMutation") return (options: any) => mutation(path.join("."), options);
        if (property === "useUtils") return () => new Proxy({}, { get: () => () => undefined });
        return node([...path, property]);
      },
    });
  }
  return { trpc: node([]) };
});

describe("Consent and Nomination action", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    distribution = undefined;
  });

  it("appears beside beneficiary letters and collects only the source template’s per-document variables", async () => {
    const { FormsTab } = await import("./EstateDetail");
    render(<FormsTab estateId="estate-consent" estate={{ id: "estate-consent", grantType: "grant_of_probate", hasWill: 1, willStatus: "will", deceasedFirstName: "Alex", deceasedLastName: "North", p1NotRequired: 1 }} onNavigateToTab={vi.fn()} />);

    const formsCard = screen.getByText("Individual Forms").closest("[data-slot='card']")!;
    const recipientDocumentsCard = screen.getByText("Recipient documents").closest("[data-slot='card']")!;
    expect(formsCard.compareDocumentPosition(recipientDocumentsCard) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();

    fireEvent.click(await screen.findByRole("button", { name: "Consent", exact: true }));
    expect(screen.getByRole("heading", { name: "Consent and Nomination" })).toBeTruthy();
    expect(screen.getByLabelText("Nominated personal representative")).toBeTruthy();
    expect(screen.getByLabelText("Nominee’s relationship to the signer")).toBeTruthy();
    expect(screen.getByText(/I nominate my \[relationship\], \[nominee\]/i)).toBeTruthy();
    expect(screen.getByLabelText("Signer’s beneficiary percentage")).toBeTruthy();
    expect(screen.getByText(/does not save or alter beneficiary shares/i)).toBeTruthy();
  });

  it("prefills a beneficiary's sole one-half residue share instead of a legacy zero", async () => {
    distribution = {
      shares: [{
        contactId: "beneficiary-1",
        shareDescription: "Per stirpes share of ½ residue (WESA s.24)",
        estimatedValueCents: 350_000_00,
        isComputed: true,
      }],
    };
    const { FormsTab } = await import("./EstateDetail");
    render(<FormsTab estateId="estate-half-residue" estate={{ id: "estate-half-residue", grantType: "admin_no_will", hasWill: 0, willStatus: "no_will", deceasedFirstName: "Alex", deceasedLastName: "North", p1NotRequired: 1 }} onNavigateToTab={vi.fn()} />);

    fireEvent.click(await screen.findByRole("button", { name: "Consent", exact: true }));
    expect((screen.getByLabelText("Signer’s beneficiary percentage") as HTMLInputElement).value).toBe("50");
    expect(screen.getByText(/one-half of the residue/i)).toBeTruthy();
  });

  it("appears beside beneficiary letters and collects the recorded administrator for the administrator-consent template", async () => {
    const { FormsTab } = await import("./EstateDetail");
    render(<FormsTab estateId="estate-admin-consent" estate={{ id: "estate-admin-consent", grantType: "admin_no_will", hasWill: 0, willStatus: "no_will", deceasedFirstName: "Alex", deceasedLastName: "North", p1NotRequired: 1 }} onNavigateToTab={vi.fn()} />);

    fireEvent.click(await screen.findByRole("button", { name: "Consent to Appoint" }));
    expect(screen.getByRole("heading", { name: "Consent to Appointment of an Administrator" })).toBeTruthy();
    expect(screen.getByLabelText("Administrator or applying applicant to be appointed")).toBeTruthy();
    expect(screen.getByText(/states that the deceased died intestate/i)).toBeTruthy();
    expect(screen.queryByLabelText("Signer’s beneficiary percentage")).toBeNull();
  });

  it("never offers deceased contacts in consent selectors", async () => {
    contacts.push({ id: "deceased-administrator", name: "Deceased Administrator", role: "administrator", executorStatus: "deceased", isPredeceased: 1 });
    const { FormsTab } = await import("./EstateDetail");
    render(<FormsTab estateId="estate-living-consents" estate={{ id: "estate-living-consents", grantType: "admin_no_will", hasWill: 0, willStatus: "no_will", deceasedFirstName: "Alex", deceasedLastName: "North", p1NotRequired: 1 }} onNavigateToTab={vi.fn()} />);
    fireEvent.click(await screen.findByRole("button", { name: "Consent", exact: true }));
    fireEvent.click(screen.getByLabelText("Nominated personal representative"));
    expect(screen.queryByRole("option", { name: "Deceased Administrator" })).toBeNull();
  });
});
