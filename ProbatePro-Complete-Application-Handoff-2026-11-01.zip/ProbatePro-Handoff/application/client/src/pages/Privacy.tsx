import React from "react";
import { Scale } from "lucide-react";
import { Link } from "wouter";
import { Seo } from "@/components/Seo";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-[#fafafa] text-[#1a1a2e]">
      <Seo
        title="Privacy Policy | ProbatePro"
        description="Privacy Policy for the ProbatePro British Columbia probate workflow application."
        path="/privacy"
        index
      />
      {/* Navigation */}
      <nav className="fixed top-0 inset-x-0 z-50 backdrop-blur-md bg-[#fafafa]/80 border-b border-black/[0.04]">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Scale className="h-5 w-5 text-[#2d3561]" />
            <span className="font-semibold text-[15px] tracking-tight text-[#1a1a2e]">
              ProbatePro
            </span>
          </div>
          <Link href="/" className="text-sm text-[#4a4a5a] transition-colors hover:text-[#2d3561]">Back</Link>
        </div>
      </nav>

      {/* Content */}
      <main className="pt-28 pb-16 px-6">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold tracking-tight mb-2">Privacy Policy</h1>
          <p className="text-sm text-[#4a4a5a]/60 mb-10">Last updated: August 5, 2026</p>

          <div className="prose prose-sm max-w-none text-[#2a2a3a] space-y-6 [&_h2]:text-lg [&_h2]:font-semibold [&_h2]:mt-8 [&_h2]:mb-3 [&_h3]:text-base [&_h3]:font-medium [&_h3]:mt-4 [&_h3]:mb-2 [&_p]:leading-relaxed [&_ul]:space-y-1 [&_li]:leading-relaxed">
            <p>
              Kairo ("Company," "we," "us," or "our") is committed to protecting the privacy and security of your personal information. This Privacy Policy explains how we collect, use, disclose, and safeguard information when you use the ProbatePro application at probate-pro.com (the "Service"), in compliance with the Personal Information Protection and Electronic Documents Act (PIPEDA) and British Columbia's Personal Information Protection Act (PIPA).
            </p>

            <h2>1. Information We Collect</h2>

            <h3>1.1 Account Information</h3>
            <p>When you create an account or sign in, we collect:</p>
            <ul className="list-disc pl-6">
              <li>Full name</li>
              <li>Email address</li>
              <li>Authentication credentials (managed through our OAuth provider)</li>
            </ul>

            <h3>1.2 Estate and Probate Data</h3>
            <p>In the course of using the Service, you may provide information about estates, including:</p>
            <ul className="list-disc pl-6">
              <li>Deceased person's name, date of death, address, and personal identifiers</li>
              <li>Beneficiary names, addresses, and contact information</li>
              <li>Executor and administrator details</li>
              <li>Asset and liability information</li>
              <li>Will and codicil documents (uploaded files)</li>
              <li>Court file numbers and registry information</li>
            </ul>

            <h3>1.3 Automatically Collected Information</h3>
            <p>We automatically collect certain technical information when you use the Service:</p>
            <ul className="list-disc pl-6">
              <li>IP address and approximate geographic location</li>
              <li>Browser type and version</li>
              <li>Device information and operating system</li>
              <li>Pages visited and features used within the Service</li>
              <li>Date and time of access</li>
              <li>Referring URL</li>
            </ul>

            <h2>2. How We Use Your Information</h2>
            <p>We use the information we collect for the following purposes:</p>
            <ul className="list-disc pl-6">
              <li><strong>Service delivery:</strong> To provide, maintain, and improve the Service, including generating probate documents, tracking deadlines, and managing estate files</li>
              <li><strong>AI-assisted features:</strong> To provide the optional estate assistant (chat) and AI-assisted document import, which use third-party artificial-intelligence models to generate responses and drafting proposals from the content you provide</li>
              <li><strong>Authentication:</strong> To verify your identity and manage your account access</li>
              <li><strong>Communication:</strong> To send you service-related notifications, updates, and support responses</li>
              <li><strong>Security:</strong> To detect, prevent, and respond to fraud, abuse, and security incidents</li>
              <li><strong>Legal compliance:</strong> To comply with applicable laws, regulations, and legal processes</li>
              <li><strong>Service improvement:</strong> To analyze usage patterns and improve the functionality and user experience of the Service</li>
            </ul>

            <h2>3. Authority for Processing</h2>
            <p>Under PIPEDA and BC PIPA, we collect, use, and disclose personal information only for disclosed purposes that are appropriate in the circumstances, with consent where required or as otherwise permitted or required by law:</p>
            <ul className="list-disc pl-6">
              <li><strong>Consent:</strong> Where consent is required, we seek consent appropriate to the sensitivity of the information and the stated purpose. Consent may be withdrawn on reasonable notice, subject to legal or contractual restrictions and reasonable consequences we explain to you</li>
              <li><strong>Providing the requested Service:</strong> We process information reasonably necessary to authenticate users, manage estate files, generate requested documents, secure the Service, and perform the other purposes disclosed in this Policy</li>
              <li><strong>Permitted or required by law:</strong> We may process information without consent only where PIPEDA, BC PIPA, a court order, or another applicable law permits or requires it</li>
            </ul>

            <h2>4. Information Sharing and Disclosure</h2>
            <p>We do not sell, rent, or trade your personal information. We may share your information only in the following circumstances:</p>
            <ul className="list-disc pl-6">
              <li><strong>Service providers:</strong> We use third-party providers for cloud hosting, authentication, database hosting, file storage, and infrastructure. They may process information only to supply the contracted service and must protect it under the applicable agreement. Contact the Privacy Officer for the current provider list and processing locations</li>
              <li><strong>AI model providers:</strong> When you use the optional estate assistant (chat) or AI-assisted document import, the content involved — your messages, files you upload or drop into those features, and relevant estate, contact, inventory, readiness, and generated-document data from your estate file — is transmitted to third-party artificial-intelligence model providers, accessed through our hosting platform's built-in AI service, to generate the response or proposal. Where these features read structured records from your estate file, we limit the fields sent: social insurance numbers, banking details, and internal file identifiers are excluded from those records. However, content you type, files you upload or drop, and documents you ask the assistant to read are transmitted as full text and may contain any information those documents hold — including account details that appear on generated court forms. No estate content is sent to AI model providers unless you use these features</li>
              <li><strong>Legal requirements:</strong> We may disclose your information if required by law, court order, or governmental regulation, or if we believe disclosure is necessary to protect our rights, your safety, or the safety of others</li>
              <li><strong>Business transfers:</strong> In the event of a merger, acquisition, or sale of assets, your information may be transferred as part of the transaction. We will notify you of any such change in ownership or control</li>
              <li><strong>With your consent:</strong> We may share your information with third parties when you have given us explicit consent to do so</li>
            </ul>

            <h2>5. Data Storage and Security</h2>
            <p>
              Information is stored and processed using the service providers and processing locations applicable to the Service. Depending on those arrangements, information may be processed outside British Columbia or Canada and may be subject to the laws of another jurisdiction. Contact the Privacy Officer for the current provider list and locations. Before a new production file-storage provider is enabled, we review its jurisdiction, security, access, retention, backup-destruction, and permanent-destruction terms. We use technical and organizational safeguards including:
            </p>
            <ul className="list-disc pl-6">
              <li>Encryption of data in transit (TLS/SSL)</li>
              <li>Server-side encryption at rest for stored files (enforced on the production storage bucket and confirmed on every upload)</li>
              <li>Access controls and authentication requirements</li>
              <li>Regular security assessments and monitoring</li>
              <li>Access-controlled file storage with a durable ownership and disposition record</li>
              <li>Session management with secure, httpOnly cookies</li>
            </ul>
            <p>
              While we take reasonable precautions to protect your information, no method of electronic storage or transmission is completely secure. We cannot guarantee absolute security of your data.
            </p>

            <h2>6. Data Retention</h2>
            <p>
              We retain personal information only while it serves the disclosed purpose or remains necessary for a legal or business purpose. If an individual's personal information is used to make a decision that directly affects that individual, BC PIPA section 35 requires it to be retained for at least one year after that use. Estate and law-practice records may require longer retention under the responsible firm's policy, a legal hold, a production obligation, or another legal or business requirement.
            </p>
            <ul className="list-disc pl-6">
              <li>Removing or replacing an uploaded client-file record removes it from the active interface but retains it with the estate file until authorized file disposition</li>
              <li>An estate file may be permanently destroyed only after an authorized user confirms either that it was created in error and never became a client file, or that the approved retention period has ended and no legal or business purpose requires continued retention</li>
              <li>The Service keeps a durable destruction audit and retries provider deletion until complete; provider backup and replica destruction remains governed by the approved provider agreement</li>
              <li>Temporary generated exports and generated images are scheduled for deletion 24 hours after creation under the current lifecycle configuration; a failed provider deletion is retried until it completes and can extend actual destruction beyond that schedule</li>
              <li>Account closure does not override legal or business retention requirements. Contact the Privacy Officer to request closure, export, or disposition review</li>
            </ul>

            <h2>7. Your Rights</h2>
            <p>Under PIPEDA and BC PIPA, you have the following rights regarding your personal information:</p>
            <ul className="list-disc pl-6">
              <li><strong>Access:</strong> You may request access to the personal information we hold about you</li>
              <li><strong>Correction:</strong> You may request correction of inaccurate or incomplete personal information</li>
              <li><strong>Deletion:</strong> You may request deletion of your personal information, subject to legal retention requirements</li>
              <li><strong>Withdrawal of consent:</strong> You may withdraw your consent to our collection, use, or disclosure of your personal information at any time, subject to legal or contractual restrictions. Withdrawal of consent may limit your ability to use the Service</li>
              <li><strong>Data portability:</strong> You may request a copy of your data in a structured, commonly used format</li>
              <li><strong>Complaint:</strong> You have the right to file a complaint with the Office of the Privacy Commissioner of Canada or the Office of the Information and Privacy Commissioner for British Columbia</li>
            </ul>
            <p>
              To exercise any of these rights, contact us using the information in Section 12. We respond to formal access requests within the period required by applicable law; under BC PIPA the ordinary period is 30 days, subject to permitted extensions. Other requests are addressed as reasonably practicable.
            </p>

            <h2>8. Cookies and Tracking</h2>
            <p>
              We use essential cookies to maintain your authentication session and ensure the Service functions correctly. These cookies are strictly necessary and cannot be disabled without affecting Service functionality. We do not use advertising cookies or third-party tracking cookies for marketing purposes.
            </p>
            <p>We may use minimal analytics to understand Service usage patterns. This data is collected in aggregate form and does not identify individual users.</p>

            <h2>9. Third-Party Services</h2>
            <p>The Service integrates with the following third-party services:</p>
            <ul className="list-disc pl-6">
              <li><strong>Cloud infrastructure:</strong> For hosting, data storage, and file storage</li>
              <li><strong>Authentication provider:</strong> For secure sign-in and account management</li>
              <li><strong>AI model providers:</strong> The optional estate assistant and AI-assisted document import send the content described in Section 4 to third-party AI model providers, accessed through our hosting platform's built-in AI service, to generate responses and drafting proposals</li>
            </ul>
            <p>
              We assess the contractual and security terms applicable to providers that process information for the Service. Contact the Privacy Officer for the current provider list, processing locations, and information about applicable safeguards.
            </p>

            <h2>10. Children's Privacy</h2>
            <p>
              The Service is not directed to individuals under the age of 19 (the age of majority in British Columbia). We do not knowingly collect personal information from children. If we become aware that we have collected personal information from a child without appropriate consent, we will take steps to delete that information promptly.
            </p>

            <h2>11. Changes to This Policy</h2>
            <p>
              We may update this Privacy Policy from time to time to reflect changes in our practices, technology, legal requirements, or other factors. When we make material changes, we will update the "Last updated" date and provide notice through the Service. Your continued use of the Service after any changes constitutes acceptance of the revised Privacy Policy.
            </p>

            <h2>12. Contact Us</h2>
            <p>
              If you have questions, concerns, or requests regarding this Privacy Policy or our privacy practices, please contact our Privacy Officer:
            </p>
            <p>
              <strong>Kairo — Privacy Officer</strong><br />
              Email: nick@kairo.chat<br />
              Website: probate-pro.com
            </p>
            <p>
              You may also contact the Office of the Privacy Commissioner of Canada at <a href="https://www.priv.gc.ca" className="text-[#2d3561] underline" target="_blank" rel="noopener noreferrer">www.priv.gc.ca</a> or the Office of the Information and Privacy Commissioner for British Columbia at <a href="https://www.oipc.bc.ca" className="text-[#2d3561] underline" target="_blank" rel="noopener noreferrer">www.oipc.bc.ca</a>.
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-black/[0.04]">
        <div className="max-w-6xl mx-auto flex items-center justify-between text-sm text-[#4a4a5a]/60">
          <div className="flex items-center gap-2">
            <Scale className="h-4 w-4" />
            <span>&copy; {new Date().getFullYear()} Kairo</span>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/terms" className="hover:text-[#2d3561] transition-colors">Terms</Link>
            <Link href="/privacy" className="hover:text-[#2d3561] transition-colors">Privacy</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
