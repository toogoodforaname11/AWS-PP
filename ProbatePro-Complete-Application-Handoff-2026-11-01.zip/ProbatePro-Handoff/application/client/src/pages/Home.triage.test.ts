import { describe, expect, it } from "vitest";
import { resolveDashboardNextAction } from "./Home";

const baseEstate = {
  id: "estate-1",
  status: "incomplete",
  willStatus: "will",
  deceasedFirstName: "Morgan",
  deceasedLastName: "Lee",
  dateOfDeath: "2026-01-01",
  registry: "Victoria",
  domicileCity: "Victoria",
};

describe("resolveDashboardNextAction", () => {
  it("keeps the first unconfirmed legal intake fact ahead of later workflow actions", () => {
    expect(resolveDashboardNextAction({ ...baseEstate, willStatus: "unknown" })).toEqual({ label: "Confirm will status", tab: "intake" });
    expect(resolveDashboardNextAction({ ...baseEstate, willStatus: "will", dateOfDeath: "" })).toEqual({ label: "Record date of death", tab: "intake" });
  });

  it("directs otherwise complete active files to the existing readiness and form-preparation path", () => {
    expect(resolveDashboardNextAction(baseEstate)).toEqual({ label: "Review readiness", tab: "readiness" });
    expect(resolveDashboardNextAction({ ...baseEstate, status: "ready_to_file" })).toEqual({ label: "Review ready-to-file checklist", tab: "readiness" });
  });
});
