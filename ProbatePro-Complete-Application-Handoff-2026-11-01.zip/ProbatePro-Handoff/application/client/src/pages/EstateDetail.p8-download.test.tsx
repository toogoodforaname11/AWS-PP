/** P8's actual dialog handoff must finish with a download or a visible error. */
import React from "react";
import { fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.setConfig({ testTimeout: 45000 });
(globalThis as any).React = React;
vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), info: vi.fn() }) }));
import { toast } from "sonner";

const state = vi.hoisted(() => ({
  estate: {} as any,
  contacts: [] as any[],
  documents: [] as any[],
  generateCalls: [] as any[],
  preflightCalls: [] as any[],
  estateWrites: [] as any[],
  contactCreates: [] as any[],
  generateResponse: {} as any,
  generateError: null as Error | null,
  preflightError: null as Error | null,
  deferContactRefresh: false,
  /** document.generate's POST delivery (Nick, 2026-10-20), never a GET URL. */
  delivery: {
    method: "POST",
    action: "/api/download/form",
    fields: { estateId: "estate-19", formCode: "P8", documentId: "doc_p8_1", signatoryType: "lawyer", signatureDate: "2026-09-06", deponentId: "avery", selectedContactId: "avery" },
  },
}));

vi.mock("@/lib/trpc", () => {
  const queryData = (key: string): any => {
    if (key === "contact.list") return state.contacts;
    if (key === "document.list") return state.documents;
    if (key === "document.preview") return { sections: [] };
    if (key === "settings.get") return { lawyerName: "Firm Lawyer", firmCity: "Victoria" };
    return ["document.versions", "document.retainedFiles", "document.getLetterRecipients", "citation.list", "delivery.list", "delivery.getRecipients"].includes(key) ? [] : undefined;
  };
  const mutation = (key: string, options?: any) => {
    const mutateAsync = async (input: any) => {
      try {
        if (key === "estate.update") state.estateWrites.push(input);
        if (key === "contact.create") {
          state.contactCreates.push(input);
          const created = { ...input, id: "new-p8-coapplicant" };
          if (!state.deferContactRefresh) state.contacts = [...state.contacts, created];
          await options?.onSuccess?.({ id: created.id }, input, undefined);
          return { id: created.id };
        }
        if (key === "document.generate") {
          state.generateCalls.push(input);
          if (state.generateError) throw state.generateError;
        }
        const result = key === "document.generate" ? state.generateResponse : { revision: 2 };
        // Match TanStack: a missing-link/download exception in onSuccess must
        // reject mutateAsync, invoke onError and leave a retryable continuation.
        await options?.onSuccess?.(result, input, undefined);
        return result;
      } catch (error) {
        await options?.onError?.(error, input, undefined);
        throw error;
      }
    };
    return { mutateAsync, mutate: (input: any) => { void mutateAsync(input).catch(() => undefined); }, isPending: false };
  };
  const utils = (path: string[]): any => new Proxy({}, {
    get(_target, property: string): any {
      if (property === "setData") return (_input: unknown, updater: any) => {
        if (path.join(".") === "contact.list") {
          state.contacts = typeof updater === "function" ? updater(state.contacts) : updater;
        }
      };
      if (["invalidate", "cancel"].includes(property)) return () => undefined;
      if (property === "getData") return () => state.estate;
      if (property === "fetch") return async (input: any) => {
        if (path.join(".") === "estate.get") return state.estate;
        if (path.join(".") !== "document.preflight") return [];
        state.preflightCalls.push(input);
        if (state.preflightError) throw state.preflightError;
        const { checkFormRequirements } = await import("@shared/formRequirements");
        const { p8ApplyingCoApplicants } = await import("@shared/types");
        const primary = state.documents.find((doc) => ["P3", "P4", "P5", "P6", "P7"].includes(doc.formCode));
        const resolved = p8ApplyingCoApplicants(state.contacts, primary?.deponentId);
        if (resolved.coApplicants.length === 0) {
          throw new Error("Cannot generate P8: add an applying co-applicant on the Contacts tab, including name, address, occupation and relationship, then try again.");
        }
        return checkFormRequirements("P8", {
          estate: state.estate, contacts: state.contacts, inventory: [], liabilities: [], deliveries: [],
          // Mirrors document.preflight's single-form stamp (checkPreflightWithApplicability):
          // only the single-form path scopes the P8 trio to the chosen co-applicant.
          renderContext: { selectedContactId: input.selectedContactId, p8SingleFormDeponentId: input.selectedContactId, primaryAffidavit: primary ?? null },
        } as any);
      };
      return utils([...path, property]);
    },
  });
  const node = (path: string[]): any => new Proxy({}, {
    get(_target, property: string): any {
      if (property === "useQuery") return () => ({ data: queryData(path.join(".")), isLoading: false, error: null });
      if (property === "useMutation") return (options: any) => mutation(path.join("."), options);
      if (property === "useUtils") return () => utils([]);
      return node([...path, property]);
    },
  });
  return { trpc: node([]) };
});

const jordan = {
  id: "jordan", name: "Jordan Ellis Calder-Quay", role: "applicant,executor", executorStatus: "applying",
  executorRank: "primary", applicantKind: "individual", occupation: "Teacher", relationship: "child",
  residentialAddress: "10 Main Street, Victoria, BC", residenceStreet: "10 Main Street",
  residenceCity: "Victoria", residenceProvince: "BC", residenceCountry: "Canada",
};
const avery = { ...jordan, id: "avery", name: "Avery Calder-Quay", executorRank: "alternate", occupation: "Engineer" };
const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
/** Each same-tab form POST the page submits; the browser's attachment download follows it. */
const downloads: Array<{ method: string; action: string | null; fields: Record<string, string> }> = [];
const posted = (fields: Record<string, string>) => ({ method: "post", action: "/api/download/form", fields: { ...fields, attemptId: expect.stringMatching(UUID_V4) } });

beforeEach(() => {
  vi.clearAllMocks();
  state.estate = {
    id: "estate-19", revision: 1, deceasedFirstName: "Helen Rose", deceasedLastName: "Calder-Quay",
    grantType: "grant_of_probate", willStatus: "will", hasWill: 1, registry: "Victoria",
    deceasedDomiciledInBC: "yes", deceasedOrdinarilyResidentInBC: "yes", oathType: "affirmed", domicileCity: "Victoria",
  };
  state.contacts = [jordan, avery];
  state.documents = [];
  state.generateCalls = [];
  state.preflightCalls = [];
  state.estateWrites = [];
  state.contactCreates = [];
  state.generateError = null;
  state.preflightError = null;
  state.deferContactRefresh = false;
  state.generateResponse = { id: "doc_p8_1", delivery: state.delivery, filename: "P8_Avery_Calder-Quay.docx", format: "docx" };
  downloads.length = 0;
  vi.spyOn(HTMLFormElement.prototype, "submit").mockImplementation(function (this: HTMLFormElement) {
    downloads.push({ method: this.method, action: this.getAttribute("action"), fields: Object.fromEntries(new FormData(this)) as Record<string, string> });
  });
});
afterEach(() => vi.restoreAllMocks());

async function mountForms() {
  const { FormsTab } = await import("./EstateDetail");
  render(<FormsTab estateId="estate-19" estate={state.estate} onNavigateToTab={vi.fn()} />);
}

async function openCoApplicant() {
  await mountForms();
  fireEvent.click(within(screen.getByTestId("form-row-P8")).getByRole("button", { name: "Generate", exact: true }));
  await waitFor(() => expect(screen.getByTestId("form-details-generate")).toBeTruthy());
  expect(screen.getByRole("dialog").textContent).toContain("Avery Calder-Quay");
  fireEvent.click(screen.getByTestId("form-details-generate"));
}

async function openDraftWarning() {
  await openCoApplicant();
  await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());
  const proceed = screen.getByTestId("pre-generate-proceed") as HTMLButtonElement;
  expect(proceed.disabled).toBe(false);
  expect(screen.getByTestId("pre-generate-dialog").textContent).toMatch(/primary.*affidavit/i);
  expect(state.preflightCalls[0]).toMatchObject({ formCode: "P8", selectedContactId: "avery" });
  return proceed;
}

describe("P8 download feedback", () => {
  it("single applicant cannot proceed without real co-applicant facts and receives a durable visible error", async () => {
    state.contacts = [jordan];
    await mountForms();
    fireEvent.click(screen.getByTestId("form-generate-P8"));
    expect(await screen.findByTestId("p8-co-applicant-intake-dialog")).toBeTruthy();
    fireEvent.click(screen.getByTestId("p8-save-co-applicant"));
    expect((await screen.findByTestId("p8-co-applicant-error")).textContent).toMatch(/name.*address.*occupation.*relationship/i);
    expect(screen.getByLabelText("Full legal name").getAttribute("aria-invalid")).toBe("true");
    expect(screen.getByLabelText("Residential address").getAttribute("aria-invalid")).toBe("true");
    expect(state.contactCreates).toHaveLength(0);
    expect(state.generateCalls).toHaveLength(0);
    expect(downloads).toHaveLength(0);
    expect(screen.getByTestId("p8-co-applicant-intake-dialog")).toBeTruthy();
  });

  it("single applicant collects a real co-applicant, then proceeds to the selected P8 details without inventing facts", async () => {
    state.contacts = [jordan];
    await mountForms();
    fireEvent.click(screen.getByTestId("form-generate-P8"));
    expect(await screen.findByTestId("p8-co-applicant-intake-dialog")).toBeTruthy();
    fireEvent.change(screen.getByLabelText("Full legal name"), { target: { value: "Morgan Calder-Quay" } });
    fireEvent.change(screen.getByLabelText("Residential address"), { target: { value: "99 Oak Lane, Victoria, BC" } });
    fireEvent.change(screen.getByLabelText("Occupation"), { target: { value: "Nurse" } });
    fireEvent.change(screen.getByLabelText("Relationship to deceased"), { target: { value: "child" } });
    fireEvent.click(screen.getByTestId("p8-save-co-applicant"));
    await waitFor(() => expect(state.contactCreates).toHaveLength(1));
    expect(state.contactCreates[0]).toMatchObject({
      role: "executor,applicant", executorStatus: "applying", name: "Morgan Calder-Quay",
      residentialAddress: "99 Oak Lane, Victoria, BC", occupation: "Nurse", relationship: "child",
    });
    expect(await screen.findByTestId("form-details-generate")).toBeTruthy();
    expect(state.generateCalls).toHaveLength(0);
    expect(state.estateWrites).toHaveLength(0);
  });

  it("keeps a newly saved co-applicant selected when the contact refresh arrives after the P8 details handoff", async () => {
    state.contacts = [jordan];
    state.deferContactRefresh = true;
    await mountForms();
    fireEvent.click(screen.getByTestId("form-generate-P8"));
    expect(await screen.findByTestId("p8-co-applicant-intake-dialog")).toBeTruthy();
    fireEvent.change(screen.getByLabelText("Full legal name"), { target: { value: "Morgan Calder-Quay" } });
    fireEvent.change(screen.getByLabelText("Residential address"), { target: { value: "99 Oak Lane, Victoria, BC" } });
    fireEvent.change(screen.getByLabelText("Occupation"), { target: { value: "Nurse" } });
    fireEvent.change(screen.getByLabelText("Relationship to deceased"), { target: { value: "child" } });
    fireEvent.click(screen.getByTestId("p8-save-co-applicant"));

    await waitFor(() => expect(screen.getByTestId("form-details-single-deponent").textContent).toContain("Morgan Calder-Quay"));
    fireEvent.click(screen.getByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(state.generateCalls).toEqual([expect.objectContaining({ formCode: "P8", deponentId: "new-p8-coapplicant" })]);
  });

  it("Avery downloads on the first confirmation with no primary history after the draft warning", async () => {
    // Another co-applicant's missing preamble must not affect Avery's draft.
    state.contacts.push({ ...avery, id: "other", name: "", residentialAddress: "", residenceStreet: "", residenceCity: "", residenceProvince: "", residenceCountry: "", occupation: "" });
    await mountForms();
    fireEvent.click(within(screen.getByTestId("form-row-P8")).getAllByRole("button", { name: "Generate", exact: true })[0]);
    fireEvent.click(await screen.findByTestId("form-details-generate"));
    await waitFor(() => expect(screen.getByTestId("pre-generate-dialog")).toBeTruthy());
    expect(screen.getByTestId("pre-generate-dialog").textContent).not.toMatch(/Co-applicant deponent (name|address|occupation)/);
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toEqual([posted(state.delivery.fields)]));
    expect(screen.getByTestId("p8-download-recovery").textContent).toMatch(/Form P8 is ready/i);
    const retry = screen.getByTestId("p8-download-retry") as HTMLButtonElement;
    fireEvent.click(retry);
    expect(downloads).toHaveLength(2);
    // Same delivery, fresh attemptId; a second click inside the window posts nothing.
    expect(downloads[1]).toEqual(posted(state.delivery.fields));
    expect(downloads[1].fields.attemptId).not.toBe(downloads[0].fields.attemptId);
    expect(retry.disabled).toBe(true);
    fireEvent.click(retry);
    expect(downloads).toHaveLength(2);
    expect(state.preflightCalls[0]).toMatchObject({ selectedContactId: "avery" });
    expect(state.generateCalls).toHaveLength(1);
    expect(state.generateCalls[0]).toMatchObject({ formCode: "P8", deponentId: "avery" });
    expect(toast.info).toHaveBeenCalledTimes(1);
    expect(toast.error).not.toHaveBeenCalled();
  });

  it("retained primary plus Avery downloads on first Generate without a retry", async () => {
    state.documents = [{ id: "primary", formCode: "P3", deponentId: "jordan", deponentName: jordan.name, signatureDate: "2026-09-05" }];
    await openCoApplicant();
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(state.generateCalls).toHaveLength(1);
    expect(state.generateCalls[0]).toMatchObject({ formCode: "P8", deponentId: "avery" });
    expect(screen.queryByTestId("pre-generate-dialog")).toBeNull();
    expect(toast.error).not.toHaveBeenCalled();
  });

  it.each(["missing download link", "generation failure"])("%s shows an error and preserves a working retry", async (failure) => {
    if (failure === "missing download link") state.generateResponse = { format: "docx" };
    else state.generateError = new Error("P8 storage is temporarily unavailable.");
    const proceed = await openDraftWarning();
    fireEvent.click(proceed);
    await waitFor(() => expect(toast.error).toHaveBeenCalledWith(expect.stringMatching(/download link|storage is temporarily unavailable/)));
    expect(screen.getByTestId("p8-download-recovery").textContent).toMatch(/Form P8 was not generated/i);
    expect(downloads).toHaveLength(0);
    expect(toast.success).not.toHaveBeenCalled();
    expect(toast.info).not.toHaveBeenCalled();
    expect((screen.getByTestId("pre-generate-proceed") as HTMLButtonElement).disabled).toBe(false);
    state.generateError = null;
    state.generateResponse = { id: "doc_p8_2", delivery: state.delivery, filename: "P8_Avery.docx", format: "docx" };
    fireEvent.click(screen.getByTestId("pre-generate-proceed"));
    await waitFor(() => expect(downloads).toHaveLength(1));
    expect(state.generateCalls).toHaveLength(2);
    expect(toast.info).toHaveBeenCalledTimes(1);
  });

  it("preflight failure displays its error and restores form details for retry", async () => {
    state.preflightError = new Error("Unable to check P8 right now.");
    await openCoApplicant();
    await waitFor(() => expect(toast.error).toHaveBeenCalledWith("Unable to check P8 right now."));
    expect(await screen.findByTestId("form-details-generate")).toBeTruthy();
    expect(downloads).toHaveLength(0);
    expect(toast.success).not.toHaveBeenCalled();
    expect(toast.info).not.toHaveBeenCalled();
    expect(state.generateCalls).toHaveLength(0);
  });

  it("preview download carries Avery's deponent id into preflight", async () => {
    const { FormPreviewModal } = await import("./EstateDetail");
    const preflight = vi.fn().mockResolvedValue(true);
    render(<FormPreviewModal
      estateId="estate-19" formCode="P8" formName="Affidavit in Support of Application for Estate Grant"
      signatoryType="executor" signatureDate="2026-09-06" deponentId="avery"
      open={true} onOpenChange={vi.fn()} runWithPreflight={preflight}
    />);
    fireEvent.click(screen.getByTestId("preview-download-docx"));
    await waitFor(() => expect(preflight).toHaveBeenCalledWith(
      ["P8"], expect.any(String), expect.any(Function),
      expect.objectContaining({ selectedContactId: "avery", supportsOverrides: true }), "download",
    ));
  });
});
