import { render, screen } from "@testing-library/react";
import React from "react";
import { describe, expect, it } from "vitest";
import Privacy from "./Privacy";

// Launch-blocker disclosure (chatbot/README.md residual #2): the Privacy Policy
// must name the AI processor for BOTH AI surfaces (estate assistant + AI-assisted
// document import). These pins keep the disclosure from silently regressing.
describe("Privacy Policy — AI processor disclosure", () => {
  it("has an indexable public canonical page without changing the legal copy", () => {
    render(<Privacy />);
    expect(document.title).toBe("Privacy Policy | ProbatePro");
    expect(document.head.querySelector('meta[name="robots"]')?.getAttribute("content")).toBe("index, follow");
    expect(document.head.querySelector('link[rel="canonical"]')?.getAttribute("href")).toBe("https://probate-pro.com/privacy");
  });

  it("discloses AI model providers in sharing (§4) and third-party services (§9)", () => {
    render(<Privacy />);
    const aiMentions = screen.getAllByText("AI model providers:");
    expect(aiMentions.length).toBe(2); // §4 sharing + §9 third-party list
    expect(screen.getByText(/estate assistant \(chat\) or AI-assisted document import/)).toBeTruthy();
    expect(screen.getByText(/social insurance numbers, banking details, and internal file identifiers are excluded from those records/)).toBeTruthy();
    // 2026-08-04 adversarial re-review: the exclusion is true only for structured
    // records — document text (incl. generated forms) transmits in full, and the
    // policy must say so rather than overstate the minimization.
    expect(screen.getByText(/documents you ask the assistant to read are transmitted as full text/)).toBeTruthy();
    expect(screen.getByText(/No estate content is sent to AI model providers unless you use these features/)).toBeTruthy();
  });

  it("lists AI-assisted features among the use purposes (§2)", () => {
    render(<Privacy />);
    expect(screen.getByText("AI-assisted features:")).toBeTruthy();
    expect(screen.getByText(/third-party artificial-intelligence models to generate responses and drafting proposals/)).toBeTruthy();
  });

  // 2026-08-04 legal-copy finding: the policy called the product "Estate
  // Manager" while the app brands itself ProbatePro everywhere else.
  it("names the service ProbatePro, not the stale Estate Manager", () => {
    render(<Privacy />);
    expect(screen.getByText(/the ProbatePro application at probate-pro\.com \(the "Service"\)/)).toBeTruthy();
    expect(screen.queryByText(/Estate Manager/)).toBeNull();
  });

  it("states the implemented PIPA retention and provider-destruction lifecycle without invented provider or backup promises", () => {
    render(<Privacy />);
    expect(screen.getByText(/BC PIPA section 35 requires it to be retained for at least one year/)).toBeTruthy();
    expect(screen.getByText(/durable destruction audit and retries provider deletion until complete/)).toBeTruthy();
    // 2026-08-05: "within 24 hours" overpromised — deletion is SCHEDULED at
    // +24h and failed provider deletes retry beyond it; the page now says so.
    expect(screen.getByText(/scheduled for deletion 24 hours after creation/)).toBeTruthy();
    expect(screen.getByText(/retried until it completes and can extend actual destruction/)).toBeTruthy();
    expect(screen.queryByText(/Amazon Web Services/)).toBeNull();
    expect(screen.queryByText(/up to 30 days to allow for data export/)).toBeNull();
    expect(screen.queryByText(/Backup copies may persist for up to 90 days/)).toBeNull();
    expect(screen.queryByText(/Legitimate interests:/)).toBeNull();
  });
});
