import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { SpotlightCard } from "@/components/SpotlightCard";
import { PageHeader } from "@/components/PageHeader";
import { motion } from "framer-motion";
import { staggerContainer, staggerItem } from "@/lib/motion";
import { AlertTriangle, Clock, RefreshCw } from "lucide-react";
import { useLocation } from "wouter";
import { fmtDisplayDate } from "@/lib/labels";

function humanStatus(value: string): string {
  return value.replace(/_/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function datePrefix(kind: string): string {
  if (kind === "eligibility") return "Operative date";
  if (kind === "internal_follow_up") return "Follow-up date";
  if (kind === "limitation") return "Last day";
  if (kind === "optional_window") return "Window closes";
  if (kind === "prohibition") return "Default restriction ends";
  return "Due";
}

export type DeadlineEvent = { kind: string; status: string; daysRemaining?: number };

export function eventUrgency(event: DeadlineEvent): "overdue" | "urgent" | "normal" {
  if ((event.kind === "obligation" && event.status === "overdue") || (event.kind === "limitation" && event.status === "expired")) return "overdue";
  if (event.daysRemaining !== undefined && event.daysRemaining >= 0 && event.daysRemaining <= 3 &&
      ((event.kind === "obligation" && ["upcoming", "due"].includes(event.status)) ||
       (event.kind === "limitation" && ["open", "last_day"].includes(event.status)))) return "urgent";
  return "normal";
}

export function segmentDeadlineEvents<T extends DeadlineEvent>(events: T[]) {
  const needsAttention = events.filter((event) => eventUrgency(event) !== "normal");
  const upcoming = events.filter((event) => eventUrgency(event) === "normal" && event.daysRemaining !== undefined && event.daysRemaining >= 0 && event.daysRemaining <= 30);
  const reference = events.filter((event) => !needsAttention.includes(event) && !upcoming.includes(event));
  return { needsAttention, upcoming, reference };
}

function statusText(event: { kind: string; status: string; daysRemaining?: number }): string {
  if (event.kind === "internal_follow_up") return event.status === "follow_up_due" ? "Follow-up due" : humanStatus(event.status);
  if (event.kind === "open_ended_obligation") return humanStatus(event.status);
  if (event.status === "overdue" && event.daysRemaining !== undefined) return `${Math.abs(event.daysRemaining)}d overdue`;
  if (event.status === "due" || event.status === "last_day") return "Due today";
  if (["upcoming", "waiting", "open"].includes(event.status) && event.daysRemaining !== undefined) {
    return event.daysRemaining === 1 ? "1d left" : `${event.daysRemaining}d left`;
  }
  return humanStatus(event.status);
}

function DeadlineEventList({ events, onOpenEstate }: { events: any[]; onOpenEstate: (estateId: string) => void }) {
  return (
    <motion.div className="space-y-2" variants={staggerContainer} initial="hidden" animate="show">
      {events.map((event) => {
        const urgency = eventUrgency(event);
        return (
          <motion.div key={event.id} variants={staggerItem}>
            <SpotlightCard className="cursor-pointer" onClick={() => onOpenEstate(event.estateId)}>
              <div className="flex items-start justify-between gap-4 px-4 py-3">
                <div className="flex min-w-0 items-start gap-3">
                  {(urgency === "overdue" || urgency === "urgent") && <AlertTriangle className={`mt-0.5 h-4 w-4 shrink-0 ${urgency === "overdue" ? "text-destructive" : "text-amber-500"}`} />}
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{event.label}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">#{event.fileNumber} — {event.estateName}</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {event.date ? `${datePrefix(event.kind)}: ${fmtDisplayDate(event.date)}` : "No numeric period prescribed"} · {event.authority}
                    </p>
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <Badge variant={urgency === "overdue" ? "destructive" : urgency === "urgent" ? "default" : "outline"} className="whitespace-nowrap text-xs">{statusText(event)}</Badge>
                </div>
              </div>
            </SpotlightCard>
          </motion.div>
        );
      })}
    </motion.div>
  );
}

export default function Deadlines() {
  const query = trpc.deadline.list.useQuery();
  const [, setLocation] = useLocation();
  const events = query.data?.events || [];
  const issues = query.data?.issues || [];
  const { needsAttention: attentionEvents, upcoming: upcomingEvents, reference: referenceEvents } = segmentDeadlineEvents(events);
  const openEstateReadiness = (estateId: string) => setLocation(`/estate/${estateId}?tab=readiness`);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Deadlines & statutory dates"
        description="Cross-file eligibility dates, obligations, limitations, prohibitions, and clearly labelled internal follow-ups"
      />

      {query.isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <motion.div key={i} className="h-[76px] rounded-lg bg-muted/50" initial={{ opacity: 0 }} animate={{ opacity: [0.4, 0.7, 0.4] }} transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.15 }} />
          ))}
        </div>
      ) : query.isError ? (
        <div role="alert" className="space-y-3 rounded-lg border border-destructive/30 bg-destructive/5 p-5">
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
            <div>
              <p className="font-medium">Deadlines could not be loaded</p>
              <p className="text-sm text-muted-foreground">{query.error.message}</p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={() => void query.refetch()}><RefreshCw className="mr-1.5 h-3.5 w-3.5" />Retry</Button>
        </div>
      ) : events.length === 0 && issues.length === 0 ? (
        <motion.div className="flex flex-col items-center justify-center py-20 text-center" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
          <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-xl border border-primary/20 bg-primary/10"><Clock className="h-6 w-6 text-primary/70" /></div>
          <p className="font-medium text-muted-foreground">No active statutory dates or follow-ups</p>
          <p className="mt-1 max-w-md text-sm text-muted-foreground/60">Events appear from persisted P1 delivery, wills-search, citation, P46, PGT, grant, variation, and distribution facts.</p>
        </motion.div>
      ) : (
        <div className="space-y-6">
          {issues.length > 0 && (
            <section className="space-y-2" aria-labelledby="deadline-data-issues">
              <h2 id="deadline-data-issues" className="text-sm font-semibold">Facts requiring review</h2>
              {issues.map((issue, index) => (
                <button key={`${issue.estateId}:${issue.path}:${index}`} type="button" onClick={() => openEstateReadiness(issue.estateId)} className="w-full rounded-lg border border-amber-300/60 bg-amber-50/50 p-3 text-left transition-colors hover:bg-amber-50 dark:bg-amber-950/15 dark:hover:bg-amber-950/25">
                  <div className="flex gap-3">
                    <AlertTriangle className={`mt-0.5 h-4 w-4 shrink-0 ${issue.severity === "error" ? "text-destructive" : "text-amber-600"}`} />
                    <div className="min-w-0">
                      <p className="text-sm font-medium">#{issue.fileNumber} — {issue.estateName}</p>
                      <p className="mt-0.5 text-xs text-muted-foreground">{issue.message}</p>
                    </div>
                  </div>
                </button>
              ))}
            </section>
          )}

          {attentionEvents.length > 0 && (
            <section className="space-y-2" aria-labelledby="deadline-needs-attention">
              <h2 id="deadline-needs-attention" className="text-sm font-semibold">Needs attention</h2>
              <DeadlineEventList events={attentionEvents} onOpenEstate={openEstateReadiness} />
            </section>
          )}
          {upcomingEvents.length > 0 && (
            <section className="space-y-2" aria-labelledby="deadline-upcoming">
              <h2 id="deadline-upcoming" className="text-sm font-semibold">Upcoming</h2>
              <DeadlineEventList events={upcomingEvents} onOpenEstate={openEstateReadiness} />
            </section>
          )}
          {referenceEvents.length > 0 && (
            <section className="space-y-2" aria-labelledby="deadline-reference">
              <h2 id="deadline-reference" className="text-sm font-semibold">Reference dates</h2>
              <p className="text-xs text-muted-foreground">Retained for context; open the estate’s readiness workspace to review the related record.</p>
              <DeadlineEventList events={referenceEvents} onOpenEstate={openEstateReadiness} />
            </section>
          )}
        </div>
      )}
    </div>
  );
}
