import React, { useEffect, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Scale, LogOut, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { useParams, useLocation, useSearch } from "wouter";
import { ClientIntakeForm } from "@/components/ClientIntakeForm";

function clientIntakeDraftScope(estateId: string, email: string) {
  let hash = 5381;
  for (const character of `${estateId}:${email.trim().toLowerCase()}`)
    hash = (hash * 33) ^ character.charCodeAt(0);
  return `portal-${(hash >>> 0).toString(36)}`;
}

/**
 * Portal entry points:
 * 1. /portal?t=<token>  — preferred one-time exchange URL (token in query param)
 * 2. /portal/:token     — legacy URL (still supported, redirects after exchange)
 * 3. /portal            — manual token entry or session-based re-entry
 */
export default function Portal() {
  const params = useParams<{ token?: string }>();
  const search = useSearch();
  const [, setLocation] = useLocation();
  const [manualToken, setManualToken] = useState("");
  const [exchangeComplete, setExchangeComplete] = useState(false);
  const [exchangeError, setExchangeError] = useState<string | null>(null);
  const exchangeAttempted = useRef(false);

  // Extract token from query param (?t=...) or route param (/:token)
  const urlToken = new URLSearchParams(search).get("t") || params.token || "";

  // Check if we already have a valid portal session cookie
  const { data: portalMe, isLoading: meLoading, isError: meError } = trpc.portal.me.useQuery(undefined, {
    retry: false,
  });

  const loginMutation = trpc.portal.login.useMutation({
    onSuccess: () => {
      setExchangeComplete(true);
      setExchangeError(null);
      // Remove token from URL immediately for security
      setLocation("/portal", { replace: true });
    },
    onError: (err) => {
      setExchangeError(err.message || "Invalid or expired access token");
      setExchangeComplete(false);
    },
  });

  // If we arrive with a token in the URL, exchange it immediately (once)
  useEffect(() => {
    if (urlToken && !exchangeAttempted.current && !portalMe && !meLoading) {
      exchangeAttempted.current = true;
      loginMutation.mutate({ token: urlToken });
    }
  }, [urlToken, portalMe, meLoading]);

  // Determine authentication state
  const hasSession = !!portalMe || exchangeComplete;

  // Phase 1: Loading — checking existing session
  if (meLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm text-muted-foreground">Checking session...</p>
        </div>
      </div>
    );
  }

  // Phase 2: Token exchange in progress (URL had a token, mutation is running)
  if (urlToken && loginMutation.isPending) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm text-muted-foreground">Verifying access token...</p>
        </div>
      </div>
    );
  }

  // Phase 3: No session and no URL token (or exchange failed) — show login form
  if (!hasSession) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <motion.div
          className="w-full max-w-md"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] as [number, number, number, number] }}
        >
        <Card className="w-full">
          <CardHeader className="text-center">
            <div className="mx-auto h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mb-2">
              <Scale className="h-6 w-6 text-primary" />
            </div>
            <CardTitle>Estate Portal</CardTitle>
            <p className="text-sm text-muted-foreground">Enter your access token to view estate information</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Access Token</Label>
              <Input
                value={manualToken}
                onChange={(e) => setManualToken(e.target.value)}
                placeholder="Paste your access token"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && manualToken) {
                    loginMutation.mutate({ token: manualToken });
                  }
                }}
              />
            </div>
            <Button
              className="w-full"
              onClick={() => loginMutation.mutate({ token: manualToken })}
              disabled={loginMutation.isPending || !manualToken}
            >
              {loginMutation.isPending ? "Verifying..." : "Access Portal"}
            </Button>
            {(exchangeError || loginMutation.error) && (
              <p className="text-xs text-destructive text-center">
                {exchangeError || loginMutation.error?.message || "Invalid or expired access token"}
              </p>
            )}
          </CardContent>
        </Card>
        </motion.div>
      </div>
    );
  }

  // Phase 4: Authenticated — show portal content
  return (
    <div className="min-h-screen bg-background">
      <PortalHeader />
      <main className="container py-6 space-y-6">
        <PortalContent />
      </main>
    </div>
  );
}

function PortalHeader() {
  return (
    <header className="border-b bg-card">
      <div className="container flex items-center justify-between h-14">
        <div className="flex items-center gap-3">
          <Scale className="h-5 w-5 text-primary" />
          <span className="font-semibold text-sm">Client Intake</span>
        </div>
        <PortalLogout />
      </div>
    </header>
  );
}

function PortalLogout() {
  const [, setLocation] = useLocation();
  const logoutMutation = trpc.portal.logout.useMutation({
    onSuccess: () => {
      setLocation("/portal", { replace: true });
      window.location.reload();
    },
  });

  return (
    <Button variant="ghost" size="sm" onClick={() => logoutMutation.mutate()} className="text-xs">
      <LogOut className="h-3 w-3 mr-1" /> Sign Out
    </Button>
  );
}

function PortalContent() {
  // No token passed — queries authenticate via the portal session cookie.
  // Retain estate context for the authenticated client-intake lifecycle without
  // exposing any estate summary. Inventory and workflow activity remain lawyer-only.
  trpc.portal.estate.useQuery();
  // This mounted query refreshes the session details after a one-time token exchange.
  const { data: portalMe } = trpc.portal.me.useQuery(undefined, { retry: false });
  const { data: clientIntakeSubmissions = [] } = trpc.portal.clientIntakeSubmissions.useQuery();

  return (
    <ClientIntakeForm
      contactName={portalMe?.contactName || ""}
      email={portalMe?.email || ""}
      draftScope={
        portalMe
          ? clientIntakeDraftScope(portalMe.estateId, portalMe.email)
          : ""
      }
      existingSubmissions={clientIntakeSubmissions}
    />
  );
}
