export { COOKIE_NAME, ONE_YEAR_MS, SESSION_MAX_AGE_MS } from "@shared/const";

/**
 * H-1 Fix: Generate login URL using the server-side /api/oauth/start endpoint.
 * This endpoint creates a cryptographic nonce, stores it in a short-lived cookie,
 * and returns a login URL with the nonce embedded in the state parameter.
 *
 * The legacy synchronous getLoginUrl has been fully removed to close the bypass
 * vector where an empty nonce could skip CSRF validation. If the server endpoint
 * fails, the user sees an error rather than being silently redirected without
 * CSRF protection.
 */
export const getLoginUrlAsync = async (returnPath?: string): Promise<string> => {
  const params = new URLSearchParams({
    origin: window.location.origin,
    returnPath: returnPath || "/",
  });
  const res = await fetch(`/api/oauth/start?${params.toString()}`, {
    credentials: "include",
    // The response contains a single-use OAuth state. Never allow a browser to
    // reuse a stale response after back/forward navigation or a flaky network.
    cache: "no-store",
    headers: { Accept: "application/json" },
  });
  if (!res.ok) {
    throw new Error(`OAuth start failed: ${res.status}`);
  }
  const data: unknown = await res.json();
  if (!data || typeof data !== "object" || typeof (data as { loginUrl?: unknown }).loginUrl !== "string") {
    throw new Error("OAuth start returned an invalid response");
  }
  const loginUrl = (data as { loginUrl: string }).loginUrl;
  if (!/^https:\/\//i.test(loginUrl)) {
    throw new Error("OAuth start returned an invalid redirect");
  }
  return loginUrl;
};

let loginRedirectInFlight = false;
const AUTH_START_ERROR_ID = "probatepro-auth-start-error";

export function showLoginStartError(returnPath?: string) {
  if (typeof document === "undefined") return;
  let errorDiv = document.getElementById(AUTH_START_ERROR_ID);
  if (!errorDiv) {
    errorDiv = document.createElement("div");
    errorDiv.id = AUTH_START_ERROR_ID;
    errorDiv.setAttribute("role", "alert");
    errorDiv.style.cssText = "position:fixed;top:0;left:0;right:0;padding:12px 16px;background:#a31320;color:white;text-align:center;z-index:99999;font-family:system-ui,sans-serif;font-size:14px;display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;box-shadow:0 2px 12px rgba(82,10,18,.3);";
    document.body.appendChild(errorDiv);
  }
  errorDiv.replaceChildren("We couldn’t start sign-in. Please check your connection and try again.");
  const retryButton = document.createElement("button");
  retryButton.type = "button";
  retryButton.textContent = "Try again";
  retryButton.style.cssText = "border:1px solid rgba(255,255,255,.75);border-radius:6px;background:rgba(255,255,255,.14);color:#fff;padding:6px 10px;font:inherit;font-weight:600;cursor:pointer;";
  retryButton.addEventListener("click", () => {
    errorDiv?.remove();
    redirectToLogin(returnPath);
  }, { once: true });
  errorDiv.appendChild(retryButton);
}

/**
 * Redirect to login using the CSRF-protected async flow.
 * If the server is unreachable, we fail closed (show error) rather than
 * falling back to an insecure direct redirect with no CSRF nonce.
 */
export const redirectToLogin = (returnPath?: string) => {
  if (loginRedirectInFlight) return;
  loginRedirectInFlight = true;
  getLoginUrlAsync(returnPath).then((url) => {
    window.location.href = url;
  }).catch((err) => {
    console.error("[Auth] Failed to get login URL:", err);
    loginRedirectInFlight = false;
    // Fail closed: do NOT redirect without the server-issued CSRF nonce.
    // A single actionable alert replaces repeated failures from concurrent queries.
    showLoginStartError(returnPath);
  });
};
