import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const publicPath = (...segments: string[]) => path.join(process.cwd(), "client", "public", ...segments);
const projectPath = (...segments: string[]) => path.join(process.cwd(), ...segments);

describe("public SEO assets", () => {
  it("allows the marketing surface, blocks private workspace paths, and declares the sitemap", () => {
    const robots = readFileSync(publicPath("robots.txt"), "utf8");

    expect(robots).toContain("User-agent: *");
    expect(robots).toContain("Allow: /");
    expect(robots).toContain("Disallow: /estate/");
    expect(robots).toContain("Disallow: /settings");
    expect(robots).toContain("Disallow: /how-it-works");
    expect(robots).toContain("Disallow: /executor-portal");
    expect(robots).toContain("Disallow: /portal");
    expect(robots).toContain("Sitemap: https://probate-pro.com/sitemap.xml");
  });

  it("lists only public canonical URLs in a well-formed sitemap", () => {
    const sitemap = readFileSync(publicPath("sitemap.xml"), "utf8");

    expect(sitemap).toContain('<?xml version="1.0" encoding="UTF-8"?>');
    expect(sitemap).toContain("<loc>https://probate-pro.com/</loc>");
    expect(sitemap).toContain("<loc>https://probate-pro.com/terms</loc>");
    expect(sitemap).toContain("<loc>https://probate-pro.com/privacy</loc>");
    expect(sitemap).not.toContain("/settings");
    expect(sitemap).not.toContain("/executor-portal");
    expect(sitemap).not.toContain("/estate/");
  });

  it("keeps root metadata within the requested description and keyword limits", () => {
    const index = readFileSync(projectPath("client", "index.html"), "utf8");
    const description = index.match(/<meta name="description" content="([^"]+)" \/>/)?.[1];
    const keywordContent = index.match(/<meta name="keywords" content="([^"]+)" \/>/)?.[1];

    expect(description).toBeDefined();
    expect(description!.length).toBeGreaterThanOrEqual(50);
    expect(description!.length).toBeLessThanOrEqual(160);
    expect(keywordContent).toBeDefined();
    const keywords = keywordContent!.split(",").map(keyword => keyword.trim()).filter(Boolean);
    expect(keywords.length).toBeGreaterThanOrEqual(3);
    expect(keywords.length).toBeLessThanOrEqual(8);
  });
});
