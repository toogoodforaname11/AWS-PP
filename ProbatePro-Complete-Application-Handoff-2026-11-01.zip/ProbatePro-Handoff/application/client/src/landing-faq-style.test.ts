import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("landing FAQ expanded state", () => {
  it("uses a separated answer surface without changing the collapsed card treatment", () => {
    const styles = readFileSync(resolve("client/src/index.css"), "utf8");

    expect(styles).toMatch(/\.landing-faq-answer\s*\{[\s\S]*margin: 0 1\.125rem 1\.125rem;[\s\S]*padding: 0\.9rem 0 0\.1rem;[\s\S]*border-top: 1px solid rgba\(30, 58, 95, 0\.1\);/);
    expect(styles).toMatch(/\.landing-faq-item\[data-state="open"\] \.landing-faq-answer\s*\{[\s\S]*opacity: 1;[\s\S]*transform: translateY\(0\);/);
    expect(styles).toMatch(/@media \(prefers-reduced-motion: reduce\) \{[\s\S]*\.landing-faq-answer\s*\{[\s\S]*transition: none;/);
    expect(styles).toMatch(/\.landing-faq-item\s*\{[\s\S]*border-radius: 0\.75rem;[\s\S]*background: #fff;/);
  });
});
