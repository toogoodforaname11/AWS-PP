import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("landing walkthrough media treatment", () => {
  it("uses a padded elevated shell and a fading frosted play overlay", () => {
    const styles = readFileSync(resolve("client/src/index.css"), "utf8");

    expect(styles).toMatch(/\.landing-walkthrough-media\s*\{[\s\S]*padding: clamp\(0\.25rem, 0\.5vw, 0\.4rem\);[\s\S]*border-radius: 0\.8rem;[\s\S]*box-shadow: 0 20px 40px -30px rgba\(18, 45, 75, 0\.42\), 0 2px 5px rgba\(18, 45, 75, 0\.06\);/);
    expect(styles).toContain("transition: transform 180ms cubic-bezier(0.23, 1, 0.32, 1), border-color 180ms cubic-bezier(0.23, 1, 0.32, 1), box-shadow 180ms cubic-bezier(0.23, 1, 0.32, 1);");
    expect(styles).toMatch(/\.landing-walkthrough-play-overlay\[data-playing="true"\]\s*\{[\s\S]*opacity: 0;[\s\S]*transform: scale\(0\.94\);/);
    expect(styles).toMatch(/\.landing-walkthrough-play-button\s*\{[\s\S]*backdrop-filter: blur\(14px\) saturate\(1\.18\);/);
    expect(styles).toMatch(/@media \(hover: hover\) and \(pointer: fine\) \{[\s\S]*\.landing-walkthrough-stage:hover \.landing-walkthrough-media\s*\{[\s\S]*transform: translateY\(-2px\);/);
  });
});
