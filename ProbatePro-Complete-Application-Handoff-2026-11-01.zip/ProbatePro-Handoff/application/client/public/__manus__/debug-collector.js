/**
 * Manus Debug Collector (agent-friendly)
 *
 * Captures:
 * 1) Console logs
 * 2) Network requests (fetch + XHR)
 * 3) User interactions (semantic uiEvents: click/type/submit/nav/scroll/etc.)
 *
 * Data is periodically sent to /__manus__/logs
 * Note: uiEvents are mirrored to sessionEvents for sessionReplay.log
 */
(function () {
  "use strict";

  // Prevent double initialization
  if (window.__MANUS_DEBUG_COLLECTOR__) return;

  // ==========================================================================
  // Configuration
  // ==========================================================================
  const CONFIG = {
    reportEndpoint: "/__manus__/logs",
    bufferSize: {
      console: 500,
      network: 200,
      // semantic, agent-friendly UI events
      ui: 500,
    },
    reportInterval: 2000,
    // Bodies and DOM/console text are never retained by diagnostics.
    // Scroll throttling: minimum ms between scroll events
    scrollThrottleMs: 500,
  };

  // ==========================================================================
  // Storage
  // ==========================================================================
  const store = {
    consoleLogs: [],
    networkRequests: [],
    uiEvents: [],
    lastReportTime: Date.now(),
    lastScrollTime: 0,
  };

  // ==========================================================================
  // Utility Functions
  // ==========================================================================

  // Diagnostics retain closed metadata only, never application bodies or free text.
  var REDACTED = "[REDACTED]";
  var SENSITIVE_HEADER_PARTS = ["password", "token", "secret", "key", "authorization", "cookie", "session"];
  var KNOWN_SENSITIVE_HEADERS = ["authorization", "proxy-authorization", "cookie", "set-cookie", "x-rotated-session", "x-api-key", "x-csrf-token"];
  var METHODS = ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "CONNECT", "TRACE"];
  var MEDIA_TYPES = [
    "application/json", "application/x-www-form-urlencoded", "multipart/form-data",
    "text/plain", "text/html", "text/css", "text/javascript", "application/javascript",
    "text/event-stream", "application/stream", "application/x-ndjson",
    "application/octet-stream", "application/pdf", "application/zip",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ];
  var STATIC_ROUTES = [
    "/", "/deadlines", "/how-it-works", "/executor-portal", "/report-a-problem",
    "/administration", "/settings", "/portal", "/terms", "/privacy", "/goodbye", "/404",
    "/api/download/form", "/api/download/export", "/__manus__/logs",
  ];
  var EVENT_KINDS = ["click", "change", "focusin", "focusout", "keydown", "submit", "scroll", "navigate", "error", "unhandledrejection", "network_error"];
  var TAGS = ["a", "button", "input", "textarea", "select", "option", "form", "label", "div", "span", "p", "section", "main", "nav", "header", "footer", "dialog", "table", "thead", "tbody", "tr", "th", "td", "ul", "ol", "li", "svg", "path", "canvas"];
  var INPUT_TYPES = ["text", "password", "email", "tel", "url", "number", "search", "date", "datetime-local", "month", "week", "time", "checkbox", "radio", "range", "file", "hidden", "button", "submit", "reset", "color", "image"];

  function isDiagnosticRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    var prototype = Object.getPrototypeOf(value);
    return prototype === Object.prototype || prototype === null;
  }

  function closedValue(value, choices, fallback) {
    return typeof value === "string" && choices.indexOf(value) !== -1 ? value : fallback;
  }

  function diagnosticMethod(value) {
    return closedValue(typeof value === "string" ? value.toUpperCase() : value, METHODS, "OTHER");
  }

  function diagnosticNumber(value, minimum = 0, maximum = Number.MAX_SAFE_INTEGER) {
    return typeof value === "number" && Number.isFinite(value) && value >= minimum && value <= maximum ? value : undefined;
  }

  function diagnosticRoute(value) {
    if (typeof value !== "string") return "[unknown-route]";
    try {
      var url = new URL(value, "https://diagnostics.invalid");
      if (url.protocol !== "http:" && url.protocol !== "https:") return "[unknown-route]";
      var pathname = url.pathname;
      if (STATIC_ROUTES.indexOf(pathname) !== -1) return pathname;
      if (/^\/api\/trpc(?:\/|$)/.test(pathname)) return "/api/trpc";
      if (/^\/estate\/[^/]+$/.test(pathname)) return "/estate/:id";
      if (/^\/portal\/[^/]+$/.test(pathname)) return "/portal/:token";
    } catch (_) { /* Invalid URLs are not diagnostic text. */ }
    return "[unknown-route]";
  }

  function redactHeaderValues(headers) {
    var pairs;
    if (Array.isArray(headers)) {
      if (!headers.every(function (pair) { return Array.isArray(pair) && pair.length === 2 && typeof pair[0] === "string"; })) return {};
      pairs = headers;
    } else if (isDiagnosticRecord(headers)) {
      pairs = Object.entries(headers);
    } else {
      return {};
    }
    var result = {};
    pairs.forEach(function (pair) {
      var name = pair[0].toLowerCase();
      var value = pair[1];
      if (name === "sensitive-header" || SENSITIVE_HEADER_PARTS.some(function (part) { return name.indexOf(part) !== -1; })) {
        // Unknown header names can themselves contain private text.
        result[KNOWN_SENSITIVE_HEADERS.indexOf(name) !== -1 ? name : "sensitive-header"] = REDACTED;
      } else if (name === "content-type") {
        var mediaType = typeof value === "string" ? value.split(";", 1)[0].trim().toLowerCase() : "";
        result[name] = MEDIA_TYPES.indexOf(mediaType) !== -1 ? mediaType :
          /^(image|audio|video)\/(png|jpeg|gif|webp|svg\+xml|mpeg|mp4|webm|ogg|wav)$/.test(mediaType) ? mediaType : REDACTED;
      } else if (name === "content-length") {
        var length = typeof value === "string" && /^\d{1,16}$/.test(value) ? Number(value) : value;
        result[name] = typeof length === "number" && Number.isSafeInteger(length) && length >= 0 ? String(length) : REDACTED;
      }
    });
    return result;
  }

  function diagnosticPart(part, response) {
    if (part === null) return null;
    if (!isDiagnosticRecord(part)) return undefined;
    var result = {};
    if (Object.prototype.hasOwnProperty.call(part, "headers")) result.headers = redactHeaderValues(part.headers);
    if (Object.prototype.hasOwnProperty.call(part, "body")) result.body = part.body == null ? null : REDACTED;
    if (response && Number.isInteger(part.status)) result.status = diagnosticNumber(part.status, 0, 599);
    return result;
  }

  function diagnosticTarget(target) {
    if (!isDiagnosticRecord(target)) return null;
    return {
      tag: closedValue(target.tag, TAGS, "unknown"),
      type: target.type == null ? null : closedValue(target.type, INPUT_TYPES, "unknown"),
    };
  }

  function projectDiagnostic(source, entry) {
    if (!isDiagnosticRecord(entry)) return null;
    var result = { timestamp: diagnosticNumber(entry.timestamp) };
    if (source === "browserConsole") {
      result.level = closedValue(typeof entry.level === "string" ? entry.level.toUpperCase() : entry.level, ["LOG", "DEBUG", "INFO", "WARN", "ERROR"], "UNKNOWN");
      result.argumentCount = Array.isArray(entry.args) ? entry.args.length :
        Number.isInteger(entry.argumentCount) ? diagnosticNumber(entry.argumentCount) : 0;
      result.errorKind = closedValue(entry.errorKind, ["UncaughtError", "UnhandledRejection"], undefined);
    } else if (source === "networkRequests") {
      result.type = closedValue(entry.type, ["fetch", "xhr"], "unknown");
      result.method = diagnosticMethod(entry.method);
      result.url = diagnosticRoute(entry.url);
      result.request = diagnosticPart(entry.request, false);
      result.response = diagnosticPart(entry.response, true);
      result.duration = diagnosticNumber(entry.duration);
      result.error = entry.error == null ? null : { kind: "network_error" };
    } else {
      result.kind = closedValue(entry.kind, EVENT_KINDS, "unknown");
      result.url = diagnosticRoute(entry.url);
      var viewport = isDiagnosticRecord(entry.viewport) ? entry.viewport : {};
      result.viewport = { width: diagnosticNumber(viewport.width), height: diagnosticNumber(viewport.height) };
      var payload = isDiagnosticRecord(entry.payload) ? entry.payload : {};
      var safePayload = {};
      if (Object.prototype.hasOwnProperty.call(payload, "target")) safePayload.target = diagnosticTarget(payload.target);
      ["x", "y", "scrollX", "scrollY"].forEach(function (key) {
        if (key in payload) safePayload[key] = diagnosticNumber(payload[key], -Number.MAX_SAFE_INTEGER);
      });
      ["documentHeight", "viewportHeight", "lineno", "colno"].forEach(function (key) {
        if (key in payload) safePayload[key] = diagnosticNumber(payload[key]);
      });
      if ("key" in payload) safePayload.key = closedValue(payload.key, ["Enter", "Escape"], undefined);
      if ("reason" in payload) safePayload.reason = closedValue(payload.reason, ["pushState", "replaceState", "popstate", "hashchange"], undefined);
      if ("kind" in payload) safePayload.kind = closedValue(payload.kind, ["fetch", "xhr"], "unknown");
      if ("method" in payload) safePayload.method = diagnosticMethod(payload.method);
      if ("url" in payload) safePayload.url = diagnosticRoute(payload.url);
      if (Number.isInteger(payload.status)) safePayload.status = diagnosticNumber(payload.status, 0, 599);
      result.payload = safePayload;
    }
    return result;
  }

  function diagnosticEntries(source, entries) {
    return entries.map(function (entry) { return projectDiagnostic(source, entry); }).filter(function (entry) { return entry !== null; });
  }

  function pruneBuffer(buffer, maxSize) {
    if (buffer.length > maxSize) buffer.splice(0, buffer.length - maxSize);
  }

  // ==========================================================================
  // Semantic UI Event Logging (agent-friendly)
  // ==========================================================================

  function shouldIgnoreTarget(target) {
    try {
      if (!target || !(target instanceof Element)) return false;
      return !!target.closest(".manus-no-record");
    } catch (e) {
      return false;
    }
  }

  function describeElement(el) {
    if (!el || !(el instanceof Element)) return null;
    var tag = el.tagName ? el.tagName.toLowerCase() : null;
    return diagnosticTarget({
      tag: tag,
      type: tag === "input" ? (el.getAttribute("type") || "text").toLowerCase() : null,
    });
  }

  function logUiEvent(kind, payload) {
    var entry = projectDiagnostic("sessionReplay", {
      timestamp: Date.now(),
      kind: kind,
      url: location.href,
      viewport: { width: window.innerWidth, height: window.innerHeight },
      payload: payload,
    });
    store.uiEvents.push(entry);
    pruneBuffer(store.uiEvents, CONFIG.bufferSize.ui);
  }

  function installUiEventListeners() {
    // Clicks
    document.addEventListener(
      "click",
      function (e) {
        var t = e.target;
        if (shouldIgnoreTarget(t)) return;
        logUiEvent("click", {
          target: describeElement(t),
          x: e.clientX,
          y: e.clientY,
        });
      },
      true
    );

    // Typing "commit" events
    document.addEventListener(
      "change",
      function (e) {
        var t = e.target;
        if (shouldIgnoreTarget(t)) return;
        logUiEvent("change", {
          target: describeElement(t),
        });
      },
      true
    );

    document.addEventListener(
      "focusin",
      function (e) {
        var t = e.target;
        if (shouldIgnoreTarget(t)) return;
        logUiEvent("focusin", { target: describeElement(t) });
      },
      true
    );

    document.addEventListener(
      "focusout",
      function (e) {
        var t = e.target;
        if (shouldIgnoreTarget(t)) return;
        logUiEvent("focusout", {
          target: describeElement(t),
        });
      },
      true
    );

    // Enter/Escape are useful for form flows & modals
    document.addEventListener(
      "keydown",
      function (e) {
        if (e.key !== "Enter" && e.key !== "Escape") return;
        var t = e.target;
        if (shouldIgnoreTarget(t)) return;
        logUiEvent("keydown", { key: e.key, target: describeElement(t) });
      },
      true
    );

    // Form submissions
    document.addEventListener(
      "submit",
      function (e) {
        var t = e.target;
        if (shouldIgnoreTarget(t)) return;
        logUiEvent("submit", { target: describeElement(t) });
      },
      true
    );

    // Throttled scroll events
    window.addEventListener(
      "scroll",
      function () {
        var now = Date.now();
        if (now - store.lastScrollTime < CONFIG.scrollThrottleMs) return;
        store.lastScrollTime = now;

        logUiEvent("scroll", {
          scrollX: window.scrollX,
          scrollY: window.scrollY,
          documentHeight: document.documentElement.scrollHeight,
          viewportHeight: window.innerHeight,
        });
      },
      { passive: true }
    );

    // Navigation tracking for SPAs
    function nav(reason) {
      logUiEvent("navigate", { reason: reason });
    }

    var origPush = history.pushState;
    history.pushState = function () {
      origPush.apply(this, arguments);
      nav("pushState");
    };

    var origReplace = history.replaceState;
    history.replaceState = function () {
      origReplace.apply(this, arguments);
      nav("replaceState");
    };

    window.addEventListener("popstate", function () {
      nav("popstate");
    });
    window.addEventListener("hashchange", function () {
      nav("hashchange");
    });
  }

  // ==========================================================================
  // Console Interception
  // ==========================================================================

  var originalConsole = {
    log: console.log.bind(console),
    debug: console.debug.bind(console),
    info: console.info.bind(console),
    warn: console.warn.bind(console),
    error: console.error.bind(console),
  };

  ["log", "debug", "info", "warn", "error"].forEach(function (method) {
    console[method] = function () {
      var args = Array.prototype.slice.call(arguments);

      var entry = projectDiagnostic("browserConsole", {
        timestamp: Date.now(),
        level: method.toUpperCase(),
        argumentCount: args.length,
      });

      store.consoleLogs.push(entry);
      pruneBuffer(store.consoleLogs, CONFIG.bufferSize.console);

      originalConsole[method].apply(console, args);
    };
  });

  window.addEventListener("error", function (event) {
    store.consoleLogs.push(projectDiagnostic("browserConsole", {
      timestamp: Date.now(),
      level: "ERROR",
      argumentCount: 1,
      errorKind: "UncaughtError",
    }));
    pruneBuffer(store.consoleLogs, CONFIG.bufferSize.console);
    logUiEvent("error", { lineno: event.lineno, colno: event.colno });
  });

  window.addEventListener("unhandledrejection", function () {
    store.consoleLogs.push(projectDiagnostic("browserConsole", {
      timestamp: Date.now(),
      level: "ERROR",
      argumentCount: 1,
      errorKind: "UnhandledRejection",
    }));
    pruneBuffer(store.consoleLogs, CONFIG.bufferSize.console);
    logUiEvent("unhandledrejection", {});
  });

  // ==========================================================================
  // Fetch Interception
  // ==========================================================================

  function recordNetwork(entry) {
    store.networkRequests.push(projectDiagnostic("networkRequests", entry));
    pruneBuffer(store.networkRequests, CONFIG.bufferSize.network);
  }

  var originalFetch = window.fetch.bind(window);

  window.fetch = function (input, init) {
    var args = arguments;
    var options = init || {};
    var startTime = Date.now();
    var url = typeof input === "string" ? input :
      (input && (input.url || input.href)) || "";
    var method = diagnosticMethod(options.method || (input && input.method) || "GET");

    // Keep internal calls and every actual application argument unchanged.
    if (typeof url === "string" && url.indexOf("/__manus__/") === 0) {
      return originalFetch.apply(window, args);
    }

    var requestHeaders = {};
    try {
      requestHeaders = Object.fromEntries(new Headers(options.headers || (input && input.headers)).entries());
    } catch (_) { /* Invalid header containers are not diagnostic text. */ }

    var entry = {
      timestamp: startTime,
      type: "fetch",
      method: method,
      url: diagnosticRoute(url),
      request: {
        headers: redactHeaderValues(requestHeaders),
        body: options.body != null || (input && input.body != null) ? REDACTED : null,
      },
      response: null,
      duration: null,
      error: null,
    };

    return originalFetch.apply(window, args)
      .then(function (response) {
        entry.duration = Date.now() - startTime;
        entry.response = {
          status: response.status,
          headers: redactHeaderValues(Object.fromEntries(response.headers.entries())),
          body: response.body === null ? null : REDACTED,
        };
        recordNetwork(entry);
        if (response.status >= 400) {
          logUiEvent("network_error", {
            kind: "fetch",
            method: entry.method,
            url: entry.url,
            status: response.status,
          });
        }
        // Telemetry never clones, reads or consumes the application's response.
        return response;
      })
      .catch(function (error) {
        entry.duration = Date.now() - startTime;
        entry.error = { kind: "network_error" };
        recordNetwork(entry);
        logUiEvent("network_error", { kind: "fetch", method: entry.method, url: entry.url });
        throw error;
      });
  };

  // ==========================================================================
  // XHR Interception
  // ==========================================================================

  var originalXHROpen = XMLHttpRequest.prototype.open;
  var originalXHRSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url) {
    var requestUrl = typeof url === "string" ? url : (url && url.href) || "";
    this._manusData = {
      method: diagnosticMethod(method || "GET"),
      url: diagnosticRoute(requestUrl),
      internal: typeof requestUrl === "string" && requestUrl.indexOf("/__manus__/") === 0,
      startTime: null,
    };
    return originalXHROpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function (body) {
    var xhr = this;
    if (xhr._manusData && !xhr._manusData.internal) {
      xhr._manusData.startTime = Date.now();
      xhr._manusData.requestBody = body == null ? null : REDACTED;

      xhr.addEventListener("load", function () {
        var entry = {
          timestamp: xhr._manusData.startTime,
          type: "xhr",
          method: xhr._manusData.method,
          url: xhr._manusData.url,
          request: { body: xhr._manusData.requestBody },
          response: {
            status: xhr.status,
            headers: redactHeaderValues({
              "content-type": xhr.getResponseHeader("content-type"),
              "content-length": xhr.getResponseHeader("content-length"),
            }),
            body: REDACTED,
          },
          duration: Date.now() - xhr._manusData.startTime,
          error: null,
        };
        recordNetwork(entry);
        if (entry.response.status >= 400) {
          logUiEvent("network_error", { kind: "xhr", method: entry.method, url: entry.url, status: entry.response.status });
        }
      });

      xhr.addEventListener("error", function () {
        var entry = {
          timestamp: xhr._manusData.startTime,
          type: "xhr",
          method: xhr._manusData.method,
          url: xhr._manusData.url,
          request: { body: xhr._manusData.requestBody },
          response: null,
          duration: Date.now() - xhr._manusData.startTime,
          error: { kind: "network_error" },
        };
        recordNetwork(entry);
        logUiEvent("network_error", { kind: "xhr", method: entry.method, url: entry.url });
      });
    }
    return originalXHRSend.apply(this, arguments);
  };

  // ==========================================================================
  // Data Reporting
  // ==========================================================================

  function reportLogs() {
    var consoleLogs = diagnosticEntries("browserConsole", store.consoleLogs.splice(0));
    var networkRequests = diagnosticEntries("networkRequests", store.networkRequests.splice(0));
    var uiEvents = diagnosticEntries("sessionReplay", store.uiEvents.splice(0));

    // Skip if no new data
    if (
      consoleLogs.length === 0 &&
      networkRequests.length === 0 &&
      uiEvents.length === 0
    ) {
      return Promise.resolve();
    }

    var payload = {
      timestamp: Date.now(),
      consoleLogs: consoleLogs,
      networkRequests: networkRequests,
      // Mirror uiEvents to sessionEvents for sessionReplay.log
      sessionEvents: uiEvents,
      // agent-friendly semantic events
      uiEvents: uiEvents,
    };

    return originalFetch(CONFIG.reportEndpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }).catch(function () {
      // Put data back on failure (but respect limits)
      store.consoleLogs = consoleLogs.concat(store.consoleLogs);
      store.networkRequests = networkRequests.concat(store.networkRequests);
      store.uiEvents = uiEvents.concat(store.uiEvents);

      pruneBuffer(store.consoleLogs, CONFIG.bufferSize.console);
      pruneBuffer(store.networkRequests, CONFIG.bufferSize.network);
      pruneBuffer(store.uiEvents, CONFIG.bufferSize.ui);
    });
  }

  // Periodic reporting
  setInterval(reportLogs, CONFIG.reportInterval);

  // Report on page unload
  window.addEventListener("beforeunload", function () {
    var consoleLogs = diagnosticEntries("browserConsole", store.consoleLogs);
    var networkRequests = diagnosticEntries("networkRequests", store.networkRequests);
    var uiEvents = diagnosticEntries("sessionReplay", store.uiEvents);

    if (
      consoleLogs.length === 0 &&
      networkRequests.length === 0 &&
      uiEvents.length === 0
    ) {
      return;
    }

    var payload = {
      timestamp: Date.now(),
      consoleLogs: consoleLogs,
      networkRequests: networkRequests,
      // Mirror uiEvents to sessionEvents for sessionReplay.log
      sessionEvents: uiEvents,
      uiEvents: uiEvents,
    };

    if (navigator.sendBeacon) {
      var payloadStr = JSON.stringify(payload);
      // sendBeacon has ~64KB limit, truncate if too large
      var MAX_BEACON_SIZE = 60000; // Leave some margin
      if (payloadStr.length > MAX_BEACON_SIZE) {
        // Prioritize: keep recent events, drop older logs
        var truncatedPayload = {
          timestamp: Date.now(),
          consoleLogs: consoleLogs.slice(-50),
          networkRequests: networkRequests.slice(-20),
          sessionEvents: uiEvents.slice(-100),
          uiEvents: uiEvents.slice(-100),
          _truncated: true,
        };
        payloadStr = JSON.stringify(truncatedPayload);
      }
      navigator.sendBeacon(CONFIG.reportEndpoint, payloadStr);
    }
  });

  // ==========================================================================
  // Initialization
  // ==========================================================================

  // Install semantic UI listeners ASAP
  try {
    installUiEventListeners();
  } catch (e) {
    console.warn("[Manus] Failed to install UI listeners:", e);
  }

  // Mark as initialized
  window.__MANUS_DEBUG_COLLECTOR__ = {
    version: "2.0-no-rrweb",
    store: store,
    forceReport: reportLogs,
  };

  console.debug("[Manus] Debug collector initialized (no rrweb, UI events only)");
})();
