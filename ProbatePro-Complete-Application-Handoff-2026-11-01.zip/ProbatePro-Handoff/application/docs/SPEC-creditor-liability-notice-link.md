# Spec: Creditor–Liability Notice Linkage

## Objective

Allow an estate user to connect a **recorded Inventory liability** to an **identified Creditor contact**. For an intestacy, a linked, recorded liability that exceeds **$10,000** must make that creditor available to the application's existing Rule 25-2 notice flows:

- Form P1 recipient selection;
- beneficiary/notice-letter recipient selection; and
- the existing delivery-recipient checklist that precedes an honest Form P9 affidavit.

This repairs the missing TD-mortgage recipient path without fabricating a lender, address, P1 notice, delivery, or sworn P9 fact.

> A liability row alone is not a legal notice recipient. It may establish that a debt exists, but it does not identify a creditor or provide a service address. The user must record and select the creditor contact.

### User story

> As the person preparing an intestacy file, after I record a mortgage or other liability and select its creditor contact, I can prepare P1 materials and record delivery to that creditor when the recorded debt exceeds $10,000. If I have not identified the creditor, the application does not claim that notice or delivery occurred.

## Scope

### Included

1. Add an optional `creditorContactId` field to Inventory liabilities.
2. Add a liability-only **Creditor contact** selector in the Inventory editor.
3. Validate that a selected contact belongs to the same estate and is recorded as a creditor (whether through `recipientType` or role).
4. Extend the canonical Rule 25-2 creditor calculation to recognize the amount of linked, recorded liabilities.
5. Feed the enriched canonical recipient set into the existing P1, notice-letter, form-status/readiness, and delivery-recipient paths.
6. Preserve the existing P2 high-value-unlinked-liability safeguard: an unidentified liability above $10,000 prevents P2 from swearing the existing no-creditor sentence, but remains a blank completion state.
7. Clear a deleted contact's liability links and remap linked contacts when an estate is duplicated.
8. Add schema, server, shared-logic, UI, and regression coverage.

### Explicitly excluded

- Inventing, automatically creating, or guessing a lender from an Inventory description such as “TD mortgage”.
- Automatic email, mail, P1 generation, delivery record creation, or P9 generation.
- Any change to Form P9 wording, layout, methods, checkboxes, delivery attestations, or its separate recipient-list defect investigation.
- Any change to P2 official wording, prescribed layout, or completion-popup questions.
- Changing the distinct P44 lawyer-signature task or either Consent and Nomination task.
- Adding dependencies, changing authentication, or reading user records.

## Key Decisions

### Data model

Add an additive, empty-by-default `inventory.creditorContactId: varchar(36)`.

- It is meaningful only for `category === "liability"`.
- An empty value means the creditor is not yet identified or linked.
- It is not a cross-estate foreign key. The server enforces same-estate ownership and creditor classification before writes; this avoids an invalid cross-estate reference and preserves the project's existing string-id relationship pattern.
- Existing inventory remains unchanged and unlinked after migration. No database backfill or description parsing is permitted.

### Effective creditor amount

For creditor-recipient eligibility only, the canonical effective amount is:

```ts
const linkedLiabilityCents = inventory
  .filter((item) =>
    item.category === "liability"
    && isInventoryValueRecorded(item)
    && item.creditorContactId === contact.id,
  )
  .reduce((sum, item) => sum + probateItemValue(item), 0);

const effectiveClaimAmountCents = Math.max(
  Number(contact.claimAmountCents || 0),
  linkedLiabilityCents,
);
```

`Math.max` preserves an existing manually recorded creditor claim where it is higher, while allowing an otherwise blank/stale claim amount to be supported by the linked recorded liability. A linked liability must not be added to a manually-entered aggregate claim, because that could double-count the same debt.

The creditor remains a Rule 25-2(2)(b)(ii) recipient only when the existing no-will predicate is true and the effective amount is **strictly greater than $10,000**. Existing non-creditor entitlement limbs remain unchanged.

### Delivery and P9 boundary

The existing delivery checklist may list the linked creditor because it reads the same canonical recipient set. It must still require an actual recipient name, method, and date before any P9 delivery affidavit is rendered. This feature does not claim that TD—or any other creditor—has received notice.

## Tech Stack

- React 19 + TypeScript client
- Express 4 + tRPC 11 server
- Drizzle ORM + TiDB/MySQL migration
- Vitest regression suite
- DOCX and structured-preview renderer in `server/docgen.ts`

## Commands

```bash
# Generate and inspect the additive migration after editing drizzle/schema.ts
pnpm drizzle-kit generate

# Apply the reviewed migration through the WebDev SQL capability
# Use: webdev_execute_sql with the generated migration SQL

# Focused logic, router, UI, and document checks
pnpm exec vitest run shared/p1-notice-creditor-limb.test.ts --maxWorkers=1
pnpm exec vitest run server/docgen.referenced-documents.test.ts --maxWorkers=1
pnpm exec vitest run client/src/pages/EstateDetail.notice-recipient.test.ts --maxWorkers=1

# Required final validation
pnpm check
pnpm test -- --maxWorkers=1
pnpm build
git diff --check
```

## Project Structure

```text
drizzle/schema.ts                         → Inventory link column and inferred types
drizzle/                                  → Generated, reviewed additive migration
shared/types.ts                           → Canonical linked-creditor amount and recipient logic
server/db.ts                              → Contact-link cleanup on deletion
server/routers.ts                         → Validation, inventory persistence, duplication remapping, recipient queries
server/docgen.ts                          → Existing P1/letter recipient calls receive Inventory context
client/src/pages/EstateDetail.tsx         → Liability creditor selector and cache invalidation
shared/*.test.ts                          → Rule 25-2 and delivery-recipient unit regressions
server/*.test.ts                          → P1/letter/document integration regressions
client/src/pages/*.test.tsx               → Inventory selector and recipient UI regressions
docs/audits/                              → Post-validation implementation boundary record
```

## Code Style

Use existing TypeScript helpers and preserve a single canonical recipient decision. The renderer, UI, and server must not implement hand-copied threshold checks.

```ts
export function effectiveCreditorClaimAmountCents(
  contact: Contact,
  inventory: Inventory[] = [],
): number {
  const linkedLiabilityCents = inventory
    .filter((item) => item.category === "liability"
      && isInventoryValueRecorded(item)
      && String(item.creditorContactId || "") === String(contact.id))
    .reduce((sum, item) => sum + probateItemValue(item), 0);

  return Math.max(Number(contact.claimAmountCents || 0), linkedLiabilityCents);
}
```

- Use additive schema changes and generated migrations only.
- Use a named helper in `shared/types.ts`; do not duplicate eligibility math in `server/docgen.ts`, `server/routers.ts`, or React.
- Keep tRPC as the sole client/server transport.
- Use existing Shadcn controls, labels, tooltips, and responsive Tailwind conventions.
- Preserve official form wording, DOCX geometry, and DOCX/preview parity.

## Testing Strategy

### Shared recipient logic

- A no-will estate with an identified creditor, a recorded linked mortgage of `$212,400`, and a zero manual claim amount includes the creditor in `p1NoticeRecipients`.
- `$10,000.00` exactly remains excluded; `$10,000.01` is included.
- A testate estate excludes a creditor-only linked liability from the creditor limb.
- An unlinked high-value liability does not fabricate a recipient.
- Multiple linked liabilities use their recorded aggregate; a larger manually recorded claim remains effective without double-counting.

### Server integrity

- Inventory create/update rejects a creditor contact from another estate, a missing contact, a non-creditor contact, or a non-liability link.
- Contact deletion clears only same-estate inventory links before deleting the contact.
- Estate duplication maps both source inventory ids and source creditor-contact ids to the new estate's ids.
- Bulk import leaves the new field empty because it cannot safely identify a contact.

### UI

- The creditor selector appears only for liabilities, lists only valid creditor contacts, and permits an unselected state.
- Changing away from `liability` clears the link.
- Saving a link invalidates the recipient, readiness, preflight, form-status, inventory, and letter-recipient data that depend on it.
- The UI guidance is warning-only; saving and form generation are never hard-blocked by an unlinked liability.

### Document and delivery integration

- Existing P1/letter recipient resolution includes the linked creditor through the shared resolver.
- The delivery checklist lists that creditor but P9 remains blank/unavailable until a real delivery record is entered.
- Existing P2 DOCX/preview tests continue to prove that an unlinked high-value liability suppresses the false no-creditor negative, without inventing a creditor name.

## Boundaries

### Always

- Read the captured local Rules reference before touching any form wording; do not change wording for this feature.
- Maintain DOCX/preview parity for any renderer call-site change.
- Validate same-estate ownership and creditor classification server-side.
- Run focused tests, typecheck, full serial tests, production build, and `git diff --check` before completion.
- Apply only a generated and human-reviewed additive migration through the WebDev SQL capability.
- Keep the feature non-blocking and retain blank/warning behavior for incomplete lender identity or delivery facts.

### Ask first

- Applying the database migration to the WebDev database.
- Adding a dependency, changing CI, changing a court form's wording/layout, or expanding this change into direct P9 document behavior.
- Any decision to backfill, infer, or create contacts from existing liability text.

### Never

- Create a lender contact from “TD mortgage”, an Inventory description, or any other free text.
- Mark a P1 as sent or a P9 delivery as made because a liability is linked.
- Modify the user's estate records during investigation or tests.
- Remove or weaken existing threshold, no-will, ownership, or delivery validations.
- Reintroduce operational/readiness prompts into a form popup when they do not populate visible document content.

## Success Criteria

1. A user can link a recorded `$212,400` liability to a same-estate Creditor contact without duplicating or inventing contact data.
2. On an estate with the existing no-will record, the linked contact is returned by the same canonical recipient resolver used by P1, notice letters, and delivery expectations.
3. The existing application does not automatically record P1 notice or P9 delivery; a P9 still needs genuine delivery facts.
4. An unlinked high-value liability remains non-blocking and does not become a fabricated recipient; P2 keeps the previously delivered blank-fill safeguard instead of the false no-creditor sentence.
5. Cross-estate, missing, non-creditor, and non-liability links are rejected at the server boundary.
6. Existing estates retain their data unchanged after migration; an estate duplicate contains only remapped same-estate links.
7. Full typecheck, serial tests, build, migration inspection/application, and whitespace checks pass.

## Open Questions

1. **Approval requested:** May I add and apply the additive `creditorContactId` database column? This is needed because the existing Inventory model has no lender identity or address.
2. **Approval requested:** Should existing high-value mortgages remain manually unlinked until the user chooses a creditor, as specified? This is the safe default; automatic creation from a description would create a legal recipient without verified identity.
3. The earlier P9 defect remains a separate task. This specification deliberately updates only the existing recipient source shared by the delivery checklist; it does not change P9's document renderer or delivery UX beyond the automatic appearance of a now-valid recipient.
