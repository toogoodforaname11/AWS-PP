# Synthetic Vault Restore Test Record

**Status:** Unexecuted template — record one completed, evidence-backed test before a sensitive vault accepts live client data, then repeat at least quarterly and after a material architecture change.

**Scope:** This is a technical recovery test for ProbatePro’s optional single-account sensitive-data vault, including planned personal-executor use. Use **synthetic records only**. Do not put real estate data, SINs, document images, email addresses, real client names, or production tokens in this record.

> **Pass rule:** A backup is not a recovery control until a segregated restore confirms expected data, checksums, lawyer/estate authorization, exportability, and absence of cross-account access. A failed or incomplete test blocks live sensitive-data acceptance until remediated and retested.

## 1. Test identification

| Field | Record |
|---|---|
| Test ID | `RESTORE-YYYY-MM-DD-###` |
| Test date/time and timezone | _Pending_ |
| Test lead | _Pending_ |
| Independent reviewer | _Pending_ |
| Environment | Segregated restore environment; not production |
| Provider/product/region | _Pending — evidence reference only_ |
| Backup/snapshot identifier | Safe internal reference; do not record credential, URL, or full bucket path |
| Architecture version / commit | _Pending_ |
| Trigger | Quarterly / architecture change / provider change / incident follow-up |

## 2. Synthetic fixture manifest

Prepare a deliberately small, non-sensitive estate fixture that exercises all relevant paths.

| Fixture element | Expected quantity | Safe identifier/checksum | Restored? |
|---|---:|---|---|
| Account | 2 (owner + non-owner control account) | `account-synthetic-a`, `account-synthetic-b` | _Pending_ |
| Estate record | 1 | `estate-synthetic-001` | _Pending_ |
| Contacts/inventory/notes | At least 1 of each | Fixture version/hash | _Pending_ |
| Vault documents | At least 3 types; one upload with a safe filename stress case | SHA-256 per document | _Pending_ |
| Opaque vault references | One reference per fixture document | Count only | _Pending_ |
| Deleted/retained sample | At least one lifecycle-state control | Count only | _Pending_ |
| Backup archive | Database + object/document recovery source | SHA-256 / provider evidence | _Pending_ |

## 3. Preconditions

- [ ] Provider due-diligence record is completed enough to identify the primary and independent backup locations.
- [ ] The test environment has separate credentials and cannot send email, notifications, or production writes.
- [ ] Access credentials are temporary or rotated after the test; none are pasted into tickets, terminals, screenshots, or this record.
- [ ] All test documents are synthetic and are labelled as test material.
- [ ] Baseline fixture hashes and object counts are recorded before restore.
- [ ] On-call/operator contacts and the [storage incident runbook](../runbooks/storage-incident.md) are available.

## 4. Procedure and observed timings

| Step | Expected result | Start | End | Result / evidence reference |
|---|---|---|---|---|
| 1. Isolate restore environment | No production network path or credentials | _Pending_ | _Pending_ | _Pending_ |
| 2. Restore database metadata | Estate, ownership, opaque references, and lifecycle metadata restore | _Pending_ | _Pending_ | _Pending_ |
| 3. Restore document/object data | All fixture objects restore to a non-production location | _Pending_ | _Pending_ | _Pending_ |
| 4. Verify hashes and counts | Every restored fixture hash/count equals baseline | _Pending_ | _Pending_ | _Pending_ |
| 5. Verify owner authorization | Synthetic owner reads own estate/documents; access succeeds | _Pending_ | _Pending_ | _Pending_ |
| 6. Verify cross-account denial | Synthetic non-owner cannot read, export, download, or delete owner data | _Pending_ | _Pending_ | _Pending_ |
| 7. Verify export | Owner’s per-estate ZIP contains records + authorized files, no internal URLs/keys | _Pending_ | _Pending_ | _Pending_ |
| 8. Verify lifecycle controls | Deleted/retained fixture behaves as expected; no deleted file becomes readable | _Pending_ | _Pending_ | _Pending_ |
| 9. Tear down and rotate | Test environment/data and temporary credentials are disposed per policy | _Pending_ | _Pending_ | _Pending_ |

## 5. Acceptance checks

| Check | Pass condition | Result |
|---|---|---|
| Recovery point objective (RPO) | Actual recovered point is within the approved target | _Pending_ |
| Recovery time objective (RTO) | Actual start-to-usable duration is within the approved target | _Pending_ |
| Data integrity | All fixture document checksums and counts match | _Pending_ |
| Authorization | Owner allowed; non-owner denied consistently without enumeration | _Pending_ |
| Export | Authorized per-estate export is usable and omits storage locators/tokens | _Pending_ |
| Deletion/retention | No unauthorized resurrection; lifecycle state remains correct | _Pending_ |
| Logging | Logs/tickets/screenshots contain no raw document content, names, tokens, signed URLs, or secrets | _Pending_ |
| Cleanup | Segregated data/credentials disposed and evidence retained safely | _Pending_ |

## 6. Results and exceptions

**Overall outcome:** _Pending — Pass / Fail / Conditional pass_

**Actual RPO:** _Pending_

**Actual RTO:** _Pending_

**Integrity result:** _Pending_

**Authorization result:** _Pending_

**Export result:** _Pending_

**Exceptions, failures, or evidence references:**

> _Pending — use safe identifiers and summaries only; do not paste sensitive content, credentials, tokens, full filenames, signed URLs, or production logs._

## 7. Remediation and approval

| Finding | Severity | Owner | Due date | Retest required? | Closed date |
|---|---:|---|---|---|---|
| _Pending_ | _Pending_ | _Pending_ | _Pending_ | _Pending_ | _Pending_ |

| Approval | Name | Date | Decision |
|---|---|---|---|
| Test lead | _Pending_ | _Pending_ | _Pending_ |
| Independent reviewer | _Pending_ | _Pending_ | _Pending_ |
| Service owner | _Pending_ | _Pending_ | _Pending_ |
| Counsel review (if required) | _Pending_ | _Pending_ | _Pending_ |

## 8. Retention of test evidence

Retain only the minimum non-sensitive evidence necessary to demonstrate the recovery test: fixture manifest hash, timestamps, count/checksum results, authorization result, export result, approvals, and remediation record. Keep detailed provider logs and credentials in the approved restricted operational location, not this repository.
