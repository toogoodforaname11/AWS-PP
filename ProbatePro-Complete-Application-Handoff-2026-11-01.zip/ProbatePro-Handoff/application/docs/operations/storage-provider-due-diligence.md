# Storage Provider Due-Diligence Record

**Status:** Unapproved template — complete with written provider evidence before any sensitive vault receives live client records.

**Scope:** ProbatePro’s optional Canadian sensitive-data vault for **individual lawyer accounts** and the planned **personal-executor account** path. This record helps organize technical and contractual evidence; it is **not** a legal opinion, a privacy impact assessment, or a certification of compliance.

> **Go-live gate:** A Toronto/Vancouver VM location alone is insufficient. Do not accept SINs, identity documents, wills, death certificates, bank records, signed documents, or other sensitive client files into the vault until every mandatory item below is evidenced, a synthetic restore succeeds, and qualified counsel approves the relevant lawyer-facing terms.

## 1. Decision record

| Item | Record before approval |
|---|---|
| Proposed provider and product | Provider legal name, exact product/SKU, region, account owner, support plan |
| Intended data classes | Sensitive document categories allowed; explicit exclusions; whether any document can be sent to AI |
| Deployment boundary | VM/API location, database location, object-storage location, backup/snapshot/log/monitoring/support-access locations |
| Account model | Single account ownership; planned `accountPurpose` of lawyer or personal executor; no `firmId` or browser-supplied owner identifier |
| Data flow | Direct browser-to-vault upload, opaque reference in Manus, short-lived scoped access token, deletion/retention path |
| Decision owner | Named service owner and accountable lawyer/platform approver |
| Evidence date | Date and source link or support ticket ID for each answer |
| Counsel review | Name/date/outcome for provider terms, customer terms, privacy notice, DPA, and any retention language |

## 2. Mandatory provider questionnaire

Obtain answers **in writing** from the provider, agreement, security documentation, or a support ticket. “Marketing page says” is not sufficient evidence. Attach or link the source outside this repository; do not paste credentials, raw contracts, account IDs, or client information here.

| Question | Mandatory evidence | Answer / source | Owner | Review date |
|---|---|---|---|---|
| Where are the primary VM/API, PostgreSQL metadata, and object-storage bytes located? | Region and data-centre jurisdiction for each component | _Pending_ | _Pending_ | _Pending_ |
| Where are backups, snapshots, replicas, disaster-recovery media, monitoring, and logs located? | Region/jurisdiction, retention, and whether each can leave Canada | _Pending_ | _Pending_ | _Pending_ |
| Which support staff or subprocessors can access systems or data, from where, and under what approval/logging controls? | Support-access and subprocessor terms; change-notice process | _Pending_ | _Pending_ | _Pending_ |
| Is encryption used in transit and at rest? Who holds/rotates keys, and how are recovery keys controlled? | TLS and at-rest encryption design; key-recovery procedure | _Pending_ | _Pending_ | _Pending_ |
| What are the provider’s access-control, MFA, audit-log, vulnerability-patching, and incident-notification commitments? | Security terms/SOC evidence where available; incident SLA | _Pending_ | _Pending_ | _Pending_ |
| Can the lawyer/platform export all records in usable formats during service and on termination? | Export process, time limits, format, pricing, and support dependency | _Pending_ | _Pending_ | _Pending_ |
| Can the provider follow deletion instructions and supply verification? How do backups expire? | Destruction workflow, evidence, retry behavior, backup expiry | _Pending_ | _Pending_ | _Pending_ |
| What are the backup frequency, encryption, independent destination, RPO/RTO, and tested restore process? | Written backup policy and restore procedure | _Pending_ | _Pending_ | _Pending_ |
| Are data, support, logs, and backups all contractually bounded to the intended locations? | Explicit scope and exceptions | _Pending_ | _Pending_ | _Pending_ |
| How are provider/service changes, terms changes, or subprocessor changes announced? | Notice period and opt-out/termination rights | _Pending_ | _Pending_ | _Pending_ |

## 3. ProbatePro technical control checklist

### Before connecting the vault

- [ ] Create separate **development, staging, and production** vault accounts/credentials. Use synthetic data only outside production.
- [ ] Keep the vault API, PostgreSQL, object-store administration, backups, and monitoring endpoints off the public internet; expose only the required TLS endpoint.
- [ ] Restrict SSH to named administrators via key-only access and a VPN/allowlist; disable root and password login.
- [ ] Configure host/provider firewalls as default-deny and document every exception.
- [ ] Configure encrypted daily backups and an independent Canadian recovery copy. A same-provider weekly snapshot is an additional layer, not sufficient alone.
- [ ] Configure alerts for disk capacity, backup failure, restore failure, TLS expiry, malware/quarantine failure, elevated authorization denial, and upload/download failure.
- [ ] Set a no-PII logging allowlist: opaque account/estate/document IDs, event name, outcome, provider code, duration, and request ID only.
- [ ] Establish direct browser-to-vault uploads with 5–10 minute account-and-estate-scoped tokens. Manus must not proxy sensitive bytes or retain signed URLs.
- [ ] Store only opaque vault document IDs and safe metadata in Manus; never raw file bytes, SINs, extracted content, access tokens, or vault URLs.
- [ ] Confirm a retention-aware delete flow: immediate access removal when authorized, verified provider destruction, and documented backup expiry.

### Existing ProbatePro evidence to preserve

- [ ] `assertEstateOwned(estateId, userId)` is invoked before sensitive-object actions.
- [ ] Storage manifest rows bind current objects to the estate and authenticated lawyer account.
- [ ] Cross-account tests cover estate read, storage proxy, disposition, and estate export.
- [ ] The per-estate **Export estate copy** action works with synthetic records and does not expose internal object URLs/keys.
- [ ] `pnpm storage:validate-provider` passes **only after** an approved S3-compatible legal-record provider is configured; retain the dated output outside git without credentials.

## 4. Contract and product review gate

Counsel must review, at minimum:

1. Whether the provider agreement preserves the relevant account holder’s ownership, custody/control, production/export, confidentiality, security, and destruction-instruction rights; lawyer-specific Rule 10 obligations require separate counsel review.
2. The platform’s Terms, Privacy notice, DPA (if used), support process, and lawyer-facing retention/deletion language.
3. Cross-border processing disclosures and any proposed residency statement.
4. The incident notification and evidence-preservation procedure.
5. Any decision to accept SINs or other data not needed for probate-form generation.

No customer-facing copy may say **“Law Society compliant,” “Canada-only,” “Canadian-resident,” “end-to-end encrypted,”** or equivalent until the relevant evidence and counsel approval are recorded.

## 5. Risk register and escalation

| Risk | Severity | Likelihood before mitigation | Score | Required action |
|---|---:|---:|---:|---|
| Provider cannot evidence backup/support/log jurisdictions | 4 — High | 3 — Possible | 12 — High | Do not accept live sensitive records; obtain written clarification or choose another provider; escalate to counsel. |
| Single VPS or same-provider backup becomes unavailable | 4 — High | 3 — Possible | 12 — High | Independent encrypted backup, synthetic restore test, and documented RPO/RTO before go-live. |
| Vault token or signed URL leaks into logs/client storage | 4 — High | 2 — Unlikely | 8 — Medium | Short lifetimes, no-store responses, secret scanning, logging allowlist, and incident runbook. |
| Cross-account access control is bypassed | 5 — Critical | 2 — Unlikely | 10 — High | Server/vault dual authorization; automated denial tests; block rollout on any failure. |
| Marketing overclaims residency or compliance | 3 — Moderate | 3 — Possible | 9 — Medium | Counsel-approved copy only; maintain this evidence record and review change control. |

## 6. Approval record

| Gate | Evidence | Approver | Date | Outcome |
|---|---|---|---|---|
| Provider questions complete | All mandatory rows answered with written sources | _Pending_ | _Pending_ | _Pending_ |
| Technical configuration reviewed | Hardening, backups, alerts, least privilege, data flow | _Pending_ | _Pending_ | _Pending_ |
| Synthetic restore passed | `docs/operations/restore-test-record.md` completed | _Pending_ | _Pending_ | _Pending_ |
| Incident procedure reviewed | `docs/runbooks/storage-incident.md` tabletop completed | _Pending_ | _Pending_ | _Pending_ |
| Counsel review complete | Written approval or qualified conditions | _Pending_ | _Pending_ | _Pending_ |
| Live sensitive data authorized | All gates above complete | _Pending_ | _Pending_ | _Pending_ |

## 7. Sources and related records

- [Rule 10 conformance baseline](../architecture/rule-10-conformance-baseline.md)
- [Individual lawyer Canadian vault checklist](../architecture/individual-lawyer-canadian-vault-checklist.md)
- [Synthetic restore test record](./restore-test-record.md)
- [Storage incident runbook](../runbooks/storage-incident.md)
- [Law Society of BC Rules 10-3 and 10-4](https://www.lawsociety.bc.ca/support-and-resources-for-lawyers/act-rules-and-code/law-society-rules/part-10-%E2%80%93-general/)
- [Law Society of BC cloud computing checklist](https://www.lawsociety.bc.ca/Website/media/Shared/docs/practice/resources/checklist-cloud.pdf)
