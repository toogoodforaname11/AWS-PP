# Public FAQ Expanded Panel and Client-Intake Portal Copy Audit

**Date:** 2026-10-12  
**Scope:** Public landing-page FAQ expanded state and executor-portal descriptions only.

## Reason for change

The collapsed FAQ cards were acceptable, but an expanded answer looked like an unstructured continuation of the trigger. Public descriptions also characterized the Executor Portal principally as a read-only sharing view, despite the existing client-intake workflow: a recipient completes a portal questionnaire and the lawyer reviews and selects facts before applying them to the estate record.

## Changes made

- Kept the collapsed FAQ cards and their existing grid unchanged.
- Gave the expanded answer a quiet divider, independent answer spacing, calmer body colour, and a short opacity/vertical-offset entrance paired with the existing accordion-height motion.
- Kept keyboard-native accordion behavior and added a reduced-motion fallback.
- Corrected public landing, Executor Portal, and portal-link management copy to describe the existing secure client-intake → lawyer-review → selected-fact application workflow.
- Updated portal link emails, toasts, titles, and empty-state help so they do not promise only read-only access.
- Did not change the client submission router, estate schema, application rules, court-form output, or portal authorization model.

## Verified existing workflow

The existing implementation already supports the requested functional path:

1. A lawyer issues a secure estate-scoped portal link.
2. The client submits the guided intake.
3. The submission remains separate from the estate record.
4. The lawyer selects individual fields or uses the preselected field set and approves only those facts.
5. The server applies only the selected, non-blank facts at the expected estate revision.

## Validation evidence

- Red/green landing FAQ and Executor Portal copy regressions passed.
- Focused validation: **42 tests passed** across Landing, FAQ styles, Executor Portal, and Settings; TypeScript check passed.
- Existing client-intake workflow validation: **33 tests passed**, including portal submission, lawyer-selected application, revision requests, UI review, and access management.
- Full serial suite: **4,492 passed, 3 skipped**.
- Production build completed successfully.
- Browser inspection confirmed an expanded answer is visible (`opacity: 1`, settled transform), and the public development page returned HTTP 200 locally and externally.
- `git diff --check` passed.

## Scope preserved

No estate records were accessed. No client data was changed. No court-form wording, generated-document layout, legal/citation text, business rules, database schema, or portal authorization behavior changed.
