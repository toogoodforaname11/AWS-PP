# Creditor–Liability Notice Link

## Objective

A recorded mortgage or other liability must contribute its identified creditor to the Rule 25-2 notice and P9 delivery workflow without treating an Inventory description as legal identity or fabricating delivery facts.

## Implemented behaviour

- Inventory now has an optional `creditorContactId` relationship, added by migration `0168_old_whirlwind.sql`.
- A link can point only to a **same-estate Creditor Contact** and only while the Inventory record is a liability. Reclassification clears it; contact deletion clears linked liabilities atomically; estate duplication remaps it to the copied creditor contact.
- The liability editor offers an explicit Creditor Contact selector and a compact **Add creditor** dialog. The dialog records a named Creditor Contact and lets the user confirm the claim amount; no lender is inferred from a liability description.
- For an intestacy, an identified creditor linked to a recorded liability **over $10,000** is a canonical Rule 25-2 recipient. That recipient appears in P1/letter recipient resolution, Forms applicability and package selection, Delivery/P9 recipient resolution, preflight, readiness, timelines, and direct-download/preview paths.
- A liability alone, an unlinked liability, a $10,000-or-less liability, a testate creditor-only case, and an unnamed contact do not create a recipient.

## Document-safety boundary

No court-form wording, layout, indentation, checkbox geometry, or delivery facts were changed. The system does **not** create a P9 delivery record or state that TD (or any other lender) received notice. The lawyer must still record the actual recipient, date, and method before a completed P9 can truthfully list delivery.

## Verification

- Focused recipient, inventory lifecycle, duplication, P1/P2, P9-route, client inventory, and deadline tests passed.
- TypeScript passed.
- Full serial suite passed: **4,447 tests passed; 3 skipped**.
- Production build and whitespace checks passed.
