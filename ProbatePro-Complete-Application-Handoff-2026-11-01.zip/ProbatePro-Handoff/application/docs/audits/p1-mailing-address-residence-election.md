# P1 mailing-address residence repair

_Completed 2026-10-09 — Form P1 applicant-information residence election only_

---

## Finding

Form P1 prints the applicant's mailing address and then requires the applicable official individual-residence alternative. Previously, any saved `cityCountry` value selected the separate “in the following city and country” alternative, even when the same applicant had a recorded mailing address. That produced a redundant city/country line instead of the mailing-address alternative.

## Repair boundary

The P1 DOCX renderer and structured preview now select “at the mailing address noted above” whenever the applicant has a mailing address under the existing P1 address precedence (postal address, then residential address, then address for service). A saved city/country value is retained in the record but is used only where no P1 mailing address is recorded.

In the existing **Relevant text only** setting, the selected individual and mailing-address wording is emitted as one line:

> This applicant is an individual and ordinarily lives at the mailing address noted above

Normal checkbox mode retains the face's existing two nested selected checkbox rows and their geometry.

## Preserved constraints

- No official wording changed
- No standard checkbox-mode layout, indentation, checkbox geometry, or page behavior changed
- No applicant/contact data was changed or cleared
- No other form or address renderer changed
- DOCX and structured preview use the same selection rule

## Verification

- Regression coverage verifies the mailing-address selection despite a stale city/country value, the text-only one-line DOCX/preview output, and the city/country fallback when no mailing address exists
- Focused P1/document/checkbox suite passed: 479 tests
- TypeScript check passed
- Full serial suite passed: 300 files, 4,457 tests, 3 skipped
- Production build passed
- `git diff --check` passed
