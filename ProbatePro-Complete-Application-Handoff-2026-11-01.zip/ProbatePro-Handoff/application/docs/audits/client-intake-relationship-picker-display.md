# Client Intake Relationship Picker Display Repair

**Date:** 2026-10-14  
**Status:** Complete  
**Scope:** Executor/Client Portal relationships in the Contacts editor only

## Reported behavior

A newly created contact could have a relationship reported through the portal, such as `second cousin`, while the Contacts edit dialog showed a blank **Relationship to Deceased** picker. The existing picker option is stored as `second_cousin`, so an older contact containing the readable phrase did not match an option.

## Finding

The prior portal mapper already normalizes newly approved relationship facts. A direct mapping regression and a new full lawyer-review approval regression both confirm that selecting a new report persists `second cousin` as `second_cousin`.

The remaining issue was backward display compatibility: contacts already written with a readable spacing/hyphen/case variant could still be rendered into the controlled Select with their old raw value. Radix could not match that value to an option and displayed its placeholder.

## Repair

A shared `normalizeContactRelationshipForPicker` helper now owns the known Contact picker equivalents. It is used in both places that need the same compatibility behavior:

- **Portal approval:** a selected new relationship persists the established canonical picker value.
- **Contacts edit dialog:** an existing equivalent value is normalized only for Select display, so `second cousin` displays as **Second Cousin**.

The dialog does not call `setContact` when it renders this compatibility value. No old contact record is silently rewritten; it changes only if a lawyer deliberately chooses an option and saves the form. Unknown relationship phrases remain unchanged rather than being guessed.

## Regression coverage

- **Red → green UI regression:** a legacy contact with `relationship: "second cousin"` initially rendered no **Second Cousin** label. It now renders the matching picker option and the no-write assertion confirms rendering does not mutate data.
- **Router regression:** a selected portal relationship flows through lawyer review to a contact patch with `relationship: "second_cousin"`.
- **Mapper regression:** known spacing, hyphen, underscore, and case equivalents retain their established canonical option values while unfamiliar terms remain verbatim.
- **Browser validation:** a fictional contact fixture was opened at desktop and 375px mobile widths. The dialog displayed **Second Cousin**, Space opened the list from keyboard focus with that option selected, and no browser console errors occurred.

## Verification

| Check | Result |
|---|---|
| Focused mapping, approval, review, and contact-editor suites | 66 passing |
| TypeScript | `pnpm check` passed |
| Full serial suite | 4,578 passed / 3 skipped |
| Production build | Passed (pre-existing jsPDF import/chunk-size warnings only) |
| Whitespace | `git diff --check` passed |
| HTTP health | Local `/`, local `/portal`, and preview `/` each returned 200 |

## Boundaries preserved

No schema, migration, actual estate or client data, Contact role, executor status, address, form generation, court-form/document layout or wording, legal relationship logic, authorization, or portal access behavior changed.
