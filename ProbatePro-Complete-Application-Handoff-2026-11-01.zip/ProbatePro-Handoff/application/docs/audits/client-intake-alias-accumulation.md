# Client Intake Alias Accumulation Audit

**Date:** 2026-10-14  
**Scope:** Client Portal application of deceased aliases into the canonical estate Intake record.

## Reported behaviour

After a later Executor/Client Portal submission was applied, the **Additional aliases** editor showed only the newest alias. An earlier portal alias disappeared. The Intake record could also retain a `No` value for **Was the deceased known by any other names?** despite holding aliases.

## Cause

The client-intake mapper correctly preserved a selected portal alias in the canonical `deceasedAliases` field and set `hasOtherNames` to `yes`. However, the approval transaction directly overwrote the existing estate field with the new patch. A later submission therefore replaced rather than accumulated the existing canonical list.

The existing structured AKA inputs are intentionally separate from client-reported full aliases. A full portal alias is not split into first, middle, and last name components, because doing so would fabricate a legal name structure.

## Repair

`approveClientIntakeSubmission` now merges a non-empty client-reported alias patch with the revision-locked estate snapshot before the atomic estate update:

- Retains every existing canonical alias and appends newly approved aliases.
- Trims aliases and deduplicates whitespace/case-insensitive repeats while preserving the first recorded spelling and the established semicolon-delimited storage format.
- Sets **known by other names** to `yes` whenever a client alias is applied.
- Marks **additional names** as `yes` when a distinct canonical alias exists beyond a structured AKA, or preserves a previously confirmed `yes` value.
- Includes these derived fields in the existing one-step undo snapshot.

The structured AKA inputs remain untouched. The Intake view continues to display client-reported full aliases in the **Additional aliases (one per line)** editor alongside any lawyer-entered structured AKA.

## Regression coverage

A red regression seeded the exact failure shape: an estate with `TEST Alias Two`, followed by a later application containing `test alias two; TEST Alias Four`. It failed because the transaction saved only the incoming patch. It now verifies the persisted record is:

```text
TEST Alias Two; TEST Alias Four
```

with both alias flags set to `yes`. A focused Intake UI regression verifies that both client aliases remain visible while the structured AKA remains unchanged.

## Verification

- Focused persistence, mapper, form-source, and Intake suites: **355 passing**.
- Isolated Playwright browser fixture with fictional account and estate data: verified both aliases appear in the desktop and 375px Intake editor, the structured AKA is not overwritten, the primary other-names control is selected as **Yes**, no mocked requests were unhandled, and no console errors occurred.
- Full serial suite: **4,576 passing; 3 skipped**.
- TypeScript: `pnpm check` passed.
- Production build: `pnpm build` passed. Existing non-fatal jsPDF dynamic/static import and bundle-size warnings remain unrelated and unchanged.
- `git diff --check` passed.
- Local and preview HTTP health: **200**.
- The three touched files had pre-existing project-wide Prettier differences; no formatter rewrite was applied because it would create a broad unrelated diff.

## Boundaries

No estate records, portal sessions, authentication, contacts, inventory, form text/layout, document generation, database schema, or authorization rules changed. Browser validation used only fictional local fixture data.
