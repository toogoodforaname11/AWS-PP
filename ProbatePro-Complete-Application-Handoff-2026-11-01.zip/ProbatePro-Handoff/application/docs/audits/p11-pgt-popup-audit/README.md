# Remaining Form Popup Relevance Audit

**Scope:** Forms P11, P12, P14–P17, P26, P34, P44–P46, VSA 532, and PGT information.

**Decision rule:** A pre-generation popup retains a gap only when its value directly fills visible document content, selects a visible official alternative, or is a direct render parameter. The popup excludes availability and applicability, generic readiness, filing or delivery workflow, certificate or attachment tracking, provenance, source/history, and validation-only/reconciliation facts. A hard legacy preflight classification does not override this rule.

## Audit records

| Form | Audit record | Implementation result |
|---|---|---|
| P11 | [11-p11.md](11-p11.md) | Retains direct deponent, affidavit, election, and Exhibit A values; hides domicile metadata, security-link validation, generic will/consistency/applicability rows. |
| P12 | [12-p12.md](12-p12.md) | Retains translator and document-language fields that print; hides language applicability and generic intake rows. |
| P14 | [14-p14.md](14-p14.md) | Retains rendered affidavit and scoped exhibit facts; hides aggregate/provenance, broad non-face inventory, validation, and availability rows. |
| P15 | [15-p15.md](15-p15.md) | Retains its actual supplemental Exhibit A fields; hides only non-rendered generic will/consistency/applicability rows. |
| P16 | [16-p16.md](16-p16.md) | Retains will-alteration text/location and affidavit values; hides route, presence, and consistency/applicability administration. |
| P17 | [17-p17.md](17-p17.md) | Retains renunciation face values; hides generic will/grant/applicability administration. |
| P26 | [26-p26.md](26-p26.md) | Retains resealing affidavit and direct supplemental exhibit values; hides aggregate/provenance, broad inventory, validation, and availability rows. |
| P34 | [34-p34.md](34-p34.md) | Retains direct citation/affidavit facts; hides file metadata, attachment evidence, response consistency, eligibility, and package tracking rows. |
| P44 | [44-p44.md](44-p44.md) | Retains visible applicant/name/signature values; hides filing and recipient workflow plus generic intake rows. |
| P45 | [45-p45.md](45-p45.md) | Retains the sworn electronic-will lock alternative and its printed values; hides electronic-will axes and repository/application-material fields that P45 does not print. |
| P46 | [46-p46.md](46-p46.md) | Retains demandant and direct document values; hides generic readiness, will/grant, and electronic-will applicability administration. |
| VSA 532 | [vsa532.md](vsa532.md) | Retains the registered direct request fields; hides universal intake, applicability, certificate, courier, and search-history workflow. |
| PGT information | [pgt-info.md](pgt-info.md) | Retains recipient name and reviewed-detail parameter; hides notify-PGT availability and committee/delivery readiness administration. |

## Implemented behavior

`PreGenerateDialog` now applies the content classifier **per owning form** in both single-form and package reports. That prevents a non-content row from another report from reappearing in a package popup. Hidden rows do not contribute to the displayed hard-block computation. When any hidden row remains, a user-initiated continuation forwards explicit draft intent, so the underlying generation route can use its existing draft/override path rather than silently treating the row as complete.

The classifier deliberately keeps direct renderer-backed values and official-alternative selections. It does not change DOCX or preview wording, document layout, selected-form behavior, data schema, or canonical server-side validation outside popup display.

## Validation

- Focused `PreGenerateDialog` regression suite: **122 passing**.
- Cross-form regression covers one excluded row for every audited form, direct P45 lock-status retention, PGT review retention, dynamic PGT committee readiness exclusion, and explicit continuation for a package made entirely of hidden non-content gaps.
- Full project validation, production build, whitespace checks, and a scoped source review are required before this audit is finalized.
