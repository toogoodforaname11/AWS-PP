# PGT_INFO popup audit — Public Guardian and Trustee Information

## Scope and decision rule

**Scope:** source audit of the `PGT_INFO` pre-generation popup only. No application source, tests, schema, prescribed wording, DOCX layout, or prior audit file was changed.

A popup item is retained only where the value directly fills visible PGT_INFO content, selects a visible official alternative, or is a direct rendering parameter. Applicability, readiness, delivery workflow, source/attachment tracking, provenance, cross-form history, validation-only facts, and unrendered metadata are excluded. A conditional item is not excluded merely for being conditional.

**PreGenerateDialog is used.** `EstateDetail` mounts one dialog instance and supplies the preflight reports, `onApplyInline`, the estate, and contacts (`client/src/pages/EstateDetail.tsx:9754-9778`). The dialog explicitly recognizes a single-form `PGT_INFO` report as a canonical completion form (`client/src/components/PreGenerateDialog.tsx:466-467`) and has a dedicated PGT recipient editor (`:1717-1741`).

## Direct renderer evidence

| Visible PGT_INFO content / parameter | DOCX evidence | Preview evidence | Audit consequence |
| --- | --- | --- | --- |
| Deceased name in style of cause | `buildPgtInfo` calls `styleOfCause(e, "PGT_INFO", ...)` (`server/docgen.ts:6243-6248`); `styleOfCause` prints `fullName(e)` in the estate style of cause (`:248-272`). | The branch calls `addStyleOfCause("PGT_INFO", ...)` (`:9000-9004`); `addStyleOfCause` prints the same `fullName(e)` expression (`:6754-6769`). | `pgt_info_deceased_name` is direct visible content. |
| Each P1-eligible recipient’s name | DOCX selects `p1Recipients(ctx)` (`:6255-6256`) and prints `rec.name` in each numbered row (`:6259-6267`). | Same resolver and name expression (`:9005-9012`). | `pgt_info_recipient_names` is direct visible content. |
| Residential, postal, e-mail, and fax values | DOCX prints all four contact fields through `pgtInfoKnownField` (`:6263-6267`). The helper returns the value; only a missing value becomes `[not known]` after `pgtInfoReviewed === 1`, otherwise a blank fill (`:6238-6241`). | Same resolver and four field expressions (`:9007-9012`). | The review confirmation is an explicit direct rendering parameter: it changes a missing visible field from a blank fill to `[not known]`. |
| Recipient set | `p1Recipients` delegates to canonical `p1NoticeRecipients`, which excludes the applicant, PGT, and non-recipients (`:1014-1028`). | Same helper (`:9005`). | The form does not render the notification flag, committee facts, delivery facts, or readiness status. |
| Applicant signature | DOCX prints applicant name in `signatureLine` (`:6277-6278`); preview prints the same applicant name (`:9017`). | Same. | No PGT_INFO requirement or injected popup gap supplies this value. |

The focused renderer tests corroborate the four printed contact fields, blank-fill behavior before review, and `[not known]` behavior after review (`server/verify-all-forms.test.ts:1975-2019`), and the PGT-specific DOCX/preview grid test passed (see **Verification**).

## Requirement and injected-gap classification

| ID / origin | When observed | Visible-content trace | Classification | Popup disposition |
| --- | --- | --- | --- | --- |
| `pgt_info_deceased_name` — `FORM_REQUIREMENTS` | Always evaluated; missing first or last name | Style-of-cause name in both renderers above. Requirement fields are `estate.deceasedFirstName` and `estate.deceasedLastName` (`shared/formRequirements.ts:4419-4425`). | **Retain** | Direct content editor / correction path. |
| `pgt_info_notify_pgt_flag` — `FORM_REQUIREMENTS` | PGT is otherwise required but `estate.notifyPGT !== "yes"` (`shared/formRequirements.ts:4428-4438`) | No PGT_INFO DOCX or preview expression reads `notifyPGT`; it is used by `formStatus` to decide whether PGT notice is applicable (`shared/types.ts:4032-4040`). | **Exclude** | Availability/applicability fact, not a visible PGT_INFO value or direct renderer parameter. Do not make it a completion card or popup blocker. |
| `pgt_info_recipient_names` — `FORM_REQUIREMENTS` | Any canonical P1 recipient lacks `name` (`shared/formRequirements.ts:4441-4449`; resolver `:309-319`) | Numbered recipient name in DOCX `:6263` and preview `:9007`. | **Retain** | Direct content editor / correction path. |
| `pgt_info_recipient_details_reviewed` — `FORM_REQUIREMENTS` | Any canonical P1 recipient has `pgtInfoReviewed !== 1` (`shared/formRequirements.ts:4451-4459`) | `pgtInfoKnownField` changes the literal visible missing-value output based on that exact flag (`server/docgen.ts:6238-6241`, `:6264-6267`, `:9009-9012`). | **Retain** | Direct rendering parameter; retain the existing per-recipient confirmation. It is not merely workflow because it selects the visible missing-value representation. |
| `readiness:committee_<contactId>` — dynamically bridged by router | A P1 recipient is mentally incapable, has a committee, and lacks committee name/address (`shared/types.ts:1965-1969`). `bridgedReadinessGaps` explicitly injects every `committee_*` failure into `PGT_INFO` as a soft `readiness:` gap (`server/routers.ts:503-517`, especially `:507-509`). | Neither renderer reads committee name, committee address, or `hasCommittee`; PGT_INFO prints only the recipient name plus residential/postal/e-mail/fax quartet. | **Exclude** | Delivery/committee workflow for P9, as the readiness producer itself states; non-rendered metadata for PGT_INFO. It must not be displayed as a PGT_INFO completion card or affect popup blocking. |
| `pgt_info_applicability` — server-injected applicability gap | When `formStatus("PGT_INFO")` is `na`, i.e., no PGT notice trigger; wrapper inserts this ID and makes it hard unless the user requested a draft (`server/routers.ts:817-859`; status condition `shared/types.ts:4032-4040`). | It controls whether the form is required; it does not feed PGT_INFO content. | **Exclude** | Availability/applicability status only. Do not recommend a PGT_INFO popup content editor or blocker for it. |

### Upstream readiness item that is **not** injected into this popup

`pgt_addr_quartet` is produced by the readiness engine when a listed P1 recipient has not been reviewed (`shared/types.ts:1508-1521`), but it is **not** in `READINESS_PREFLIGHT_FORMS` and is not a `committee_*` ID. The router therefore does **not** bridge it into `PGT_INFO` (`server/routers.ts:490-517`). The functional content equivalent is the retained registry row `pgt_info_recipient_details_reviewed`; it already controls the direct renderer parameter. No separate popup treatment is warranted.

## Direct-editor persistence result

| Retained requirement | Dialog behavior | Persistence to exact consumer | Result |
| --- | --- | --- | --- |
| `pgt_info_deceased_name` | Both estate columns have inline controls (`shared/inlineFieldControls.ts:72-77`); generic editor eligibility accepts `estate.<column>` only when it has an inline control (`:591-605`). | The dialog receives estate fields and `onApplyInline` from `EstateDetail` (`client/src/pages/EstateDetail.tsx:9766-9778`); its canonical-completion path saves corrections before re-check (`PreGenerateDialog.tsx:2258-2261`). The renderers consume those estate name columns through `fullName(e)`. | **Persists to the exact renderer consumer.** |
| `pgt_info_recipient_names` | Dedicated editor shows only a missing recipient name (`PreGenerateDialog.tsx:1717-1736`). | Action builder sends `{ mode: "update", id, name }` for changed named recipients (`:777-785`); `EstateDetail` persists contact row edits with `contact.update` before preflight is invalidated/re-run (`EstateDetail.tsx:8485-8497`). Both renderers consume `rec.name`. | **Persists to the exact renderer consumer.** |
| `pgt_info_recipient_details_reviewed` | Dedicated per-recipient checkbox writes only `pgtInfoReviewed: true` (`PreGenerateDialog.tsx:1729-1740`). | Action builder sends that exact flag (`:779-785`); `contact.update` writes it. The router deliberately clears it when any printed quartet field changes without an explicit review value (`server/routers.ts:2852-2866`), preventing stale `[not known]` selection. Both renderers consume it only via `pgtInfoKnownField`. | **Persists to the exact renderer consumer.** |

The focused dialog test asserts that typed name plus review confirmation emits exactly `{ name: "Robin Recipient", pgtInfoReviewed: true }` for the canonical contact update (`client/src/components/PreGenerateDialog.test.tsx:1733-1762`).

`pgt_info_notify_pgt_flag` is intentionally not assessed as a retained editor: although `notifyPGT` has a generic intake control (`shared/inlineFieldControls.ts:263-272`), it is excluded because the only source trace is applicability, not PGT_INFO rendering.

## Potential hard-block and preview/DOCX parity risks

1. **Hard-block leakage — applicability:** `pgt_info_applicability` can be injected as a hard preflight gap (`server/routers.ts:843-859`) even though it is availability only. It must remain outside the content-popup blocking calculation under the stated decision rule.
2. **Soft-gap leakage — committee:** `readiness:committee_<contactId>` is dynamically added to PGT_INFO by a special router rule (`server/routers.ts:507-517`) despite being P9 delivery workflow and non-rendered in PGT_INFO. It is soft today, but it can still appear as an irrelevant popup card; it must be excluded after gap assembly, including dynamic IDs.
3. **No duplicate readiness card:** `pgt_addr_quartet` is upstream readiness but not bridged. Adding it would duplicate the retained review parameter and risk presenting the same fact as both generic readiness and content completion.
4. **Parity:** the DOCX and preview use the same `p1Recipients` selection, `pgtInfoKnownField`, name fallback, quartet fields, no-recipient alternative, and applicant signature (`server/docgen.ts:6255-6278`, `:9005-9017`). The targeted renderer/alignment tests passed. No source-traced PGT_INFO preview/DOCX content divergence was found.
5. **Do not infer recipient facts:** review confirmation can legitimately make an unrecorded quartet value print `[not known]`; collecting or defaulting a contact address/fax/e-mail from unrelated fields would be an unsourced legal fact. Retaining the existing confirmation is therefore narrower and safer than inventing values.

## Recommendation

**Retain only** `pgt_info_deceased_name`, `pgt_info_recipient_names`, and `pgt_info_recipient_details_reviewed` in the PGT_INFO content/direct-parameter popup path. **Exclude** `pgt_info_notify_pgt_flag`, `pgt_info_applicability`, and dynamic `readiness:committee_<contactId>` from PGT_INFO popup completion and blocker state. Do not add a duplicate `readiness:pgt_addr_quartet` card: it is not currently injected and its content-relevant function is already covered by the retained review parameter. No wording, layout, schema, or renderer change is recommended by this source audit.

## Verification

Fresh focused verification, without source changes:

```text
pnpm exec vitest run shared/pgt-info-alignment.test.ts server/pgt-info-alignment.test.ts server/docgen-rule25-pgt-info.test.ts client/src/components/PreGenerateDialog.test.tsx --testNamePattern='PGT_INFO|PGT information|pgt_info|pgtInfo'

Test Files  4 passed (4)
Tests       10 passed | 120 skipped (130)
```
