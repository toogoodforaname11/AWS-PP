# Public Landing Form Catalogue Repair

**Date:** 2026-10-13  
**Scope:** Public marketing homepage form catalogue only (`/`)

## Reported issue

The public homepage presented a hand-maintained short list of conditional forms. It omitted supported forms, including Form P12 (Affidavit of Translator), and the conditional list was permanently open.

## Root cause

`Landing.tsx` contained a separate static list of eleven conditional entries. The application already had `FORM_CATALOG` as its supported-form inventory, but the marketing page did not use it. Any new supported form could therefore be absent from the public page.

## Repair

- The landing page now derives its core and conditional rows from `FORM_CATALOG`.
- The five existing core application rows remain directly visible: P1, P2, P9, VSA 532, and the beneficiary letter.
- Every other currently supported catalogue entry is present in the **Conditional forms (auto-determined)** disclosure, including P6, P7, P12, P13–P16, P26, P46, PGT information, and the two consent documents.
- The conditional section begins closed and uses a native button with `aria-expanded` and `aria-controls`; the named content region is mounted only while expanded.
- The disclosure has a 44px control height, visible keyboard focus, click / Enter / Space support, and responsive no-overflow behavior.
- Plain-language condition notes explain why each row may apply. The canonical catalogued form title remains the displayed title, preventing title drift.

## Boundaries preserved

No generation, preflight, form applicability, server route, database, document, official court-form wording/layout, account, or authentication behavior changed. The page still describes **supported** forms only; unsupported resealing Forms P21–P25 were not represented as available product functionality.

## Regression coverage

The new landing regression starts red against the former static section and verifies that:

1. the conditional catalogue begins collapsed;
2. it exposes an accessible disclosure state;
3. expanding it contains every non-core `FORM_CATALOG` entry; and
4. Form P12 is present.

## Validation evidence

- Red-green focused landing regression completed.
- Landing authentication/style suites: **12 passing**.
- TypeScript: `pnpm check` passed.
- Isolated browser fixture with no authenticated data:
  - desktop and 390px mobile;
  - starts collapsed;
  - click, Enter, and Space disclose/collapse correctly;
  - all 23 conditional catalogue entries render;
  - no horizontal overflow, target height meets 44px intent, and browser console is clean.
- Full serial suite: **4,569 passing / 3 skipped**.
- Production build passed. Existing non-blocking jsPDF static/dynamic import and chunk-size warnings remain unchanged and are unrelated.
- `git diff --check` passed.
- Local and sandbox preview homepage health checks returned **HTTP 200**.
