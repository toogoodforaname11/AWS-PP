# Public landing beneficiary-letter row overlap

**Date:** 2026-10-14  
**Status:** Complete

## Reported symptom

On the public homepage’s Core application forms list, the `Letter` badge visually ran into “Letter to Beneficiaries (accompanies P1)” on a phone viewport.

## Root cause

Every catalogue row reserved a fixed `2.25rem` first grid column. That was sufficient for short codes such as P1 and P9 but narrower than the rendered Letter badge, allowing its content to overrun into the title column.

## Repair

The shared public `FormItem` now sizes its code column to the badge’s intrinsic width with `max-content`, while the title remains in a constrained flexible second column. This preserves the established responsive wrapping of the title without clipping or horizontal overflow.

## Regression and browser evidence

A red-green UI regression verifies that the Letter row uses the intrinsic-width code column. A fictional-data Chromium check at 375px and 1280px measured the badge’s right edge no farther than the title’s left edge, confirmed the row is visible, and reported no console errors. The visual review confirms the label and title have a consistent gap at both widths.

## Boundaries preserved

No public copy, form catalogue content, form generation, document layout, API, data, authentication, or legal logic changed.

## Validation evidence

Focused public landing regressions: 14 passing. TypeScript passed. The serial application suite passed with 4,573 tests and 3 skipped. Production build, whitespace check, and local/sandbox-preview HTTP health checks passed. The existing non-fatal jsPDF import/chunk-size build warnings remain unrelated and unchanged.
