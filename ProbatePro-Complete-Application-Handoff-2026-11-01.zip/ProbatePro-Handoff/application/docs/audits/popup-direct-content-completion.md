# Direct popup content-completion audit

_Form-popup follow-up — 2026-10-10_

---

## 📋 Finding

The P8 repair established the required interaction pattern: when a pre-generation popup identifies a fact that prints on the requested form, the user must be able to supply that fact **in the generation flow**. The earlier P44 repair only applied that handoff to P44. Other optional forms could therefore collect their applicability answer and then bypass their existing document-detail controls, silently using defaults or leaving the user to discover the missing choice later.

## 🔍 Scope reviewed

`FormsTab.handleFixProceed` is the common continuation for all Optional-form applicability dialogs. `FormDetailsDialog.FORM_DETAILS` is the existing registry for form-facing fields.

| Form-detail registry groups | Existing controls preserved | Optional continuation after this repair |
| --- | --- | --- |
| P1, P2, P44 | Signatory and date; P2 certified-copy choices | Opens the registered details popup |
| P3–P7, P8–P11, P14–P16, P26, P45 | Deponent, oath, signature date, and registered form-specific controls | Opens the registered details popup |
| P9 | Deponent, oath, signature date, and delivery checklist | Opens the registered details popup |
| P12 | Translator/deponent and registered fields | Opens the registered details popup |
| P34 | Citor's actual signature date for a selected citation | Opens the registered date control from that citation record |
| P46 | The selected delivery recipient and the demandant's actual signature date | Opens the registered date control from the selected delivery row |
| Forms without a `FORM_DETAILS` entry | Existing form-specific flow remains unchanged | Continues through the existing preflight pipeline |

> **P34 and P46 are controlled record selections, not general free-text form fields.** P34's citor comes from an estate-owned citation record; P46's demandant comes from an estate-owned Rule 25-2 delivery row. Each action now opens the shared details dialog even where no previous form date exists, so the user selects the actual signature date before preview or generation.

## ⚙️ Repair

The shared Optional-form continuation now tests `FORM_DETAILS[code]` rather than naming P44 alone. Any optional form with registered printed-detail controls is handed, after the existing two-frame Radix overlay release, into the same `FormDetailsDialog` used for ordinary Generate and Preview actions.

- Applicability answers remain transient document overrides; the estate record is not changed.
- Existing `FormDetailsDialog` fields, persisted-field flushes, validation, and downstream `PreGenerateDialog` preflight are reused without duplication.
- The user can answer deponent, signatory, oath, date, delivery, and any registered form-specific controls before the document request is issued.
- P34 preserves the canonical citation id through the details dialog, preflight, preview, and generation. Its citation action clears the inherited global date before opening the picker, so a previous form's date cannot be reused silently.
- P46 preserves the delivery row identity through both preflight and document preview/generation; it clears the inherited global date before opening its date picker, so a prior form's date is never reused silently.
- No court-form wording, DOCX renderer, preview renderer, document geometry, or selected-only alternative behavior changed.

## 🔎 Remaining-form audit

The same “Go to Forms” / missing-document-detail audit was run across **P13 and P17–P43**. P34 was the only additional P8-style dead end: an eligible citation could start Preview or Generate with the ambient global date, while its P34 signing date is visible document content.

| Reviewed scope | Result |
| --- | --- |
| P13 | No direct-content Form-tab redirect or missing document-detail control found. |
| P17–P33, P35–P43 | No P8-style “Go to Forms” dead end found. Existing prompts either already collect the printed value or describe a non-content workflow fact. |
| P34 | Repaired: the selected citation now opens P34's date-only details dialog and carries its canonical citation id through the existing preview/generation pipeline. |

This review does not convert workflow, source-document, readiness, or attachment provenance into popup questions. The popup policy remains limited to facts that visibly print or select a visible official alternative.

## ✅ Regression coverage

The regression suite proves the former P45 bypass now opens `FormDetailsDialog`, preserves its electronic-will applicability answers, and carries the selected deponent to generation. A second regression exercises P16 to prove the continuation is registry-driven rather than another P44/P45-only exception. The existing P44 lawyer-signatory path remains covered. P46 regression coverage proves its delivery-row action opens the date picker even with no existing global signature date, without starting a generation request. P34 coverage proves an eligible citation opens the shared date picker rather than calling Preview or Generate directly, and the existing P34 DOCX regression continues to pass unchanged.

| Verification | Result |
| --- | --- |
| Targeted Optional-form flow regression | Passed: P45, P16, and P44 continuation cases |
| Targeted P46 date-control and delivery-row handoff regressions | Passed: 114 tests |
| Targeted P34 details, citation handoff, preflight, and document regressions | Passed: 121 tests |
| TypeScript check | Passed |
| Scope and whitespace review | Passed |
| Full serial suite | Passed: 4,462 passing, 3 skipped |
| Production build | Passed |

## 📌 Boundary

This audit changes **how the existing form-facing choices are reached**, not which legal facts are collected or printed. A missing fact that has no safe in-popup editor remains subject to the application’s existing warning/draft rules; it is not invented or auto-selected.
