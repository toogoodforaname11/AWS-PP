# Portal Link Presentation Repair Audit

**Date:** 2026-10-13
**Scope:** Estate-scoped Client Portal link issuance and copying only.

## Reported behavior

After a lawyer selected **Grant Access**, the client-intake URL was not visibly retained. The row-level copy icon could be interpreted as copying that existing link, but it invoked the intentional token-reissue procedure and created a replacement link instead.

## Root cause

The client retained no issued URL after the create mutation’s best-effort clipboard attempt. That was consistent with the secure server contract: access-list rows intentionally exclude raw tokens, which are available only during create or reissue. The problem was the presentation layer: it discarded the creation response and used a copy icon for an action whose real behavior was token rotation.

## Repair

- The estate-scoped Client Portal now keeps a just-issued URL only in React component state for the current browser view.
- An accessible **New client-intake link** panel shows the raw URL, selects it on focus, tries to copy it, and keeps it available for manual copy if the browser denies clipboard access.
- The row action is now visibly and accessibly named **Replace link**; it continues to call the existing guarded reissue operation only when deliberately selected.
- Reissue by email now accurately describes that it creates a replacement link and retains that issued link visibly in the current view.
- No raw token is stored in the database, returned by access-list queries, added to the query cache, or written to logs.

## Regression coverage

`EstateClientPortal.test.tsx` proves that estate-scoped Grant Access keeps the returned URL visible, copies that exact URL on request, and does not invoke reissue; it also requires the explicit replacement control. `portalAccess.security.test.ts` remains green and continues to prove that access-list rows never expose a stored token and the server persists only a SHA-256 digest.

## Validation evidence

- Focused: `pnpm exec vitest run client/src/components/EstateClientPortal.test.tsx server/portalAccess.security.test.ts --maxWorkers=1` — **7 passing**.
- TypeScript: `pnpm check` — **passed**.
- Serial suite: `pnpm test -- --maxWorkers=1` — **4,562 passing, 3 skipped**.
- Production build: `pnpm build` — **passed**.
- `git diff --check` — **passed**.
- Runtime: local root, local `/portal`, and the managed preview root each returned **HTTP 200**.

## Deliberate exclusions

The server’s estate-ownership check, secure token hashing, one-time redemption, expiry, revocation, client submission flow, review/apply flow, and every court-form renderer remain unchanged.
