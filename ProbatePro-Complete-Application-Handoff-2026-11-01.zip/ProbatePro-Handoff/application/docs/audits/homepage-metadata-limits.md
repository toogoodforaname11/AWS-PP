# Homepage Metadata Limits — Audit

**Date:** 2026-10-12  
**Surface:** Public root page (`/`)

## Requirement and implementation

The public HTML head now carries a `keywords` tag with **six** focused phrases:

1. British Columbia probate software
2. BC probate forms
3. estate administration
4. probate lawyers
5. personal executors
6. executor intake

The root description is now exactly **140 characters**, within the requested 50–160 character range:

> ProbatePro helps BC lawyers and personal executors organize probate files, prepare court forms, track deadlines, and manage estate contacts.

The same 140-character wording is used by the initial document head, Open Graph, Twitter card, and client-rendered landing metadata. No internal workspace, estate-file, legal-policy, citation, structured-data, sitemap, robots, or other public copy was changed.

## Validation

- A red-green static metadata regression now verifies the root description and keyword-count limits.
- Focused metadata, reusable SEO, and landing regressions: **14 passed**.
- TypeScript: `pnpm check` passed.
- Rendered browser inspection confirmed description length **140** and keyword count **6**.
- Canonical production root verification confirmed the same **140-character** description and **six** keywords after deployment propagation.
- Full serial suite: **4,539 passed / 3 skipped**.
- Production build: `pnpm build` passed.
