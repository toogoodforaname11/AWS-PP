# Client Intake Other-Names Repair Audit

**Date:** 2026-10-13
**Task:** Client Portal — retain submitted other names beside a lawyer-entered AKA
**Scope:** One client-intake defect: a selected full alias was marked **Applied** but disappeared from Intake whenever the estate already had structured AKA name parts.

## Root Cause

The client-intake mapper correctly preserves a submitted full alias in the canonical `estates.deceasedAliases` list and does not infer name parts. The remaining loss occurred later in the Intake alias synchronizer.

When structured AKA fields were present, that synchronizer rebuilt the list as the structured primary AKA plus `existing.slice(1)`. That silently assumed the first canonical list item was the structured AKA. A client application can instead provide a list beginning with a newly reported alias, such as `TEST Alias`; in that state `slice(1)` discarded the only submitted alias.

## Repair

- The Intake synchronizer now treats the canonical alias list as authoritative regardless of ordering.
- When a lawyer has structured AKA fields, it places that structured primary alias first and retains every canonical alias except an exact normalized duplicate of that primary alias.
- A reported full alias remains an unstructured value in the editable **Additional aliases (one per line)** list; it is never guessed into first, middle, or last AKA fields.
- Existing structured primary AKA behaviour remains intact, including duplicate suppression only for the same primary name.

## Deliberate Boundaries

- No primary-name, address, client portal, contact, inventory, signatory, upload, authorization, database, API, document-generation, court-form, legal-text, or citation behaviour changed.
- Client-facing intake remains componentized: first name, middle names, last name, unit/suite, street, city, province/state, postal code, and country stay separate fields.
- The repair does not infer legal facts or rewrite existing aliases.

## Regression Coverage

1. A client-reported alias without structured AKA fields remains visible in the canonical aliases editor.
2. A client-reported `TEST Alias` remains visible as an additional alias when existing structured AKA fields contain a different name.
3. The mapper still writes client aliases only to `deceasedAliases` plus `hasOtherNames`, never to structured AKA name fields.

## Validation Evidence

| Check | Result |
| --- | --- |
| Focused Intake alias + mapper tests | **35 passed** |
| TypeScript | `pnpm check` passed |
| Full serial suite | **4,555 passed; 3 skipped** |
| Production build | passed |
| Whitespace | `git diff --check` passed |
| Runtime health | local root **200**; preview root **200** |

The build emitted existing jsPDF/chunk-size warnings only and exited successfully.
