# Client Intake Submission Success-State Audit

**Date:** 2026-10-13  
**Scope:** Executor/Client Portal post-submission experience only

## Reported symptom

After an executor sent the intake form, the portal could leave them with no durable client-facing completion state. A Sonner toast and submissions-query invalidation occurred, but the form component had no successful-submission rendering branch.

## Root cause

The mutation success callback only performed two transient actions:

1. showed a toast; and
2. invalidated `portal.clientIntakeSubmissions`.

It did not retain a component-level receipt or render a confirmed submitted state. A data refresh therefore had no stable UI state to show in place of the editable form.

## Repair

`ClientIntakeForm` now:

- records only the returned submission ID in a local receipt on mutation success;
- renders a calm, client-facing confirmation instead of the editable form after submission;
- continues rendering that confirmation from the latest authoritative `submitted` or `approved` submission after a full refresh or reload;
- deliberately omits submitted answers, names, email addresses, and other client facts from the confirmation;
- returns to the existing prefilled editable flow only when a revision request is received for the newly submitted record; and
- retains the existing toast and submissions-cache invalidation as secondary feedback.

The confirmation says the legal team will review the information before it is added to the estate file and explains that a revision request will appear on the same page if changes are needed. It makes no legal, filing, or timing claim.

## Accessibility and interaction

- Confirmation container uses `role="status"`, `aria-live="polite"`, and the accessible name **Submission confirmation**.
- Focus moves to the confirmation heading after successful submission, then proceeds to the next ordinary keyboard target without a trap.
- The success state has a visible focus treatment and responsive desktop/mobile layout.

## Regression coverage

A focused red-green test now proves that a successful mutation:

- exposes a visible success heading and named status region;
- hides the editable form and send action rather than showing a blank/ambiguous state;
- does not repeat fictional submitted answers or the access-holder email; and
- preserves the confirmation while an older revision remains during query refresh, then resumes the existing revision form when the new submission is actually marked `revision_requested`.

## Verification evidence

- Red baseline: the new success-state assertion failed at the prior checkpoint because **Your intake has been sent** did not exist.
- Focused form and Portal suites: **18 passed**.
- TypeScript: `pnpm check` passed.
- Full serial suite: **4,564 passed; 3 skipped**.
- Production build: `pnpm build` passed.
- `git diff --check` passed.
- Local `/portal` and public preview `/portal`: HTTP **200**.
- Isolated Playwright fixture: fictional tRPC responses drove a send action, server-refresh and full reload; it confirmed the visible confirmation, no submitted-data disclosure, heading focus, keyboard progression, no console errors, and a bounded mobile confirmation card. No authenticated portal session, client record, or portal link was accessed.

## Deliberate boundaries

No portal authorization, persistence, server response contract, database schema, estate data, lawyer review/application, contact/inventory mapping, court-form/document, legal, or citation behavior changed. Uploads, signatory selection, and unrelated portal backlog items remain separate tasks.
