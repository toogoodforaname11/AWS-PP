# Public FAQ Accordion Polish

**Date:** 2026-10-12  
**Scope:** Public pre-login landing-page FAQ interaction only.

## Change

The five public product answers now use the existing Radix single-open accordion pattern rather than static answer blocks. Each question is a native button with Radix-managed `aria-expanded` state and a labeled content relationship.

The FAQ cards have a restrained border/shadow response on fine-pointer hover, a clearer open state, a visible keyboard focus treatment, and a rotating disclosure icon. Answer content opens and closes through the existing reduced-motion-safe FAQ animation hook: 240 ms open and 180 ms close using the existing strong ease-out curve. Touch devices retain the tap interaction without hover-only behavior.

## Preserved

- The exact visible FAQ text and matching landing-page JSON-LD values.
- Public metadata, crawl controls, and all authentication behavior.
- Internal settings, estate data, generated documents, legal language, and citations.

## Validation

- Red regression: the new FAQ button/expanded-state test failed against the static FAQ implementation.
- Focused regression: `Landing.auth.test.tsx` and `HowItWorks.test.tsx` passed, **13 tests** total.
- TypeScript: `pnpm check` passed.
- Full serial suite: **4,485 passed; 3 skipped** across 303 files.
- Production build: `pnpm build` passed.
- Browser: clicked the Settings FAQ to open its answer, then pressed **Enter** while focused to close it. Desktop and 375px mobile screenshots show the accordion fitting the landing layout.
