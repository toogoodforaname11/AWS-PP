# Assistant right-side dock correction

**Date:** 2026-10-14  
**Scope:** Assistant launcher placement only

## Reported issue

The floating ProbatePro Assistant launcher had been moved from its established right-side dock to the lower left. The user requested that it be returned to the right and that unrequested interface changes not be made.

## Root cause

The earlier Inventory-overlap correction explicitly changed `.kairo-root` from a right-anchored position to `left: calc(var(--sidebar-width, 0px) + 20px)` with `right: auto`. Its mobile overrides and the assistant hint were changed to the left as well.

When the right anchor was restored without another adjustment, an isolated fictional Inventory fixture confirmed the original overlap: at a 1280px viewport, the assistant launcher occupied the Edit button centre (`launcher x=1140, y=730, 120x120`; Edit `x=1147, y=733.5, 32x32`).

## Repair

- Restored the launcher to the **right** at every responsive breakpoint.
- Restored the hint alignment to the right edge of the launcher.
- Kept the established lower-right dock, but placed its top at the viewport edge so an Inventory action scrolled into view lands above it.
- Added a narrow 481–767px tablet adjustment to eliminate the last 7px visual collision while retaining the right dock.
- Replaced the regression contract that required a left-side dock with one requiring right-side positioning and action clearance.

No assistant behaviour, server routes, estate data, inventory data, form logic, documents, privacy settings, or portal functionality changed.

## Verification

| Check | Result |
|---|---|
| Red regression | Confirmed the prior left-anchored CSS failed the new right-dock contract. |
| Focused assistant tests | 14 passing (`ChatbotWidget` and style-contract suites). |
| Fictional browser fixture | At 1280px, 600px, and 375px: right dock confirmed, no launcher/Edit overlap, Edit button received pointer input, keyboard Enter opened the assistant, and no browser console errors occurred. |
| Serial suite | 311 test files passed, 1 skipped; 4,586 tests passed, 3 skipped. |
| Type check | `pnpm check` passed. |
| Production build | `pnpm build` passed. Existing non-fatal jsPDF static/dynamic import warning remained unchanged. |
| Health checks | Local root and temporary public preview each returned HTTP 200. |
| Whitespace | `git diff --check` passed. |

## Files changed

- `client/src/index.css`
- `client/src/components/chatbot/chatbot-style-contract.test.ts`
