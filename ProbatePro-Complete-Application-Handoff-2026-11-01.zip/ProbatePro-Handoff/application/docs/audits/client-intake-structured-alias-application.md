# Client Intake Structured Alias Application Repair

**Date:** 2026-10-14  
**Scope:** Executor/Client Portal alternate-name capture, lawyer review, and selected application to existing Intake AKA fields.

## Root cause

The portal had only one unstructured **Other names used** input. The application correctly avoided guessing first, middle, and last-name components from that free-text report, but it therefore had no safe way to update the separate `akaFirstName`, `akaMiddleName`, and `akaLastName` Intake fields. A newly reported structured alternate name could remain unavailable while a prior structured AKA stayed visible.

## Repair

- Added optional, separately labelled portal fields for an alternate-name first name, middle name(s), and last name. The original full-name alias report remains separate.
- Extended the existing encrypted client-intake payload, review labels, revision support, and selected-field allowlist with the three structured fields.
- Mapped each **lawyer-selected**, non-empty structured field to only its matching existing Intake AKA column. Free-text aliases are never split or inferred.
- Set the existing `hasOtherNames` state to `yes` when a selected structured AKA part is applied, so the corresponding Intake controls remain visible after refresh.
- Kept the existing newest-approved full-alias report behavior: structured alias fields do not add, replace, or reintroduce entries in the full-alias list.
- Added the submitted structured values to the completed client-intake PDF record, without changing court-form content or document generation.

## Safety and accessibility

The portal presents the fields in a native `<fieldset>` with an explicit legend and individual labels. Keyboard Tab advances through the three inputs in order. Blank structured values cannot be selected or used to clear an existing AKA value. The lawyer retains explicit, per-field approval control.

No authenticated estate, executor, client, or production portal session was accessed. Browser testing used fictional tRPC fixtures only.

## Validation evidence

| Check | Fresh result |
|---|---|
| Red regressions | Failed as expected before the implementation: unknown payload keys, unsupported approval fields, missing portal controls, omitted PDF rows, and missing other-names state transition |
| Focused suites | **140 passing** across client-intake mapper, router, persistence, portal form, review, PDF, and Intake alias tests |
| TypeScript | `pnpm check` passed |
| Browser | Fictional desktop and 390 px mobile portal flows verified labelled controls, ordered keyboard focus, exact submitted payload values, accessible success confirmation, no console errors, and in-bounds structured inputs |
| Full serial suite | **4,585 passing / 3 skipped** |
| Production build | Passed; known pre-existing jsPDF dynamic/static-import and chunk-size warnings remain unrelated |
| Hygiene and health | `git diff --check` passed; local and preview `/` and `/portal` returned HTTP 200 |

> The browser fixture also observed a pre-existing 390 px portal-header overflow from the **Sign Out** control (`scrollWidth` 470). The new structured alias controls stayed within 58–332 px and this unrelated header behavior was not changed in this isolated repair.

## Deliberate boundaries

No database schema or migration, existing estate record, portal authorization, contact/inventory workflow, court-form wording, generated form layout, or general alias-report replacement behavior was changed.
