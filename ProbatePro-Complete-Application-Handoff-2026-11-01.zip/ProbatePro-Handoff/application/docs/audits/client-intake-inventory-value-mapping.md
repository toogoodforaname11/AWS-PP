# Client intake inventory value mapping repair

**Date:** 2026-10-12
**Status:** Complete — separate task 2 of the reported Client Portal defects

## Reported behavior

When the lawyer selected **Apply all ready facts**, a client-reported $400,000 house and $12,000 bank account appeared as $0.00 in the estate record’s current P10/readiness value path.

## Root cause

The portal has one client-facing `value` input per estate item. Its application mapper correctly converted the dollar string to cents but wrote only the generic Inventory `value` column.

The inventory model intentionally uses category-specific sources for probate value:

| Client item category | Canonical value read by P10/readiness |
|---|---|
| `real_property` | `assessedMarketValue` |
| `financial` | `dateOfDeathValue` |
| Other categories, including liabilities | `value` |

Because `valueRecorded` was set to `1`, the existing `probateItemValue()` helper correctly preferred the category-specific source; that source had remained at its database default of zero.

## Repair

The selected item application now:

1. Converts the client-provided dollar value to integer cents once, with the existing safe-integer guard.
2. Preserves the generic `value` field for legacy consumers.
3. Sets `assessedMarketValue` to the same cents for selected real-property values.
4. Sets `dateOfDeathValue` to the same cents for selected financial values.
5. Keeps `valueRecorded = 1`, including for an intentional reported $0.

No amount is created when the client leaves the amount blank, and no real-property, financial, liability, or other inventory category is reclassified.

## Regression proof

The red regression used the exact reported shape:

- House: `$400,000` → `value` and `assessedMarketValue` both `40,000,000` cents.
- Bank account: `$12,000` → `value` and `dateOfDeathValue` both `1,200,000` cents.

It failed before the repair because both category-specific fields were absent, then passed after the repair. Existing `probateItemValue()` tests also confirm that real property and financial assets read their category-specific source when `valueRecorded = 1`.

## Validation

| Check | Result |
|---|---|
| Focused mapper, inventory semantics, and approval tests | 35 passed |
| TypeScript | Passed (`pnpm check`) |
| Full serial suite | 4,546 passed; 3 skipped |
| Production build | Passed |
| Whitespace and scoped diff | Passed |
| Local and public preview health | HTTP `200` / `200` |

## Scope held

This task changes only selected inventory-value application. It does not change client field layout, forms, document rendering, court-form wording/layout, legal/citation text, existing estate data, uploads, links, signatory selection, will location, review-conflict handling, labels, or alias decomposition.

The client-facing intake’s existing separate name and address components were not collapsed or altered. The next form/UI task must retain separate first, middle, and last name and separate street, unit, city, province, postal code, and country values so the lawyer can review and apply each to the correct destination field.
