# Client intake contact application repair

**Date:** 2026-10-12
**Status:** Complete — separate task 1 of the reported Client Portal defects

## Reported failure

“Apply all ready facts” could fail when it included a newly reported contact. The browser received the raw storage error, including submitted contact details.

## Root cause

The deployed TiDB `contacts` table contains two historic non-null text columns — `committeeAddress` and `priorityConsentInquiryDetails` — without database defaults. New client-intake contacts supplied only the source-schema defaults, so the `INSERT ... ON DUPLICATE KEY UPDATE` failed before any selected facts could be committed.

## Repair

- `clientIntakeContactDefaults` now supplies explicit empty values for both legacy non-null fields when it creates a client-reported contact.
  - Empty strings preserve the fact that the client did **not** provide committee or priority-consent details.
  - Existing contacts remain untouched because the values are defaults for an inserted row only; the duplicate-key update still changes only lawyer-selected fields.
- The client-intake approval route now preserves intentional tRPC and revision-conflict messages but converts unexpected persistence errors to:

  > The selected facts could not be applied. No changes were saved. Refresh and try again.

  It logs only estate/submission identifiers plus error class/code server-side. It does not return raw SQL, submitted email, phone, other client values, or storage implementation details.

## Regression coverage

1. A mapping regression requires every known legacy non-null/no-default contact field to be supplied for a new client contact.
2. A router regression proves an unexpected persistence error becomes the safe generic error rather than the source error that contains a test email/phone.
3. The existing atomic persistence tests continue to cover estate revision, review selection, contact/inventory write ordering, and encrypted values.
4. A direct schema-level reproduction used only synthetic values in a transaction with `FOREIGN_KEY_CHECKS` disabled and rollback; the repaired insert succeeded and no row persisted.

## Validation

| Check | Result |
|---|---|
| Focused mapping, router, and persistence tests | 60 passed |
| TypeScript | Passed (`pnpm check`) |
| Full serial suite | 4,545 passed; 3 skipped |
| Production build | Passed |
| Whitespace and scoped diff | Passed |
| Local + public preview HTTP health | `200` / `200` |
| Browser runtime | Public landing loaded without a console/runtime failure; no authenticated estate or client record was opened |

## Deliberately out of scope

This task does **not** change the other independently reported defects: monetary field mapping, will-location destination, false review conflict, readable enum labels, alias decomposition, uploads, or signatory choice.

The next client-facing intake task must preserve **separate structured fields** — including first, middle, and last name, and address, city, province, postal code, and country — so each can be reviewed and applied to the matching estate/contact field. It must not collapse those values into a single free-text field.

No court forms, document rendering, legal/citation text, portal authentication, estate records, user records, or production client submissions were changed or inspected.
