# Client Intake Contact Role Display Audit

**Completed:** 2026-10-13

## Issue

Contacts created from a client intake submission could show the persisted role token `client_reported_person` verbatim. A non-executor client-reported person could also display the internal executor-status placeholder `unknown` as a status badge.

## Cause

The Contacts tab rendered each parsed storage token directly rather than using the application's role-label helper. Its executor-status badge was not scoped to executor-capable roles, even though older database schemas require the client-intake creation path to persist a non-null `unknown` placeholder.

## Repair

- Added the curated user-facing label **Client-reported person**.
- Routed Contacts-tab role badges through the shared `roleLabel()` helper.
- Limited executor-status badges to executor, alternate-executor, and applicant roles.
- Converted empty or legacy `unknown` executor status on those roles to the neutral **status not set** cue.
- Preserved the existing database persistence default and all contact classification, legal facts, application logic, and court-form behavior.

## Regression coverage

The Contacts-tab regression uses one client-reported contact with `executorStatus: "unknown"` and one executor with the same legacy placeholder. It verifies that the raw role and placeholder are absent, the client-reported role is readable, and only the executor receives the neutral status prompt.

## Validation

- Focused client role, mapper, and persistence checks: **47 passed**
- TypeScript: **passed**
- Full serial test suite: **4,559 passed, 3 skipped**
- Production build: **passed**
- `git diff --check` and targeted trailing-whitespace check: **passed**
- Local and preview root health: **HTTP 200**
