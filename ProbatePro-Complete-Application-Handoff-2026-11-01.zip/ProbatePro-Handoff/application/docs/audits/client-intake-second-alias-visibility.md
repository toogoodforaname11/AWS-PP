# Client Intake Second-Alias Visibility Audit

**Date:** 2026-10-13  
**Scope:** Estate Intake presentation of an already-applied Client Portal alias only

## Reported symptom

When an existing structured AKA showed the first alias, a second portal-reported alias could be marked **Applied** yet remain invisible in Intake. The user could see only the structured AKA fields, creating the appearance that the later alias had not been applied.

## Root cause

The alias list editor was gated by the legacy `hasAdditionalNames === "yes"` flag whenever the structured AKA fields contained a value. Client Portal application deliberately preserves full aliases in the canonical `deceasedAliases` list and does not guess first/middle/last parts or alter lawyer-controlled structured fields. Consequently, a real second alias in that canonical list was hidden if the historic flag remained `no`.

The textarea also assumed that the structured AKA was always the first list element (`slice(1)`). That positional assumption was unnecessary and fragile.

## Repair

The Intake view now normalizes alias strings for comparison and derives additional aliases from the canonical list, excluding only a normalized duplicate of the structured AKA. It shows the **Additional aliases (one per line)** editor whenever a distinct canonical alias exists, irrespective of the legacy flag, and displays the derived values rather than relying on list position.

The structured `AKA First Name`, `AKA Middle Name`, and `AKA Last Name` remain untouched. This is a presentation correction only: it does not infer name parts, rewrite the portal payload, alter persistence, or change form rendering.

## Regression and verification

A red-green Intake regression creates the exact fictional state: structured AKA `TEST Alias`, canonical portal alias `TEST Alias Two`, and `hasAdditionalNames: "no"`. It failed before the change because the labelled additional-alias editor did not exist, then passed after the repair.

Validation evidence:

- Focused Intake, mapping, and canonical-alias suites: **321 passed**.
- TypeScript: `pnpm check` passed.
- Full serial suite: **4,565 passed; 3 skipped**.
- Production build: `pnpm build` passed.
- `git diff --check` passed.
- Local and preview route health: HTTP **200**.
- Isolated Playwright fixture: a fictional authenticated workspace rendered `TEST Alias` in structured AKA inputs and `TEST Alias Two` in the visible additional-alias editor at desktop and 375px widths, with no console errors or unhandled mocked requests. No live estate, executor portal session, or client record was accessed.

## Boundaries

No server route, application decision, database/schema, authorization, portal link, contact, inventory, court-form/document, legal, or citation behavior changed. The remaining reported portal issues are separate tasks.
