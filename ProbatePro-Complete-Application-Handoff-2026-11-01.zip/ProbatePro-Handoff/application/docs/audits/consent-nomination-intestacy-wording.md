# Consent and Nomination — Intestacy Wording and Relationship Orientation

## Defect

The Consent and Nomination source-template renderer retained **grant of probate** wording for an estate explicitly recorded as having no will. Its dialog also labeled the relationship input from the inverse perspective, even though the rendered source sentence is:

> “I nominate my [relationship], [nominee] …”

For example, when Laura nominates her father Gordon, the value needed by that sentence is **father**, not child.

## Repair

- The DOCX renderer and structured preview now select **administration** when `estateWillStatus()` records `no_will`; recorded will paths retain **probate**.
- The relationship input now says **“Nominee’s relationship to the signer”**, uses **“e.g., father”** as its example, and shows the exact sentence shape before generation.
- The relationship remains an expressly confirmed per-document fact. The application does not infer a relationship from names or invent one.

## Scope Boundary

This repair does **not** calculate or overwrite a beneficiary share. Laura’s reported half-residue/0% issue is an independent task and remains outside this change. It also does not alter the source template’s layout, signing block, recipient identities, or any P-form.

## Verification

- Added DOCX and structured-preview regression coverage for a no-will consent that names the nominee as the signer’s father and confirms no probate wording remains.
- Retained the recorded-will consent regression.
- Ran focused server and dialog tests, TypeScript verification, the full serial suite (4,432 passing; 3 skipped), production build, and whitespace validation.
