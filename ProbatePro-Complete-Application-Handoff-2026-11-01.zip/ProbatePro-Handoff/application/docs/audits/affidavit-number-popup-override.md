# Affidavit Number Popup Override

## Scope

This change gives the user a document-local choice for the visible affidavit number while retaining the existing automatic sequencing as the default. It applies to every renderer that prints the affidavit-number caption:

| Forms | Numbering behaviour |
| --- | --- |
| P3–P10, P12, P14–P16, P26, P34, P45 | Automatic per-deponent ordinal unless a number is entered in Form Details |
| P11 | Same document-local choice; it overrides the legacy stored P11 header value for that one generation |

## Document-facing behaviour

1. The Form Details popup now includes **Affidavit number (override)** for the applicable affidavits.
2. Leaving it blank preserves the existing automatic result: `1st`, `2nd`, `3rd`, and so on, based on the deponent's recorded affidavit history.
3. Entering a positive number, with or without an ordinal suffix (for example, `6` or `6th`), prints the normalized value on that document only.
4. The number is carried to **preview**, the regular tRPC document download, and the direct download route, so the preview and DOCX agree.
5. Invalid free text is rejected as actionable validation before rendering; it cannot silently create an unsupported affidavit caption.

## Safeguards

- The override is **not** saved to estate intake or affidavit history.
- The automatic sequence remains the default and continues to be used for later documents.
- P11 retains support for legacy `p11AffidavitOrdinal` data, but a current popup choice takes priority for the current DOCX and preview.
- The change does not alter official wording, form layout, indentation, checkbox geometry, selected-only rendering, page breaks, affidavit identity, date, oath, or jurat logic.

## Validation

- Confirmed every `styleOfCause` call that prints an ordinal caption has a Form Details override path.
- Added Form Details, tRPC generation/preview, direct-download, and P11 DOCX/preview precedence regressions.
- Focused suite: **158 passing**.
- TypeScript: **passed**.
- Full serial suite: **4,474 passing / 3 skipped**.
- Production build and `git diff --check`: **passed**.
