# Consent and Nomination half-residue share safeguard

_Implementation record for the independently scoped beneficiary-share repair — ProbatePro, 2026-10-08_

---

## 📋 Defect boundary

The Consent and Nomination source template has a percentage-only signer variable. Its dialog previously copied a contact's stored percentage verbatim; a default or legacy `0` therefore produced `0%` even where the completed no-will distribution recorded the signing descendant as taking one-half of the residue.

This repair addresses only that stale-zero outcome. The document's approved wording, one-page geometry, signature block, and all non-share template variables remain unchanged.

## ⚙️ Resolution

| Condition | Consent percentage behaviour |
| --- | --- |
| Completed no-will distribution identifies the **signing descendant** as taking one-half of residue | Prefill and render `50` for the source-template percentage variable |
| Distribution is incomplete or unallocated | Retain the signer-confirmed value; never infer a percentage |
| Signer is a spouse with preferential share plus a half-residue component | Retain the signer-confirmed value; never collapse the composite entitlement to `50` |
| Will-based estate or another determined distribution path | Retain the signer-confirmed value |

The Forms tab shows a concise explanation when it supplies the confirmed descendant half-residue prefill. The value remains per-document and is not written back to the estate record.

## ✅ Verification

- DOCX and structured-preview regression: a completed no-will descendant half-residue path replaces a stale `0` with `50`
- DOCX and structured-preview regression: a spouse's preferential-plus-half entitlement is not reduced to `50`
- Dialog regression: the confirmed descendant half-residue value appears as `50` with its review note
- Focused consent document and dialog tests passed
- TypeScript check passed
- Full serial suite passed: 4,435 tests passed and 3 skipped
- Production build passed

## 📌 Scope retained

This change does not calculate or display a general percentage for every statutory distribution, alter beneficiary records, or change the earlier separate repair for consent wording and relationship orientation. It also does not address the separate TD creditor notice/P9 recipient task or the P44 lawyer-signature task.
