# Personal Executor Letter Settings Audit

**Date:** 2026-10-11  
**Scope:** Settings availability for beneficiary-letter configuration only.

## Finding

Personal-executor accounts were denied all letter configuration through a client-side presentation gate. `Settings` removed the Letter template and Closing block navigation links, and `FirmSettingsSection` returned `null` for `accountPurpose === "personal_executor"`. This contradicted the existing account-purpose definition: it is a workspace preference, not an access boundary. The protected settings API already accepts each relevant value for any authenticated account, and the LETTER renderer already consumes those shared values without an account-purpose check.

## Repair

Personal executors now receive a neutral **Letters** Settings section. It exposes the existing DOCX/image letterhead controls, beneficiary-letter body template, closing block, custom-letterhead sender-text suppression, and adjacent beneficiary signing-contact suppression. The text-suppression control now uses neutral sender wording and explicitly states that the closing and signature block remain visible.

Lawyer accounts retain the existing Firm details navigation, profile fields, and save workflow. Personal executors do not receive lawyer/firm profile and service-contact fields. No API, schema, migration, document-generation path, official court-form wording, or document geometry changed.

## Regression Coverage

The focused Settings regression starts from a personal-executor account with an uploaded DOCX letterhead and proves all of the following:

- The Letters, Letter template, and Closing block anchors are available and valid.
- Professional profile controls remain absent.
- Template and closing saves use the existing settings update mutation.
- The beneficiary signing-contact checkbox persists `hideBeneficiaryLetterSigningContact`.
- The custom-letterhead sender-text switch persists `suppressFirmText`.

## Validation Evidence

- `pnpm exec vitest run client/src/pages/Settings.test.tsx --maxWorkers=1` — 24 passing.
- `pnpm exec vitest run client/src/pages/Settings.test.tsx server/letter-template.test.ts --maxWorkers=1` — 40 passing.
- `pnpm exec vitest run server/letterhead-assets.test.ts server/letterhead.test.ts --maxWorkers=1` — 11 passing.
- `pnpm check` — passed.
- `pnpm test -- --maxWorkers=1` — 4,474 passing, 3 skipped.
- `pnpm build` — passed.
- `git diff --check` — passed.
- Local and temporary public development health probes both returned HTTP 200.
