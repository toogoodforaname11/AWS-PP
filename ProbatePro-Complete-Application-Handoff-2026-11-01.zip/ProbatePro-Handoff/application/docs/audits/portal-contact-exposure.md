# Portal Contact Exposure Audit

**Date:** 2026-10-13
**Scope:** Client-facing portal contact disclosure only

## Issue

A person holding a valid Executor/Client Portal link could request and view the estate contact list. This exposed each listed contact's name, role, and relationship through both the `portal.contacts` server procedure and a Contacts card in the public portal.

## Repair

- Removed the `portal.contacts` procedure from the portal router. The bearer-link session now has no contact-list capability to invoke.
- Removed the client-side contact query and Contacts card from the portal page.
- Preserved the client-intake form, access holder prefill, minimal estate summary, masked inventory display, activity display, and lawyer-side contact management.
- Added a server regression proving `portal.contacts` is absent from the router and a portal-page regression that intentionally supplies no contact query while confirming the client intake still renders.

## Boundaries retained

This repair does not alter portal authentication, one-time-link handling, client submission storage, lawyer review/application controls, estate contacts, inventory records, court forms, or document generation.

## Validation

- Focused portal boundary tests: **8 passed**
- TypeScript: `pnpm check` passed
- Full serial suite: **4,556 passed, 3 skipped**
- Production build: passed
- Search confirmed no `portal.contacts` procedure or portal-page query remains
- `git diff --check`: passed
- Local and preview root health: HTTP **200**
