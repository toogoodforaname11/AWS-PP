# Client Intake Contact Address Application Repair

**Date:** 2026-10-13  
**Status:** Complete  
**Scope:** Executor/Client Portal structured contact details only

## Reported defect

New contacts created from a submitted client intake could show a relationship but leave the Contacts editor's **Residential Address** and **City / Country** fields blank. The portal had collected an address, but the application path did not feed the contact fields used by the estate editor.

## Root cause

The portal contract exposed only one generic `address` value for executors and family members. The mapper applied that value to `postalAddress`, while the Contacts editor and contact-card state use distinct `residentialAddress`, residence components, and `cityCountry` fields.

The submitting client's address had separate source fields, but review collapsed them into one contact value, preventing lawyers from independently selecting and applying each address component.

## Repair

- Added separately captured residential street, unit/suite, city/town, province/state, postal/ZIP code, and country fields for reported executors and other persons.
- Added the missing country field for the submitting client's own address.
- Made all address components individually visible and selectable during lawyer review.
- When selected, maps only reported values into the existing contact destinations:
  - `residenceStreet`, `residenceCity`, `residenceProvince`, `residencePostalCode`, `residenceCountry`
  - derived display fields `residentialAddress` and `cityCountry`, composed only from selected submitted components
- Retained the old one-line `address` key for historical submissions. It now lands unchanged in `residentialAddress`; no city, country, or other component is parsed or invented.
- Kept relationship mapping explicit and separately reviewable for the submitting client, executors, and other reported people.
- Added the structured fields to the completed-intake PDF export labels.

## Privacy and safety boundaries

- No estate records, portal sessions, or client data were opened or altered.
- Browser validation used only a fictitious estate and contacts.
- Address values still require lawyer selection and approval before changing the estate file.
- No changes were made to court forms, document generation, legal wording, contact roles, permissions, or database schema.

## Validation evidence

| Check | Result |
|---|---|
| Red regression | Confirmed the old strict contract rejected structured contact address facts. |
| Mapping regressions | 15 passing in `server/clientIntakeMapping.test.ts`, including three fictional contacts and an old one-line address case. |
| Focused portal suites | 76 passing across mapping, router, portal form, review, and completed-intake PDF tests. |
| TypeScript | `pnpm check` passed. |
| Fictional browser flow | Submitted client, executor, and family relationship/address/country values; success confirmation was accessible and focused; no console errors. |
| Mobile fixture | Structured Country control fit inside the 390 px fixture (`274 px` wide). |
| Full serial suite | 4,567 passed, 3 skipped. |
| Production build | Passed; existing jsPDF dynamic/static import and bundle-size warnings remain non-fatal and unchanged. |
| Health checks | Local `/portal` and temporary preview `/portal` both returned HTTP 200. |
| Diff hygiene | `git diff --check` passed. |

## Deliberate exclusions

This repair does not address the separate raw role-chip, unsolicited “Intake changes saved” toast, help-bubble overlap, alias display, or other portal backlog items.
