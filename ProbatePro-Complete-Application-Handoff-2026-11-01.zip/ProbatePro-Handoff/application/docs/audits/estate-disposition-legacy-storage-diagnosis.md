# Estate Disposition Legacy-Storage Diagnosis

**Status:** Configuration and provider-control blocker; no estate data was deleted.

## Observed symptom

An estate deletion attempt was refused before the database transaction removed any estate rows. The visible error identified a generated-document key that had no durable manifest row.

## Root cause

The active deployment has the platform's built-in Forge storage credentials but no configured `STORAGE_S3_*` profile. The platform storage helper can write and read known keys, but its supported interface does not expose an underlying permanent-delete operation. It therefore cannot produce the object-level deletion verification that ProbatePro's estate disposition requires.

The specific estate also has at least one older generated-document reference without a corresponding durable `stored_objects` manifest row. The current transaction correctly refuses to remove the estate database rows in that state, because doing so could make the provider object untraceable and leave it retained.

There are therefore two separate prerequisites for a verified permanent disposition:

1. A deletion-capable approved storage provider must be configured for future records and the outbox.
2. Existing platform-store records must be migrated with byte verification and the legacy provider must supply evidence that the legacy source objects were permanently destroyed. A database-only deletion is not a substitute for that evidence.

## Legal and professional-control context

PIPA section 35(2) requires an organization to destroy documents containing personal information, or remove the means of associating it with individuals, once the original purpose is no longer served and retention is no longer needed for legal or business purposes. PIPA section 34 also requires reasonable safeguards against unauthorized disposal.

The Law Society of BC's closed-file guidance states that a lawyer using a storage provider must ensure the provider will not fail to destroy records completely and permanently on the lawyer's instructions, while preserving the lawyer's ownership, custody/control, and ability to produce records.

These sources describe the legal and professional-control context; they are not a conclusion that every estate may be destroyed immediately. The application's existing created-in-error and retention-complete attestations remain necessary.

## Safe remediation boundary

Do not weaken the manifest or provider guard, delete only database rows, or mark a platform-store object as destroyed without provider evidence. Doing either would produce a false deletion result.

After an approved AWS S3 Canada storage profile and provider evidence are available:

1. Configure the storage secrets and validate the provider profile.
2. Migrate every current platform-store reference to the approved provider, with exact byte checks and durable manifests.
3. Obtain/provider-record complete legacy-store source-destruction evidence before relying on the new profile for legacy records.
4. Reattempt the estate disposition. The existing outbox then deletes every exact-key object, verifies absence, and retains a destruction audit until complete.

## Sources

- [BC Personal Information Protection Act, ss. 34–35](https://www.bclaws.gov.bc.ca/civix/document/id/complete/statreg/00_03063_01/)
- [Law Society of BC, *Closed Files: Retention and Disposition*](https://www.lawsociety.bc.ca/getContentAsset/5514cbd5-4b99-43d0-8ede-5af8af1b8f4d/dfc3d011-8f63-43f6-9ed8-4b444333a1d0/ClosedFiles.pdf?language=en-CA)
