# Client Intake False Conflict Repair Audit

**Date:** 2026-10-12  
**Scope:** Immediate successive client-intake applications in the lawyer-only estate Client Portal review.

## Reported symptom

A lawyer could apply a client fact successfully, then quickly apply another fact and receive the misleading message that the Intake had changed while they were reviewing it.

## Root cause

`ClientIntakeReview` continued to send the revision received as a prop until the estate query invalidation/refetch completed. A successful partial application increments the estate revision atomically, so a second application in that interval legitimately reached the server with the prior revision and triggered the existing optimistic-concurrency guard.

## Repair

- Added a local **confirmed revision** token in `ClientIntakeReview`.
- The token initializes from, and synchronizes with, the parent-provided estate revision.
- A successful apply or undo advances the local token from the mutation result before cache invalidation completes.
- Apply and undo requests now use that confirmed token.
- The database optimistic-concurrency condition remains intact, so an actual concurrent estate edit still returns a conflict rather than being overwritten.

## Regression evidence

A focused component test reproduced the actual timing window:

1. Apply a first fact at revision `4`.
2. Deliver a successful mutation result with revision `5`.
3. Apply a different fact before mocked query data changes.
4. Assert that the second request carries revision `5`.

The test failed before the repair with `expectedRevision: 4`, then passed after it.

## Validation

| Check | Result |
| --- | --- |
| Focused review regression | 16 passed |
| TypeScript | Passed (`pnpm check`) |
| Full serial suite | 4,549 passed; 3 skipped |
| Production build | Passed |
| Whitespace | Passed (`git diff --check`) |
| Runtime health | Local and preview roots returned HTTP 200 |

## Preserved boundaries

No schema or migration changed. No server-side revision guard, submission-state guard, undo snapshot, client data, contact/inventory mapping, court-form/document output, legal wording, or portal access behavior changed. The remaining reported portal defects remain separate tasks.
