# Contact Edit Dialog Role-Label Repair

**Date:** 2026-10-13  
**Status:** Complete  
**Scope:** Human-readable role display in the Contacts edit dialog only

## Reported defect

A client-intake-created contact correctly displayed **Client-reported person** on its contact card, but the Roles chip inside the Edit Contact dialog displayed the raw stored value **Client_reported_person**.

## Root cause

The contact card already uses the shared `roleLabel()` formatter. The edit-dialog chip used a separate first-character-uppercase expression, which did not replace underscores or apply the curated client-reported label.

## Repair

The edit-dialog chip now calls the existing shared `roleLabel()` helper. This keeps labels consistent across the card and dialog while preserving the stored role token, role-menu choices, role mutations, filters, and contact persistence behavior.

## Regression coverage

A focused UI regression opens an actual Edit Contact dialog for a fictional `client_reported_person` contact and verifies:

- the dialog chip reads **Client-reported person**;
- the raw token does not appear in the dialog; and
- the existing card and executor-status presentation stay intact.

The regression was run red before the source change and green afterward.

## Browser validation

An isolated fictional estate fixture validated the dialog without accessing real records:

- keyboard activation of **Edit Morgan Relative** opened the desktop dialog;
- the dialog showed **Client-reported person** and no raw token;
- no console errors occurred; and
- the mobile fixture rendered the corrected role label.

> The mobile fixture also exposed a pre-existing off-screen Contact edit dialog geometry issue at 375 px. It is not part of this text-label repair and was not changed here.

## Validation evidence

| Check | Result |
|---|---|
| Exact-symptom red regression | Failed before the repair because the dialog chip rendered `Client_reported_person`. |
| Focused role-chip regression | Passed after the repair. |
| Contacts dialog suite | 6 passing. |
| TypeScript | `pnpm check` passed. |
| Full serial suite | 4,567 passed, 3 skipped. |
| Production build | Passed; existing jsPDF import/chunk-size warnings remain unchanged and non-fatal. |
| Health checks | Local and temporary preview estate routes both returned HTTP 200. |
| Diff hygiene | `git diff --check` passed. |

## Deliberate exclusions

No contact role data, database schema, application logic, contact creation, client portal mapping, court forms, generated documents, or other portal backlog item was changed.
