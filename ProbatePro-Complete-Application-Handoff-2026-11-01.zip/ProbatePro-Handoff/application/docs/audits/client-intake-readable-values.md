# Client Intake Review — Readable Values Audit

**Completed:** 2026-10-12
**Scope:** Lawyer-facing Client Portal review display only

## Problem

The review panel exposed persisted internal tokens instead of readable values. Examples included `in_bc`, `will`, `no_will`, and lower-case field/category identifiers. The same issue could appear in the current-Intake comparison for scalar select fields.

## Repair

- Added display mappings for will status, First Nation status, inventory location, inventory category, item subfield labels, person subfield labels, and reported-document labels.
- Formats the client-reported inventory amount as Canadian currency in the review panel.
- Uses the same readable formatter for scalar **Current Intake** comparison values.
- Clarified dependent actions as **Apply full name first** and **Apply item description first**.
- Kept a separate `rawValue` on review-field descriptors. The server-side mapper now uses that raw stored value exclusively, while the UI renders the formatted `value`.

> The initial display implementation made the raw/application distinction explicit because applying formatted values would be unsafe. The final mapper is pinned by existing structured-application tests: it continues to store enum tokens and converts client amounts to integer cents as before.

## Preserved boundaries

- No schema or migration.
- No portal submission, selection key, ownership, authorization, review-state, undo, or cache contract change.
- No change to client input structure: first/middle/last name and address components remain separate fields.
- No court form, document, official wording, legal citation, or estate-data migration change.

## Verification

| Check | Result |
| --- | --- |
| Red regression | Confirmed raw `in_bc` / lower-case review labels before repair |
| Focused tests | 27 passed: `server/clientIntakeMapping.test.ts`, `ClientIntakeReview.test.tsx` |
| TypeScript | Passed: `pnpm check` |
| Full serial suite | Passed: **4,551 passed / 3 skipped** (310 passed files, 1 skipped) |
| Production build | Passed: `pnpm build` |
| Whitespace/scope | Passed: `git diff --check` and scoped review |
| Runtime health | Local and preview root returned HTTP 200 |

The production build retains the pre-existing chunk-size advisory; it is not caused by this display-only repair.
