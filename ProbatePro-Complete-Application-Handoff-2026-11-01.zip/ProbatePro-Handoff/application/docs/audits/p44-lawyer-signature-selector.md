# P44 lawyer signature selector

_Implementation record for Form P44 — Notice of Withdrawal of Application_

---

## 🔍 Finding

The P44 DOCX and preview renderer already selected the correct existing official signature caption when `signatoryType` was `lawyer`. The Forms page did not expose that selection for P44 because P44 had no `FORM_DETAILS` entry, so its generation path skipped the shared signature-and-date dialog.

## 🔧 Repair

P44 now uses the existing signed-form dialog fields: **Signatory** and **Signature date**. Selecting Lawyer passes the existing `lawyer` value to the existing P44 renderer, which prints only the established `Signature of lawyer for applicant(s)` branch. Selecting Executor retains the applicant branch.

No court-form text, DOCX geometry, preview layout, or signature-block renderer changed.

## ✅ Verification

The regression first failed while `FORM_DETAILS.P44` was absent, then passed after the entry was added. Focused dialog and DOCX/preview P44 tests passed, as did TypeScript, the full serial suite (**4,448 passed; 3 skipped**), production build, and whitespace checks.

## Addendum — Optional P44 route

The ordinary P44 row already opened the shared signer dialog, but the **Optional** row’s applicability confirmation bypassed it and generated with the ambient default signer. The confirmation now transitions to the same **Signatory** and **Signature date** dialog before preview or generation. Its document-only applicability context is retained through that handoff; it does not write Intake facts.

The P44 DOCX and preview renderer, court-form wording, signature captions, geometry, indents, and page behavior remain unchanged. A Forms-tab regression exercises the exact Optional → confirmation → Lawyer → Generate sequence.

**Verification:** focused P44 workflow suite (100 tests), TypeScript, full serial suite (**4,449 passed; 3 skipped**), production build, and whitespace checks passed.
