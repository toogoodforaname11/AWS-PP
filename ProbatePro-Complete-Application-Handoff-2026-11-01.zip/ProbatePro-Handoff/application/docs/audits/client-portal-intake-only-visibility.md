# Client portal intake-only visibility

**Date:** 2026-10-14  
**Scope:** Executor/client portal visible content only

## Request and boundary

The executor/client portal must show the client intake experience only. The user clarified that the portal should continue requesting the estate context, but it must not display an estate summary. The portal must also not request or display masked Inventory or Recent Activity information.

## Root cause

`PortalContent` queried the estate, Inventory, and activity endpoints, then rendered each result below `ClientIntakeForm`. `PortalHeader` also used the estate result to expose the deceased’s name and file number.

## Repair

- Preserved the authenticated `portal.estate` query without rendering its returned fields.
- Removed the estate name and file number from the client header.
- Removed the visible **Estate Summary**, **Inventory (Masked Values)**, and **Recent Activity** panels.
- Removed the `portal.inventory` and `portal.activity` calls from the client portal.
- Left the intake form, its prefill data, submitted-answer receipt, revision flow, session access, and Sign Out control intact.

No authorization contract, server handler, estate data, inventory data, document generation, form logic, or lawyer workspace was changed.

## Regression coverage

The portal-page regression covers the precise boundary: it requires one estate-context query, forbids Inventory and activity queries, confirms the client intake renders, and confirms that the estate summary, masked inventory, and recent-activity text do not render.

## Verification

| Check | Result |
|---|---|
| Red regression | Confirmed the former portal rendered **Estate Summary** and failed the client-only visibility assertion. |
| Corrected regression | Passed while requiring the retained estate request and no Inventory/activity requests. |
| Focused tests | 20 passing (`Portal` and `ClientIntakeForm` suites). |
| Synthetic browser | Desktop and 375px phone coverage confirmed an initial estate request, no Inventory/activity calls, no visible summary panels, submitted-answer receipt, keyboard flow, no overflow, and no console errors. |
| Serial suite | 311 test files passed, 1 skipped; 4,586 tests passed, 3 skipped. |
| Type check | `pnpm check` passed. |
| Production build | `pnpm build` passed. Existing non-fatal jsPDF static/dynamic import warning remained unchanged. |
| Health checks | Local `/portal` and temporary public-preview `/portal` each returned HTTP 200. |
| Whitespace | `git diff --check` passed. |

## Files changed

- `client/src/pages/Portal.tsx`
- `client/src/pages/Portal.test.tsx`
