# Client Intake Will-Location Application Repair

**Date:** 2026-10-12
**Scope:** One Client Portal application defect — the selected “Will location” fact appeared applied but was neither persisted to a canonical estate field nor visible in Intake.

## Root cause

The client-intake mapper already selected `willLocation`, but `estates` had no corresponding Drizzle schema column. The generic approval transaction therefore omitted the field from its estate patch. The existing `wills_search` table is a retired, read-only legacy workflow and was not an appropriate destination or current Intake source of truth.

## Repair

- Added estate-scoped `willLocation`, preserving the existing portal’s **500-character** shared-payload validation.
- Added migrations **0171** (the additive column) and **0172** (row-width-safe storage conversion).
- Used `TEXT` at the schema/source level so a fresh MySQL installation remains within the project’s enforced aggregate estate `VARCHAR` budget. The migration runner adapts it to TiDB-compatible `VARCHAR(16383)` with `NOT NULL DEFAULT ''`; the physical column was verified after migration.
- Added **Where the original will is kept** to the existing **Information About the Will** Intake section for estates recorded with a will.
- Confirmed selected Client Portal will-location application writes the canonical estate field and that the existing one-step application undo restores its prior value.

## Preserved boundaries

- No court form, generated document, official wording, layout, indent, geometry, or document behavior changed.
- No legacy Wills Search records were changed or reactivated.
- No submitted contact/inventory/client data was read during diagnosis or validation.
- No change was made to the remaining separately scoped client-portal defects: false conflict handling, readable labels, other-name structure, upload, and signatory collection.

## Validation evidence

| Check | Result |
| --- | --- |
| Focused mapping, router, persistence, Intake-editor, undo, and migration-integrity tests | **77 passed** |
| TypeScript | `pnpm check` passed |
| Migration + schema check | `pnpm db:migrate && pnpm db:check` passed; all 28 tables in sync |
| Physical TiDB column | verified `willLocation` is `VARCHAR(16383)`, `NOT NULL`, default empty |
| Full serial suite | **4,548 passed, 3 skipped** |
| Production build | `pnpm build` passed |

> The first full-suite run correctly caught the row-width guard after the initial 500-character `VARCHAR` schema choice. The persisted schema now uses the compatible text representation, and the full serial suite passed after the repair.
