# Client-reported person role-label repair

**Date:** 2026-10-14  
**Scope:** Contact-card and Contact edit-dialog presentation only.

## Reported behavior

A person added through the Executor/Client Portal as a non-executor—for example, a sibling—was saved with the intentionally neutral role token `client_reported_person`. The Contacts card and the edit-dialog role chip rendered only that token’s generic label, **Client-reported person**, even when the portal report included a relationship.

## Cause

The portal correctly preserves a neutral Contact role rather than assigning a legal role from a client report. It separately records the reported relationship. The two role-label call sites rendered `roleLabel(role)` without access to that relationship.

## Repair

`roleLabel` now accepts an optional relationship. For the sole neutral portal token, a nonblank relationship is displayed as a readable, non-legal contextual label such as **Sibling (client-reported)**. It retains **Client-reported person** if no relationship is available. Cards and edit-dialog chips pass the existing relationship to this helper.

The repair does not change stored roles, Contact relationship values, legal classification, executor status, portal submission/application, database schema, existing records, forms, or authorization.

## Accessibility and interaction

- The same readable label is exposed in the card and the edit-dialog chip.
- The existing keyboard-operable role menu remains available and the browser fixture verified Enter activation of Edit and Space activation of the role menu.
- Fictional desktop and 375px mobile fixtures showed the label without overflow or browser-console errors.

## Verification

1. Added a deterministic red regression proving that a client-reported sibling must not show the generic label on either surface.
2. Confirmed green with the complete focused Contact dialog suite.
3. Passed related portal mapping, router, Client Intake review, and Contact suites: **67 tests**.
4. Passed the full serial suite: **4,579 passed / 3 skipped**.
5. Passed `pnpm check`, production build, `git diff --check`, and local plus public-preview HTTP 200 health checks.

> Build retained the known non-fatal jsPDF dynamic/static import and bundle-size warnings. They predate this presentation-only repair and were not changed.
