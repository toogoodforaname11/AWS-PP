# Assistant launcher / Inventory action overlap repair

**Date:** 2026-10-13  
**Scope:** Floating ProbatePro Assistant launcher only

## Reported symptom

The floating assistant launcher sat over the lower-right Inventory action column, preventing users from selecting Inventory row controls such as **Edit**.

## Confirmed cause

The launcher was fixed at `right: 20px` with a 120 px desktop footprint. In an isolated fictional Inventory fixture at 1280 px wide, its bounds were `x=1140–1260, y=730–850`; the Edit control was `x=1147–1179, y=733.5–765.5`. The launcher therefore directly intercepted the Edit control.

The same layout defect existed on a 375 px mobile viewport: the 114 px launcher overlapped the right-edge Edit control.

## Repair

- Desktop: docked the closed assistant launcher just beyond the resizable sidebar instead of in the right-side action column.
- Mobile and tablet layouts below the application’s 768 px navigation breakpoint: docked the launcher in the lower-left corner, leaving right-edge row actions clear.
- Aligned the assistant’s transient hint with the relocated launcher.
- Added a CSS contract regression that preserves desktop/mobile docking rules.

The chat panel itself remains in its existing location when opened. No assistant capability, privacy gate, session handling, Inventory data, edit behavior, or estate workflow changed.

## Validation evidence

- Red browser reproduction: desktop and mobile launcher bounds overlapped the fictional Inventory Edit control.
- Red/green style-contract regression for the launcher and hint dock.
- Focused assistant suite: **14 passing** tests.
- TypeScript: `pnpm check` passed.
- Isolated browser fixture with fictional data:
  - desktop (1280 px), phone (375 px), and tablet (600 px) launcher/Edit bounds do not overlap;
  - `document.elementFromPoint` resolves the desktop Edit control, not the assistant;
  - Edit opens successfully on each viewport;
  - the assistant opens with keyboard Enter and closes normally;
  - no unknown tRPC procedures or browser console errors.
- Full serial suite: **311 files passed, 1 skipped; 4,568 tests passed, 3 skipped**.
- Production build passed. The known non-blocking jspdf import/chunk warnings were unchanged.
- `git diff --check` passed; local and preview roots both returned HTTP 200.

## Deliberate non-changes

- No real estate, client, executor, or portal records were accessed.
- No court forms, documents, legal wording, Intake fields, contact/inventory persistence, authorization, or chat-service behavior changed.
