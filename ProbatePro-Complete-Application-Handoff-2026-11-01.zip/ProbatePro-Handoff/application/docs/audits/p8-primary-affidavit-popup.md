# Form P8 primary-affidavit popup repair

## Scope

Form P8 paragraph 2 previously surfaced a primary-applicant-affidavit gap with only a **Go to Forms** action. The user could not answer the missing document-reference facts from the P8 generation popup.

The P8 popup now provides three transient, document-facing inputs:

- primary affidavit form: P3, P4, P5, P6, or P7;
- date sworn; and
- primary deponent name.

The answers are forwarded as per-generation overrides to preflight, preview, and DOCX generation. They are not persisted as estate fields, are not saved into Intake, and do not fabricate a retained document row. If the user leaves an answer incomplete, the existing blank/draft behavior remains in force.

## Preservation boundary

- No official P8 wording, document layout, indentation, checkbox geometry, or page-break behavior was changed.
- No affidavit file is fabricated or marked as retained.
- Existing P8 co-applicant and deponent workflows remain separate.
- The popup remains a content-only editor: it asks only for values that populate P8 paragraph 2.

## Validation

Focused `PreGenerateDialog` regressions pass, including direct P8 popup rendering and callback activation. TypeScript and whitespace checks pass. Full serial tests and production build were run as the final validation gate.
