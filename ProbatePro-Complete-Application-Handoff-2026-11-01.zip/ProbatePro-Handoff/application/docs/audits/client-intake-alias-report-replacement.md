# Client Intake Alias Report Replacement Repair

**Date:** 2026-10-14  
**Scope:** Executor/Client Portal alias application only

## Reported behavior

After several executor portal submissions, the estate Intake alias list accumulated prior reports (for example, **Four**, **Five**, and **Six**) even when the newest approved report was meant to supersede the earlier portal answer. The separate structured AKA inputs continued to display their existing values.

## Root cause

The approval persistence helper merged every newly approved portal alias into `estates.deceasedAliases`. The Intake screen correctly rendered that stored list, so the visible pile-up was caused by persistence rather than by a rendering duplicate.

## Repair

- Treat **Other names used** as the complete alias report for its approved portal submission.
- Replace prior portal aliases with the newly approved report instead of appending them.
- Preserve the established semicolon format and de-duplicate repeated aliases within one report, ignoring case and collapsed whitespace.
- Derive the existing other-names flags from the resulting report and any separately recorded structured AKA.
- Leave `akaFirstName`, `akaMiddleName`, and `akaLastName` untouched. The portal currently captures one free-text full alias and does not collect separable name parts, so automatically splitting it would guess legal name components.

A client can still report multiple aliases in a single submission using semicolons; the lawyer selects that fact through the existing review workflow.

## Boundaries

No database schema, migrations, existing records, portal authorization, client intake submission contract, Contact data, inventory, form/document generation, court-form wording/layout, legal logic, or structured AKA mapping changed.

## Validation

- Red regression: approving **Six** after **Four/Five** demonstrated the prior merged value.
- Persistence regression verifies the newest report becomes the sole canonical portal alias value, duplicate variants in that report are removed, the existing structured AKA fields are not written, and flags remain consistent.
- Intake regression verifies the latest portal alias remains visible beside a separately recorded structured AKA.
- Fictional-data Playwright fixture verified desktop and 375px mobile rendering, visible affirmative other-name controls, no overflow, and no console errors.
- Focused suite: **72 passing**.
- TypeScript: `pnpm check` passed.
- Full serial suite: **4,579 passing / 3 skipped**.
- Production build passed; only the known non-blocking jspdf static/dynamic import and chunk-size warnings appeared.
- `git diff --check` passed; local and preview HTTP health checks returned **200**.

> The repository's three changed files already had Prettier drift at the checkpoint baseline; no broad formatter rewrite was applied for this scoped behavioral repair.
