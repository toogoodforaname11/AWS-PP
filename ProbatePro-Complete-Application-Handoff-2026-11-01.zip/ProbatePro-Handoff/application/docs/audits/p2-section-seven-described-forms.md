# P2 Part 3 section 7 described-forms repair

_Completed 2026-10-11 — Form P2 section 7 document placement only_

---

## Finding

The package resolver correctly treats a co-applicant **Form P8** and a non-English-will **Form P12** as required forms. P2, however, already declares those forms on its own face:

- Part 3 section 1 declares the P8 affidavit(s) with the primary applicant affidavit; and
- Part 3 section 8 declares the P12 translator affidavit.

Section 7's first official alternative states that no documents **other than those described elsewhere in the submission** are filed. The renderer was treating every package-required form as a section 7 addition, so it could repeat P8 (and P12) under section 7 rather than select that existing official alternative.

## Repair boundary

A small P2-only helper now removes **only P8 and P12** from the section 7 list. It does not modify the shared package resolver, the Forms catalogue, or the P8/P12 generation rules.

| Form | P2 face location | Section 7 behavior |
| --- | --- | --- |
| P8 | Part 3 section 1 | Not repeated in section 7 |
| P12 | Part 3 section 8 | Not repeated in section 7 |
| P16 and other genuinely additional forms | Not described by another P2 Part 3 section | Remain listed under the existing section 7 second alternative |

When P8 and/or P12 are the only package additions, section 7 now selects its unchanged existing **“No documents other than those described elsewhere…”** alternative. The DOCX and structured preview use the same helper.

## Preserved constraints

- No official court-form wording changed
- No DOCX layout, indents, checkbox geometry, selected-only behavior, or pagination changed
- No P8, P12, package-selection, notice, preflight, or other form logic changed
- The P16 case remains an affirmative regression: section 7 continues to list a genuinely additional form

## Verification

- Focused DOCX + preview regression: P8 is declared by section 1, P12 by section 8, neither repeats in section 7, and P16 still prints there
- Focused document/package suite: 193 tests passed
- TypeScript check passed
- Full serial suite passed: 300 files, 4,465 tests, 3 skipped
- Production build passed
- `git diff --check` passed
