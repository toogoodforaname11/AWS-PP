# Client Intake Review Design Audit

**Date:** 2026-10-12  
**Scope:** Lawyer-side presentation refinement for the submitted-intake review workspace in the estate-level **Client Portal** tab.

## Outcome

The review panel now presents a clearer decision path without changing the client-intake workflow:

1. The selected client submission is identified with a readable status label.
2. A compact **Ready for review** summary shows the selected-fact count and keeps the existing bulk action visible.
3. The reported-facts area is a comparison workspace, with desktop column labels for **Field**, **Client report**, **Current Intake**, and **Decision**. On narrower containers, the existing row layout stacks safely and labels the current record inline.
4. Selected and already-applied facts receive restrained state treatment. Applied values remain a review record and still cannot be applied twice.
5. Client-reported contextual information is separated into an explicitly **review-only** section. It has no Apply control and is not written to the estate.
6. The corrections path is a concise disclosure with a clear purpose and open/closed state cue. The final action band keeps the existing unsaved-Intake protection, correction action, and explicit selected-fact application together.

## Safeguards retained

- No schema, migration, router, tRPC contract, query, mutation, or authorization change.
- No alteration to estate revision checks, individual/bulk application behavior, identity/description dependencies, review history, or unsaved-Intake application block.
- No automatic application: a lawyer must still select/use an existing Apply action.
- Case-specific answers and all other review-only context remain non-applicable.
- No change to court forms, document generation, legal wording, citations, intake answers, or stored client/estate data.

## Regression coverage

Added a client-review component regression that verifies the decision summary, selected-count update, comparison labels, and review-only custom answer boundary. Existing review, estate Client Portal, and custom-question authoring tests remain in the focused run.

## Validation evidence

| Check | Result |
|---|---|
| Focused component tests | 15 passed across ClientIntakeReview, EstateClientPortal, and ClientIntakeQuestions |
| Application TypeScript (`pnpm check`) | Passed |
| Full serial application suite | 4,534 passed; 3 skipped; no failures |
| Production build (`pnpm build`) | Passed |
| Whitespace and scoped diff checks | Passed |
| Local development health | HTTP 200 |
| Public sandbox preview health | HTTP 200 |

An isolated fictional-data browser fixture was attempted for visual inspection after disabling all query/mutation paths. The sandbox browser crashed while resolving local Vite modules, so it was not retried; no authenticated estate or client record was read or changed. The component was instead verified through the focused UI tests, source review, production build, and runtime health checks.
