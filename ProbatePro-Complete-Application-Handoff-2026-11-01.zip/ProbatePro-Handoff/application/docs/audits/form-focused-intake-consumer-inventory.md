# Form-focused Intake consumer inventory

> Generated as a source-trace aid for the 2026-10-01 audit. A direct `docgen` hit is a starting point, not a legal conclusion; fields can also legitimately drive applicability, preflight, attachment, or other generated-form decisions.

## Audit result

The source trace covered the Form-focused Intake controls and conditional branches against document rendering, form requirements, applicability, router, and attachment code. Fields that fill document content remain visible. Fields that establish a required/available form, required attachment, or generation completion path also remain visible, preserving the agreed ability to identify required forms without inventing facts.

The strict follow-up removed every confirmed operational-only Intake control **only from Form-focused Intake**: the deceased occupation (no consumer outside the control itself), manually entered individual codicil-date reference, free-text grant-limitation note, PGT grant-issuance/copy-delivery tracking, and the court-ordered early-application record. The codicil count remains because it names delivered codicils in Form P9 and drives codicil attachment checks; the limited-grant selection remains because it controls the Form P19 limited-grant clause. Facts used by a generated form's content, availability, required attachment, or completion path remain visible; for example, electronic-will repository details accompany the P4/P45 filing path even though they are not sworn P45 text.

No document renderer, official wording, or document layout changed during the audit. The table below preserves the source-level inventory for future maintenance.

## Streamlined Forms status display — 2026-10-07

The numeric Form-focused catalog intentionally omits per-row **Required/Optional** badges and the legacy `complete/total ready` field counts. Both are derived from applicability and readiness/preflight criteria, not a document-only field set, and therefore do not belong in the streamlined workflow. The count query is not run in that mode. The full Forms workflow retains its existing headings, status badges, and generation routes unchanged; the streamlined list keeps the same numeric order, form availability, and form-specific generation prompts.

## VSA certificate result vs. searched names — 2026-10-07

The VSA certificate **result** remains visible in Form-focused Intake. `vsaCertificateResult` selects the existing visible certificate alternative in P3, P4, P6, and P7; `vsaWillsNoticeDate` remains conditionally visible when a notice was found because it is rendered on the relevant affidavit path.

`vsaNamesSearched` has no `server/docgen.ts` consumer. It is retained in the standard Intake only for the readiness comparison against the deceased's recorded legal names and aliases. Form-focused Intake now hides both that input and its readiness-only “every alias searched” guidance; no stored value, renderer, official wording, form availability, or generation behavior changes.

## SIN — 2026-10-07

`deceasedSIN` has no generated-form DOCX or preview consumer. Its only live consumers were the Intake control, a UI-only format helper, and the existing sensitive-field encryption boundary. The SIN control and its UI validation/hint are removed from **all** Intake modes. The database column, encryption/decryption boundary, and any already-stored values remain untouched; no form content, form availability, or generation path uses the SIN.

## TIN — 2026-10-07

`deceasedTIN` likewise has no generated-form DOCX or preview consumer, and no requirement, applicability, or generation consumer. Its only live use was the adjacent Intake control and the existing sensitive-field encryption boundary. The TIN control and its now-empty tax-identifier wrapper are removed from **all** Intake modes. The database column, encryption/decryption boundary, and any already-stored values remain untouched; no form content, form availability, or generation path uses the TIN.

| Field | `docgen` refs | Requirements/types refs | Router refs | Source hits |
|---|---:|---:|---:|---|
| `Assignee` | 0 | 0 | 0 | — |
| `City` | 11 | 3 | 0 | server/docgen.ts:11, shared/formRequirements.ts:3, shared/inlineFieldControls.ts:2 |
| `Country` | 6 | 2 | 0 | server/docgen.ts:6, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:2 |
| `Deceased` | 48 | 53 | 1 | server/docgen.ts:48, server/routers.ts:1, shared/clientIntake.ts:3, shared/formRequirements.ts:45, shared/inlineFieldControls.ts:2, shared/types.ts:8 |
| `SIN` | 0 | 0 | 0 | — |
| `TIN` | 0 | 0 | 0 | — |
| `Translator` | 1 | 6 | 0 | server/docgen.ts:1, shared/formRequirements.ts:5, shared/inlineFieldControls.ts:4, shared/types.ts:1 |
| `addressCity` | 8 | 11 | 0 | server/docgen.ts:8, shared/formRequirements.ts:11, shared/inlineFieldControls.ts:1 |
| `addressFormatOverride` | 84 | 0 | 4 | server/docgen.ts:84, server/routers.ts:4 |
| `addressPostalCode` | 3 | 1 | 0 | server/docgen.ts:3, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:1 |
| `addressProvince` | 5 | 3 | 0 | server/docgen.ts:5, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1, shared/types.ts:1 |
| `addressStreet` | 1 | 2 | 0 | server/docgen.ts:1, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1 |
| `addressUnit` | 1 | 0 | 0 | server/docgen.ts:1 |
| `akaFirstName` | 0 | 1 | 0 | shared/types.ts:1 |
| `akaLastName` | 0 | 2 | 0 | shared/formRequirements.ts:1, shared/inlineFieldControls.ts:1, shared/types.ts:1 |
| `akaMiddleName` | 0 | 1 | 0 | shared/types.ts:1 |
| `ancillaryWillDocumentsCertifiedByIssuingCourt` | 0 | 1 | 13 | server/documentAssets.ts:2, server/routers.ts:13, shared/formRequirements.ts:1 |
| `appearanceAffidavits` | 0 | 1 | 0 | shared/types.ts:1 |
| `appearanceIssueOther` | 0 | 2 | 0 | shared/formRequirements.ts:1, shared/types.ts:1 |
| `appearanceIssueTypes` | 0 | 3 | 0 | shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1, shared/types.ts:1 |
| `applicantIsGovernmentNominee` | 2 | 1 | 0 | server/docgen.ts:2, shared/applicabilityQuestions.ts:1, shared/types.ts:1 |
| `applicantIsNominee` | 2 | 2 | 0 | server/docgen.ts:2, shared/applicabilityQuestions.ts:1, shared/types.ts:2 |
| `applicantPriorityParagraph` | 1 | 3 | 0 | server/docgen.ts:1, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1, shared/types.ts:1 |
| `applicantSurname` | 2 | 0 | 0 | server/docgen.ts:2 |
| `attestationAffidavits` | 0 | 2 | 0 | shared/formRequirements.ts:1, shared/types.ts:1 |
| `attestationClauseStatus` | 0 | 4 | 0 | shared/formRequirements.ts:2, shared/types.ts:2 |
| `attestationRoute` | 0 | 4 | 0 | shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1, shared/types.ts:2 |
| `beliefLastBcWill` | 0 | 2 | 0 | shared/inlineFieldControls.ts:2, shared/types.ts:2 |
| `certifiedCopies` | 4 | 1 | 0 | server/docgen.ts:4, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:1 |
| `certifiedCopiesP10` | 4 | 0 | 0 | server/docgen.ts:4 |
| `certifiedCopiesP11` | 4 | 0 | 0 | server/docgen.ts:4 |
| `code` | 7 | 183 | 146 | server/affidavitHistory.ts:1, server/aiProcessorGate.ts:1, server/db.ts:23, server/docgen.ts:7, server/documentAssets.ts:16, server/downloadRoute.ts:2, server/routers.ts:146, server/uploadSecurity.ts:16 |
| `codicilCount` | 2 | 3 | 4 | server/docgen.ts:2, server/documentAssets.ts:9, server/routers.ts:4, shared/formRequirements.ts:2, shared/types.ts:1 |
| `codicilDates` | 0 | 1 | 11 | server/routers.ts:11, shared/types.ts:1 |
| `courtFileNumber` | 3 | 1 | 0 | server/docgen.ts:3, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:1 |
| `creditorReviewStatus` | 0 | 5 | 1 | server/routers.ts:1, shared/types.ts:5 |
| `dateOfBirth` | 2 | 4 | 2 | server/aiImportSecurity.ts:1, server/docgen.ts:2, server/routers.ts:2, shared/clientIntake.ts:3, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1, shared/types.ts:2 |
| `dateOfDeath` | 16 | 16 | 5 | server/aiImportSecurity.ts:1, server/docgen.ts:16, server/routers.ts:5, shared/clientIntake.ts:3, shared/formRequirements.ts:5, shared/inlineFieldControls.ts:1, shared/types.ts:11 |
| `deceasedAliases` | 0 | 5 | 1 | server/routers.ts:1, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1, shared/types.ts:3 |
| `deceasedFirstName` | 6 | 25 | 7 | server/aiImportSecurity.ts:1, server/docgen.ts:6, server/notesExportRoute.ts:1, server/routers.ts:7, shared/clientIntake.ts:3, shared/formRequirements.ts:23, shared/inlineFieldControls.ts:1, shared/types.ts:2 |
| `deceasedLastName` | 7 | 25 | 24 | server/affidavitHistory.ts:2, server/aiImportSecurity.ts:1, server/docgen.ts:7, server/downloadRoute.ts:6, server/notesExportRoute.ts:1, server/routers.ts:24, server/documentFilenames.ts:2, shared/clientIntake.ts:3 |
| `deceasedMiddleNames` | 6 | 7 | 6 | server/aiImportSecurity.ts:1, server/docgen.ts:6, server/routers.ts:6, shared/clientIntake.ts:3, shared/formRequirements.ts:6, shared/inlineFieldControls.ts:1, shared/types.ts:1 |
| `deceasedPlaceOfBirth` | 1 | 3 | 4 | server/docgen.ts:1, server/routers.ts:4, shared/formRequirements.ts:3, shared/inlineFieldControls.ts:1 |
| `deceasedPostOfficeBox` | 6 | 2 | 0 | server/docgen.ts:6, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1 |
| `deceasedSecondMiddleName` | 3 | 2 | 3 | server/docgen.ts:3, server/routers.ts:3, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:1, shared/types.ts:1 |
| `distributionCourtConsentDate` | 0 | 0 | 1 | server/routers.ts:1, shared/deadline-engine.ts:3 |
| `distributionExceptionDate` | 0 | 0 | 1 | server/routers.ts:1, shared/deadline-engine.ts:4 |
| `distributionExceptionFilePath` | 0 | 0 | 3 | server/routers.ts:3, server/storageRegistry.ts:7, shared/deadline-engine.ts:2, shared/serverManagedEstateFields.ts:1 |
| `distributionExceptionType` | 0 | 0 | 1 | server/routers.ts:1, shared/deadline-engine.ts:4 |
| `distributionProceedingStatus` | 0 | 0 | 1 | server/routers.ts:1, shared/deadline-engine.ts:4 |
| `electronicOriginalUnavailableAffidavits` | 1 | 2 | 0 | server/docgen.ts:1, shared/formRequirements.ts:2 |
| `electronicOriginalUnavailableKnowledge` | 2 | 4 | 0 | server/docgen.ts:2, shared/formRequirements.ts:4 |
| `electronicOriginalUnavailableReason` | 2 | 1 | 0 | server/docgen.ts:2, shared/formRequirements.ts:1 |
| `electronicWillFormat` | 2 | 16 | 0 | server/docgen.ts:2, shared/applicabilityQuestions.ts:5, shared/formOverrides.ts:1, shared/formRequirements.ts:10, shared/inlineFieldControls.ts:1, shared/types.ts:6 |
| `electronicWillFormatDescription` | 2 | 1 | 0 | server/docgen.ts:2, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:1 |
| `electronicWillLockMethod` | 2 | 1 | 0 | server/docgen.ts:2, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:1 |
| `electronicWillLocked` | 2 | 3 | 0 | server/docgen.ts:2, shared/formRequirements.ts:3, shared/inlineFieldControls.ts:1 |
| `electronicWillRepositoryAccess` | 2 | 2 | 0 | server/docgen.ts:2, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1 |
| `electronicWillRepositoryAddress` | 2 | 2 | 0 | server/docgen.ts:2, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1 |
| `electronicWillRepositoryName` | 3 | 2 | 0 | server/docgen.ts:3, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1 |
| `electronicWillVerificationMethod` | 2 | 1 | 0 | server/docgen.ts:2, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:1 |
| `erasureAffidavits` | 0 | 2 | 0 | shared/formRequirements.ts:1, shared/types.ts:1 |
| `erasureLocations` | 0 | 1 | 0 | shared/types.ts:1 |
| `erasureStatus` | 0 | 4 | 0 | shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1, shared/types.ts:2 |
| `erasureTreatments` | 0 | 3 | 0 | shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1, shared/types.ts:1 |
| `executionIssueDescription` | 2 | 1 | 0 | server/docgen.ts:2, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:1 |
| `executionIssues` | 7 | 5 | 1 | server/docgen.ts:7, server/routers.ts:1, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:4, shared/types.ts:4 |
| `foreignGrantCertifiedByIssuingCourt` | 0 | 1 | 5 | server/documentAssets.ts:2, server/routers.ts:5, shared/formRequirements.ts:1 |
| `foreignGrantGranteeNames` | 0 | 7 | 0 | shared/formRequirements.ts:1, shared/inlineFieldControls.ts:1, shared/types.ts:6 |
| `foreignGrantIncludesWill` | 0 | 7 | 5 | server/documentAssets.ts:3, server/routers.ts:5, shared/formRequirements.ts:5, shared/types.ts:2 |
| `foreignGrantIssuedDate` | 8 | 5 | 4 | server/docgen.ts:8, server/routers.ts:4, shared/formRequirements.ts:4, shared/inlineFieldControls.ts:2, shared/types.ts:1 |
| `foreignGrantIssuingCourt` | 5 | 5 | 0 | server/docgen.ts:5, shared/formRequirements.ts:4, shared/inlineFieldControls.ts:1, shared/types.ts:1 |
| `foreignGrantIssuingJurisdiction` | 3 | 3 | 0 | server/docgen.ts:3, shared/formRequirements.ts:3, shared/inlineFieldControls.ts:1 |
| `foreignWillAffidavitDate` | 1 | 1 | 0 | server/docgen.ts:1, shared/formRequirements.ts:1 |
| `foreignWillAffidavitName` | 1 | 1 | 0 | server/docgen.ts:1, shared/formRequirements.ts:1 |
| `foreignWillSection80Paragraph` | 1 | 1 | 0 | server/docgen.ts:1, shared/formRequirements.ts:1 |
| `foreignWillStatus` | 11 | 5 | 1 | server/docgen.ts:11, server/routers.ts:1, shared/formRequirements.ts:3, shared/inlineFieldControls.ts:2, shared/types.ts:2 |
| `grantIssuedDate` | 4 | 7 | 7 | server/docgen.ts:4, server/routers.ts:7, shared/deadline-engine.ts:7, shared/types.ts:7 |
| `grantLimitation` | 0 | 0 | 0 | — |
| `grantType` | 32 | 33 | 16 | server/docgen.ts:32, server/routers.ts:16, server/_core/sdk.ts:1, server/_core/types/manusTypes.ts:1, shared/applicabilityQuestions.ts:1, shared/formOverrides.ts:1, shared/formRequirements.ts:13, shared/inlineFieldControls.ts:4 |
| `hasAdditionalNames` | 0 | 0 | 0 | — |
| `hasOtherNames` | 0 | 7 | 0 | shared/formRequirements.ts:3, shared/types.ts:4 |
| `hasTestamentaryTrust` | 0 | 4 | 0 | shared/types.ts:4 |
| `hasWill` | 16 | 57 | 11 | server/docgen.ts:16, server/documentAssets.ts:2, server/routers.ts:11, shared/applicabilityQuestions.ts:4, shared/deadline-engine.ts:4, shared/formRequirements.ts:18, shared/types.ts:39 |
| `interlineationAffidavits` | 0 | 2 | 0 | shared/formRequirements.ts:1, shared/types.ts:1 |
| `interlineationTreatment` | 0 | 4 | 0 | shared/formRequirements.ts:2, shared/types.ts:2 |
| `intestateConsentState` | 2 | 2 | 0 | server/docgen.ts:2, shared/applicabilityQuestions.ts:1, shared/types.ts:2 |
| `isElectronicWill` | 12 | 12 | 6 | server/docgen.ts:12, server/routers.ts:6, shared/applicabilityQuestions.ts:5, shared/deadline-engine.ts:3, shared/formOverrides.ts:1, shared/formRequirements.ts:4, shared/inlineFieldControls.ts:1, shared/types.ts:8 |
| `isMilitaryWill` | 6 | 3 | 1 | server/docgen.ts:6, server/routers.ts:1, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:2, shared/types.ts:2 |
| `laterTestamentaryDescription` | 13 | 6 | 0 | server/docgen.ts:13, shared/formOverrides.ts:1, shared/formRequirements.ts:4, shared/inlineFieldControls.ts:1, shared/types.ts:2 |
| `limitedGrant` | 2 | 0 | 0 | server/docgen.ts:2 |
| `maritalStatus` | 6 | 12 | 2 | server/aiImportSecurity.ts:1, server/docgen.ts:6, server/routers.ts:2, shared/formRequirements.ts:6, shared/inlineFieldControls.ts:1, shared/types.ts:6 |
| `militaryWillDescription` | 4 | 1 | 0 | server/docgen.ts:4, shared/formRequirements.ts:1 |
| `needsNameReview` | 0 | 0 | 0 | — |
| `noVisibleSignatureReason` | 0 | 1 | 0 | shared/formRequirements.ts:1 |
| `noticeContactsComplete` | 1 | 4 | 0 | server/docgen.ts:1, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1, shared/types.ts:2 |
| `notifyPGT` | 36 | 18 | 4 | server/db.ts:1, server/docgen.ts:36, server/routers.ts:4, shared/applicabilityQuestions.ts:1, shared/formRequirements.ts:16, shared/inlineFieldControls.ts:1, shared/types.ts:2 |
| `orderDate` | 2 | 1 | 0 | server/docgen.ts:2, shared/deadline-engine.ts:7, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:1 |
| `orderDescription` | 4 | 1 | 0 | server/docgen.ts:4, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:1 |
| `orderFiled` | 5 | 3 | 0 | server/docgen.ts:5, shared/formRequirements.ts:3 |
| `ordersAffectingWill` | 13 | 5 | 5 | server/docgen.ts:13, server/routers.ts:5, shared/formRequirements.ts:3, shared/inlineFieldControls.ts:2, shared/types.ts:2 |
| `otherGrantApplicants` | 5 | 2 | 0 | server/docgen.ts:5, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1 |
| `otherGrantsDescription` | 5 | 2 | 0 | server/docgen.ts:5, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1 |
| `otherGrantsRelevanceReason` | 5 | 2 | 0 | server/docgen.ts:5, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1 |
| `otherGrantsStatus` | 5 | 15 | 1 | server/docgen.ts:5, server/routers.ts:1, shared/formRequirements.ts:10, shared/inlineFieldControls.ts:3, shared/types.ts:5 |
| `p10FiledDate` | 0 | 1 | 0 | shared/types.ts:1 |
| `p11FiledDate` | 0 | 4 | 0 | shared/applicabilityQuestions.ts:1, shared/types.ts:4 |
| `p13SealedMaterial` | 3 | 1 | 0 | server/docgen.ts:3, shared/formRequirements.ts:1 |
| `p16DeponentPresentAtSigning` | 0 | 1 | 0 | shared/formRequirements.ts:1, shared/inlineFieldControls.ts:2 |
| `p19IssuedPursuantToOrder` | 2 | 0 | 1 | server/docgen.ts:2, server/routers.ts:1 |
| `p19WillReadWithOrder` | 2 | 0 | 1 | server/docgen.ts:2, server/routers.ts:1 |
| `p1EarlyApplicationOrderDate` | 0 | 3 | 1 | server/routers.ts:1, shared/deadline-engine.ts:3, shared/formRequirements.ts:1, shared/types.ts:2 |
| `p1EarlyApplicationOrderFilePath` | 0 | 3 | 3 | server/routers.ts:3, server/storageRegistry.ts:7, shared/deadline-engine.ts:2, shared/formRequirements.ts:1, shared/serverManagedEstateFields.ts:1, shared/types.ts:2 |
| `p1EarlyApplicationPermittedDate` | 0 | 5 | 1 | server/routers.ts:1, shared/deadline-engine.ts:4, shared/formRequirements.ts:2, shared/types.ts:3 |
| `p1NotRequired` | 4 | 1 | 0 | server/docgen.ts:4, shared/applicabilityQuestions.ts:2, shared/types.ts:1 |
| `p25FiledDate` | 0 | 2 | 0 | shared/applicabilityQuestions.ts:1, shared/types.ts:2 |
| `p2FiledDate` | 0 | 3 | 7 | server/routers.ts:7, shared/deadline-engine.ts:3, shared/formRequirements.ts:3 |
| `pgtCommentsProvidedToCourt` | 0 | 2 | 1 | server/routers.ts:1, shared/formRequirements.ts:1, shared/types.ts:1 |
| `pgtCommentsProvidedToCourtDate` | 0 | 3 | 1 | server/routers.ts:1, shared/formRequirements.ts:1, shared/types.ts:2 |
| `pgtEarlyGrantOrderDate` | 0 | 3 | 1 | server/routers.ts:1, shared/formRequirements.ts:1, shared/types.ts:2 |
| `pgtEarlyGrantOrderFilePath` | 0 | 2 | 3 | server/routers.ts:3, server/storageRegistry.ts:7, shared/formRequirements.ts:1, shared/serverManagedEstateFields.ts:1, shared/types.ts:1 |
| `pgtGrantCopyDeliveredDate` | 0 | 0 | 1 | server/routers.ts:1, shared/deadline-engine.ts:3 |
| `pgtIsApplicant` | 0 | 1 | 0 | shared/applicabilityQuestions.ts:1, shared/types.ts:1 |
| `referencedDocumentNames` | 4 | 2 | 0 | server/docgen.ts:4, shared/formRequirements.ts:2 |
| `referencedDocuments` | 6 | 10 | 1 | server/docgen.ts:6, server/routers.ts:1, shared/formRequirements.ts:8, shared/inlineFieldControls.ts:1, shared/types.ts:2 |
| `referencedDocumentsCannotObtainReason` | 4 | 2 | 0 | server/docgen.ts:4, shared/formRequirements.ts:2 |
| `referencedDocumentsNotTestamentary` | 4 | 2 | 0 | server/docgen.ts:4, shared/formRequirements.ts:2 |
| `registry` | 21 | 18 | 9 | server/docgen.ts:21, server/routers.ts:9, shared/applicabilityQuestions.ts:4, shared/date-utils.ts:2, shared/deadline-engine.ts:2, shared/formOverrides.ts:8, shared/formRequirements.ts:11, shared/gapEditors.ts:2 |
| `specialCircumstances` | 4 | 10 | 1 | server/docgen.ts:4, server/routers.ts:1, shared/formRequirements.ts:5, shared/inlineFieldControls.ts:2, shared/types.ts:5 |
| `specialCircumstancesAffidavits` | 4 | 1 | 0 | server/docgen.ts:4, shared/formRequirements.ts:1 |
| `specialCircumstancesFollowUp` | 2 | 2 | 0 | server/docgen.ts:2, shared/formRequirements.ts:2 |
| `testamentaryDocStatus` | 32 | 14 | 1 | server/docgen.ts:32, server/routers.ts:1, shared/formRequirements.ts:8, shared/inlineFieldControls.ts:2, shared/types.ts:6 |
| `toString` | 0 | 0 | 1 | server/downloadRoute.ts:3, server/fieldEncryption.ts:2, server/legacyForgeStorage.ts:1, server/outboundUrlPolicy.ts:1, server/routers.ts:1, server/storageProvider.ts:2, server/uploadSecurity.ts:1, server/_core/context.ts:1 |
| `translatedDocument` | 4 | 2 | 0 | server/docgen.ts:4, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1 |
| `translatorName` | 9 | 2 | 2 | server/docgen.ts:9, server/downloadRoute.ts:1, server/routers.ts:2, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1 |
| `treatyFirstNation` | 2 | 10 | 0 | server/docgen.ts:2, shared/applicabilityQuestions.ts:2, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1, shared/types.ts:8 |
| `treatyFirstNationName` | 4 | 2 | 0 | server/docgen.ts:4, shared/formRequirements.ts:1, shared/types.ts:1 |
| `trusteeNamed` | 0 | 1 | 0 | shared/types.ts:1 |
| `useLongFormAffidavit` | 0 | 1 | 0 | shared/applicabilityQuestions.ts:1, shared/types.ts:1 |
| `variationCplRegisteredDate` | 0 | 0 | 1 | server/routers.ts:1, shared/deadline-engine.ts:4 |
| `variationExecutorServedDate` | 0 | 0 | 1 | server/routers.ts:1, shared/deadline-engine.ts:4 |
| `variationPgtServedDate` | 0 | 3 | 1 | server/routers.ts:1, shared/deadline-engine.ts:4, shared/types.ts:3 |
| `variationProceedingCommencedDate` | 0 | 0 | 4 | server/routers.ts:4, shared/deadline-engine.ts:5 |
| `variationProceedingStatus` | 0 | 1 | 1 | server/routers.ts:1, shared/deadline-engine.ts:6, shared/types.ts:1 |
| `variationServiceExtensionDate` | 0 | 0 | 1 | server/routers.ts:1, shared/deadline-engine.ts:5 |
| `variationTreatyNationServedDate` | 0 | 3 | 1 | server/routers.ts:1, shared/deadline-engine.ts:4, shared/types.ts:3 |
| `vsaCertificateResult` | 3 | 13 | 2 | server/docgen.ts:3, server/routers.ts:2, shared/formRequirements.ts:4, shared/inlineFieldControls.ts:2, shared/types.ts:9 |
| `vsaNamesSearched` | 0 | 4 | 1 | server/routers.ts:1, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1, shared/types.ts:2 |
| `vsaWillsNoticeDate` | 2 | 8 | 1 | server/docgen.ts:2, server/routers.ts:1, shared/inlineFieldControls.ts:2, shared/types.ts:8 |
| `wesaS58OrderDate` | 0 | 3 | 1 | server/documentAssets.ts:1, server/routers.ts:1, shared/formRequirements.ts:1, shared/types.ts:2 |
| `wesaS58OrderFilePath` | 0 | 2 | 3 | server/documentAssets.ts:3, server/routers.ts:3, server/storageRegistry.ts:7, shared/formRequirements.ts:1, shared/serverManagedEstateFields.ts:1, shared/types.ts:1 |
| `wesaS58RecordDescription` | 0 | 1 | 0 | shared/types.ts:1 |
| `wesaS58RecordType` | 0 | 1 | 0 | shared/types.ts:1 |
| `wesaS58Reliance` | 0 | 4 | 1 | server/documentAssets.ts:1, server/routers.ts:1, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:2, shared/types.ts:3 |
| `willAlterationRoute` | 0 | 4 | 0 | shared/applicabilityQuestions.ts:1, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:1, shared/types.ts:2 |
| `willAlterationTypes` | 1 | 3 | 0 | server/docgen.ts:1, shared/formRequirements.ts:2, shared/types.ts:1 |
| `willAlterations` | 4 | 8 | 1 | server/docgen.ts:4, server/routers.ts:1, shared/applicabilityQuestions.ts:1, shared/formRequirements.ts:2, shared/inlineFieldControls.ts:3, shared/types.ts:6 |
| `willAlterationsDetail` | 2 | 0 | 0 | server/docgen.ts:2, shared/inlineFieldControls.ts:2, shared/p16Location.ts:4 |
| `willAppearanceIssues` | 1 | 5 | 0 | server/docgen.ts:1, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:2, shared/types.ts:4 |
| `willCopyAffidavit` | 1 | 2 | 0 | server/docgen.ts:1, shared/formRequirements.ts:2 |
| `willCopyDescription` | 2 | 1 | 0 | server/docgen.ts:2, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:1 |
| `willCopyKnowledge` | 2 | 4 | 0 | server/docgen.ts:2, shared/formRequirements.ts:4, shared/inlineFieldControls.ts:1 |
| `willDate` | 42 | 21 | 1 | server/docgen.ts:42, server/routers.ts:1, shared/clientIntake.ts:3, shared/formRequirements.ts:7, shared/inlineFieldControls.ts:2, shared/types.ts:14 |
| `willDocumentsAttached` | 0 | 2 | 0 | shared/inlineFieldControls.ts:2, shared/types.ts:2 |
| `willFilingType` | 16 | 18 | 2 | server/docgen.ts:16, server/routers.ts:2, shared/formRequirements.ts:8, shared/inlineFieldControls.ts:3, shared/types.ts:10 |
| `willLanguage` | 5 | 5 | 0 | server/docgen.ts:5, shared/applicabilityQuestions.ts:1, shared/formRequirements.ts:3, shared/inlineFieldControls.ts:1, shared/types.ts:2 |
| `willSourceLanguage` | 3 | 1 | 0 | server/docgen.ts:3, shared/formRequirements.ts:1, shared/inlineFieldControls.ts:1 |
| `willType` | 8 | 11 | 9 | server/docgen.ts:8, server/routers.ts:9, shared/applicabilityQuestions.ts:6, shared/deadline-engine.ts:2, shared/formOverrides.ts:1, shared/formRequirements.ts:3, shared/inlineFieldControls.ts:1, shared/types.ts:8 |


## Contact popup audit — 2026-10-03

The Add/Edit Contact popup was source-traced control-by-control against `server/docgen.ts`, `shared/formRequirements.ts`, `shared/types.ts`, delivery/readiness code, and the contact router. The same preservation rule applies: a field remains visible in Form-focused mode when it contributes to document content, form availability or requiredness, an attachment, or a completion/preflight path. The default/full Contact workflow remains unchanged.

| Popup control(s) | Verified generated-form or completion consumer | Form-focused decision |
|---|---|---|
| Roles; name; name as shown in will; firm name | P1/P2/P3/P4/P5/P8/P9/P10/P17, letters, applicant selection, and address-for-service selection | Keep |
| Residential/postal address, same-as-residential, email, phone, fax, city/country, address for service | P1/P2 service and PGT information blocks, notice/delivery recipients, letters, requirements | Keep |
| PGT supplemental-information review | Rule 25-2(13) PGT output state and the `pgt_info_reviewed` completion requirement | Keep |
| Relationship, family side, relationship duration/termination, predeceased, parent-by-representation link, spousal share | P2/P5/P10/P17 wording and availability; WESA succession, notice, and distribution/representation calculations | Keep |
| Occupation | Affidavit preambles, P8 co-applicant collection, P34 contact validation, and deponent requirements | Keep |
| Applicant kind; service fax; organizational signatory details | Applicant/deponent identity and service blocks across P1/P2/P3/P4/P5/P6/P8/P17/P19 | Keep |
| Executor status/reason, trustee appointment, structured residence, formatting override, rank and priority | P2/P3/P4/P17 content, affidavit preambles, applicant selection, and completion requirements | Keep |
| Minor/incapacity, minor-delivery branch/guardian, committee status/type/name/address | P9/P9 preview substitute-receiver/capacity text and delivery-proof/preflight paths | Keep |
| Consent status/document/inquiry details | P5 consent/renunciation attachment and inquiry completion paths | Keep |
| Notice recipient category and creditor claim amount | P1/P2/P9 recipient selection, applicability, creditor threshold, and delivery paths | Keep |
| **Appointing Jurisdiction** (foreign committee only) | No renderer, requirement, applicability, attachment, readiness, delivery, or completion consumer; the retained committee type already drives the P9 capacity treatment | **Hide only in Form-focused mode** |

`committeeJurisdiction` remains stored for existing records and remains editable in the full workflow. Legacy `deliveryMethod` and `deliveryDate` are not popup controls; delivery proof continues to be entered in Forms → P9 / P1 Delivery Records. No document renderer, official wording, layout, selection behavior, or generation logic changed.
