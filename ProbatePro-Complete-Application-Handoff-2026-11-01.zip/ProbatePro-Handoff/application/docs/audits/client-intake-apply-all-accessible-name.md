# Client Intake Apply All Accessible Name Audit

**Date:** 2026-10-13  
**Scope:** Client Portal lawyer review Apply All button only

## Issue

The visible button caption was **Apply all ready facts**, while an obsolete `aria-label` exposed **Apply all unapplied facts** to assistive technology. The conflicting accessible name was misleading and did not match the control that sighted lawyers use.

## Change

The obsolete override was removed. The native button accessible name now derives from its visible text: **Apply all ready facts** at rest and **Applying…** while the action is pending. The focused regression covers normal, disabled, and pending states, and retains the existing verified-field application assertion.

## Deliberate boundaries

No application workflow, selected fields, submission data, review state, database behavior, portal permissions, document output, court-form content, or visual styling changed.

## Verification

Focused client review tests: **17 passed**. TypeScript check, the full serial application suite (**4,554 passed; 3 skipped**), production build, `git diff --check`, and local/preview HTTP **200** health checks passed.
