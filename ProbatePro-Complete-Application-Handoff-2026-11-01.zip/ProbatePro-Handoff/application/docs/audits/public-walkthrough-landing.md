# Public Walkthrough Landing Audit

**Date:** 2026-10-12  
**Scope:** Public, pre-login landing page only.

## Result

The user-supplied ProbatePro walkthrough now replaces the simulated application carousel in the first fold. The landing page uses a two-column editorial layout on larger screens and a single-column flow on phones. The primary sign-in action remains intact; a separate `Watch walkthrough` link moves visitors to the real product demo.

The video sits in a navy/slate double-border frame with an inset white keyline, modest depth, a high-contrast focus-within state, and a fine-pointer-only hover lift. The frame identifies the recording as a 2:54 product walkthrough of a fictional sample estate. Playback remains user-controlled through the native browser controls with `preload="metadata"` and `playsInline`.

## Media and accessibility

The supplied 1920×1080 H.264/AAC recording is hosted through the public CDN, with a 1600×900 poster. The public page includes a 22-cue English WebVTT caption track. The CDN supplies the video and poster; the 2 KB WebVTT source is served same-origin, fetched into a browser Blob URL, then passed to the native caption track. This preserves captions where the CDN does not grant the CORS access a native `track` request needs.

Browser inspection confirmed the video has native controls, a 174.4-second duration, metadata available, a keyboard-focusable video element, and **22 loaded caption cues**.

## Preserved

The change does not alter public SEO metadata or FAQ JSON-LD, sign-in behavior, Terms/Privacy links, settings, estate records, private routes, court-form wording, document generation, legal language, citations, or database/API behavior. The former simulated carousel remains in source only; it is no longer rendered in the first fold.

## Validation

- Red/green regression: the new video test failed before implementation, then passed after the accessible frame was added.
- Focused tests: `Landing.auth.test.tsx` and `public-seo-assets.test.ts` passed, **10 tests** total.
- TypeScript: `pnpm check` passed.
- Full serial suite: **4,486 passed; 3 skipped** across 303 files.
- Production build: `pnpm build` passed; the built output contains the VTT asset.
- Browser checks: video poster and controls rendered, the video duration resolved to 174.4 seconds, the video received keyboard focus, and captions parsed to 22 cues.
- Responsive visual checks: desktop and 375px full-page screenshots show the frame inside the intended layout without horizontal clipping.
- HTTP health: local landing page, local caption track, and public preview returned HTTP 200.
