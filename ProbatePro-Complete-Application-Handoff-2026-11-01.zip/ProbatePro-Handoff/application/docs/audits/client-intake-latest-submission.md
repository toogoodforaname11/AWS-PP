# Client Intake Latest Submission Selection Audit

**Date:** 2026-10-13
**Scope:** Estate Client Portal review selection only

## Reported behaviour

After a lawyer reloaded an estate, the Client Portal review panel could reopen an older intake submission instead of the newest submission.

## Root cause

`ClientIntakeReview` chose the first submission whose status was `submitted`. That silently coupled the automatic selection to response order and preferred an older pending record over a newer submitted record.

## Repair

- The review component now derives a stable newest-first sequence using `submittedAt`.
- Automatic selection uses the newest available submission whenever there is no valid explicit selection.
- The submission selector itself uses the same ordered sequence.
- A valid lawyer-selected submission is retained during re-renders.

No client facts are applied, changed, deleted, or inferred by this repair. Portal session authorization, database query scope, submission payloads, lawyer review actions, contact/inventory application, and court-form behaviour were intentionally unchanged.

## Regression coverage

`client/src/components/ClientIntakeReview.test.tsx` now supplies an older pending record followed by a newer record and asserts that the newest report is opened initially. The regression failed before the repair and passed after it.

## Validation

| Check | Result |
|---|---|
| Focused review regression | 18 passing |
| TypeScript | `pnpm check` passed |
| Full serial suite | 311 files passed, 1 skipped; 4,563 tests passed, 3 skipped |
| Production build | `pnpm build` passed |
| Whitespace | `git diff --check` passed |
| Runtime health | Local and preview roots returned HTTP 200 |
