# Client Intake Local Draft Recovery

**Date:** 2026-10-15  
**Scope:** Executor/Client Portal — prevent loss of an in-progress, unsubmitted client intake after refresh.

## Reported issue

Refreshing the Executor/Client Portal could discard information entered into the intake before it was sent to the legal team.

## Root cause

`ClientIntakeForm` kept all unsubmitted answers only in React state. A browser refresh unmounted the component and recreated it from the portal-session defaults, with no local recovery record or client-controlled restore path.

## Repair

- Reused the existing browser-local `useLocalDraft` mechanism for the client intake only.
- Marked the intake dirty only after a client-originated edit; initial contact defaults, lawyer-authored question hydration, and server-provided revision prefill do not create drafts.
- Added an explicit, accessible recovery notice after a refresh with **Restore saved draft** and **Discard saved draft** controls. Neither action sends data.
- Restoring preserves the current lawyer-authored question set and restores only matching answer IDs, then moves keyboard focus to the first client field.
- Scoped browser storage to an opaque, deterministic value derived from the authenticated estate/contact session. The estate ID and email are not included in the storage key or rendered UI.
- Cleared the local draft after a successful intake submission, explicit discard, or when the submitted receipt is shown.
- Kept the existing portal-session query inside `PortalContent` so a one-time access-token exchange still refreshes portal identity before the form receives its scope.

## Evidence

| Check | Result |
| --- | --- |
| Red regressions | Failed before implementation for missing restore notice, missing successful-send cleanup, and absent portal draft scope. |
| Focused form and portal suites | **25 passed**: same-scope recovery, cross-scope isolation, explicit restore/discard, focus restoration, no hydration-only save, successful-send cleanup, and opaque scope wiring. |
| Fictional-browser validation | Typed a fictional value, refreshed, restored it by keyboard, confirmed no submission occurred, confirmed local draft removal after restore/discard, verified a 375 px viewport, and recorded no console errors. No real portal session or client record was accessed. |
| Full serial suite | **311 files passed, 4,591 tests passed, 3 expected skips**. |
| Type checking | `pnpm check` passed. |
| Production build | `pnpm build` passed. |
| Whitespace | `git diff --check` passed. |
| HTTP health | Local `/portal` and sandbox preview `/portal` both returned **200**. |

## Scope confirmation

This is browser-local draft recovery only. It does **not** change portal authorization, API payloads, server persistence, estate records, inventory, lawyer review/apply behavior, court forms, generated documents, legal wording, or existing client data.

## Known unrelated build warning

The existing build warning about `jspdf` being both dynamically and statically imported remains non-fatal and was not changed by this work.
