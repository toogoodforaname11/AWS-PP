# Client intake submitted-answer receipt repair

**Date:** 2026-10-14  
**Scope:** Executor/Client Portal post-submission presentation only

## Reported behavior

After an executor sent the intake, the portal replaced the form with an **Under Review / Your intake has been sent** panel. The form itself was intentionally hidden, but the panel did not show a record of the answers the executor had just submitted. This made the result appear blank and left the executor unable to confirm what had been sent.

## Cause

`ClientIntakeForm` stored only a successful submission identifier in its component receipt state. The submitted confirmation component received status information only; it received neither the just-submitted payload nor the stored submission payload after a portal reload. The earlier regression explicitly asserted that submitted values were absent from that confirmation.

## Repair

- The form now captures an immutable snapshot of the form at the moment it is sent.
- The success panel renders a **Your submitted answers** read-only receipt from that snapshot immediately after success.
- On a later reload, the same receipt is rebuilt from the selected saved submission payload.
- The receipt shows only values that belong to that submission, organized into readable sections such as Deceased, Client details, reported people, reported assets or debts, documents, custom responses, and additional information.
- The normal editable form remains unavailable after an ordinary submission; this is a receipt, not an unreviewed resubmission path.
- The existing revision-request flow remains authoritative. A revision request for the just-submitted report clears the receipt and restores the editable revision form.
- The compact submission announcement remains the only `role="status"` / `aria-live="polite"` region. The potentially long answer receipt is a separately named, read-only region so assistive technology is not forced to announce every submitted fact at once.
- The PDF export and client-facing receipt share the same pure section builder, preserving the existing export content and preventing divergent labels.

## Privacy and boundaries

The receipt contains only the immutable payload that the executor supplied through the current portal submission. It does not expose lawyer review notes, current estate values, access details, application choices, or other estate records. No portal authorization, persistence, database schema, lawyer review/apply controls, court-form output, document wording, or legal workflow changed.

## Validation evidence

1. Added red regressions for both immediate mutation success and saved-submission reload. Each initially failed because no accessible **Your submitted answers** region existed.
2. Passed focused component and completed-intake PDF coverage: **41 tests**.
3. Used a fictional isolated browser fixture to submit, reload, and confirm the read-only receipt. It verified the saved answers, the concise live status, absence of editable inputs, focus on the confirmation heading, keyboard continuation, desktop and mobile layout bounds, and no console errors.
4. Ran the full serial suite: **4,586 passed, 3 skipped**.
5. Ran TypeScript checking, production build, whitespace validation, and local plus preview health checks for `/` and `/portal`; each returned **HTTP 200**.

> The production build retains the existing non-fatal jsPDF static/dynamic import warning. This repair only extracted its existing payload-section formatter into a pure shared client module; it did not alter the import warning's underlying established usage.
