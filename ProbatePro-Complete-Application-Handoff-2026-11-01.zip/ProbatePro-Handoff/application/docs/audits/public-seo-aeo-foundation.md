# Public SEO and AEO Foundation Audit — ProbatePro

**Date:** 2026-10-12  
**Scope:** Public pre-login marketing surface, public legal pages, crawl controls, and authenticated Settings / How It Works / Executor Portal boundaries.  
**Out of scope:** Estate-file content, court-form wording and citations, generated documents, private records, access control, and legal-policy body copy.

## Executive summary

ProbatePro’s public site had a solid product demonstration but lacked a crawlable technical foundation: the home page metadata targeted only lawyers, `robots.txt` and `sitemap.xml` fell through to the SPA HTML instead of returning crawl directives/XML, and there was no public answer surface for users looking for product information about Settings, the workflow, or Executor Portal. Those three issues made it harder for search engines and answer engines to identify the product’s audience, public scope, and canonical pages.

The implementation establishes an accurate public search surface without exposing the application workspace. It adds descriptive metadata, an accessible BC-probate landing-page overview for lawyers and personal executors, visible product FAQs, conservative page-matching JSON-LD, a working sitemap, and crawler blocks plus `noindex, nofollow` metadata for private Settings, How It Works, and Executor Portal routes. No legal body text, citations, court-form language, estate data, or document output was changed.

## Evidence and research basis

| Source | Finding applied |
|---|---|
| [Google Search: Optimizing for generative AI features](https://developers.google.com/search/docs/fundamentals/ai-optimization-guide) | AI-search visibility relies on normal crawlability, technical clarity, and non-commodity people-first content—not special “AI SEO” files or keyword stuffing. |
| [Google Search: Helpful, reliable, people-first content](https://developers.google.com/search/docs/fundamentals/creating-helpful-content) | For a legal-adjacent topic, visible purpose, accurate scope, and trust are more important than mass-produced pages. |
| [Google structured-data policies](https://developers.google.com/search/docs/appearance/structured-data/sd-policies) | JSON-LD must describe visible page content and must not include misleading claims or concealed content. |
| [Estateably — British Columbia](https://www.estateably.com/jurisdictions/british-columbia) | A direct comparable uses jurisdiction-specific public product content and clearly enumerates supported probate outputs. |
| [EstateExec — BC Executor’s Guide](https://www.estateexec.com/ca/Docs/Guide/BC) | A direct comparable serves personal-executor intent with public BC-oriented educational guidance. |
| Public fetch of `https://probate-pro.com/robots.txt` and `/sitemap.xml` before the change | Both URLs returned the SPA landing page rather than robots directives/XML. |

## Shipped technical SEO improvements

| Area | Implementation | Why it matters |
|---|---|---|
| Public metadata | Replaced the lawyer-only default title/description with **“BC Probate Software for Lawyers & Executors | ProbatePro”** and matching factual Open Graph/Twitter metadata. | Makes the public audience, geography, and product category clearer without overstating functionality. |
| Canonical URLs | Added canonical root metadata and a reusable `Seo` component for page-level canonical URLs. | Reduces ambiguity for the three indexable public URLs. |
| Public product content | Added a visible role-specific workspace overview for lawyers, personal executors, and controlled collaboration. | Addresses the user’s request to surface public information about Settings and Executor Portal without indexing a private account workspace. |
| Answer-ready content | Added five visible FAQ answers covering audience, intake-to-document workflow, Settings, Executor Portal, and the legal-advice boundary. | Gives visitors and answer engines concise, page-visible product answers. |
| Structured data | Added a conservative `SoftwareApplication`, `Organization`, and `FAQPage` JSON-LD graph whose values mirror visible landing content. | Improves machine readability without using reviews, ratings, pricing, invented credentials, or hidden content. |
| Crawl control | Added real static `robots.txt` and `sitemap.xml` assets; the sitemap contains only `/`, `/terms`, and `/privacy`. | Repairs the prior SPA fallback defect and prevents private routes from being treated as public site pages. |
| Private-route protection | Explicitly blocks workspace patterns in `robots.txt` and writes `noindex, nofollow` metadata for Settings, How It Works, and Executor Portal. | Preserves privacy and prevents authenticated workspace content from becoming SEO content. |
| Public legal pages | Added indexable canonical metadata to Terms and Privacy without changing their legal text or citations. | Avoids duplicate generic titles for indexable legal pages while preserving reviewed legal language. |

## What was deliberately not changed

- No official court form, generated-document template, filing requirement, citation, or layout.
- No estate-file content, records, or account access path.
- No legal policy or Terms body language.
- No fabricated reviews, rankings, customer numbers, locations, pricing, legal outcomes, or “best” claims.
- No programmatic page farm. Future province/form/topic pages require unique, reviewed public content and a separate task.

## Backlink and competitor-data status

The user approved both **Competitor Benchmarking** and **Competitor Backlink Comparison for Link Gaps and Opportunities** and connected Ahrefs with a free-tier intent. The enabled Ahrefs connector was queried with only read-only endpoint requests for `probate-pro.com`, `estateably.com`, and `estateexec.com`.

All requested detailed endpoints—batch comparison, referring-domain history, referring domains, anchor profile, and backlinks—returned **“Insufficient plan.”** Ahrefs’ public Domain Rating endpoint returned the same response. Therefore, this audit does **not** present invented domain ratings, link counts, growth/loss, anchor distribution, link risk, or competitor link gaps. A data-backed backlink report remains pending until one of the following is available:

1. An Ahrefs plan with Site Explorer/API access;
2. An export from Ahrefs, Semrush, DataForSEO, or Similarweb; or
3. A separately authorized paid data source.

When a usable source is available, the report should include the target’s last-three-month referring-domain growth/loss, referring-domain quality and risk sample, anchors, competitor benchmark, and competitor link-gap section requested here.

## Validation evidence

| Check | Result |
|---|---|
| New metadata unit tests | 2 passed |
| Focused public SEO suite | 57 passed across 8 files |
| TypeScript | `pnpm check` passed |
| Full serial suite | **4,484 passed, 3 skipped** across 303 files |
| Production build | `pnpm build` passed |
| Whitespace validation | `git diff --check` passed |
| Built assets | Production output includes `dist/public/robots.txt` and `dist/public/sitemap.xml`; sitemap parsed as valid XML |
| Development server | Local root, robots, and sitemap each returned HTTP 200; robots content type was `text/plain`, sitemap was `text/xml` |
| Public preview | Root, robots, and sitemap each returned HTTP 200 |

## Post-deployment checks

After production deployment, submit `https://probate-pro.com/sitemap.xml` in Google Search Console, inspect the public root and the three public URLs, and monitor the Generative AI performance report where available. These are observation steps—not a promise of indexing, rich-result eligibility, ranking position, or traffic.
