# Client Intake Relationship Normalization Repair

**Date:** 2026-10-14  
**Scope:** Executor/Client Portal relationship facts applied to Contacts

## Reported behavior

A relationship reported through the portal, such as `second cousin`, could be saved as readable text while the Contacts editor expected a different persisted Select value, `second_cousin`. Because no Select item matched the stored value, the Relationship to Deceased control appeared blank after application.

## Root cause

`buildClientIntakeApplication` copied selected relationship text verbatim from the client report. The portal intentionally accepts client-friendly text, while the Contact editor stores a defined set of option values with a mixture of spaces, hyphens, and underscores. No mapper normalization connected the two representations.

## Repair

The client-intake mapper now normalizes only relationship phrases that correspond to existing Contact selector options. It accepts equivalent spacing, hyphen, underscore, and case variants and persists the canonical existing value; for example:

| Portal report | Stored Contact value | Editor display |
|---|---|---|
| `second cousin` | `second_cousin` | Second Cousin |
| `maternal grandmother` | `maternal_grandmother` | Maternal Grandmother |
| `common law partner` | `common-law partner` | Common-Law Partner |

An unfamiliar report remains verbatim rather than being guessed or silently reclassified. The change does not add, remove, or alter Contact roles, executor status, legal relationship rules, form generation, database schema, existing records, or authorization.

## Regression coverage

A red-green mapper regression proves that selected portal relationship facts are converted to matching Contact picker values for common spacing variants, while an unknown phrase remains unchanged. The focused portal mapping, router, review, and contact-dialog suites pass: **64 tests**.

A fictional browser fixture (no authenticated account or estate data) verified that a normalized `second_cousin` contact:

- renders as **Second Cousin** in the Contact edit dialog;
- is selected in the keyboard-opened relationship list;
- remains visible and usable at desktop and 375px mobile widths; and
- produces no console errors.

## Release verification

- Serial suite: **4,574 passed, 3 skipped**
- TypeScript: `pnpm check` passed
- Production build: passed
- Whitespace: `git diff --check` passed
- Health: local and sandbox preview HTTP **200**

The production build continues to emit its pre-existing jspdf dynamic/static import and chunk-size warnings. This repair does not change those unrelated build warnings.
