# P2 certified-copy popup repair

_Completed 2026-10-08 — Form P2 generation detail controls only_

---

## Finding

The existing Form P2 DOCX builder and structured preview already use three separate official certified-copy request values:

1. Estate grant
2. Affidavit of assets and liabilities for domiciled estate grant
3. Affidavit of assets and liabilities for non-domiciled estate grant

The P2 generation dialog exposed only signatory and signature date, then displayed a read-only note directing users to Intake. With the estate-grant request defaulting to three copies, a user could generate P2 with only that request selected and omit the separate assets-and-liabilities request.

## Repair boundary

The P2 generation dialog now presents an independently selectable checkbox and quantity field for each of the three existing official request lines. The values use the existing estate columns and persist through the established revision-safe `estate.update` path before preview or generation continues.

| Request | Stored value | Dialog behavior |
| --- | --- | --- |
| Estate grant | `certifiedCopies` | Prefilled from the existing value; a positive quantity selects the existing face line |
| Domiciled assets-and-liabilities affidavit | `certifiedCopiesP10` | Unchecked at zero; selecting it initializes one copy, then allows a quantity from 1 to 20 |
| Non-domiciled assets-and-liabilities affidavit | `certifiedCopiesP11` | Unchecked at zero; selecting it initializes one copy, then allows a quantity from 1 to 20 |

Clearing a selected request saves zero and preserves the existing selected-only renderer behavior, so the unused line does not print. An in-progress amount change is flushed as a number before the Generate or Preview handoff; it cannot race the document builder.

> The authorization-to-obtain-estate-information request remains absent. P2's existing selected official election states that Form P10 or P11 is filed, so offering an authorization-copy request would contradict the selected branch.

## Preserved constraints

- No official court-form wording changed
- No DOCX layout, checkbox geometry, indentation, or page behavior changed
- No document renderer logic changed; DOCX and structured preview retain their existing shared three-line mapping
- No operational, readiness, attachment, or non-output question was added to the P2 popup

## Verification

- P2 dialog regression coverage verifies all three controls, select/unselect persistence, safe replacement of an existing quantity, and an unblurred quantity save before Generate
- P2 DOCX and structured preview regression verifies all three selected official lines and excludes the authorization line
- TypeScript check passed
- Full serial suite passed: 300 files, 4,457 tests, 3 skipped
- Production build passed
- `git diff --check` passed
