# Dashboard client-intake submission indicator — verification record

**Date:** 2026-10-12
**Scope:** Estate Files dashboard only

## Completed behaviour

The Estate Files dashboard now shows a restrained **Client intake received** control when both conditions are true for an estate:

1. The estate currently has one or more lawyer-authored case-specific intake questions; and
2. At least one portal intake submission remains in the `submitted` state, awaiting lawyer review.

The control uses an icon-led, navy surface treatment rather than a coloured dot or counter. It is keyboard reachable, has a visible focus ring, stops the parent-row navigation event, and routes directly to the existing **Client Portal** tab for that estate.

## Privacy and authorization boundary

A new no-input protected `clientIntake.dashboardStatus` procedure derives estate IDs solely through `db.listEstates(ctx.user.id)`. It invokes a narrow aggregate that selects only `estateId` from `client_intake_submissions` for those IDs and `status = "submitted"`.

The dashboard receives only these booleans by estate ID:

```ts
{ hasCustomQuestions: boolean; pendingReview: boolean }
```

It does **not** receive client names, email addresses, submission IDs, timestamps, custom prompts, answers, or encrypted payload content. Records that are approved or returned for revision do not render as pending review. The procedure safely degrades to no visual signal for malformed saved custom-question configuration.

## Deliberate exclusions

- No database migration or schema change.
- No portal submission, review, apply, link, access, session, or notification behaviour changed.
- No estate facts, contacts, inventory, court forms, document generation, legal wording, citations, or client data were changed or inspected.

## Validation evidence

| Check | Result |
|---|---|
| Focused dashboard, router, and persistence suites | **68 passed** |
| TypeScript | `pnpm check` passed |
| Full serial suite | **4,533 passed; 3 skipped** across 309 passed test files / 1 skipped |
| Production build | `pnpm build` passed |
| Whitespace | `git diff --check` passed |
| Runtime health | Local root, public development root, and Home module each returned **HTTP 200** |

The focused regressions prove owner-derived aggregate IDs, `submitted`-only status selection, no custom-question signal without both eligibility conditions, no client text rendered, and navigation to `?tab=client-portal`.
