# Affidavit jurat firm-city default

_ProbatePro implementation record — 2026-10-11_

---

## 🎯 Objective

Default every affidavit jurat to the recorded law-firm office city when that affidavit has no explicit sworn-place override. An explicit form or estate jurat city remains controlling. A deceased address or residence is never used as evidence of where an affidavit was sworn.

## 📋 Resolution matrix

| Affidavit group | Explicit city source | Default when blank | Result |
| --- | --- | --- | --- |
| Applicant affidavits | `estate.domicileCity` | `settings.firmCity` | Existing common rule retained |
| P11 — Assets and Liabilities for Non-Domiciled Estate Grant | `estate.juratCity` | `settings.firmCity` | Added shared fallback |
| P12 — Affidavit of Translator | `estate.p12JuratCity` | `settings.firmCity` | Added shared fallback |
| P34 — Affidavit of Deemed Renunciation | None | `settings.firmCity` | Added shared fallback |

If neither an explicit city nor `settings.firmCity` is recorded, the existing official blank fill remains. This does not infer a sworn place from the deceased’s address, the applicant’s address, or another city field.

## 🔧 Implementation boundary

- `server/docgen.ts` now uses the common `juratCity()` resolver for P11, P12, and P34 in both DOCX and preview branches.
- All other affidavit jurat calls were audited: they already resolve an explicit `domicileCity` before the same firm-city fallback.
- P11 and P12 city inputs remain available in Form Details as **optional overrides**. They no longer create a pre-generation gap, because a recorded firm city supplies the visible jurat value.
- P11 and P12 explicit overrides were separately verified to take precedence over a different recorded firm city.
- The P12 schema comment was updated only; `pnpm drizzle-kit generate` confirmed **no migration** is required.

> **Preservation:** Official jurat wording, layout, spacing, indents, checkbox geometry, signature-block flow, page breaks, and non-jurat content are unchanged.

## ✅ Verification

| Check | Result |
| --- | --- |
| Focused DOCX/preview, requirement, and Form Details suites | 757 passing |
| Cross-form jurat callsite audit | No stale P11/P12/P34 blank-only expression found |
| TypeScript | Passed |
| Drizzle schema generation | No schema changes; no migration required |
| Full serial suite | 4,467 passing / 3 skipped |
| Production build | Passed |
| Whitespace check | Passed |
