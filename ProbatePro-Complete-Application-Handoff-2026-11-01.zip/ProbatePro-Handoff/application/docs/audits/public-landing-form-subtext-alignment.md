# Public Landing Form Catalogue — Long-Code Alignment Repair

**Date:** 2026-10-13  
**Scope:** Public homepage catalogue layout only (`/`)

## Reported issue

On a narrow public-page viewport, conditions for the two consent entries and PGT information began after their unusually wide code badges. Their descriptions therefore appeared substantially farther right than the corresponding descriptions for ordinary P-series forms.

## Root cause and repair

The shared `FormItem` used a content-width flex badge followed by a text column. A long code widened its own badge and shifted the title and condition to the right. `FormItem` now uses a fixed two-column grid. Codes longer than ten characters occupy a first row; their titles and conditions begin in the standard catalogue text column beneath the code. Short codes retain their compact inline badge treatment.

This preserves the complete canonical form catalogue, titles, conditions, disclosure behavior, data, routes, and all application logic.

## Accessibility and responsive behavior

The conditional-form control remains an accessible native button. The adjustment is non-interactive; it does not alter focus order, disclosure state, or keyboard operation. The long code remains visible as text rather than being abbreviated, while the title and subtext remain readable in the shared text column.

## Regression and validation evidence

A component regression identifies the PGT information and Consent and Nomination rows as stacked long-code layouts and checks their condition markers. A browser regression initially failed with the consent condition **115.22px** farther right than a standard condition on a 390px viewport. After the repair, browser checks confirm both consent and PGT descriptions align with the normal description column on mobile and desktop, without horizontal overflow or browser-console errors.

Validation also included the complete Landing suite (**13 passing**), TypeScript, the serial application suite (**4,570 passing / 3 skipped**), production build, `git diff --check`, and local plus preview homepage health checks (**HTTP 200**). Existing non-blocking jsPDF static/dynamic import and chunk-size build warnings were unchanged.
