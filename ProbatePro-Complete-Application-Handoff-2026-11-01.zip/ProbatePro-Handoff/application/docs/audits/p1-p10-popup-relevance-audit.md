# P1–P10 popup relevance audit

_Implementation-oriented synthesis of the P1–P10 audits, updated after the 2026-10-07 content-only popup implementation. The individual per-form reports preserve the original source traces; this record distinguishes their historical findings from the completed UI and P2/P9 companion-flow changes. No prescribed form wording, checkbox geometry, indenting, or document layout was changed._

---

## Decision rule and implementation boundary

> **Implemented popup relevance rule:** a popup field is eligible only when its answer **directly fills visible document content**, selects a visible official alternative, or supplies a direct value used by the generated form. Availability, operational workflow, readiness, source-document, attachment, and cross-form history data must **not appear as popup completion fields or block the popup**.

Apply the rule at the **gap level**, after base requirements, injected universal preflight gaps, bridged readiness gaps, and dynamic gaps have all been assembled. A form-code prefix is not enough: `readiness:*` is a transport namespace, not proof that a fact is relevant to the owning form.

Two concerns remain distinct:

- **Content completion popup:** direct face facts and direct generation parameters only. A hard flag must not override this relevance filter.
- **Availability/draft handling:** an excluded non-content gap is never rendered as a card or button blocker. For a user-initiated single-form run, the continuation carries explicit draft intent without inventing any form fact.

Server-side validation remains the authoritative protection for a genuinely direct document parameter. The aim is not to make invalid documents generable; it is to prevent an irrelevant readiness, workflow, or source-file fact from becoming a visible modal field or an accidental hard stop.

## Implemented status — 2026-10-07

1. **Per-gap, form-owned filtering now applies to P1–P10 in both single-form and package popups.** A gap is classified by its owning form after all requirements, universal preflight rows, readiness bridges, and dynamic rows are assembled. An excluded row remains excluded even if a legacy preflight marked it hard.
2. **Readiness bridges are hidden by default.** The only retained exceptions are P2 executor/relationship/notice-recipient facts and P10 spouse/distribution facts that were source-traced to a visible P2 or P10 branch. Every other `readiness:*` row—including dynamic committee and VSA search rows—is excluded.
3. **A hidden non-content gap cannot disable a popup.** It sets explicit draft intent for the user-initiated continuation; no content card, hard badge, or duplicate availability escape is rendered.
4. **P2 no longer asks for a prior P9.** The former `p2_p9_affidavit_history` popup requirement and VSA alias bridge are removed. Where Rule 25-2 recipients exist, P2 DOCX and preview select the existing official companion-P9 alternative, use retained deponent/date facts when present, and otherwise keep only the existing blank fill line. P9 retains ownership of real delivery facts.
5. **P7 and P8 editors now match their output consumers.** P7 no longer asks for its unprinted organization title; P8 organization signatory name/title edits persist to the exact fields its preamble prints.

Focused regression coverage verifies the classifier, hard-gap suppression, package filtering, P2/P9 DOCX-preview parity, P3 selected-deponent draft forwarding, P7 title suppression, and P8 organization persistence. Full-project validation is recorded with the final implementation checkpoint.

### Classification used in this report

| Classification | Popup treatment | Examples |
| --- | --- | --- |
| **Face / direct parameter** | Retain as a popup field or direct selector | a printed date/name/address, a branch that selects prescribed wording, a recipient/delivery fact printed in P9 |
| **Availability** | Present only as a concise availability/draft status, not a content-card editor | `p1_applicability`, P3 short-form eligibility, P10-vs-P11 selection |
| **Operational, readiness, source, or attachment** | Remove from the popup and do not use to block it | `readiness:*`, VSA receipt/search workflow, upload/copy requirements, committee data |
| **Intentional retained warning** | Retain only when it identifies an actual omitted/blank/selected document branch or direct artifact | P9 delivery proof and P9 Exhibit A; P8 primary-affidavit history warning |

## Compact P1–P10 decision table

The exact IDs are in the form ledger below. “Status only” means an availability/draft treatment may remain outside the content-card list.

| Form | Retain in content/direct-parameter path | Hide, remove, or relocate from popup | Availability / hard-block conclusion |
| --- | --- | --- | --- |
| **P1** | 11 direct registry fields plus grant-type branch rows | Alias, birth, recipient/spouse, e-will reason, uploads, all readiness bridges | Status only for applicability; resolve generate-only foreign-grant file throws |
| **P2** | Direct affidavit facts and ancillary-face branches | VSA, notice-circle, source files, ancillary attachment mechanics, all readiness bridges | P9 delivery proof belongs to P9; fix direct P2 DOCX/preview parity |
| **P3** | Deceased, grant branch, jurat/deponent, PGT-notice fields | Every Rule 25-3(6) checklist row, source/PGT workflow and readiness rows | Rule 25 facts are a separate short-form availability/draft decision, not P3 face completion |
| **P4** | Direct long-form facts and conditional paragraphs/affidavit details | VSA/source, selected Rule 25 availability rows, readiness and global status/consistency rows | Retain direct later-document/alteration/copy/foreign-will requirements; use separate availability status |
| **P5** | Direct priority, other-grant/testamentary, jurat and no-will facts | Marriage-duration/successor/WESA workflow, route/consistency/applicability and readiness | Promote selected-applicant validation before a late generator failure |
| **P6** | Direct ancillary affidavit face facts | Foreign-grant filing metadata, will/VSA receipt, domicile recommendation and grantee readiness | Keep universal availability guards outside content completion |
| **P7** | Direct foreign-grant, applicant, VSA-result, and jurat facts | Grantee names, VSA receipt, source/workflow/global rows and generic readiness | Split organization fields so only printed signatory data is editable |
| **P8** | Deceased, oath, correct deponent preamble, primary-history warning | Co-applicant/history-validity mechanics, global rows and executor readiness | Surface eligible co-applicant / selected-deponent validation before generator failure |
| **P9** | Face branch, delivery proof/records, Exhibit A and relevant draft/availability status | Will-copy availability, dispensation order, recipient-determination and committee readiness | Delivery proof is an intentional P9 hard control because it directly governs sworn content/artifact generation |
| **P10** | All P10 registry fields except foreign-grant scope; direct P10 distribution/spouse facts | Global will-status and grant/will-consistency leaks; foreign-grant scope | Retain and promote applicant-deponent validation; grant type remains a direct branch |

## Form decision ledger: exact IDs

### P1 — Notice of Proposed Application in Relation to Estate

**Retain as direct face/branch IDs:** `p1_deceased_first_name`, `p1_deceased_last_name`, `p1_deceased_last_residence`, `p1_deceased_last_residence_country`, `p1_deceased_dod`, `p1_will_date`, `p1_applicant_names`, `p1_applicant_postal`, `p1_applicant_contact`, `p1_grant_type`, `p1_registry`, `p1_grant_type_required`, `p1_grant_will_consistency`.

**Hide/remove from content popup:** `p1_deceased_other_names`, `p1_deceased_birth`, `p1_deceased_place_of_birth`, `p1_recipient_list`, `p1_wesa_spouse_status`, `p1_spouse_name`, `p1_spouse_address`, `p1_electronic_will_no_signature_reason`, `p1_will_copy_upload`, `p1_codicil_uploads`, `p1_foreign_grant_upload`, `p1_foreign_grant_will_inclusion`, `p1_will_status_required`; all of `readiness:creditor_review`, `readiness:separation_date_missing`, `readiness:reconciliation_primary_purpose`, `readiness:reconciliation_duration`, `readiness:p1_recipient_determination`, and dynamic `readiness:committee_<contactId>`.

**Availability/status only:** `p1_applicability`. It may explain that the notice circle has no entitled recipient and may enable the documented single-form draft re-entry, but must not be a face-completion card.

**Verified defect:** ancillary/resealing P1 generation, unlike preview, resolves foreign-grant storage and can throw for `foreignGrantStorageKey` or `foreignGrantIncludesWill`. Those hidden attachment mechanics violate parity and the no-source-document-blocking rule.

### P2 — Submission for Estate Grant

**Retain as direct face/branch IDs:** `p2_wesa_spouse_status`, `p2_spouse_contact`, `p2_late_spouse_contact`, `p2_deceased_names`, `p2_deceased_dod`, `p2_deceased_address`, `p2_deceased_address_details`, `p2_marital_status`, `p2_grant_type`, `p2_grant_type_required`, `p2_ancillary_foreign_grant_issuing_court`, `p2_ancillary_foreign_grant_issuing_jurisdiction`, `p2_ancillary_foreign_grant_issued_date`, `p2_will_date`, `p2_will_filing_type`, `p2_will_language`, `p2_translator_name`, `p2_orders_answer`, `p2_orders_affecting_will`, `p2_order_filed_status`, `p2_referenced_documents_answered`, `p2_referenced_documents`, `p2_referenced_documents_cannot_obtain`, `p2_referenced_documents_not_testamentary`, `p2_certified_copies`, `p2_applicant_contact`, `p2_creditor_claim_amount`, `p2_treaty_first_nation_answer`, and `p2_treaty_first_nation_name`.

**Hide/remove from content popup:** `p2_vsa_certificate_received`, `p2_vsa_certificate_outcome`, `p2_vsa_all_names_searched`, `p2_notice_recipients_resolved`, `p2_notice_circle_confirmed`, `p2_notice_wait_elapsed`, `p2_pgt_grant_gate`, `p2_death_certificate_source`, `p2_original_will_source`, `p2_asset_statements_source`, `p2_applicant_id_source`, `p2_deceased_place_of_birth`, `p2_ancillary_foreign_grant_upload`, `p2_ancillary_foreign_grant_certification`, `p2_ancillary_will_inclusion`, `p2_ancillary_will_certification`, `p2_ancillary_separate_will_upload`, `p2_ancillary_codicil_uploads`, `p2_priority_paragraph`, `p2_will_status_required`, `p2_grant_will_consistency`, `p2_ancillary_filing_attachments`, and `p2_applicability` from the content-card set. Also remove all observed/injected readiness cards: `readiness:creditor_review`, `readiness:committee_<contactId>`, `readiness:all_names_searched` if restored, `readiness:executor_primary_missing`, `readiness:executor_primary_duplicate`, `readiness:separation_date_missing`, `readiness:reconciliation_primary_purpose`, `readiness:reconciliation_duration`, and `readiness:p1_recipient_determination`.

**Verified retained fact:** P2 section 3 is fixed prescribed VSA text. The VSA certificate, outcome, and searched-name inputs do not change P2 DOCX or preview and must stay excluded.

**Verified companion boundary:** In a P2/P9 package, P9 is generated first and supplies companion affidavit details to P2. `assertP9DeliveryProof` applies to P9, not P2. Do not create a P2 proof card or a P2 retained-P9-history prerequisite.

**Verified defect / no-hard-block risk:** `p2_ancillary_filing_attachments` currently hard-blocks because both DOCX and preview call the ancillary filing resolver. It is source/attachment mechanics, not P2 face content; relocate that enforcement out of the content popup and remove it as a popup blocker. Direct P2 also has a parity defect: DOCX can render blank P9-affidavit fills when notice recipients exist but retained P9 history is absent, while preview omits the section-2 row.

### P3 — Affidavit of Applicant (Short Form)

**Retain as direct face/branch IDs:** `p3_deceased_name`, `p3_grant_type`, `p3_grant_type_required`, `p3_domicile_city`, `p3_oath_type`, `p3_deponent_name`, `p3_deponent_address`, `p3_deponent_postal_code`, `p3_deponent_occupation`, `p3_applicant_contact`, `p3_notify_pgt_answered`.

**Hide/remove from content popup:** `p3_will_date`, `p3_vsa_certificate_received`, `p3_original_will_source`, `p3_pgt_auto_required`, `p3_will_status_required`, `p3_grant_will_consistency`, `p3_applicability`, `p3_rule_25_3_6_completion_required`, `p3_rule_25_3_6_short_form_unavailable`, `p3_rule_25_3_6_applicant_eligibility_unverified`, `p3_rule_25_3_6_s131_eligibility_unverified`, `p3_rule_25_3_6_diligent_search_unconfirmed`, `p3_rule_25_3_6_belief_last_bc_will_unconfirmed`, `p3_rule_25_3_6_special_circumstances_unconfirmed`, `p3_rule_25_3_6_will_filing_type_unconfirmed`, `p3_rule_25_3_6_will_compliance_unconfirmed`, `p3_rule_25_3_6_wesa_s58_unconfirmed`, `p3_rule_25_3_6_orders_affecting_will_unconfirmed`, `p3_rule_25_3_6_vsa_certificate_unconfirmed`, `p3_rule_25_3_6_vsa_notice_date_unconfirmed`, `p3_rule_25_3_6_military_will_unconfirmed`, `p3_rule_25_3_6_execution_issues_unconfirmed`, `p3_rule_25_3_6_alterations_unconfirmed`, `p3_rule_25_3_6_appearance_issues_unconfirmed`, `p3_rule_25_3_6_documents_attached_unconfirmed`, `p3_rule_25_3_6_other_grants_unconfirmed`, `readiness:executor_primary_missing`, and `readiness:executor_primary_duplicate`.

**Availability/status only:** the Rule 25-3(6) facts decide whether short-form P3 or P4 is available. They do not populate P3 paragraphs 4–12, which are unconditional prescribed text. Keep the normal rejection/draft decision in a separate eligibility flow; do not turn this checklist into P3 content completion.

### P4 — Affidavit of Applicant (Long Form)

**Retain as direct face/branch IDs:** `p4_deceased_name`, `p4_grant_type`, `p4_grant_type_required`, `p4_domicile_city`, `p4_oath_type`, `p4_deponent_name`, `p4_deponent_address`, `p4_deponent_postal_code`, `p4_deponent_occupation`, `p4_rule_25_3_6_applicant_eligibility_unverified`, `p4_rule_25_3_6_s131_eligibility_unverified`, `p4_rule_25_3_6_diligent_search_unconfirmed`, `p4_rule_25_3_6_special_circumstances_unconfirmed`, `p4_rule_25_3_6_will_filing_type_unconfirmed`, `p4_rule_25_3_6_will_compliance_unconfirmed`, `p4_rule_25_3_6_vsa_certificate_unconfirmed`, `p4_rule_25_3_6_vsa_notice_date_unconfirmed`, `p4_rule_25_3_6_military_will_unconfirmed`, `p4_rule_25_3_6_execution_issues_unconfirmed`, `p4_rule_25_3_6_alterations_unconfirmed`, `p4_rule_25_3_6_appearance_issues_unconfirmed`, `p4_rule_25_3_6_other_grants_unconfirmed`, `p4_execution_issue_description`, `p4_attestation_route`, `p4_attestation_affidavits`, `p4_alteration_details_complete`, `p4_interlineation_treatment`, `p4_interlineation_affidavits`, `p4_erasure_status`, `p4_erasure_treatments`, `p4_erasure_affidavits`, `p4_appearance_types`, `p4_appearance_other_specify`, `p4_military_will_description`, `p4_foreign_will_section_80_paragraph`, `p4_foreign_will_affidavit_name`, `p4_foreign_will_affidavit_date`, `p4_will_copy_knowledge`, `p4_will_copy_description`, `p4_later_testamentary_description`, `p4_other_grant_description`, `p4_other_grant_relevance_reason`, `p4_other_grant_applicants`, `p4_pgt_auto_required`, `p4_notify_pgt_answered`, `p4_will_medium_answered`, `p4_referenced_documents_answered`, `p4_electronic_copy_format`, `p4_referenced_documents_identify`, `p4_referenced_documents_cannot_obtain`, `p4_referenced_documents_not_testamentary`, `p4_special_circumstances`, `p4_special_circumstances_follow_up`, `p4_will_copy_affidavit`, `p4_will_copy_affidavit_complete`, `p4_special_circumstances_affidavits_complete`, `p4_repository_details`, `p4_electronic_original_unavailable_knowledge`, `p4_electronic_original_unavailable_reason`, `p4_electronic_original_unavailable_affidavit`, and `p4_electronic_original_unavailable_affidavit_complete`.

**Hide/remove from content popup in every dialog shape:** `p4_wesa_s58_order`, `p4_vsa_certificate_received`, `p4_original_will_source`, `p4_rule_25_3_6_belief_last_bc_will_unconfirmed`, `p4_rule_25_3_6_wesa_s58_unconfirmed`, `p4_rule_25_3_6_orders_affecting_will_unconfirmed`, `p4_rule_25_3_6_documents_attached_unconfirmed`, `readiness:executor_primary_missing`, `readiness:executor_primary_duplicate`, `p4_will_status_required`, `p4_grant_will_consistency`, and `p4_applicability`.

**Important distinction:** P4’s retained conditional-document facts are direct paragraph and affidavit inputs; they are not the P3 short-form availability checklist. Do not remove them merely because they are complex or may cause a non-draft renderer rejection.

### P5 — Affidavit of Applicant for Grant of Administration without Will Annexed

**Retain as direct face/branch IDs:** `p5_deceased_name`, `p5_priority_paragraph`, `p5_other_grants_status`, `p5_other_grants_status_valid`, `p5_other_grant_description`, `p5_other_grant_relevance_reason`, `p5_other_grant_applicants`, `p5_testamentary_doc_status`, `p5_testamentary_doc_status_valid`, `p5_later_testamentary_description`, `p5_oath_type`, `p5_deponent_name`, `p5_deponent_address`, `p5_deponent_postal_code`, `p5_deponent_occupation`, `p5_pgt_auto_required`, `p5_notify_pgt_answered`, `p5_will_status_required`, and `p5_no_will_confirmation`.

**Hide/remove from content popup:** `p5_marriage_like_duration`, `p5_prior_rights_consent`, `p5_prior_rights_inquiry_details`, `p5_intestate_successors`, `p5_wesa_spouse_status`, `p5_grant_type_required`, `p5_grant_will_consistency`, `p5_applicability`, `p5_without_will_affidavit_on_will_grant`, `readiness:executor_primary_missing`, `readiness:executor_primary_duplicate`, `readiness:creditor_review`, `readiness:separation_date_missing`, `readiness:reconciliation_primary_purpose`, and `readiness:reconciliation_duration`.

**Verified direct-parameter gap:** non-draft P5 rejects a selected applicant who does not apply, including a Settings lawyer, but no P5 preflight requirement identifies that selection. Add a direct selected-applicant/deponent validation before generation rather than exposing readiness facts.

### P6 — Affidavit of Applicant for Ancillary Grant with Will Annexed

**Retain as direct face/branch IDs:** `p6_deceased_name`, `p6_testamentary_doc_status`, `p6_later_testamentary_description`, `p6_vsa_certificate_result`, `p6_pgt_auto_required`, `p6_notify_pgt_answered`, `p6_applicant_contact`, `p6_individual_applicant_residence`, `p6_organization_signatory`, `p6_oath_type`, `p6_deponent_name`, `p6_deponent_address`, `p6_deponent_postal_code`, and `p6_deponent_occupation`.

**Hide/remove from content popup:** `p6_foreign_grant_issued_date`, `p6_foreign_grant_issuing_court`, `p6_foreign_grant_issuing_jurisdiction`, `p6_will_date`, `p6_vsa_certificate_received`, `p6_domicile_city`, and `readiness:foreign_grant_grantees`. Do not render universal will-status/grant-type/consistency or applicability gaps as P6 content cards when injected.

**Verified fact:** the foreign-grant court/date/jurisdiction data are filing material for P6, not text consumed by the P6 DOCX or preview. `p6_domicile_city` is recommended/non-gap.

### P7 — Affidavit of Applicant for Ancillary Grant of Administration without Will Annexed

**Retain as direct face/branch IDs:** `p7_deceased_name`, `p7_foreign_grant_issued_date`, `p7_foreign_grant_issuing_court`, `p7_foreign_grant_issuing_jurisdiction`, `p7_testamentary_doc_status`, `p7_later_testamentary_description`, `p7_vsa_certificate_result`, `p7_pgt_auto_required`, `p7_notify_pgt_answered`, `p7_applicant_contact`, `p7_individual_applicant_residence`, `p7_organization_signatory` **for printed `orgSignatoryName` only**, `p7_oath_type`, `p7_deponent_name`, `p7_deponent_address`, `p7_deponent_postal_code`, and `p7_deponent_occupation`.

**Hide/remove from content popup:** `p7_foreign_grant_grantees`, `p7_wills_notice_found_omits_para6`, `p7_vsa_certificate_received`, `p7_domicile_city`, `readiness:foreign_grant_grantees`, `readiness:executor_primary_missing`, `readiness:executor_primary_duplicate`, `p7_applicability`, `p7_will_status_required`, `p7_grant_type_required`, `p7_grant_will_consistency`, and the unprinted organization subfield `p7_organization_signatory:orgSignatoryTitle`.

**Verified implementation detail:** P7 paragraph 3 is fixed text and does not print foreign grantee names. P7’s organization editor must collect the printed signatory name, but must not request or persist `orgSignatoryTitle` as a P7 face field.

### P8 — Affidavit in Support of Application for Estate Grant

**Retain as direct face/direct-parameter IDs:** `p8_deceased_name`, `p8_oath_type`, `p8_deponent_address`, `p8_deponent_name` and `p8_deponent_occupation` for individual applicants, plus `p8_primary_affidavit_history` as a non-blocking paragraph-2 warning. For organizational applicants, the control must instead persist the actual consumers `orgSignatoryName` and `orgSignatoryTitle`; the current name/occupation UI does not populate P8’s organization preamble.

**Hide/remove from content popup:** `p8_co_applicants`, `p8_domicile_city`, `p8_will_status_required`, `p8_grant_type_required`, `p8_grant_will_consistency`, `p8_applicability`, `p8_primary_affidavit_missing`, `p8_primary_affidavit_ambiguous`, `p8_primary_affidavit_non_applicant`, `readiness:executor_primary_missing`, `readiness:executor_primary_duplicate`, and UI/internal selection values `selectedContactId` / `deponentId`.

**Intentional retained fact:** a single P8 draft without primary history is permitted and paragraph 2 intentionally displays blank reference fields. Therefore `p8_primary_affidavit_history` is a soft, direct-content warning—not a single-form hard block. Bulk/all-P8 history rules are separate availability/selection behavior.

### P9 — Affidavit of Delivery

**Retain as direct face/branch/proof/artifact IDs:** `p9_deceased_name`, `p9_oath_type`, `p9_foreign_grant_available`, `p9_foreign_grant_will_inclusion`, `p9_at_least_one_delivery`, `p9_delivery_recipient_names`, `p9_delivery_methods_and_dates`, `p9_all_required_recipients_resolved`, `p9_minor_delivery_branch`, `p9_electronic_ack_date`, `p9_no_registered_mail`, `p9_pgt_delivery_record`, `p9_electronic_will_demand`, `p9_substitute_receiver_names`, `p9_exhibit_a_p1`, `p9_will_status_required`, `p9_grant_type_required`, `p9_grant_will_consistency`, and `p9_applicability` (as availability/draft status where applicable).

**Hide/remove from content popup:** `p9_will_copy_available`, `p9_dispensation_order`, `readiness:p1_recipient_determination`, and dynamic `readiness:committee_<contactId>`.

**Intentional retained hard control:** `p9_at_least_one_delivery` is not an operational leak. `assertP9DeliveryProof` validates an effective, non-applicant actual delivery before ordinary P9 generation, preview, download, and packages; explicit Generate Anyway permits a truthful incomplete draft. Delivery facts populate sworn P9 lines and its Exhibit A companion behavior, so this is a valid direct artifact/content parameter.

### P10 — Affidavit of Assets and Liabilities for Domiciled Estate Grant

**Retain all P10 registry rows except the explicit exclusion below, including:** `p10_deceased_name`, `p10_deponent_is_applicant`, `p10_deponent_name`, `p10_deponent_address`, `p10_deponent_postal_code`, `p10_deponent_occupation`, `p10_signature_date`, `p10_grant_type`, `p10_oath_type`, `p10_at_least_one_asset`, `p10_asset_descriptions`, `p10_beneficiary_shares`, `p10_wesa_spouse_status`, `p10_inventory_categories`, `p10_asset_locations`, `p10_inventory_values`, `p10_passes_to_personal_representative`, `p10_real_property_ownership_details`, `p10_real_property_details`, `p10_liability_security_status`, `p10_secured_liability_asset`, `p10_secured_liability_asset_valid`, and `p10_secured_link_requires_status`.

**Intentional retained bridged direct facts:** `readiness:separation_date_missing`, `readiness:reconciliation_primary_purpose`, `readiness:reconciliation_duration`, and `readiness:p10_distribution` are exceptional `readiness:*` IDs. Their P10 mapping is verified to drive P10 distribution/spouse output, so retain them only after an explicit P10 face-consumption classification—not because of their prefix.

**Hide/remove from content popup:** `p10_part3_foreign_grant_scope`, `p10_will_status_required`, and `p10_grant_will_consistency`.

**Verified direct-parameter correction:** `p10_passes_to_personal_representative` is the valid explicit hard block and is independently enforced in DOCX and preview. `p10_grant_type_required` remains direct because it selects P10/P11 and fills P10 paragraph 1. By contrast, `p10_will_status_required` does not affect P10 DOCX or preview and must not disable the P10 content flow. Promote `p10_deponent_is_applicant` from soft preflight to a hard direct-parameter check because DOCX and preview already reject a selected non-applicant deponent.

## Generic bridge leaks and multi-form defects

The current dialog’s per-form negative ID sets are insufficient because server preflight adds `readiness:<sourceId>` after registry evaluation, and the UI currently retains hard rows even when an exclusion set would otherwise match. The generic `committee_*` branch is especially unsafe: it produces unbounded dynamic IDs that a static exclusion list cannot enumerate.

| Affected forms | Verified leaked bridge IDs | Required treatment |
| --- | --- | --- |
| P1 | `readiness:creditor_review`, `readiness:separation_date_missing`, `readiness:reconciliation_primary_purpose`, `readiness:reconciliation_duration`, `readiness:p1_recipient_determination`, `readiness:committee_<contactId>` | Remove all from P1 content popup |
| P2 | `readiness:creditor_review`, `readiness:committee_<contactId>`; observed assembled rows also include executor, reconciliation, and P1-recipient readiness; `readiness:all_names_searched` is stale/not currently bridged | Remove unless a specific P2 face-consumption mapping is proven; none is established here |
| P3/P4/P5/P8 | `readiness:executor_primary_missing`, `readiness:executor_primary_duplicate`; P5 also has creditor/separation/reconciliation rows | Remove from content popup |
| P6/P7 | `readiness:foreign_grant_grantees`; P7 also gets executor-primary rows | Remove: P6/P7 grantee names do not populate the audited face text |
| P9 | `readiness:p1_recipient_determination`, `readiness:committee_<contactId>` | Remove: P9 prints name/capacity, not the leaked committee-address readiness requirement |
| P10 | `readiness:separation_date_missing`, `readiness:reconciliation_primary_purpose`, `readiness:reconciliation_duration`, `readiness:p10_distribution` | **Retain only as explicit exceptions** because the audit verified a direct P10 output dependency |

Multi-form mode has an additional leakage path: P2 VSA exclusions are currently tied to an `isP2Only`/single-report condition, so `p2_vsa_certificate_received`, `p2_vsa_certificate_outcome`, and `p2_vsa_all_names_searched` can reappear in joint P2/P9 dialogs. Several P4 exclusions similarly reappear outside P4-only mode. The filter must apply **per gap and per owning form** before reports are flattened; it must not depend on `reports.length === 1`.

## Verified findings versus intentional retained facts

### Verified defects to correct

1. **Hard-gap override defeats relevance.** The current dialog keeps every `blocker === 'hard'` row, allowing universal, readiness, and source rows to bypass form-specific exclusions.
2. **Negative denylists cannot cover bridged/dynamic IDs.** `readiness:*`, especially `readiness:committee_<contactId>`, bypass bare requirement-ID filters.
3. **Single-form condition leaks into packages.** P2 VSA and P4 exclusion behavior changes merely because another form is selected.
4. **P1 foreign-grant attachment parity failure.** Direct P1 generation may fail on hidden attachment mechanics while preview does not.
5. **P2 attachment mechanics are a hard content-popup blocker.** `p2_ancillary_filing_attachments` is enforced by the shared renderer path despite not affecting P2 visible text.
6. **P2 direct generation/preview parity defect.** The absent-P9-history case yields a blank P9 affidavit line in DOCX but no section-2 row in preview.
7. **P8 organizational editor is a functional no-op for the printed P8 preamble.** It saves name/occupation instead of the DOCX/preview consumers `orgSignatoryName` and `orgSignatoryTitle`.
8. **Late direct-parameter failures are not consistently preflighted.** P5 and P7 selected non-applicants, P8 invalid/ambiguous selection states, and P10 non-applicant deponent checks can fail after the relevance popup.

### Intentional retained facts and constraints

- **P2 VSA text is fixed.** Excluding P2 VSA receipt/outcome/name-search values is correct, not a missing feature.
- **P2/P9 sequencing is intentional.** P9 precedes P2 in the package plan and supplies P2 section-2 companion context; P9 alone owns the delivery-proof refusal.
- **P3 Rule 25-3(6) is eligibility, not P3 face text.** Its current normal/draft protection must remain, but outside the P3 content-card list.
- **P4 conditional will facts are direct long-form content.** Unlike P3’s short-form gate, the listed P4 items populate conditional body text, alternatives, or affidavit references and should remain available.
- **P8 single-form blank primary history is an intentional draft.** Do not convert `p8_primary_affidavit_history` into a single-form hard refusal.
- **P9 actual delivery proof is valid.** It directly controls sworn delivery material; retain it as the P9 proof/artifact control.
- **P10 distribution/spouse readiness exceptions are intentional only after explicit mapping.** Do not use this exception to preserve other generic readiness cards.
- **Official wording and layout are out of scope.** The audit supports classification and flow changes only.

## Potential no-hard-block failures and safe disposition

| Risk | Why it matters | Safe disposition |
| --- | --- | --- |
| P1 foreign-grant storage/inclusion throws | Hidden source-file mechanics can stop direct generation but not preview | Remove from content-popup blockers; align generation/preview and relocate any filing-artifact validation outside the popup |
| P2 ancillary filing attachment resolver | A source/attachment requirement is hard in both preview and DOCX | Remove `p2_ancillary_filing_attachments` from content blocking; preserve any downstream filing-package check separately without making it a popup field |
| P3 Rule 25 gate | Removing cards without retaining an eligibility route could silently permit a normal short-form output | Keep a clear availability/draft decision before normal generation; do not present its checklist as face completion |
| P5/P7 selected non-applicant | The server rejects a direct selected-deponent/applicant only after the dialog | Add an explicit preflight direct-parameter error, then keep it in the relevant selection path |
| P8 co-applicant / primary-affidavit state | Dedicated intake or direct renderer can reject ambiguity/no eligible co-applicant; bulk behavior differs from single-form draft behavior | Validate selection before normal generation; retain the documented single-P8 draft and keep bulk availability logic separate |
| P10 selected non-applicant deponent | Existing `p10_deponent_is_applicant` is soft although DOCX/preview throw | Promote this exact direct-parameter requirement to hard preflight |
| P2/P9 absent-history parity | Preview and DOCX disagree despite no intended hard requirement | Make preview mirror the truthful DOCX blank-line behavior or make both use the same documented fallback |
| Package/single-form filter divergence | An irrelevant card reappears and may be hard only when a second form is selected | Apply relevance to every gap before merge and compute blocker state from eligible gaps only |

## Minimal safe implementation sequence

1. **Freeze the policy in tests first.** Add table-driven expectations for each retained/hide ID above, including hard rows, `readiness:*` rows, dynamic `committee_*`, and single- versus multi-form dialogs. Treat the supplied report as the fixture source.
2. **Introduce one central popup eligibility classifier.** Its inputs should include `formCode`, requirement/gap ID, origin (`registry`, `universal`, `bridge`, `dynamic`), and an explicit classification: `face`, `directParameter`, `availability`, `operational`, `source`, or `attachment`. Use positive per-form allowlists rather than name-based denylists.
3. **Filter only after all gaps are assembled.** Run the classifier before `displayedGaps`, `hardBlocked`, and Proceed-button state are calculated. Never reinstate a gap solely because it is hard. Handle dynamic `readiness:committee_<id>` by source/origin classification, not literal equality.
4. **Separate availability from content completion.** Render only a concise form-availability/draft status for IDs such as `p1_applicability`, `p3_applicability`, `p4_applicability`, `p5_applicability`, `p7_applicability`, `p9_applicability`, and P10’s P10/P11 selection. Preserve the existing explicit Generate Anyway semantics where the audits establish them.
5. **Close direct-parameter gaps before changing server behavior.** Add preflight parity for P5/P7/P8/P10 selected-deponent/applicant rules; correct P8 organization control persistence; retain P9 proof enforcement. This prevents a cleaner popup from merely moving a preventable error later.
6. **Resolve renderer/preview parity and source-blocking mechanics.** Remove P1/P2 attachment/source mechanics from modal blocking, decide their downstream filing-package treatment, and make P2 preview/DOCX use one absent-P9-history policy.
7. **Apply the same classifier to multi-form packages.** P2/P9 and P4 combinations must not fall back to `isP2Only`, P4-only, or `reports.length` behavior.
8. **Verify before release.** Run TypeScript check; targeted dialog/preflight/docgen/preview tests for P1–P10; package tests for P2/P9; and full test suite. Reconcile stale expectations rather than counting the suite as green while they remain.

## Evidence and verification note

This synthesis is based on the supplied P1–P10 audit evidence, including the associated reports in `docs/audits/p1-p10-popup-audit/01-p1.md` through `10-p10.md`, traced references to `PreGenerateDialog.tsx`, `shared/formRequirements.ts`, `shared/types.ts`, `server/routers.ts`, and `server/docgen.ts`, and the focused test results reported in those audits.

The audits report many focused suites passing (including P4, P5, P6, P7, P8, P9, and P10 runs), but also identify two current working-tree/stale-expectation failures: the removed `readiness:all_names_searched` P2 bridge expectation and the P2 absent-P9-history expectation. A broader P1 run likewise reported 379/381 passing with those pre-existing/current-source mismatches. This report does not represent those mismatches as fixed. The repository already contained modified application files when this documentation-only synthesis was prepared; no application source, test, or configuration file was modified by this work.
