# Assistant enterprise no-training disclosure

**Date:** 2026-10-14  
**Status:** Complete

## Scope

Update only the Assistant enablement confirmation dialog so it clearly describes the third-party enterprise AI processing and confirms that questions, selected files, and estate information are not used to train AI models.

## Confirmed basis

The product owner confirmed that the active third-party enterprise AI API has training disabled for user input. This is recorded in `RULES.md` so future work preserves the disclosure and requires re-verification if the provider or service tier changes.

## Repair

- Replaced the vague processor notice with clear, client-facing copy:
  - Requests may send questions, files deliberately provided, and relevant estate details to ProbatePro’s configured third-party enterprise AI processor.
  - Questions, files, and estate information are not used to train AI models.
- Kept the existing authorization and withdrawal explanation.
- Corrected a related keyboard accessibility defect discovered during browser validation: closing the confirmation with Escape now returns focus to the Assistant switch instead of the document body.

## Boundaries preserved

No AI processor, model selection, server-side approval gate, data-minimization logic, retention policy, privacy-policy text, estate data, authorization, form generation, or document content changed.

## Validation evidence

- Focused red regression captured the missing no-training disclosure.
- Focused red regression captured Escape returning focus to the document body.
- `pnpm vitest run client/src/components/AssistantConsentToggle.test.tsx` — 4 passing.
- Isolated fictional-data Chromium fixture: desktop and mobile dialog layout, keyboard open/close, focus restoration, no overflow, and no console errors.
- `pnpm check` — passed.
- `pnpm test -- --maxWorkers=1` — 4,571 passed / 3 skipped.
- `pnpm build` — passed; pre-existing jsPDF chunking/import warning remained non-fatal and was not changed.
- `git diff --check` — passed.
- Local and sandbox-preview HTTP health — 200 / 200.
