# Client Intake Application Undo — Audit

**Date:** 2026-10-12  
**Scope:** Undo the immediately preceding lawyer-applied client-intake change set from the estate-level **Client Portal** review panel.

## Delivered behavior

- An **Undo last apply** control appears beside an applied client-intake submission, and beside the pending-review summary after a partial application.
- Undo restores only the values changed by the most recent application from that submission. The review record returns to its preceding state, and the stored undo snapshot is cleared, so the action is single-use.
- The review panel refreshes the estate, contact, inventory, readiness, and dashboard caches after a successful undo.
- A success or conflict message is shown in the existing review-panel feedback path; no confirmation is required because the operation is deliberately narrow and immediately reversible.

## Safety model

The feature does **not** use a broad estate rollback. Before applying facts, the server stores one encrypted rollback snapshot containing only:

1. Estate fields changed by that application;
2. Existing Contact and Inventory fields changed by that application, or a complete row only when the application created that row; and
3. The submission review state before and after the application.

Undo is an atomic transaction and requires all of the following:

- Current estate revision equals the revision supplied by the review panel;
- The submission still carries the exact stored snapshot;
- The submission review state still matches the post-application snapshot;
- Every changed Contact and Inventory row still matches the recorded post-application value; and
- Newly created Contacts/Inventory are not subsequently linked by Inventory relationships.

Any later edit, re-review, link, repeated undo, stale revision, missing snapshot, or mismatched record fails safely with a refresh-and-review conflict. A later application replaces the old snapshot, making the feature strictly **one-step** rather than an unsafe change-history system.

## Data and privacy

Migration `0170_pale_baron_strucker.sql` adds nullable `lastApplicationSnapshot` to `client_intake_submissions`. The serialized rollback record is encrypted with the existing field-encryption helper, never returned by the client-intake list API, and exposed to the UI only as the boolean `undoAvailable`. The stored ciphertext is bounded at 45,000 bytes, below the deployment's known intake storage constraints.

An activity record is written after a successful undo without recording payload or answers.

## Exclusions

- No changes to portal authentication, client submission, client-visible questions, review selection, bulk/individual application rules, or revision requests.
- No changes to court-form content, generated documents, legal text, citations, contacts/inventory outside the selected application, or estate-wide history.
- No access to authenticated client or estate records during verification.

## Validation

- **Focused regressions:** 67 passed across client review UI, estate Client Portal placement, router ownership/conflict behavior, and atomic persistence.
- **TypeScript:** `pnpm check` passed.
- **Database:** migration applied with `pnpm db:migrate`; `pnpm db:check` confirms all 28 tables in sync.
- **Full serial suite:** 4,538 passed; 3 skipped.
- **Production build:** `pnpm build` passed.
- **Runtime:** local and public preview root returned HTTP 200; public browser runtime loaded successfully.
- **Scope hygiene:** `git diff --check` passed.
