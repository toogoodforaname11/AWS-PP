# Estate Client Portal: Implementation and Verification

## Delivered workflow

**Location:** Open an estate file and select **Client Portal**. The tab is available in both normal and form-focused mode, including the `?tab=client-portal` deep link.

1. The lawyer creates and manages the client’s secure, estate-specific intake link from this tab.
2. The client completes the guided questions in the supplied PDF’s sequence: About you; About the person who died; Executors; Family & other persons; Estate assets and debts; Documents to gather.
3. Submission creates a separate review record. It does not directly change the estate, generate a document, or create a court filing.
4. In the estate’s Client Portal tab, the lawyer can use **Apply** beside a field, select several facts and use **Approve selected facts**, or use **Apply all unapplied facts** after verification.
5. Applied facts remain visible and cannot be applied a second time from the same submission. Unapplied facts remain available for later review. The lawyer can request corrections, with general or field-specific comments.

The top-level Executor Portal remains the cross-estate access manager. Application controls have moved out of Intake into the estate-level Client Portal tab.

## Supplied PDF → application mapping

| PDF question/group | Client portal input | Application destination after lawyer approval |
|---|---|---|
| Your name, email, phone, relationship, occupation | About you | Individual contact fields on a neutral client-reported contact |
| Your street, second address line, city, province, postal code | Structured client mailing address, including unit/suite | Contacts → postal address |
| Your date of birth | About you → date of birth | Retained in the submission as review-only context; no equivalent contact birth-date field exists |
| Deceased full name | First, middle and last name inputs | Corresponding Intake name fields |
| Other names used | Other names input | Intake aliases and existing other-name controls; names are not guessed into first/last components |
| Deceased place of birth | Place of birth | Intake → deceasedPlaceOfBirth |
| Deceased last address | Street, unit/suite, city, province, postal code and country | Corresponding Intake address fields |
| Deceased date of birth and date of death | Date inputs | Corresponding Intake date fields |
| Deceased SIN | Not collected | Preserves the user’s prior removal of non-form SIN collection |
| Will yes/no, date and original location | Will answer with unknown state, date and location | Intake → willStatus/hasWill, willDate, willLocation; unknown is never applied as an answer |
| Nisga’a / treaty First Nation | Explicit answer and treaty name where applicable | Existing Intake First Nation fields |
| Executors named in the will | Repeatable executor contact entries | Selected Contacts fields; executor status remains unconfirmed, not applying or appointed |
| Spouse/former spouse, children, parents/siblings and other people named in the will | Repeatable people, with client-reported categories | Selected Contacts fields on neutral client-reported contacts; no automatic beneficiary or notice-recipient classification |
| Age for reported persons | Age, if known | Retained as review-only context; not converted to a date of birth or minor status |
| Real estate | Repeatable property details, optional value, location, title/ownership details | Selected Inventory fields |
| Vehicles, including year/make/model/VIN/value | Repeatable vehicle descriptions and optional values | Inventory → tangible asset, using the recorded description |
| Bank accounts/investments, branch address, account number/value | Repeatable financial account entries | Selected Inventory fields; account numbers use the existing encrypted write path |
| Other assets | Repeatable other assets | Selected Inventory fields |
| Estate debts | Repeatable debt entries | Selected Inventory liability fields; no inferred creditor Contact or security link |
| Original will, death certificate, most recent tax return; optional ID | Documents-to-gather checklist | Review-only checklist, not an upload or evidence-received confirmation |
| Extra information | Client notes | Retained as review-only context |

**Additional fields:** place of death, unit/suite, country, explicit unknown answers, and structured property/account detail support existing application fields without inventing facts.

## Application safeguards

- Link queries and approval routes assert estate ownership server-side. Link responses do not disclose stored access tokens.
- The client’s session fixes the estate/access identity; a client cannot choose another estate in the submission.
- The estate-level link dialog is pinned to the current estate and does not ask the lawyer to select a different estate.
- Name or item description must be applied first, or included in the selected batch, before dependent contact/item fields can be applied.
- Stable estate/submission-local row IDs keep partial applications updating the same new record rather than creating one record per field. A later, separate submission remains a separately reviewed report, not an automatic match to an existing Contact.
- Only selected facts are written. Contact role and inventory classification defaults are used only when creating a row, not when updating later selected fields.
- Estate revision and prior applied selections are checked in a transaction. Conflicts roll back estate, review, contact and inventory writes together.
- Unknown values remain unrecorded (`valueRecorded = 0`); they are not presented as a reported $0. Explicit $0 is retained. Monetary values are converted to integer cents without floating-point rounding.
- Client submission snapshots are encrypted using the existing field-encryption capability. Existing plaintext snapshots remain readable. New financial account numbers remain encrypted in Inventory.
- Submission size is bounded before encryption to fit existing TEXT storage, and applied-field metadata is bounded to its existing column.
- Unsaved Intake state is carried to the review tab and disables application until those pending changes are resolved.
- No database migration, court-form wording/layout edits, document-generator edits, statutory interpretation changes, or live estate-record access was required.

## UI verification

- Client form rendered with fictional fixtures: all input controls had accessible labels, and no horizontal overflow at a 390px container width.
- Lawyer review rendered with fictional fixtures at narrow and desktop widths. A footer overflow was reproduced and corrected with container-aware responsive layout; final 390px review width and scroll width both measured 390px, with no overflowing descendants.
- Individual Apply controls, batch selection, name/description dependency states, history display, revision requests and estate-pinned access creation are covered by component tests.
- Browser validation used isolated fictional fixtures with query execution disabled; no real client or estate data was read or written.

## Fresh validation

| Check | Result |
|---|---|
| Application TypeScript (`pnpm check`) | Passed |
| Focused mapping, router, persistence, review and estate workspace tests | 62 passed |
| Full application serial test suite | 4,520 passed; 3 skipped; no failures |
| Production build | Passed |
| Chatbot TypeScript | Passed |
| Full chatbot test suite | 205 passed; no failures |
| Whitespace / scoped diff review | Passed |
| Local/public preview HTTP health | Verified separately before checkpoint |

Existing court-form generators, legal wording and citations are unchanged. Document collection/upload and contact birth-date/age schema expansion are not part of this change.
