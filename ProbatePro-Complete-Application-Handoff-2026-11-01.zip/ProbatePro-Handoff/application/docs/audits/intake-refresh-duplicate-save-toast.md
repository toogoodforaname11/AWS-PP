# Intake refresh duplicate-save toast

**Date:** 2026-10-14  
**Status:** Complete

## Reported symptom

After the user refreshed the estate Intake, the application could show “Intake changes saved” even though no new edit had been made.

## Root cause

A confirmed latest Intake snapshot remained locally marked as dirty until the two-second delayed query refetch. If the page closed or refreshed during that interval, the unmount cleanup compared the current form to the still-stale parent estate prop, sent the same full-row update again, and the unmount-save callback could announce that duplicate request as a new save.

## Repair

The mutation-success path now immediately clears the explicit dirty marker only for the latest confirmed snapshot. The delayed timer retains its refetch role. The unmount autosave now requires both a true dirty marker and a data difference, so it preserves unsaved edits but skips the already-confirmed snapshot.

## Regression coverage

A red-green regression performs one real edit and save, receives confirmation, then unmounts immediately. Before the repair it observed two update requests; after the repair it observes exactly one and no “Intake changes saved” toast. A fictional-data Chromium fixture performed the same save-and-reload flow and verified one update, no duplicate success toast, and no console errors.

## Boundaries preserved

No estate data, database schema, server contract, contact/inventory behavior, portal workflow, document generation, court-form wording, authorization, or legal logic changed.

## Validation evidence

- Focused Intake lifecycle suite: 16 passing.
- TypeScript: passed.
- Serial suite: 4,572 passed / 3 skipped.
- Production build: passed. The pre-existing non-fatal jsPDF chunking/import warning was unchanged.
- `git diff --check`: passed.
- Local and sandbox-preview HTTP health: 200 / 200.
