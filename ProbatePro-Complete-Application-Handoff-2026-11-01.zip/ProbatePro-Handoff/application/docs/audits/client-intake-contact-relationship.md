# Client Intake Contact Relationship Repair Audit

**Date:** 2026-10-13  
**Scope:** One client-portal retest defect — relationship to the deceased was blank after applying newly reported contacts.

## Finding

The client-intake mapper already preserved a relationship when a lawyer selected that individual fact. The failure occurred earlier: the Family & other persons category selector looked like a relationship choice but did not populate the dedicated `relationship` field. With that field blank, the review panel had no relationship fact to apply.

## Repair

The portal now treats the supported family categories **Spouse**, **Child**, **Parent**, and **Sibling** as the client’s reported relationship, placing the value into the separate relationship input for lawyer review. The field is now labelled **“Relationship to the deceased, if known”** and has a contextual placeholder. A client-entered value always wins over an automatic category value. Changing a category only changes an earlier automatic value, preventing the interface from overwriting a more specific client report.

The selected relationship remains a proposed fact: it reaches the estate contact only when the lawyer selects it or uses **Apply all ready facts**. The category still never assigns a legal role, and relationship is not inferred from the person’s name or executor role.

## Boundaries preserved

This task did not alter contact roles, executor status, custom questions, portal access links, uploads, signatory choices, client submission ordering, existing estate records, or court-form generation/rendering. The client’s distinct name, address, and relationship inputs remain separate.

## Validation evidence

| Check | Result |
| --- | --- |
| Focused mapper + client form tests | 27 passing |
| TypeScript (`pnpm check`) | Passing |
| Full serial Vitest suite | 4,558 passing / 3 skipped |
| Production build (`pnpm build`) | Passing |
| `git diff --check` | Passing |
| Local / preview runtime root | HTTP 200 / HTTP 200 |

## Regression coverage

The mapper regression proves three separately selected relationship values become three matching contact patches. The portal form regression proves that choosing **Child** for a family person writes `child` to the dedicated relationship field, keeps it separate from the person’s name, and sends it in the submitted payload for lawyer review.
