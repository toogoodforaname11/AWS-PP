# Client-reported executor status — repair audit

**Date:** 2026-10-13
**Task:** `CLIENT-INTAKE-EXECUTOR-STATUS`

## Defect

A person entered through the Executor/Client Portal could be reviewed and created as an executor contact, but the portal did not collect a status. The resulting executor status was therefore blank, even when the client knew whether that person planned to apply, reserved their right, had renounced, could not act, or had died.

## Repair

- Added an executor-only, optional `executorStatus` to the validated client-intake contract. Legacy submissions default safely to blank.
- Added a plain-language portal selector with no preselected legal position:
  - Not known — leave for the legal team
  - Plans to apply for the grant
  - Will not join this application (right reserved)
  - Has renounced
  - Unable to act
  - Has died
- Kept citation-only `deemed_renounced` unavailable to portal users.
- Added the submitted nonblank status as a standalone lawyer-review fact. The lawyer must explicitly select it before it is applied to the estate contact.
- Rendered readable values in the lawyer review and completed-intake PDF; raw storage tokens do not appear in those surfaces.

## Safeguards retained

- No executor status is inferred or defaulted to `applying`.
- A client report changes no estate record until a lawyer selects it in the estate-side review panel.
- Family and other-person entries do not receive executor-status controls.
- Existing lawyer contact-status controls, court-form wording, document layout, and form-selection logic were not modified.

## Validation

- Red/green focused regression: status was rejected by the schema and absent from the portal before the repair; after repair, it is captured, made selectable in review, applied only to the executor contact, and rendered with a readable label.
- Focused tests: **48 passing** across client intake mapping, client portal form, review, and client-intake PDF suites.
- TypeScript: `pnpm check` passed.
- Full serial suite: **311 files passed, 1 skipped; 4,561 tests passed, 3 skipped**.
- Production build: `pnpm build` passed.
- `git diff --check` passed.
- Local development server and public preview both returned HTTP **200**.
