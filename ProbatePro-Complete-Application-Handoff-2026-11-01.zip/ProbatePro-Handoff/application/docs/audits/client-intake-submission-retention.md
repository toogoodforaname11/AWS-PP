# Client Intake Submission Retention Audit

**Date:** 2026-10-13  
**Scope:** Client Portal submission success state only

## Issue

After an executor submitted the Client Portal intake, the success callback intentionally rebuilt the form from an empty payload. That cleared completed ordinary fields and case-specific question answers even though the submission had succeeded.

## Change

- Removed the post-success form reset in `ClientIntakeForm`.
- Retained the existing confirmation toast and client-intake submission cache invalidation.
- Added a focused regression that enters a standard field and a required lawyer-authored answer, invokes the actual mutation success callback, and verifies both values remain visible.

## Deliberate boundaries

- No server procedure, authorization rule, submission persistence contract, database schema, or migration changed.
- No lawyer review, application, or court-form behavior changed.
- This audit covers only the reported blank-after-submit defect. The remaining portal retest findings remain separate tasks.

## Verification

- Focused client form regression: **14 passed**.
- TypeScript: `pnpm check` passed.
- Full serial suite: **4,554 passed; 3 skipped**.
- Production build: `pnpm build` passed.
- `git diff --check` passed.
- Local development server and public preview both returned HTTP **200**.
