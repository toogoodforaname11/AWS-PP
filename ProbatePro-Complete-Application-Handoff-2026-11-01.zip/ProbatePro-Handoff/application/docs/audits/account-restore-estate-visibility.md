# Estate List Recovery and Visibility

## Scope

This repair addresses the reported same-account mobile dashboard symptom in which an unresolved `estate.list` query displayed loading rows while nearby count controls displayed `0`. No client account, browser session, estate record, or production request was accessed or changed during this work.

## Confirmed Cause and Repair

| Area | Prior behavior | Repair |
| --- | --- | --- |
| Dashboard query state | A missing `estate.list` result flowed into Active, Archived, and status-filter count fallbacks as `0`. | Pending, failed, and otherwise indeterminate estate-list states now show an em dash and explicit `Loading files` or `Unavailable files` context; only a settled array may produce a numeric count or empty-state conclusion. |
| Transport | The shared tRPC request path retried some HTML 5xx responses but had no timeout for a request that never settled. | Requests now have a bounded 10-second attempt timeout, retain bounded retries for temporary infrastructure and network failures, and resolve terminal transport failures to the existing retryable tRPC error shape. Caller cancellation remains cancellation, not a fabricated server error. |
| Authorization | `estate.list` already called `db.listEstates(ctx.user.id)`, and the database query filters `createdByUserId`. | Preserved unchanged and covered with an explicit route-level ownership regression. No cross-account lookup, recovery, transfer, or fallback query was added. |

## Authentication Boundary

The client continues to send normal same-origin credentials and may use the existing `manus-cookie` Bearer fallback only when a mirrored session is present in session storage. Server authentication continues to prefer the verified cookie, then falls back to a verified Bearer token, and `estate.list` receives only the resulting authenticated user id. Session rotation remains wired through `X-Rotated-Session` without exposing its value in UI or logs.

## Evidence

The new deterministic dashboard regressions prove that both loading and failed estate-list states never render zero totals or the empty-state claim. The transport regression suite covers a hung request, temporary HTML 5xx recovery, and explicit caller cancellation. The ownership regression proves the list route sends the authenticated user id to the scoped database query.

Validation completed with the focused dashboard/transport/ownership suite, TypeScript, full serial application tests, production build, whitespace checks, and a diff review. Live reproduction against the reported account is intentionally outside this repair because that would require access to client data or an authenticated client session.
