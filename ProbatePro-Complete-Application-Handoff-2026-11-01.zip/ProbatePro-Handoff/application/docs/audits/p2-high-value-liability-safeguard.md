# P2 Schedule (d) — Recorded High-Value Liability Safeguard

**Date:** 2026-10-08  
**Scope:** Form P2 Schedule paragraph (d) only. This record addresses the false P2 creditor-negative independently of the separately reported TD notice/P9-recipient issue.

## Root cause

P2 classified Schedule (d) creditors solely from `Contact` records marked as a creditor with `claimAmountCents > $10,000`. Inventory records a liability amount, but its schema deliberately has no lender/creditor-contact relation. A recorded mortgage liability could therefore be more than $10,000 while P2 emitted the existing official sentence that no creditor has a claim exceeding $10,000.

## Narrow safeguard

For domestic and ancillary administration-without-will schedules, DOCX and structured preview now use the existing Schedule (d) blank fill when all of the following are true:

1. No qualifying over-$10,000 creditor Contact is available for Schedule (d).
2. Inventory contains a `liability` with a recorded value.
3. Its shared probate value is more than $10,000.

The existing official negative sentence is retained when there is no qualifying contact **and** no recorded high-value inventory liability. The existing named-creditor and unpriced-creditor paths are unchanged.

## Deliberate limits

- No creditor identity is inferred from an inventory description.
- No Contact, P1 recipient, P9 delivery, or P9 recipient is created or inferred.
- No P2 popup/preflight requirement, official wording, checkbox selection, indentation, spacing, or page break changes.
- The user must record the lender as a Creditor Contact with the claim amount before the system can identify that party for the later, separate notice/P9 task.

## Regression evidence

| Check | Result |
|---|---|
| New DOCX + preview regression: $212,400 unnamed mortgage liability on domestic administration | Blank fill; no false creditor-negative sentence |
| New DOCX + preview regression: same liability on ancillary administration | Blank fill; no false creditor-negative sentence |
| Focused P2/document/readiness/recipient suite | 166 passing |
| TypeScript | Passed (`pnpm check`) |
| Full serial suite | 4,431 passing; 3 skipped |
| Production build | Passed (`pnpm build`) |
| Whitespace check | Passed (`git diff --check`) |
