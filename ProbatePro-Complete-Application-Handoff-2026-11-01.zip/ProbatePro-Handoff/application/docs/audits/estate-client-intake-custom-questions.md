# Estate-Specific Client Intake Questions: Implementation and Verification

## Delivered workflow

**Location:** Open an estate file and select **Client Portal**. The feature is available before the estate-specific portal-link controls and client-submission review.

1. A lawyer can add, edit, reorder, remove, mark required, and save up to 20 free-text **case-specific questions** for the current estate only.
2. The portal client receives only the question configuration for the estate fixed by their authenticated portal session. The client sees a concise **Questions from your legal team** section, with optional guidance below each prompt.
3. Required answers are labelled, validated at the focused field, and revalidated server-side. The client request contains IDs and answers only; it cannot submit a prompt, help text, or required state.
4. At submission, the server resolves every ID against the current lawyer-owned estate configuration and stores an immutable prompt/help/required/answer snapshot in the separate client-intake submission.
5. In the lawyer’s Client Portal tab, submitted custom answers appear under **Review-only client context**. They deliberately have no Apply, Approve, Contact, Inventory, form, notice, or document-generation effect.

## Data, access, and migration safeguards

- The estate owns a validated JSON configuration (`clientIntakeCustomQuestions`); every submission keeps its own snapshot, so later question edits/deletions do not alter historical client reports.
- Owner procedures assert estate ownership before reading or changing configuration. The portal procedure derives the estate only from `ctx.portalSession.estateId`; no client input selects an estate.
- The API rejects unknown, duplicate, invalid, or unanswered required question IDs before it writes a submission.
- The 20-question, 500-character prompt/help, and 4,000-character answer limits are enforced in the shared Zod contract and the browser UI.
- Updating questions uses the existing estate revision token. A stale lawyer tab receives a refresh instruction instead of overwriting newer configuration. The Client Portal tab carries the new revision into the existing review controls after a save.
- Old submission payloads remain valid because `customQuestions` defaults to an empty array.

### Migration recovery

Generated migration `0169_pretty_gunslinger` adds the additive estate column with default `[]`. The managed database physically contained the historical schema while its Drizzle ledger had only the original entry, so the ordinary migrator attempted to recreate existing legacy tables before it could reach migration 0169. No client/estate records were read or changed during recovery.

After verifying the target column was absent and reading the generated migration, the reviewed additive column was applied once. The exact SHA-256 migration record (`482f829a6af4…`) and journal timestamp were then inserted only for migration 0169. A fresh `pnpm db:migrate` and `pnpm db:check` subsequently completed successfully, with all 28 tables in sync.

## Explicit exclusions

- No estate fact is automatically applied from a case-specific answer.
- No court form, document generator, official wording, legal citation, layout, form-selection rule, notice recipient, or deadline changed.
- No new portal-link permissions, token exposure, login behavior, upload workflow, notification, attachment, or question type was introduced.
- No real estate, client, portal-link, or session content was accessed for validation.

## Verification evidence

| Check | Evidence |
|---|---|
| Red/green contracts | Shared custom-question contract, owner/portal scope/snapshot, stale/foreign answer rejection, client required-answer, lawyer authoring, estate-tab placement, and review-only display regressions were added and run. |
| Focused suites | **57 passed** across shared contract, router, client form, question authoring, estate Client Portal, client review, and portal-copy suites. |
| TypeScript | `pnpm check` passed. |
| Database | `pnpm db:migrate` completed after ledger recovery; `pnpm db:check` confirmed **28 tables** in sync; the new `clientIntakeCustomQuestions varchar(16383)` column is present with `[]` default. |
| Full serial suite | **4,529 passed, 3 skipped** (309 passed files, 1 skipped). |
| Production build | `pnpm build` completed successfully. Vite reported the pre-existing large-chunk advisory only; it was not a build failure. |
| Runtime | Local root health probe returned HTTP **200**. |
| Scope hygiene | `git diff --check` passed; no whitespace errors. |

The estate-level Client Portal remains the single place where lawyers configure the questions, send the portal link, and review client submissions; the standard intake and court-form workflows are unchanged.
