# ProbatePro Rule 10 Records-Control Baseline

**Status:** Internal conformance baseline and product decision record — not a legal opinion or a compliance certification.

**Scope:** ProbatePro currently uses a single-account ownership model. It is intended for individual lawyer accounts and is being planned for individual personal executors who administer their own estates. Each account controls only its own records in the application. This document records a starting point for working toward Law Society of British Columbia Rules 10-3 and 10-4 **for lawyer accounts** while Manus remains the main application platform; it does not treat a personal executor as a lawyer or give legal advice to executors.

## 1. Why this work exists

Law Society Rule 10-3 regulates a lawyer’s use of a storage provider for records outside the lawyer’s office. It requires the lawyer to retain custody and control, retain ownership, be able to produce records, require secure handling and permanent destruction on instruction, and have a suitable written agreement with the storage provider.

Rule 10-4 requires reasonable security arrangements against loss, destruction, and unauthorized access, use, or disclosure.

Neither rule prescribes a particular cloud provider, a Canadian-only location, a database type, a VPS count, a backup topology, or a multi-server deployment. The controls below are risk-management steps to support the rules; qualified counsel must determine whether the final product and contracts satisfy the requirements for the intended lawyers and data.

## 2. Product decisions recorded on 2026-10-03

1. **Single-account purpose model:** A ProbatePro account will be explicitly classified as either an individual lawyer account or a personal executor account. The current model has no shared firm/workspace tenancy. The platform must not describe itself as owner of a lawyer’s client records or an executor’s estate records.
2. **Account-derived authorization:** The server derives the owner account from the authenticated session. A browser cannot choose another account’s owner identifier.
3. **No compliance overclaim:** Do not market the product as “Law Society compliant,” “Canadian-resident,” or “Canada-only” until provider, backup, support-access, subprocessor, contract, and recovery facts are verified and approved.
4. **No VPS-count rule:** A single appropriately hardened Toronto VPS plus independent encrypted backup may be a reasonable future sensitive-data vault for a small single-account deployment. Multiple VPSs are a resilience option, not a Law Society requirement.
5. **Sensitive-data minimization:** The current `deceasedSIN` field is not used by probate-form generation. It should remain optional and should not be required for normal probate workflow. A future vault decision must precede any expansion of sensitive-data collection.
6. **Retention controls:** Account-holder-directed deletion remains subject to applicable retention, production, and legal-hold obligations. “Delete from the screen” is not necessarily “destroy the record.” The specific obligations vary between lawyer and personal-executor use and require qualified advice where uncertain.
7. **Purpose is not authority:** Selecting “personal executor” must not claim or establish that the account holder is appointed as executor, applicant, or personal representative. Those are estate/contact facts recorded separately and must never be inferred from onboarding.

## 3. Existing technical controls

### Ownership and access

| Existing control | Evidence | Rule 10 contribution |
|---|---|---|
| Estate owner relation | `estates.createdByUserId` with an index in `drizzle/schema.ts` | Establishes the authenticated account attributable to an estate file; it does not prove legal executor appointment. |
| Estate authorization helper | `server/db.ts` `assertEstateOwned(estateId, userId)` | Rejects cross-account estate access. |
| Storage ownership metadata | `server/storageRegistry.ts` requires `estateId` and `userId` for `client_file` objects | Ties stored client-file bytes to both an estate and a lawyer account. |
| Fail-closed document authorization | `server/db.ts` `findAccessibleStoredObject(userId, storageKey)` plus `server/storageRegistry.ts` `withReadableStoredObjects` with a server-resolved read context (as of 2026-10-27; `userCanAccessStorageKey` remains in `server/db.ts` but has no non-test caller) | Requires an exact active manifest ownership match; a storage-key prefix alone is insufficient. |
| Server-managed file-key denylist | `shared/serverManagedEstateFields.ts` | Prevents a browser from writing storage keys into another estate. |
| Durable storage manifest | `stored_objects` in `drizzle/schema.ts` | Tracks owner, estate, category, retention class, checksum, provider, lifecycle state, and deletion activity. |
| Controlled disposition | `estate.delete`, `disposeEstate`, storage deletion outbox | Requires a basis and attestation; retains destruction status until provider deletion is verified. |
| Activity trail | `activity` records and storage-disposition records | Provides workflow evidence; it is not yet a complete security audit trail. |

### Privacy and retention statements already present

`client/src/pages/Privacy.tsx` currently discloses that data may be processed outside British Columbia or Canada, identifies provider review topics, describes access controls and encryption safeguards, and explains that estate records may require authorized retention/disposition. `client/src/pages/Terms.tsx` says account closure does not itself authorize destruction of estate or law-practice records.

These statements are a useful starting point, but they must be reconciled with the actual provider configuration and customer agreement before being treated as final legal terms.

## 4. Current gaps and limits

| Gap or open question | Why it matters | Safe next action |
|---|---|---|
| No executed storage-provider/data-processing agreement reviewed for Rule 10-3(4) | Product controls cannot replace the required contractual position. | Obtain provider terms and have counsel review the lawyer-facing agreement and provider terms. |
| No verified Canadian vault or independent Canadian recovery destination | A Canada-only claim cannot be made; recovery evidence is incomplete. | Use synthetic data only until an approved provider, backup destination, and restore test exist. |
| Sensitive uploaded documents currently use the existing storage path | Raw files may remain in the current platform storage path. | Inventory all storage classes, then migrate only after a vault design and deletion/reconciliation plan are approved. |
| Whole-account export remains out of scope | Rule 10-3 requires records be producible/exportable when required; individual estates can now be exported, but a portfolio-level archive has not been designed. | Use the lawyer-initiated per-estate export for each requested file; design a separately scoped portfolio export only if needed. |
| Personal-executor account purpose is not yet persisted | Current onboarding requests a firm profile even when a user chooses “not a lawyer,” creating confusing and potentially inaccurate professional framing. | Implement the planned `accountPurpose` enum and personal-executor onboarding/profile path; do not ship legal/executor-authority copy without counsel review. |
| Current public terms sometimes use “firm” language | The product now needs to distinguish lawyer, personal-executor, and any future workspace use. | Counsel-approved copy revision: “subscribing lawyer,” “personal executor,” or “account holder” as appropriate; do not imply a firm workspace exists. |
| No provider-backed recovery evidence | A backup file is not proof of recoverability. | Test restore of a synthetic estate and document set; record RPO/RTO results. |
| AI/document processing can transmit user-provided files when optional features are used | Cross-border processing must be disclosed and cannot be treated as Canadian-only. | Keep sensitive document AI processing opt-in/off by default until the processing boundary is approved. |

## 5. Minimum target state before accepting sensitive vault data

- A documented account-purpose and data-classification model distinguishes lawyer client records from personal-executor estate records, identifies what remains in Manus, what is excluded from AI processing, and what moves to a vault.
- Every estate and stored document has an account-derived owner and estate relationship.
- Cross-account access tests cover read, update, download, export, disposal, and a crafted file-key attempt.
- An account holder can export an individual estate record and its manifest-authorized documents in a usable ZIP format; a whole-account export remains a separate scope.
- Written provider/customer terms preserve the relevant account holder’s ownership, custody/control, export, security, and deletion-instruction rights, with lawyer-specific Rule 10 terms reviewed separately.
- The sensitive-vault provider, backups, snapshots, logs, support access, and subprocessors are known and documented.
- The operator has completed an encrypted backup restore using synthetic data.
- The product has an incident process and a contact path for lost control, unauthorized access, or destruction failures.

## 6. Not yet claimed

This baseline does **not** establish that ProbatePro is compliant with any particular law, Law Society obligation, PIPA/PIPEDA requirement, public-body rule, or Canadian residency requirement. It documents technical starting controls and the work still required.

## 7. Source material

- [Law Society of BC Rules 10-3 and 10-4](https://www.lawsociety.bc.ca/support-and-resources-for-lawyers/act-rules-and-code/law-society-rules/part-10-%E2%80%93-general/)
- [Law Society of BC cloud computing due diligence guidelines](https://www.lawsociety.bc.ca/getContentAsset/a6d7dfd6-0cd5-480a-b9c5-3fb942cc4c7b/dfc3d011-8f63-43f6-9ed8-4b444333a1d0/guidelines-cloud?language=en-CA)
- [Law Society of BC cloud computing checklist](https://www.lawsociety.bc.ca/Website/media/Shared/docs/practice/resources/checklist-cloud.pdf)
