# ProbatePro Hybrid Canadian Vault Blueprint

**Status:** Architecture proposal — not implemented

## Objective

Keep Manus/WebDev as the primary ProbatePro application, authentication surface, workflow engine, and ordinary estate database while isolating highly sensitive information in a Canadian-resident vault.

Sensitive data includes SINs, government identification, uploaded wills and codicils, death certificates, grants, bank statements, PGT/court correspondence, client portal uploads, and signed/generated documents that the firm elects to classify as highly confidential.

## Important residency boundary

A second database is not, by itself, a Canadian-residency solution. The residency boundary must include:

- Primary database and replicas
- Object storage and version history
- Backups and disaster-recovery copies
- Temporary upload and processing files
- Search indexes and queues
- Logs and diagnostics
- Encryption keys and key backups
- Document extraction/AI services
- Email attachments and external integrations
- Provider support and administrative access

If a sensitive document is permanently stored in Canada but is sent to a non-Canadian Manus server for parsing or form generation, the design is Canadian storage with cross-border processing—not a fully Canadian processing boundary.

## Target architecture

```mermaid
flowchart LR
  Browser[User browser] --> ManusApp[Manus/WebDev ProbatePro app]
  Browser -->|direct upload with short-lived token| VaultAPI[Canadian Vault API]
  ManusApp --> MainDB[Manus main database]
  ManusApp --> VaultAPI
  VaultAPI --> VaultDB[Canadian managed PostgreSQL]
  VaultAPI --> VaultObject[Canadian object storage]
  VaultAPI --> VaultKMS[Canadian-region KMS / key service]
  VaultAPI --> VaultWorker[Canadian document worker]
  VaultWorker --> VaultObject
  VaultWorker --> VaultDB
  ManusApp -->|opaque vault IDs/status only| MainDB
  ManusApp -->|job request, no raw sensitive bytes where possible| VaultAPI
```

## Data split

| Data | Manus main database | Canadian vault |
|---|---:|---:|
| Estate ID and internal status | Yes | Reference only |
| Estate name and workflow state | Yes | Reference only |
| Form selection/completion state | Yes | Reference only |
| Contact role and ordinary workflow facts | Yes, after privacy review | Optional |
| SIN | No | Yes, encrypted/tokenized |
| Government ID | No | Yes |
| Uploaded legal documents | No raw bytes | Yes |
| Generated sensitive DOCX/PDF | No raw bytes | Yes |
| Vault record ID and document status | Yes | Yes |
| File hash, MIME type, size, timestamps | Limited metadata only | Yes |
| Raw document text/OCR | No | Yes, if required |
| Encryption keys | No | Canadian KMS or customer-controlled key service |

## Core design rules

1. Manus stores only an opaque `vaultRecordId` or `vaultDocumentId` for sensitive items.
2. The browser uploads directly to Canadian object storage using a short-lived, single-purpose upload token.
3. The vault API validates the Manus session, estate ownership, requested operation, file type, file size, and malware-scan status.
4. Signed download URLs expire quickly and are never stored in the Manus database.
5. Vault object keys are random IDs, not names, SINs, estate names, or document titles.
6. Sensitive values are never written to application logs, analytics, error reports, URLs, browser localStorage, or toast messages.
7. The vault keeps an immutable audit record for upload, view, download, replace, delete, export, and failed access.
8. Deletion is retention-policy controlled, not an immediate UI delete for legal records.
9. Every provider contract must identify regions, subprocessors, breach obligations, export/termination rights, and support access.
10. AI/document extraction is disabled by default for sensitive documents unless the processing service is inside the approved Canadian boundary.

## Suggested Canadian vault stack

Use managed services rather than a self-hosted database for the first production version:

- Managed PostgreSQL in a Canadian region
- S3-compatible object storage in the same Canadian region, with Canadian backups
- Managed KMS/HSM in a Canadian region, or a documented customer-managed key arrangement
- Small private API/worker service in the same Canadian region
- Private networking between API, database, object storage, and worker where available
- WAF/rate limiting and an allowlisted administrative path

The provider must explicitly document Canadian region availability. Do not infer residency from a company being Canadian or from a `.ca` domain.

## Minimal vault schema

```sql
create table vault_records (
  id uuid primary key,
  manuscript_estate_id varchar(64) not null,
  classification varchar(32) not null, -- highly_sensitive, restricted
  status varchar(24) not null default 'active',
  created_at timestamptz not null default now(),
  retention_until timestamptz,
  legal_hold boolean not null default false
);

create table vault_documents (
  id uuid primary key,
  vault_record_id uuid not null references vault_records(id),
  object_key varchar(512) not null unique,
  original_name varchar(255) not null,
  mime_type varchar(160) not null,
  byte_size bigint not null,
  sha256 char(64) not null,
  encryption_key_version varchar(120) not null,
  malware_status varchar(24) not null default 'pending',
  processing_status varchar(24) not null default 'not_requested',
  created_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table vault_audit_events (
  id bigserial primary key,
  vault_record_id uuid,
  document_id uuid,
  manuscript_user_id varchar(128) not null,
  action varchar(40) not null,
  result varchar(24) not null,
  request_id varchar(128) not null,
  created_at timestamptz not null default now(),
  metadata jsonb not null default '{}'
);

create index vault_records_estate_idx on vault_records(manuscript_estate_id);
create index vault_documents_record_idx on vault_documents(vault_record_id);
create index vault_audit_record_time_idx on vault_audit_events(vault_record_id, created_at desc);
```

Do not place raw SINs or document contents in `metadata`.

## Manus-side reference fields

Add only non-sensitive references to the Manus schema, for example:

```ts
export const sensitiveDocumentRefs = mysqlTable("sensitive_document_refs", {
  id: varchar("id", { length: 36 }).primaryKey(),
  estateId: varchar("estate_id", { length: 36 }).notNull(),
  vaultDocumentId: varchar("vault_document_id", { length: 120 }).notNull(),
  documentKind: varchar("document_kind", { length: 64 }).notNull(),
  displayName: varchar("display_name", { length: 255 }).notNull(),
  status: varchar("status", { length: 24 }).notNull(),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});
```

The `displayName` should be a safe label such as `Death certificate`, not a filename containing a SIN or unnecessary client information.

## Vault API contract

```ts
// POST /v1/uploads/initiate
// Manus sends only authorization context and safe metadata.
type InitiateUpload = {
  estateId: string;
  documentKind: "will" | "codicil" | "death_certificate" | "identity" | "bank_statement" | "court_document" | "other";
  fileName: string;
  mimeType: string;
  byteSize: number;
};

type UploadTicket = {
  vaultDocumentId: string;
  uploadUrl: string;       // expires in minutes, never persisted in Manus
  requiredHeaders: Record<string, string>;
};

// POST /v1/documents/:id/complete
// Called after direct browser upload; vault verifies checksum and scan result.

// GET /v1/documents/:id/access
// Returns a short-lived signed URL after Manus authorization is verified.

// POST /v1/documents/:id/process
// Requests processing only when the selected worker is approved for the classification.

// DELETE /v1/documents/:id
// Soft-delete or retention-controlled destruction; never immediate hard delete by default.
```

## Manus integration outline

```ts
// server/vaultClient.ts
export async function createVaultUpload(input: {
  userId: number;
  estateId: string;
  kind: SensitiveDocumentKind;
  fileName: string;
  mimeType: string;
  byteSize: number;
}) {
  const response = await fetch(`${VAULT_URL}/v1/uploads/initiate`, {
    method: "POST",
    headers: {
      "authorization": `Bearer ${VAULT_SERVICE_TOKEN}`,
      "content-type": "application/json",
      "x-request-id": crypto.randomUUID(),
    },
    body: JSON.stringify({
      estateId: input.estateId,
      documentKind: input.kind,
      fileName: safeDisplayName(input.fileName),
      mimeType: input.mimeType,
      byteSize: input.byteSize,
    }),
  });
  if (!response.ok) throw new Error("Canadian vault upload could not be initialized.");
  return response.json() as Promise<UploadTicket>;
}
```

The client then uploads directly to `uploadUrl`. The Manus server should not proxy the file unless the vault provider cannot support direct uploads.

## Form-generation options

### Phase 1 — metadata-only integration

Keep current Manus form generation unchanged. Sensitive files are stored in the vault and surfaced as status/links. This is the lowest-risk first step but forms cannot automatically read sensitive file contents.

### Phase 2 — Canadian document worker

For forms that need a sensitive document:

1. Manus creates a signed, scoped job request containing an estate ID, form code, and vault document IDs.
2. The Canadian worker fetches the document inside Canada.
3. The worker extracts only approved facts.
4. Facts are written to the vault or returned as a signed result.
5. Manus receives only the minimum structured facts needed for workflow or rendering.
6. The final sensitive document is generated and stored in the Canadian vault, or generation is performed entirely by the Canadian worker.

Do not send the raw document to Manus merely because it is convenient.

## Authentication and authorization

- Use Manus OAuth/session identity as the user-facing identity.
- Exchange a short-lived, audience-restricted token for vault access.
- Bind every vault request to `userId`, `estateId`, and permitted role.
- Re-check estate authorization in the vault API; never trust a client-supplied estate ID alone.
- Use separate service credentials for development, staging, and production.
- Rotate vault credentials and revoke compromised tokens.
- Require MFA for vault administration.
- Do not expose database ports publicly.
- Keep the API behind HTTPS, a WAF/reverse proxy, and rate limits.

## Migration plan

1. Inventory all current sensitive fields and storage keys.
2. Decide which data is highly sensitive and which may remain in Manus.
3. Select a provider with Canadian-region database, object storage, backups, KMS, subprocessors, and export guarantees.
4. Build the vault API and schema in a non-production Canadian environment.
5. Add Manus reference records without changing existing form behavior.
6. Migrate one document class, such as uploaded wills, with checksums and reconciliation counts.
7. Verify that no raw sensitive values appear in Manus logs, database rows, analytics, or error reports.
8. Add dual-read fallback only for migration; do not create permanent duplicate copies.
9. Migrate remaining documents and sensitive fields.
10. Rotate or delete legacy copies only after retention, legal hold, and backup implications are approved.
11. Run a security review, threat model, restore test, access review, and provider due diligence review.
12. Update privacy notices, client-retainer language, incident procedures, and data-retention policies.

## Sizing recommendation

### Do not use a Manus Cloud Computer for the residency vault

The available Manus Cloud Computer locations are US East, US West, East Asia, Southeast Asia, and West Europe; Canada is not listed. Therefore it should not be represented as a Canadian-resident vault.

### If the external provider offers managed Canadian services

Start with:

- Managed PostgreSQL: 2 vCPU, 4 GB RAM, 50–100 GB allocated storage
- Canadian object storage: start at 250 GB, with versioning and a separate Canadian backup policy
- API/worker: 2 vCPU, 4 GB RAM, 50 GB OS/container storage
- Redis/queue: optional; begin with a managed small queue or database-backed jobs
- CDN: do not cache private documents
- KMS: managed Canadian-region key service

This is enough for an early legal-practice deployment with low-to-moderate concurrent use. Object storage, not CPU, will usually become the first cost driver as documents accumulate.

### If forced to self-host the vault on one VM

Use a minimum of 4 vCPU, 8 GB RAM, 100 GB encrypted OS/database disk, plus separate encrypted document storage and tested off-server Canadian backups. Do not store the only copy of legal documents on that VM.

For production legal records, I prefer managed PostgreSQL plus managed Canadian object storage over a single VM because backups, failover, patching, and access controls are easier to evidence.

### Manus Cloud Computer reference tiers

The Manus VM tiers are 2 vCPU with 1 GB RAM/$10 Basic, 4 GB RAM/$30 Standard, or 8 GB RAM/$50 Advanced, but none is a Canada-region option. If used only for a non-sensitive development proxy or worker, Standard is the reasonable starting tier. It should not be purchased as the Canadian data-residency vault.

## Acceptance checklist

- [ ] Provider confirms Canadian region for database, object storage, backups, replicas, logs, and KMS.
- [ ] Provider supplies subprocessors, breach notification, support-access, deletion, and export terms.
- [ ] Raw SINs and sensitive document bytes are absent from Manus DB and logs.
- [ ] Direct browser upload and short-lived signed access work.
- [ ] Estate/user authorization is enforced in both Manus and the vault.
- [ ] Malware scanning and file-type/size validation are enforced before availability.
- [ ] Retention and legal-hold behavior is documented.
- [ ] Restore and disaster-recovery tests pass.
- [ ] Sensitive document processing is either Canadian-resident or explicitly disclosed as cross-border processing.
- [ ] Privacy notice, retainer language, incident plan, and client communications are reviewed by qualified Canadian privacy/legal counsel.
