# Single-Account Canadian Vault: Deployment Checklist and VPS Plan

**Status:** Architecture and procurement checklist — not implemented

**Audience:** ProbatePro as a platform for **individual lawyer accounts** and a planned **personal-executor account** path. This is technical and operational guidance, not a legal opinion or compliance certification. Customer terms, provider terms, privacy notice, and any data-processing agreement require qualified review before lawyer-client-record or personal-executor-estate-record claims are made.

## 1. The practical decision

A **Toronto 4 vCPU / 8 GB RAM / 120 GB NVMe VPS** is a reasonable starting point for a **synthetic-data development environment or tightly controlled pilot** of a sensitive-data vault. It is the minimum self-hosted configuration identified in the hybrid-vault blueprint.

It is **not** a complete production records-control solution on its own because one server is one failure domain and the supplied weekly backup is not proof of an independent, tested recovery arrangement.

The Law Society of BC Rules 10-3 and 10-4 do **not** require multiple VPSs, a particular cloud provider, a Canadian-only location, PostgreSQL, object storage, or a particular backup topology. The obligation is outcome-oriented: the lawyer needs custody/control, ownership, ability to produce records, security, a suitable storage-provider agreement, and reasonable protection against loss or unauthorized access.

> A second VPS is a resilience choice—not a rule requirement. For a single-account vault, buy **one Toronto 4 vCPU / 8 GB / 120 GB VPS only after** the independent backup and provider-terms questions below have a plan. Do not put real client or estate documents on it until the synthetic restore test succeeds.

## 2. Recommended first deployment

| Component | Start point | Boundary |
|---|---|---|
| Vault API, PostgreSQL metadata, and private object storage | One Toronto VPS: **4 vCPU / 8 GB / 120 GB NVMe** | Pilot/small production only; keep the database, object store, and services private behind the API. |
| Operating system | **Ubuntu Server 24.04 LTS**, not AlmaLinux 8 for a new setup | Use an LTS release with supported security updates. |
| External backup | Separate Canadian provider/account, encrypted, sized for all documents + database + growth | Required before real client records; do not rely only on the same VPS or same provider login. |
| Local provider backup | Enable daily backup if the provider offers it | Useful recovery layer, not the only recovery copy. |
| Production documents | Separate encrypted storage volume or S3-compatible object storage | Do not let application logs, Docker volumes, or database backups become untracked document copies. |

### Capacity expectations

A 120 GB volume is enough to begin with operating system, database metadata, scan staging, and a modest document volume. Document storage—not CPU—will be the first capacity constraint. Alert at **70% storage use**, leave working room for upload/scan/restore, and expand before a full disk can corrupt a recovery path.

For higher volume, add a **separate encrypted object-storage service/volume** before adding a second compute VPS. Add a separate recovery/replica VPS only when the documented recovery objective requires it or an outage review shows that one server is insufficient.

## 3. Single-account authorization model

A vault request must bind to the authenticated account and the existing estate ID:

```ts
type VaultAccessClaims = {
  issuer: "probatepro";
  audience: "probatepro-canadian-vault";
  subject: string; // authenticated ProbatePro account ID, no email
  accountPurpose: "lawyer" | "personal_executor";
  estateId: string;
  scope: Array<"upload:initiate" | "upload:complete" | "document:read" | "document:delete">;
  jti: string;
  exp: number; // 5–10 minutes
};
```

There is no `firmId` in this model. The server derives the account from the authenticated session; neither the browser nor a stored object key can select another account’s data. `accountPurpose` selects product policy and copy only; it is not proof of executor appointment or legal authority.

Each vault record must hold:

```text
accountId        — authenticated ProbatePro account ID
accountPurpose   — lawyer or personal_executor; not legal authority
estateId         — opaque ProbatePro estate ID
vaultObjectId    — random UUID; never a client name, SIN, filename, or email
```

## 4. Data flow requirements

### Upload

- [ ] ProbatePro authenticates the account and confirms `assertEstateOwned(estateId, userId)`.
- [ ] Manus sends only a short-lived scoped upload request to the vault; it does not proxy sensitive bytes.
- [ ] The browser uploads directly to a quarantined vault location over HTTPS.
- [ ] The vault checks MIME type, size, checksum, and malware scan before activation.
- [ ] Manus stores only an opaque vault document ID and safe label—not the raw bytes, signed URL, SIN, raw filename, or extracted document text.
- [ ] The vault audit entry records opaque IDs, action, result, request ID, and time only.

### View/download

- [ ] Both ProbatePro and the vault independently verify the account and estate relationship.
- [ ] Access returns a one-document URL/token valid for minutes, with `Cache-Control: no-store`.
- [ ] Access is denied when the manifest/reference is missing, mismatched, retained under an unapproved hold, or being destroyed.
- [ ] Logs never include content, names, addresses, SINs, signed URLs, tokens, headers, or passwords.

### Deletion and retention

- [ ] A UI delete is a retention-aware request, not automatic physical destruction.
- [ ] Legal hold and retention are evaluated before destruction is scheduled.
- [ ] Soft deletion makes the document unavailable immediately where approved.
- [ ] Permanent destruction has provider verification and separate backup-expiry handling.
- [ ] Account closure does not silently erase estate/law-practice files.

## 5. Base hardening checklist

### Network and host

- [ ] Expose only HTTPS `443` publicly.
- [ ] Use a default-deny host and provider firewall.
- [ ] Restrict SSH to a VPN/allowlist and SSH keys; disable password login and root login.
- [ ] Do not expose PostgreSQL, object-storage management, Docker, Redis, or monitoring administration to the public internet.
- [ ] Run services as non-root; apply security updates with a documented maintenance window.
- [ ] Use separate development, staging, and production credentials. Never use real client records in development.

### Encryption and secrets

- [ ] Enforce TLS for browser → vault API and internal service paths.
- [ ] Encrypt backup archives and document storage at rest.
- [ ] Keep application secrets, backup credentials, and database credentials out of git, screenshots, shell history, and logs.
- [ ] Keep recovery-key instructions separate from the production server.
- [ ] Rotate credentials after suspected compromise and on a documented schedule.

### Monitoring and recovery

- [ ] Alert on disk space, failed backups, restore failures, TLS expiry, malware-scan failure, abnormal authorization denials, and upload failures.
- [ ] Keep daily encrypted database/object backups plus an independent Canadian backup copy.
- [ ] Perform a synthetic restore before client data is accepted, then at least quarterly and after material architecture changes.
- [ ] Record actual recovery duration, recovered-data point, checksum verification, and cross-account authorization checks.

## 6. Provider and contract questions to answer in writing

Before asserting any residency or using the vault for live client records, receive written answers for:

1. Primary VM location and data-centre jurisdiction.
2. Backup, snapshot, log, monitoring, and support-access locations.
3. Subprocessors and changes to them.
4. Encryption, support access, incident notification, and account security.
5. Export on request and on service termination.
6. Deletion/destruction instructions and evidence.
7. Provider terms that let the lawyer retain ownership, custody/control, and production ability.

A Canadian VPS address does not, by itself, prove that all backups, logs, support access, or processing remain in Canada.

## 7. Start sequence

1. **Record the single-account product boundary.** Use `docs/architecture/rule-10-conformance-baseline.md`, keep the lawyer Rule 10 analysis distinct from personal-executor use, and do not make unverified claims.
2. **Finish the existing-control proof.** Add/strengthen cross-account ownership, storage-manifest, disposition, and export tests.
3. **Choose and document the provider.** Get its written location, backup, support, export, deletion, and subprocessor answers.
4. **Provision with synthetic data only.** Set up Ubuntu LTS, private services, firewall, TLS, backup, monitoring, and an incident runbook.
5. **Perform a recovery test.** Restore synthetic files and check hashes, authorization, and export before accepting real documents.
6. **Have counsel review the terms.** Review provider terms plus the lawyer-facing terms/privacy/retainer wording.
7. **Implement the vault reference integration.** Move one non-form-critical document class first; maintain checksums and documented legacy-copy destruction.
8. **Migrate deliberately.** No permanent duplicate copies and no destructive move without an approved retention/legal-hold and rollback plan.

## 8. Claims prohibited until verified

Do not claim:

- “All ProbatePro data is stored in Canada.”
- “All backups, logs, and support access remain in Canada.”
- “Canadian-resident by design.”
- “Law Society compliant.”
- “End-to-end encrypted” or “zero-access provider” unless the actual operating/recovery design proves it.

Accurate interim wording is:

> “ProbatePro is implementing a segregated Canadian-hosted vault for selected highly sensitive records. Availability, regions, subprocessors, and controls are documented in the applicable service agreement.”

## 9. References

- [Law Society of BC Rules 10-3 and 10-4](https://www.lawsociety.bc.ca/support-and-resources-for-lawyers/act-rules-and-code/law-society-rules/part-10-%E2%80%93-general/)
- [Law Society of BC cloud computing guidance](https://www.lawsociety.bc.ca/getContentAsset/a6d7dfd6-0cd5-480a-b9c5-3fb942cc4c7b/dfc3d011-8f63-43f6-9ed8-4b444333a1d0/guidelines-cloud?language=en-CA)
- [Law Society of BC cloud computing checklist](https://www.lawsociety.bc.ca/Website/media/Shared/docs/practice/resources/checklist-cloud.pdf)
- [Individual-lawyer Rule 10 baseline](./rule-10-conformance-baseline.md)
- [Staged implementation plan](../superpowers/plans/2026-10-03-rule-10-records-control.md)
