# Personal executor registration and Full Intake handoff

**Status:** Implementation specification and UI copy. Account purpose describes the intended workflow, not proof of appointment or legal authority. No changes to official forms, document facts, or legal Terms/Privacy wording are authorized by this document.

## Screen 1 — Account purpose (first sign-in, after existing Terms gate)

**Heading:** How will you use ProbatePro?

**Description:** Choose the workspace that fits you. You can still change your Intake view later.

| Choice | Supporting copy | Initial Intake view |
|---|---|---|
| Lawyer | I prepare estate files as a legal professional. | Form-focused; Full Intake remains available in the sidebar. |
| Personal executor | I am organizing an estate in a personal capacity. | Full Intake, with the app’s form-guidance sections visible. |

**Help icon:** “This choice tailors your starting view; it does not confirm your appointment as an executor or change who may access an estate file.”

A clear selection indicator and radio-group keyboard behaviour prevent an ambiguous answer. Existing users who already completed a firm profile are not sent through this screen again.

## Screen 2 — Profile details

**Lawyer path:** Preserve the existing lawyer name (pre-filled from the signed-in profile), firm name (required), address, phone, fax and email (pre-filled from the signed-in profile). Maintain the existing letterhead and professional Settings workflow.

**Personal executor path:** Show “Your name” and “Email” as read-only values from the signed-in profile. These are not copied into professional settings or estate contacts; where an identity value is unavailable, its placeholder says so and does not block account setup. Do not show or require firm name, firm address, firm phone/fax or lawyer labels. Collect no SIN or estate details in this screen. Save `accountPurpose=personal_executor` and `formFocusedIntake=false` together. The existing form generator must not infer an applicant, a lawyer, or an executor contact from this choice.

**Primary action:** Continue to your workspace. On save error, keep the entered values and offer a visible retry.

## Screen 3 — Welcome and first estate

**Heading:** Welcome to ProbatePro, {first name}.

**Body:** “Start by opening an estate file. You can then work through Full Intake at your own pace. The answers you record help organize the file and identify relevant forms; you can review and change them as you go.”

**Note:** “Choosing a personal workspace does not establish that you have been appointed as an executor. Record the appropriate people and roles in the estate file.”

**Primary action:** Start an estate file. **Secondary action:** Go to dashboard. On the first empty dashboard, the primary action opens the existing **Create New Estate File** dialog (without creating an estate automatically). After successful creation, navigate to `/estate/{id}?tab=intake` and show Full Intake. Closing the dialog leaves the empty dashboard intact and keeps an obvious “Start Full Intake” call to action. If the account already has estate files, do not auto-open a creation dialog.

## UI mockup anatomy

The live first-sign-in surface should use the existing ProbatePro navy/ink design: a centered responsive card, compact heading, two equal-height selectable purpose cards with visible selection/focus states, restrained supporting text, and a single primary continue action. On mobile the cards stack in one column; labels remain fully readable and keyboard/touch targets remain usable. No decorative gradients or borrowed image assets are needed. An implementation screenshot can be supplied after the UI is rendered with synthetic data.

## Acceptance and limits

- Persist account purpose per authenticated account; default unselected for accounts without a completed profile. Preserve completed existing firm profiles without asserting an unverified professional qualification or changing their stored data.
- No automatic estate creation, role assignment, or inference of legal appointment.
- Personal executors enter Full Intake even if stale browser cache previously selected form-focused mode; the user can switch later.
- Lawyer onboarding and existing lawyer settings remain functional. Account-purpose changes never transfer files between users.
- Use synthetic tests, TypeScript, full serial Vitest, build and a reviewed migration before checkpointing.
