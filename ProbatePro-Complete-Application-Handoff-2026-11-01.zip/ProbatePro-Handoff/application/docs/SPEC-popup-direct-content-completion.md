# Direct document-content popup completion specification

## Objective

When a pre-generation popup identifies a missing fact that directly fills visible content in the selected court form, it must offer an honest control in that same popup instead of sending the user to **Forms** or **Contacts**. The control must write the fact to its authoritative owner or carry it as a per-generation parameter, then re-check before preview, download, or generation.

## Product rule

> A popup may ask only for a fact that fills visible generated content, selects a visible official alternative, or is a direct render parameter for that document. It must not collect operational, readiness, source-document, attachment, or historical evidence merely because it affects filing workflow.

## Preservation constraints

- Preserve every official court-form word, paragraph/run geometry, indentation, page behavior, signature/jurat layout, and selected-only checkbox/alternative behavior.
- Maintain DOCX and preview parity for every affected form.
- Never infer, default, or invent a deponent, applicant, demandant, delivery, recipient, address, postal code, occupation, signing date, representative, PGT status, electronic acknowledgement, or P46 result.
- A pending signature date is a per-generation fact; never silently replace it with today, an estate date, or a default-signature date.
- Contact, delivery, distribution, and applicant facts must use their existing canonical record and re-check after a successful write. Do not use document-only overrides for canonical facts.
- Package/bulk paths retain their canonical-data requirements; a single-form popup must not collect values that package generation would discard.

## Scope by form

| Form | Direct popup completion required | Authoritative owner |
| --- | --- | --- |
| P9 | Actual delivery recipient/method/date, electronic acknowledgement, linked PGT delivery, represented-recipient facts, and P46 demand outcome when the corresponding row directly controls P9 text | Delivery rows and linked Contacts; existing P46 tracking on delivery |
| P10 | Applying deponent selection, signing date, and unresolved distribution facts | Pending render context for deponent/date; canonical Contacts/Estate distribution data |
| P11 | Applying deponent selection, selected deponent postal code, signing date, jurat city | Pending render context for deponent/date; Contact and Estate respectively |
| P16 | Signing date and selected factual deponent’s printed name/address/postal code/occupation or organizational signatory fields | Pending render context for date; selected Contact |
| P44 | Signing date and missing canonical applying applicant; individual lawyer name only where the lawyer path is selected and no actual individual name resolves | Pending date/render data; canonical Contact; lawyer name must never be inferred from firm name |
| P45 | Signing date and selected factual deponent’s printed name/address/postal code/occupation | Pending render context for date; selected Contact or the existing Settings source when that sentinel is selected |
| P46 | Selected actual P1-notice-recipient delivery, its reviewed/corrected recipient name and address, and actual signing date | Pending delivery id/date; canonical Delivery row |

## Explicit exclusions

The following remain outside this repair: uploaded-copy availability, sealed-order evidence, P1 Exhibit A retention, dispensation order documents, foreign-grant/will attachments, generic readiness, applicability, and workflow-only electronic-will repository facts. They may remain as honest warnings or established workflow actions, but must not be turned into fictitious popup content controls.

## Acceptance criteria

1. For every scoped direct-content gap, the popup shows a fitting input/select/checkbox/editor and does **not** show a standalone Go to Forms/Contacts control for that gap.
2. Applying a canonical fact waits for its save, keeps data available for retry on failure, invalidates/reloads the relevant data, and re-runs preflight.
3. Applying a per-generation fact returns it to the same pending action used by preflight, preview, download, generation, and document snapshots.
4. DOCX and preview show the identical selected facts and preserve all existing official alternatives/layout.
5. A blank or unknown fact remains blank/unfinished; no control silently creates a legal fact merely to clear a warning.
6. Focused regressions, TypeScript, full serial tests, production build, and whitespace checks must pass before checkpointing.
