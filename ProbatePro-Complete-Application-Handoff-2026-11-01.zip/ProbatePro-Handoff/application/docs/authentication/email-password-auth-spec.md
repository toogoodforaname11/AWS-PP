# Email and Password Authentication Specification

**Status:** Dormant implementation. ProbatePro remains **OAuth-only** until the Resend domain is verified, a least-privilege sending key is configured, and direct authentication is explicitly enabled for production.

## Objective

Allow a person to create and sign in to a ProbatePro account using a verified email address and a strong password, while preserving the existing OAuth option and the existing user/estate ownership model.

The Settings **Password and sign-in** area must allow a signed-in user to set or reset their ProbatePro password by email. Existing OAuth users can attach a verified password without creating a second account.

## Account Model

- One `users` row remains the source of account ownership for estates, settings, storage objects, and audit records.
- Local credentials attach to that existing row; they do **not** create a second estate owner.
- OAuth stays available as an alternate sign-in path.
- New email/password users receive a local-only, opaque `openId`; it is never an email address.
- Email addresses are normalized for lookup but are never placed in session tokens, URLs, logs, user-facing error details, or audit metadata.

## User Flows

| Flow | Result |
|---|---|
| Create account | Collect name, email, and a strong password; store only an Argon2id hash; send a one-time verification link; do not create a session until verification succeeds. |
| Verify email | Consume a short-lived, single-use token; mark the existing row verified; issue the normal ProbatePro session cookie; enter the existing Terms gate and first-run workflow. |
| Password sign-in | Accept email and password; apply a strict endpoint rate limit; return a generic error for invalid or unverified credentials; issue the same session cookie used by OAuth. |
| Forgot password | Always return the same confirmation response; when a verified credential account exists, issue a single-use reset link by email. |
| Reset password | Validate password policy, atomically consume the token, write a new Argon2id hash, revoke existing sessions, then issue one fresh session. |
| Existing OAuth account | In Settings, send a password-set/reset link to the verified OAuth email; the existing account, estate ownership, and settings remain unchanged. |

## Security Contract

- **Password policy:** 14–128 characters; reject the user email, common/breached password deny-list entries, and passwords with no lower-case, upper-case, digit, and symbol character classes.
- **Hashing:** `@node-rs/argon2` Argon2id, memory-hard parameters held in one server-only module.
- **Verification and reset tokens:** 32-byte random values; only SHA-256 digests stored; 30-minute expiry; single use; reset issuance invalidates earlier active reset tokens for the same user.
- **Sessions:** existing signed, `HttpOnly`, `Secure` (HTTPS), `SameSite=None` production session cookie. Password reset increments `sessionVersion` and invalidates prior sessions.
- **Anti-enumeration:** registration, sign-in, forgot-password, verification and reset errors do not disclose whether an email exists.
- **Rate limiting:** separate limits for sign-in and email-token issuance; the general API limiter remains in place.
- **Audit:** registration, verified email, successful/failed password sign-in, verification request/consume, reset request/consume, and invalid token actions are recorded without raw email, password, or token values.
- **No secrets in source:** Resend key is a project secret (`RESEND_API_KEY`), never a source constant or browser environment value.

## API and UI Contract

When explicitly enabled, public JSON endpoints (Express, mounted before the SPA fallback):

- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/request-password-reset`
- `POST /api/auth/verify-email`
- `POST /api/auth/reset-password`
- `POST /api/auth/request-password-setup` (authenticated Settings action)

When explicitly enabled, public screens:

- `/auth` — sign in, registration, and password-recovery entry surface
- `/auth/verify?token=…` — single-use verification completion
- `/auth/reset?token=…` — new password entry

The landing page and Settings page remain OAuth-only while the feature is dormant: they contain **no** email/password account, reset, or verification action. The dormant routes are mounted only when the server receives `EMAIL_PASSWORD_AUTH_ENABLED=true`; this flag is intentionally unset in the current environment. After the external email gate is complete, expose the account and recovery controls in a separate launch change and then enable the flag.

## Data Model

Additive schema only:

- `users.passwordHash` nullable
- `users.emailVerifiedAt` nullable
- `users.emailNormalized` nullable, unique when present
- `users.passwordSetAt` nullable
- `email_auth_tokens` table: opaque id, user id, purpose, token digest, expiry, consumed time, requested time

No passwords, raw reset tokens, or raw verification tokens are persisted in plaintext.

## Production Email Gate

The configured Resend domain `probate-pro.com` is present but **not verified** as of 2026-10-07. Add these DNS records at the authoritative provider, then trigger verification in Resend:

| Type | Host/name | Value | Priority | TTL |
|---|---|---|---:|---|
| TXT | `resend._domainkey` | `p=MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDBYneTQ6OFn15qWB2C+KYlLPbhrLAJ+Ay9rppLvBN5teq1ltYaqA+k8eNhU5STOOqEOg8MpJFSjiAT2EYrzNOFERc6JXBQDI2ouWLvfIJ9mOkdoGi07goQhmvE7uK1oztx08JgObW1fE96t+eur+pWCZhcCEmQk+C9o1AT9D1hoQIDAQAB` | — | Auto |
| MX | `mail` | `feedback-smtp.us-east-1.amazonses.com` | 10 | Auto |
| TXT | `mail` | `v=spf1 include:amazonses.com ~all` | — | Auto |
| CNAME | `rmail` | `send.forge.rmta.net` | — | Auto |

Before production testing, configure a least-privilege Resend sending key as `RESEND_API_KEY` in project secrets. Do not enable direct password registration in production until the domain, secret, and an explicit reviewed `EMAIL_PASSWORD_AUTH_ENABLED=true` configuration are all available.

## Verification

```bash
pnpm check
pnpm vitest run server/emailPasswordAuth.test.ts client/src/pages/Landing.auth.test.tsx client/src/pages/Settings.test.tsx --maxWorkers=1
pnpm test -- --maxWorkers=1
pnpm build
git diff --check
```

## Boundaries

- Never alter estate ownership, generated court document wording/layout, or an existing OAuth account merely because an email/password account is added.
- Never send a real transactional email during automated tests.
- Never log, return, display, store, or serialize plaintext passwords or raw tokens.
- Do not claim production password email delivery is available before Resend domain verification and server-secret configuration are confirmed.
