# Storage and Sensitive-Vault Incident Runbook

**Status:** Pre-go-live operational runbook. Complete the owners, provider contact route, and tabletop record before accepting live sensitive vault data.

**Scope:** Current ProbatePro record storage and the future optional sensitive vault. This runbook governs suspected unauthorized access, loss of control, provider outage, failed backup/restore/destruction, and credential compromise. It is not legal advice; involve qualified counsel where required.

> **Safety rule:** Preserve evidence and contain access first. Do not paste document contents, names, addresses, SINs, signed URLs, access tokens, credentials, or raw request bodies into logs, tickets, chat, or screenshots.

## 1. Roles and contacts

| Role | Name/contact | Backup | Responsibilities |
|---|---|---|---|
| Incident lead | _Pending_ | _Pending_ | Coordinates containment, timeline, decisions, and updates |
| Technical owner | _Pending_ | _Pending_ | Access changes, provider case, backups/restores, evidence collection |
| Privacy/counsel contact | _Pending_ | _Pending_ | Notification/legal-hold assessment and external advice |
| Lawyer/platform owner | _Pending_ | _Pending_ | Record-control decision and affected-account communication |
| Provider emergency support | _Pending_ | _Pending_ | Provider evidence, containment, service restoration |
| Insurer contact | _Pending_ | _Pending_ | Coverage notification if applicable |

## 2. Classify and escalate

| Situation | Initial severity | First response | Escalate immediately to |
|---|---|---|---|
| Suspected exposure of client document, SIN, credentials, or cross-account data | Critical | Revoke/contain access; preserve evidence; do not delete evidence | Incident lead, counsel/privacy contact, service owner, insurer as applicable |
| Confirmed cross-account authorization bypass | Critical | Disable affected access path; preserve request/provider evidence | Incident lead, counsel/privacy contact, technical owner |
| Provider reports compromise or loss of control | Critical | Open provider incident; assess data scope; freeze destructive jobs if needed | Incident lead, counsel/privacy contact, service owner |
| Backup failed or restore cannot meet target | High | Verify most recent good recovery point; stop sensitive-vault onboarding | Technical owner, service owner |
| Storage provider outage / inaccessible documents | High | Check provider status and authentication; do not retry destructively | Technical owner, provider support |
| Deletion fails or an object remains accessible after authorized destruction | High | Revoke access path; preserve manifest/provider evidence; retry through verified lifecycle | Technical owner, counsel/privacy contact if exposure is possible |
| Single upload/download failure with no exposure indication | Medium | Gather safe error code/request ID; retry only if idempotent | Technical owner |

**Escalation principle:** Any credible sensitive-data exposure, credential compromise, loss of access control, or conflicting jurisdiction/provider evidence requires prompt qualified privacy/professional-responsibility assessment. Do not decide notification obligations from this runbook alone.

## 3. Immediate response sequence

### A. Contain (first 15 minutes)

1. Create an incident ID and record the time, reporter, systems, and only safe identifiers.
2. Stop the affected route or feature if access control cannot be trusted. Prefer a narrow disablement over broad destructive action.
3. Revoke suspected user sessions, vault API credentials, presigned-token issuers, and provider access keys as appropriate; rotate compromised secrets.
4. Freeze automatic destructive jobs for the affected scope if they could erase evidence or complicate recovery.
5. Open a priority provider case and request preservation of relevant audit evidence where needed.
6. Preserve the manifest state, access/audit logs, deployment revision, and safe request IDs. Do not alter or delete suspected evidence.

### B. Assess (next 60 minutes)

1. Identify which lawyer account, estate IDs, object categories, and time window are affected using opaque IDs only.
2. Determine whether the event is **suspected**, **confirmed**, or **contained**; separate facts from hypotheses.
3. Confirm whether provider, backup, support, or log locations and subprocessors affect the event.
4. Check whether any export/download URL, scoped token, or credential could be active; expire/revoke where supported. See §4.2, implemented-state addendum.
5. Check current backup/restore viability with a non-destructive read-only verification; do not restore over production.
6. Consult counsel/privacy contact on notification, regulator, insurer, or affected-lawyer communication.

### C. Recover and verify

1. Apply the smallest safe remediation: corrected authorization condition, provider access restriction, credential rotation, or service rollback.
2. Test with synthetic accounts that the owner can access only their own records and the non-owner receives the same non-enumerating denial as an absent record.
3. Verify provider-object state against the manifest; do not activate unowned, mismatched, or deleted objects.
4. If recovery is necessary, use the [synthetic restore procedure](../operations/restore-test-record.md) principles and restore to a segregated environment first.
5. Re-enable features only when the incident lead and technical owner agree the verification evidence supports it.

## 4. Situation playbooks

### 4.1 Suspected unauthorized document access

- Disable the affected download/export/vault-token route or narrow it to unaffected accounts.
- Rotate issuer credentials and revoke current short-lived grants where possible.
- Preserve manifest row, account/estate opaque IDs, safe request IDs, provider audit evidence, and deployment revision.
- Validate cross-account denial with synthetic fixtures after the fix.
- Escalate to counsel/privacy contact before sending any external notice.

### 4.2 Credential or token compromise

- Revoke/rotate the exact credential scope first; do not print it to validate its value.
- Invalidate sessions or change issuer secrets if token integrity may be compromised.
- Audit provider access history using safe identifiers and time window.
- Create new credentials using a separate operator and update the controlled secret store only.
- Record the rotation time and affected scopes, never the secret itself.

**What can be expired or revoked (implemented state, 2026-10-27):**

- A presigned storage GET URL is requested for at most 900 s (default 300 s; `server/storageProvider.ts:40-42, 566-569`). The application has no per-URL revocation; whether AWS honours a URL after signing-credential rotation or a bucket-policy deny is platform behaviour, unproven here.
- A form-delivery binding expires 10 minutes after its signed issue timestamp, with a separate 60 s future-skew refusal that adds no lifetime, checked once at admission (`server/formDeliveryBinding.ts:30-31, 113-114`; `server/downloadRoute.ts:180-186`). Row replacement or archive by a later generation and a changed render digest refuse subsequent requests that observe them (`server/downloadRoute.ts:288-299, 313, 345`) and revoke nothing already admitted. Changing the session secret, `GENERATOR_RELEASE` or the build fingerprint invalidates bindings only in serving processes that have loaded the new value, so old workers keep verifying old bindings until restarted (`server/formDeliveryBinding.ts:55-58`; `server/formDeliveryArtifact.ts:57-61`). This describes behaviour and prescribes no containment step: regenerating documents or editing database rows is not a procedure.
- The Bearer fallback token is a server session token; this addendum documents no server-side revocation procedure (none is cited in code), and any such revocation would not clear a tab's stored token by itself: a tab's own session generation changes only on its own logout (`client/src/_core/hooks/useAuth.ts:48`) or account deletion (`client/src/pages/Settings.tsx:371`), the two non-test callers of `clearFallbackSession` (`client/src/lib/fallbackSession.ts:38-46`).
- The delivery trace (the acknowledged-before-send `*_delivery_started` row; finished and aborted events best-effort), generated-byte non-retention and the fact that delivery descriptors carry no token are described in `references/file-storage.md` sections 6 and 10 to 15.

### 4.3 Provider outage or inaccessible records

- Verify provider status, DNS/TLS, and authorized account status.
- Check the latest backup completion and last successful synthetic restore record.
- Do not delete/re-upload documents as an outage workaround.
- If RTO is exceeded, notify the service owner and follow the agreed communication path.
- Restore only to a segregated environment unless a formal recovery decision is made.

### 4.4 Backup, restore, or checksum failure

- Stop onboarding of new sensitive records until a good recovery point is confirmed.
- Preserve the failing backup identifier, safe error code, and timestamps.
- Test the most recent prior backup in isolation.
- Open a provider case and update the due-diligence/recovery record.
- Require a successful retest and owner approval before clearing the incident.

### 4.5 Failed destruction or unexpected post-delete access

- Remove access immediately through the manifest/authorization layer where approved.
- Preserve provider and manifest state; do not assume a UI delete completed physical destruction.
- Retry only through the verified lifecycle/outbox process and capture provider verification evidence.
- Determine backup expiry and legal-hold/retention consequences with the responsible lawyer and counsel.

## 5. Evidence and communications

### Minimum incident timeline

| Time | Action | Safe identifiers | Owner | Evidence location |
|---|---|---|---|---|
| _Pending_ | Detection | Incident ID; opaque account/estate/object IDs | _Pending_ | _Pending_ |
| _Pending_ | Containment | Safe request/deployment/provider case IDs | _Pending_ | _Pending_ |
| _Pending_ | Assessment | Scope/count only; no content or names | _Pending_ | _Pending_ |
| _Pending_ | Recovery | Verification result | _Pending_ | _Pending_ |
| _Pending_ | Closure | Approval and follow-up review | _Pending_ | _Pending_ |

### Communication rules

- Use verified facts only; label uncertainty explicitly.
- Do not make legal, residency, or notification conclusions without qualified review.
- Do not include client content or credentials in status updates.
- Preserve legal-hold, retention, and evidence requirements before deletion or broad remediation.
- Record all provider support cases, but keep raw provider logs in the restricted operational system.

## 6. Closure checklist

- [ ] Containment was completed and all affected credentials/tokens were reviewed or rotated.
- [ ] Manifest/provider consistency and cross-account denial were verified with synthetic tests.
- [ ] Backup/recovery status is documented; required restore test completed.
- [ ] Counsel/privacy and insurer decisions are recorded where applicable.
- [ ] Affected-lawyer communication decision is recorded by the responsible owner.
- [ ] Root cause, remediation, and residual risk are documented without sensitive payloads.
- [ ] This runbook, alerting, tests, and provider due-diligence record are updated for lessons learned.
- [ ] Service owner approves return to normal operation.

## 7. Related records

- [Storage provider due-diligence record](../operations/storage-provider-due-diligence.md)
- [Synthetic restore test record](../operations/restore-test-record.md)
- [Rule 10 conformance baseline](../architecture/rule-10-conformance-baseline.md)
- [Individual lawyer Canadian vault checklist](../architecture/individual-lawyer-canadian-vault-checklist.md)
