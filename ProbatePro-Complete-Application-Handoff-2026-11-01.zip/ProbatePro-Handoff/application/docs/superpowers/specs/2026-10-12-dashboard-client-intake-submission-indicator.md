# Dashboard Client Intake Submission Indicator

## Goal

On the Estate Files dashboard, clearly identify an estate when a client has submitted a portal intake while that estate currently has case-specific intake questions configured.

## User experience

- Show a compact, professional status control in the existing estate-row indicator area.
- Use the exact visible label **Client intake received** with a document/check icon — never a coloured dot, badge count, client name, email address, answer, or answer preview.
- The status is actionable: selecting it opens the current estate’s **Client Portal** tab, where the lawyer can review the existing submission.
- Show it only while a custom-question configuration exists and at least one client intake submission remains in the `submitted` review state. An approved or revision-requested submission is not presented as awaiting review.
- Preserve the current estate-row click, progress, status menu, document indicators, responsive wrapping, keyboard navigation, and no-data behaviour.

## Data and authorization boundary

- Add a protected no-input summary procedure. It obtains estate IDs only through `db.listEstates(ctx.user.id)` and aggregates submission status only for that owned ID set.
- Return per-estate booleans only: whether case-specific questions are currently configured and whether a submission is pending lawyer review. Do not return submission IDs, timestamps, client identity, custom prompts, or answers.
- Do not change portal submission, lawyer review/apply logic, estate facts, form generation, documents, notifications, or database schema.

## Acceptance checks

1. An owned estate with configured questions and a `submitted` intake renders **Client intake received** and routes to `?tab=client-portal`.
2. A submission without configured custom questions, or one that is no longer in the `submitted` state, does not render the status control.
3. The protected procedure never queries submissions outside the caller’s owned estate ID list and returns no client-facing submission content.
4. Existing dashboard rendering and client-intake workflows retain their current behaviour.
