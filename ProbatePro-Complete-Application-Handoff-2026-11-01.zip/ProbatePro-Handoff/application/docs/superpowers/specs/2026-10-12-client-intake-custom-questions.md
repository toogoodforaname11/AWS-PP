# Spec: Estate-Specific Client Intake Questions

## Objective

Allow a lawyer to add, edit, reorder and remove case-specific free-text questions from the **Client Portal** tab before issuing an estate’s secure intake link. The client sees those questions in that estate’s portal intake, answers any marked required, and sends the answers with the rest of the intake. Each submission retains the exact prompt, required setting and answer that were presented. Lawyers can read the answers in the existing review record, but custom answers do not automatically change Intake, Contacts, Inventory, form generation, readiness, notices or court documents.

## Assumptions and product decisions

- A custom question is a plain-text, free-text prompt; no multiple-choice, attachment, legal classification or conditional logic is introduced.
- There is a maximum of 20 questions, each 500 characters, with optional answer guidance of up to 500 characters. Client answers are limited to 4,000 characters per question.
- A lawyer may mark a question **Required**. Required only means the portal client must answer before sending that submission; it does not create a legal or filing requirement.
- Configuration is estate-specific, stored separately from individual access links, and may be updated later. Submitted payloads retain their own immutable question snapshots so later edits/deletions do not rewrite history.
- Existing submissions without custom-question fields remain valid and readable. Existing estate records receive an empty question set.

## Commands

```bash
pnpm exec vitest run client/src/components/ClientIntakeQuestions.test.tsx client/src/components/ClientIntakeForm.test.tsx server/routers.client-intake.test.ts server/clientIntakeMapping.test.ts --maxWorkers=1
pnpm check
pnpm test -- --maxWorkers=1
pnpm build
pnpm db:generate
pnpm db:migrate
pnpm db:check
```

## Project structure

- `shared/clientIntake.ts` — validates configured questions and submission snapshots.
- `drizzle/schema.ts` and `drizzle/migrations/` — persist a bounded estate-level JSON question set.
- `server/db.ts` and `server/routers.ts` — owner-only configuration read/write and portal-only configuration read; protect the estate/access boundary.
- `client/src/components/ClientIntakeQuestions.tsx` — lawyer configuration surface inside the estate Client Portal tab.
- `client/src/components/ClientIntakeForm.tsx` — renders and validates the submitted custom question snapshots.
- `client/src/components/ClientIntakeReview.tsx` — displays answers as review-only context.
- Focused Vitest suites — verify UI, validation, ownership and backward compatibility.

## Code style

Use existing React, tRPC and Zod conventions. Keep field IDs stable and generated client-side only during unsaved editing; persisted question IDs must be opaque safe identifiers. Prefer labelled native textareas, visible required indicators, `aria-live` status messages and existing Button/Card/Input/Checkbox components.

```ts
const customQuestionSchema = z.object({
  id: z.string().regex(/^cq_[A-Za-z0-9_-]{8,64}$/),
  prompt: z.string().trim().min(1).max(500),
  helpText: z.string().trim().max(500).default(""),
  required: z.boolean().default(false),
});
```

## Testing strategy

- Unit-test schema parsing, duplicate/limit rejection, blank required-answer rejection and legacy payload acceptance.
- Component-test lawyer add/edit/remove/reorder/save states and client labelled required fields.
- Router-test estate ownership, portal-only configuration delivery, submitted snapshot integrity and payload-size protection.
- Browser-test a fictional estate configuration, custom question rendering, required-answer feedback and submission/review visibility without accessing real records.
- Run full serial application suite, production build, migration and schema checks before checkpointing.

## Boundaries

- **Always:** assert estate ownership for lawyer configuration; scope portal reads to the authenticated portal session; preserve question snapshots in submissions; retain visible labels and keyboard control.
- **Ask first:** additional response types, uploads/attachments, client-visible automation, notifying lawyers, or applying custom answers to estate data.
- **Never:** expose portal access tokens, auto-apply custom answers, infer legal facts, touch court-form wording/layout, add client data from test fixtures, or access real client records to test the feature.

## Success criteria

1. A lawyer can configure a clean, estate-specific set of free-text questions in the Client Portal tab before creating/sending a link.
2. A client with a valid portal session sees the configured questions, sees required status, and cannot submit an unanswered required question.
3. The submitted payload preserves question prompt/help/required/answer snapshots even when configuration later changes.
4. The lawyer sees submitted answers in the estate review tab as review-only information; custom answers have no Apply control and do not modify estate data.
5. Owner and portal boundaries reject cross-estate or unauthenticated access; legacy payloads and question-free estates remain usable.
6. The migration has been generated, applied and schema-checked; focused, full, build and browser verification pass.

## Open questions

None for v1. Question types, attachments, conditional questions and custom-answer application are consciously out of scope.
