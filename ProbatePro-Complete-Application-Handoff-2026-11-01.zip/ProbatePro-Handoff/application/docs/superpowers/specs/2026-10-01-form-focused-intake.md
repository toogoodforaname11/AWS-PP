# Form-focused intake mode

## Goal

Add an optional, per-user workspace preference that gives practitioners a narrower Intake view containing only fields that can populate a generated ProbatePro document. When the preference is enabled, show all individual forms in one ordered list instead of Required and Optional groups.

## Scope

- Add `settings.formFocusedIntake`, defaulting to `false`.
- Expose the preference in Settings as **Form-focused intake**.
- Preserve the present Intake and Forms-tab experience when the preference is off.
- In form-focused Intake, hide only controls explicitly identified as case-management or workflow-tracking fields that do not populate a generated document.
- Keep all document fields, document attachments, form-applicability facts, and existing Intake persistence unchanged.
- In form-focused Forms, render every supported individual form in the existing catalog order under one **All forms** heading. Retain the existing per-form applicability badge and Generate/Preview behavior.

## Non-goals

- Do not change form applicability, requiredness, preflight, document generation, PDF/DOCX output, official wording, document layout, attachments, or contact/inventory behavior.
- Do not remove fields from the standard Intake.
- Do not infer document relevance from a partial preflight registry; relevance is explicitly curated in the Intake UI.

## Curated omissions in form-focused Intake

The compact view omits only:

- deceased SIN and TIN;
- file status and assignee;
- post-grant deadline/event tracking.

Every other existing Intake field remains visible because it either supplies document content, a document attachment, a form-applicability fact, a required-document condition, or a document-specific completion path. This deliberately keeps filing dates, certified-copy requests, codicil facts, and limitation facts visible where they affect a form or its supporting documents.

## Acceptance criteria

1. The new preference defaults off for a user with no settings row and existing users retain the standard view.
2. Toggling the setting persists through the existing protected Settings API.
3. Form-focused Intake hides only the curated non-document controls; the standard view remains unchanged.
4. Form-focused Forms has one All forms group, no Required/Optional group headings, and keeps all existing rows/actions/badges.
5. With the setting off, existing Forms grouping behavior is unchanged.
6. Schema migration is additive and validated; focused tests, TypeScript, full serial suite, production build, whitespace checks, and a scoped diff review pass.
