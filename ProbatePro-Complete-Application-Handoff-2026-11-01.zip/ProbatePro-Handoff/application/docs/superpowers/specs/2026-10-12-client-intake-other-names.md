# Client Intake Other-Names Mapping Specification

## Reported defect

A client-submitted deceased alias such as `TEST Alias` is applied to `akaFirstName`, rather than remaining an intact alias in the canonical estate alias list. The lawyer sees an apparent first-name-only alias after applying the selected client fact.

## Root cause

`server/clientIntakeMapping.ts` treats the full client `deceasedAliases` value as the first structured AKA (`akaFirstName`) and clears `akaMiddleName` and `akaLastName`. This incorrectly converts an undivided reported alias into a name part. The Intake alias synchronizer then treats that derived structured AKA as the primary alias.

## Required behavior

1. A selected portal `deceasedAliases` fact must write the submitted, semicolon/newline-delimited aliases only to canonical `estates.deceasedAliases`.
2. The mapper must set `hasOtherNames` to `yes` when at least one alias is supplied.
3. The mapper must not infer, set, clear, or overwrite `akaFirstName`, `akaMiddleName`, `akaLastName`, or `hasAdditionalNames` from a client-reported full alias.
4. Existing lawyer-entered structured AKA fields must remain unchanged when the selected client alias fact is applied.
5. The Intake alias editor must keep a full client-reported alias visible and editable in the canonical alias list when no structured primary AKA exists. It must not force that alias into an AKA name-part field.
6. Do not change client-facing primary name or address fields. First/middle/last names and street/unit/city/province/postal/country remain separately captured and mapped.
7. Do not change court-form text/layout, document generation, the canonical alias reconciliation contract, other portal defects, or historical estate records.

## Acceptance examples

| Submitted value | Existing lawyer AKA fields | Selected outcome |
| --- | --- | --- |
| `TEST Alias` | all blank | `deceasedAliases = "TEST Alias"`, `hasOtherNames = "yes"`; all AKA name parts remain blank; Intake shows the full alias in its list editor. |
| `A; B` | `Existing / Middle / Name` | canonical list becomes `A; B`; structured AKA fields remain `Existing / Middle / Name` untouched. |
| blank aliases | any values | selection is rejected as an unavailable/blank client fact; no write occurs. |

## Verification

- Add a red-green mapper regression for a single full alias and an existing structured AKA non-overwrite case.
- Add an Intake editor regression showing a full canonical alias without a structured primary AKA remains visible/editable outside AKA name-part inputs.
- Run focused mapper + Intake tests, TypeScript, the serial suite, production build, whitespace/scope review, and runtime health before checkpointing.
