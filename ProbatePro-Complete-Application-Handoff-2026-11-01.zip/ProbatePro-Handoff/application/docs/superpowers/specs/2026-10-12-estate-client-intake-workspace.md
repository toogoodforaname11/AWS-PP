# Estate Client-Intake Workspace

## Goal

Give lawyers a **Client Portal** tab within each estate file. From that tab they can issue and manage the secure client-intake link, review submissions, and apply only the facts they verify—either one at a time or all eligible items together.

The external portal must use the supplied *Executor Information Form* as its information architecture, in a clear client-friendly format. It must not write directly to the estate or generate court documents.

## Current state and gap

The application already has secure, owner-scoped portal links and a client-submission review component. It already supports selected estate facts being applied after lawyer review. The review surface is currently embedded in the Intake tab, and the portal only gathers a small subset of the supplied template.

## Approved scope

### Estate file

- Add a **Client Portal** estate tab visible in the normal and form-focused tab sets.
- Move the existing client-submission review surface into that tab.
- Provide per-estate link issue, copy, reissue, expiry, revoke, and status controls in that tab.
- Keep the top-level Executor Portal page as the cross-estate access manager.

### Client-facing portal form

Use the supplied template’s sequence, with plain-language grouping:

1. **About you** — name, email, phone, relationship, occupation, date of birth, and structured mailing address.
2. **About the person who died** — legal name, other names, place of birth, structured last address, dates of birth/death, will answer, will date/location, and treaty-first-nation answer/name where relevant.
3. **Executors named in the will** — repeatable contact rows.
4. **Family members and other people** — repeatable, clearly categorized contact rows (spouse/former spouse, child, parent, sibling, person named in the will/other).
5. **Estate assets and debts** — repeatable assets/debts separated visually as real property, vehicles, bank accounts/investments, other assets, and debts. Values are optional and never changed to $0 when unknown.
6. **Documents to gather** — concise non-upload checklist for original will, death certificate, and most recent tax return. This is a request for the client to gather documents; it is not represented as a completed legal fact or automatically applied.

### Lawyer application controls

- Existing scalar estate facts remain individually selectable.
- Every client-reported executor, person, asset, or debt appears as its own selectable review item.
- **Apply all verified details** selects all currently eligible scalar facts and reported rows; lawyers can deselect any one item before approval.
- An executor row creates an executor contact, but never an applicant or a legal conclusion about appointment status.
- Family/other rows create a neutral `client_reported_person` contact with the relationship recorded. The app must not infer that a child or person named in a will is a beneficiary or notice recipient.
- Asset/debt rows create inventory records only after explicit selection. Values are recorded only when the client entered a numeric amount. Financial account numbers retain the existing encrypted inventory write path.
- Lawyer approval still uses the current revision guard and marks the submission reviewed atomically with the estate patch. If a conflict occurs, nothing is marked approved.

## Explicit non-goals

- No automatic upload or application of identity documents, wills, death certificates, or tax returns.
- No automatic creation of beneficiaries, creditors, applicants, notice recipients, or filing conclusions from client statements.
- No court-form wording, layout, or document-generator changes.
- No database migration: the existing JSON submission payload and current contacts/inventory tables are sufficient.

## Success criteria

1. Lawyer can open `/estate/:id?tab=client-portal`, manage access, and review the submitted intake without leaving the estate.
2. Client form carries the supplied outline in a readable mobile-friendly sequence.
3. Lawyer can select individual fields/rows or use an explicit all-eligible selection before applying.
4. Only selected values are written, all writes are owner-scoped and revision-safe, and sensitive financial account numbers use existing encryption.
5. Existing submissions remain parseable: new fields default safely, and legacy submissions remain reviewable.
6. Focused UI/router tests, typecheck, serial suite, production build, whitespace check, runtime health, and checkpoint all pass.
