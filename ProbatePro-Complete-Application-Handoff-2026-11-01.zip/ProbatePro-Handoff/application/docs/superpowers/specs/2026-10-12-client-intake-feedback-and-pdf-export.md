# Spec: Client Intake Undo Feedback and PDF Export

## Objective

Give the lawyer reviewing a client intake submission two clear post-review utilities in the estate Client Portal tab:

1. After a successful `Undo last apply`, show a concise, smooth success notification that confirms the client facts were restored and that review can continue.
2. Let the lawyer download the selected completed client intake submission as a clean PDF record.

The export is a local browser download for the authenticated estate reviewer. It must reproduce only the submitted intake payload and submitted custom-question responses; it must not apply facts, alter the estate, expose any data to a portal client, or create a court form.

## Tech Stack

- React 19 / TypeScript
- tRPC query cache and existing `ClientIntakeReview` component
- Sonner 2 for application toasts
- Existing `jspdf` 4 dependency for in-browser PDF creation
- Vitest + Testing Library

## Commands

```bash
pnpm exec vitest run client/src/components/ClientIntakeReview.test.tsx client/src/lib/clientIntakePdf.test.ts --maxWorkers=1
pnpm check
pnpm test -- --maxWorkers=1
pnpm build
```

## Project Structure

- `client/src/components/ClientIntakeReview.tsx` — review actions, success feedback, and the lawyer-facing export button.
- `client/src/lib/clientIntakePdf.ts` — pure submitted-payload-to-section mapper and browser PDF generator.
- `client/src/components/ClientIntakeReview.test.tsx` — interaction regression coverage.
- `client/src/lib/clientIntakePdf.test.ts` — output-model and download regression coverage.
- `docs/audits/` — completion record.

## Code Style

Use existing aliases and named helpers. Keep submitted facts separate from estate facts:

```ts
const filename = exportCompletedClientIntakePdf({
  payload: active.payload,
  submittedByName: active.submittedByName,
  submittedAt: active.submittedAt,
});
toast.success("Client intake PDF downloaded", { description: `Saved ${filename}.` });
```

## Testing Strategy

- Start with focused component and PDF-helper regressions.
- Test an undo success callback invokes the clear success toast configuration.
- Test selected submission export calls the PDF exporter with the selected immutable submission payload.
- Test the PDF model includes submitted scalar, collection, document, and non-empty custom-response values while omitting blank values.
- Test a mocked jsPDF save call receives a sanitized `.pdf` filename.
- Run type checking, the full serial suite, production build, whitespace checks, and browser-level interaction using isolated fictional fixtures only.

## Boundaries

- **Always:** preserve the existing undo authorization, revision, snapshot, cache invalidation, and client-intake review rules; use the existing toast system and existing `jspdf` dependency; use native buttons with accessible names.
- **Ask first:** any database schema, router, tRPC contract, server document persistence, or new dependency change.
- **Never:** include reviewer notes, correction requests, estate values, undo snapshots, login/access links, or portal credentials in the PDF; alter court forms, official wording, legal logic, or client-facing portal scope.

## Success Criteria

- A successful undo produces a visible Sonner success toast with a concise title, a clear description, and a bounded duration; error behavior remains unchanged.
- The selected submitted intake displays an accessible lawyer-side PDF export button.
- Clicking export downloads one `.pdf` file containing the submitted client intake information and non-empty case-specific responses in readable sections.
- Exporting has no mutation, no tRPC request, and no effect on approval, undo, revision, or estate state.
- The PDF filename is safe for browser download and does not leak email addresses or portal tokens.
- Focused tests, TypeScript, full serial tests, production build, whitespace checks, and an isolated browser interaction pass.

## Open Questions

None. The request specifies a PDF record in the lawyer review tab; the existing in-browser PDF dependency is adequate and avoids a new stored-document or server-export workflow.
