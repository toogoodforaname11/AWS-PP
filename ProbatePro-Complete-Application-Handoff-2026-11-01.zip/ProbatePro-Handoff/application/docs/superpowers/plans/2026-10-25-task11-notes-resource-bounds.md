# Task 11 — Notes PDF export resource bounds — plan r1 (Gate A proposal)

**Status:** plan r2, Gate A proposal. Nick reviewed r1 on 2026-10-25 and declined the plan-mode exit; his review is
recorded verbatim at the end.
- Nothing is implemented, and no application edit is authorized. **Gate B is not approved.**
- Nick's answers approve only the four choices P1–P4 (account gate after auth/strict body and before lookup; the four
  input caps; the 10 s unconfirmed-start answer with one late terminal; three notes sentences without the
  estate-export pointer). See the review record.
- In a second round (r2), Nick answered P12 ("After auth"), the remaining §2 numbers ("As proposed"), P9 ("Yes, 300 s")
  and P5/P7/P8/P11 (all approved). Every P-item and §2 value now has an exact recorded answer.
- **Gate B still needs Nick's separate, explicit go-ahead.** These answers approve the design; they do not start
  implementation.

## Changes from r1 (Nick's review, 2026-10-25)

1. **Approval mapping.** The global lease placement is split out of P1 as **P12** — Nick chose "After auth (Recommended)" — with its
   busy-before-auth answer and its starvation-during-auth trade-off. Claims of full per-account fairness, or of
   other-account notes service being unaffected, are withdrawn while P12 stands.
2. **No pool reservation claimed.** Only the per-process maximum of lease-owned pending notes DB work (≤3), plus Task
   15's separately bounded ≤2 report writes, is claimed. Free-connection figures and "other features unaffected"
   guarantees are removed. The fixture's capacity is described conditionally.
3. **Send-deadline ordering contract** (§4a): arm only after `sendNotesPdf` returns, and only if no stage has been
   seen; one idempotent clear/settle path; tests for every immediate path with zero armed timers left.
4. **Proof gaps closed in the plan:**
   - every capacity and memory figure is labelled an observation/estimate, not a hard bound;
   - a mandatory combined-cap vector with two retained PDFs;
   - a named B6 stop metric;
   - a QA-only linebreak differential oracle and a reconstructed displayed-string oracle;
   - conditional materialization including all selected fields and astral UTF-16 expansion;
   - a structural (not GC) retention gate.
5. **N10 corrected.** Cross-feature availability is proved under a labelled notes-start-only injected hold. The
   global `audit_log` lock is used only for notes waiting, late ACK/failure, blocked-session counts and reads without
   audit inserts.
6. **The estate-export alternative claim is withdrawn.** It has its own limits and dependencies.
7. **Rule 29 renderer retention** is treated as a requirement, not a decision (former P6).

Queue item 11 only (not hybrid Step 4). Not in scope:
- Tasks 7/8 (not reopened), 12 and 17, the final review, any other prompt;
- commit/stage/push/publish/deploy, production or AWS, vault writes;
- marking Task 11 done.

## Approval gates

1. **Gate A — this plan.** Plan mode allows writing only the session plan file. Exiting plan mode authorizes **only**
   saving this text as `docs/superpowers/plans/2026-10-25-task11-notes-resource-bounds.md` (new, untracked, LF),
   reporting its SHA-256, and **stopping**.
   - The saved status block records each of P1–P12 and every §2 value as **approved, changed or declined**, quoting
     Nick verbatim.
   - Anything he has not answered is recorded as "**proposed — not approved**".
2. **Gate B — implementation.** Steps B0–B11 (§9) start only after Nick's separate, explicit go-ahead, and only once
   every P-item used by §2 and §8 has an explicit answer.

## Capability routing (find-skill, recorded)

| Phase | Capability |
|---|---|
| Gate A investigation | Workflow of six read-only Explore streams + completeness critic: PDFKit probes, DB/pool, client copy, tests/fixtures, rules/dispositions, connected features. Then an adversarial plan-review panel. |
| Gate B implement | Main session, plan-driven (`superpowers:test-driven-development`, `superpowers:verification-before-completion`); no subagent edits |
| Gate B verify | QA harness copies (Task 10 pattern); gates via `run-gates.cjs` in the background |
| Gate B review | General-purpose agents on Opus (the Review Council guard blocks specialist types; pass the model explicitly). R3 runs `probate-integrity-gate` read-only, re-pointed at this worktree, with no SHIP verdict. |

Routing rows that applied:
- "New feature → planner (+architect, tdd-guide)";
- "Backend build → express-expert (+database-reviewer, security-reviewer)";
- "Performance → performance-benchmarker";
- "Testing → tdd-guide → test-runner (+e2e-runner)".

The work spans several domains and is high-stakes, so it is orchestrated.

## Context

Task 10 (accepted/done by Nick 2026-10-25 08:10 PDT, tracking only, not SHIP) carried **L1** to Task 11 (queue
:585-588):
- an audit write (start or denial) that never settles holds its request (the start wait also holds the PDF);
- concurrent unresolved writes and the growth of append-only audit rows are unbounded;
- the notes route has no per-user budget.

Queue item 11 (:59): "Enforce rate/concurrency/byte budgets and cleanup, preserve PDF output for in-budget inputs.
Cover failure/disconnect/retry."

**Investigation adds two unrecorded hazards.** Both are reachable today by one authenticated account within schema
limits:
- **Memory bomb.** 500 notes of 9,999 line breaks → ~100,000 pages. That is ~1.7 GB of buffered output (extrapolated
  from a measured 10,003 pages = 170 MB external / 368 MB RSS) — an OOM risk.
- **CPU bomb.** 500 notes of one unbroken 10,000-character word → ~71 s of synchronous event-loop block (measured
  7.1 s for 50 notes). That stalls every request in the process.

**Goal:** every notes export holds a bounded share of the process — admission, waits, memory, render time, DB
connections and audit-row creation rate. An in-budget export keeps:
- byte-identical PDF output;
- the same selected notes and order;
- the same D1–D4 answers and audits;
- the same client behaviour.

**Non-goals:** no SQL cancellation claim, no cluster-wide enforcement, no audit retention/deletion, no renderer,
filename, schema, client, pool or global-audit change, no partial export.

## State verified at planning time (2026-10-25 08:20–09:40 PDT; read-only)

**Repository and queue**
- Branch `security/hybrid-vault-review`, HEAD `db0d7e9161bc3899b75858fab58bce54e3d5247a`, index empty, one
  pre-existing stash (never touched).
- Porcelain shows 78 modified and 67 untracked entries. Task 10's 18:05 step 0 recorded 78/65; the difference includes
  the new `2026-10-25-task11-handoff-preferences.md`. All preserved.
- Task 10 manifests:
  - `pass2-source-before.sha256` 4/4 OK;
  - `reference-before-hashes.sha256` 36/36 OK;
  - `qa-hashes.sha256` 24/24 OK.
- The run-gates `freeze()` replay checked 54 files with 0 violations.
- Queue (`0a264f49…`, LF; only append-only notes since Task 10):
  - 1/2/3/16/4/5 accepted;
  - 15/9/13/10 done by Nick's decisions (not SHIP);
  - 14/6/7/8 open and not reopened;
  - 11 next.
- RULES.md Rule 29 (1966-1980) is the document freeze only; there are no "three exceptions".
  - Rules 28/29 exist only in the uncommitted worktree RULES.md (HEAD ends at Rule 27): preserved predecessor work.
  - The stale "three Rule 29 format exceptions" wording survives in older prompts 01-04/10-14 (outside this task;
    noted only).
- `run-gates.cjs` does **not** freeze-check `notesExportRoute.ts`. The notes-PDF freeze is therefore proved by the
  golden byte-equality cases and the frozen-region hashes (§9), not by the runner.
- **AWAITING-NICK items preserved, none resolved:**
  - RULES.md :296-298, :308/:363, :1029, :1066, :1103, :1564-1565;
  - the Probate Software vault's hybrid D1–D7 and its `CLAUDE.md:44`.
  - **Hybrid D2** (keep or split the shared 8/min download bucket) is neither decided nor mooted: notes gets a separate
    notes-only window, and `document_generation` is untouched.
- No vault or external archive is written (closure precedent, queue :458, :527).
- Fixture state: no listener on 43117/43316/43xxx, no `mysqld`, no `mysql.pid`, no arms.
- 56 unidentified `node.exe` processes own no listening socket. They are not touched; Gate B step 0 checks for a busy
  peer.
- The label `claude-task11-pass1` is unused (227 labels, none containing task11). No `.work/hybrid-remediation/task11/`.
- **Source graph:** `code-review-graph` (built at HEAD) was queried for callers, callees and impact. It does not index
  the untracked `deliveryRouter.ts`, `downloadExportsRoute.ts`, `exportFailureReporting.ts`, the audit test or
  `shared/postDelivery.ts`, so the trace fell back to Grep (a bounded caller/test trace).
  - Callers of the handler: `deliveryRouter.ts:14, 250`.
  - Tests driving the real handler: the audit test, `downloadRoute.test.ts`, `deliveryBearerAuth.test.ts`.
  - Tests that stub it: `deliveryRouter.test.ts`, `index.startup-storage.test.ts`.
  - `listEstateNotes` consumers: `notes.list`, the PDF route, `estateExport.ts:131`.

**Pre-task copy inventory (full SHA-256; secrets, env files, profiles and dependencies excluded).**

Edit targets:
- `server/notesExportRoute.ts` `52b07b23b15cf220d085773aa35cffde72b56f4f2fae2700b7f4ba70bc21bd8c`
- `server/_core/deliveryRouter.ts` `6d0f009ba606cfaf1d0245bd6c6640a59def32001adbd10f306dd3f583fa3d4e`
- `server/notesExportRoute.audit.test.ts` `bfebc2669a7f08c2b935156ab02a3f96113844ec6730db3e30c2237930ca9e5d`
- `server/downloadRoute.test.ts` `4adb4c5b21677d368101cdb5b7ed2c2a24e650b51d2aa09abf9687d2d42b4937`

Protected and referenced:
- `affidavitHistory.ts` `38f875b8…90e0`
- `deliveryBearerAuth.test.ts` `9c529224…29fe`
- `db.ts` `32c57258…68ef7`
- `trpc.ts` `6b2e7198…c6c290`
- `exportFailureReporting.ts` `81429bc9…cce8`
- `sdk.ts` `92c133a1…a5d561`
- `index.ts` `ad2a9fd2…aee`

Task 10 copy sources:
- `fixture/start-ui-task10.cjs` `b735f7b0…367a`
- `ui-server-task10.ts` `666ccb0e…d94c`
- `arm-task10.cjs` `fca81bf2…d7f5`
- `audit-faults-task10.ts` `ebcfc66f…ca2c`
- `capture-deliveries-task10.ts` `56eba67e…4188`
- `native/run-native-task10.cjs` `440f9421…2226`
- `verify-native-task10.ts` `7d4f8a1b…bf68`
- `qa/golden.qa.test.ts` `cf75d2c3…b99d`
- `golden.vitest.config.mts` `8ab4045e…c7a9`
- `run-golden.cjs` `90539191…813e`
- `golden-compare.cjs` `7bccdc69…0aa5`
- `golden-before.json` `9f0c4a25…d297`
- `frozen-regions.cjs` `3f8e80ca…9449`

Shared:
- `run-gates.cjs` `ac2828be…8be8e`
- `fixture/mysql-fixture.cjs` `3a6954df…f876`

B0 records every value in full, copies every edit target and copy source into `before/`, and refuses to run on any
drift.

**Fingerprints** (full SHA-256 in the Gate B step-0 receipt; any drift stops work)

| File | sha256 prefix | Line endings (CRLF/LF) |
|---|---|---|
| `server/notesExportRoute.ts` | `52b07b23b15cf220` | CRLF 214/0 |
| `server/_core/deliveryRouter.ts` | `6d0f009ba606cfaf` | CRLF 258/0 |
| `server/_core/trpc.ts` | `6b2e719866102e99` | CRLF 258/0 |
| `server/affidavitHistory.ts` | `38f875b89dcde4f6` | MIXED 472/173 |
| `server/db.ts` | `32c5725805d1c90c` | MIXED 2377/169 |
| `server/exportFailureReporting.ts` | `81429bc961d237e9` | LF 0/198 |
| `server/failureReporting.ts` | `6a152dfbcacd63c6` | CRLF 341/0 |
| `server/_core/index.ts` | `ad2a9fd26a97c5c4` | CRLF 248/0 |
| `server/_core/sdk.ts` | `92c133a1dbe1ad10` | CRLF 379/0 |
| `server/notesExportRoute.audit.test.ts` | `bfebc2669a7f08c2` | LF 0/841 |
| `server/deliveryBearerAuth.test.ts` | `9c5292242e38f1d6` | LF 0/173 |
| `server/downloadRoute.test.ts` | `4adb4c5b21677d36` | MIXED 2124/42 |
| `server/_core/deliveryRouter.test.ts` | `cfc0d36504426fdb` | CRLF 626/0 |
| `server/downloadExportsRoute.ts` | `caa3cfbc92171203` | CRLF 172/0 |
| `drizzle/schema.ts` / `shared/types.ts` / `server/docgen.ts` / `RULES.md` | `25f7c362…` / `9a60dfb7…` / `7224c88e…` / `648f49a7…` | CRLF |
| `package.json` / `pnpm-lock.yaml` | `4640e1f4…` / `95bfc047…` | not edited |
| `client/src/pages/EstateDetail.tsx` (protected) | `efc61382917a939a` | CRLF |
| `client/src/lib/attachmentDelivery.ts` (protected) | `af06d770b5179a66` | LF |
| `client/src/lib/fallbackSession.ts` (protected) | `4dbfdcd6bd9441a8` | LF |
| `client/src/components/PreGenerateDialog.tsx` (protected) | `aeb48a9a148f0917` | CRLF |
| Task 10 plan / handoff prefs | `c62cf78c…` / `fba5ee58…` | LF |

Frozen regions of `notesExportRoute.ts` (current lines; hashed at step 0):
- TAG_LABELS 27-33;
- `notesBody` 35-39;
- `notesPdf` 43-104 (`chunks` 47, `Buffer.concat` 49);
- estateName/fileName 183-184;
- the call text `notesPdf(estateName, estate.fileNumber, notes)` (once);
- the catch body 206-213;
- line 180's "Fetch all notes" comment, which is not fixed here.

**Runtime facts**
- **Versions:** Node v24.13.1, pdfkit 0.19.1, mysql2 3.15.1, drizzle-orm 0.45.2, express 4.22.2, express-rate-limit
  8.5.2, vitest 2.1.9.
- **Pool** (`driver.js:72-78`, `pool_config.js:11-26`, `base/pool.js:35-158`):
  - `drizzle(DATABASE_URL)` = `createPool({ uri })`: 10 connections, unbounded queue, no acquire timeout.
  - Every query acquires and releases internally, so no caller ever holds the connection.
  - Queued requests cannot be withdrawn.
  - mysql2's per-query `timeout` only rejects the caller and frees nothing. There is no cancel API.
  - `DATABASE_URL` parameters could override the pool size; the production value was not inspected (secret).
- **Production engine** is described as TiDB (RULES.md :783, :1241). Fixture evidence is MySQL 8.4.11/InnoDB only.
- **Auth** (`sdk.ts:233-349`):
  - Unauthenticated or invalid-token requests touch no DB.
  - An authenticated request performs a users SELECT **and an `upsertUser` write** (`sdk.ts:330, 343-346`).
- **Audit writers** `recordAuditEvent`/`createAuditEntry`/`recordIdorAttempt`:
  - total (true/false, never reject);
  - `deliveryEvent` allow-lists 14 keys and cuts `failure` to 64 characters (`affidavitHistory.ts:483-503, 611-621`);
  - all write the one shared `audit_log` table (no FKs).
- **Task 15 reporter** (`exportFailureReporting.ts:33-39, 153-198`):
  - total, 1 s caller wait;
  - ≤2 unsettled writes per process (all users);
  - 8 rows per user per 60 s;
  - each reservation is released only when its write settles. This is the in-repo precedent for the leases below.
- **No HTTP server timeouts** (`index.ts`). A client that never reads can pin a response indefinitely.
- **Client** (Task 13 files read-only):
  - **Cookie-native path:** a same-tab form POST navigation; the button is held 2 s; a refusal page offers only
    "Return to ProbatePro" (`/`).
  - **Bearer path:** one fetch, with the button disabled until settlement. Any ≥400 JSON `{error}` is shown verbatim
    in a 4 s toast, or GENERIC after a token change.
  - **Fetch bounds:** 900 s for headers, 60 s idle, 30 min total; PDF ceiling 64 MiB.
  - Notes ignores status codes.
  - Same-user concurrency is normal: a cookie re-click after 2 s abandons the first navigation.
- **Schema:** `estate_notes.content varchar(10000)` (migration 0031:10; zod `.max(10000)` on create/update, the only
  writers). `schemaCheck` verifies only text-type columns (`schemaCheck.ts:116-123`).
- **Deployment** is autoscale/serverless (`.cursorrules:180`). Every limit is per process instance; the replica count
  is unknown.
- **Estate export.** The archive includes the same selected notes (`estateExport.ts:131, 185`), but it has its own
  limits, storage and audit dependencies. No guaranteed alternative retrieval under every saturation scenario is
  claimed. A notes-PDF refusal never alters or truncates the note set.

**PDFKit facts** (Gate A probes: `require('pdfkit')` only, `notesPdf` copied verbatim at runtime, no files written,
fictional text)
- **Defaults:** compress on, PDF 1.3, Helvetica. CreationDate and `/ID` derive from `new Date()` (1 s resolution).
  Bytes are identical for a frozen clock — pre-existing, frozen.
- **Buffering:** every chunk is held in the stream buffer until the synchronous render returns. **0 `data` events
  fire before the executor returns, in all 16 cases.** Then `Buffer.concat` copies once.
- The non-preemptible region is `notesExportRoute.ts` 46-102, plus the concat (49) and the sha256 (186). PDFKit checks
  no AbortSignal.
- **Measured** (one process per case; times are the synchronous block):

| Input | Pages | PDF | Block | Peak RSS / arrayBuffers |
|---|---|---|---|---|
| empty | 1 | 1.6 KB | <0.1 s warm | 65 / 2 MB |
| 500 notes × 1,000 chars prose | 125 | 0.59 MB | 0.74 s | 85 / 5 MB |
| 500 × 10,000 prose (schema max) | 972 | 5.5 MB | 8.1 s | 178 / 32 MB |
| 50 × 9,999 line breaks | 10,003 | 4.3 MB | 0.71 s | 368 / 170 MB |
| 50 × "W"×10,000 (unbroken) | 191 | 0.14 MB | 7.1 s | 131 / 6 MB |
| 50 × 10,000 emoji / CJK | 3 | ≤18 KB | 0.43 / 0.27 s | ≤137 MB (zero-width glyphs) |
| 500 × 1 char, pinned | 28 | 30 KB | 0.19 s | 90 MB |

- **Model:**
  - prose ≈ 1.5 µs/char;
  - unbroken runs ≈ 14 µs/char, super-linear in run length;
  - about one page per 50 line breaks, ≈ 22 KB buffered per page;
  - a fixed ≈ 0.4 ms per note.

## Current resource behaviour (traced)

| Stage | Line | Work | Holds while pending | Bounded today by |
|---|---|---|---|---|
| auth | 153 | users SELECT + upsert (authenticated only) | request | edge 200/min/IP |
| lookup | 163 | `getEstate` (wide row + decryption) | request | – |
| foreign denial | 166-174 | awaited `audit_log` INSERT | request | – (L1) |
| notes read | 181 | ≤500 rows, every column (≤ ~5.8 M chars) | rows | LIMIT 500 + column caps |
| render | 185 → 44-104 | synchronous PDFKit; stream buffer; concat | rows + output ≈ 22 KB/page + PDF ×2 | nothing |
| hash | 186 | sha256 (≈11 µs/KB) | PDF | – |
| start audit | 191-196 | awaited INSERT, strict `true` | PDF + rows | – (L1) |
| send | 205 → 125-147 | `res.end(pdf)` | PDF until written or the socket closes | – (no server timeouts) |
| terminal | 115 | detached INSERT | scalars | – |
| report | 201, 212 | detached Task 15 submit | scalars | Task 15 caps |

The awaited chain is sequential (≤1 DB operation pending at a time). After the answer, ≤1 terminal write plus Task 15's
own report write remain.

## Decisions requested (Gate A)

| # | Decision | Recommended | Alternative |
|---|---|---|---|
| P1 | Account-gate placement — **APPROVED** ("Before lookup (Recommended)") | Account gate after authentication, suspension and strict body, and **before** the estate lookup. Every authenticated, well-formed attempt counts; an over-budget attempt gets 429 with no lookup and no idor row. In-budget answers and audits unchanged (D1). | (precedent order declined) |
| P2 | Input caps — **APPROVED** ("Measured caps (Recommended)"); other numbers — proposed | Approved: 500,000 printed units, 20,000 mandatory breaks, longest wrap segment 1,000, long-segment Σ L² ≤ 10,000,000. **Proposed, not approved:** leases 3 (process) / 2 (account), rates 12 and 30 per 60 s, render windows 15 s and 6 s per 60 s, the 15 s pre-render wait, the 1,000-entry tracking cap. | Adjust any proposed number |
| P3 | Waits and late outcomes | Waits of 15 s pre-render and 10 s for the start ACK. A denial timeout still answers 404/403. A lookup that times out answers 503, but if it later proves a foreign owner it still writes its one `idor_attempt` (tracked). A start timeout → 503 S_UNCONFIRMED. A late `true` → exactly one `notes_delivery_failed` with `failure: "start_ack_timeout"`; a late false → nothing. New fixed failure literals: `start_ack_timeout`, `send_deadline`. | Same waits with no late terminal ("started, no terminal" = outcome not recorded, as L2); or no waits (D3 kept; leases alone bound the damage) |
| P4 | Refusal copy | Three new notes sentences (§6), added as three entries to `FIXED_SENTENCES` so the cookie-native page shows them (an additive edit to the shared router). Option: S_LARGE could add "Export estate copy on the dashboard includes them." — the estate export archive carries the same notes (`Home.tsx:989`, `estateExport.ts:131, 185`). | Reuse existing fixed sentences only: no shared edit, but busy shows "Estate exports are busy…" and the cookie page for oversize shows "The request is too large." (as the estate export's page does today) |
| P5 | Cancellation — **APPROVED** (round 2) | None. Leases are held until the work settles; no claim that anything is cancelled. | A separately approved shared `db.ts`/`affidavitHistory.ts`/`trpc.ts`/`sdk.ts` path (explicit connection, destroy on deadline, `MAX_EXECUTION_TIME`/`KILL QUERY`). It still never undoes a committed row. Not proposed. |
| P6 | (requirement, not a decision) | Rule 29: the whole `notesPdf` raw region and the single render call stay byte-identical; a cap inside 47-49 could not bound anything anyway (0 early `data` events) | – |
| P7 | Tests and evidence — **APPROVED** (round 2) | No environment exemption (every QA launcher sets VITEST=true). Add `resetNotesExportLimitsForTest()` (import + call; two lines per file) beside the existing `resetExportReportWindowsForTest()` in the `beforeEach` of `notesExportRoute.audit.test.ts` (:188) and `downloadRoute.test.ts` (:88/:1494; MIXED file, byte-exact Node splice). These are edits to accepted predecessor test files. The reset clears windows and idle entries only, never live leases. All assertions and EOLs are preserved. **Rate rationale (12/60 s/account):** interactive use is one export plus deliberate retries; the cookie button re-enables after 2 s and the Bearer button after each settlement, so a frustrated user can click every few seconds. 12 per minute is a click every 5 s sustained for a full minute, while cutting today's ceiling (200 requests/min/IP, unbounded per account) ~17× and bounding audit rows to ≤ ~24/min/account. That it also fits the existing 11-request test is a consequence, not the reason. | Mirror the VITEST exemption (makes limits invisible in evidence; not recommended) |
| P8 | Staff reports — **APPROVED** (round 2) | Task 11's new answers (busy, 429, 413 oversize, every wait timeout) file **none** — consistent with the chosen timeout option (P3), where the outcome is uncertain. The **existing** D4 report for a **definite** non-true ACK is unchanged and stays distinct from timeout uncertainty. Task 15's two unsettled slots are process-wide, so timeout reports during a stall would make other users' export reports "saturated" (handoff #14). | D4 parity on the start timeout |
| P9 | Send deadline — **APPROVED "Yes, 300 s (Recommended)"** | 300 s from `end(pdf)` to `finish` under the §4a ordering contract. On expiry: clear, then select and track `failed` with `failure: "send_deadline"` through the one-terminal guard, **then** `res.destroy()`. The expiry never cancels the tracked SQL terminal write. Node 24's synthetic `finish` on destroy is then ignored by the guard, and `aborted` keeps meaning "the requester left". | None: a client that never reads holds its lease and PDF until it disconnects (disclosed; ≤2 leases per account) |
| P10 | Hybrid D2 — affirmed untouched (Nick's r1 review) | Recorded as untouched | – |
| P11 | PDF non-retention — **APPROVED** (round 2) | Line 195 uses a precomputed scalar `const bytes = pdf.length` (also in `sent`, line 204). Primary gate (structural): every continuation that can outlive the answer captures scalars only; no PDF handoff on a timeout or refusal; no live response reference after a refusal; exactly-once settlement accounting. Reviewed in V1 and pinned by tests. A QA `FinalizationRegistry` run is recorded only as observed/inconclusive evidence, never as proof of prompt collection or a hard peak. | Keep line 195; the PDF stays reachable through the pending start-write closure until that write settles (bounded by the held lease; unbounded in time if the DB never answers) |
| P12 | Global-lease placement — **APPROVED "After auth (Recommended)"** (split from P1). The lease is taken after authentication/suspension/strict body and immediately before the account gate. The text below records the rejected "before auth" option and its consequences, for the record. | Take the process-wide lease (3) at handler entry, before `sdk.authenticateRequest`, so notes-path auth DB work (a users SELECT + upsert per authenticated request, `sdk.ts:298-348`) is bounded too. **Consequences Nick must accept or decline:** (a) when all 3 leases are busy, every request — even an unauthenticated one — gets 503 S_BUSY instead of its ordinary 401/403/400; (b) during authentication, before the account gate, any requester's concurrent requests occupy global leases. So one valid session (or a flood of slow authentications) can starve every user's notes export while auth is pending, and full per-account fairness is **not** claimed. Identity still comes only from verified `sdk` output; no SDK/auth refactor; no unverified token claim is used. | Take the global lease **after** authentication and before the account gate. Unauthenticated answers are then unaffected and fairness improves, but notes-path auth work is bounded only by the 200/min/IP edge limiter. |

## Design

### 1. Admission order

```
200/min/IP edge limiter (index.ts:190) → delivery guard → 8 KB parsers          (all unchanged)
notesExportHandler (new thin wrapper; still the module's only export):
    const holder = { lease: null };  try { await exportNotes(req, res, holder) } finally { holder.lease?.release() }
exportNotes (the existing body moved verbatim at the same indentation, plus the marked insertions):
 B  exportFailureAttempt                                                       (unchanged)
 C  authenticate, within the pre-render deadline [new caller wait] — timeout → 503 S_BUSY.
    Auth runs before any lease exists, so its DB work is not lease-tracked (P12 "After auth"; disclosed).
    null → 401; suspended → 403; strict body → 400                             (unchanged order and answers)
 A  global lease [new; P12 approved "After auth"]: holder.lease = admitNotesExport(); none free → 503 S_BUSY
    (no lookup, audit or report). Taken immediately before F with no await between.
 F  account gate [new]: lease.admitAccount(user.id), counting the attempt:
      account rate → 429 COSTLY_ROUTE_LIMIT_MESSAGE (existing fixed sentence)
      account leases / process rate / either render window / tracking cap → 503 S_BUSY
 G  getEstate (deadline) — timeout → 503 S_BUSY; if it later resolves to a foreign owner, the one idor_attempt
      write is still issued from scalars and tracked (P3), so a timed-out foreign probe is still audited
 H  foreign owner: one idor_attempt write, tracked, waited at most until the deadline;
      the answer below is identical whether it settled, failed or timed out
 I  missing/alias → 404; foreign → 403                                         (D1 unchanged)
 J  listEstateNotes (deadline) — timeout → 503 S_BUSY
 K  input caps [new]: measure the selected rows + header → over any cap → 413 S_LARGE (no render, audit or report)
 L  render + sha256                                     (frozen call; its measured duration is charged to both render windows)
 M  started write (its own 10 s wait): true → send; any other answer → D4 503 + one report (unchanged)
      timeout → 503 S_UNCONFIRMED (no report); a late true → one terminal event (§4)
 N  sendNotesPdf (unchanged) with a wrapped settle (§3) + the send-deadline timer (P9)
```

- **Rate suppression never grants access or reads another user's notes.** Every new refusal happens before, or
  instead of, the lookup and the read. An admitted request still passes B–I in full.
- **Identity** for F is `user.id` from `sdk.authenticateRequest` (cookie first, Bearer fallback), never a client field.
- **Under exhaustion:**
  - **P1 (approved):** an over-budget foreign attempt leaves no idor row (the first ones in each window do).
  - **P12 (approved "After auth"):** unauthenticated, suspended and malformed requests keep their ordinary answers.
    One account holds at most 2 of the 3 leases. Notes-path authentication DB work (a users SELECT + upsert per
    authenticated request, `sdk.ts:298-348`) is **not** bounded by notes leases. It is bounded only by the
    200/min/IP edge limiter, like every route's authentication: a disclosed shared-auth limit.
- **Requesters who leave are still processed exactly as today** (render, started, `aborted`; accepted T5/T7). Skipping
  that work would change accepted behaviour and is not proposed.

### 2. Budgets (approved by Nick 2026-10-25: input caps in round 1, the other values in round 2)

| Budget | Value | Scope | Enforced at | When exceeded | Released / reset by | Rationale |
|---|---|---|---|---|---|---|
| Global leases | **3** | concurrent notes requests incl. unsettled work; process | A | 503 S_BUSY | lease finalization (refcount 0) | A lease owns ≤1 notes DB operation at any moment, so at most 3 lease-owned notes DB operations are pending per process. Task 15's ≤2 report writes are bounded separately. This caps notes' own work; it **reserves nothing** for other routes. The physical pool size depends on `DATABASE_URL` (not inspected). The fictional fixture's pool (10 when no URL override) is described only conditionally. |
| Account leases | **2** | per account, incl. unsettled work | F | 503 S_BUSY | finalization | Admits a cookie re-click while the abandoned first export finishes. **The global lease is taken immediately before F (P12 "After auth"), so one account holds ≤2 of the 3 leases and a refused request holds a lease for no I/O. |
| Live notes bytes | ≤ 3 leases × (PDF ≤ cap-measured max, ×2 during concat, + rows ≤ ~11–21 MB conditional on the 0031 schema) | process | implied by A + K | – | lease finalization (cleanup owner: `lease.track` settlement and the response reference) | **Estimate**, not an enforced bound; re-measured at B6 with the combined-cap vector |
| Unresolved notes DB jobs | ≤ 1 per lease → ≤ 3 per process (+ Task 15's ≤2 report writes, not notes-owned) | process | A | – | `lease.track` settlement | The sequential chain plus tracked late writes |
| Account rate | **12 / 60 s** (fixed window) | admitted attempts | F | 429 limit sentence | window expiry | ≤ ~24 audit rows/min/account (today: 200 requests/min/IP). Fits the existing 11-request test (P7). |
| Process rate | **30 / 60 s** (fixed window) | admitted attempts | F | 503 S_BUSY | window expiry | Bounds process-wide audit creation (≤ ~60 rows/min) |
| Process render time | **15 s / 60 s** of measured rendering | process | checked at F, charged after L | 503 S_BUSY | window expiry | Per aligned window ≤ 15 s + 3·R_max of rendering (≈ 18–19 s ≈ 30% with the measured R_max); any 60 s span ≤ 2× that |
| Account render time | **6 s / 60 s** | per account | checked at F, charged after L | 503 S_BUSY | window expiry | One account cannot take more than ~40% of the render budget |
| Waiting queue | **0** | process | A, F | immediate refusal | – | Interactive and retryable; a queue would hold sockets, memory and connections |
| Pre-render wait | **15 s** from admission | per request | C, G, H, J | 503 S_BUSY (H: 404/403 unchanged) | timer cleared, `unref`'d; tracked work keeps the lease | Far below the 900 s Bearer header limit |
| Start-ACK wait | **10 s** from the start write | per request | M | 503 S_UNCONFIRMED; no report | as above | Starts after the bounded render, so never pre-exhausted. Fixture InnoDB lock wait is 50 s, so a late `true` is testable. |
| Send deadline | **300 s** `end` → `finish` (P9) | per response | N | `failed`/`send_deadline` recorded, then destroy | cleared at the forwarded finished/aborted | Allows a ~6 MB PDF at 20 KB/s |
| Input: printed characters | **500,000** | selected rows + header | K | 413 S_LARGE | – | ≈125 prose pages (measured 0.74 s) |
| Input: line breaks | **20,000** (all UAX#14 mandatory breaks) | selected rows + header | K | 413 S_LARGE | – | ≤ ~400 pages from breaks alone (≤ ~9 MB buffered) |
| Input: longest wrap segment | **1,000** UTF-16 units | content, printed tag, attachment name, header | K | 413 S_LARGE | – | Bounds any single long-word chop (a 1,000-unit worst mix ≈ 80 ms) |
| Input: long-segment budget | Σ L² (L > 49) **≤ 10,000,000** | same | K | 413 S_LARGE | – | Bounds the total chop cost (measured ≤0.49 s at the cap). Realistic link- and citation-heavy notes use 3.8–4.9 M. Keeps every render far below mysql2's 10 s connect timer, which a long synchronous block can trip for a concurrent new connection. |
| Tracked accounts | natural ≤ 2×30+3; hard cap **1,000** | map entries | F | 503 S_BUSY | pruning oldest-first; live entries never evicted | Entries exist only for accounts admitted in the current/previous window or holding a lease |
| Lease lifetime | until every tracked operation settles; **unbounded** if the DB never answers | – | – | notes stays busy (503) | DB recovery | No permit is recycled while its work runs (P5) |

**Measured inside the caps** (Gate A re-measurement: verbatim `notesPdf`, pdfkit 0.19.1, one process per case, this
workstation; B6 re-measures the final implementation and stops if R_max > 2.0 s or > 64 MB):

| Input | Block | Pages | Buffered (arrayBuffers) | RSS |
|---|---|---|---|---|
| 500 notes of punctuated prose (499 k chars) | 0.32 s | 129 | 8.3 MB | 110 MB |
| 500 notes, each with a ~85-char URL | 0.33 s | 121 | 7.9 MB | 110 MB |
| Email threads, legal citations, lists, TSV, French | 0.30–0.34 s | 130–228 | ≤12.8 MB | ≤116 MB |
| 20,000 breaks; CJK lines; max pages (blank lines + widest glyphs) | 0.25–0.57 s | ≤751 | ≤37.5 MB | ≤149 MB |
| Ten worst-mix 1,000-unit words at the long-segment cap | ≤0.49 s | 1–2 | 1.8 MB | – |

- Stacked worst estimate (not run as one input): ≈1.1–1.2 s, ≤ ~40 MB buffered, ~160 MB RSS. All PDFs are ≤1.3 MB,
  far below the 64 MiB client ceiling.
- A refused oversize read materializes up to ~11–21 MB of row strings per lease before refusal (conditional on the 0031 schema; astral worst case; B7 measures the fixture).
- Earlier caps were defeated by inputs blocking 36.5 s (zero-width-mix runs), 4.1 s (NBSP glue) and 2.1 s (space runs),
  and FF/VT page bombs reached ~9,800 pages. All of these are now refused by the segment rule or the break count.

### 3. Leases (new `server/notesExportLimits.ts`, LF, notes-only)

- `admitNotesExport()` returns a lease or null. A lease is a reference count:
  - the handler, dropped in the wrapper's `finally`;
  - the attachment response, taken only when `sendNotesPdf` is called;
  - every tracked promise.
- `lease.track(work)` returns `work` and drops its reference with `work.then(done, done)`, never `finally`, so there is
  no derived unhandled rejection. The reservation is released only at real settlement: the Task 15 pattern,
  `exportFailureReporting.ts:178-192`.
- `lease.admitAccount(userId)`:
  - prunes expired idle entries oldest-first (the `recentAttempts` / Task 15 LRU pattern);
  - checks account leases, the account rate, the process rate, both render windows and the cardinality cap;
  - counts only an admitted attempt.
- `lease.chargeRender(ms)` adds the measured render duration (`performance.now()`, unaffected by the golden harness's
  frozen `Date`) to both windows.
- **The lease adds no listener and no `req`/`res` method call.** Accepted Task 10 tests pin exactly
  `["close","error","finish"]` at the attachment header and none when the response is destroyed before the send, and
  T7's fake request/response lack `on`/`getHeader` (`notesExportRoute.audit.test.ts:166-183, 494-546, 572`).
  - The handler therefore passes `sendNotesPdf` a wrapped `settle`.
  - The wrapper forwards every call to the unchanged one-terminal guard and tracks the terminal write the guard now
    returns.
  - Then, on `"aborted"`, it drops the response reference. That stage is always reported at `close` (even after
    `finish`), or at once when the response was already destroyed.
  - Refusal answers hold no response reference.
- Finalization happens exactly once. A test asserts that no `track` can happen after finalization.
- **Test-only exports** (precedent: `resetExportReportWindowsForTest`):
  - `resetNotesExportLimitsForTest()` — clears the rate and render windows and idle map entries only. It **never
    touches live-lease counts**, so a finalization can never underflow (asserted) and a test that leaks a lease fails
    visibly. The new suites assert zero live leases in `afterEach`, like Task 15's unsettled-count check;
  - a counters/maxima snapshot (live, max live, per-account live, window counts, render ms, map size, finalizations);
  - `setNotesExportLimitsForTest()`, so QA harnesses can shorten waits and windows, always labelled.
- **Comment:** "Process-local. A tracked promise that never settles keeps its lease: this bounds notes work; it cancels
  nothing."

### 4. Bounded caller waits and late outcomes

`settleWithin(work, ms)`:
- builds `outcome = work.then(v => ({ok: true, v}), e => ({ok: false, e}))`, which never rejects;
- races it against an `unref`'d timer, clearing the timer in `finally`;
- returns `{settled: false}` on timeout, otherwise the value, or rethrows an in-time rejection (so a DB error keeps
  today's 500 + Task 15 report).
- It cancels no SQL, frees no connection, dequeues nothing and undoes no row (stated in its comment).

| Stage | On timeout | Late fulfil | Late reject | Lease |
|---|---|---|---|---|
| auth / lookup / notes read | 503 S_BUSY; no report; nothing logged | dropped | dropped | held until it settles |
| denial audit | 404/403 exactly as D1 | ignored (as today) | n/a (total) | held |
| start ACK | 503 S_UNCONFIRMED; no attachment header or byte; no report (P8) | `true` → exactly one `notes_delivery_failed` {format, attemptId, contentSha256, bytes, success: false, failure: "start_ack_timeout"} (P3); otherwise nothing | n/a (total) | held until that write settles |
| terminal write | – | – | n/a (total) | held |
| Task 15 report | unchanged: its own 1 s wait and its own settlement-held reservation | – | – | not tracked (already bounded) |

- **Late-ACK tracking (runtime review fix).** The lease tracks the whole chain
  `startAck.then(ack => ack === true && refused ? lateTerminalWrite() : undefined)`, not `startAck` alone.
  - The reaction returns the late write, so the lease's reference drops only after that write settles. No write is
    ever tracked after finalization, and the ≤1-operation-per-lease bound holds.
  - Same-turn ordering is handled on the handler side: if the reaction already saw `true` before the handler set
    `refused`, the handler issues and tracks the late write itself while its own reference is still held.
  - One once-flag guarantees exactly one late terminal. An R6/U7 case delivers the ACK after the handler returned and
    asserts exactly one finalization and one late write.
- **Late lookup (P3).** If `getEstate` settles after its wait and proves a foreign owner, the one `idor_attempt` write
  is issued from scalars, inside the same tracked chain. The answer (503) is already sent; the audit signal is kept.
- An ACK settling inside the wait is Task 10 exactly: `true` sends (or `aborted` if the requester left), anything else
  gives D4.
- **PDF retention (runtime review fix).** Today the started-write closure reads `pdf.length` (`notesExportRoute.ts:195`),
  so a pending write would pin the PDF after a 503.
  - The plan computes `const bytes = pdf.length` once before the start write and uses `bytes` there and in `sent`. This
    is a one-token change in the non-frozen handler.
  - After a refusal or timeout, only scalars, the decrypted estate row (`estate.id`/`revision`) and the request scalars
    stay reachable while the write is pending.
  - This is proved with a QA-only `FinalizationRegistry` / `--expose-gc` check, never inferred.
- No retry, no second response/report/started write, no unhandled rejection. Every handler is attached in every
  ordering; there is no process-level `unhandledRejection` handler, so an abandoned rejecting promise would crash the
  process.

### 4a. Send-deadline ordering contract (P9; Nick's review item 3)

State per attachment send: `sendState = { stageSeen: false, timer: null }`. There is exactly one wrapped settle and
one idempotent clear.
- **Wrapped settle `(stage, failure)`**, in this order:
  1. `stageSeen = true`;
  2. `clearSendTimer()` (idempotent: clears and nulls if set; decrements the armed-timer counter once);
  3. forward to the unchanged Task 10 one-terminal guard, and `lease.track()` the write it returns;
  4. on `"aborted"`, drop the response reference (idempotent).
- **Arming happens after `sendNotesPdf(...)` returns, and only if `!stageSeen`.** Every immediate path settles
  synchronously inside that call and therefore suppresses arming:
  - the response destroyed at entry → `aborted` (`notesExportRoute.ts:127`);
  - a synchronous setup failure such as the F1 `setHeader` throw → `failed`, then rethrow: the throw skips arming
    entirely;
  - a controlled synchronous finish/close (fake emitters).
  So no timer is armed for any of them, and none is left behind.
- **Finish before close:** `finished` sets `stageSeen` and clears the timer even though the response reference drops
  only at `close`, so a completed transfer never arms or keeps a deadline.
- **On expiry `onDeadline()`:**
  1. clear;
  2. wrapped settle `("failed", "send_deadline")` — the guard selects and tracks that terminal;
  3. then `res.destroy()`. Node 24's synthetic `finish` and the later `close` → `aborted` reach the guard
     already-terminal and are ignored; `close` still drops the response reference.
  The expiry never cancels the tracked SQL terminal write: the lease holds until it settles.
- The timer is `unref`'d and counted in the test-only armed-timer counter. It adds no listener, so Task 10's
  listener-identity and once-guard assertions are unchanged.
- **Tests (R14):** each must end with 0 armed timers and exactly one terminal:
  - destroyed at send entry;
  - synchronous finish/close through `HandBuiltResponse`;
  - synchronous setup failure (non-Latin-1 filename → `failed` "TypeError", then the 500);
  - normal finish (armed, then cleared);
  - a real stalled reader on a raw socket with a body larger than the socket buffers and a test-hook-shortened
    deadline → `failed`/`send_deadline`, never `finished`; lease released only after that write settles.

### 5. Input caps (step K)

- **Materialization before the check is a conditional bound, not a guarantee.**
  - `listEstateNotes` materializes every selected column of up to 500 rows before K (`db.ts:2088-2096`): id,
    estateId, userId, content, pinned, tag, attachmentKey/Url/Name/Type, createdAt, updatedAt
    (`drizzle/schema.ts:1066-1078`). The decrypted estate row is already live too.
  - **If** the physical column matches migration 0031's `varchar(10000)`, content is ≤10,000 database characters,
    which is up to **20,000 JS UTF-16 units** for astral input. That gives ≤ ~5.7 M UTF-16 units of row strings for BMP
    content and up to ~10.7 M for all-astral content (≈11–21 MB as two-byte strings), plus per-row object overhead.
  - Pre-0031 TEXT would allow 65,535 bytes per note. Source metadata does not prove the physical schema, and
    `schemaCheck` does not check varchar lengths.
  - B7 verifies **only the owned fixture's** actual column metadata (`information_schema`) and materializes its
    maximum permitted Unicode rows (fictional astral content), recording the measured size.
  - No production claim; no query, schema or migration change.
- **No preflight count query.** It would race the read, could not improve that hard ceiling, and would need a DB
  change.
- **Measured conservatively on the strings the renderer prints**, after the read and before `notesPdf`. The fixed
  64-per-note / 128-header overhead must be proved ≥ the actual displayed date/tag/pin/attachment/header strings by
  the B2 displayed-string oracle; it is not called exact. Selection, order and
  renderer are untouched. The measure covers every note's content, tag and attachment name **and** the header (the
  estate name, which has no app-level length cap, plus `String(fileNumber)`).
  - **Printed characters** = Σ UTF-16 lengths + 64 per note + 128 for the header.
  - **Line breaks** = every UAX#14 mandatory break that PDFKit honours: LF, VT (U+000B), FF (U+000C), CR (a CRLF counts
    once), NEL (U+0085), LS (U+2028) and PS (U+2029).
  - **Wrap segments.** A conservative subset of PDFKit's own UAX#14 break opportunities, each rule verified at Gate A
    against the installed `linebreak@1.1.0` with pure probes:
    1. Mandatory breaks end a segment.
    2. After a run of U+0020 spaces, the segment ends when the next character is a letter, digit, CJK or emoji
       character and the character before the run is not opening punctuation (`\p{Ps}` or `¡ ¿ „ ‚`).
       - Verified for every printable ASCII predecessor and for é Ж 漢 📌 NBSP » « ’ ” “ – — …, before a, Z, 5, é, Ж, м,
         Ω, ع, א, ਪ, ह, ก, 漢, 가, 📌 and Ａ.
       - The only non-breaking predecessors were `( [ { ¡ ¿ （ 「 《 „ ‚`.
    3. A boundary falls between a letter/digit/ID character and an ID character (CJK ideographs, kana, Hangul
       syllables, fullwidth forms, emoji) in either order. It never falls next to ZWJ, combining marks, variation
       selectors, skin-tone modifiers or closing/infix punctuation.
       - Verified: 漢字, ab漢, 漢ab, 📌📌, ab📌, 📌ab, 가나다, かな, ＡＢ and `@@`→📌 split; `@@‍📌‍📌`, `@@`+U+FE0F and `@@、`
         stay joined.
    4. Everything else stays in the segment: NBSP/U+2007/U+202F/U+FEFF glue, tabs, Cyrillic/Greek/Thai letter runs,
       combining marks. So the measured attack (`@`×50 + 949 zero-width Cyrillic/combining letters) remains one
       segment.
  - **Longest segment** ≤ 1,000 UTF-16 units.
  - **Long-segment budget** Σ L² over segments with L > 49 ≤ 10,000,000.
    - Below 50 characters PDFKit never enters its long-word chop loop (49 widest glyphs fill 504 pt).
    - The loop costs ~L²/2 width evaluations per word, measured at ≤0.49 s for ten worst-mix 1,000-unit words at the cap.
- **Strings only.** Only string values are measured (`typeof v === "string"`), and the check never fails closed on a
  NaN sum. A malformed row — accepted T12 passes `content: Symbol(...)` and expects 500 + one report + `TypeError`,
  `notesExportRoute.audit.test.ts:791-805` — still reaches the renderer's existing 500 path. An R8 case pins that.
- **No dependency.** `linebreak` is only a transitive pdfkit dependency (not importable without a dependency change),
  so its behaviour is approximated conservatively, never imported.
- **Residual false refusals (disclosed):**
  - unbroken tokens over 1,000 units (pasted `data:` URIs, JWTs, base64);
  - Thai or other spaceless non-ID scripts with runs over 1,000;
  - estate names over ~987 characters.
  The estate export includes the same selected notes, but under its own limits and dependencies; no guaranteed
  alternative retrieval is claimed.
- **Over any cap → refuse the whole export (413 S_LARGE).** Never a shorter note set. Empty notes, a missing name or a
  null file number are always in budget. In the rare case where the estate name itself breaks a cap, the same refusal
  applies (disclosed).

### 6. Refusals: statuses and copy (P4)

| Condition | Status | Bearer toast | Cookie-native page | Report | Audit |
|---|---|---|---|---|---|
| Global or account leases full, process rate, a render window, tracking cap, pre-render timeout | 503 | S_BUSY | S_BUSY + "Status 503" | no | none new (an issued idor write continues) |
| Account rate | 429 | "Request limit reached for this action. Please wait a moment and try again." | same (`PAGE_SENTENCES[429]`) | no | no |
| Over an input cap | 413 (sibling parity: the estate export refuses deterministic oversize with 413) | S_LARGE | S_LARGE + "Status 413" (without the `FIXED_SENTENCES` entry the page would show "The request is too large.", as the estate export's page does today) | no | no |
| Start ACK non-true (existing D4) | 503 | existing sentence | existing | one | started attempted |
| Start ACK timeout | 503 | S_UNCONFIRMED | S_UNCONFIRMED | no | started pending; a late `true` → one terminal |
| Send deadline passed (P9) | – (headers already sent) | a truncated transfer is the client's own "incomplete" GENERIC | browser download failure | no | `failed` with `send_deadline` (recorded before the destroy) |

Proposed sentences:
- S_BUSY: "Notes export is busy. Please try again in a moment."
- S_UNCONFIRMED: "The document was generated but its audit record could not be confirmed. Please try again."
- S_LARGE: "These notes are too large to export as one PDF."

**Why they must join `FIXED_SENTENCES`.** On the cookie-native path, `renderDeliveryError` shows a sentence on the
navigation page only if it is in `FIXED_SENTENCES`, otherwise `PAGE_SENTENCES[status]`. A busy 503 would then show
"The document was generated but could not be audited", which is false, and a 413 would show "The request is too
large.", which blames the request. The Bearer path already shows any JSON `error` verbatim, so there are **no client
edits**.

**Retry.**
- Bearer: the button re-enables at once.
- Cookie: "Return to ProbatePro", reopen the estate's Notes tab, then retry. The page has no estate link; changing that
  is a client edit and is not proposed.

### 7. Non-preemptible work and memory (disclosure)

- The render (46-102), the concat (49) and the sha256 (186) run on the shared event loop with no preemption.
- The bounds are:
  - the input caps (measured ≤ ~0.6 s for single worst shapes, ≈1.1–1.2 s stacked estimate; re-measured at B6);
  - the render-time windows (per aligned window ≤ 15 s + 3·R_max process-wide and ≤ 6 s + 2·R_max per account; any
    60 s span ≤ 2× that);
  - the leases.
- Typical exports block for 0.05–0.3 s.
- **Peak memory is an estimate, not an enforced bound:** ~40 MB render transient (one render at a time; single-shape
  observations) + ≤3 live PDFs (≤1.3 MB each observed) + up to 3 × ~11–21 MB of rows (conditional) during refused
  oversize reads ≈ ~100 MB, versus ~1.7 GB possible today. The B6 combined-cap vector measures the real same-process
  peak; until then these figures are labelled observations/estimates.
- **Rule 29:** `notesPdf` 43-104 stays byte-identical (P6).
- No worker, monkeypatch or renderer rewrite. Removing the block entirely would need one: a separate decision.

### 8. Exact file and interface scope

**`server/notesExportRoute.ts`** (uniform CRLF; Edit keeps it)
- Imports.
- `notesExportHandler` becomes the thin wrapper (gate A + `try/finally`). Exports stay exactly `['notesExportHandler']`.
- The body (150-213) moves into `async function exportNotes(req, res, lease)` at the same indentation.
- **Exact edit map** (current line numbers):
  - **Modified:**
    - 112 (return type) and 115 (`void` → `return`) in `notesOutcome`;
    - 149 (the wrapper plus the `exportNotes` signature);
    - 153 (auth wait);
    - 163 (lookup wait plus the late-foreign chain);
    - 166-174 (idor write tracked and waited);
    - 181 (notes-read wait);
    - 191-196 (the started write captured as a promise for the late guard; `bytes`);
    - 204 (`bytes`);
    - 205 (the wrapped settle).
  - **Inserted:**
    - after 161 (A: the global lease into `holder`, then F);
    - after 184 (K);
    - around 185 (render timing and the charge; line 185's text is unchanged);
    - before 191 (`const bytes = pdf.length`);
    - after 196 (the timeout branch);
    - after 205 (the P9 timer).
  - Every other moved line keeps its exact bytes. A task-owned `frozen-regions-task11.cjs` hashes the frozen regions
    and every moved line that is not in this map.
- `notesOutcome` returns the terminal write instead of `void`; the guard is unchanged.
- Line 195 `bytes: pdf.length` → `bytes` (a `const bytes = pdf.length` computed just before), also used in `sent`, so a
  pending start write cannot pin the PDF (§4).
- Frozen regions stay byte-identical; hashes are checked by a task-owned `frozen-regions-task11.cjs`.

**New `server/notesExportLimits.ts`** (LF)
- Leases, windows, pruning, `settleWithin`, the printed-text measure, constants, and the test-only hooks.

**`server/_core/deliveryRouter.ts`** (uniform CRLF)
- Only `FIXED_SENTENCES` (45-54) gets the three sentences (P4).

**Existing tests (P7)**
- Two inserted lines each: an import of `resetNotesExportLimitsForTest` beside the existing
  `resetExportReportWindowsForTest` import, and the call right after it in `beforeEach`.
  - `notesExportRoute.audit.test.ts` (LF): call after line 188.
  - `downloadRoute.test.ts` (MIXED): import after line 88, call after line 1494. Byte-exact Node splice using the
    neighbouring lines' terminators, with an EOL census before/after.
- Every existing assertion is kept. `deliveryBearerAuth.test.ts` needs no edit (its notes requests stay under the
  windows); if red evidence shows otherwise, stop and ask.

**New tests**
- `server/notesExportLimits.test.ts` and `server/notesExportRoute.limits.test.ts` (LF).

**QA only, under `.work/hybrid-remediation/task11/claude-pass01/`**
- `before/` copies;
- golden runner copy (saving PDFs for geometry);
- `frozen-regions-task11.cjs`;
- fault adapter copy with injected **hold** modes for reads and denial/start/terminal writes, plus its offline
  self-check;
- native harness and launcher copies;
- UI server/launcher copies with new `sourceHashes`;
- browser plans.

**Not touched:**
- `docgen.ts`, every renderer and preview builder;
- `shared/*`, schema and migrations;
- `db.ts`, `affidavitHistory.ts`, `sdk.ts`, `trpc.ts`;
- `exportFailureReporting.ts`, `failureReporting.ts`, `estateExport.ts`, `downloadExportsRoute.ts`;
- `index.ts` (edge limiter), the client, `references/*`, `RULES.md`, vault, memory files.

## 9. Verification (after Gate B approval)

**Vocabulary:** Task 10's labels — recorder invocation / acknowledged / durable row; mocked writer, unconfigured
database, injected driver fault, injected hold, real-engine lock; injected emission. Plus:
- **lease counters** (the test-only snapshot);
- **caller-wait timeout vs settled work:** asserted separately, never inferred from one another.

**Common rules**
- QA bounded waits (10–25 ms polls up to 2 s unit / 15 s native/browser) run before assertions and cleanup. Under fake
  timers `vi.waitFor` advances time, so the route deadlines are set explicitly through the test hook.
- Every locker, socket, server, deferred, timer, arm and browser is released in `finally`.
- `audit_log` is append-only and recorded exactly. Only this run's own fictional estates, notes and `failure_reports`
  rows are removed, by id.
- Fixture evidence is MySQL 8.4.11/InnoDB only (production is described as TiDB).

**B0 — preconditions** (stop and ask on any failure)
- Branch/HEAD/index.
- Porcelain 78/67 plus Task 11's own files.
- Every fingerprint plus the Task 10 manifests (4/4, 36/36, 24/24).
- Protected client hashes.
- No listener on 43117/43316; `ListAgents` shows no busy peer in this worktree.
- New `task11/claude-pass01/` with `before/` copies, sha256, Node EOL census, `prior-work.diff`, and frozen-region
  hashes.

**B1 — golden capture before any edit (G1–G7).**
- The Task 10 harness via a task-owned runner: same environment whitelist, `TZ=America/Vancouver`, `vi.setSystemTime`
  (no fake timers).
- The seven cases through the real route; PDFs saved for page geometry (`render-pdf-pages.py`, PyMuPDF).
- Compared with Task 10's `golden-before.json` hashes:
  - empty `7f5eeb6a…`;
  - one `01477791…`;
  - pinned `6907622b…`;
  - tags `ea37b631…`;
  - multi-page `a61f10d2…`;
  - attachment `03b64d44…`;
  - emoji `816b5b9d…`.

**B2 — red.**
- First add an inert stub `server/notesExportLimits.ts`: the planned API, always admits, measure returns zeros, hooks
  and snapshot present, not wired into the route. The suites then load, and every case fails on its own assertion
  instead of at module load.
- Route cases also assert observable effects (statuses, writer and pdfkit spies, timers).
- Run `run-gates.cjs claude-task11-red1 focus --test-file=…` (expect exit 1) and record per-test failures.

Unit — `notesExportLimits.test.ts` (counters asserted directly):
- **U1 global leases:** 2 and 3 admitted, the 4th refused; max = 3; exactly one finalization.
- **U2 account leases:** 2 admitted, the 3rd refused while held, including when held only by unsettled tracked work;
  another account admitted.
- **U3 account rate:** 11, 12 admitted, 13 refused; reset at the window edge; refused attempts not counted.
- **U4 process rate:** 29, 30 admitted, the 31st refused across ≥3 accounts; reset.
- **U5 render windows:** charges below / at / above 15 s and 6 s; reset; an account refused while others are admitted.
- **U6 map:** churn → size ≤ 2×30+3; forced hard cap → busy; live entries never pruned.
- **U7 tracking:** fulfilled / rejected / never-settling. The lease stays live; no `unhandledRejection`; no track after
  finalization.
- **U8 `settleWithin`:** in-time value and rethrown rejection; timeout then late fulfil/reject; no unhandled rejection;
  the snapshot's armed-timer counter (incremented on arm, decremented on clear or fire; it covers `unref`'d timers)
  back to 0.
- **U9 measure:** counts, including CRLF; below / equal / above each cap; empty notes, a missing name and a null file
  number admitted.
- **U10 linebreak differential oracle** (QA only; resolves pdfkit's installed `linebreak` by its pnpm path inside
  `.work/…/task11/claude-pass01/qa/`; never a production import or dependency):
  - Over a bounded, reviewed corpus covering every UAX#14 class pair present in the measure's rules (AL, NU, ID, CJ,
    H2/H3, JL/JV/JT, CM, ZWJ, EB/EM, GL, SP, BA/BB/B2, HY, CL/CP/IS/SY/EX/NS, OP, QU, IN, SA, plus astral and
    combining sequences) and every attack found at Gate A:
  - assert that **no measured segment boundary falls inside a linebreak word**, so the quadratic charge never
    undercounts.
  - Any counterexample stops B3 and is reported.
- **U11 displayed-string oracle** (QA only): reconstruct the renderer's actual header, date (`toLocaleDateString` with
  the route's options, under the pinned locale/TZ and a worst-case date), tag label, pin prefix and attachment line
  (`notesExportRoute.ts:53-88`). Assert that the measure's fixed 64-per-note / 128-header overhead plus counted
  tag/attachment lengths is **≥** the displayed strings for every tag (including custom 64-char tags) and for
  pinned/unpinned notes, and that the break and segment metrics cover those strings. The measure is called
  conservative, never exact.

Route — `notesExportRoute.limits.test.ts`. Task 10 drivers: `installDeliveryRoutes`, supertest, raw sockets,
`HandBuiltResponse`; mocked sdk/db with no new db export, spied writers:
- **R1 in-budget parity:** statuses, headers, started/finished hashes, filename and D1 identical to Task 10 T1/T10.
- **R2 global busy:** three leases held by deferred writers across ≥2 accounts (accounts cap at 2). An authenticated 4th
  → 503 S_BUSY after authentication (JSON, and the page with "Status 503"); no lookup, audit or report. An
  unauthenticated, suspended or malformed 4th still gets its ordinary 401/403/400 (P12 "After auth").
- **R3 account limits:**
  - the 3rd concurrent same-user → 503 while another user → 200;
  - the 13th within a window → 429 (JSON, and the page showing the 429 sentence);
  - foreign attempts count;
  - an over-budget foreign attempt → 429 with no `getEstate` and no idor.
- **R4 waits:** a never-settling auth/lookup/read → 503 at the wait. The lease stays live (counters) until the deferred
  settles. Then a healthy retry succeeds; no report.
- **R5 denial wait:** idor pending past the wait → 403/404 at the deadline, exactly one idor invocation, lease held.
- **R6 start-ACK timeout:**
  - 503 S_UNCONFIRMED (JSON, and the page with the sentence and "Status 503", never the old audit-failure sentence), no
    Content-Disposition, `end` never called with the PDF, no report;
  - late `true` → exactly one failed/`start_ack_timeout` with the same hash/bytes/attemptId;
  - late `false` → nothing;
  - both guard orderings.
- **R7 settle-inside-wait parity:** Task 10 T3/T4 matrices unchanged.
- **R8 caps:**
  - below / equal / above each of the four caps;
  - above → 413 S_LARGE (JSON, and the page with the sentence and "Status 413") with no PDFDocument constructed, no
    started write, no report. The pdfkit constructor spy's implementation is re-armed after `vi.resetAllMocks()`,
    because vitest 2.1.9 resets it to `() => undefined`;
  - every UAX#14 break kind (LF, VT, FF, CR, CRLF-once, NEL, LS, PS) counted; NBSP-glued runs counted as one run;
    CJK/emoji-only notes admitted; a pathological estate name refused;
  - equal → 200 with the complete PDF.
- **R9 response-held lease:** after `end(pdf)` the lease stays live until `close` (delayed-flush `end` spy, the
  `downloadExportsRoute.test.ts:786-808` pattern).
- **R10 disconnects:** before render, during start, after the acknowledged start → Task 10 terminals; leases finalize.
- **R11 hygiene:**
  - Task 10's route-listener identity checks still pass, and no listener is added on refusal or destroyed paths;
  - no unhandled rejection; no live timer.
- **R12 isolation:**
  - `enforceCostlyRouteLimit` counts unchanged after notes saturation (probed directly, since its tRPC path is VITEST-exempt);
  - Task 15's unsettled count is unaffected by Task 11 refusals;
  - notes CRUD procedures succeed while exports are saturated.
- **R13 identity** (its own file, using the real sdk and minted tokens like `deliveryBearerAuth.test.ts`): cookie A +
  Bearer B spends A's budget; an invalid cookie + Bearer → 401 with nothing counted.
- **R15 render windows through the real route:** account render budget set to 1 ms through the labelled test hook.
  - One 200 export → the snapshot shows render ms > 0.
  - The same account's next attempt → 503 S_BUSY while another account → 200.
  - The same for the process window.
- **R16 cross-feature** (labelled): while one user holds 2 leases and another account the 3rd, via deferred starts:
  - a Generate-anyway `POST /api/download/form` with missing data → 200;
  - `/api/download/export` for estate and package → 200;
  - a letters/package mutation and an upload mutation succeed;
  - notes CRUD succeeds;
  - `enforceCostlyRouteLimit` counts are unchanged.
- **R14 send deadline:** a real stalled transfer — a raw-socket client that never reads, with a test-hook-shortened
  deadline and a body larger than the socket buffers.
  - Expect exactly one `failed`/`send_deadline`, never `finished`; the lease released; no second response.
  - A normal send clears the timer. A spy on `end` cannot reproduce the synthetic `finish`, so it is not used as the
    proof.

**B3 — implement** (§8 only; replaces the stub).
- The EOL census, frozen-region hashes and `git diff` against `before/` give the Task 11 delta.
- The `downloadRoute.test.ts` splice is verified with GNU `diff` with and without `--strip-trailing-cr`.

**B4 — green.** Focus runs on the new suites plus:
- `notesExportRoute.audit.test.ts`, `deliveryBearerAuth.test.ts`, `downloadRoute.test.ts`;
- `downloadExportsRoute.test.ts`, `_core/deliveryRouter.test.ts`, `_core/trpc.ownership-audit.test.ts`;
- `exportFailureReporting.test.ts`, `affidavitHistory.test.ts`, `notes.test.ts`.

**B5 — mutants** (QA-only, byte-exact restore, receipts). Each must be killed by a unit or route test (native runs
come later, in B7):

| Mutant | Killed by |
|---|---|
| M1 release the lease at caller timeout | U7, R4, R6 |
| M2 account gate after the lookup | R3 |
| M3 race without rejection handling | U8, R11 |
| M4 late `true` with no terminal, or two terminals | R6 |
| M5 refused attempts counted | U3 |
| M6 map never pruned | U6 |
| M7 caps checked after render | R8 |
| M8 global lease taken after the account gate or after the lookup (the account counted, or a lookup done, while busy) | R2, R3 |
| M9 timer not cleared | U8 |
| M10 report on Task 11 refusals | R2, R3, R6, R8 |
| M11 response reference dropped at `end` | R9 |
| M12 `finally` instead of `then(done, done)` | U7 |
| M13 render not charged | R15 |
| M14 a new `res` listener | R11 |
| M15 timed-out lookup proving foreign writes no idor row | R4 variant |
| M16 the send deadline recorded as `finished` (destroy before settle) | R14 |
| M17 the late-ACK chain not tracked (only `startAck` tracked) | R6/U7 ACK-after-return case |
| M18 the started-write closure reads `pdf` again | QA retention check |
| M19 one new sentence dropped from `FIXED_SENTENCES` | R2, R6, R8 page assertions |

**B6 — freeze and measurement.**
- Re-run the realistic and adversarial matrix at the approved caps (§5), sequentially and bounded (≤90 s and ≤800 MB
  per probe process). The old unbounded gigabyte/71 s attacks are never run.
- **Mandatory combined-cap vector**, in one selected set of ≤500 rows: ~500 k printed units with 20,000 mandatory
  breaks and ten worst-mix 1,000-unit segments at Σ L² ≈ 10 M (or a recorded proof that some maxima are mutually
  incompatible).
  - It runs through the real route while **two earlier exports from other accounts hold their PDFs** at the start-ACK
    barrier (deferred writers), and the third renders.
- **Named barriers**, each recording input metrics, final bytes, live leases, `heapUsed`, `external`, `arrayBuffers`
  and RSS:
  - `B-base` (before the requests);
  - `B-read` (after `listEstateNotes`);
  - `B-render` (after `notesPdf` returns);
  - `B-hold` (two PDFs held at the start-ACK barrier while the third renders);
  - `B-send` (after `end`);
  - `B-settled` (all leases finalized).
- **Stop metric (defined).** Stop and ask Nick if either:
  - the synchronous render block (`performance.now()` around the call) exceeds **2.0 s**; or
  - the **incremental `external + arrayBuffers`** from `B-base` to `B-hold` exceeds **64 MB**.
  Whole-process RSS (baseline already ~65–110 MB) is recorded, not gated.
- The results replace the §2/§7 estimates in the handoff. Figures that are not measured stay labelled
  "estimate/observation".
- Re-run the golden cases: byte-equal to B1 and to Task 10's hashes; geometry unchanged.
- Any difference is reported, never normalised.
- Frozen-region and protected hashes unchanged.

**B7 — native fixture** (owned fictional MySQL 8.4.11 only; fixture UI stopped first because the harness refuses
peers)
- Task 10's guarded launchers and identity checks, task-owned copies; real pool; real router on
  `listen(0, "127.0.0.1")`; minted fixture sessions; raw sockets; server-side `setHeader`/`end` spies.
- Write barrier: root REPEATABLE READ `SELECT id FROM audit_log FOR UPDATE`, identified via processlist and
  `data_lock_waits`, released by ROLLBACK in `finally`.
  **Used only for** notes waiting, late ACK/late failure, blocked-session counts and unrelated reads that need no audit insert. It blocks every audit_log insert, so it can never prove cross-feature availability (forms and exports need their own audit ACKs through the same writer: affidavitHistory.ts:483-503, 611-640; downloadRoute.ts:387-404; downloadExportsRoute.ts:122-144).
- Never-settling reads use the task-owned **injected hold** mode. `LOCK TABLES` on `estate_notes` would stall
  authentication (FK to `users`), so it is not used.

| Case | Expected | Label |
|---|---|---|
| N1 Saturation | Two or three users block at the started INSERT: ≤3 app sessions executing the blocked INSERT (processlist statement + `data_lock_waits`; idle pool rows are not counted). The 4th → 503 S_BUSY immediately. An unrelated `getEstate`/notes list answers in <1 s (Task 15 prior art). | real engine |
| N2 Start deadline + late true | The three get 503 S_UNCONFIRMED with 0 client bytes. Locker released at ~12 s (before the 50 s InnoDB timeout) → three started rows + three failed/`start_ack_timeout` rows. Leases finalize; a healthy retry → 200 and hash = row. | real engine |
| N3 Late false | The locker is held past `innodb_lock_wait_timeout` (50 s, recorded) → the started write fails: no started row, no terminal, no report. Lease released at settlement. This case alone uses a labelled bounded wait of the recorded timeout + 20 s, asserted ≤120 s. | real-engine lock timeout |
| N4 Denial under lock | Foreign estate → 403 within the wait; the idor row appears after release | real engine |
| N5 Account rate | 13th within a minute → 429; a foreign 13th leaves no idor row | real engine |
| N6 Caps | Oversize fictional sets (each cap) → 413 with no started row. The maximum in-budget set → 200 and a complete PDF. In-process heap/RSS and the render duration recorded and compared with §2. | real engine + QA measurement |
| N7 Held read | Injected hold on `listEstateNotes` → 503 at the wait; lease held until release; then healthy | injected hold |
| N8 Disconnect inside the wait | `aborted` (Task 10 N6 parity) | real engine |
| N9 ACK lost after persisting | Task 10 N5b parity | injected |
| N10 Cross-feature availability | Under a labelled **notes-start-only injected hold** (task-owned fault adapter matching only `notes_delivery_started` INSERTs; no global audit lock), two accounts saturate notes. The same user and another account then run the real routes: a Generate-anyway form delivery with missing data, a package/estate export, notes CRUD and an upload. Each must answer successfully **and** its required audit ACKs/rows must be verified. Only owned holds/rows are released, in `finally`. | injected limiter-isolation evidence (labelled separately from real-engine saturation) |

**B8 — build and real browser** (busy is produced by the same labelled notes-start-only injected hold, never by the global audit lock, with ≥2 accounts holding leases).
- Task 10's UI-server variant copied with new `sourceHashes`; manifest-verified assets; `cdp.cjs` with `allowAndName`
  and `MSYS_NO_PATHCONV=1`.
- Sessions only from `/__fixture/login` and `?mode=bearer`.
- Saturation is produced by QA-held starts (labelled).

| Run | Checks |
|---|---|
| B1 Cookie-native in-budget | Download = capture = audit hash |
| B2 Bearer in-budget | Download = network body = capture = audit hash |
| B3 Cookie-native busy | The page shows S_BUSY + "Status 503"; no file. After release: Return, reopen the Notes tab, explicit retry → file. |
| B4 Bearer busy | The toast shows S_BUSY verbatim; the button re-enabled; retry after release → file |
| B5 Bearer oversize | The toast shows S_LARGE; no file |

- No console errors.
- Task 13 D11/D12 observed, not changed.
- An uncertain click is never replayed.

**B9 — full gates.**
`& 'C:\Program Files\nodejs\node.exe' '.work\hybrid-remediation\run-gates.cjs' claude-task11-pass1 check tests chatbot-check chatbot-tests build render`.
- The label is checked unused first.
- Runs in the background (~13 min); read `RUNNER_EXIT` and `results.json`, never `tail`; `FROZEN_LEGAL_SOURCES_UNCHANGED`
  is not a success signal.
- Bind the counts to the final hashes.
- Recheck the build manifest against the browser evidence.
- Never run `server/storage.live-uat.test.ts`. A pass1 worker-exit recurrence → fresh label plus an isolated focus run,
  recorded, never relabelled.

**B10 — independent read-only reviews** (general-purpose agents on Opus, model passed explicitly):
- V1 resource/cancellation semantics;
- V2 security/IDOR/privacy and D1;
- V3 freeze/integrity (`probate-integrity-gate`, re-pointed at this worktree);
- V4 a claims audit of `final-status.md`.

Only Task 11 findings are fixed; the affected proof is re-run under fresh labels.

**B11 — handoff:** `final-status.md` (every item in prompt §10), an append-only queue evidence entry with the box
unticked, and stopping only this session's processes. **Stop.** No acceptance, no SHIP, no Task 12.

## Connected-feature matrix

| Feature | Shared resource | Contract after Task 11 | Recheck |
|---|---|---|---|
| Notes privacy / selection | `estate_notes`, pool | Own notes only; LIMIT 500 newest-first unchanged; nothing read before auth + admission + ownership | R1, R3 |
| Notes CRUD (`notes.*`, same 500-row list query) | pool, event loop, auth upsert | Untouched; usable while exports are saturated; mutation/uploads counters untouched | R12, N1 |
| PDF output / empty notes | – | Byte-identical; empty always in budget (a pathological estate name aside) | G1–G7, R8 |
| Auth / sessions | sdk, pool (users write) | Unchanged; the account key is the server user id | R13; `deliveryBearerAuth.test.ts` |
| Guard, parsers, body caps, edge limiter | – | Unchanged; body caps not raised | router suite |
| Start audit (D2/D4) | `audit_log` | Strict `true`; D4 on non-true; timeout = S_UNCONFIRMED | R6, R7; N2, N3 |
| Transport (Task 10 listeners) | response | One guard, identical listener sets, no second response; lease held to `close` | R9–R11, R14 |
| Denial audit (D1) | `audit_log` | One write per admitted foreign attempt; statuses unchanged | R3, R5; N4, N5 |
| Task 15 reporting | `failure_reports`, its caps | Code unchanged; Task 11 adds no report; notes never uses the report budget as its export budget | R12; `exportFailureReporting.test.ts` |
| `document_generation` (forms, packages, exports; hybrid D2) | in-memory bucket | Never read, spent or reset by notes | R12 |
| Estate export / letters / packages | pool (estate export issues 13 parallel queries), memory, loop | Their guards unchanged; notes keeps ≤3 lease-owned pending DB operations and a bounded render share (nothing reserved for them) | N1, N10 |
| Uploads | `uploads` bucket, loop | Untouched | full gates |
| Forms / Generate anyway | pool, loop | Missing data stays warn-only; notes budgets never block generation | full gates |
| Navigation / tRPC | pool (2 auth operations each), loop | Bounded by leases + render windows | N1 |
| Client (Task 13 D11/D12) | – | No client edit; sentences verbatim (Bearer) or via `FIXED_SENTENCES` (cookie) | B1–B5 |
| Generated-byte non-retention | – | No storage/document/activity write. After a refusal or timeout no continuation holds the PDF (scalar-only captures, precomputed `bytes`; structural gate P11). The socket's copy is counted until `close`. GC observations are recorded only as observed/inconclusive. | R6, N2, V1 |

## Limits that remain after Task 11 (disclosed, not solved)

- **No cancellation (P5).** A DB call that never answers keeps its lease, possibly indefinitely, so notes stays busy
  (503).
  - Notes' own pending work is capped at 3 lease-owned operations per process (plus Task 15's separately capped ≤2
    report writes).
  - No pool connections are reserved for other routes. Other work can still occupy or queue for the shared pool, whose
    real size (`DATABASE_URL`) and production engine (TiDB) are not verified.
  - A silently dead DB peer may take OS keepalive time (minutes to hours) to surface.
- **First-come-first-served process caps (security review).** Notes export (only notes export) can be starved by a
  few authenticated accounts:
  - 2 accounts with stalled or slow readers can hold all 3 leases for up to the send deadline (P9) per attempt;
  - 3 accounts can exhaust the 30/min process rate, even with cheap 404/403 attempts;
  - 3 accounts can exhaust the 15 s/min render window with near-cap exports;
  - notes-path authentication DB work is bounded only by the 200/min/IP edge limiter, like every route (P12 "After auth").
  - Notes never spends other features' budgets. It bounds its own share of the shared pool, event loop and memory, but
    reserves nothing for them, and the starvation thresholds above apply to every user's notes export.
  - Each threshold is tested (R2, R3, R15) and disclosed rather than solved. Authentication itself is shared infrastructure and is
    not lease-bounded (P12 "After auth").
- **Process-local** per replica (autoscale; the replica count is unknown). Production pool parameters and the TiDB
  engine behaviour are not verified.
- **Fixed windows** allow up to 2× a window's rate across a boundary. Per aligned window, render time is ≤ 15 s +
  3·R_max (process) and ≤ 6 s + 2·R_max (account); any 60 s span is ≤ 2× that. R_max is the measured worst render
  inside the caps.
- **Auth/lookup DB work** is bounded only by the global lease; `sdk`/`db` are unchanged.
- **The read before the caps** is bounded only by LIMIT 500 and the column caps (migration 0031 assumed).
- **Audit storage** still grows over time; only creation is rate-bounded. Retention is a separate policy/schema
  question for Nick.
- **Existing behaviours not changed by this task:**
  - the per-IP edge limiter's raw-JSON 429 on cookie navigations;
  - the `recentAttempts` map shared across routes;
  - the cookie refusal page's link to `/`;
  - emoji/CJK printing as zero-width `.notdef` (a legibility issue, frozen);
  - CreationDate second-resolution nondeterminism (frozen; the golden harness pins the clock).
- **Carried forward:**
  - L2, L3, F1/O1;
  - denial timing (Task 10 §12: a foreign-alias 404 waits for its idor write; sibling parity). H bounds the wait but
    keeps the difference.
  - `references/file-storage.md:117` (Task 17);
  - the Task 9/13 runtime-message validation and Dev/Preview body redaction;
  - P10 carry-over, the tab-remount panel loss, the preview gap;
  - chatbot cookie-to-fetch rotation;
  - Task 15's browser gap; the pass1 worker exit;
  - Safari/iOS/Android; Word/pixels;
  - the Task 6/14 limits; every AWAITING-NICK item.

## Repository preferences (recorded for future models)

Sources: `docs/superpowers/plans/2026-10-25-task11-handoff-preferences.md` (15 items; referenced, never overwritten),
the Task 11 prompt §2 rules 1–8, and Task 10's list.

1. Task 11 only. Plan first, and get Nick's explicit approval before any application edit. No Tasks 7/8, 12 or 17, no
   hybrid Step 4, no automatic next task. Save the plan; stop.
2. Only `C:\Users\nick\probate pro\probatepro-hybrid-review`, branch `security/hybrid-vault-review`, HEAD
   `db0d7e9161bc3899b75858fab58bce54e3d5247a`; verify at execution.
   - Preserve the dirty tree and every file's per-line EOL class (MIXED: `affidavitHistory.ts` 472/173, `db.ts`
     2377/169, `downloadRoute.test.ts` 2124/42; census in Node, not Git Bash grep).
   - No stage/commit/reset/stash/push/merge/branch/worktree/checkpoint/publish/deploy.
   - Never change another Manus project or domain, or touch a production worktree.
3. Rule 29 freezes legal and notes PDF output.
   - No wording/format/rendering/legal/form-selection change.
   - No `docgen.ts`, renderer, preview builder, `shared/types.ts`, schema, migration or capture edit.
   - Preserve the affirmed default, the lawyer-signing model, capitalized defined terms, spaced citations, and no
     fabricated sworn facts.
   - A non-text buffer-control change inside a renderer needs its own approval naming the exact region.
4. Preserve the four approved output behaviours (P2 current-P9 selection, P9 current-P1 Exhibit A re-render, P8
   primary-affidavit override, package/exhibit reconstruction) and every AWAITING-NICK deferral.
   - There are no "three Rule 29 exceptions".
   - Unused-field hiding is not authorized.
5. Missing data stays warn-only, with Generate anyway/draft/blank. Admission, audit acknowledgement, authentication and
   authorization are separate boundaries. A finite budget never blocks missing data.
6. Absolute production/AWS/data isolation:
   - no production DB/storage/records/accounts, AWS/S3/STS/KMS/vault credentials, policy inspection, secret/env display
     or external writes;
   - never configure `AWS_*`, `STORAGE_S3_*` or `LEGAL_RECORD_STORAGE_APPROVED`;
   - Task 19 stays separate.
7. No dependency/toolchain/lockfile/configuration upgrades or installs. No Office retry, settings change, unrecognized
   process stop, peer fixture takeover or uncertain click replay.
   - Prove fixture ownership, build identity and no busy peer before mutations.
   - Port numbers are not identity.
   - Never inherit a DSN or reuse another user's browser or profile.
8. Keep this list and every new approval in the repository plan and evidence. Never overwrite RULES.md, receipts or
   dispositions. Post-save notes are append-only.
9. Task 10 is accepted/done (2026-10-25 08:10 PDT; tracking, not SHIP). Preserve:
   - D1–D4, the controlled 503 and the strict-`true` ACK;
   - one-terminal scheduling and safe privacy fields;
   - owned listener cleanup and its exact listener sets;
   - Task 15's at-most-one report.
10. Task 13 is done within scope. Preserve:
    - its Notes feedback (D11/D12);
    - the cookie/Bearer paths and rotation/refusal hardening;
    - the display-only VSA532 rule.
    No client edits by default.
11. Address real pending work, not just caller waits.
    - `Promise.race` is not SQL/CPU cancellation.
    - Never recycle a live-job permit early.
    - Never erase append-only audit history.
    - Creation-rate limits are not retention or cluster-wide enforcement.
12. Each of the following needs an explicit decision: numeric limits, precedence changes, the deadline/late-outcome
    policy, refusal wording, and renderer plumbing. No shared-pool/global-audit refactor, filename fix or partial
    export is implied.
13. Distinguish historical, fresh, real-engine, injected, mocked and user-closure evidence, and report every gap.
    - No skipped failing regression, new legal snapshot or PDF metadata normalization.
    - Real UI and native evidence.
    - No SHIP or acceptance without Nick.
14. Independent budgets: notes never spends or resets `document_generation` or the Task 15 staff-report counter.
    - **Requirement (handoff #14):** saturation must not interfere with other accounts, forms/Generate anyway,
      letters/packages, notes CRUD, uploads or navigation.
    - **Task 11 status against it:** notes spends no other feature's budget and bounds its own share. But the shared
      pool, event loop and memory are not reserved for others, and the P12 during-auth and first-come process-cap
      starvation of other accounts' **notes** exports is disclosed in Limits.
    - Neither is claimed fully satisfied until Nick decides P12 and B7/N10 provide evidence.
15. Keep open:
    - F1/O1, Task 17 docs;
    - runtime-message/body redaction;
    - P10 carry-over, preview/panel behaviour;
    - Task 15's browser gap, the pass1 incident;
    - Safari/iOS/Android, Word/pixels.
    No silent AWAITING-NICK resolution.
16. `audit_log` is append-only in the fixture. Remove only this run's own QA estates, notes and report rows, by exact
    id. Never modify seeded rows. Never print private fixture credentials, session tokens, request bodies or real
    client facts.
17. Operational:
    - Never pipe `run-gates.cjs` through `tail`; read `results.json`.
    - Run the six gates in the background (~13 min).
    - Pass an explicit model when dispatching subagents-140 agent definitions; use general-purpose reviewers on Opus.
    - Every QA launcher sets `VITEST=true`, so no VITEST-gated exemption may hide a limit.
18. Workstation hygiene (2026-10-25 ~08:45 PDT): commit headroom fell to ~2.6 GB of 65 GB with ~137 Python + 34 uv MCP
    processes running. Keep concurrent agents/probes few and bounded; never stop processes this session did not start.

## Review record (for future models)

Source prompt: `outputs/claude-remaining-tasks/09-task-11-notes-resource-bounds.md` (Task 11 only), plus
`docs/superpowers/plans/2026-10-25-task11-handoff-preferences.md`.

**Decisions (Nick, 2026-10-25, plan-mode questions; each answer was the recommended option):**

| Question | Answer | Records |
|---|---|---|
| Precedence (per-account check vs estate lookup) | "Before lookup (Recommended)" | P1 approved |
| Input caps (500k chars, 20k breaks, segment 1,000, ΣL² ≤ 10M) | "Measured caps (Recommended)" | P2 input caps approved. The other §2 values (leases 3/2, rates 12 and 30 per minute, render windows 15 s/6 s, waits 15 s/10 s) were not separately asked in round 1; Nick approved them "As proposed (Recommended)" in round 2. |
| Start-ACK wait / late outcomes | "503 + late record (Recommended)" | P3 approved (incl. the late-foreign idor write and the `start_ack_timeout` literal) |
| Refusal copy | "New notes sentences (Recommended)" | P4 approved (three `FIXED_SENTENCES` entries) |

**Decisions, round 2 (Nick, 2026-10-25, after the r1 review; plan-mode questions):**

| Question | Answer | Records |
|---|---|---|
| P12 global-lease placement | "After auth (Recommended)" | P12 approved: the lease is taken after authentication/suspension/body, immediately before the account gate |
| Remaining §2 numbers | "As proposed (Recommended)" | Leases 3/2, rates 12/30 per 60 s, render windows 15 s/6 s, 15 s pre-render wait, 1,000-entry tracking cap approved |
| P9 send deadline | "Yes, 300 s (Recommended)" | P9 approved under the §4a ordering contract |
| Remaining proposals (multi-select) | "P11 scalar bytes, P8 no new reports, P5 no cancellation, P7 reset hooks" | P5, P7, P8, P11 approved |

- **Previously open, now answered** (kept for the record):
  - **P12 (global lease placement)**, split from P1 by Nick's r1 review;
  - the remaining §2 numbers: leases 3/2, rates 12/30, render windows 15 s/6 s, the 15 s pre-render wait, the
    tracking cap;
  - P5, P7, P8, P9 (300 s send deadline), P11.
- The 10 s start wait is part of the answered P3 and is not re-voted. P10 (D2 untouched) is recorded as affirmed by
  Nick's review. Former P6 is a requirement.
- Every design decision is now answered. Gate B (B0–B11) still requires Nick's separate, explicit go-ahead.

**Nick's review of r1 (2026-10-25; plan-mode exit declined), verbatim:**

> The plan's intent is sound: bound notes-export resource use without changing selected notes, PDF output or accepted Task 10/13 delivery behavior. Keep the signed-off four choices and the proposed small notes-only lease design. Do not approve Gate B yet. The outstanding issues concern approval mapping, a send-timer ordering gap, overstated capacity/memory guarantees and a confounded native test—not a reason to rewrite the renderer or reopen other tasks.
>
> This reviews the complete 752-line attached pasted_content_14.txt, current relevant source and two independent read-only checks. No application gates, services, heavy PDF probes or database queries were run by this review. Claude's measured timings/peaks in the plan remain attributed measurements, not independently reproduced results or production guarantees.
>
> Current identity: Branch security/hybrid-vault-review; HEAD db0d7e9161bc3899b75858fab58bce54e3d5247a; index empty. Task 10 and Task 13 remain accepted for tracking with retained limits. Nothing here closes Task 11 or gives SHIP/production approval.
>
> What to retain: The four choices remain: account gate after authentication/strict body and before estate lookup; input caps 500,000 printed units / 20,000 mandatory breaks / longest segment 1,000 / long-segment ΣL² 10M; a ten-second unconfirmed-start response with one correlated failed terminal after a late positive ACK; three notes-specific fixed sentences without the estate-export pointer. Keep the complete notesPdf raw region and the single render call unchanged. Keep the fixed-clock seven-case PDF byte-golden comparisons against both the immediate before-state and Task 10. Keep current selected-note filtering, createdAt DESC, LIMIT 500, filename, form/renderer/schema/client freeze, strict-true start ACK, owned listeners and one-terminal scheduling. Whole-chain tracking of late start/foreign-lookup continuations is the right approach. Tracking terminal writes instead of detaching them, and precomputing scalar bytes, are appropriately scoped plumbing proposals. They still require the approvals and proof below.
>
> Required revisions: 1. Approval blocker: global-before-auth is a separate choice, not approved P1 … Explicitly ask Nick to accept or decline the latter, including the busy-before-auth response and possible notes starvation while authentication is pending. Do not declare full per-account fairness or unaffected other-account notes service while that exception remains. This is not permission to refactor SDK/auth or use an unverified token's account claim as authoritative identity. 2. High: caps do not reserve a minimum number of pool connections … claim only the supported per-process maximum of lease-owned pending database work, plus the separately bounded Task 15 reporter … Any actual reservation/isolation design needs separate approval; do not inspect production credentials or change the global pool to make this claim pass. 3. High design gap: specify safe send-deadline arm/clear ordering … Use one idempotent clear/settle path. Add tests for destroyed-at-send-entry, synchronous finish/close and synchronous setup failure with zero unnecessary armed timers; preserve Task 10 listener identities/once-guard. On deadline, select and track failed/send_deadline before destroying, as intended. Timer expiry does not cancel the SQL terminal write. 4. High proof gap: proposed input caps do not yet establish the numerical peak/work guarantee … combined/same-process peak vector with two prior PDFs retained …; clarify what the ">64 MB" stop condition measures …; QA-only differential oracle using PDFKit's resolved installed linebreak dependency …; reconstruct actual displayed header/date/tag/pin/attachment strings … do not call slack "exact"; conditional materialization … varchar(10000) database characters also need not mean 10,000 JS UTF-16 units for astral input …; GC observation, not timing guarantee … Label GC evidence observed/inconclusive. 5. High verification flaw: the global audit lock invalidates N10's cross-feature availability proof … Use a separate labelled notes-start-only injected hold for cross-feature availability … verify required audit ACKs/rows as well as responses.
>
> Remaining proposals and approvals: Do not turn the four answers into blanket Gate B approval. Global-before-auth precedence/fairness, numerical rates/leases/render windows, the 15-second pre-render wait, 300-second send deadline and other P5–P11 items still need the exact recorded answer where not already covered by P1–P4. The ten-second start wait is already part of the answered late-ACK choice; do not unnecessarily re-vote it. P5: no cancellation is an honest narrow-scope option, with potentially indefinite occupied permits disclosed. It is not equivalent to fixing stuck SQL. P6: retaining the entire renderer is required, not a new output-change approval. P7: test reset hooks are reasonable if they never reset live leases and preserve all assertions/EOLs. Give the 12/minute product limit a user/workload rationale, not only "an existing test needs 11 calls." No environment exemption should hide enforcement. P8: no reports for new busy/rate/oversize/timeouts fits the chosen timeout option; preserve the existing definite non-true ACK report and distinguish it from timeout uncertainty. P9: the proposed 300-second send deadline needs the corrected race/cleanup tests and explicit approval. P10: hybrid D2 remains untouched. P11: precomputed scalar bytes is appropriate; use the corrected structural retention proof, not a GC guarantee. The estate archive includes the same selected notes at estateExport.ts:131, 185, but still uses its own limits/storage/audit dependencies. Do not restore the rejected estate-export pointer or claim guaranteed alternative retrieval under every saturation scenario. This is not permission to truncate or alter the existing note set.

(The full review text, including its per-line references and all five revision items, is kept in this session's
transcript. The excerpt above preserves every decision and requirement verbatim, with "…" marking only elided
supporting citations.)

**Gate A process record**
- Investigation: six read-only streams plus a completeness critic.
- Adversarial plan review in four lenses: runtime, security, compliance, numbers. It found two HIGH runtime defects
  (send-deadline audit, late-ACK tracking), one security HIGH (fairness disclosure), one compliance HIGH (header run
  scope) and one numbers BLOCKER (caps defeated at 36.5 s). All are fixed in this text.
- Budget re-measurement: a measurer plus an adversary. Segment rules verified against `linebreak@1.1.0`.
- The adversary's 5M recommendation was an unexecuted estimate; the measured worst at 10M is ≤0.49 s.

## Gate A save record (appended when saved, 2026-10-25)

- **Approval.** Nick approved this plan at the plan-mode exit on 2026-10-25, shortly before 12:08 PDT. Under "Approval
  gates" above, that authorizes only this save, its SHA-256 report and a stop.
  - **Gate B (B0–B11) has not started** and still needs Nick's separate, explicit go-ahead.
  - Task 11 is not accepted; no SHIP claim; Task 12 is not started.
- **State at save (read-only checks):** branch `security/hybrid-vault-review`, HEAD
  `db0d7e9161bc3899b75858fab58bce54e3d5247a`, index empty, one pre-existing stash, porcelain 78 modified / 67 untracked
  before this file. `server/notesExportRoute.ts` is unchanged (`52b07b23b15cf220…`). No application file was edited.
- **Byte identity.** Lines 1–1132 of this file are the approved session plan, unchanged: 93,381 bytes, LF, SHA-256
  `d9e253b2b9d31a3b12f09d2fa7329d3c2173c77974ddd24ce3f90d9c75db957c`. This section is the only addition. It follows
  preference 8 ("Keep this list and every new approval in the repository plan"; post-save notes are append-only).
- **Save-time errata.** Found while saving; not corrected in place. Where one of these lines conflicts with the recorded
  decisions (the approval labels in the decisions table, "Decisions, round 2" and Nick's r1 review), the recorded
  decisions control, and Gate B follows them.
  1. Line 1 says "plan r1". The approved text is r2 (status block, line 3).
  2. Line 301 (P2) still calls leases 3/2, rates 12/30 per 60 s, render windows 15 s/6 s, the 15 s pre-render wait and
     the 1,000-entry tracking cap "Proposed, not approved". Nick approved them in round 2 ("As proposed
     (Recommended)").
  3. Lines 302–303 (P3, P4) carry no approval label; both were approved in round 1. Line 303 still offers the S_LARGE
     estate-export pointer, which Nick's review withdrew. P4 is the three §6 sentences, without the pointer.
  4. Line 465 (§4) says retention "is proved with a QA-only `FinalizationRegistry` / `--expose-gc` check". P11
     (line 310) and Nick's review item 4 supersede it: the structural gate is the proof, and GC runs are recorded only
     as observed/inconclusive. M18 (line 834, "QA retention check") therefore also needs a structural killing test,
     not only a GC observation.
  5. Lines 610–611 (§8) predate P12. The wrapper only creates `holder` and runs `try/finally`; step A runs inside
     `exportNotes` after authentication, whose signature is `exportNotes(req, res, holder)` (lines 320, 326).
  6. Lines 757–758 (R4): under P12 no lease exists during authentication. A never-settling auth answers 503 at its
     wait with zero live leases and nothing counted. "The lease stays live" applies to the lookup and the notes read
     only.
  7. Line 970 (Limits) says auth DB work "is bounded only by the global lease". Under P12, notes-path authentication
     work is bounded only by the 200/min/IP edge limiter, as the first-come bullet in the same section says. The
     lookup is lease-bounded.
  8. Line 1057 (preference 14) still waits "until Nick decides P12". P12 is decided; the B7/N10 evidence condition
     still stands.
- **Open question for Gate B (not decided here).** Line 369 (§2) times the 15 s pre-render wait "from admission" and
  lists C, but under P12 authentication (C) runs before admission, and line 323 says C runs "within the pre-render
  deadline". Either authentication gets its own 15 s wait from handler entry (worst case ~30 s before render), or a
  single 15 s deadline runs from entry. Nick's answer is needed before B2 encodes either reading.

## Gate B go-ahead record (appended 2026-10-25)

- **Nick, verbatim** (received shortly before 12:28 PDT, replying to the Gate A save report): "proceed with
  recommendations /orchestrate-swarms /orchestrate specialized agents with optimal skills for each task
  /zizi-skills:find-skills".
- **Recorded as** the go-ahead for Gate B (B0–B11), taking the recommendation below for the one open question. It is
  not acceptance; there is no SHIP claim; Task 12 is not started.
- **Open question → recommendation adopted.** The 15 s pre-render wait is one deadline measured from handler entry,
  shared by C (authentication), G (lookup), H (denial audit) and J (notes read). The worst case before rendering
  therefore stays 15 s, as in r1, where admission happened at entry. Line 369's "from admission" reads as "from
  handler entry". The 10 s start-ACK wait (M) is separate and unchanged.
- **Routing.** Implementation stays in the main session (no subagent edits). Read-only workflows map the Task 10
  harnesses and run the B10 reviews. Installing new skills (`npx skills`) is out of scope, because the task forbids
  tool installs.
- **Workstation at go-ahead.** 494 MB free RAM and 2.9 GB commit headroom, with 124 Python and 55 Node processes this
  session did not start. Heavy steps (B6, B7, B8, B9) re-check headroom first and stop rather than run degraded.

## B6 stop-metric erratum (appended 2026-10-25)

- **What fired.** The B6 combined-cap run `combined-2` (receipt
  `.work/hybrid-remediation/task11/claude-pass01/qa/measure-combined-combined-2.json`) measured the memory stop metric
  as line 855 defines it: the incremental `external + arrayBuffers` from `B-base` to `B-hold` was 75.7 MB, over
  64 MB. The render block was 987 ms, under 2.0 s. Work stopped there and Nick was asked.
- **Why line 855 double counts.** In Node, `process.memoryUsage().arrayBuffers` is already part of `external` (the
  Node docs say of `arrayBuffers`: "This is also included in the external value"). Checked directly on this
  workstation (Node v24.13.1): allocating one 50 MB Buffer raised `external` by 50.00 MB and `arrayBuffers` by
  50.00 MB. So the line 855 sum counts every Buffer twice. combined-2 measured `external` +37.8 MB (7.7 → 45.5) and
  `arrayBuffers` +37.9 MB (1.7 → 39.6).
- **Nick, verbatim** (2026-10-25). Asked: "The B6 memory stop rule fired: 75.7 MB measured as the plan defines it
  (heap-external + array buffers), but 37.8 MB once the Node double count is removed. Render passed at 0.99 s. How
  should I proceed?" Answer: "Fix the formula, continue (Recommended)". That option read: "Record an erratum:
  external already includes array buffers, so the metric is external growth alone, still raw and without GC at
  B-hold. 37.8 MB passes. Continue to B7."
- **Corrected metric (replaces line 855).** The incremental `external` from `B-base` to `B-hold`. `arrayBuffers` is
  recorded but not added. The reading stays raw: no forced collection at `B-hold`, so it still includes
  unreclaimed garbage. The threshold stays 64 MB. combined-2 = 37.8 MB, so it passes. The 2.0 s render threshold
  (line 854) is unchanged and passed at 987 ms.
- **Nothing else changes.** No cap, lease, window or code change follows from this erratum. The 75.7 MB reading
  stays in the record. Every B6 figure is an observation on this workstation (one process, Node v24.13.1), not a
  hard bound. The B6 summary is `.work/hybrid-remediation/task11/claude-pass01/measure/b6-summary.md`.

## B10 review fix record (appended 2026-10-25)

- **Finding V1-F1.** Raised by B10 reviewer V1; the verifier CONFIRMED it and rated it LOW. The main session
  reproduced it and re-rated it HIGH.
  - §5's rules 1–4 were not a conservative subset of linebreak 1.1.0's breaks. Its LB21a implementation
    ("HL (HY | BA) ×") keeps its state across space runs, absorbed combining marks and an explicit newline.
  - So "Hebrew letter, then hyphen or break-after character" glues the next space run, and a chain of such units is
    one PDFKit word. U10 checked single adjacencies only.
  - Before the fix, one 9,964-unit note shaped that way passed every cap and rendered in 2.07 s; three took 5.77 s.
    49 fit the printed-units cap, which extrapolates to about 94 s. That was not run.
- **Fix, within the approved design.** The measure stays a conservative, dependency-free approximation. No cap,
  decision or file outside `server/notesExportLimits.ts` changed.
  - A fifth rule: no segment ends where linebreak's LB21a state suppresses the break.
  - The measure follows that state machine with three tables derived from linebreak over every code point: Hebrew
    letters, hyphen or break-after characters, and linebreak's own combining-mark class. That class is exact, not
    the measure's wider joiner kind.
  - The fixed measure only removes boundaries, so it admits a subset of what it admitted before.
  - A stateful QA oracle, U10b, supplements U10: 0 violations in 42,650,815 strings.
- **New residual false refusal (disclosed).** Hebrew text whose words are chained by hyphen- or dash-and-space units is
  measured as one word, which is how PDFKit wraps it.
- **Evidence:** `.work/hybrid-remediation/task11/claude-pass01/review/dispositions.md`, and the native re-run on the
  final bytes, `claude-task11-native3`.
- **Not an approval change.** It records that the implementation now meets §5's stated intent. No acceptance and no
  SHIP claim; Task 12 is not started.

## User decision record — Task 11 accepted (appended 2026-10-25 18:08 PDT)

- **Nick, verbatim:** "mark accepted". He sent it after B8 (real browser) passed, while the V4 claims audit of
  `final-status.md` was still running.
- **Recorded as:** Task 11 accepted/done by Nick's decision for remediation tracking. It is not a SHIP or
  production-readiness approval.
- **Limits.** Every limitation and deferral in `final-status.md` §15, and in the queue's disposition, stays open.
- **V4.** Its corrections are applied to `final-status.md` as document-only edits.
- **No change made.** No code or test change follows from this record. Nothing was staged, committed, pushed,
  published or deployed. Task 12 is not started.
