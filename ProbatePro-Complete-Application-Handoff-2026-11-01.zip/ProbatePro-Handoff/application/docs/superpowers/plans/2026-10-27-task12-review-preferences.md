# Task 12 review preferences — 2026-10-27

This is a non-authoritative review handoff record for consistency across models. It records standing instructions and review boundaries, not Gate B approval or task acceptance. The supplied plan r3 remains a proposal.

1. Review only the user-specified Task 12 material. Do not start implementation, read/execute a next-task prompt, reopen another task or perform hybrid Step 4 without explicit instructions.
2. Preserve the approved P1 tested preview-only split-link factory and P1a mechanical rotated-session-handler move. Do not request a reversal solely because another reviewer prefers fewer lines.
3. Preserve the approved provisional 4 MiB decoded preview envelope limit, 16 KiB refusal-body limit, 15 s body idle and 60 s body total, pending the bounded fictional measurement. Keep current header/transport retry defaults; do not increase to 8 MiB silently.
4. Preserve P3 safe public text, P4 terminal client failures/neutral cancellation, P5 abort-aware wait and cleanup, P6 subscription-based close cancellation. Validate actual observer/link/body behavior, not only mocked options or enabled flags.
5. P7 cache defaults are conditional on correct stale/ownership behavior. P8 requires previous-session result suppression without breaking normal rotation; a logout-only counter must not be described as comprehensive account-switch protection. Expose unsupported identity cases for a decision rather than waive them.
6. Keep Task 13 residuals and global logging changes out of scope as approved. No new sensitive error causes, raw preview bodies, headers, tokens or console trail. Preserve explicit DOCX download handoff after modal close; no generation replay.
7. Keep missing data warn-only and Generate anyway usable. Malformed transport data is distinct from legitimate blank/empty draft content; reject malformed data whole without changing, filtering, normalizing or inventing legal content.
8. Freeze prescribed wording, citations, fields, tables, geometry, jurats, signatures, DOCX/PDF/print/preview rendering and legal/form selection. Do not edit renderer/schema/official-capture/shared legal-type files; preserve mixed-module frozen regions exactly.
9. Maintain absolute isolation from production, real client data, AWS/vault/policies/credentials, environment values and migrations. No installs, deployment, publication, checkpoints or Git index/history changes.
10. Distinguish current source checks, library-source inference, pure offline checks, estimates, planned/injected tests and real UI/native evidence. Browser cancellation is not a server compute deadline; envelope-byte probes are not heap measurements.
11. Probe/build/fault-adapter/QA/mutant steps must have non-circular provenance and run on their stated artifact. Use a fresh stable baseline and only owned fictional fixture resources after approval. Do not mark pending checks passed.
12. Word/pixels remain user-deferred-not-passed. Keep other recorded evidence limitations open; do not clear them to award Task 12 acceptance or SHIP.
13. Current queue evidence shows Task 11 accepted by Nick and Task 12 unchecked. Historical prompt/preferences retain their capture-time caveat; this review does not alter either task status.
14. Return a revised plan addressing supported findings and wait for explicit Gate B go-ahead. No automatic next task, implementation or acceptance follows this review.

Only review documentation and task-specific working evidence may be written in this review. No application, original prompt, existing preferences, queue or Git index edits are authorized by it.
