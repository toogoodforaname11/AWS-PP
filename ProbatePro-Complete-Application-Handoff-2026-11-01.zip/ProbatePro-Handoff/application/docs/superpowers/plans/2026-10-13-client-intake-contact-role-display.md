# Client Intake Contact Role Display Repair

**Task date:** 2026-10-13
**Scope:** Correct the Contacts tab presentation of contacts created from a client intake submission. This is a display-and-safe-default repair only.

## Confirmed defect

The Contacts tab rendered `contactRoles(c)` directly in role badges. A client-intake-created family contact therefore displayed the persisted internal token `client_reported_person`. The same row could display an `unknown` executor-status badge because the application default used that placeholder for every created contact, including non-executors.

## Repair

1. Add a curated display label for `client_reported_person` in the shared client label helper.
2. Render contact-card role badges through the helper rather than printing stored tokens.
3. Treat an executor status as relevant on a contact card only for executor, alternate-executor, or applicant roles. For an executor whose status is empty or legacy `unknown`, show one neutral `status not set` signal rather than the stored token.
4. Preserve the existing `unknown` persistence default required by older non-null database schemas, but never expose that internal placeholder to the lawyer-facing contact card.

## Explicit exclusions

- No reclassification of client-reported people into beneficiary, executor, spouse, or other legal roles.
- No inferred executor status or change to court-form selection logic.
- No change to contact facts, linked records, portal authorization, submissions, or documents.

## Acceptance checks

- A `client_reported_person` role displays as **Client-reported person**.
- A non-executor contact with legacy `executorStatus: "unknown"` displays neither an executor-status badge nor the raw role token.
- An executor with empty or legacy unknown status keeps a clear **status not set** prompt.
- Existing user-facing role labels remain unchanged.
