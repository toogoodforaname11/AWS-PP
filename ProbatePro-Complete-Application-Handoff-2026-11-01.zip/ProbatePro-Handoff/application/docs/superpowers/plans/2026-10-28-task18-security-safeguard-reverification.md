# Task 18 — Reverify security safeguards — Gate A plan r4 (investigation complete; Gate A save authorized; Gate B NOT authorized), 2026-10-28

**Status (r4, 2026-10-28, Gate A complete and saved on Nick's authorization):** Nick's 2026-10-28 decision ("Finish Gate A
and save the plan only, subject to these corrections. This does not authorize Gate B or accept Task 17/18.") authorized
only this save. The Gate A investigation is complete: identity verified, governing files read (including Nick's
2026-10-28 review-preferences record, review report and the two independent review reports, §2), the source census
proven byte-equal to the Task 17 Gate A census, nine read-only tracers returned (D/G/H from `wf_0d42a336-cf8`; A/B/C/E/F/I
from the relaunch `wf_46ca40c4-b18`, §4.3), the three-lens panel folded (§13), the raw tracked-diff review ledger closed
hunk by hunk with the critical consumer reads (§4 item 6; `diff-review-ledger.md`), and Nick's two rounds of corrections
folded (§13 addenda). This text is saved as the authoritative plan with the Gate A evidence (§14) and the session
**stops**. Task 17 stays implemented/not accepted and Task 18 is not accepted; nothing here accepts either. Gate B starts
only on Nick's separate, explicit go-ahead after this save; answered design questions alone do not start it. At no point
of Task 18 is any application, test, schema, configuration, renderer, policy, legal, queue or predecessor file written;
Gate B produces evidence and reports only, and a defect found is reported, never repaired.

Queue item 18 only (`docs/superpowers/plans/2026-10-21-hybrid-remediation-queue.md:62`). Not in scope: Tasks 19/20,
hybrid Step 4, the implementation of Tasks 14/6/7/8 (their implemented boundaries are inspected and their gaps reported;
nothing is repaired, closed or re-required), acceptance of Task 17 or of anything, SHIP, policy clearance, compliance or
Canadian-processing assertions, any git write, any AWS/production/`.env*`/Office/install action.

## Approval gates

1. **Gate A — this plan (done 2026-10-28).** The save (§14) writes this text as
   `docs/superpowers/plans/2026-10-28-task18-security-safeguard-reverification.md` (new, untracked, LF) and the fresh
   pass directory `.work/hybrid-remediation/task18/claude-pass01/` with the source census, fingerprints, the diff-review
   ledger and patch, the proof matrix, the tracer returns, the test inventory, the fixture inventory, the known-gap
   register and the gate-a notes; reports their hashes; stops. Nothing else is written.
2. **Gate B — execution (§8–§9).** Only after Nick explicitly approves the saved plan and says to proceed, and only after
   the Task 17 prerequisite question (§12 Q1) has his explicit answer. No repairs; a nonzero gate, a hash drift or a
   fixture identity mismatch stops the step and is reported.
3. **Acceptance** belongs to Nick. The queue entry is drafted in the handoff only; it is appended or ticked solely on his
   authorization. No SHIP verdict (Task 20), no policy clearance (Task 19), no hybrid Step 4.

## Capability routing (find-skill, recorded)

| Phase | Capability |
|---|---|
| Gate A investigation | Main session: own reads of RULES.md Rules 28–29, `.cursorrules`, the queue (structure, Task 6/12/15 dispositions, erratum), the Task 17 closeout receipt, `references/file-storage.md` (all 377 lines), `docs/runbooks/storage-incident.md`, the four accepted-task acceptance receipts, Task 6 repair status, Task 15 final status, the fixture launchers (`start-ui.cjs`, `ui-server.ts`, `mysql-fixture.cjs`), `run-gates.cjs`, `render-freeze.ts`, and the row-anchor source lines (`storageProvider.ts:30-110, 180-265, 688-758`; `_core/env.ts:40-255`; `_core/deliveryRouter.ts:160-261`; `downloadRoute.ts:170-320`). Nine parallel read-only `Explore` tracers (Workflow, Read/Grep only, no edits, no tests, no services): rows A–F, fixture/runner inventory, known-gap register, test inventory. `code-review-graph` consulted (§2). |
| Gate A design check | One three-lens read-only `Plan` panel over this draft (coverage/completeness; overclaim and evidence-class; freeze, isolation and safety), Read/Grep only, no Bash (memory: a Bash call in a Plan agent can hang on a permission prompt). Dispositions recorded in §13 before the save. |
| Gate B execution | Main session runs the gate runner, the fixture and the journeys (nothing delegated that executes); one bounded read-only reviewer reconciles the matrix with the final hashes (B8). |

Routing rows applied (`capability-routing.md`): "Security audit → security-reviewer + owasp-top10-expert + security-scanner"
(row 40) and "Code review → code-reviewer + security-reviewer" (row 32) for the lenses; "Testing → test-runner" (row 43)
for Gate B. Orchestration triggers fired: multi-domain (storage, delivery, client, notes), research + synthesis,
producer + validator, high stakes. The subagents-140 specialist files pin a retired model id, so the built-in `Explore`
and `Plan` types are used (memory). The `/orchestrate-swarms` skill's plugin did not load in this session (unmet
dependency); the `orchestrate` and `find-skill` skills were applied instead. The Agent Archive setup hook was skipped per
Nick's recorded decision (queue `:810`): no external account.

**Skills recommended (find-skill format, advisory):** `superpowers:writing-plans` (this plan), `superpowers:verification-before-completion`
(Gate B), `probate-integrity-gate` (B8 lens, briefed for this worktree's RULES.md), `security-audit` (lens vocabulary only;
no scanner run), `code-review-graph` MCP (tracked symbols only). Agents: `Explore` (tracers), `Plan` (lenses),
general-purpose for the B8 reviewer. Orchestration: parallel tracers → single-session execution → one reviewer.

## 1. Context

Steps 0–3 of the hybrid vault were implemented and then remediated by queue Tasks 3, 16, 4, 5, 14, 6 (+repair), 15, 9,
13, 10, 11 and 12; Task 17 re-documented the implemented contract. No pass has re-verified the whole safeguard set
against the final working tree with fresh gates since the last implementation task (Task 12's `claude-task12-pass2`), and
Task 17 ran no application check at all. Task 18 is that reverification: for each safeguard row (A role split and purge
chokepoint; B fail-closed profile and encryption; C namespace, manifest and lifecycle authorization; D generation,
replacement and delivery integrity; E client authentication, CSRF and truthful outcomes; F generated-byte non-retention and
connection checks) establish, on the current bytes, what the source does, what the existing tests prove (positive and
negative), what the fictional fixture can show, and what only a deployment could prove — then run the full serial gates
and the frozen-output check, and hand the result to Nick with every known gap carried forward. Goal: a reproducible,
hash-bound statement of which safeguards are preserved as implemented, which gaps are known, which items are not exercised
and which need deployment evidence, with no overclaim.

## 2. State verified at planning time (2026-10-27, read-only)

**Workspace.** `C:\Users\nick\probate pro\probatepro-hybrid-review`, worktree of `probatepro`, branch
`security/hybrid-vault-review`, HEAD `db0d7e9161bc3899b75858fab58bce54e3d5247a`; porcelain 168 entries (85 `??`); index
empty; one shared stash entry (`700f9a9 On main: Safety backup before P9-P10 commit and sync 2026-09-06`; not ours, never
touched; no `git stash` of any kind in this task); three worktrees (main, this, `p9-p10-sync-20260906`); `core.autocrlf=true`.
`.work/hybrid-remediation/task18/` does not exist → `claude-pass01` is free; no gate label starting `claude-task18-` exists.

**Prompt and preferences.** The pasted prompt is `outputs/claude-remaining-tasks/12-task-18-security-safeguard-reverification.md`
(155 lines, sha256 `9beac0839163f06fcbd48902fa317c2cdc5f66b51bdced1203a32529e337a572`); the preference record is
`docs/superpowers/plans/2026-10-27-task18-handoff-preferences.md` (sha256 `f48870f19a4185aa55f25f17d533bb0ab98cc1c11c1719aec80e663fabb30401`).
Nick's review of r2 added, on 2026-10-28, `docs/superpowers/plans/2026-10-28-task18-review-preferences.md` (26 lines,
sha256 `87452f6d2de44b431b1097e29520a69aa259023fddaa6c7101597c7ad651ef68`; fourteen handoff requirements, read whole),
`outputs/task18-plan-review-2026-10-28.md` (24 lines, sha256 `083eeef88486f2350df7f00e42e626c0eb6a20f279ba106bbb8a426c6b11afdc`)
and the review-working evidence under `.work/task18-plan-review-2026-10-28/` (two independent review reports, read whole;
baseline, excerpts and verification receipts, hashed in the census; none edited). All are advice; authority stays with
Nick's explicit decisions and the queue. The porcelain count is 169 at the save (the three Task 17 documentation
targets now ` M`, the two preference records `??`).

**Task 17 handoff hashes (re-hashed now).** `outputs/task17-documentation-report-2026-10-27.md` `d012dc6a…` (match);
`.work/hybrid-remediation/task17/claude-pass01/final-status.md` `f8885fe3…` (match); `manifest.sha256` `bd8824a9…`
(match); `references/file-storage.md` is now `91cf8da8cd70ba91b8bef6c2d28ab64377e9d0f9d5ae6e5494d87cae1644e3ed`, not the
handoff's `cf80d461…`: a legitimate later update (line 179 only, twice, during Nick's 18:39 PDT closeout; recorded in
`task17/claude-pass01/closeout.md` §2 and `post-receipt-closeout.diff`). The handoff hashes are a dated record, not an
instruction to restore old bytes. Queue `e7c6c07c181b644333ce50b54dbe118b7c4e7c7ab0a3978c0f9ccb1cf36440b9` (852 lines,
LF; equals the closeout's recorded hash; erratum at `:840-852`); Task 17 plan `83ad932b…` (542 lines; matches closeout).

**Task 17 disposition (unresolved prerequisite).** Implemented, **NOT accepted**: the closeout's final-fragment review
classed one attribution finding "material, low"; it was corrected; per Nick's condition acceptance was not recorded, row 61
is unchecked, the disposition is drafted only (`closeout.md` §6, §10). Gate A proceeds with this limitation; **Gate B
needs Nick's explicit decision on Task 17 first (§12 Q1)**. Preparing or executing Task 18 accepts nothing.

**Queue state.** Checked: 1, 2, 3, 16, 4, 5, 15, 9, 13, 10, 11, 12 (15/9/13/10/11/12 by Nick's decision with recorded
limits). Unchecked: 14, 6, 7, 8, 17, 18, 19, 20. Tasks 7/8 not reopened (`:432`); Task 6 repairs verified, not accepted
(`:402-418`); Task 14 STILL-BLOCKED on the Word pixel step only (`task14/claude-pass01/STILL-BLOCKED.md`).

**Source identity: byte-equal to the Task 17 Gate A census.** Re-hashing every entry of
`task17/claude-pass01/before-hashes.json` (captured 2026-10-27T23:34:16Z) against the tree now: census 61 equal / 5
differ (exactly the four Task 17 documentation targets and the queue) / 0 missing; cited extras 23/23 equal; test tree
333/333 equal (tree digest `2e134c23bf9f9489614b3f07ed749ae1074893ea89369b6dfe9852b60b1029d0`). Consequence: the
`file-storage.md` citations (re-anchored by Task 17 on these bytes; 449 citations path/range-checked, 101 anchored) and the
three Task 17 tracer reports are path/range-consistent **maps** of the current source (their semantic accuracy was not
re-established by Task 17's checker) — used as starting points only; every matrix
row rests on reads made in this task.

**Frozen and protected sources.** `RULES.md` `648f49a7…`, `.cursorrules` `4d0e0bb9…`, `server/docgen.ts` `7224c88e…`,
`shared/types.ts` `9a60dfb7…`, `drizzle/schema.ts` `25f7c362…` equal the prefixes Task 12 and Task 17 recorded;
`.work/hybrid-remediation/baseline.json` `6f73f857…` carries 55 frozen entries (RULES.md, schema, 23 legal/reference
captures, 27 docgen test files, docgen.ts, 6 shared sources) that `run-gates.cjs` re-checks before and after every gate.

**Instruction files.** No `CLAUDE.md` or `AGENTS.md` exists anywhere in the repository outside `node_modules` (the only
hit is a dependency's own `cytoscape/AGENTS.md`, not an instruction to this project). RULES.md Rule 28 (`:1930-1964`,
credential split, purge chokepoint, region/HTTPS/SSE-KMS, read-the-diff-before-publishing) and Rule 29 (`:1966-1980`,
document freeze, no compliance assertion) read in full; Rule 24 (`:1485-1549`, missing data warn-only, sworn-truth gates
fail-closed) is the warn-only authority. `.cursorrules` (182 lines) adds only "S3 via `storagePut`/`storageGet`; never store
file bytes in the DB" and "read RULES.md before touching docgen.ts".

**Graph.** `code-review-graph` pre-existed this session (built at HEAD on this branch; the session-start hook reported
it last updated 2026-10-27T18:22:19, and its own file-change hook refreshed it at 20:54:33 during Gate A; its store
lives outside the repository's porcelain, which stayed at 168 entries; 75 files, 2,480 nodes, 40,646 edges; 20,311 of
26,257 call edges unresolved; 0 embeddings). It was queried, never built or embedded, by this task. `callers_of providerDeleteExact` returns one direct production call site
(`storageRegistry.ts:1672`, `processStorageDeletionJobs`) and 14 unresolved test-node sites in `storage-s3.test.ts`. The
untracked modules (`_core/deliveryRouter.ts`, `formDeliveryBinding.ts`, `storageNamespace.ts`, `attachmentDelivery.ts`,
…) are not indexed (memory), so every caller trace below is bounded direct tracing (Grep + offset Read); the graph is
recorded, not relied on.

**Vault.** The Obsidian vault has no live ProbatePro item (`BRAIN.md`: none; `DASHBOARD.md:221`: one historical line);
read-only, not updated (project precedent).

**Fixture preconditions found at Gate A (read-only; re-checked at B0; recorded in `gate-a-notes.md`).** No pending arm:
`fixture/audit-fault-next.json`, `capture-next.json` and `preview-fault-next-task12.json` are absent; `captures/` holds only
consumed Task 13 receipts. `dist/public/index.html` exists (built 2026-10-27 11:24, sha256 `8fd43766…`, gitignored) and
**differs** from the hash the fixture last served (`ui-status.json` `7542cd11…`) and from `ui-status-task15.json`
(`d7a955f7…`), so B4 runs only on a bundle built by B2 and recorded then. The bundled
`.work/tools/mysql-8.4.11-winx64/bin/mysqld.exe` and `fixture/db/auto.cnf` exist; `status.json` reads ready (28 tables,
`projectMigrationsApplied: false`, `containsOnlyFictionalData: true`). Nothing listens on 127.0.0.1:43117 or :43316.
The cached QA Chromium (`ms-playwright/chromium-1228`) exists; the Task 13 QA browser (pid 11236) is not running (its
`endpoint.json` is a stale file in the task13 pass, not reused); no `WINWORD.EXE` process exists; no `node` process with
`hybrid-remediation` in its command line is running. `.work/` is one untracked entry (`?? .work/`), so files written under
it never change the porcelain count; `dist/` and `*.log` are gitignored. Ports and old status files prove nothing
(prompt §6); identity is re-proved at run time.

**Own-read tier facts for rows A/B (used in B3).** `_core/env.ts:23-39` seeds, at import time and only when `NODE_ENV`
is `development` or `test`, `VITEST` is unset and no `STORAGE_*` variable is set, a dev-only profile
(`LEGAL_RECORD_STORAGE_APPROVED=true`, `http://127.0.0.1:9000`, `us-east-1`, path style, unversioned). While no `AWS_*`
name is set it leaves the nine-variable dedicated profile incomplete, so the platform store is used; with the six `AWS_*`
names set in development the seeded local endpoint completes the profile and skips the non-local checks (A8, REG-52).
The fail-closed tiers never seed. `_core/trpc.ts:215-226`, `:232-236`: the `VITEST` rate-limit exemption holds only
when `ENV.storageFailsClosed` is false (dev/test tier), never on production or an unset `NODE_ENV`.

## 3. Evidence classes (one legend, used in every row and report)

| Class | Meaning | What it can never prove |
|---|---|---|
| SRC | source inference from lines read in this task, pinned by file hash | deployed behaviour, AWS answers |
| MOCK | executable mock: Vitest with the AWS SDK, STS, signing, `./db` or `fetch` mocked; the command input shape or a mocked response is asserted | an IAM permission, a real 403/404, a real purge |
| UI | real fictional browser against the loopback fixture (headless Chromium on this workstation) | Safari/iOS/WebView; a save on disk; a recipient's receipt |
| NATIVE | real local MySQL 8.4 fixture (`127.0.0.1:43316`, `probatepro_fictional_hybrid_fixture`), identity-guarded | TiDB locking/collation, production pool, migration state |
| FROZEN | frozen package comparison (26 `render-freeze` fixtures; part-level DOCX/XML equality) | rendered geometry or pixels (Word/pixels user-deferred-not-passed) |
| HIST | historical receipt under `.work/hybrid-remediation/` or the queue, valid for the hashes it records | the current row (reused only as explicitly historical) |
| EST | an estimate or nominal figure | a measured bound |
| HTTP | a scripted request against the loopback fixture without a browser (`verify-retained.cjs`, `fetch-post-bearer`, `real-app-http.cjs`) | React rendering, toasts, downloads: a UI requirement met only by HTTP is reported NOT EXERCISED |
| DEPLOY | deployed policy, trust, KMS, bucket, pool or release proof — **Task 19; none produced here** | — |

A valid citation or manifest hash proves artifact identity, not a semantic claim or a security guarantee. A configured
runtime credential path does not prove the deployed role cannot delete; a configured purge path does not prove the real
role lacks read or KMS privileges. The fixture runs `NODE_ENV=development` with the loopback platform-store stand-in and
`failsClosed: false`, so **rows A and B (STS/S3/KMS) are SRC + MOCK only**; the fixture exercises rows C (platform-path
manifest reads through the proxy), D, E and F.

## 4. Gate A method and what it produced

1. Identity and governing reads (§2), by the main session.
2. Source census equality against the Task 17 census (above) — the lever that makes the maps usable.
3. Nine read-only tracers (`Explore`, structured output; no `.env*`, no `*.private.*`, no node_modules globbing): rows
   A–F, G fixture/runner inventory, H known-gap register and preservation contracts, I test inventory and execution-safety
   map. **Tooling incident, recorded:** in the first run (`wf_0d42a336-cf8`, nine in parallel, ≤3 calls per message, Bash
   allowed for `git status --porcelain`/`wc -l`/`sha256sum`) D, G and H returned (20:54–20:59) while A, B, C, E, F and I
   never received the results of their first Read/Grep/Glob batch (transcripts frozen at 20:32–20:34; one shows
   `hook_cancelled` on `PostToolUse:Glob`); after 45 minutes without progress the run was stopped (`TaskStop`) and the six
   were relaunched as `wf_46ca40c4-b18` with Read and Grep only (no Bash, no Glob), two calls per message, three agents
   at a time (wave 1 A/B/C, wave 2 E/F/I); wave 1 progressed normally from 21:24. The completed D/G/H returns are taken
   from the first run's journal (`subagents/workflows/wf_0d42a336-cf8/journal.jsonl`). All returns are saved verbatim as
   `tracer-reports/<key>.json` at the Gate A save and are the source of §5–§7 and §10 below (each row's lines were
   spot-read by the main session before being written here). Memory note to keep: in this host, parallel subagents beyond
   three stall on their first tool batch; Glob triggers a cancellable post-tool hook; keep tracers to Read/Grep.
4. Own reads of the row anchors (routing table) confirmed, before any tracer returned: two fixed-parameter STS
   factories with `DurationSeconds: 3600` and no `Policy` (`storageProvider.ts:65-79, 86-100`), separate cached clients
   keyed by stable configuration only (`:185-225, :231-261`), the purge client "Call ONLY from providerDeleteExact"
   (`:227-230`) and consumed there alone (`:723-758`: runtime proof first `:728`, purge list/delete `:732-752`, runtime
   absence check `:755`); the tier `storageFailsClosed = !["development","test"].includes(NODE_ENV ?? "")`
   (`_core/env.ts:51`) with the fail-closed gate `:218-251` (static credential names rejected `:224-230`, local-UAT
   endpoint rejected `:232-239`, platform fallback only off the fail-closed tier `:240-248`), the full `ca-west-1`
   account-qualified KMS ARN regex `:132` tested untrimmed `:210-213`, identical role ARNs rejected `:152-154`, HTTPS
   except loopback `:162-165`; the delivery guard order 405 → 400 (query) → 403 (Origin exact, `Sec-Fetch-Site`) → 415 →
   413 before any parser (`_core/deliveryRouter.ts:189-218`), parser errors mapped without stack or echo and other errors
   to a class-only log (`:226-237`), trusted origins kept only when https (`:244-248`), loopback only off the fail-closed
   tier (`:169-175`); the form route's order ownership 404/403 (`downloadRoute.ts:176-177`) → binding 409 or 500 on
   `key_unavailable` (`:180-186`) → rate unit (`:190`) → current-row `replayRow` 409 (`:293-299`). Also read by the main
   session after the tracers launched: `storage.ts:40-174` (vault key allocation and manifest registration before bytes
   `:45-100`; `readsFromLegacyPlatform` refusing an `approved_s3` row in platform mode `:112-121`; `privateReadRequest`
   requiring a context `:123-126`; the eight-key public exemption `:146-147`, `:170-171`); `storageRegistry.ts:640-750`
   (`withReadableStoredObjects`: estate FOR UPDATE NOWAIT and literal owner compare `:676-682`, exact-key rows with
   owner/estate/category compare `:686-692`, account and disposition tombstone `:693-701`, identity/lifecycle/byte-metadata
   validity `:703-708`, dispatch while locked `:709-715`, bounded retries and 30 s completion `:717-738`, one generic refusal
   `:741-744`); `formDeliveryBinding.ts:25-124` (TTL, skew, `deliveryInputsHash`, HKDF key, MAC tuple, verify order);
   `_core/index.ts:40-215` (startup block skipped only under `NODE_ENV=development` `:55-76`; delivery headers, CORS
   `origin: false` on delivery paths, the credentialed-origin guard, helmet `same-origin` referrer policy, the two per-IP
   limiters, `installDeliveryRoutes` with `failsClosed: ENV.storageFailsClosed` before the chatbot and the 50 MB parsers
   `:87-211`); `_core/originPolicy.ts:60-94` (the guard acts only on a request carrying both an `Origin` and a named
   session cookie `:89`; allowed when the origin matches the request host or a configured https origin `:60-67`);
   `client/src/lib/attachmentDelivery.ts:325-372` (invalid descriptor → generic sentence before any credential read; pending
   or busy control → suppressed `:334`; no stored token → native form POST and "download requested" `:335-342`; stored
   token → one fetch, "preparing the download…" then "download started" or the refusal sentence, generic text after a
   session change `:343-371`) and `:450-524` (session change or ceiling mid-body halts the read; `Authorization` only when a
   token exists, `credentials: "include"`, `redirect: "manual"`; redirect/non-basic/non-200 refused; media type, exact
   `Content-Disposition`, declared length versus decoded bytes for unencoded bodies, container markers, final
   `sameSession` before handoff); `_core/env.ts:1-39` and `_core/trpc.ts:205-241` (§2 tier facts);
   `storage.live-uat.test.ts:1-40` (`describe.runIf(process.env.RUN_STORAGE_LIVE_UAT === "true")`, real provider imports);
   `storageNamespace.ts:1-93` (32-hex random account/estate/object segments, `VAULT_KEY_PATTERN` `:14-16`, compare-and-swap
   that fills only a NULL with at most 3 attempts `:24-47`, estate namespace only for the owner `:60-71`, extension-only
   contribution from the caller `:74-79`, allocation `:82-93`); `storagePublicAssets.ts:1-13` (a `Set` of eight complete
   keys, exact membership, comment on why suffix matching is forbidden); `_core/storageProxy.ts:1-67` (`normalizeStorageKey`
   or 400; public assets skip authentication; private keys need `sdk.authenticateRequest` (401), a non-suspended user and
   `findAccessibleStoredObject` (else 404 without disclosure; 503 on a lookup error); a server-resolved read context
   `{userId, estateId, category}` is passed to `storageGetSignedUrl`; 307 with `private, no-store` for private keys,
   `private, max-age=240` for public assets; 502 on a provider or gate error); `db.ts:630-667` (`findAccessibleStoredObject`:
   positive integer user id and a key of at most 512 characters, exact key AND owner AND state in `active`/`retained`/
   `pending_reference` AND no disposition, then a literal post-query key comparison that rejects a collation-only match
   `:661`; `userCanAccessStorageKey` is a wrapper with no non-test caller); `storageProvider.ts:483-501`
   (`normalizeStorageKey`: strips leading slashes only, refuses an empty key, more than 512 characters, control
   characters, a backslash, and any empty, `.` or `..` segment; no percent-decoding, no case folding, no trailing-slash
   trimming, so a key is matched as given; `appendStorageHashSuffix` adds an 8-hex random suffix on the platform path);
   `storageProvider.ts:395-470` (`validateAwsCanadaBucketSecurity`: location equals the configured region `:402-406`;
   all four Block Public Access controls `:408-412`; exactly one `BucketOwnerEnforced` rule `:414-418`; a default rule
   with `SSEAlgorithm === "aws:kms"` and `KMSMasterKeyID === kmsKeyId` `:420-429`; a policy, if present, must be the
   approved deny-only one `:431-441`; no replication rule `:443-450`; Object Lock not enabled `:452-459`; absence of a
   subresource is tolerated only via `missingBucketSubresource`; `validateStorageProviderConfiguration:463-470` runs the
   versioning proof on every endpoint and the security proof on non-local endpoints only); `storageProvider.ts:505-554`
   (`providerPutExact`: the platform branch is refused on the fail-closed tier `:515-520` and otherwise presigns a Forge
   PUT with only a Content-Type header `:521-531`; the vault PUT sends `ChecksumSHA256`, `ServerSideEncryption` and
   `SSEKMSKeyId` `:535-543`, requires the algorithm echo whenever SSE is configured `:544-546`, and on non-local
   endpoints requires `result.SSEKMSKeyId === kmsKeyId` `:549-553`); `_core/index.ts:216-248` (tRPC mount; Vite only in
   dev; the lifecycle worker starts in the listen callback outside dev `:234-238`; a startup failure logs `[FATAL]` and
   exits with code 1 `:242-248`).
5. A three-lens `Plan` panel over this draft (§13) before the save.
6. **Raw tracked-diff review ledger — closed 2026-10-28 (Nick's correction 1).** Every untracked task module was read
   whole (no diff exists for them: `_core/deliveryRouter.ts`, `formDeliveryBinding.ts`, `formDeliveryArtifact.ts`,
   `documentReplacement.ts`, `storageNamespace.ts`, `downloadExportsRoute.ts`, `exportFailureReporting.ts`,
   `shared/postDelivery.ts`, `attachmentDelivery.ts`, `fallbackSession.ts`, `previewTransport.ts`, `trpcLinks.ts`;
   `notesExportLimits.ts` partly). Every tracked production and configuration file's `git diff -U0 --ignore-cr-at-eol
   HEAD` hunks were then read by the main session and assigned to a matrix row, a register item or OUT, one line per
   hunk group: `routers.ts` 142 hunks, `EstateDetail.tsx` 64, `storageRegistry.ts` 48, `storageProvider.ts` 47,
   `downloadRoute.ts` 37, `documentAssets.ts` 27, `db.ts` 22, `affidavitHistory.ts` 22, `_core/env.ts` 20,
   `notesExportRoute.ts` 18, `_core/index.ts` 16, `storage.ts` 15, `estateExport.ts` 14, `_core/trpc.ts` 13,
   `_core/storageProxy.ts` 6, `failureReporting.ts` 3, and the small client, shared, schema, config and documentation
   files (the numstat with and without `--ignore-cr-at-eol` is identical: no CR-only noise). The ledger
   (`diff-review-ledger.md`) is saved beside the full-context `diff-before.patch`. No hunk contradicted a row; the diff
   confirmed that prefix-based storage authorization and every `storagePut` of generated bytes are removed, and added
   two nuances (C3: `assertCitationEvidenceKeys` re-validates only changed keys; E11b: the preview DOCX download is a
   `document.generate` plus one bounded fetch). The 39 modified test files were not read as diffs (the matrix cites
   current test source; Gate B executes it). Critical consumer reads closed the same day (details in the ledger):
   `db.createAuditEntry` returns `true` on a resolved insert (`db.ts:2025-2040`) and `recordAuditEvent` accepts only
   `=== true`; the deletion enqueue sites (`storageRegistry.ts:338-340`, `:371`, `:828-883`, `:1215`, `:1631`) change
   state only (A4 holds); no cleanup follows a PutObject echo mismatch (`storage.ts:87-97`, B7 gap);
   `validateLegacyForgeDestructionAuthorization` checks operator confirmation strings and deletes nothing; the signed-URL
   lifetime is clamped to 1–900 s (default 300 s); `registerStoredObjectUpload` inserts the manifest row before any PUT;
   `REFERENCED_AFFIDAVIT_FORMS` is P3–P7 plus P8 and P9; `existingDocs` is the 200-capped `listDocuments`, so the P9
   Exhibit A selection is capped too; an empty session cookie lets Bearer be consulted (static, benign); `auth.logout`
   revokes server-side through `revokeUserSessions` (`sessionVersion + 1`); `versionRowFor` copies the superseded row
   verbatim; no temp-file, copy, multipart or presigned-POST primitive exists in server or client source; the client
   intake stores a text payload, never bytes; React Query runs on defaults (`new QueryClient()`, v5.90.2: a 5-minute
   documented default, `node_modules` not read); the costly-route table is `document_generation` 8/60 s, `uploads`
   12/60 s, `ai_import` 6/60 s; 46 test files name the proxy or preview; `documents`/`document_versions` have no `userId`
   column (ownership is `estates.createdByUserId`).

## 5. Proof matrix (filled from the tracer returns named in §4.3; each row: invariant → callers/consumers → current file:line → tests + / − → native/UI → deployment limit)

Rules for reading this matrix (panel L2-03, L1-01): **at Gate A every "Tests +/−" cell is a read of test source** (SRC of
the test tree, digest `2e134c23…`), not an executed result; a cell becomes MOCK only when B1/B2 execute that file on the
B0 hashes and B7 records the command, count and outcome. **Hash binding:** the saved `proof-matrix.md` carries an
appendix binding every file cited in §5 to its sha256 from `source-before.json` at the save (the rows below cite
file:line; the §2 census statement binds them to the Task 17 hashes until then). "Implemented" means the source lines
read do what the invariant states; it is never "proven" or "passed". Anchors verified by the main session are in §4.
**New observations made by Task 18** (A5 default-chain exposure, A8 dev-tier `us-east-1`, B2 untested localhost refusal,
B5 no approved-key pin, B8 reads without encryption evidence, C10 storage key in `lastError`, E1b stale guard comment,
E11b preview DOCX fetch after close) are report-only and classified "NO" in §10 (REG-51..58), with Nick's classification
asked in Q10. The reads that r2 listed as "not established at Gate A" were closed on 2026-10-28 (§4 item 6 and the
ledger). **Still not read (bounded B0 reads, Q10):** the write paths of `contacts.priorityConsentDocumentKey` and the
letterhead keys (C11); `it.each` blocks missed by the describe/it grep (D); the `deliveryRouter.test.ts:391` table,
`sdk.session-revocation.test.ts`, `sdk.account-deletion.test.ts` and the `EstateDetail.p16-review.test.tsx` preview cases
by name (E); the 39 modified test files' diffs (cited as current test source).

### Row A — Role split and purge chokepoint (tracer A: 45 calls, `storageProvider.ts` read whole, 19 files; own reads of `:30-110`, `:180-265`, `:688-758`, `_core/env.ts:40-255` agree)

Governing text RULES.md `:1930-1964`. All SDK tests mock `fromTemporaryCredentials` and `S3Client` and prove request
input shape only (MOCK); STS, TLS, IAM and CloudTrail are DEPLOY. Grep: `@aws-sdk` imports, `new S3Client`, Delete*/ListObjectVersions
commands exist in production only in `server/storageProvider.ts`; none in `client/src` or `shared`; no `client-kms`,
`KMSClient` or `KMS*Command` anywhere.

- **A1 two non-parameterized STS factories — implemented (SRC).** `createRuntimeCredentialsProvider` `:65-79`,
  `createPurgeCredentialsProvider` `:86-100` (not exported, no parameters; `fromTemporaryCredentials` invoked only at `:66`
  and `:87`); separate env inputs `_core/env.ts:67-72`; identical ARNs refused trimmed/case-insensitive `:150-154`.
  Callers: `getRuntimeS3Client:212`, `getPurgeS3Client:252` only. Tests + `storage-s3.test.ts:803-856` (strict-equal
  option objects for both providers, `calledTimes(2)`); − `env.validation.test.ts:473-498` (two different roles, AWS and
  local-UAT profiles), `_core/index.startup-storage.test.ts:273` (startup refusal text). Gap: no source-scan test pins the
  factory count or export surface (a third or parameterized factory is caught only through the strict-equal objects).
- **A2 separate cached clients, no boolean or caller-input role selection — implemented (SRC).** Four module-private
  caches `:33-36`; `getRuntimeS3Client` `:185-225` (signature: endpoint, region, bucket, path style, SSE, KMS key, runtime
  ARN); `getPurgeS3Client` `:231-261` (signature without SSE/KMS; returns client/bucket/versioningMode only);
  `resetStorageClientForTests` `:473-480` destroys both. Whole-file read: role selection is by function identity only.
  Consumers: runtime `:464`, `:534`, `:593`, `:614`, `:631`, `:663`; purge `:729`. Tests + `storage-s3.test.ts:949-971`
  (one client per role; a changed secret or external ID does not rebuild), `:973-986`, `:988-1021`; − `:869-902` (every
  non-delete operation on `probatepro-runtime`, purge provider never created), `:593-603` (a failed pre-delete proof creates
  only the runtime session). Note: credential values are not in the cache signatures and ENV is read at module load, so a
  rotated external ID takes effect on restart only (asserted behaviour, not a Rule 28 breach).
- **A3 `providerDeleteExact` sole purge-client consumer; bounded static caller list — implemented (SRC).** `getPurgeS3Client`
  referenced only at `:231` (definition), `:729` (call), `:84` (comment); `listExactObjectVersions` `:689-711` private,
  receives the purge client, called only from `providerDeleteExact` `:723-758` (runtime bucket proof `:728` → purge
  list/delete `:732-752` → runtime absence check `:755`). Production call site: `storageRegistry.ts:1672`
  (`processStorageDeletionJobs` `:1622-1707`; non-`approved_s3` rows blocked `:1668-1671`), reached only from
  `startStorageLifecycleWorker` `:1714-1745` (`:1723`), started at `_core/index.ts:234-238` outside dev. Every other
  importer of `storageProvider` imports no delete primitive: `storage.ts:18-29`, `:32`; `legacyForgeStorage.ts:2`;
  `scripts/confirmLegacyStorageDestruction.ts:17-20`; `scripts/migrateLegacyStorage.ts:13-17`;
  `scripts/validateStorageProvider.ts:2`; `_core/index.ts:21`; test importers and `vi.mock`s listed in the tracer return
  (`storage.live-uat.test.ts:8,24-26,124` opt-in only). The graph query agrees (one direct caller, §2). Tests
  + `storage-s3.test.ts:544-556`, `:1052-1078` (1,001 versions in two batches on the purge session),
  `storageRegistry.test.ts:644-661`; − `storage-s3.test.ts:869-902`, `:593-603`, `:586-591` (deletion accepted but the
  object still served → failure). Gap: "sole consumer" rests on static reading; no source-scan test. DEPLOY: any holder of
  the bootstrap key can assume the purge role outside the process (IAM/CloudTrail only).
- **A4 every other physical-delete path delegates — implemented (SRC).** Delete*/ListObjectVersions and `new S3Client`
  only at `storageProvider.ts:7-26`, `:208`, `:248`, `:694`, `:740`, `:752`; `storage.ts:1-6` ("physical deletion is
  intentionally not exported"; no delete/purge/destroy match); `confirmLegacyStorageDestruction.ts:22-69` deletes nothing
  (reads, Forge absence check, operator evidence); `legacyForgeStorage.ts:41-99` GET-only; `migrateLegacyStorage.ts`
  exists/put/read/validate only; the only `DELETE` literal in server source is the CORS method list `_core/index.ts:100`.
  Tests + `storageRegistry.test.ts:644-661`, `:895-908`; − `:947-965` (legacy Forge row never reported deleted through
  the S3 provider), `:967-990`, `:683-699` (no delete while a reference remains), `:910-922` (retry/backoff). Gaps: the
  enqueue paths (disposition, replace/delete, abandoned upload, transient expiry) were not read in this pass — delegation
  is inferred from the absence of any other primitive; no structural test forbids Delete* outside the provider module.
  DEPLOY: only the real versioned bucket proves all versions and delete markers are gone.
- **A5 bootstrap pair used for `sts:AssumeRole` only — implemented (SRC).** `ENV.awsAccessKeyId`/`awsSecretAccessKey`
  consumed only as `masterCredentials` `:67-70`, `:88-91`; `new S3Client` always takes a role provider `:208-213`,
  `:248-253`; the retired static pair is excluded from the profile and refused on the fail-closed tier
  (`_core/env.ts:93-108`, `:117-125`, `:218-230`). Tests + `storage-s3.test.ts:813-849`; − `:858-867` (never a client from
  the static pair), `env.validation.test.ts:261`. Gap (report): the bootstrap pair uses the SDK's default env names, so any
  future client built without explicit credentials would pick it up through the default chain; no such client exists today
  and nothing guards against one. DEPLOY: bootstrap user limited to `sts:AssumeRole` on exactly two ARNs; external-ID trust.
- **A6 purge: no session policy, no KMS, ≤ 3600 s — implemented (SRC).** Params are only RoleArn, ExternalId,
  RoleSessionName, `DurationSeconds: 3600` (`:39`, `:92-97`; no Policy/PolicyArns/Tags); no KMS import `:7-26`; purge
  commands carry only Bucket/Prefix/markers, Bucket/Delete, Bucket/Key `:694-699`, `:740-743`, `:752`; `getPurgeS3Client`
  exposes no SSE/KMS `:231-245`; proof and absence check run on the runtime role `:728`, `:755`. Tests
  + `storage-s3.test.ts:818-839` (strict equality guards Policy/PolicyArns/Tags and the duration), `:904-947` (purge input
  keys matching kms/encryption/sse are empty under the `aws:kms` profile); **no negative test** (nothing injects a session
  policy or a KMS call; "no KMS call" is a static inference from the import list). DEPLOY: purge role without `kms:*` or
  `s3:GetObject`, role `MaxSessionDuration` ≥ 3600, CloudTrail showing no KMS events for `probatepro-purge`.
- **A7 runtime session — implemented (SRC).** No session policy (`:59-79`, comment `:62`), ExternalId, 3600 s; runtime
  PUT sends `ServerSideEncryption` + `SSEKMSKeyId` and verifies the echoed key on non-local endpoints `:534-553`; the Rule
  28 KMS-separation clause (`RULES.md:1947-1950`) applies only if a session policy is attached, so it is not applicable in
  code. Tests + `storage-s3.test.ts:820-829`, `:357` (name only); **no separate negative test** (strict equality only).
  DEPLOY: managed policy, `kms:ViaService` / `kms:EncryptionContext:estateId` conditions, trust policy.
- **A8 region and endpoint sourcing — PARTIAL (SRC; new observation for Nick).** Both STS providers and both S3 clients
  take their region from `STORAGE_S3_REGION` (`:46-57`, `:77`, `:98`, `:209-210`, `:249-250`; no STS endpoint override);
  HTTPS except loopback, non-local must be `ca-west-1` at exactly `s3.ca-west-1.amazonaws.com` without a port, and the
  fail-closed tier rejects local endpoints (`_core/env.ts:156-197`, `:218-239`); the bucket location must equal the
  configured region on non-local endpoints (`:402-406`, `:466-469`; the `us-east-1` default at `:403` is
  `GetBucketLocation` null semantics for the comparison only); `ca-central-1` occurs in production source nowhere (tests
  only, as a rejected value). **Gap (dev tier only, report-only):** `_core/env.ts:23-39` seeds `STORAGE_S3_REGION="us-east-1"`
  and `http://127.0.0.1:9000` when `NODE_ENV` is development/test, `VITEST` is unset and all ten `STORAGE_*` names are
  blank; `STORAGE_ENV_KEYS` excludes the `AWS_*` names, so a development run that has the six `AWS_*` variables set
  completes the nine-variable profile with the seeded local endpoint, skips the non-local Canada checks (`:191`), and
  would run the vault with STS and S3 on `us-east-1` from the bootstrap key — contrary to the `env.ts:12-14` comment,
  which holds only while `AWS_*` are unset. The dev-fallback test deletes `AWS_*` first (`env.validation.test.ts:547-569`),
  so this combination is untested. It cannot occur on the fail-closed tiers (`:24`, `env.validation.test.ts:571-591`).
  HTTPS for STS rests on SDK defaults (no assertion). Tests + `storage-s3.test.ts:828-854` (region from env; endpoint
  `http://127.0.0.1:9000`, so client-level HTTPS is not exercised), `env.validation.test.ts:436-444`;
  − `env.validation.test.ts:374-392`, `:394-430` (`us-east-1`, `ca-central-1`, non-AWS host rejected),
  `storage-s3.test.ts:759-775` (bucket in another region fails closed), `env.validation.test.ts:571-591`. B3-P3 covers the
  `AWS_*`-set development combination as a probe outcome (no fix). DEPLOY: real TLS on S3 and STS, the bucket's location,
  STS endpoint region.
- **A9 no convenience path hands out the purge client — implemented (SRC).** The export list (`:118`, `:173`, `:177`,
  `:463`, `:473`, `:483`, `:495`, `:503`, `:556`, `:581`, `:608`, `:630`, `:647`, `:659`, `:723`) returns or accepts no
  `S3Client`; `getPurgeS3Client`, `createPurgeCredentialsProvider`, `cachedPurgeClient`, `listExactObjectVersions` are not
  exported; the facade re-exports only `normalizeStorageKey` and `resetStorageClientForTests` (`storage.ts:32`). Tests
  +/− `storage-s3.test.ts:869-902`. Gap: module privacy only; no export-list test.
- Tracer citation notes: all task-cited lines matched; three imprecisions in the map (file-storage.md `:40` cites the
  return type for "no KMS client" — the proof is the import block; `:26` cites only the runtime `masterCredentials`;
  `providerDeleteExact` spans `:723-758`, not `:723-753`) are noted for Task 17's record, not edited. Closed 2026-10-28
  (ledger): the enqueue paths change state only (A4 holds). For Nick: whether the dev-tier `us-east-1` seeding is an
  accepted dev exception or needs a separate task (REG-52); the default-credential-chain exposure of the bootstrap names
  (REG-51).

### Row B — Fail-closed profile and encryption (tracer B: 44 calls, `_core/env.ts` 1-300 and `storageProvider.ts` 1-758 read whole, 22 files; own reads of `env.ts:1-39, 40-255`, `index.ts:40-215`, `trpc.ts:205-241` agree)

All provider tests mock `S3Client`, the credential providers and the presigner and assert command **input** shape or a
mocked **response** (MOCK, labelled per test); config tests re-import the real env module with `vi.resetModules`.
SigV4 signing of the SSE headers, bucket-policy enforcement, `kms:GenerateDataKey`/`kms:Decrypt` scoping and the
deployed `NODE_ENV` are DEPLOY.

- **B1 tier derivation — implemented (SRC, own read).** `storageFailsClosed = !["development","test"].includes(NODE_ENV ?? "")`
  (`env.ts:48-51`): exact, case-sensitive, untrimmed, read once; unset → `""` → fail-closed; `staging`, `Production`,
  ` production` fail closed; `isProduction` (`:47`) is not used by the gate; the startup gate runs whenever
  `NODE_ENV !== "development"` (`index.ts:55`, `:59`); dev/test with a complete profile is fully validated
  (`env.ts:249-250`); the seeding at `:17-39` never adds `AWS_*`. Tests + `env.validation.test.ts:304-321`, `:347-355`
  (unset and `staging` accept a complete valid profile like production); `index.startup-storage.test.ts:320-342`;
  − `env.validation.test.ts:323-345` (unset, empty, `staging`, `Production` → throw, no fallback, no warning),
  `:571-591`; `index.startup-storage.test.ts:292-305`; `storage-s3.test.ts:404-425`. Gaps: no test for `DEVELOPMENT`,
  `TEST` or whitespace-padded values; startup-level tests cover only the unset case among the non-production fail-closed
  values. DEPLOY: the deployed process's actual `NODE_ENV` (including anything a `.env` loads); `NODE_ENV=test` in
  production would disable fail-closed, `development` skips the gate (B11).
- **B2 no fallback through an incomplete or invalid profile on fail-closed tiers — implemented (SRC).** Order at
  `index.ts:59-75` (profile → provider proof → strict schema → reconciliation, before `express()` at `:85` and `listen`
  at `:234`; a startup error logs `[FATAL]` and exits `:242-248`); `getStorageConfig` re-runs the gate on every client
  acquisition (`storageProvider.ts:46-57`, `:194`, `:236`); platform writes throw on fail-closed tiers (`:515-520`); the
  three scripts validate first (`validateStorageProvider.ts:4-6`; `migrateLegacyStorage.ts:56-58`;
  `confirmLegacyStorageDestruction.ts:22-26`); the lifecycle worker starts only outside dev (`index.ts:236-237`) and
  `providerDeleteExact` re-proves the bucket; the chatbot mounts after the gate and uses no S3 (`chatbot/src` grep).
  Tests + `index.startup-storage.test.ts:210-218`, `env.validation.test.ts:288-294`; − `index.startup-storage.test.ts:173-192`
  (each of 13 variables missing), `:194-208`, `:228-265` (proof/reconciliation failures refuse listen), `:267-290`,
  `:307-318`; `env.validation.test.ts:213-302`; `storage-s3.test.ts:404-425`. **Gaps (report-only):** `env.ts:232-239` is
  the only check that refuses the `localhost`/`127.0.0.1` local-UAT profile on fail-closed tiers and **no test asserts
  it** (the Canada/KMS rules are skipped for a local endpoint, `:162`, `:191`); no test imports or exercises the three
  scripts; the platform **read** branches (`storageProvider.ts:591`, `:613`) carry no tier guard (writes do, `:518`) and
  rely on the gate having run earlier in the process; on dev/test the scripts do not refuse an incomplete profile (the gate
  warns and returns, `env.ts:240-247`, then a client is built from blank values and fails only inside the SDK);
  `validateStorageProvider.ts:7-10` prints an AWS Canada/SSE-KMS PASS even when the localhost skip bypassed those checks
  (dev/test only); `storage-s3.test.ts:332-342` never calls a provider primitive, so its not-called assertions prove
  nothing. B3-P3 covers the untested tier/profile combinations as probe outcomes.
- **B3 endpoint shape — implemented (SRC, own read).** `env.ts:156-168` (valid URL; https unless `localhost`/`127.0.0.1`
  http; no credentials, path, query or fragment), `:169-174` (bucket name regex; path-style true/false/blank),
  `:191-200` (non-local: host exactly `s3.ca-west-1.amazonaws.com`, no explicit port; path style refused), `:232-239`;
  trailing slash stripped and the bucket proof and KMS echo skipped only for local endpoints (`storageProvider.ts:49`,
  `:466-468`, `:549-551`). Tests + `env.validation.test.ts:436-444`, `:500-526`; − `:374-392`, `:394-411`, `:296-302`.
  Gaps: no test for endpoint credentials/path/query/fragment, an explicit non-default port, an invalid URL, a malformed
  bucket name, an invalid path-style value, or the fail-closed localhost refusal (static inference only; `:443` would be
  dropped by the URL parser, so `https://s3.ca-west-1.amazonaws.com:443` passes — noted, not judged).
- **B4 region ca-west-1 — implemented (SRC).** `env.ts:191-194`; bucket location must equal the configured region
  (`storageProvider.ts:402-406`; the `us-east-1` default is `GetBucketLocation` null semantics); STS and S3 clients take
  the region from the same setting (`:77`, `:98`, `:208-213`). Tests + `storage-s3.test.ts:613-619`; − `env.validation.test.ts:402-411`,
  `:528-545` (`AWS_REGION`/`AWS_KMS_KEY_ID` aliases refused), `storage-s3.test.ts:759-775`, `index.startup-storage.test.ts:279-290`.
  Gaps: the local UAT profile is exempt (dev seed `us-east-1`, see A8); the location proof never runs at startup on dev.
- **B5 full account-qualified Canada West KMS ARN — PARTIAL (SRC; report for Nick/Task 19).** `CA_WEST_1_KMS_KEY_ARN`
  `env.ts:127-132` (`^arn:aws:kms:ca-west-1:\d{12}:key/<uuid>$`; `mrk-` ids refused), applied untrimmed `:204-213` only
  when `aws:kms` is configured and the endpoint is non-local (`:191`); a key id without `aws:kms` is refused `:182-184`.
  Tests + `env.validation.test.ts:436-444`; − `:446-462` (bare id, alias, alias ARN, `ca-central-1`, `us-east-1`,
  11- and 13-digit accounts, `aws-cn`, `s3` service, padding, trailing newline, `/extra`), `:464-471`, `:416-429`,
  `index.startup-storage.test.ts:279-290`. **Gap:** there is no approved-key or account pin anywhere in code: any
  well-formed 12-digit account and key id passes, and every runtime check (bucket default `:420-426`, deny-only policy
  `:361-367`, PutObject echo `:550-553`) compares against the **same configured value**, so a consistently configured
  wrong key passes them all. That the configured ARN is the approved key in the vault account is DEPLOY (Task 19).
- **B6 bucket default-encryption key equality at startup and before every delete — implemented (SRC).**
  `validateAwsCanadaBucketSecurity:420-429` (`SSEAlgorithm === "aws:kms" && KMSMasterKeyID === kmsKeyId`, strict;
  `aws:kms:dsse` refused; `BucketKeyEnabled` not checked); the deny-only policy exact-match `:327-393`, `:431-441` (an
  absent policy is accepted, `:280-288`); `validateStorageProviderConfiguration:462-470` (versioning then security;
  skipped for local); `providerDeleteExact:723-728`. Callers `index.ts:65-67`, `storageProvider.ts:728`, the three
  scripts. Tests + `storage-s3.test.ts:613-619`, `:714-719`; − `:707-712` (other default key), `:777-783` (AES256
  default), `:737-747` (every policy deviation incl. a different key and `StringNotEqualsIfExists`), `:721-735`,
  `:749-757`, `:593-603`. Gaps: no test for an `aws:kms` default without `KMSMasterKeyID` (the AWS-managed key) or an
  alias/bare-id default (strict equality refuses, static); a missing bucket policy passes, so the AWS-side `DenyNonKmsPut`
  / `DenyUnexpectedKmsKey` are optional; no re-proof between startup and the next delete or restart; dev never runs it;
  startup tests mock the proof (`index.startup-storage.test.ts:72-77`) and prove call order only.
- **B7 PutObject requests aws:kms + SSEKMSKeyId and verifies the echo exactly — implemented (SRC).**
  `providerPutExact:534-553` (command input `:534-543` with `ChecksumSHA256`; algorithm echo required whenever SSE is
  configured `:544-546`; non-local `SSEKMSKeyId` strict equality, a missing echo refused `:547-553`); every application
  write goes through `storagePut` → `providerPutExact` (`storage.ts:88`; `PutObjectCommand` only at `:535`); callers
  `routers.ts:2504, 3084, 3134, 3196, 3375, 3652, 4975, 5129, 5229, 5789, 5835, 6767`, `_core/imageGeneration.ts:108`,
  `scripts/migrateLegacyStorage.ts:33` (feeds F1). Tests + `storage-s3.test.ts:357-370` (input: `aws:kms`, the ARN,
  checksum; matching echo accepted), `:387-394` (local algorithm-only relaxation), `:344-355`; − `:372-385` (a
  different key; no reported key → refused, error names the variable), `:396-402` (no encryption confirmed). Gaps: no
  test for an `AES256` echo after an `aws:kms` request, nor an alias/bare-id/case-variant echo; signing of the
  `x-amz-server-side-encryption*` headers never exercised (mocked); after an echo mismatch the object is already stored
  and `storage.ts:90-96` only marks the upload failed (cleanup not traced; Gate B read-only follow-up, report-only).
- **B8 encryption evidence on GET/HEAD/presign/validation — NOT implemented (design limit; report-only).**
  `providerGetSignedUrl:581-601` (presign, 300 s default, 1–900 s clamp), `providerReadExact:608-621` (Body only),
  `providerObjectExists:630-640`, `providerHeadExact:659-686` (ContentLength and `ChecksumSHA256` only),
  `validateStorageManifestReconciliation` (`storageRegistry.ts:1354-1357`, size and SHA-256 only), migration
  verification (bytes and hash). No path reads `ServerSideEncryption` or `SSEKMSKeyId` on a read, so no test asserts it
  (positive read tests `storage-s3.test.ts:465-537` by name). Consequence: an object stored under another key or with
  SSE-S3 (pre-profile or out-of-band) would be served and reconciled as valid; whether reads of such objects fail depends
  on the runtime role's `kms:Decrypt` scoping (DEPLOY). Satisfied for PUT (`providerPutExact:534-553`) and the bucket
  default-encryption proof only; for GET/HEAD/presign/reconciliation no encryption evidence is read or asserted — NOT
  implemented. Rule 28 names PUT only; whether the read-side absence is an accepted design limit is Nick's call (Q10).
- **B9 presigned PUT — not applicable.** `getSignedUrl` is used only with `GetObjectCommand` (`:26`, `:594`); no
  presigned PUT, `createPresignedPost`, multipart or `lib-storage` upload exists in server or client (grep); the
  dev/test Forge presigned PUT (`:515-531`) sends only a Content-Type header and is refused on fail-closed tiers
  (`storage-s3.test.ts:404-425`: no fetch, no S3 send, no STS).
- **B10 no platform write on fail-closed tiers — implemented (SRC).** `providerPutExact:512-520`; `usingPlatformStorage:118-120`;
  `storagePut:51-88` manifests `legacy_forge` vs `approved_s3` by the same decision. Tests + `storage.test.ts:188-202`,
  `:310-335`; − `storage-s3.test.ts:404-425` (production absent/incomplete, unset absent). Gap: no provider-level
  refusal test for `staging`/empty/mis-cased (flag derivation tested at env level).
- **B11 development skips the whole startup gate — design limit (not a pass).** `index.ts:55`, `:59-76` (no profile
  validation, bucket proof, strict schema or reconciliation), `:234-238` (worker not started), `env.ts:23-39` (dev seed),
  `:240-250` (a complete dev profile is validated lazily on the first provider call; the non-local echo check still
  applies). Tests + `index.startup-storage.test.ts:344-352`, `env.validation.test.ts:547-569`. DEPLOY: whether any hosted
  environment runs with `NODE_ENV=development`.
- Tracer citation notes: `env.ts` is 300 lines (brief said about 270); file-storage.md `:101-107` for the profile list
  should be `:98-108`; `storageProvider.ts:420-425` is the comparison with the throw at `:427-429`. Closed 2026-10-28
  (ledger): no cleanup follows a PutObject echo mismatch (`storage.ts:87-97`; the B7 gap stands);
  `validateLegacyForgeDestructionAuthorization` (`legacyForgeStorage.ts:15-32`) checks operator confirmation strings and
  an evidence reference and deletes nothing. Still noted: `storage-s3.test.ts:427-453` relies on vitest's default
  `NODE_ENV=test` for its first half.

### Row C — Namespace, manifest and lifecycle authorization (tracer C: 44 calls, 24 files; own reads of `storage.ts:1-174`, `storageRegistry.ts:640-750`, `storageNamespace.ts`, `storagePublicAssets.ts`, `_core/storageProxy.ts`, `db.ts:630-667`, `storageProvider.ts:483-501` agree)

Every test in this row runs on a fake `drizzle-orm/mysql2` database with the provider mocked (MOCK); the registry tests
mock the normalizer with a simplified rule (`storageRegistry.test.ts:39`, `storage.read-boundary.test.ts:22`) and the
facade tests stub the gate; no test composes the proxy with the real facade and registry. Real-engine evidence is HIST
(Task 3: five InnoDB ordering scenarios, seven padded-key cases, two retained-read 307→200, actor boundary 404) and is
refreshed only by J4/J6 (NATIVE/UI). TiDB stays DEPLOY.

- **C1 exact-key matching; malformed, traversal, alias and prefix variants cannot select another object (percent-encoded
  and NFC/NFD variants untested at the proxy; static inference) — implemented (SRC, own read).** `normalizeStorageKey:483-493` (leading slashes stripped; empty, >512, control
  characters, backslash, empty/`.`/`..` segments refused; no decoding, case folding, trim or Unicode normalization);
  `storage.ts:138-149`, `:165-173`; `privateReadRequests` (`storageRegistry.ts:541-557`: key already canonical, ≤512,
  not a public key, valid non-public category, conflicting duplicates refused); SQL `IN` + FOR UPDATE NOWAIT with a JS
  map keyed by the row's own key and a count check `:686-692`; pointer folding checks `:567-581`, `:599-604`;
  `manifestIdentityIsValid:184-214` (stored key canonical; v1 keys must match account/estate namespace and category);
  `db.ts:661` literal re-compare; proxy 400 on an invalid key; `previewFile`/`assertStoredObjectOwnedBy` zod 1..512 +
  normalize (`routers.ts:3350-3357`, `:357-366`). Tests + `storage-key.test.ts:5`, `db.storage-authorization.test.ts:129`;
  − `storage-key.test.ts:9-18`, `db.storage-authorization.test.ts:145`, `:176`, `storageRegistry.test.ts:1382` (collation-only
  match), `:1457` (namespace prefix not trusted), `:1464-1472`, `:1474`, `:1598`, `storage.read-boundary.test.ts:701`,
  `storage.test.ts:248-262` (public near misses), `storage-authorization.test.ts:106`, `storageNamespace.test.ts:266`.
  Gaps: no percent-encoded (`%2F`, `%252F`) or NFC/NFD test at the proxy or gate (Express decodes `req.params[0]` once,
  dependency behaviour; the decoded key is still compared exactly against an owned manifest); the real normalizer is
  exercised only by `storage-key.test.ts`; a stored pointer spelled with a leading slash makes the read refuse (fails
  closed). DEPLOY: real collation (PAD SPACE, ci/ai) and URL decoding in the deployed stack.
- **C2 owner/account binding — implemented (SRC, own read).** Proxy: authenticate (401), suspended refused, lookup by
  the session user, 503 on lookup error, 404 otherwise (`storageProxy.ts:25-46`); `findAccessibleStoredObject` WHERE
  owner (`db.ts:653-661`); gate: positive safe-int user, `estate.createdByUserId === userId`, `row.userId === userId`,
  account row locked and equal (`storageRegistry.ts:545`, `:682`, `:689-701`); `manifestIdentityIsValid:195-203`;
  `assertStoredObjectOwnedBy:357-384`. Read-context callers: `routers.ts:3359-3363`, `:2009`, `:3240`;
  `estateExport.ts:156-158`; `downloadRoute.ts:354`, `:359`, `:365`; `downloadExportsRoute.ts:114`. Tests
  + `storage-authorization.test.ts:154`, `storage.read-boundary.test.ts:863`; − `storage.read-boundary.test.ts:277`,
  `:287`, `storageRegistry.test.ts:1320-1327`, `:1349`, `:1394`, `db.storage-authorization.test.ts:155`,
  `storage-authorization.test.ts:128`, `:173` (never from browser query fields), `:182` (suspended → same 404),
  `:192` (lookup unavailable → fail closed). Gaps: `previewFile` relies on `protectedProcedure` for suspension (not
  re-read here); the proxy/preview tests mock `./db` and `./storage`.
- **C3 estate and category binding — implemented (SRC).** Estate row FOR UPDATE NOWAIT with exact id and owner
  (`:675-683`); `row.estateId`/`row.category` equal the request (`:689-692`); `PRIVATE_RETENTION_CATEGORIES` and
  retention/category pairs (`:151-155`, `:195-203`); pointer cross-checks (`:587-641`); `assertStoredObjectOwnedBy:374-383`;
  the dispensation-order path rule (`routers.ts:4945-4950`); fixed categories per attachment code
  (`documentAssets.ts:219-233`); `assertCitationEvidenceKeys` (`routers.ts:526-552`) re-validates only keys that differ
  from the existing record (an unchanged pre-manifest key is trusted as previously authorized; ledger nuance). Tests
  + `storageRegistry.test.ts:1293`; − `storage.read-boundary.test.ts:287`, `:587`,
  `storageRegistry.test.ts:1328-1335`, `:1447`, `db.storage-authorization.test.ts:211`. Note (by design, stated): on the
  proxy and preview routes the estate and category come **from the manifest row** (`storageProxy.ts:36`,
  `routers.ts:3363`), so the binding there is ownership plus readability of any owned object.
- **C4 lifecycle and disposition refusals — implemented (SRC, own read).** Readable: `active`, or `retained` with no
  destruction marker and `deleteAfter` null; transient only when active with a future `deleteAfter`
  (`hasNoDestructionMarker:224-226`, `manifestLifecycleIsReadable:228-239`); refused: `pending_reference`, `uploading`,
  `upload_failed`, `pending_delete`, `delete_failed`, `deleting`, `deleted`, unknown states, `dispositionId`,
  `deletedAt`, a lock token, any non-transient `deleteAfter`, and a `storage_dispositions` tombstone for the estate (not
  owner-filtered, `:696-701`); validity checked before and after the runtime-reference check, dispatch inside the
  locking transaction (`:703-715`), 30 s completion timeout (`:728-738`); the pre-filter admits `pending_reference`
  (`db.ts:656`). Tests + `storageRegistry.test.ts:1479`, `:1492`; − `:1336-1354` (every state and marker),
  `storage.read-boundary.test.ts:321`, `:423` (foreign-owner tombstone still refuses), `:663` (revalidates before the
  next chunk), `:376`, `db.storage-authorization.test.ts:161`, `:170`, `storage-authorization.test.ts:136-152`. Gaps
  (report-only): an owner's `pending_reference` upload passes the proxy/preview lookup and is then refused by the gate,
  so the proxy answers **502** rather than 404 (already Task 17 §13 item 2; visible only to the owner; no composed test);
  a later disposition does not revoke a signed URL already issued (`:649-650`); the dispositions read takes no lock and
  relies on the estate lock to serialize tombstone writers (`:696-698`).
- **C5 provider switching — implemented as the approved hybrid design (PARTIAL against the prompt's wording; stated
  precisely).** `readsFromLegacyPlatform` (`storage.ts:112-121`): an `approved_s3` row in platform-only mode throws; a
  `legacy_forge` row is routed to the read-only platform helpers (`:120`, `:134`, `:156`; `storageProvider.ts:173-182`)
  **also in vault mode** — the runtime gate has no strict/hybrid flag, and non-approved rows are refused in vault mode
  only by startup reconciliation when `retainLegacyPlatformObjects` is false (`storageRegistry.ts:1298-1301`,
  `:1316-1319`); production passes `retainLegacyPlatformObjects: true` (own read, `index.ts:74`), which is the recorded
  "hybrid, no migration" decision (file-storage.md §4; Task 3 acceptance). `manifestIdentityIsValid:185-187`, `:705`
  (provider must be `approved_s3`/`legacy_forge` with consistent legacy-source state; `approved_s3` needs verified
  size/SHA); the worker refuses deleting non-approved rows (`:1661-1671`); `storagePut` sets the manifest provider by
  the same decision (`storage.ts:52-56`, `:84`). Tests + `storageRegistry.test.ts:1293`, `:1703`, `storage.test.ts:216`,
  `:310`; − `storageRegistry.test.ts:1515`, `:1321-1324`, `:1356`, `:1613-1627`, `:1677`, `:947`, `storage.test.ts:301`.
  Note: through the real registry the facade's synchronous throw becomes the one generic refusal (`:712-713`, `:721`,
  `:741-744`); the "configured storage provider" message is asserted only against the stubbed registry.
- **C6 missing manifest refused except the exact eight-key allowlist — implemented (SRC, own read).**
  `PUBLIC_STORAGE_ASSETS` is a `Set` of eight complete keys with an exact-match comment (`storagePublicAssets.ts:1-13`);
  `Set.has` after normalization (`storage.ts:146-148`, `:170-172`; proxy `:19`, `:25`); a missing context refuses
  (`:123-126`); public key/category refused on the private path and a missing row refuses (`storageRegistry.ts:548-550`,
  `:689-692`); public-key rows must be ownerless `public_asset` (`:191-193`); startup expects all eight and treats a
  missing manifest as invalid unless hybrid and public (`:1248-1256`, `:1289-1295`). Tests
  + `storage-authorization.test.ts:98`, `storage.test.ts:231`, `storageRegistry.test.ts:1715`; − `storage.test.ts:248-262`
  (`private/` prefix, `prefix-`, `.extra`, uppercase, trailing space, other name), `storage-authorization.test.ts:106`,
  `storageRegistry.test.ts:1307`, `:1530`, `:1589`, `:1649`, `:1082`. Gaps: no test pins the allowlist to exactly these
  eight entries (tests iterate the Set); in vault mode the public assets are signed through the legacy platform helper
  with no manifest check at request time while strict startup wants them manifested (residency/availability, not an
  authorization bypass); a leading-slash spelling normalizes to the public key (benign).
- **C7 legitimate owner/current and retained historical reads admitted — implemented (SRC).** `active` and `retained`
  readable (`:228-239`); `validateRuntimeReferences:567-642` refuses only conflicting pointers; the lookup includes
  `retained` (`db.ts:656`); both providers routed (`storage.ts:112-121`). Tests + `storageRegistry.test.ts:1414`
  (retained bytes without a current pointer), `:1429` (retained firm asset), `:1423`, `:1578`,
  `storage.read-boundary.test.ts:508`, `:1012`, `db.storage-authorization.test.ts:135`; − `storageRegistry.test.ts:1320-1354`.
  Gaps (availability, fail-closed): a legitimate read is refused if any pointer in the estate case- or trim-folds to the
  requested key or malformed codicil JSON contains a folded hint (`:570-581`, `:599-604`); `documentAssets.ts:230` passes
  keys unnormalized, so one non-canonical key refuses the whole batch (`:549`).
- **C8 no authorization cache — implemented (SRC, own read).** `storage.ts:128`; a fresh transaction per chunk per
  call, nothing retained but dispatched promises (`storageRegistry.ts:644-650`, `:672-716`); the engine is probed on the
  leased connection every transaction (`:495-505`); a retry re-runs the whole validation (`:718-727`); `attachmentSigner`
  reuses a Promise only within one attachment operation (`documentAssets.ts:224-232`). Tests
  − `storage.read-boundary.test.ts:632`, `:790`, `:663`, `:1045`. Gaps: issued signed URLs stay valid until expiry
  (≤900 s); public-asset redirects may be cached 240 s (`storageProxy.ts:60`).
- **C9 proxy and preview route use the gate with a server-resolved context — implemented (SRC, own read).**
  `storageProxy.ts:10-66` and `previewFile` `routers.ts:3350-3365` (normalize → public check → auth → suspended →
  owned lookup → context from the row → `storageGetSignedUrl` → `private, no-store` 307 / NOT_FOUND). Tests
  + `storage-authorization.test.ts:161`, `:199-209`; − `:117`, `:173`, `:199-204`. Gaps: every proxy/preview test mocks
  `./storage` and `./db` (no composed test through the real registry; J4 is the composed evidence); after a successful
  lookup any gate refusal returns 502, not 404; 14 other test files mentioning the proxy/preview were not inventoried.
- **C10 startup reconciliation refusals, counts-only messages — implemented (SRC).**
  `validateStorageManifestReconciliation:1241-1373` (conflicting expectations; missing/mismatched/non-active/unreadable
  referenced rows; identity of every live/retained row; `legacy_forge` unless hybrid; byte metadata and legacy-source
  proof; hybrid needs Forge config; S3 HEAD size/SHA re-verified); messages at `:1264`, `:1305`, `:1323`, `:1326`,
  `:1364`, `:1371` carry counts, variable names or a provider error name only; `loadManifestOwners:158-182`;
  `:1044-1059`; `reconcileCommittedStorageReferences:1106-1134` repairs only recoverable rows; worker log `:1714-1727`;
  `errorMessage:1504-1512` redacts ARNs, access keys and 12-digit ids. Tests + `storageRegistry.test.ts:1724`, `:1197`;
  − `:1613-1627`, `:1657`, `:1668`, `:1165`, `:1182`, `:1761-1777`, `:1805`, `:992`, `:753`. **Gap (new observation,
  report-only):** the worker writes the **storage key** into `stored_objects.lastError` for a blocked legacy deletion
  (`:1670` via `errorMessage:1697`), which redacts ARNs/keys/account ids but not storage keys — a database column, not a
  log; and `registerMigratedStoredObject`'s error includes the key (`:399`, grep line). The production startup flags
  were read by the main session (`index.ts:71-74`), not by the tracer.
- **C11 namespace randomness, CAS and server-managed fields — implemented (SRC, own read).** `storageNamespace.ts:7-18`,
  `:24-47` (UPDATE WHERE NULL, ≤3 attempts, re-read, regex-validated), `:60-71` (owner before UPDATE), `:82-93`;
  `storage.ts:52-67` (vault keys only from the allocator; platform keys keep the caller path plus an 8-hex suffix);
  `shared/serverManagedEstateFields.ts:20-37`; `routers.ts:313-315`, `:329-348`, `:6533`, `:2976-2981`; `db.ts:693-694`;
  `estateExport.ts:30-45`. Tests + `storageNamespace.test.ts:243` (1,000 unique keys, no ids), `:100`,
  `storage.tenancy.test.ts:93`; − `storageNamespace.test.ts:112`, `:143`, `:159`, `:315`, `storage.tenancy.test.ts:149`,
  `db.storage-authorization.test.ts:230`. Gaps: CAS/conflict retry proven on a fake DB only (TiDB 9007/8028 from a
  comment); the unique index is asserted in a comment (`routers.ts:2977`; schema not re-read); `ensureEstateNamespace`
  compares the owner but not the literal estate id (`:66-68`; only a same-owner collation alias could match);
  platform-mode keys are not opaque (they authorize nothing); stale comment `shared/serverManagedEstateFields.ts:14-17`
  (Task 17 §13 item 1); write paths for `contacts.priorityConsentDocumentKey` and the letterhead keys not read.
- **C12 engine/isolation requirement at read time — implemented (SRC).** `requireStorageReadLockingEngine:495-517`
  (RC/RR; MySQL 8.0/8.4 Community/Enterprise exact comment; TiDB v8 + comment prefix + `tidb_txn_mode=pessimistic`;
  else refuse), `requireStorageReadInnoDBTables:519-527` (`estates`, `stored_objects`, `users` InnoDB base tables, exactly
  3), probe first in the transaction `:672-695`, contention retry errno 3572/1213/1205 up to 8 attempts, never after
  admission (`:530-538`, `:718-727`). Tests + `storage.read-boundary.test.ts:800`; − `:755`, `:767`, `:781`, `:941`,
  `:992` (its describe says "not real-engine evidence"). Gaps: all fake connections; `storage_dispositions` and the
  runtime-reference tables are outside the InnoDB check and dispositions are read without a lock; TiDB skips the table
  check; a managed MySQL whose `@@version_comment` differs from the accepted strings would refuse every private read
  (REG-42/43). HIST: Task 3 `database-lock-compatibility.md` (local InnoDB).
- Tracer citation notes: no map mismatches in the ranges read; the stale in-source comment above. Closed 2026-10-28
  (ledger): `storageProvider.ts:559-569`, `:581-601` (signed URLs: default 300 s, clamp 1–900 s); `registerStoredObjectUpload`
  (`storageRegistry.ts:253-321`: manifest row inserted before any PUT; client files serialised on the locked estate row);
  the estateExport object list is `listEstateExportObjects` → `db.listExportableStoredObjects` (`estateExport.ts:87-99`);
  46 test files name the proxy or preview. Production callers recorded by the tracer (`storageGet` and `userCanAccessStorageKey`
  have none; `withReadableStoredObjects` only from `storage.ts:133`, `:155`; `storageGetSignedUrls` only from
  `documentAssets.ts:230`; `storageReadExact` only from `routers.ts:1457`; `storageReadManyExact` only from
  `estateExport.ts:156`; `findAccessibleStoredObject` from `storageProxy.ts:35`, `routers.ts:367`, `:3359`).

### Row D — Generation, replacement and delivery integrity (tracer D: 57 calls, 18 files; own reads of `downloadRoute.ts:170-320` and `formDeliveryBinding.ts:25-124` agree with every cited line)

Every database proof in this row runs on a fictional drizzle driver or an in-memory `./db` mock (MOCK); the real-engine
evidence is historical (HIST: Task 16 13, Task 4 18 and Task 5 22 native MySQL/InnoDB scenarios on the owned fixture) and
is refreshed only by the Gate B journeys (NATIVE/UI); TiDB stays DEPLOY.

- **D1 exact estate checks — implemented (SRC).** `db.ts:1073-1080` (`assertDocumentReplacementInput`, literal insert key
  checks before any await, called at `:1178`, `:1241`), `:1095-1103` (effects rows must carry the estate), `:1147-1150`
  (`commitGenerationEffects` locks `estates` FOR UPDATE and compares `lock.id !== estateId`), `:1171-1193`
  (`replaceCurrentDocuments`: inputs copied pre-await, literal lock compare `:1185`, FOR UPDATE read `:1189`, any affected
  row from another estate → NOT_FOUND before any write `:1193`), `:1229-1264` (batch, same), deletes scoped by id AND
  estateId `:1199`, `:1270`. Callers: `affidavitHistory.ts:350-356`, `:381-390`; `routers.ts:4572-4595`, `:4676-4689`,
  `:4726-4739`, `:2697-2703`, `:4625-4631`; `db.ts:1247-1250`. Tests + `db.replaceCurrentDocuments.test.ts:551`;
  − `:325`, `:336-360`, `:362-375` (collated alias refused), `:377`, `:565`; `db.replaceCurrentDocumentsBatch.test.ts:398`,
  `:406`, `:412`, `:366`; `db.generation-effects.test.ts:200-208`. Gaps: route suites emulate `./db` without locks or
  estate checks (prove nothing for D1); collation only simulated. DEPLOY: FOR UPDATE and collation on real MySQL/TiDB.
- **D2 complete-set replacement and typed conflict — implemented (SRC).** `documentReplacement.ts:13-36`
  (`documentsReplacedBy`, four branches), `:58-62` (`sameIdSet`); `db.ts:1021-1053` (unbounded key-scoped and estate-wide
  snapshots; `listDocuments` `:978-982` capped at 200 is not used for the expected set); `routers.ts:4427-4444`, `:4586`,
  `:4649-4652`, `:4710-4713` (snapshot before render); `affidavitHistory.ts:346-353`, `:372-384`; under the lock the
  affected set is recomputed and must equal the expected set, each delete must affect exactly 1 row (`db.ts:1189-1205`,
  `:1237-1278`); `DocumentReplacementConflictError` CONFLICT with the fixed sentence, errno 1213/1205/9007/8028 from
  `DrizzleQueryError.cause` (`:1055-1070`, `:1123-1128`, `:1208-1213`, `:1281-1286`). Tests + `db.replaceCurrentDocuments.test.ts:581`,
  `:636`, `:265`; batch `:214-279`; `routers.bulk-replacement.test.ts:86`, `:111`, `:144`; − errno mapping `:679-716`,
  stale snapshot `:417-476`, capped set refused `batch:288`, empty batch `:297`, duplicate-id rollback `:325`, delete count
  `:334`, foreign set `:429-435`, overlapping batches `:484-527`, `routers.bulk-replacement.test.ts:128-176`,
  `db.generation-effects.test.ts:158`, `:242`. Gaps: only four errnos map to the typed conflict (others → raw rethrow
  without effects, or "unconfirmed" with effects); `listAffidavitOrdinalHistory` reads outside the lock (`db.ts:993-996`,
  acknowledged in a comment: two concurrent generations for one deponent can share an ordinal); the TiDB FOR UPDATE
  freshness comment (`:1186-1188`) is untested on TiDB. DEPLOY: lock waits, deadlocks, errno emission on the real engine.
- **D3 transactional GenerationEffects with acknowledgement — implemented (SRC).** `db.ts:1082-1086`, `:1105-1113`
  (`assertGenerationWriteAcknowledged`: tuple shape and `affectedRows === 1`), `:1117-1121`, `:1140-1156`, `:1197-1206`,
  `:1269-1279`; row builders `affidavitHistory.ts:328-333`, `:467-481`, `:537-539`, `:574-576`; passed as effects at
  `routers.ts:4535-4550`, `:4587-4594`, `:4625-4631`, `:4678-4688`, `:4728-4738`. Tests + `db.generation-effects.test.ts:62`;
  `routers.generation-effects.test.ts:148`, `:215`; `affidavitHistory.generation-effects.test.ts:27-96`;
  − `db.generation-effects.test.ts:90`, `:113`, `:184`, `:224`; `routers.generation-effects.test.ts:178-255`;
  `routers.bulk-replacement.test.ts:154`. Gaps (report, not fix): `ensurePgtContact` (`routers.ts:455`; writes `:518-519`)
  runs in letters/package before render and outside the transaction (a later failure does not roll those rows back);
  `assertGenerationEstateStillCurrent` (`routers.ts:218-231`, called `:4481`) checks the revision before the transaction and
  returns early for a non-integer revision; the audit `contentSha256` is the raw sha256 of the bare render (`:4591`).
- **D4 GenerationCommitUnconfirmedError semantics — implemented (SRC).** `db.ts:1088-1093`, `:1123-1137`
  (`generationCommitError` mapping), `:1144-1155`, `:1208-1209`, `:1281-1282`; `routers.ts:1473-1492`, `:4570-4596`
  (binding minted before commit, descriptor returned only after the commit resolves); `affidavitHistory.ts:350-358`,
  `:381-392` (activation only after success). Tests − `db.generation-effects.test.ts:232-240` (lost COMMIT ack is
  "unconfirmed", never "rolled back"); `routers.generation-effects.test.ts:264`; `formDeliveryBinding.races.routes.test.ts:738`,
  `:715`; `routers.estate-export.test.ts:236`; `affidavitHistory.generation-effects.test.ts:105`;
  `db.generation-effects.outage.test.ts:12`, `:21`. Gaps: rolled-back failures and unknown COMMIT outcomes share one answer;
  no idempotency key (a retry after a committed-but-lost ack makes another row; Task 5 acceptance says so, REG-46).
- **D5 binding MAC coverage and key — implemented (SRC, own read).** `formDeliveryBinding.ts:30-36`, `:46-52`
  (`deliveryInputsHash` drops only `attemptId` and `binding`), `:54-59` (HKDF over the untrimmed `ENV.cookieSecret`, no
  fallback), `:61-65` (MAC over `[DOMAIN, userId, generatorRelease, issuedAtMs, fieldsDigest, renderSha256]`), `:71-87`,
  `:95-116` (shape → key → constant-time MAC → expired → future); `formDeliveryArtifact.ts:19-62` (composite release:
  `GENERATOR_RELEASE` + bundle or source-tree hash, cached per process); issued at `routers.ts:4553-4571`, verified at
  `downloadRoute.ts:180-186`; `shared/postDelivery.ts:7-28`. Tests + `formDeliveryBinding.test.ts:100`, `:114`, `:59-91`;
  `formDeliveryBinding.routes.test.ts:358`, `:372` (same binding twice streams twice, intended), `:381`;
  `formDeliveryArtifact.test.ts:34-89`; − `formDeliveryBinding.test.ts:123-145` (every MAC input), `:147-226`;
  `formDeliveryBinding.routes.test.ts:401-420` (eleven altered fields → 409), `:486`, `:494`, `:570`, `:589` (blank key at
  delivery → 500), `:607` (rotated key → 409), `:448`; `p9-delivery-proof.routes.test.ts:342`; `downloadRoute.test.ts:1883`
  (no budget spent on nine tampered deliveries). Gaps: no nonce/single-use (by design, Task 6 plan); not tied to session,
  Origin or estate revision; key separated from the session secret only by the HKDF info label. DEPLOY: non-blank secret
  and identical artifact identity on every replica (SEC-2, REG-07/08).
- **D6 expiry and skew at admission — implemented (SRC, own read).** TTL 600,000 ms and +60,000 ms future skew,
  negated comparisons so a NaN clock fails closed (`formDeliveryBinding.ts:30-31`, `:112-115`); checked once at
  `downloadRoute.ts:180-190` before the rate unit; `issuedAtMs = Date.now()` before the commit (`routers.ts:4570-4572`).
  Tests + `formDeliveryBinding.test.ts:179-188`; races `:550`, `:579`; − `formDeliveryBinding.test.ts:184-187`;
  `formDeliveryBinding.routes.test.ts:501`; races `:550`, `:610`. Gaps: no re-check after admission (deliberate); lifetime
  starts before the commit; one 409 sentence for expired/future/MAC (reason only in `console.warn`).
- **D7 refusal ordering — implemented (SRC, own read of `:176-190`, `:293-299`).** Guard (router, row E) → 401 → 403
  suspended → 400 strict body (`downloadRoute.ts:102-109`; override/consent JSON `:138-161`) → ownership: `idor_attempt`
  awaited, 404 non-literal id, 403 foreign (`:164-177`) → binding 409, `key_unavailable` → 500 + report (`:180-186`) →
  rate unit 429 (`:190`) → fact reads and applicability/P9-proof/deponent/P8 400s (`:199-286`) → `replayRow` 409, no
  event (`:293-299`) → render → digest 409 with a failed event (`:313-345`) → started exactly `true` else 503 → bytes →
  finished/aborted (`:382-407`); catch `:408-447`. Tests − `formDeliveryBinding.routes.test.ts:704-743`, `:624-680`,
  `:689-702`; `downloadRoute.test.ts:1670-1883`, `:1696`, `:1910`, `:1935`, `:1540`;
  `formDeliveryBinding.body-size.routes.test.ts:229`; races `:550`, `:680`. Gaps: the rate unit is spent before the
  `replayRow` 409 and the applicability 400s; body-JSON 400s precede the ownership check.
- **D8 current-row check — implemented (SRC, own read).** `downloadRoute.ts:293-299` (id, formCode, signatureDate; P34
  target; persisted-affidavit deponent), `routeDocuments = db.listDocuments` (`:203`; `db.ts:978-982` limit 200).
  Tests + races `:490-525`; `downloadRoute.test.ts:462`, `:1003`, `:1035`, `:1261`; − races `:409`, `:422`, `:431`;
  `formDeliveryBinding.routes.test.ts:689`; `downloadRoute.test.ts:1048`; `document-generation.audit.test.ts:361`.
  Gaps: signatoryType, format, exhibit stamp, estate revision, P46/LETTER/P8/P17 targets and the Exhibit A P1 row are
  covered by the MAC only; a current row older than the 200 newest gets a false 409 (fails closed; no route test).
- **D9 bare-render digest — implemented (SRC).** `formDeliveryBinding.ts:142-205` (one-pass core-timestamp blanking),
  `:207-236` (`canonicalRenderDigest`; a corrupt ZIP rejects); `routers.ts:4478-4479`; `downloadRoute.ts:343-345`
  (409 `StaleDeliveryError` after re-render), `:313`, `:420-429` (writes `document_delivery_failed` 409), body assembled
  only after the check `:351-367`. Tests + `formDeliveryBinding.test.ts:352-465`; media routes `:349-561`; routes `:530`;
  − `formDeliveryBinding.test.ts:364-475`; races `:508`, `:667`; media `:368-584`; routes `:546`;
  `downloadRoute.test.ts:599`. Gaps: digest excludes the ZIP container, P9 Exhibit A, P1 attachments, P34 evidence (D13);
  the audit `contentSha256` and the started event's are recorded, never compared; `downloadRoute.test.ts` mocks the digest
  to a constant (`:41-47`). DEPLOY: render determinism across replicas.
- **D10 audit ACK before bytes — implemented (SRC).** `downloadRoute.ts:382-401` (503 unless `started === true`),
  `_core/deliveryRouter.ts:130-137` (`auditWritten`), `:145-166` (headers only inside `sendAttachment`),
  `affidavitHistory.ts:483-503`; exports `downloadExportsRoute.ts:118-141`. Tests + `downloadRoute.test.ts:1281`, `:1221`,
  `:1314`; `document-generation.audit.test.ts:259`; − `downloadRoute.test.ts:1383-1430` (false, undefined, null, "true",
  rejects, throws → 503, no byte); routes `:733-743`; `_core/deliveryRouter.test.ts:567-577`. **Contract of the
  recorder (own read, `db.ts:2025-2040`):** `createAuditEntry` returns `true` when the insert promise resolved and
  `false` when no database is available or the insert threw; it never inspects `affectedRows`. "Exactly true" therefore
  means "the driver resolved the insert", a weaker check than the GenerationEffects acknowledgement
  (`assertGenerationWriteAcknowledged`, `affectedRows === 1`, `db.ts:1105-1113`), which applies to generation rows only.
  Gaps: every route test mocks `createAuditEntry`; that a resolved insert is a committed row on the real engine is
  NATIVE evidence (J6 reads the started row by attempt id); no existing fault driver can refuse a delivery-start insert
  natively (the injector's audit arm covers `document_generated`/`export_generated` only, `audit-faults.ts:126-149`),
  so the native started-ACK refusal is **NOT EXERCISED** (J5 correction).
- **D11 finished/aborted/failed and the detail whitelist — implemented (SRC).** `downloadRoute.ts:402-407`, `:420-429`;
  `_core/deliveryRouter.ts:139-166`; `affidavitHistory.ts:588-621` (fixed key list), `:623-641`;
  `downloadExportsRoute.ts:142-147`, `:160-168`. Tests + `downloadRoute.test.ts:1281`, `:1331`;
  `document-generation.audit.test.ts:334`; `downloadExportsRoute.test.ts:402`; − `downloadRoute.test.ts:1772`, `:1406`,
  `:2117`. Gaps: no test adds an extra key (filename/URL/answer) and asserts it is dropped; binding and replay 409s write
  no event (console only).
- **D12 estate.export timeline best-effort only — implemented (SRC).** `routers.ts:2696-2717`; all other generation
  activity rows are inside the transaction (`:4535-4550`, `:4587-4594`, `:4629`, `:4687`, `:4737`); the compatibility
  recorders `affidavitHistory.ts:541-549`, `:578-586` have no production caller. Tests + `routers.generation-effects.test.ts:230`;
  `routers.estate-export.test.ts:97`, `:260`; − `:236`; `routers.generation-effects.test.ts:148`. Gap: `ensurePgtContact`'s
  `contact_added` activity (`routers.ts:518-519`) is awaited outside the transaction (neither best-effort nor transactional).
- **D13 Task 7 exhibit/container binding — NOT implemented (open task; reported, not repaired).** `downloadRoute.ts:310-312`
  (Exhibit A row re-selected at delivery), `:345` (only the bare buf compared), `:353-367` (P34 zip, Exhibit A render,
  P1 attachments added after the check, unbound), `:383`; `routers.ts:1436-1466`, `:4497`, `:4506-4514`, `:4479`,
  `:4591`; `replayRow` never references the P1 row (`:293-298`). Positive inclusion tests only
  (`document-generation.audit.test.ts:410-523`; `p9-delivery-proof.routes.test.ts:355`; `downloadRoute.test.ts:399`,
  `:732`); **no negative test**. Static consequence: a P1 regenerated between the P9 generate and its delivery streams as
  Exhibit A with 200; a replaced will/codicil/citation file changes the ZIP undetected.
- **D14 Task 8 export binding — NOT implemented (open task; reported, not repaired).** `downloadExportsRoute.ts:27-35`
  (no binding, documentId or digest field), `:60-147` (no verify; builds from current state after auth, ownership, busy
  and rate checks); `routers.ts:1528-1534`; the `export_generated` digests (`:4628`, `:4680`, `:4730`, `:2700`) are never
  compared. Positive streaming tests only (`downloadExportsRoute.test.ts:263-354`); admission controls tested at `:543-740`;
  **no binding or staleness test**. Static consequence: any owner can POST `{type, estateId}` and stream a fresh build
  with no preceding mutation.
- **D15 delivery routes write no documents/history/activity rows — implemented (SRC).** `downloadRoute.ts:5-8`, `:167`,
  `:387`, `:404`, `:423`, `:437`; `downloadExportsRoute.ts:7-8`, `:78`, `:122`, `:139`, `:144`, `:162`, `:170`; no db write
  call in the builders `routers.ts:1500-2366`. Tests + `downloadRoute.test.ts:462-1993` (not-called assertions on
  `createDocument`, `createDocumentVersion`, `deleteDocument`, `createActivity`); `document-generation.audit.test.ts:259`,
  `:293`; `downloadExportsRoute.test.ts:288`; `routers.bulk-replacement.test.ts:196`. Limit: static grep plus mocked
  non-call assertions; J6 native deltas refresh this.
- **D16 four approved output behaviours present, cited without judgement.** Newest current P9 per deponent in
  `affidavitHistoryContext` (`affidavitHistory.ts:137-160`, `:146-152`); Exhibit A reconstruction (`routers.ts:1434-1466`,
  `:4497`, `:4506-4514`; `downloadRoute.ts:308-312`, `:356-361`; selected from the 200-capped `listDocuments`, so a P1
  older than the 200 newest rows reads as absent — the preflight warning, not an error); P8 primary-affidavit override
  (`routers.ts:127-156`, applied `:4313-4314`, `:4084-4085`, `:4792-4793`; `downloadRoute.ts:204-205`); package/exhibit
  reconstruction (`routers.ts:1676-1701`, `:1332-1395`, `:4710-4740`; `downloadExportsRoute.ts:111-112`). Tests
  `formDeliveryBinding.routes.test.ts:545-546`; `p9-delivery-proof.routes.test.ts:355-420`;
  `document-generation.audit.test.ts:446-502`; `downloadRoute.test.ts:1432`; `downloadExportsRoute.test.ts:322`, `:860`.
- Tracer citation mismatches: none substantive (two-line offsets in `affidavitHistory.ts:524-586`; `routers.ts:1427` is
  the P34 artifact record's empty storage key). Closed 2026-10-28 (ledger): `createAuditEntry`'s boolean contract (D10);
  `ENV.cookieSecret` ← `JWT_SECRET` (`_core/env.ts:43`); `REFERENCED_AFFIDAVIT_FORMS` = P3–P7, P8, P9; `existingDocs` is
  the 200-capped `listDocuments`, so the Exhibit A selection is capped (D16). Still open (B0): `it.each` blocks missed by
  the describe/it grep.

### Row E — Client authentication, CSRF and truthful outcomes (tracer E: 49 calls, `deliveryRouter.ts`, `originPolicy.ts`, `attachmentDelivery.ts`, `fallbackSession.ts`, `previewTransport.ts`, `trpcLinks.ts`, `trpcTransport.ts` read whole; own reads of `deliveryRouter.ts:160-261`, `originPolicy.ts:60-94`, `index.ts:80-215`, `attachmentDelivery.ts:325-372, 450-524` agree)

Server tests are supertest in-process with the handlers mocked (`deliveryRouter.test.ts`) or a real JWT with `./db`
spied (`deliveryBearerAuth.test.ts`); client tests are jsdom with `fetch` stubbed (MOCK). Real `redirect: "manual"`,
`response.type`, download UI, per-tab storage and the proxy/CDN path are UI/DEPLOY.

- **E1 guard order before any parser or authentication — implemented (SRC, own read).** 405 → 400 (query) → 403
  (Origin/`Sec-Fetch-Site`) → 415 → 413 (declared length) at `deliveryRouter.ts:189-218`; `router.all(action,
  deliveryHeaders, guard, ...parsers, handler, errorHandler)` on a case-sensitive strict router `:255-259`; mounted
  after the limiters, before the chatbot and the 50 MB parsers (`index.ts:192-197`, `:209-211`); authentication is
  inside the handler (`downloadRoute.ts:102-103`). Tests + `deliveryRouter.test.ts:98`; − `:137-150` (six methods ×
  three paths, nothing ran), `:152-161`, `:163-187` (13 Origin shapes), `:189-198`, `:200-225`, `:227`, `:240` (413
  without awaiting a byte). Gaps: `/\?./` lets a bare trailing `?` through; no test shows 400 decided before 403 for an
  untrusted Origin. **E1b (nuance, report-only):** app-wide middleware runs first — `deliveryHeaders` (`index.ts:87-89`,
  `:159-160`), the CORS delegate `origin: false` on delivery paths (`:104-106`), the credentialed-origin guard
  (`:122-128`; it consults `Host`, `originPolicy.ts:57-62`, and answers JSON `{error:"forbidden_origin"}` 403 for a
  cookie-bearing cross-origin request, never the accessible page), and the per-IP `downloadLimiter` (`:182-190`), which
  counts refused requests — so the `deliveryRouter.ts:5-6` comment "nothing counted before the guard" is stale. No
  test sends a delivery through the full `index.ts` stack (J1/J3 observe it through the fixture, which mounts the same
  guards, `ui-server.ts:103-105`).
- **E2 origin trust — implemented (SRC, own read).** `originTrusted:168-175` (exact browser serialization, the https
  trusted set, loopback only off the fail-closed tier from the request's own Origin); only `origin` and
  `sec-fetch-site` are read `:200-205`; https-only trusted set `:244-248`; `parseBrowserOrigin`/`isLocalAuthority`
  (`originPolicy.ts:3-21`). Tests + `deliveryRouter.test.ts:422`, `:432`; − `:163-187`, `:189`, `:442` (never
  consults Host, X-Forwarded-*, Referer). Gaps: off the fail-closed tier loopback trust comes from Origin alone (any
  port, http or https); an absent `Sec-Fetch-Site` is accepted (non-browser clients rely on Origin alone); `[::1]` is not
  a loopback form. DEPLOY: that production runs fail-closed with an exact https `APP_URL`; that the browser sends a
  non-null Origin on the native POST (the 2026-10-20 `Origin: null` incident is recorded at `index.ts:152-156`).
- **E3 body type and caps, parser-error mapping — implemented (SRC, own read).** Constants `:20-27`;
  `acceptedBodyType`/`deliveryBodyLimit:177-187`; parsers `:220-223`, `:257`; `deliveryErrorHandler:225-237`
  (413/415 kept, other parser errors 400, non-parser 500 with a class-only log; `res.destroy()` if headers were sent).
  Tests + `deliveryRouter.test.ts:112`, `:124`, `:276`, `:303`, `:372`, `:410`; `deliveryBearerAuth.test.ts:163`;
  − `deliveryRouter.test.ts:200-225`, `:289`, `:325`, `:348`, `:391` (it.each table not read). Gap: a non-numeric
  `Content-Length` becomes NaN and passes the header check (the parser limit still applies; static).
- **E4 cookie-first, Bearer only without a cookie, invalid cookie 401 — implemented (SRC).** `sdk.ts:298-317`
  (`if (!sessionToken)` then `Authorization: Bearer`), `:332-341` (missing user or `sessionVersion` mismatch →
  Forbidden); route mapping to 401 (`downloadRoute.ts:58-69`, `:102-103`; `downloadExportsRoute.ts:47-67`;
  `notesExportRoute.ts:22-24`, `:183-188`). Tests + `deliveryBearerAuth.test.ts:77`, `:84` (valid cookie wins over a
  different Bearer), `:129`; − `:90-95` (invalid cookie never falls through), `:97-104`, `:106`, `:111`, `:117`,
  `:122` (version-revoked 401). Gaps: a present but **empty** cookie value lets Bearer be consulted (`parseCookies`,
  `sdk.ts:163-170`, returns the empty string; static and benign: an empty cookie is no session; untested); the `Bearer `
  prefix check is case-sensitive.
- **E5 token never in a URL, descriptor field, body or reviewed log — PARTIAL (SRC; by-design nuances).**
  Descriptor validated before any credential read (`attachmentDelivery.ts:68-79`); the token is added only as
  `headers.Authorization` `:473-481`; native hidden inputs are fields + `attemptId` `:103-121`; handoff uses a blob URL
  `:659-671`; `shared/postDelivery.ts:15-28`; tRPC sends it only through the headers fallback (`trpcLinks.ts:59-69`);
  server logs are class/status only (`deliveryRouter.ts:235`; `downloadRoute.ts:63-65`, `:418-419`). Tests
  + `attachmentDelivery.test.tsx:108`, `debugCollector.redaction.test.ts:61`; − `attachmentDelivery.test.tsx:833`
  (absent from every URL, body, anchor, toast and console argument), `:151`, `trpcLinks.test.ts:68`, `:84`,
  `debugCollector.redaction.test.ts:55`. Nuances: the token is returned in the `X-Rotated-Session` response header on
  non-delivery paths (`context.ts:142`; CORS exposes it `index.ts:102`) — by design; `downloadRoute.ts:184` logs the
  binding refusal reason and form code (not class-only; no token); the `formDelivery` callers' field set was not fully
  traced (row D covers `routers.ts:4553-4571`).
- **E6 rotation storage and clearing — implemented (SRC).** `fallbackSession.ts:9-26`, `:34-46` (generation bumps
  even if removal throws); `trpcLinks.ts:22-29`, `:57-58` (default `onResponse` stores `X-Rotated-Session` verbatim);
  `trpcTransport.ts:75-80` (on every attempt, retried 5xx included); `botClient.ts:18-38`, `:53`, `:262` (duplicate
  reader/writer); the only clearers are `useAuth.ts:29-55` (after logout, even on a server error, then a hard reload) and
  `Settings.tsx:369-377`. Tests + `fallbackSession.test.ts:40`, `:53`, `:60`; `trpcLinks.test.ts:90`, `:163`;
  − `fallbackSession.test.ts:47`, `:69`; `attachmentDelivery.test.tsx:190` (never writes the store). Gaps (known,
  REG-16/17/21): any non-empty header value is stored without validation, so a cookie tab can switch to the fetch
  path; a 401 or server-side revocation never clears the tab's token; the initial mirror write comes from the runtime
  (E13).
- **E7 native vs fetch and observed-state feedback — implemented (SRC, own read).** `attachmentDelivery.ts:335-342`
  ("download requested"), `:343-371` ("preparing…" → "download started" only on `handed-off`, else the refusal or
  generic sentence; cancelled retires), `:7-25` (comment: handed-off is never saved or received), owner-scoped feedback
  `:205-304`; `EstateDetail.tsx:7497-7503`. Tests + `attachmentDelivery.test.tsx:430`, `:451`; `postDownload.test.tsx:67`,
  `:73`; `EstateDetail.bearer-delivery.test.tsx:203`, `:326`; `Home.bearer-export.test.tsx:111`;
  − `Home.bearer-export.test.tsx:132`, `attachmentDelivery.test.tsx:135`, `:143`, `:1009`, `:1085`, `:1104`, `:1243`.
  By design: the native path observes nothing after `form.submit()`.
- **E8 bounded response consumption — implemented (SRC, own read).** Ceilings 512 MiB ZIP / 64 MiB DOCX-PDF /
  64 KiB refusal; 900 s headers, 60 s idle, 1,800 s total; blob revoke 120 s; native path unbounded (`:32-41`);
  `readBody:436-470`; declared length digits-only and within the ceiling, exact match only for identity encoding
  `:495-519`; every non-handoff exit aborts and cancels `:527-537`. Tests + `attachmentDelivery.test.tsx:539`, `:422`;
  − `:567`, `:577`, `:517`, `:524`, `:530`, `:654-739`. Gaps: the whole body is buffered in memory before handoff;
  the exact-length check is skipped for encoded bodies (by design).
- **E9 handoff validation and `sameSession` — implemented (SRC, own read).** `:481-493` (manual redirect, `basic`,
  session after headers), `:500-506`, `:569-578` (`attachment; filename="…"`, extension by kind), `:622-657`
  (ZIP/PDF markers only; interior corruption passes, no ZIP64 — disclosed), `:81-83`, `:454-457`, `:520` (token and
  generation at headers, every chunk, before handoff), `:349-351` (generic sentence after a token change); server
  `sendAttachment` sets headers then ends (`deliveryRouter.ts:145-166`). Tests + `attachmentDelivery.test.tsx:373`,
  `:414`, `:362`; − `:489`, `:501`, `:509`, `:637`, `:301`, `:312`, `:334`, `:349`, `:356`, `:272`, `:283`.
- **E10 second-click suppression — implemented (SRC, own read).** Fetch: per-descriptor and per-control hold for the
  attempt's lifetime (`:334`, `:85-101`, `:123-149`, `:352-366`); native: the control is disabled for 2 s only
  (`:41`, `:113-120`); the server links a repeated `attemptId` as `retryOf` within 10 min but never refuses it
  (`deliveryRouter.ts:98-128`). Tests + `attachmentDelivery.test.tsx:771`, `:926`; − `:753`, `:875`, `:895`,
  `postDownload.test.tsx:105`. Gap (by design, disclosed): native de-duplication is time-based and per control.
- **E11 Task 12 preview isolation — PARTIAL as recorded by Task 12 (SRC).** Only `document.preview` queries go
  unbatched through the bounded reader (`trpcLinks.ts:31-77`); 4 MiB 2xx (provisional) / 16 KiB refusal / 15 s idle /
  60 s total (`previewTransport.ts:12-20`); generation checked at start, every chunk and end, aborts rethrown, non-JSON
  2xx refused, rebuilt Response carries status and content-type only `:47-104`; cache partitioned by generation
  `:156-163` (default-hashed helpers cannot see those entries — disclosed); modal options `EstateDetail.tsx:7420-7436`.
  Tests + `previewTransport.test.ts:78`, `:91`, `:313`, `:374`; `trpcLinks.test.ts:120`, `:145`;
  `EstateDetail.preview-lifecycle.test.tsx:753`, `:785`; − `previewTransport.test.ts:99-386` (U1–U16),
  `trpcLinks.test.ts:199`, `EstateDetail.preview-lifecycle.test.tsx:281`, `:294`, `:371`, `:464`, `:589`, `:629`,
  `:680` (R15: the preview creates and revokes no Object URL), `trpcTransport.test.ts:62-124`. Gaps: the "same-tab
  guard" named in the prompt is, in code, the generation-partitioned cache plus the generation-only session guard (a
  token rotation mid-body is accepted; only `clearFallbackSession` ends a read) — Task 12 P8 as accepted (REG-36);
  the cap is provisional (REG-38). **E11b (new observation, report-only):** the preview modal's DOCX download is a
  separate bounded fetch with no AbortSignal (`EstateDetail.tsx:7439-7440`, `:7468-7514`; `attachmentDelivery.ts:397-403`),
  so closing the modal drops only its feedback — a handoff can still occur after close with no message (static; no
  test covers closing during the download). Tests + `EstateDetail.bearer-delivery.test.tsx:305`; − `:342`,
  `EstateDetail.preflight.test.tsx:466`, `:503`, `:531`, `:567`.
- **E12 no private raw error text on the reviewed paths — implemented (SRC).** `deliveryRouter.ts:29-57`, `:80-96`
  (navigation: fixed sentences only; fetch: the route's public JSON sentence, which by design can name a form, person or
  value, `:43-44`), `:225-237`; `downloadRoute.ts:63-65`, `:415-419`; client fixed sentences and JSON-only refusal
  display (`attachmentDelivery.ts:55-62`, `:133-140`, `:554-567`; `previewTransport.ts:24-40`, `:106-109`;
  `trpcTransport.ts:14-27`, `:90`, `:107-109`). Tests + `deliveryRouter.test.ts:488`, `attachmentDelivery.test.tsx:603`,
  `:613`; − `deliveryRouter.test.ts:466`, `:510`, `attachmentDelivery.test.tsx:629`, `:334`, `:1140`. Nuances:
  `downloadRoute.ts:184` logs reason + form code; outside the delivery paths `useAuth.ts:44` logs the raw logout error
  object to the console (report-only).
- **E13 runtime `message` listener origin/source validation — UNVERIFIED (open; REG-16).** No listener exists in
  `client/src` (`main.tsx` grep: only `createAppTrpcLinks()` at `:40`); the mirror into `sessionStorage` is injected by
  `vite-plugin-manus-runtime` (`vite.config.ts:7`, `:175`) under `node_modules`, which the tracer rules forbade reading
  and which Task 18 does not read either (dependency code is untrusted data, not reviewed source). Stays OPEN before
  production, as the queue records (`:454`, `:513`).
- **E14 what is not claimed — stated (SRC).** `deliveryRouter.ts:139-144` (finished = handed to the transport,
  never receipt); `downloadRoute.ts:404-406`; `attachmentDelivery.ts:16`, `:39-40`, `:339`, `:359`;
  `EstateDetail.tsx:7502-7503` ("a handoff, not a saved file"); `fallbackSession.ts:38-46` and `useAuth.ts:47-55`
  (this tab only); server revocation is by `sessionVersion` or a missing user (`sdk.ts:332-341`). Tests
  + `attachmentDelivery.test.tsx:451`; − `Home.bearer-export.test.tsx:132`, `EstateDetail.bearer-delivery.test.tsx:326`.
  Gaps: `Settings.tsx:376` toasts "Account deleted and signed out" (other tabs fail only because the user no longer
  exists). Closed 2026-10-28 (ledger): `auth.logout` (`routers.ts:2551-2554`) calls `revokeUserSessions` (`db.ts:236-242`,
  `sessionVersion + 1`), so logout does revoke every issued token server-side; the tab's own store is cleared by
  `useAuth.ts:48`; the portal logout (`:6289`) clears only its cookie.
- Tracer citation notes: `botClient.ts:7`, `:30` comments cite `main.tsx:50-63` / `:73-78` for code that now lives in
  `trpcLinks.ts:22-29` and `fallbackSession.ts` (stale in-source comments, report-only); the brief's "runtime message
  listener in main.tsx" is in the plugin, not `main.tsx`; the brief's "object URL revocation" for the preview is
  inapplicable (R15) — the only blob revocation is the attachment handoff (120 s). Every map citation checked matched.
  Closed 2026-10-28 (ledger): `parseCookies` empty value (E4); `context.ts:99-145` rotation past 50 % of lifetime (E6);
  logout revocation (E14). Still open (B0): `deliveryRouter.test.ts:391` table; `sdk.session-revocation.test.ts` and
  `sdk.account-deletion.test.ts` by name; `EstateDetail.p16-review.test.tsx` preview cases.

### Row F — Generated-byte non-retention and connection checks (tracer F: 50 calls, 26 files; own reads of `storage.ts:45-100`, `routers.ts` generate ranges via tracer D, `trpc.ts:205-241`, the three QA instruments agree)

Static inventory plus mocked tests (MOCK: `storagePut`/provider mocked, fake drivers); the current live evidence of
zero generated-byte storage is HIST (Task 3 `r5-p1-before/after`, Task 16, 4, 5 and the Task 6 repair receipts:
PUT/presign-PUT counters unchanged, `currentRowsRetainingGeneratedBytes: 0`) and is refreshed by J1–J6 (NATIVE/UI).
Provider-side proof (S3 access logs, CloudTrail data events) is DEPLOY.

- **F1 complete `storagePut` caller census — implemented (SRC).** `PutObjectCommand` is imported and sent only in
  `providerPutExact` (`storageProvider.ts:21`, `:503`, `:535`); `providerPutExact` is reached only from `storagePut`
  (`storage.ts:88`) and the operator script `scripts/migrateLegacyStorage.ts:33`. Production `storagePut` call sites:
  twelve in `routers.ts`, each a decoded user upload — `:2504` support-report attachment, `:3084` will, `:3134` foreign
  grant, `:3196` codicil, `:3375` legal evidence (four kinds), `:3652` consent document, `:4975` and `:5129`
  dispensation order (the latter refusing PGT deliveries `:5124-5126`), `:5229` citation evidence, `:5789` letterhead
  image, `:5835` letterhead DOCX, `:6767` note attachment (dynamic import `:6758`) — plus `_core/imageGeneration.ts:104-122`
  (`generateImage`, which would PUT newly generated AI-image bytes as `transient`) which has **no production caller**
  (grep). None lies inside the generate (`:4270-4745`) or export (`:2655-2720`) ranges. Tests: `storage.test.ts:101-316`,
  `storage-s3.test.ts:346-967`, `storage-platform.test.ts:60-122`, `routers.support-report.test.ts:46`,
  `_core/imageGeneration.test.ts:34`, `:42`. Gaps: only `storagePut(`, `providerPut`, `providerPutExact` and
  `PutObjectCommand` were searched by the tracer; closed 2026-10-28 (ledger): `CopyObjectCommand`, `CreateMultipartUpload`,
  `UploadPartCommand`, `lib-storage` and `createPresignedPost` occur nowhere in non-test `server/`, `client/src` or
  `shared/` (row B9 found no presigned PUT); no structural test pins the caller set; `imageGeneration.ts` is held back by review only;
  `migrateLegacyStorage.ts` treated as operator-only from its path. B3-P2 makes this census a hashed receipt.
- **F2 generation mutations write no bytes — implemented (SRC).** `document.generate` renders, digests and discards
  (`routers.ts:4478-4485`, comment "Generated bytes are not retained (Nick, 2026-10-19)"); P1 attachments, Exhibit A and
  P34 entries are built into a throwaway archive only to fail early (`:4498-4521`); provenance row `storageKey ""`,
  `storageUrl ""` (`:4582-4583`; bulk `:4669-4670`; `generatedAffidavitRecord` `affidavitHistory.ts:457-458`; the P34
  artifact record `routers.ts:1420-1431` with `storageKey: ""` at `:1427`, from tracer D); effects rows carry ids,
  digests and summary text under allowlists (`affidavitHistory.ts:524-539`, `:551-576`); activation only for a non-empty
  key (`:416-428`); letters commit an export audit and activity with no document row (`:4622-4632`); `estate.export`
  builds no archive and commits a digest-less audit (`:2662-2718`, "The archive is never stored" `:2673-2675`); the
  effects writers insert scalar rows under the estate lock (`db.ts:1083-1121`, `:1140-1288`); no table these flows
  write has a byte-typed column (`drizzle/schema.ts` grep: `documents`/`document_versions` keys `varchar(512)`,
  `activity.summary` and `audit_log.detail` `varchar(2000)`, `stored_objects` metadata only; no blob/longtext/binary
  anywhere). Tests + `routers.generation-effects.test.ts:148` (`storagePut` asserted not called `:120`), `:215`,
  `:230`; `document-generation.audit.test.ts:197`, `:279`, `:615`; `routers.generateAllP8.retained-primary.test.ts:142`,
  `:160`; `routers.estate-export.test.ts:105`, `:140`, `:158`; `affidavitHistory.generation-effects.test.ts:27`, `:38`;
  `db.generation-effects.test.ts:62`, `:184`; − `routers.generation-effects.test.ts:178`, `:193`, `:204`, `:243`, `:264`;
  `affidavitHistory.generation-effects.test.ts:105`; `db.generation-effects.test.ts:90`, `:224`, `:242`. Gaps: the
  `document_override` activity summary can carry substituted answers (text metadata bounded by `varchar(2000)`);
  `versionRowFor` copies the superseded row, so a legacy row's non-empty key is carried into history (a reference to
  lawful legacy bytes, inferred).
- **F3 form and export deliveries stream once and discard; events carry no bytes, filename or URL — implemented
  (SRC, own read).** `downloadRoute.ts:343-345` (re-render, digest check), `:351-380` (archive assembled in memory;
  attachments and Exhibit A read, not written), `:382-407` (started detail: ids, digests, sizes, `inputsHash`,
  `estateRevision`; 503 unless acknowledged; sent = ids, digest, byte count), `:415-429`; `downloadExportsRoute.ts:106-147`;
  `deliveryEvent` allowlist `affidavitHistory.ts:588-621` ("never a filename, URL, answer or byte"); `deliveryAttempt`
  `deliveryRouter.ts:104-128`. Tests + `downloadRoute.test.ts:701`, `:1014`, `:1045`, `:1314`;
  `downloadExportsRoute.test.ts:198`, `:271`, `:415`, `:459`, `:1020`, `:1037`; − `formDeliveryBinding.races.routes.test.ts:508`,
  `formDeliveryBinding.media.routes.test.ts:432-433`. Row D15 covers the no-row assertions. Note: `inputsHash` is an
  unsalted digest of low-entropy answers (metadata, not bytes).
- **F4 notes route the same — implemented (SRC).** `notesExportRoute.ts:110-126` (terminal event from scalars),
  `:194-238` (admission, ownership, caps 413, in-memory render, digest; `bytes` kept as a scalar "so a pending audit
  write never keeps the PDF reachable" `:237-238`), `:239-268` (nothing sent unless the start write is acknowledged).
  Tests + `notesExportRoute.audit.test.ts:208`, `:252` (createDocument/Version/delete/activity/storagePut not called),
  `:778`; `notesExportRoute.retention.test.ts:81` (structural: no closure captures pdf/notes/req/res, with a positive
  control `:68`); − `notesExportRoute.limits.test.ts:775`, `notesExportRoute.audit.test.ts:324`.
- **F5 in-memory and client retention — PARTIAL (SRC; report-only).** Server structures hold ids, counters and
  timestamps only: `recentAttempts` (`deliveryRouter.ts:98-128`, ≤5,000, 10-min prune), `usersBuildingInMemory`
  (`downloadExportsRoute.ts:43-45`, `:98-104`), notes `accounts` (`notesExportLimits.ts:66-105`), `recentReports`
  (`exportFailureReporting.ts:44-74`), `costlyRouteCounts` (`trpc.ts:195-201`); delivery responses carry
  `Cache-Control: no-store` and `Referrer-Policy: no-referrer` (`deliveryRouter.ts:64-70`; no header test inventoried).
  Client: the preview caches a validated JSON payload of typed sections (not DOCX/ZIP/PDF, not HTML; may include
  letterhead image data) in React Query memory partitioned by session generation (`previewTransport.ts:116`, `:150-163`;
  `EstateDetail.tsx:7420-7434`); no `gcTime` is set anywhere in `client/src` and the QueryClient runs on library defaults
  (closed 2026-10-28, see Gaps); intake form data is auto-saved to
  `localStorage` (comments `EstateDetail.tsx:946-1143`; intake data, not document bytes). Tests
  + `notesExportLimits.test.ts:215`, `exportFailureReporting.test.ts:339`. Closed 2026-10-28 (ledger): no `writeFile`,
  `createWriteStream`, `tmpdir` or `mkdtemp` call exists in non-test `server/**/*.ts` (B3-P2 repeats that grep as a
  hashed receipt); `new QueryClient()` runs on defaults (`main.tsx:11`, `@tanstack/react-query ^5.90.2`), so a closed
  preview's sections may stay in tab memory for the library's documented 5-minute default (`node_modules` not read).
  Gaps: generic-typed maps are invisible to a `new Map(` grep (the brief's method, corrected by the tracer). DEPLOY: heap
  snapshots of a running server or tab.
- **F6 QA instruments outside the application, explicitly armed — present as described (SRC, own read).** The three instruments
  live only under `.work/hybrid-remediation/fixture/` and are installed only by the fixture launchers; `server/` contains
  no hook (grep for `installFictional`, `capture-next`, `audit-fault`, `PROBATE_QA`, `hybrid-remediation`, `.work/`,
  `preview-fault` finds nothing; `FICTIONAL` occurs only as test sentinels). Capture: arm file + allowlisted estate +
  200 body ≤16 MiB on the three paths, consumed by rename, written with `wx`, metadata `applicationStorage: false`
  (`capture-deliveries.ts:7-53`); faults: loopback-pool assertions, label/estate/mode/age checks, consumed by rename
  (`audit-faults.ts:25-71`); preview faults: task12 server only. Disclosed: a capture writes the full delivered body to
  `fixture/captures/` as intentional QA evidence that the application does not govern; the launchers' `VITEST=true`
  exempts the costly-route limit on the fixture (§7). DEPLOY: that no production build includes the fixture launchers
  (entrypoint not inspected; `ui-server*.ts` are not part of `pnpm run build`).
- **F7 lawful retained uploads enumerated — PARTIAL (SRC; inventory).** The twelve upload categories above; key
  columns `estates.willStorageKey`/`foreignGrantStorageKey`, `settings.letterheadStorageKey/Url`, the support-report
  `attachmentStorageKey`, `citation_records` citation/serviceAffidavit/response keys (`schema.ts` grep); legacy generated
  rows that kept a `storageKey` are still activated (`affidavitHistory.ts:416-428`) and P9 Exhibit A reads a legacy P1
  row's retained bytes (`downloadRoute.ts:308-310`, `:359`) — reads, not writes. Tests `routers.support-report.test.ts:46`,
  `routers.canonical-events.test.ts:371`, `:441`, `:474` (+), `:420`, `:495` (−). Closed 2026-10-28 (ledger): the client
  intake stores a text payload (≤45,000 bytes, `routers.ts:6372-6374`; `schema.ts:872`) and calls no `storagePut`; the
  citation evidence writers go through `assertCitationEvidenceKeys` (`routers.ts:526-552`, `:5292`). Gaps: procedure
  names at `:4975`, `:5129`, `:5229` fall outside the grep context.
- **F8 notes and staff-report limits gate only their own feature — implemented (SRC).** `admitNotesExport` is called
  only at `notesExportRoute.ts:194-199`; `notesExportLimits` is consumed in production only by the notes route;
  `exportFailureReporting.ts:1-17`, `:33-38`, `:96-128`, `:153-198` (total, never throws; saturation/rate limit only
  skip the staff row); every caller fires and forgets (`routers.ts:2684`; `downloadExportsRoute.ts:139`, `:170`;
  `notesExportRoute.ts:260`, `:275`). Guard tests are **not** in `exportFailureReporting.test.ts` (the brief's
  assumption; corrected): `downloadExportsRoute.test.ts:1192-1211` (after the per-user window: the same user's retry,
  other exports and bulk generation proceed; `createFailureReport` called exactly the cap), `document-generation.audit.test.ts:234`
  (Generate anyway still generates after rate-limited reports), `notesExportRoute.isolation.test.ts:300-373` (R16: with
  every notes lease held, a Generate-anyway form delivery, estate/package export, letters mutation, notes upload and
  CRUD succeed and every costly-route bucket keeps its budget), `notesExportRoute.limits.test.ts:809`; bounds
  − `exportFailureReporting.test.ts:289`, `:314`, `notesExportLimits.test.ts:143`, `notesExportRoute.limits.test.ts:408`.
  Gaps: no test proves the **notes export itself** proceeds after the staff-report limit; the shared costly-route
  `document_generation` bucket (`trpc.ts:210-240`; callers `downloadRoute.ts:190`, `downloadExportsRoute.ts:97`) is a
  real per-user limit (8 per 60 s window per process, file-storage §6) that refuses generation **and** delivery with
  429 — the approved budget, not a notes/report limit, and the fixture's `VITEST` exemption hides it; the generate
  mutations report faults through `controlledGenerationError` (`routers.ts:1480-1520`, called at `:4605-4607`,
  `:4634-4636`: one staff report for a fault or a `report` refusal, then a 500 reference sentence or a 409), not the
  export reporter.
- **F9 missing information warn-only; integrity boundaries separate — implemented (SRC).** RULES.md Rule 24
  `:1485-1549` (data-class blockers warn on single-form actions `:1492-1496`; sworn-truth gates fail-closed
  `:1497-1502`; "Answer & generate anyway" `:1515-1521`; bulk and package stay hard-gated `:1522-1523`; never resurrect
  a disabled button `:1547`); `PreGenerateDialog.tsx:562`, `:564`, `:1235`, `:2372-2391` (`generateAnyway: true` when
  not ready; the proceed button is disabled only while proceeding/applying, `hardBlocked` or the P45 lock status);
  `EstateDetail.tsx:7349-7350`, `:9060-9133`; server lifts only by `allowNotApplicable`/`allowIncompleteDraft`
  (`routers.ts:1039-1086`), set by `generateAnyway === true` with a `document_override` activity (`:4319`, `:4408`,
  `:4447-4449`, `:4541-4549`, `:4567`); delivery re-renders the draft with the same flags (`downloadRoute.ts:316-318`).
  Integrity refusals stay distinct: 401/403/404 auth and ownership with `idor_attempt`, 409 stale/tampered, 503
  unconfirmed commit or start audit, 429/503/413 resources (`notesExportRoute.ts:183-219`, `:195-199`, `:230`,
  `:248-262`; `downloadExportsRoute.ts:87-97`; `downloadRoute.ts:190`, `:345`, `:384-401`; `routers.ts:2671`, `:4481`,
  `:4570-4571`; `db.ts:1088-1137`). Tests + `formDeliveryBinding.routes.test.ts:391`, `p9-delivery-proof.routes.test.ts:286`,
  `routers.preflight.test.ts:404`, `p1-codicil-delivery.test.ts:153`, `PreGenerateDialog.test.tsx:1828`,
  `EstateDetail.p3-longform.test.tsx:236`; − `PreGenerateDialog.test.tsx:1594`, `:427`, `p7-draft-access.test.ts:195`,
  `routers.generation-effects.test.ts:255`, `db.generation-effects.test.ts:232`, `db.generation-effects.outage.test.ts:12`,
  `formDeliveryBinding.races.routes.test.ts:499`, `notesExportRoute.identity.test.ts:88`, `notesExportRoute.limits.test.ts:347`.
  Gap: no server test by name asserts that `assertFormApplicable` still throws without `generateAnyway` or that bulk and
  package refuse a not-applicable form (not searched by name). J2 is the UI evidence.
- Tracer corrections to the brief (recorded): the guard tests live in the route suites, not `exportFailureReporting.test.ts`;
  generic-typed maps need a `Map<` grep; the preview cache holds JSON sections, not HTML; "three delivery paths" include
  the notes route; `documentRowFor` (`affidavitHistory.ts:396-413`) copies the record builder's key verbatim. Open
  (read-only follow-ups): `versionRowFor`; whether `recordDocumentDelivery`/`recordExportDelivery`/`recordNotesDelivery`
  all route through `deliveryEvent` (own read of `:623-641` via the map: yes, thin wrappers). Closed 2026-10-28 (ledger):
  temp-file and copy/multipart searches, client-intake upload storage, React Query defaults and the costly-route table
  (`trpc.ts:150-176`: `document_generation` 8/60 s, `uploads` 12/60 s, `ai_import` 6/60 s).

## 6. Test inventory and focused file groups (tracer I: 44 calls, 74 findings over `vitest.config.ts`, `vitest.setup.ts`, 60+ test files; final)

**Execution-safety facts (SRC).** `vitest.config.ts:31-37` includes `server/**/*.test.ts` with no exclude list, so a plain
`vitest run` collects `server/storage.live-uat.test.ts`; only its own `describe.runIf(RUN_STORAGE_LIVE_UAT === "true")`
stops it, and when it runs it does real database writes and real provider calls with inherited credentials. The runner
scrubs that variable and every `AWS_*`/`STORAGE_S3_*` name (`run-gates.cjs:19-29`), and `tests` mode also passes
`--exclude` (`:38`); **no focus list ever names it.** `client/**` runs under jsdom, everything else under node
(`:38-40`); the setup file only raises the Testing Library timeout (`vitest.setup.ts:8-11`): no network guard, no env
scrub — each file isolates itself. AWS SDK: only `storage-s3.test.ts` references `@aws-sdk`, mocking
`credential-providers` (`:21-23`, stub providers that throw if resolved `:11-18`), `client-s3` (`:25-61`) and
`s3-request-presigner` (`:63-65`); nothing mocks `client-sts` (none is used in code). All 26 ARN lines across five
server test files use account `000000000000` or `123456789012` (fictional). **Flagged for a read-only B0 check before any
focused run:** `storage-platform.test.ts:127-135`, `:155-163` sets a complete fictional vault profile at
`https://s3.ca-west-1.amazonaws.com` with **no SDK mock** (safe only if those cases never construct or use the S3 client;
unverified by the tracer — B0 reads the three cases and the code they reach; if a client would be built, the file is
excluded from the focus lists and the question goes to Nick, Q9); `routers.storage-lifecycle.test.ts`, `notes.test.ts`
(`:14-17`, `storagePut` only mocked) and `storage-authorization.test.ts` (`:29-36`, partial `./storage`,
`./storageProvider` unmocked) load the real provider module — under the scrubbed runner environment an unexpected call
would hit `usingPlatformStorage()` → an empty Forge URL and fail without a network peer (static); B0 confirms by reading
the cases. `deliveryBearerAuth.test.ts:9-12` keeps an inherited `JWT_SECRET` with `||=` (the runner supplies a random
one). `_core/deliveryRouter.test.ts:65` and `downloadExportsRoute.test.ts:821`, `:1138`, `:1157` call `listen(0)` with no
host (an ephemeral port on all interfaces for the test's lifetime; `cors.test.ts:67` and the notes suites bind
`127.0.0.1`) — a local-firewall prompt is possible, no remote peer is contacted. The fake-driver suites
(`db.*generation-effects*`, `db.replaceCurrentDocuments*`, `db.storage-authorization`) mock `drizzle-orm/mysql2`; a missing
mock would reach the real driver with the runner's unset `DATABASE_URL` (fails, no peer).

**Focused invocations (fresh labels; each ≤ 25 files; node unless stated; the row letters are the prompt's A–F).**

| Label | Rows | Files |
|---|---|---|
| `claude-task18-focus-p1-pass1` | A, B | server/storage-s3.test.ts, env.validation.test.ts, _core/index.startup-storage.test.ts, storageRegistry.test.ts, legacyForgeStorage.test.ts, storage.test.ts, trpcErrorBoundary.test.ts, routers.storage-lifecycle.test.ts, storage-platform.test.ts (the last two only after the B0 check clears them) |
| `claude-task18-focus-p2-pass1` | C | server/storage-authorization.test.ts, db.storage-authorization.test.ts, storage.read-boundary.test.ts, storage.tenancy.test.ts, storageNamespace.test.ts, storage.test.ts, storageRegistry.test.ts, legacyForgeStorage.test.ts, notes.test.ts, notesExportRoute.isolation.test.ts, notesExportRoute.identity.test.ts, routers.estate-export.test.ts, downloadExportsRoute.test.ts, estateExport.test.ts, letterhead-assets.test.ts, p5-draft-access.test.ts, p7-draft-access.test.ts, p8-draft-access.test.ts, p11-draft-access.test.ts |
| `claude-task18-focus-p3-pass1` | D, E | server/_core/deliveryRouter.test.ts, deliveryBearerAuth.test.ts, cors.test.ts, formDeliveryBinding.test.ts, formDeliveryArtifact.test.ts, formDeliveryBinding.routes.test.ts, formDeliveryBinding.races.routes.test.ts, formDeliveryBinding.media.routes.test.ts, formDeliveryBinding.body-size.routes.test.ts, p9-delivery-proof.routes.test.ts, downloadRoute.test.ts, downloadExportsRoute.test.ts, notesExportRoute.limits.test.ts, notesExportRoute.audit.test.ts, notesExportLimits.test.ts |
| `claude-task18-focus-p4-pass1` | D, F | server/db.generation-effects.test.ts, db.generation-effects.outage.test.ts, routers.generation-effects.test.ts, affidavitHistory.generation-effects.test.ts, routers.bulk-replacement.test.ts, db.replaceCurrentDocuments.test.ts, db.replaceCurrentDocumentsBatch.test.ts, document-generation.audit.test.ts, exportFailureReporting.test.ts, failureReporting.test.ts, notesExportRoute.retention.test.ts, estateExport.test.ts, affidavitHistory.test.ts, affidavitHistory.batch.test.ts |
| `claude-task18-focus-p5a-pass1` (jsdom) | E, F | client/src/lib/attachmentDelivery.test.tsx, fallbackSession.test.ts, previewTransport.test.ts, trpcLinks.test.ts, trpcTransport.test.ts, postDownload.test.tsx, utils.test.ts, debugCollector.redaction.test.ts |
| `claude-task18-focus-p5b-pass1` (jsdom) | E, F | client/src/pages/EstateDetail.p8-download.test.tsx, EstateDetail.preflight.test.tsx, EstateDetail.preflight-busy.test.tsx, EstateDetail.preview-lifecycle.test.tsx, EstateDetail.task13-recovery.test.tsx (split per the jsdom starvation note at `vitest.config.ts:7-18`) |

The router regression sweep the tracer lists (P6, 24 files incl. `verify-all-forms.test.ts` with 160 cases) is covered
by the full serial gate (B2) and is not run separately. Per-file facts (imports, `it` counts, mocks, env writes, ports)
are saved verbatim in `test-inventory.md` from the tracer return; the tracer did not inventory `shared/**/*.test.ts` or
`server/**/*.spec.ts` (also in the include glob) and left the extra router files' imports unread.

Mock evidence per AWS-shaped test file (L1-09): `storage-s3.test.ts:11-65` (credential providers, client-s3, presigner
mocked); `env.validation.test.ts` (no SDK; pure config functions re-imported); `_core/index.startup-storage.test.ts:72`
(`../storageProvider` mocked); `storageRegistry.test.ts:37` (`./storageProvider` mocked); `storage-platform.test.ts`
(no SDK mock — Q9 gate). Focus invocation form (L1-08), one per label with the file list exactly as tabled:

```
& 'C:\Program Files\nodejs\node.exe' '.work\hybrid-remediation\run-gates.cjs' claude-task18-focus-p1-pass1 focus --test-file=server/storage-s3.test.ts --test-file=server/env.validation.test.ts ... (every file of the row)
```

Rules for every focused invocation: a fresh label, ≤25 files, only paths matching `^(server|client/src)/…\.test\.tsx?$`;
`server/storage.live-uat.test.ts` is never named (focus mode does not exclude it; it is skipped only by the scrubbed
`RUN_STORAGE_LIVE_UAT`, own read `storage.live-uat.test.ts:24-26`, and it imports the real provider primitives); any test
with AWS-shaped values must be shown (file:line) to mock the SDK sends, signing, STS and default credential resolution
before it runs; no test file is added, edited or re-labelled. The superseded r1 grouping (four labels
`claude-task18-focus-abc/d/e/f-pass1`, 43 files) is moved to `gate-a-notes.md` at the save and is **not to be run** (L1-10).

Every group's `results.json`, log and console freeze line are read; counts are reported per group; a nonzero exit ends
that group's record as a result (never re-run to green). The full serial gates (B2) remain the authority: the focused
groups exist to bind each matrix row to named cases.

## 7. Fixture, harness and the six journeys (tracer G: 68 calls, 48 files, nothing executed; own reads of the four launcher/runner files)

**Gate runner facts that shape Gate B (G1).** `run-gates.cjs` refuses `.env*` only in the root and `chatbot/`, only at
startup (`:15-18`); its child environment is built from scratch (PATH inherited; `NODE_ENV=test`, `VITEST=true`, random
secrets; build gate `NODE_ENV=production`, `:19-35`, `:65`); **`focus` mode does not exclude `storage.live-uat.test.ts`**
(`:39`) — it stays skipped only because `RUN_STORAGE_LIVE_UAT` is scrubbed and the file is `describe.runIf` (`storage.live-uat.test.ts:24-26`),
so the focused sets in §6 must never name it; the frozen-baseline check runs before the loop and after each gate but reads
only `baseline.json.frozen` (HEAD/status/index/changed are not enforced, `:45-55`, `:83`); `results.json` is rewritten per
run and written before the post-gate freeze (`:79` vs `:83`), so a freeze failure appears only on the console — Gate B
captures the console too; a used label can be reused for a gate that has not run under it (`:60-61`) — Gate B still uses
fresh labels for every invocation. Render verify (`render-freeze.ts`) hashes every `.xml`/`.rels` part except the whole
`docProps/core.xml` and the preview JSON for 26 codes and overwrites `render-checks/<label>/hashes.json` (`:14-15`, `:30-48`):
package/XML equality only (FROZEN). `verify-p1-delivery.cjs` compares only `word/*` parts against the Task 3 P1.

**Fixture UI server (G3; own read).** Serves the built `dist/public` only (no Vite), so B2's build precedes B4; records
the hashes of 20 named files plus `dist/public/index.html` (not a bundle manifest: the JS/CSS bundles and modules such as
`sdk.ts`, `originPolicy.ts`, `context.ts` are not hashed) in `ui-status.json` and `/__fixture/health`; the only full served-file
manifest tool is `task13/claude-pass02/qa/build-manifest.cjs` (used at B4). Guards: loopback DSN host/port/database
(`ui-server.ts:38-41`), `NODE_ENV=development` and `APP_URL` (`:42`), live `@@port`/`@@datadir`/`database()` (`:43-48`);
the launcher refuses `.env*`, requires `status.json` ready, rebuilds a whitelisted environment and refuses any `AWS_*`,
`STORAGE_S3_*`, `LEGAL_RECORD_STORAGE_APPROVED` name (`start-ui.cjs:6-26`). **Consequences:** `VITEST=true` makes
`documentGenerationAllowed` return true (`_core/trpc.ts:215-218`, `:232-236`) and selects the Forge path emulated by the
fixture's own `/v1/storage/presign` and `/__fixture/object` (`ui-server.ts:79-102`, counters `presignGet/presignPut/objectGet/objectPut`),
and the delivery router is mounted with `failsClosed: false` (`:105`, loopback Origin accepted): **the fixture never
reaches S3/KMS/STS, never exercises the 429 budget and never the fail-closed tier** — rows A/B stay SRC+MOCK, and the
fixture exercises the platform-path manifest gate (row C), delivery (D), transport/CSRF with a loopback origin (E) and
non-retention (F). Current drift (G3-6): today's `dist/public/index.html` `8fd43766…` equals `ui-status-task12.json` but
not `ui-status.json` (`7542cd11…`) nor `ui-status-task15.json` (`d7a955f7…`); `routers.ts`, `deliveryRouter.ts` and
`notesExportRoute.ts` on disk match the task12 record — a fresh build and restart precede any journey.

**MySQL fixture (G4; own read).** Bundled `.work/tools/mysql-8.4.11-winx64/bin/mysqld.exe`, `--no-defaults`, loopback
127.0.0.1:43316, datadir `fixture/db` (present, `auto.cnf`), database `probatepro_fictional_hybrid_fixture` (status: ready,
28 tables), refuses a busy port and resumes only with `--resume-owned-fixture` plus a matching private identity; the app
user has SELECT/INSERT/UPDATE/DELETE only. **No whole-database backup/restore helper exists**: only
`task06/manus-repair01/fixture-state.cjs` (settings backup/restore, row-count evidence) and
`task15/claude-pass01/native/shutdown-fixture.cjs` (identity-checked SHUTDOWN). Gate B therefore takes a read-only,
hashed snapshot of the declared fictional document metadata of `hybrid-fictional-estate-a` before J1 and reports every
row delta; **nothing is restored this pass** (Q11). The server writes `fixture/mysql-server.log` and `fixture/mysql.pid`
beside the datadir `fixture/db/` (`--skip-log-bin`; the InnoDB redo, undo, temp and doublewrite files change on every
run), which the Q4 allowlist names.

**Fault and capture arms (G5; own read).** Capture: `fixture/capture-next.json` `{label, estateId}`, consumed by rename to
`captures/<label>.arm.json` on the first matching 200 (`capture-deliveries.ts:18-46`); **no expiry**, so a leftover arm
would capture a later journey — checked absent at B0 and after each journey. Fault: `fixture/audit-fault-next.json`
(modes `reject-audit`, `zero-ack-audit`, `reject-activity`, `commit-ack-loss`, `leak-read` on one of seven estate tables;
valid 300 s; label must be new; consumed by rename into `audit-faults/`; `audit-faults.ts:48-71`), patched into the mysql2
pool only (no trigger, no application hook). Preview fault arm belongs to the task12 server only. State on 2026-10-27:
no `*next*.json` present; `captures/` holds only consumed Task 13 receipts. The request trace and provider counters are
in memory only (`/__fixture/evidence`, last 200) and are saved to a file before any restart.

**Browser harness (G6-B; own read).** `task13/claude-pass02/qa/browser-launch.cjs` starts the cached Playwright Chromium
(`%LOCALAPPDATA%/ms-playwright/chromium-1228/chrome-win64/chrome.exe`, present) headless with a fresh profile, a DevTools
port on 127.0.0.1 and a dead proxy that only 127.0.0.1 bypasses; `cdp.cjs` drives it (goto, click, wait, trace, downloads,
fetch-post-bearer, pause) recording header names and body hashes only. The Task 13 QA browser (pid 11236) is not running;
its stale `endpoint.json` sits in the task13 pass and is not reused. No WINWORD process exists; none is started.

**Journey → harness map (G6).** J1 ← Task 3/6 P1 UI delivery + `verify-p1-delivery.cjs` + `verify-ui-native.cjs`;
J2 ← Task 6 case B9 (P7 missing-field warning → Generate anyway 200) and Task 12 S4; J3 ← Task 6 cases B1(c)/B2/B3/B5/B6/B8/B10
(tamper, missing token, drift, expiry → 409) + the native ordering proof; J4 ← `task03/verify-retained.cjs` (307 → 200,
hash `48eab159…`, other account 404 with zero provider calls) plus the UI attachment view; J5 ← Task 15
`browser-check-pending.md` scenarios A–D (leak-read on `stored_objects`/`estate_notes`, retry) — the real-browser part has
never been performed; J6 ← `fixture-counts.cjs`, `audit-correlate.cjs`, `verify-ui-native.cjs`, `/__fixture/evidence`.

**Hazards recorded (G7).** Every UI launcher rewrites `runtime.private.json` (adds secrets if missing; never printed);
`inspect-fixture.cjs --delete-task15-rows` with the default `--since=0` deletes all-time rows for the two QA users (Gate B
passes an explicit `--since`); `word-render.cjs` drives Word (never called); the capture arm has no expiry; `results.json`
and `render-checks/<label>` overwrite on label reuse; `start-ui-task15.cjs` logs to `ui-task15.log` but reports `ui.log`.
Comment/code mismatches (G CM-1) are harness-only, noted, not fixed.

Known from own reads: `mysql-fixture.cjs` starts the bundled mysqld with `--no-defaults`, loopback only,
datadir `fixture/db`, port 43316, database `probatepro_fictional_hybrid_fixture`, refuses a busy port and any identity
mismatch, resumes only with `--resume-owned-fixture`, writes `status.json`; `start-ui.cjs` refuses `.env*`, requires
`status.json` ready, builds a loopback DSN from `runtime.private.json` (never read or printed by this task), refuses any
`AWS_*`, `STORAGE_S3_*` or `LEGAL_RECORD_STORAGE_APPROVED` setting, redacts secrets from `ui.log`; `ui-server.ts` refuses
any non-fixture DSN, re-proves `@@port`/`@@datadir`/`database()`, records the loaded-source hashes of 20 files including
`dist/public/index.html` in `ui-status.json` and `/__fixture/health`, installs the QA fault adapter (`audit-fault-next.json`,
allowed estate `hybrid-fictional-estate-a` only) and the delivery capture, serves the built bundle, offers the fixture
login (cookie or `?mode=bearer`, 4 h) and `/__fixture/evidence` (in-memory trace of ≤200 requests, provider counters,
generated rows retaining bytes, manifests, last 200 audits). The pinned browser harness is
`.work/hybrid-remediation/task13/claude-pass02/qa/cdp.cjs` (`claude-pass01/qa/` is the older copy and is not used; memory traps: set download behaviour inside the clicking step
with `allowAndName`; buffer `requestWillBeSentExtraInfo`; dismiss the cookie banner; include failure texts in waits;
save the evidence trace before stopping; `MSYS_NO_PATHCONV=1`).

## 8. Gate B protocol (only after a separate explicit go-ahead; no repairs)

- **B0 Identity and baseline.** Branch/HEAD/index as §2; recompute every hash in `source-before.json` (the Gate A census:
  the Task 17 census set, the Task 18 row files, the fixture and runner scripts, `baseline.json`, `render-baseline/hashes.json`,
  the full test tree) and stop on any difference; `git diff --cached` empty; stash count 1; `porcelain-b0.txt` saved;
  no `.env*` in the root or `chatbot/` (the runner refuses otherwise and would still consume a label); no pending fault or
  capture arm; nothing already listening on 43117/43316; the Task 17 question answered (§12 Q1). **Execution-safety
  reads (read-only, recorded in `b0-notes.md`):** `storage-platform.test.ts:120-170` and the provider/config functions
  its three vault-profile cases reach (no `S3Client` construction or credential resolution, else exclude and ask, Q9);
  the cases of `routers.storage-lifecycle.test.ts`, `notes.test.ts` and `storage-authorization.test.ts` that could reach
  the unmocked provider module; confirmation that `RUN_STORAGE_LIVE_UAT`, every `AWS_*` and `STORAGE_S3_*` name are
  absent from the runner's child environment (`run-gates.cjs:19-29`, own read) and that the live-UAT file is in no
  focus list.
- **B1 Execution-safety screen, then focused gates** (Nick's correction 5). Before any command: freeze the **actual**
  candidate membership of the root and chatbot runs (the `vitest.config.ts` include globs resolved to a file list, plus
  `vitest.setup.ts`, both configs and `chatbot/` config/setup) with hashes; statically screen every candidate and setup
  file for reachable external boundaries (`@aws-sdk`, `STSClient`, `fromNodeProviderChain`, non-loopback `fetch`/`http`
  targets, `child_process`, `net`/`dns` connects, `mysql2` `createConnection`/`createPool` with inherited URLs); for each
  flagged file inspect the caller and its actual mock; record the result in `b1-screen.md`. An unresolved external
  boundary **holds the affected command** (reported NOT RUN); the runner is never edited, no test is excluded, weakened
  or relabelled, and a partial run is never called the full gate. Recorded already: `storage-platform.test.ts:126-139`
  calls only `usingPlatformStorage()` on its dedicated-profile assertion (no client construction or credential
  resolution on that path — not a credential leak; Q9 stays a general rule for any boundary the screen cannot resolve);
  the runner's child environment is an explicit allowlist (`run-gates.cjs:19-29`) and `tests` mode excludes the live
  UAT (`:38`); neither establishes no-network execution by itself (execution-safety review, 2026-10-28), so a candidate
  without file:line evidence of its mocked boundary holds its command. Then the focused groups (§6), each with a fresh
  label; read `results.json`, counts and the freeze line of
  every log; a nonzero exit stops the group and is reported as a result, never retried into green.
- **B2 Full serial gates.** `& 'C:\Program Files\nodejs\node.exe' '.work\hybrid-remediation\run-gates.cjs' claude-task18-pass1 check tests chatbot-check chatbot-tests build render`
  (new pass label if it exists). Scrubbed fictional settings, serial no-cache tests, both typechecks, the build (writes
  `dist/`, a declared local build output; its `dist/public/index.html` hash is recorded for B4), the 26 frozen renders;
  `storage.live-uat.test.ts` stays excluded; the runner is not edited. Missing later results after a nonzero gate are
  "not run", never "passed". Results bound to the B0 hashes and re-hashed after.
- **B3 Standalone read-only probes** (new files under the pass directory only, labelled QA, importing nothing that
  executes the application; proposed in §12 Q3): P1 a static inventory of every AWS SDK client/credential constructor and
  KMS import across `server/`, `shared/`, `server/scripts/` (receipt: no constructor outside `storageProvider.ts`; no KMS
  client anywhere); P2 a static `storagePut`/`PutObjectCommand` caller census with classification (feeds F1); P3 a tier
  matrix: spawn one Node child whose environment is built from an explicit allowlist exactly as `run-gates.cjs:19-35`
  does (PATH, SystemRoot, TEMP, COMSPEC, PATHEXT, then only `NODE_ENV`, `VITEST`, a fictional
  `PROBATE_FIELD_ENCRYPTION_KEY` and the probe's fictional storage names; nothing inherited, nothing persisted) per combination of `NODE_ENV` (unset, empty, `production`, `staging`, `development`,
  `test`) × `VITEST` (unset, `true`) × profile (none; incomplete fictional; complete fictional with a `localhost` http
  endpoint; complete fictional `https://s3.ca-west-1.amazonaws.com` with a fictional account `000000000000` ARN; the
  same with an alias, a bare key id, a `ca-central-1` ARN, identical role ARNs, a retired static key name), importing
  `server/_core/env.ts` through `tsx` and recording whether the dev seeding at `env.ts:23-39` fired, what
  `legalRecordStorageConfigurationError()` returns (the message names variables, never values) and whether
  `validateLegalRecordStorageConfiguration()` throws. No network: the module reads only `process.env`; nothing is written.
  Each probe's script hash and command line are recorded; the receipt lists outcomes only.
- **B4 Fictional UI and native journeys** (§7 J1–J6) on the verified source: start the owned MySQL fixture
  (`--resume-owned-fixture`), then the **pinned pair** `fixture/start-ui-task15.cjs` → `fixture/ui-server-task15.ts`
  (Q7; log `fixture/ui-task15.log`; B0 reads that pair's guards by line, not the base variant's) and the **pinned
  harness** `task13/claude-pass02/qa/` copied unchanged into `task18/claude-pass01/qa/` (Q8; both hashed; any change
  needed is a new, differently named QA file, never an edit of the copy); `inspect-fixture.cjs` is used in read mode
  only (`--since=<journey start ms>`), **`--delete-task15-rows` is never passed** (L3-04); confirm `ui-status.json` source hashes equal the files on disk and the
  B2 bundle hash; sign in with the fixture login; before each journey save `/__fixture/evidence` and the native row counts
  (documents, document_versions, stored_objects, audit_log, activities) for the fixture estate; after each, save the
  deltas and correlate the attachment hash with the started/finished events and the provenance row; provider PUT and
  presign-PUT counters must stay at their pre-journey values; snapshot (read-only, hashed) the declared fictional document
  metadata of `hybrid-fictional-estate-a` before J1 and report every delta — no restoration this pass (Q11); the
  three-record identity check (Q6) passes before any UI evidence counts; stop only the processes this task started (by
  command line and PID). Browser:
  the Task 13 CDP harness reused after its guards and the loaded-source identity are verified; if no browser on this
  machine can open 127.0.0.1:43117 (the Task 15 situation), the journeys are reported as NOT EXERCISED, not substituted
  by HTTP evidence.
- **B5 Frozen outputs (corrected).** The B2 `render` gate (26 forms; `render-freeze.ts:30-35` excludes the whole
  `docProps/core.xml` and hashes XML/relationship members only, not binary media — useful, not an all-member proof) plus
  the copied `compare-docx.cjs` (`:28-69`: every member of every DOCX, including DOCX inside a ZIP and every non-DOCX
  ZIP member, byte-identical except the `dcterms:created`/`dcterms:modified` text of `docProps/core.xml` — the only two
  approved normalizations) run on **demonstrably identical fictional inputs**: pair J1's first delivery with a second
  POST of the same descriptor within its binding lifetime (same estate state, same answers; the estate is not edited
  between them), and the Bearer-path delivery of the same descriptor where J3 produces one. Every case's `pass` and the
  `diffs` list are read, never the exit code alone. A capture from a different fixture state (the Task 6 repair P1) is
  not a comparable baseline: a difference against it is reported, never normalized. No timestamp normalization is
  broadened; renderer/layout code is untouched. Word/pixels remain user-deferred-not-passed: no Office start, repair or
  request.
- **B6 Source preservation.** Re-hash the whole B0 set; the porcelain and filesystem delta allowlist is exactly Q4 (one
  list; the pre-run `status.json`/`ui-status*.json` and a file listing of `fixture/db/` with sizes are copied into the pass
  first; every allowed fixture file's before/after hash or size and the native row-count deltas are recorded). A
  `fixture/blobs/` delta is **not** pre-authorized: any new blob is reported as a finding (an unexpected provider write,
  L3-09); every other delta stops the task and is reported; existing application, tests, config and lockfiles hash-equal.
- **B7 Matrix completion.** Every row cell receives its actual command, result, count and evidence class; failed checks
  and deviations stay failed; "not exercised" and "requires deployment evidence" stay distinct from "known gap".
- **B8 Independent bounded review.** One read-only general-purpose reviewer (Read/Grep only, ≤40 calls, no Bash)
  reconciles the proof matrix with the final hashes, the commands run, the changed-file inventory and the known-gap
  register; findings by blocking/high/medium/informational; documentary mistakes fixed in Task 18 artifacts only.
- **B9 Handoff.** `final-status.md`, then `manifest.sha256` (every pass file except itself, `final-status.md` and the
  report), then the report `outputs/task18-security-safeguard-reverification-<date>.md` citing the receipt hash, the
  drafted queue entry (not appended), the deferred/not-run list and the disposition (verification-supported within scope,
  or STILL-BLOCKED/partial with reasons). **Stop.**

## 9. Journeys (rows D–F; minimum representative set; exact steps after tracer G)

| Id | Journey | Observes | Evidence |
|---|---|---|---|
| J1 | Successful generation and delivery (P1 lawyer notice: generate → POST `/api/download/form` → ZIP; and one plain DOCX form) | HTTP 200, attachment hash = `contentSha256` of the started event, exactly one provenance row, no new byte reference, provider PUT counters unchanged | UI + NATIVE |
| J2 | Incomplete input on the supported single-form path: the P7 missing-field warning (Task 6 case B9), Generate anyway enabled and used, then the 200 delivery; packages and bulk runs stay hard-gated and are not used for J2 | warn-only single-form path, delivery proceeds, blanks preserved, no fabricated fact | UI + NATIVE |
| J3 | Stale or tampered delivery: re-POST after a later generation (409 current-row), and a tampered `binding` field (409 before the rate unit; nothing written) | refusal page text, no audit row for the pre-render refusal, no bytes | UI (native re-POST, refusal page) + HTTP (`fetch-post-bearer` tamper) + NATIVE |
| J4 | Valid retained-file read (the fixture will PDF through `/manus-storage/*`: 307 → 200, `Cache-Control: private, no-store`); other-account 404 with zero provider calls | manifest gate on the platform path | UI (owner attachment view) + HTTP (`verify-retained.cjs` other-account 404) + NATIVE |
| J5 | Read-failure refusal and recovery (corrected): arm one `audit-fault-next.json` (`leak-read` on `stored_objects` for the estate export, then `estate_notes` for the notes PDF): the injector fails the next estate-bound SELECT (`audit-faults.ts:101-124`), so the export preparation answers the fixed preparation refusal through `routers.ts:2676-2694` (tRPC error, no descriptor, at most one report attempt) and the notes route answers 500 "Failed to generate PDF" through `notesExportRoute.ts:269-275`; the arm is consumed; the unarmed retry → 200. Recorded: the actual route status, the refusal sentence shown, the reporter outcome from the sanitized log (`acknowledged`/`saturated`/`rate_limited`/`timed_out`/`unconfirmed`, `exportFailureReporting.ts:96-128`, `:153-197`: at most one attempt, not an unconditional row) and the `failure_reports` delta by `--since`. **This journey does not exercise a refused delivery-start audit**: no existing driver can fail `*_delivery_started` (the audit arm is restricted to `document_generated`/`export_generated`, `audit-faults.ts:126-149`); that native case is NOT EXERCISED and rests on the mock tests cited in D10; the injector is never edited | SELECT-failure refusal, recovery, bounded reporting | UI + NATIVE |
| J6 | Native audit/provenance/no-new-byte correlation across J1–J5 | per-journey deltas; `generatedRowsRetainingBytes` 0; `historicalRowsWithStorageReferences` unchanged | NATIVE |

**Common frame for every journey** (harness per §7; all identity-checked, nothing deleted): (1) `fixture-counts.cjs
<label>` before; (2) save `/__fixture/evidence` before; (3) for a delivery journey, arm `capture-next.json`
`{label:"task18-j<n>-…", estateId:"hybrid-fictional-estate-a"}` immediately before the click and confirm it was consumed
(renamed into `captures/`) immediately after; (4) `cdp.cjs` steps with `downloads` set inside the clicking step,
`trace` for the POST, waits that include the failure texts; (5) the approved Task 18 reader (Q8/Q13) by estate, actor, journey window and attempt, with generation
events joined separately by `documentId` and generation time, a bounded wait (≤10 s, polled) for the asynchronous terminal
row, and `audit-correlate.cjs <out> j<n>=<sha256 of the captured or downloaded file>` only as a secondary hash lookup; (6) `/__fixture/evidence` after (trace, `providerCounts`, `generatedRowsRetainingBytes`,
`historicalRowsWithStorageReferences`, manifests, audits); (7) `fixture-counts.cjs` after; (8) confirm no arm is pending.
Exact steps: **J1** Forms → P1 → Lawyer → preview preflight → DOCX: POST `/api/download/form` 200 ZIP; `verify-p1-delivery.cjs
<label> task18` (word/* parts against the Task 3 P1; the seeded fixture estate is the same, so a part difference is
reported, not normalized); `verify-ui-native.cjs`-style match of the attachment hash to exactly one started/finished pair
and the current provenance row; a second plain DOCX form (P19 as in the Task 6 repair, 9,240 B) the same way.
**J2** a single form only — P7 with its missing-information warning (Task 6 case B9; a P3 draft is the alternate if P7
is not applicable to the fixture estate): observe the warning text, the enabled Generate anyway control, the 200 delivery
after acknowledgement, the blank left where the fact is missing, and that no estate fact changed (`fixture-counts`,
estate row unchanged). No package or bulk run is used (Rule 24 keeps them hard-gated). **J3(a)** keep J1's descriptor, generate P1 again, re-POST the old descriptor (native form via
`cdp.cjs`, and `fetch-post-bearer` for the Bearer tab) → the 409 page with the fixed sentence, no new audit row, no bytes,
no capture; **J3(b)** `fetch-post-bearer` with the `binding` field altered by one character → 409 before the rate unit
(no `document_delivery_*` row; `[download] form delivery binding refused: mac_mismatch` in the sanitized log). **J4**
as the owner, `GET /manus-storage/<will key>` → 307 → 200, 1,311 B, sha256 `48eab159…`, `Cache-Control: private,
no-store`; as `?actor=other` → 404 with zero provider calls; the UI attachment View once; `providerCounts` show
`presignGet`/`objectGet` increments and no PUT. **J5** record the baseline first (`/__fixture/evidence` `providerCounts`, the trace length and the `failure_reports` count
by `--since`; the fixture's counters and trace are global with no per-journey reset), then arm `audit-fault-next.json`
`{label, estateId, mode:"leak-read", table:"stored_objects", armedAt}` (the failing statement is the
`listExportableStoredObjects` SELECT inside the preparation try, `routers.ts:2676-2693`; if the receipt shows another
statement failed, the observed status and sentence are recorded as found); start the estate export in the UI → the
existing preparation-error sentence, no attachment, a zero `objectGet`/`presignGet` delta with no storage-read trace entry
for the failed request, at most one staff-report attempt whose actual outcome is read from the sanitized log and the
`failure_reports` delta by `inspect-fixture.cjs --since=<journey start ms>` (0 or 1 rows: `acknowledged`/`saturated`/
`rate_limited`/`timed_out`/`unconfirmed`; an uncertainty to record, not an acceptance criterion), no fault marker text in
the UI; the arm is consumed; retry → 200 ZIP saved by the browser; then the notes PDF export the same way with `estate_notes`
(Task 15 scenarios A and C; scenario B with `skipMatches:1` if time allows). **J6** the per-journey deltas are tabulated (the J1 tuple is: `documents.id` = `document_generated.detail.documentId` =
`document_delivery_started.detail.documentId`; `document_delivery_started.detail.contentSha256` =
`document_delivery_finished.detail.contentSha256` = sha256 of the captured file; `document_generated.detail.contentSha256`
is the bare-render SHA, reported beside them and never equated; the generation rows are written inside the replacement
transaction, the delivery rows by the route — started before any byte, finished asynchronously after the stream):
`documents`/`document_versions` counts and storage-reference counts, `audit_log` rows by event with `contentSha256`
matching the captured bytes, `activity` rows, `stored_objects` manifests, `providerCounts` (PUT/presign-PUT unchanged);
the declared pre-J1 snapshot of `hybrid-fictional-estate-a` is compared with the end state and every difference is
reported; nothing is restored this pass (Q11). Teardown: SIGINT the UI launcher, `shutdown-fixture.cjs`, confirm both
ports free, save the sanitized `ui-task15.log` slice into the pass.

## 10. Known gaps to preserve (register from tracer H: 60 calls, the whole queue 1–852 read and bound to `e7c6c07c…`, 36 files; every item is report-only)

Classes: KG known gap · UD user-deferred-not-passed · DEP requires deployment evidence (Task 19) · NX not exercised ·
RU repaired but unaccepted · OT open task (7/8/14/6) · PI preserved implemented safeguard · HIST citation or artifact
match only · **NO new observation made by Task 18, report-only (Nick classifies, Q10)** · **NR new regression** (a
behaviour contradicting an accepted receipt or the queue; none found at Gate A — the class exists for Gate B). Rows are
the tracer's mapping; REG-10 is reclassed KG (the result record lacks a Node version; mapping unverified) and REG-49 HIST
(panel L2-09).

| Id | Item (source) | Class | Rows |
|---|---|---|---|
| REG-01 | Word/pixels user-deferred (queue :404, :430, :822-824; task06 json:40; task15 fs:60; task12 fs:258) | UD | D, F |
| REG-02 | Task 14 STILL-BLOCKED: Word render hang only; Word parts byte-identical to Task 5 baselines (STILL-BLOCKED.md:1-47) | OT | D, E |
| REG-03 | Task 14 open-for-Nick: formStatus wording; Rule 18 UNRATIFIED; R2 lost-commit trace (queue :312-315) | OT | D, E |
| REG-04 | Task 6 not accepted (json:5-8, :35-39; queue :416, :333-334 snapshot admission) | OT | D |
| REG-05 | INT-1 suspected: row order could cause a false-stale 409; TiDB unproven (queue :383-385, :414; report :98-106) | KG | D |
| REG-06 | INT-2 repaired: exact form-route envelope 8,349/8,353 (`deliveryRouter.ts:20-25`, `:186`, `:220-223`; queue :406) | RU | D, E |
| REG-07 | SEC-2 repaired: composite artifact release identity (`formDeliveryArtifact.ts:12-62`; `routers.ts:4571`; `downloadRoute.ts:180`) | RU | D |
| REG-08 | `GENERATOR_RELEASE` default "1.0.0" in frozen `docgen.ts:6618`; set per deploy (queue :388-389) | DEP | D |
| REG-09 | Frozen `docgen.ts` template-merge and Relationship regexes (queue :390-391, :414) | KG | D |
| REG-10 | Node 24 residual: receipts identify regression (`sdd/review-ff-verdict.md:66-68`), runtime v24.13.1 (`red-original-regex.json:2-11`; `scanner-verification.json:58-69`), result (green gate `:39-57`, **no Node version recorded**); current `formDeliveryBinding.ts` = receipt's final hash `8403a470…`; not closed, not re-executed | RU | D |
| REG-11 | Task 6 residuals: admission log form code (success line unverified), "Kevin Kisser" fixture name, appendix A1 (queue :341-342, :392-397) | OT | D |
| REG-12 | Tasks 7/8 not reopened (queue :53-54, :432); D13/D14 not implemented | OT | D |
| REG-13 | Task 15 real-browser gap (task15 fs:56-59; queue :426, :430) | NX | E |
| REG-14 | Task 15 bounds and dependencies: awaited failed-audit can hang; unbounded `download_form` writes; mysql2 no query timeout (fs:61-69) | KG | D, F |
| REG-15 | Dev/Preview delivery-body redaction OPEN before real client data (queue :450, :512; task09 fs:9-12, :135-138) | KG | E |
| REG-16 | Runtime `message` listener validates neither `event.origin` nor `event.source` (queue :454, :513) | KG | E |
| REG-17 | Chatbot rotation moves cookie tabs onto the fetch path (queue :453, :514) | KG | E |
| REG-18 | No developer console trail for client delivery failures (queue :451, :602) | KG | E |
| REG-19 | Safari/iOS/Android WebView unverified; handoff is not a saved file (task09 fs:156-159; queue :442, :456) | NX | E |
| REG-20 | Task 13 preview-path microtask gap INFO (pass02 fs:393-395; queue :515) | KG | E |
| REG-21 | Task 13 S2 different-user token swap reads as rotation (pass02 fs:396-399; queue :516; `fallbackSession.ts:39-40`) | KG | E |
| REG-22 | Task 13 kept behaviours: DATE_NOT_PRINTED list, c48, S12f not run, retry/toast/recovery-panel semantics (queue :517-524) | KG | E |
| REG-23 | P10 deponent carry-over left unchanged by Nick (queue :505) | KG | D |
| REG-24 | Task 10 L1: unsettled audit writes hold request and buffer; audit_log append-only (task10 fs:449-452; queue :585-588) | KG | F |
| REG-25 | Task 10 L2: started row without terminal row = outcome not recorded (fs:453-454; queue :589-590) | KG | D, F |
| REG-26 | Task 10 L3: Node response error not natively triggerable on 24.13.1 (fs:455-457; queue :591-592) | NX | F |
| REG-27 | Task 10 F1/O1: non-Latin-1 or CR/LF deceased name → 500 with `Content-Type: application/pdf`; quote injects disposition parameters (fs:458-463; queue :593-596) | KG | E, F |
| REG-28 | Task 10 sibling-route, denial-timing and IP-source differences (fs:464-473) | KG | C, E |
| REG-29 | Unexplained vitest worker exit in `formDeliveryBinding.races.routes.test.ts` during `claude-task10-pass1` (fs:469-471; queue :598-599) | KG | D |
| REG-30 | Task 11 P5: no cancellation; a never-answering DB call keeps its lease (task11 fs:612-615; queue :666, :690) | KG | F |
| REG-31 | Notes first-come caps: 3 process / 2 account leases, one per request (`notesExportLimits.ts:40-46`, `:123-125`, `:156-158`, `:168-183`; `notesExportRoute.ts:195`, `:197`; erratum queue :840-852) | KG | F |
| REG-32 | Auth holds no notes lease; process-local caps per replica; workstation render times (fs:623-629; queue :668-670, :693-696) | KG | F |
| REG-33 | Audit retention unresolved (fs:658, :708; queue :673, :702) | KG | F |
| REG-34 | NEL trailing unit LOW; prototype-named tags INFO (Rule 29 region); residual false refusals; name-based retention gate (fs:634-656; queue :697-699) | KG | F |
| REG-35 | Uploads and package-export success shown only by R16 mocks (fs:657; queue :700) | NX | F |
| REG-36 | Task 12 P8 partial same-tab session guard (`previewTransport.ts:156-163`; `fallbackSession.ts:34-46`; `EstateDetail.tsx:7426-7436`; queue :820-821) | KG | E |
| REG-37 | Task 12 outstanding tests and measurements: understated-header+oversize, mid-body rotation, Unicode/letterhead, heap, mobile, pixels (queue :822-824) | NX | E |
| REG-38 | Provisional 4 MiB preview ceiling; largest probe 8,256 B, no headroom claim (`previewTransport.ts:12-20`; queue :765, :804) | KG | E |
| REG-39 | Browser abort is not server cancellation; actual-last-observer cancellation is React Query semantics (task12 fs:243-247; queue :778-779, :826) | KG | E |
| REG-40 | Task 12 disclosed/pre-existing behaviours; duplicate `FetchLike` and two error classes left alone (queue :784-786, :825-827) | KG | E |
| REG-41 | Deployed IAM/STS trust, KMS and bucket policies; mocks are not policy proof (queue :16, :63; acceptances) | DEP | A, B, C |
| REG-42 | TiDB engine semantics unverified (locks, pessimistic mode, INT-1 order) (queue :126, :148, :383-385, :693-694) | DEP | C, D |
| REG-43 | Production pool, migration state, schema compatibility; 64 KiB-page fixture and the four TEXT+CHECK intake columns (queue :16, :102; task11 fs:614) | DEP | C, D, F |
| REG-44 | Disposition lookup is a table scan on the fixture (queue :136) | KG | C |
| REG-45 | SQL locks do not cover slow provider completion; admitted reads may finish after a destructive commit (queue :130, :148; task03 acc:9, :27) | KG | C |
| REG-46 | No exactly-once or idempotent-retry guarantee (task05 acc:14; queue :333-334) | KG | D |
| REG-47 | AWAITING-NICK / UNRATIFIED RULES.md items (Rules 7, 18, 19, 20; :1562-1565) — never resolved here | UD | D (Rule 18 wording) |
| REG-48 | Task 17 implemented, not accepted; row 61 drafted only (closeout.md:3-7, :34, :80-86, :141, :156) | RU | all (map) |
| REG-49 | Task 11 erratum: every cited lease line matches current source | PI | F |
| REG-50 | Task 9 L4 sink passes header arrays and error text; reviewer substitution; D6 erratum 8,351 B (task09 fs:64-67, :75-77, :133-135) | KG | E |
| REG-51 | Bootstrap pair uses the SDK default env names; a future client without explicit credentials would use it through the default chain (A5; `storageProvider.ts:67-70`, `:88-91`) | NO | A |
| REG-52 | Dev-tier seed `STORAGE_S3_REGION=us-east-1` completes the profile when `AWS_*` are set, skipping the non-local checks; untested (A8; `_core/env.ts:23-39`, `:191`; `env.validation.test.ts:547-569`) | NO | A, B |
| REG-53 | The fail-closed localhost-endpoint refusal (`_core/env.ts:232-239`) has no test; scripts untested; platform read branches unguarded (B2; `storageProvider.ts:591`, `:613`) | NO | B |
| REG-54 | No approved-key or account pin: every KMS check compares to the configured value only (B5; `_core/env.ts:132`; `storageProvider.ts:361-367`, `:420-426`, `:550-553`) | NO | B |
| REG-55 | GET/HEAD/presign/reconciliation read no SSE evidence (B8; `storageProvider.ts:581-686`; `storageRegistry.ts:1354-1357`) | NO | B |
| REG-56 | Lifecycle worker writes the storage key into `stored_objects.lastError` for a blocked legacy deletion (C10; `storageRegistry.ts:1670`, `:1697`, `:1504-1512`) | NO | C |
| REG-57 | Stale guard comment: the per-IP limiter counts and the credentialed-origin guard can refuse before the delivery guard (E1b; `_core/deliveryRouter.ts:5-6`; `_core/index.ts:122-128`, `:182-190`) | NO | E |
| REG-58 | The preview modal's DOCX download fetch has no abort on close; a handoff can occur after close with no message (E11b; `EstateDetail.tsx:7439-7440`, `:7468-7514`) | NO | E |
| REG-59 | Native-cookie streaming is unbounded while the fallback fetch is bounded (E7/E8; `attachmentDelivery.ts:33`, `:32-41`; queue :442, :456) | KG | E |

**Severity and proposed disposition of the Task 18 observations (author's assessment from the cited lines; Nick
decides; none is accepted or repaired here):** REG-51 low — latent only (no default-chain client exists); proposed:
record in `references/file-storage.md` under a later documentation task, no code change now. REG-52 medium — dev tier
only, requires an operator to set the six `AWS_*` names in development; consequence: STS and S3 calls to `us-east-1`
from the bootstrap key with a loopback endpoint, outside the Canada profile; proposed: a separate small task (an
`AWS_*`-set guard in the dev seed, plus a test) — not in Task 18. REG-53 medium — a production-critical refusal
(`env.ts:232-239`) without a test; proposed: a separate test-only task; B3-P3 gives a probe-level receipt meanwhile.
REG-54 medium — configuration-trust limit by design: every KMS check binds to the configured value; the approved-key
identity is Task 19 deployment evidence (confirm the configured ARN is the vault account's approved key); no code
change proposed. REG-55 low-to-medium — read-side absence of encryption evidence; AWS-side `kms:Decrypt` scoping is the
enforcing control (Task 19); proposed: Nick decides between "accepted design limit" and a separate task adding a
HEAD-time check. REG-56 low — a random opaque vault key written into `stored_objects.lastError` (no PII; a locator in
a column meant for error text); proposed: separate small task (redact storage keys in `errorMessage`) or accept.
REG-57 info — stale comment (`deliveryRouter.ts:5-6`); proposed: documentation/comment task. REG-58 low — a handoff
can occur after the preview closes with no message (own session only, no exposure); proposed: UX task or accept.
REG-59 — already known (queue :442, :456).

Decision records and preservation contracts the matrix must honour: DR-01 four approved output behaviours (queue :9);
DR-02 do not reopen 7/8 (queue :432); DR-03 no Agent Archive account (queue :810); DR-04 global constraints and Rule 29
(queue :13-20; RULES.md :1966-1980); DR-05 missing information warn-only (queue :225; task04 acc:49; task05 acc:16);
DR-06 Task 18 is verification and report only (preferences :14-15, :21-23). PC-03/16/04/05 (accepted Tasks 3/16/4/5) and
PC-15/09/13/10/11/12 (user-accepted) restate what each acceptance preserves and its evidence limits (local InnoDB only,
mocked SDK, headless Chromium on one workstation, HTTP is not browser evidence); they are carried verbatim into
`known-gaps.md`. Tracer citation notes: CM-01 the preferences file predates the closeout (the final-fragment review did
run; five fragments on four lines); CM-02 the Task 11 historical wording stays, corrected by the append-only erratum;
CM-03 the Node-version attribution was corrected in the closeout bytes; CN-01 the Task 16 `db.ts` hash is historical.
Tracer gaps disclosed: Task 14 `implementation.md` LOWs not read; Task 13 §6, Task 10 §1-11, Task 11 §1-14 bodies not read.

Verbatim pointers kept in the handoff's residual list: Word/pixels user-deferred-not-passed (queue `:404, :430`; Task 6 repair
status); Task 14 STILL-BLOCKED Word render (`task14/claude-pass01/STILL-BLOCKED.md`); Task 15 real-browser gap (`:426`;
`task15/claude-pass01/browser-check-pending.md`); Task 6 INT-1 suspected (`:383-385, :414`), INT-2 repaired (`:406`),
SEC-2 (`:388-389`), frozen `docgen.ts` regexes (`:390-391, :414`), Node 24 residual as the receipts record it (regression
`task06/claude-pass01/sdd/review-ff-verdict.md:66-68`; runtime v24.13.1 `manus-repair01/hostile-template-investigation.md:9`,
`scanner-verification.json:58-60` red reproduction; result `scanner-implementation.md:32, 38`, `scanner-verification.json:39-57`
with no Node version for the green gate) — not closed from inference, nothing installed; Tasks 7/8 not reopened (`:432`),
exhibit/container and export binding unbound; Task 13 residuals (`:515-516`); rotation/runtime `message` listener OPEN
(`:454, :513`); Dev/Preview body redaction OPEN (`:450, :512`); chatbot rotation (`:453, :514`); Task 10 L2/L3/F1
(`:589-596`); Task 11 NEL/O1 (`:697-699`), first-come caps with the erratum (`:691-692`, `:840-852`), retention (`:702`);
Task 12 P8 cases, outstanding tests and measurements, 4 MiB provisional cap, heap, actual-last-observer cancellation,
partial same-tab guard (`:820-827`); deployed roles/trust/KMS/bucket/pool/migration/`GENERATOR_RELEASE` (Task 19, `:63`).
A broad requirement already known to fail (comprehensive export input binding; universal session revocation) is never
marked PASS because Task 18 made no edit.

## 11. Stop conditions and what is never done

Stop and report (no repair, no rebaseline): any hash in the B0 set differs; branch/HEAD/index differ; a `.env*` appears;
a fixture identity check fails; a pending arm exists before a journey; a gate exits nonzero (later gates are "not run");
a source file changes during Gate B (a concurrent edit is reported, never hidden behind a refreshed baseline); a browser
submission's outcome is uncertain (read the network/native/capture evidence first; never re-submit to find out); Word is
running or needed (user-deferred, no start/kill/request); a probe would need an install, a dependency, a network or a
credential; a chosen gate or render label already exists under `gates/` or `render-checks/` (use the next `passN`,
never reuse); an authority conflict (code versus RULES.md or a capture) is found — flag it, never fix it. Never modify
another local worktree, Manus project, staging project or custom domain. `inspect-fixture.cjs` runs in read mode only.
Never: edit application/test/schema/config/renderer/legal/RULES/.cursorrules/captures/receipts; weaken or
accept a snapshot; run `storage.live-uat.test.ts`, `test:storage:live` or any runbook command against a provider; read or
print `.env*`, `runtime*.private.json`, tokens, passwords, keys, real ARNs; configure persistent `AWS_*`/`STORAGE_S3_*`/
`LEGAL_RECORD_STORAGE_APPROVED`; migrate, seed, reset, wipe tables; stage, commit, stash, push, checkpoint, publish, deploy.

## 12. Approval questions for Nick (Gate B does not start on answers alone)

| # | Question | Default if silent |
|---|---|---|
| Q1 | Task 17 is implemented, not accepted (closeout A1). Proceed with Gate B while it stays pending, accept Task 17 first, or hold Task 18? | **Hold Gate B** (prompt §2 requires the explicit decision). |
| Q2 | Approve the six journeys J1–J6 as the minimum representative set, run in the real React UI through the Task 13 CDP harness; HTTP-only evidence is reported as not exercised. | As listed. |
| Q3 | Authorize the three standalone read-only QA probes (B3 P1–P3) under `task18/claude-pass01/qa/`, each importing no application code except `server/_core/env.ts` in a scrubbed child process. | Run P1–P2 (pure static); P3 only with explicit yes. |
| Q4 | **Single output allowlist (Nick's correction 7; §14 and B6 point here):** (1) the saved plan `docs/superpowers/plans/<save-date>-task18-security-safeguard-reverification.md`; (2) `.work/hybrid-remediation/task18/claude-pass01/**` including `scripts/` (the save and probe scripts) and `qa/` (the copied helpers, `task-files.txt`, any approved new reader); (3) `outputs/task18-security-safeguard-reverification-<date>.md`; (4) `.work/hybrid-remediation/gates/claude-task18-*` and `render-checks/claude-task18-*`; (5) `dist/` (the build gate; gitignored); (6) the identity-guarded fixture database and its server files: `fixture/db/**` (the datadir the launcher re-proves by `@@datadir`/`@@port`/`database()`: InnoDB system, undo, redo, temp and doublewrite files plus the `probatepro_fictional_hybrid_fixture` tablespaces; recorded as a before/after file listing with sizes and the native row-count deltas), `fixture/mysql-server.log`, `fixture/mysql.pid`, `fixture/status.json`, `fixture/ui-task15.log`, `fixture/ui-status-task15.json`; (7) the exact transient arms written by the task immediately before a step and consumed by rename — `fixture/capture-next.json` → `fixture/captures/<label>.arm.json` plus the capture file, `fixture/audit-fault-next.json` → `fixture/audit-faults/<label>.json`; (8) the launcher's rewrite of `fixture/runtime.private.json` (name recorded, values never read). Every allowed fixture file's before/after sha256 (or size, for the live datadir) is recorded in the pass. **Not allowed, each a finding that stops the step:** any `fixture/blobs/*` write, any change to `fixture/schema*.sql`, `fixture/db-16k-evidence/**` or any other fixture file, any seeding or migration (`status.json` must keep `projectMigrationsApplied: false` and 28 tables), and any delta outside this list. | Accept this list as the only allowlist. |
| Q5 | Browser: reuse the pinned Task 13 harness (`task13/claude-pass02/qa/cdp.cjs` and `browser-launch.cjs`, copied unchanged) with its guards, or the chrome-devtools MCP? | Task 13 pass02 harness. |
| Q6 | **Hard bundle identity (replaces the r2 assumption):** three records must agree before any UI evidence counts — (a) the B2 final build manifest (`build-manifest.cjs` copy over `dist/public/**` with the declared sources from the Task 18 `task-files.txt`; every `declaredSources`, `dependencies` and `fixture` hash must be non-null — the script writes `null` for a missing file (`:26`), and a null stops the step), (b) the fixture's served-filesystem manifest taken immediately before and after the journeys (`dist/public/**` re-hashed, equal to (a)), and (c) the browser-loaded assets captured by the harness `assets` command in a fresh-profile browser with the cache disabled: it hashes only the same-origin `Document`, `Script` and `Stylesheet` responses of one reload of the current URL (`cdp.cjs:462-491`; fonts, images, JSON and chunks loaded on later navigation are outside it; a `sha256: null` entry is a failed body read and counts as a mismatch), so it is run at each journey's URL (estate page, Forms tab, preview) and every entry must equal the served file of the same path in (a). The record claims coverage only of the assets it hashed. Any mismatch **stops that evidence step** and is reported; nothing is edited to make them agree; no record is designated authoritative by assumption. | As stated; not a question of preference. |
| Q7 | Fixture UI variant for B4: `start-ui-task15.cjs` → `ui-server-task15.ts` (hashes `formDeliveryArtifact.ts` and `exportFailureReporting.ts`; no client files) plus a full served-bundle manifest from `task13/claude-pass02/qa/build-manifest.cjs`; or `ui-server-task12.ts` (client files and preview faults, not the two server modules). Neither is edited. | task15 variant + full manifest. |
| Q9 | If the B1 screen finds that `storage-platform.test.ts` (fictional vault profile at the real AWS host, no SDK mock; its current `:126-139` assertion calls only the boolean `usingPlatformStorage()`, so this hold is conservative, not a demonstrated exposure) could construct an S3 client or resolve credentials: it is excluded from every focused list, the finding is reported with file:line, and the serial run is **held after `check`**: `tests`, `chatbot-check`, `chatbot-tests`, `build` and `render` are reported NOT RUN until Nick decides. Historical green results of that gate do not show whether a credential resolution or network attempt occurred. | Exclude from focus; hold after `check`; report NOT RUN; Nick decides. |
| Q12 | Answered: the raw tracked-diff review ledger (§4 item 6) was closed read-only on 2026-10-28 before this save (`diff-review-ledger.md`). | Closed. |
| Q13 | Approve the new read-only reader `qa/delivery-correlate-task18.cjs` (Q8 semantics, written only at Gate B as a new file) and the Task 18 `task-files.txt` (generated at B0 from the saved `source-before.json` application list) as pass-directory QA files under Q3? | Yes. |
| Q10 | Classification of the eight Task 18 observations (REG-51..58, severities and proposed dispositions in §10): each is recorded as "NO" (new observation, report-only). Nick classifies each as accepted design limit, known gap to track, or a separate task; Task 18 repairs none. Also: the r2 "not established" list was closed before the save (§4 item 6); the five remaining bounded reads (§5 intro) are B0 reads unless Nick wants them first. | Record as NO; B0 reads. |
| Q11 | **No restoration this pass** (Nick's correction 6 and, on 2026-10-28, "no restoration this pass"). The journeys leave the declared fictional end state, which is reported with every delta against the read-only pre-J1 snapshot. Any later cleanup is a separate, separately approved QA mutation with its own QA ledger, never a rollback of the application's transactional effects, and would have to meet this contract exactly: snapshot before J1 (`SELECT *` of `documents` and `document_versions` `WHERE BINARY estateId = ?` — neither table has a `userId` column (`drizzle/schema.ts:677-695`, `:1044-1059`); the owner is proven once from `estates.createdByUserId` = the fixture owner — JSON `wx`, hashed); cleanup scope = exactly the snapshotted ids (all columns restored verbatim) and the rows the journeys created, deleted only when their ids are absent from the snapshot and their `estateId` matches, inside one transaction with the estate row locked; compare-before guards: the pre-cleanup rows are re-read and hashed, each restored row must keep an empty `storageKey`/`storageUrl` or the snapshot's own legacy key, lifecycle/`stored_objects` references are never touched, `audit_log`/`activity`/`stored_objects`/`failure_reports` are never deleted, rewritten or backfilled; all evidence is saved before the cleanup; before/after hashes recorded; no claim of whole-fixture equality. | No restoration; report the end state; a cleanup needs its own later approval. |
| Q8 | Copy the Task 13 harness scripts (`browser-launch.cjs`, `cdp.cjs`, `fixture-counts.cjs`, `audit-correlate.cjs`, `build-manifest.cjs`, `compare-docx.cjs`) unchanged, hash-recorded, into `task18/claude-pass01/qa/` (new files only; the Task 13 pass is untouched). **Declared inputs and limits (Nick's correction 3):** `build-manifest.cjs:21` reads `task-files.txt` from the pass root — the Task 18 pass gets its own `task-files.txt` generated from the approved §14 application source list (never the Task 13 list); its `dependencies` and `fixture` lists are fixed in the script (`:22-25`, task15 fixture files) and are recorded as such. `audit-correlate.cjs:27-34` selects only `document_delivery_*`/`export_delivery_*` rows by a content hash across the whole table and groups by attempt: it omits `notes_delivery_*`, cannot bind to this estate, actor, journey window or the current provenance row, and can match historical identical deliveries — it is used only as a secondary hash lookup. **New reader, if approved under Q3/Q13:** `qa/delivery-correlate-task18.cjs` (read-only SQL, identity-guarded, written at Gate B as a new file) reports, per journey window (estate, actor, start/end): (i) **delivery events grouped by `attemptId`** — `document_/export_/notes_delivery_started|finished|aborted|failed` with their `contentSha256`, `bytes`, `documentId`, `retryOf`, `estateRevision`, compared with the captured or downloaded file's SHA (`downloadRoute.ts:383-405`); (ii) **generation events joined separately** — `document_generated` by `documentId` and generation time (`createdAt` within the window; `contentSha256` = raw SHA of the bare render, `routers.ts:4478-4479`, `:4588-4591`), `export_generated` by `exportType` and time (it carries no `documentId`; a digest only when an archive was built) — and the current `documents` row by id. The finished/aborted rows are written asynchronously after the stream (`sendAttachment` callback; the notes route's `attachmentSettle`), so the reader waits a **bounded** time (≤10 s, polled every 500 ms) for a terminal row; a row not observed by the deadline is recorded as "terminal row not observed within 10 s", never as finished. Four digests stay distinct and are never forced equal: the bare-render SHA (`document_generated`), the canonical render digest (the binding's `renderSha256`, in no audit row), the delivered-artifact SHA (`*_delivery_*`) and the provenance identity (`documents.id`). Native evidence is captured before anything else touches the fixture. | Yes, with the declared inputs and the new reader. |

## 13. Design-panel dispositions (Gate A, Workflow `wf_804e9c4b-7f5`, three read-only Plan lenses, Read/Grep only)

Verdicts: coverage `sound-with-changes` (15), overclaim `sound-with-changes` (12), safety: see the addendum below.
Folded = changed in this text; Save = applied mechanically at the Gate A save; Carried = recorded for Gate B/handoff.

| Id | Sev | Finding (short) | Disposition |
|---|---|---|---|
| L2-01 | blocking | Q9 misused HIST and defaulted to running a gate that may resolve credentials | Folded → Q9 rewritten: hold the full gate, Nick decides |
| L2-02 | high | B8 declared the prompt requirement "met" by reinterpretation | Folded → B8 "satisfied for PUT and bucket proof only; NOT implemented on reads" |
| L1-01 | high | Matrix rows carry no source hash | Save → per-row file hashes from `source-before.json` in `proof-matrix.md`; rule in §5 intro |
| L1-02 | high | Fixture restore unspecified | Folded → Q11 names tables, selection, mechanism; append-only tables never restored |
| L2-03 | medium | Test cells stamped MOCK before any run | Folded → §5 reading rule (SRC of the test tree until B1/B2) |
| L2-04 | medium | §2 says the dev seed "can never" select the vault | Folded → read §2 with A8: true only while `AWS_*` are unset (Save: reword §2 sentence) |
| L2-05 | medium | No HTTP evidence class; J3/J4 mislabelled | Folded → §3 HTTP row; J3/J4 relabelled |
| L2-06 / L1-05 | medium | New observations not in the register; no NR class | Folded → classes NO/NR; REG-51..58; Q10 |
| L1-03 | medium | Unread items scattered | Folded → consolidated "not established" list in §5 intro; Q10 |
| L1-04 | medium | No map of the prompt's eleven negative classes | Carried → `proof-matrix.md` gains the eleven-row map (class → row item → test → label) at the save |
| L1-06 | medium | No pre-task diff saved; raw diff not read | Folded → §5 intro statement; Save → `diff-before.patch` (tracked census files, `git diff HEAD --`) at the save and B0 |
| L1-07 | low | Read inventory of prompt §3 documents | Save → `gate-a-notes.md` table (document → reader → whole/partial) |
| L1-08 | low | Focused commands not written out | Folded (form) → §6; Save → full lines in `test-inventory.md` |
| L1-09 | low | Mock lines for the five ARN test files | Folded → §6 |
| L1-10 / L2-11 | low | Stale "pending/running" text; superseded table | Folded → status line, §5 intro, §6 heading; Save → table moved to notes |
| L1-11 | low | Six return items not mandated as report sections | Carried → B9 report sections = the prompt's six items; B8 schema gains "needed to resolve" |
| L1-12 | low | Three prompt lines without a home | Folded → REG-59; Carried → §11 adds "flag an authority conflict; never modify another worktree, Manus project, staging project or domain" at the save |
| L1-13 | low | J2/J4 HIST values as expectations without fallback | Carried → B4 rule: absent fixture state ⇒ NOT EXERCISED + dependency reported; HIST values are expectations, differences reported |
| L1-14 | info | Dev-tier question not in §12 | Folded → Q10 |
| L1-15 | info | Manifest excludes two artifacts | Carried → their hashes are printed in the handoff (Task 17 pattern) |
| L2-07 | low | "accurate maps" overstates Task 17's checker | Save → "path/range-consistent maps" (semantic accuracy not established) |
| L2-08 | low | C1 header overstates encoded variants | Save → header reworded: encoded/NFC variants untested at the proxy |
| L2-09 | low | REG-49/REG-10 classes | Folded → legend note |
| L2-10 | low | §1 reads as if 14/6 completed | Save → parenthetical added |
| L2-12 | info | Four wording overreaches (F6, B5, E14, A3) | Save → reworded as proposed |

**Safety lens (10 findings, `sound-with-changes`).** L3-01 blocking (Q9 default would have run a gate that may resolve
credentials) → Folded: Q9 holds the serial run after `check`, later gates reported NOT RUN. L3-02 high (porcelain cannot
see edits to untracked modules or `.work/`) → Folded: mechanical preservation set in §14/B0/B6. L3-03 (launcher pair
inconsistent) → Folded: task15 pair pinned in B4, guards read by line at B0. L3-04 (`--delete-task15-rows` not
forbidden) → Folded: §11 and B4. L3-05 (P3 child environment) → Folded: explicit allowlist. L3-06 (two `cdp.cjs`
paths) → Folded: `task13/claude-pass02/qa/` pinned; copies never edited. L3-07 (Task 17 save script could be executed)
→ Folded: new `gate-a-save-task18.cjs`; the Task 17 script is read only. L3-08 (superseded table) → Folded: marked not
to be run; Save: moved out of the plan. L3-09 (label reuse; `blobs/` pre-authorized) → Folded: §11 rule; `blobs/` delta
is a finding; status files copied first. L3-10 (graph provenance) → Folded: §2.

**Nick's review of r2 (2026-10-28), folded:** (1) investigation status corrected to not complete; diff-review ledger
defined (§4.6, Q12); `createAuditEntry` contract read and D10 reworded (resolved insert, not `affectedRows`); enqueue
sites read (A4 holds). (2) Q6 replaced by the three-manifest hard identity check; mismatch stops the step. (3) Q8
declares the helpers' inputs (`task-files.txt`), the correlator's limits, the new estate/actor/time/attempt reader, and
keeps generation SHA and delivered SHA as separate relations (Q13). (4) J5 corrected to SELECT-failure refusal and
recovery with actual statuses and bounded reporter outcomes; the native started-ACK refusal is NOT EXERCISED; the
injector is never edited. (5) B1 gains the candidate-membership freeze and external-boundary screen; unresolved
boundaries hold the command; `storage-platform.test.ts:126-139` recorded as no client construction. (6) Q11: no restore
by default; the exact guarded contract is specified for a later approval; evidence saved first; never a whole-fixture
rollback claim. (7) One allowlist (Q4; §14 and B6 defer to it); scripts live in the pass; `blobs/` writes are findings;
B5 uses `compare-docx.cjs` on identical inputs with per-case `pass` reads and the two timestamp-text normalizations
only; pixels deferred. New observations carry severities and proposed dispositions (§10); Task 17 stays pending.

**Nick's Gate A save authorization (2026-10-28, "Finish Gate A and save the plan only, subject to these corrections"),
folded:** (1) Q4 names the identity-guarded fixture database (`fixture/db/**`), the server log and PID files and the
exact transient arms, with their deltas recorded; no broad fixture allowance, seeding, migration or blob write. (2) Q6
requires complete, non-null manifest hashes and browser-loaded assets equal to the served files, and states the
unchanged collector's actual coverage (one reload's Document/Script/Stylesheet responses) without overstating it.
(3) Q8 correlates delivery events by attempt and generation events separately by `documentId` and generation time,
bounds the wait for the asynchronous terminal rows (missing evidence is never a claimed finish) and keeps the four
digests distinct. (4) The contradictory restore instructions in §7, B4 and J6 are removed: no restoration this pass;
the nonexistent `documents`/`document_versions.userId` predicate is removed from the Q11 cleanup contract. (5) J5
records actual bounded staff-report outcomes; J2 is the supported incomplete single-form case (P7, Task 6 case B9);
the pass02 harness is named consistently (Q5, §7). (6) The raw-diff ledger and the critical reads are finished (§4
item 6). (7) One concise authoritative plan is saved with every open finding and deferral retained; no new tracer or
panel cycle was run. (8) The two independent review reports under `.work/task18-plan-review-2026-10-28/` were read
whole: B1 now states that the scrubbed runner and the live-UAT exclusion do not establish no-network execution; Q9 is
labelled a conservative hold; J5 takes a per-journey baseline and requires a zero provider-read delta; J6 names the J1
comparison tuple; the save script lives inside the pass. Gate B, Task 17 acceptance and Task 18 acceptance remain
unauthorized.

Panel limits: no lens verified any file:line against application source (by brief); the lenses read the plan whole
(1,372 lines at the time), the prompt and the preferences; "Save" items are applied verbatim by the save script to the
saved plan copy and recorded in `panel-report.json` with the lens outputs.

## 14. What the Gate A save does (exactly; the only writes on exiting plan mode)

1. `docs/superpowers/plans/2026-10-28-task18-security-safeguard-reverification.md` ← this text, LF (new, untracked).
2. `.work/hybrid-remediation/task18/claude-pass01/`: written by a **new** script inside the pass,
   `.work/hybrid-remediation/task18/claude-pass01/scripts/gate-a-save-task18.cjs` (Q4 item 2; nothing outside the pass)
   (the Task 17 save script is read for its enumeration only and is never executed: its outputs would overwrite the
   Task 17 receipts; L3-07). `source-before.json` (sha256, size, EOL census in Node and git state of the **mechanical
   preservation set** (L3-02): (a) every path cited in §5 (`proof-matrix.md`); (b) every porcelain ` M` and `??` path
   outside `.work/`, excluding `.env*` and `*.private.*` (an edited untracked module stays `??`, so this hash census,
   not the porcelain, is the concurrent-edit detector); (c) the Task 17 census list and its 23 cited extras exactly as
   `task17/claude-pass01/scripts/gate-a-save.cjs` enumerates them; the Task 18 additions `server/_core/trpc.ts`, `server/fieldEncryption.ts`, `server/notesExportLimits.ts`,
   `server/exportFailureReporting.ts`, `server/scripts/validateStorageProvider.ts`, `server/storage.live-uat.test.ts`,
   `drizzle/0173_storage_namespaces.sql`, `vitest.config.ts` or `vite.config.ts`, `pnpm-lock.yaml`, `.gitignore`;
   the harness set `.work/hybrid-remediation/{run-gates.cjs, render-freeze.ts, render-fixtures.json, baseline.json,
   render-baseline/hashes.json, verify-p1-delivery.cjs, verification-runtime.md}`, `fixture/{mysql-fixture.cjs,
   start-ui.cjs, start-ui-task15.cjs, start-ui-task12.cjs, start-ui-task06-repair01.cjs, ui-server.ts, ui-server-task15.ts,
   ui-server-task12.ts, ui-server-task06-repair01.ts, capture-deliveries.ts, audit-faults.ts, preview-faults-task12.ts,
   schema.fixture.sql, schema-compatibility.json}`, `task13/claude-pass02/qa/{browser-launch.cjs, cdp.cjs,
   fixture-counts.cjs, audit-correlate.cjs, build-manifest.cjs, compare-docx.cjs}`, `task15/claude-pass01/native/{inspect-fixture.cjs,
   shutdown-fixture.cjs, real-app-http.cjs}`, `task06/manus-repair01/{verify-ui-native.cjs, fixture-state.cjs}`,
   `task03/verify-retained.cjs`; the governing and predecessor documents (the prompt, the two preference records, the
   review report and its six review-working files, the queue,
   `task17/claude-pass01/{final-status.md, closeout.md, manifest.sha256, manifest-closeout.sha256}`, the four Task 17
   documents, the acceptance and final-status receipts named in §10); and the full `*.test.ts`/`*.test.tsx` tree under
   `server/` and `client/` with its digest — never `.env*`, never `runtime*.private.json`, never `status*.json` values
   beyond their names); `porcelain-before.txt`; `stash-before.txt`; `diff-review-ledger.md` (§4 item 6, written before
   the save) with `diff-before.patch` (`git diff HEAD` of every modified tracked file, full context) and
   `diff-numstat.txt`; `graph-notes.json` (stats and the two queries, as recorded at Gate A);
   `tracer-reports/*.json` (the nine returns verbatim, with their run ids); `proof-matrix.md` (§5 verbatim);
   `test-inventory.md` (§6); `fixture-inventory.md` (§7 and §9); `known-gaps.md` (§10 plus the PC/DR text verbatim);
   `panel-report.json` (§13 source); `gate-a-notes.md` (identity, preconditions found, instruction inventory, tooling
   incident, the read inventory of the governing documents, the superseded r1 focus grouping, what was not run: no suite,
   service, browser, database, Office, provider or runner).
3. `gate-a-hashes.sha256` (every pass file except itself); report the plan path and the hashes; **stop** for Nick's
   separate Gate B decision. No other file is touched.

## 15. Acceptance (decision record, appended 2026-10-28 13:16 PDT; the sections above are the saved Gate A plan, sha256 2eb720d57fcfb7348455c090549bd6736d46b172ae7867113ad26e29138e9828 before this addendum)

Gate B was executed on 2026-10-28 under Nick's four answers (scope B1–B9; B0 drift "record, do not stop"; probes
P1/P2/P3 and the reader; Task 17 re-checked and found accepted). Results, limitations and the independent review are
in `.work/hybrid-remediation/task18/claude-pass01/final-status.md`, `proof-matrix-completion.md` (with the appended
B8 corrections), `gate-b-notes.md`, `b8-review.json` and `manifest.sha256`, and in the handoff
`outputs/task18-security-safeguard-reverification-2026-10-28.md` (sha256 `dce2703929cd194954ca5f22c75a4f2521f7525ad3c45f612a19721a779da930`).
Disposition: verification-supported within its stated scope (B8 `sound-with-changes`, all changes documentary and
applied). **Nick accepted Task 18 by his one-word reply "accept" to the Gate B handoff, recorded 2026-10-28 13:16 PDT.** The
acceptance is remediation tracking only: not a SHIP verdict (Task 20), not policy clearance (Task 19), not hybrid
Step 4, not a deployment, security or compliance approval; every limitation, not-exercised item and deployment-only
item in the final status stands; the new report-only observations REG-51…REG-61 remain for Nick's classification;
REG-48 is superseded by the Task 17 acceptance. No code, test, schema, configuration, renderer, legal or policy file
was changed by Task 18; nothing staged, committed, pushed, checkpointed, published or deployed. The fixture end state
is left as recorded (no restoration). Queue row 62 is ticked and the disposition appended there at this acceptance.
