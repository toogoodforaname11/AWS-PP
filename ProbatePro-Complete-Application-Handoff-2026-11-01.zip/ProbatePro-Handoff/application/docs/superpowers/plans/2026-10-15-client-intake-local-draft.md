# Client Intake Local Draft Recovery Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Preserve an in-progress client intake locally so a refresh can offer a safe, explicit draft recovery path without submitting information automatically.

**Architecture:** Reuse the established `useLocalDraft` browser-storage hook with a portal-scope-specific, non-PII key derived from the estate and client identity. `ClientIntakeForm` alone owns the dirty flag, recovery prompt, and successful-submission cleanup; no submission, review, authorization, database, or court-form contract changes are required.

**Tech Stack:** React 19, TypeScript, Vitest, Testing Library, localStorage.

**Spec:** User request in the active task context: “Implement an auto-save feature for the client intake form to prevent data loss if the page is refreshed.”

## Global Constraints

- Keep the change limited to unsubmitted client-intake recovery; do not alter portal authorization, server persistence, lawyer review, estate records, inventory, forms, documents, or legal language.
- Save only after an explicit client edit; configuration hydration and server-provided revision prefill must not create drafts.
- Never submit a draft automatically; recovery and discard must be explicit, keyboard-operable controls.
- Use an opaque, non-PII browser-storage key scoped to the estate and portal contact.
- Clear the local draft only after successful portal submission or when the client explicitly discards it.
- Verify with fictional browser data only; do not access real portal sessions or client records.

## Review Focus

- Refresh after an ordinary field edit restores the exact unsubmitted value only after the client chooses **Restore saved draft**.
- A newly mounted, untouched form writes no draft despite custom-question configuration hydration.
- A draft is not offered under a different estate/client scope.
- A successful submission removes the recovery copy so a later refresh presents the submitted receipt, not an obsolete editable draft.
- Restore/discard controls have clear accessible names, focus-visible native buttons, and concise live feedback.

---

### Task 1: Client intake draft lifecycle

**Files:**

- Modify: `client/src/components/ClientIntakeForm.tsx`
- Test: `client/src/components/ClientIntakeForm.test.tsx`

**Interfaces:**

- Consumes: `useLocalDraft<ClientIntakeFormData>({ key, data, isDirty })` from `client/src/hooks/useLocalDraft.ts`.
- Produces: `ClientIntakeForm` browser-local draft recovery for an unsubmitted portal intake.

- [x] **Step 1: Write failing lifecycle regressions**

Add tests that edit a fictional first name, flush the local lifecycle event, remount the same portal scope, verify an explicit recovery notice, restore the value, and verify a separate portal scope is not offered the draft. Add a success-path assertion that invoking the real mutation `onSuccess` clears the draft.

- [x] **Step 2: Run the focused tests to verify they fail**

Run: `pnpm vitest run client/src/components/ClientIntakeForm.test.tsx -t 'client intake draft'`

Expected: FAIL because the form does not create, restore, scope, or clear a client draft.

- [x] **Step 3: Implement portal-scoped local draft handling in `ClientIntakeForm`**

Accept an opaque `draftScope` prop, derive a stable non-PII key, mark only user-originated form operations dirty, wire the existing hook, render a concise restore/discard notice, and clear the copy after submission success. Keep revision prefill and custom-question hydration non-dirty.

- [x] **Step 4: Run focused tests to verify they pass**

Run: `pnpm vitest run client/src/components/ClientIntakeForm.test.tsx -t 'client intake draft' && pnpm check`

Expected: all selected tests and TypeScript pass.

### Task 2: Portal scope wiring and browser evidence

**Files:**

- Modify: `client/src/pages/Portal.tsx`
- Modify: `client/src/pages/Portal.test.tsx`
- Test: `/tmp/client-intake-draft-browser-check.py` (temporary fictional fixture)

**Interfaces:**

- Consumes: authenticated `portal.me` estate ID, contact name, and email.
- Produces: an opaque `draftScope` to `ClientIntakeForm`, without rendering estate details.

- [x] **Step 1: Write a focused portal wiring regression**

Verify the portal passes a scope built from portal-session context to the client intake while retaining the existing client-intake-only visible boundary.

- [x] **Step 2: Run it to verify it fails**

Run: `pnpm vitest run client/src/pages/Portal.test.tsx -t 'client intake draft scope'`

Expected: FAIL because the form does not receive portal scope context.

- [x] **Step 3: Wire the portal scope**

Pass only the authenticated portal context needed for a non-PII local key; do not display it or alter portal queries.

- [x] **Step 4: Verify browser recovery with fictional data**

Use a mocked portal page to type a fictional answer, trigger a refresh lifecycle event, reload, choose **Restore saved draft**, and verify the answer and native-button keyboard operation. Check a mobile viewport for overflow.

### Task 3: Release verification and documentation

**Files:**

- Create: `docs/audits/client-intake-local-draft-recovery.md`
- Modify: `todo.md`

- [x] **Step 1: Run full verification**

Run focused Portal and form suites, `pnpm check`, `pnpm test -- --maxWorkers=1`, `pnpm build`, `git diff --check`, and local/preview HTTP health checks.

- [x] **Step 2: Inspect scope and document evidence**

Review the diff for data-contract or unrelated portal changes; record the root cause, browser evidence, test counts, and known unrelated warnings in the audit.

- [x] **Step 3: Create the project checkpoint**

Save the validated isolated repair as a WebDev checkpoint before reporting completion.

## Self-Review

- **Spec coverage:** Task 1 implements save, restore, discard, and successful-send cleanup. Task 2 supplies client-appropriate scope and validates the original refresh scenario. Task 3 supplies release evidence.
- **Step scan:** Each task has one test/fail/implement/pass sequence before wider validation.
- **Type consistency:** `draftScope: string` is consumed only by `ClientIntakeForm`; its derived key remains internal.
- **Review focus:** Each listed condition is covered by Task 1 tests or Task 2 fictional browser validation.
- **Proportion:** The plan specifies a narrow client-side change and intentionally avoids server/schema work.
