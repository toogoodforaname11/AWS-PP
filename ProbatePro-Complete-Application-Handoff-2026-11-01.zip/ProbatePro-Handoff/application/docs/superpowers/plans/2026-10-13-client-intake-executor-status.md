# Client-reported executor status repair

## Problem

The Executor/Client Portal collects people named as executors but has no executor-status input. Consequently, a lawyer can apply the reported contact while the contact’s executor status remains blank. The application must not infer that an executor is applying.

## Scope

1. Add an optional, constrained `executorStatus` property to the client-intake person contract, defaulting to blank for legacy payloads.
2. Show an executor-only portal control with plain-language client-report choices. Keep the default as “Not known / leave for legal team”; do not expose citation-only deemed-renounced status.
3. Surface a submitted nonblank status as its own lawyer-review field and allow it to be selected and applied to the corresponding executor contact.
4. Preserve the raw stored status for application while showing a readable label in review.
5. Cover payload parsing, portal submission, review availability, and mapper output.

## Safeguards

- The portal does not default a person to applying, renounced, reserved, or any other legal status.
- Every reported status remains subject to a lawyer’s explicit selection in the estate-side review tab.
- No court-form wording, form selection, executor-status resolver, or existing lawyer contact-status controls will be changed.
- Family and other-person records retain no executor-status control.

## Validation

Run focused shared-contract, mapping, and client portal form tests; then TypeScript, the serial test suite, production build, whitespace check, health checks, scope review, an audit note, tracker update, and checkpoint.
