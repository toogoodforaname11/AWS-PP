# Client Intake Undo Feedback and PDF Export Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Give lawyers clear undo confirmation and an on-demand PDF record of a selected client intake submission.

**Architecture:** Keep both features within the existing authenticated review surface. Enhance the current Sonner success callback without changing the undo procedure. Add a pure client-side PDF mapper/generator that receives an immutable submission payload and uses the already-installed `jspdf` package; the review component calls it directly, then reports the download through the same toast system.

**Tech Stack:** React 19, TypeScript, Sonner 2, jsPDF 4, Vitest, Testing Library.

**Spec:** `docs/superpowers/specs/2026-10-12-client-intake-feedback-and-pdf-export.md`

## Global Constraints

- Keep the undo and review server contracts unchanged.
- Do not add a dependency, database field, server storage object, router procedure, or tRPC call.
- Export the immutable submitted payload only; omit reviewer-only and estate-current data.
- Preserve accessibility, small-screen layout, existing portal review controls, legal/court-form behavior, and formatting rules.

## Review Focus

- A stale selection must not export a different submission after list refresh; bind export to the active submission only.
- Blank payload fields must not produce empty sections or invented values.
- A custom prompt without an answer must not appear as a completed response.
- Punctuation/long names must yield a safe `.pdf` filename without an email or token.
- Undo success must announce completion without removing the existing cache invalidation or error path.

---

### Task 1: PDF export utility

**Files:**
- Create: `client/src/lib/clientIntakePdf.ts`
- Create: `client/src/lib/clientIntakePdf.test.ts`

**Interfaces:**
- Consumes: `ClientIntakePayload`, submitter display name, submission timestamp.
- Produces: `buildClientIntakePdfSections(payload)` and `exportCompletedClientIntakePdf(input): string`.

- [ ] **Step 1: Write failing PDF-model and filename/download tests**

Assert submitted facts and answered custom questions form readable non-empty sections; mocked jsPDF receives a safe `.pdf` filename.

- [ ] **Step 2: Run the focused test to verify it fails**

Run: `pnpm exec vitest run client/src/lib/clientIntakePdf.test.ts --maxWorkers=1`

Expected: FAIL because the helper does not exist.

- [ ] **Step 3: Implement the pure mapper and jsPDF exporter**

Use A4 pages, text-only payload values, simple heading/section hierarchy, wrapped content, and page continuation. Sanitize the filename from the display name only.

- [ ] **Step 4: Run the focused test to verify it passes**

Run: `pnpm exec vitest run client/src/lib/clientIntakePdf.test.ts --maxWorkers=1`

Expected: PASS.

### Task 2: Review action and undo feedback

**Files:**
- Modify: `client/src/components/ClientIntakeReview.tsx`
- Modify: `client/src/components/ClientIntakeReview.test.tsx`

**Interfaces:**
- Consumes: `exportCompletedClientIntakePdf(input)` from Task 1.
- Produces: an accessible `Download client intake PDF` action and richer undo success toast.

- [ ] **Step 1: Write failing component regressions**

Assert successful undo emits a titled/described success toast and the selected submission export action calls the helper exactly once with its immutable payload.

- [ ] **Step 2: Run the focused test to verify it fails**

Run: `pnpm exec vitest run client/src/components/ClientIntakeReview.test.tsx --maxWorkers=1`

Expected: FAIL because no export action and no enriched undo toast exist.

- [ ] **Step 3: Add the feedback and export controls**

Place the export action in the active lawyer review header; disable it only when no active submission exists. Keep it a native button with an explicit accessible name. Use a Sonner success toast after undo with a concise title, description, existing smooth host animation, and bounded duration.

- [ ] **Step 4: Run focused tests and type checking**

Run: `pnpm exec vitest run client/src/components/ClientIntakeReview.test.tsx client/src/lib/clientIntakePdf.test.ts --maxWorkers=1 && pnpm check`

Expected: PASS and zero TypeScript errors.

### Task 3: Release validation and record

**Files:**
- Create: `docs/audits/client-intake-feedback-and-pdf-export.md`
- Modify: `todo.md`

- [ ] **Step 1: Test the feature with isolated fictional submission data**

Use the browser to trigger PDF download and undo success feedback without an authenticated estate session; confirm button state, visible toast, and downloaded filename.

- [ ] **Step 2: Run release checks**

Run: `pnpm test -- --maxWorkers=1 && pnpm build && git diff --check`

Expected: passing full suite, successful build, and no whitespace errors.

- [ ] **Step 3: Write audit and tracker entry**

Record scope, payload-only boundary, actual verification output, and exclusions. Then create a WebDev checkpoint.

## Self-Review

- **Spec coverage:** Task 1 covers payload-only PDF export and filename boundaries; Task 2 covers the review button and undo feedback; Task 3 covers functional and release validation.
- **Type consistency:** the same `ClientIntakePayload` crosses from the active submission to the pure export helper; no persistence contract is introduced.
- **Review focus:** stale selection is contained by calling export only from the active submission; blank values/custom prompts/filename sanitation are utility tests; undo success preserves existing invalidations in the component regression.
- **Proportion:** three independent, testable tasks; no backend or schema work.

**Execution decision:** The user explicitly requested implementation, so this plan proceeds natively without a separate approval pause.
