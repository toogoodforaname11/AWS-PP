# Task 17 handoff preferences — 2026-10-27

## Selected work

Nick requested the next task’s prompt and the remaining task count. The next selected prompt is `outputs/claude-remaining-tasks/11-task-17-accurate-guarantee-documentation.md`. Preparing this prompt does not implement Task 17 or authorize any other prompt. The forward sequence is 17 → 18 → 19 → 20; Task 19 requires separate policy evidence/authorization and remains blocked under the existing isolation rules.

The current authoritative queue has 20 entries: 12 checked and 8 unchecked. Four unchecked entries are forward work (17–20); four are earlier retained open entries (14, 6, 7, 8). Nick moved on from 7/8; do not reopen them or silently change their statuses. Task 12 is recorded as accepted by Nick with known limitations, not approved for SHIP, deployment or production security. This record changes no checkbox or acceptance.

## Preferences and approval boundaries

1. Work in the existing local `security/hybrid-vault-review` tree at retained HEAD `db0d7e9161bc3899b75858fab58bce54e3d5247a`; preserve earlier uncommitted work.
2. Execute only the expressly selected task. Task 17’s Gate A is bounded investigation/planning. Gate B documentation edits require explicit Nick approval; decision answers alone are not a go-ahead. Stop after the handoff and wait for acceptance/next-task instruction.
3. Documentation only: propose edits to non-authoritative technical storage/delivery documents. No application, test, UI, schema, configuration or dependency changes. Preserve authoritative rules, legal references/captures and historical evidence.
4. Absolute document freeze: no court wording, citations, formatting, layouts, renderer arguments/output, legal logic or form-selection changes. Preserve the four previously approved output behaviors and only the exceptions actually recorded in RULES.md. Missing information remains warn-only and Generate anyway stays enabled.
5. No production/client data, AWS/RDS/S3/STS/KMS/vault access, credentials, environment values, migrations, seeds, live UAT, external accounts or infrastructure changes. Quoted deployment/destruction commands are documentary material, not execution authorization.
6. No stage, commit, reset, stash, push, merge, checkpoint, publish, deploy or other-project/worktree operation. A repository Markdown record is not a Git commit.
7. Trace each documentation guarantee to current source and properly scoped evidence. Local fixtures/mocks, historical gates, measured samples, estimates and deployed policy proof are different. Do not turn an accepted deferral into a passed test or compliance claim.
8. Carry forward Task 12’s partial session protection, missing Unicode/letterhead measurements, unmeasured heap, mobile/WebView and Word/pixel gaps; preserve all earlier task deferrals and AWAITING-NICK items. Do not tidy deferred code or silently close Tasks 6/7/8/14.
9. Save a source-preserving documentation impact/claim-evidence matrix and a docs-only handoff. Draft progress updates if needed; do not append/check Task 17 or change other task statuses without explicit authorization. No overall SHIP claim or hybrid Step 4.

## Evidence for this prompt-only update

The prompt-preparation baseline and count receipt are under `.work/task17-prompt-update-2026-10-27/`. Only the selected Task 17 prompt and this handoff record are intended deliverable changes. Application code, test files, RULES.md, source configuration, queue and predecessor evidence must remain unchanged. This file records scope and preferences; it grants no new implementation or deployment authority.
