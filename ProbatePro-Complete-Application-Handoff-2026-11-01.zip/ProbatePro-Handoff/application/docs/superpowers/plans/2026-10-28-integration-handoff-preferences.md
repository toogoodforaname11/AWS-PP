# ProbatePro integration handoff preferences

_Prepared 2026-10-28 at Nick's request. This is a portable preference record, not execution, integration completion, a new repository or AWS authorization._

## Requested workflow

1. Finish Task 20's actual final review first. Its current Gate A plan is not a final execution report.
2. Identify the separate Manus staging/development destination and approve one concise integration plan before transfer. Never target the live app by default.
3. Transfer the complete reviewed application state by sanitized files; Git is not required as the transfer mechanism. Account for all 20 task records without pretending each is a code patch or completed task.
4. Fix concrete local integration/application defects end to end in the approved destination. Preserve the original review worktree, repository, queue and historical evidence.
5. Verify the final imported application, including connected-feature, fresh automated, actual fictional UI/native and protected-output evidence with limitations recorded honestly.
6. Create and populate the confirmed new private GitHub repository after the integration/repairs are verified. Preserve existing source/production and Manus-managed histories; no force-push or public deployment. Clarify canonical app connection versus backup.
7. Then stop and await Nick's explicit AWS go-ahead. Do not initiate login, console inspection, API/CLI calls or use an already logged-in account beforehand.

## Binding format, logic and isolation preferences

- No court-document wording, format, citations, structure, rendering, legal or form-selection changes. Preserve existing approved frozen files byte-for-byte after their import. A new frozen change needs separate approval.
- Preserve affirmed default, lawyer-signing model, capitalized defined terms, spaced citations and no fabricated sworn facts.
- Preserve the four existing approved behaviors named in the integration prompt; they do not authorize further changes.
- Missing information remains warn-only. Generate anyway is not disabled for incomplete fields; ownership/auth/tamper/persistence/resource integrity remains enforced.
- Preserve the two distinct STS providers, runtime/purge separation, sole `providerDeleteExact` purge consumer, Canada West KMS/full-ARN/equality checks and production fail-closed behavior.
- Preserve tenancy/manifests, required coherent audit/provenance, bounded safe reporting, existing cookie/Bearer delivery, truthful UI, notes audit/resources, preview lifecycle and generated-byte non-retention.
- No client records, production data, source environment files, credentials, browser profiles, database dumps, private uploads or blanket `.work/` copies enter the destination or Git.
- No AWS/vault access or real secrets before the separate AWS phase. No migrations/schema changes/RDS provisioning/bucket recreation/purge/production connections under the integration prompt.
- The managed staging database's blank-state restriction remains unless Nick separately approves schema/fixture setup. Native/UI tests use identity-verified disposable fictional fixtures.
- Word/native pixels remain user-deferred-not-passed. Do not restart Office or request the same manual startup check. Automated renders and package comparisons have distinct scopes.
- Do not silently clear AWAITING-NICK decisions, limited closures or REG observations. Record real blockers, untested paths and evidence gaps separately.
- Never claim Canadian-only processing, compliance, production readiness or SHIP from code import, mocks, passing local gates or Canadian storage alone.
- Keep package-manager/lockfile and source bytes/line endings; no broad upgrade, restructuring or renderer workaround.
- Keep all decisions/rules discoverable in the new destination repository: track `PROJECT_PREFERENCES.md` or an equivalent index, reference unchanged `RULES.md`/`.cursorrules`, and retain a safe integration/task ledger.
- No automatic publication or custom-domain attachment. Inspect auto-publish before a checkpoint-triggering push and require it off for this non-publication phase.

## Full execution prompt

The reusable prompt is `outputs/Manus-ProbatePro-Integration-Handoff-Prompt.md`. Writing these two files does not run that prompt, import an app, create a repository, accept Task 20 or authorize AWS.
