# Task 13 — Truthful delivery feedback, same-delivery coordination and safe recovery (plan r2; STOP for approval)

> Plan mode allows writing only this file. **Step 0 after approval** copies it byte-for-byte to
> `docs/superpowers/plans/2026-10-23-task13-truthful-delivery-feedback.md` (SHA-256 recorded) before any other write.
> Task 13 only: no other task prompt was read, Tasks 7/8 are not reopened, Task 13 is not marked done, no next task,
> no Word/Office, no transition, no production/AWS, no commit/stage/stash/push. **Nothing is implemented.**

## r2 revision record (answers Nick's 2026-10-23 review of r1)

| Nick's point | r2 answer |
|---|---|
| Keep native requested/info copy, fetch-only same-delivery coordination, separate generation/delivery timing, ZIP-aware feedback, one delivery-error owner | Kept unchanged: D1, D2, D4, D5, D8 |
| 1. Preserve regeneration context; correct D6 | D6 is corrected: r1's "the form's own Generate keeps every choice" was false (facts below). New **D9** adds a memory-only review/regeneration path with the proposed client-state scope listed explicitly |
| 2. Guard stale feedback (toast ids are not ownership) | New **D7**: each attempt's feedback is owned by a mounted owner, a slot (delivery/attempt) and a session, checked at dispatch |
| 3. Failure-safe cleanup | New **D10**: an exactly-once attempt lifecycle with isolated cleanup steps |
| 4. Test the final browser bundle | Steps 5–8: build and restart first; manifest-check served assets before any browser run; recheck after any fix or gate rebuild |
| Preserve freeze, warn-and-proceed, limits, deferrals; keep decisions in the repo plan | Unchanged; recorded under Retained deferrals; step 0 copies this plan into the repo |

**r1 facts that were wrong or missing (from the code, read-only):**
- `FormDetailsDialog.tsx:966-968` resets the affidavit ordinal to "" every time the dialog opens.
- `:910-925` resets the P8 deponent to the first candidate unless `initialDeponentId` is passed. The generic P8
  Generate (`EstateDetail.tsx:9407`) passes none.
- The P46 and P34 open handlers clear the lifted signature date (`:9632`, `:8989`).
- The consent drafts are cleared right after generation (`:9742`, `:9801`).
- Per-run answers from the optional-form popup and the gap-dialog inline fill live only in that run's continuation.
- The 409 for an unreadable stored file carries a re-upload sentence (`downloadRoute.ts:411-412, :447`).
  Regeneration alone cannot resolve it.

## Context

**Why.** Task 9 (accepted by Nick for remediation tracking, 2026-10-23 19:06 PDT, not a SHIP) deferred one bug here:
an auto-download and its own "Download X" button share no busy state. On the fetch path a retry during a slow response
starts a second full fetch: duplicate file, about 2× memory for large ZIPs. Feedback is also untruthful or unowned:
- "— downloading..." after a native submission whose result JavaScript never sees;
- no in-flight signal on the fetch path;
- "DOCX downloaded" for a ZIP;
- a dead link still offered after a 409;
- a silent invalid descriptor;
- late toasts that can land on another view, estate or session.

**Workspace (verified read-only).**
- Path and identity: `C:\Users\nick\probate pro\probatepro-hybrid-review`, `security/hybrid-vault-review`,
  HEAD `db0d7e9161bc3899b75858fab58bce54e3d5247a`.
- Index: 0 staged; 138 status lines (Task 9's recorded end state).
- `attachmentDelivery.ts` still has Task 9's final hash `eb2ca76d…`.
- Six idle peer sessions are attached to this worktree, so **any unexpected change before or during edits is a STOP**.

**Status (no reopening).**
- Queue item 9 is `[x]` with its 19:06 disposition, matching `final-status.md`: no closure discrepancy.
- Stale pointers recorded, not edited:
  - queue line 30 names `utils.ts`;
  - the queue's Task 13 line says "await observed HTTP success". That is impossible for native submissions; prompt
    item 7 governs.
- Task 15 is done by decision, with its browser gap outstanding. Task 6/14 items are not closed.

**Governance read.**
- There is no `AGENTS.md` anywhere in the repo (a fact).
- `.cursorrules`.
- RULES.md:
  - Rule 29 is the freeze; it has no "three exceptions".
  - Addendum 24.8: never silent-succeed; rejected handoffs stay visible and retryable.
  - Rules 26, 27 and 28.
- The queue's global constraints, and the four approved existing P2/P9/P8/package behaviors (preserved, not
  extended).
- Task 9 receipts were read as historical evidence only: `final-status.md`, `review/dispositions.md`,
  `review/reviewer-reports.md`, gate label `claude-task9-pass1`.

## Repository preferences and binding boundaries (from the Task 13 prompt; kept here for future models)

1. **One prompt at a time.**
   - Read and execute only Task 13's prompt.
   - Return a plan and wait for approval. After authorized implementation, hand back evidence and wait again.
   - Do not read other task prompts to anticipate later work.
2. **Workspace and Git.**
   - Only this worktree, branch and HEAD. Verify identity, index and non-secret status first.
   - Preserve the intentionally dirty tree and prior changes.
   - No reset-to-HEAD, stage, commit, stash, reset, push, merge, branch/worktree switch, checkpoint, publish, deploy
     or domain/project change.
3. **No document or legal changes.**
   - No court-document wording, format, citations, headings, paragraph/section/field order, tables, spacing,
     margins, typography, page breaks, or signature/jurat/checkbox geometry.
   - No DOCX/PDF/HTML-preview output, legal logic or form-selection changes.
   - `server/docgen.ts`, all renderers/drawing/preview builders, official captures, `shared/types.ts`, the document
     schema and migrations stay untouched.
   - In a mixed module, only delivery feedback/state plumbing may change. Render arguments and byte-building calls
     stay identical.
4. **RULES.md.**
   - Read the actual `RULES.md`, especially Rule 29. Invent no "three Rule 29 exceptions".
   - Preserve the four approved EXISTING P2/P9/P8/package-exhibit behaviors; they authorize no new output changes.
   - Preserve the affirmed default, the lawyer-signing model, capitalized defined terms, spaced citations and no
     fabricated sworn facts.
   - Resolve no AWAITING-NICK deferral.
5. **Missing information never becomes a new hard generation block.**
   - Keep warnings, blanks/drafts and enabled Generate anyway.
   - Busy state may stop duplicate work only while the same action is in flight; it is never a
     missing-data/applicability gate.
   - Authentication, tenancy, stale/tampered bindings, unconfirmed persistence and resource safety remain separate
     gates.
6. **No production, credentials or external writes.**
   - No production database/accounts/estates/uploads/generated or retained documents.
   - No AWS/S3/STS/KMS/vault credentials, live policies or connectivity. No `.env` values, secret searches or
     credential printing.
   - Never configure `AWS_*`, `STORAGE_S3_*` or `LEGAL_RECORD_STORAGE_APPROVED`.
   - No migrations, production seeds, dependency/toolchain changes, new OAuth or external-service writes.
7. **UI copy.**
   - Existing transport feedback may change; exact labels/messages are in this plan.
   - No legal guidance, letter-body templates, form preview markup or court wording. No unrelated UI redesign.
8. **Verification limits.**
   - No Office/Word automation, browser/tool installs or Office setting changes. Deferred pixels are never claimed as
     passed.
   - Fictional local verification only, with identity-guarded fixture/process ownership. No unidentified service or
     user session is touched.

## Root cause (bounded trace)

The review graph does not index the untracked Task 9 module (`callers_of` = "not indexed", which is not evidence of
zero callers), so the trace is a grep over `client/src`. It found 10 call sites:

| Helper | Call sites |
|---|---|
| `deliverAndAnnounce` | EstateDetail `:8132` (single form), `:8224` (package), `:8233` (letters), `:8242` (all-P8), `:10107` (P46 card fallback); `Home.tsx:241` (export) |
| `deliverAttachment` | `:9964` (P8 retry), `:9978` (generic retry), `:11880` (notes) |
| `fetchDeliveryAttachment` | `:7438` (preview) |

- **RC1 — busy state is keyed by the clicked element.** Only a busy *control* is suppressed (`attachmentDelivery.ts:83, 128`),
  and the auto-download passes none (`:147`).
- **RC2 — copy claims more than is known.**
  - `submitted` and `handed-off` share "— downloading..." (`:148`).
  - The fetch path is silent while in flight.
  - `invalid` is silent.
  - The preview says "DOCX downloaded" for any file (`EstateDetail.tsx:7440`).
- **RC3 — recovery offers a dead link** after 400/409/413 (`:9964, :9978`). The only regeneration path ("Review &
  retry", `:9983-9986`, or the row's own Generate) **loses choices** (facts above).
- **RC4 — feedback has no owner.** A toast or `onOutcome` from an attempt fires after the panel was dismissed or
  replaced, after navigation/unmount or another estate, or after a session change. Distinct toast ids do not prevent
  that.
- **RC5 — cleanup is not failure-safe.** Release runs only in one `.then` (`:135-139`). A throwing toast inside an
  auto-download's `onSuccess` would surface as a false "X was not generated" through TanStack's `onError`.
- **RC6 — the test-only P46 fallback claims a download.** Its gap dialog uses action "download" (`:10412`), so it says
  "Download started!" after generation alone. Production P46 goes through the details dialog to `generateMutation`
  with action "generate", because `:9622` always passes `onOpenP46Details`.

**Traced and unchanged:**
- `handlePgProceed`/`pgSucceeded` (only consumer: PreGenerateDialog `:2084-2125`).
  - For "generate" it says "Document generated!", which is true.
  - The preview "download" waits for the handoff via the rethrow.
- `preflight-busy`.
- The notes transport.
- Every mutation input, and every preflight/gap/override/deponent/applicability decision.

**Server facts (unchanged).**
- Bulk/export descriptors are `{type, estateId, signatoryType?, signatureDate?}`, re-rendered when posted
  (`routers.ts:1529-1534`).
- Single-form descriptors carry `documentId` plus a per-issue binding (`:1537-1543`).
- Refusals: `deliveryRouter.ts:30-54`. A native refusal is a server "Download not available" page (`:77-93`).
- `@tanstack/query-core` 5.90.2 awaits `onSuccess` and routes a throw to `onError` (`mutation.js:121, :153`).
- `new QueryClient()` uses default staleTime, so `utils.document.preflight.fetch` always refetches.

## Decisions for approval

**Nick's answers (AskUserQuestion, 2026-10-23):**
- Native retry stays immediately clickable; the lock is fetch-only.
- A native "request sent" is announced with an info toast.

### D1 — Preparation state and delivery state stay separate (kept)

| State | Owner | Visible as |
|---|---|---|
| Preparation pending | TanStack `isPending`; PG dialog `proceeding` | Existing labels |
| Preparation result | Mutation `onSuccess`/`onError`; PG dialog overlay | Existing "Document generated!" or the existing error toast and panel |
| Delivery in flight (fetch only) | Per-delivery registry (D4) | Auto: loading toast. Retry buttons: disabled, "Downloading…" |
| Delivery outcome | The attempt's feedback handle (D7); one per attempt | D2 |
| Recovery | P8 / generic panels | D6 / D9 |

`deliverAndAnnounce` stays `void` and detached, so `mutateAsync`/`isPending` never wait for a download. A synchronous
native `form.submit` throw still reaches `onError`; no other synchronous throw can (D10).

### D2 — Exact UI copy (transport feedback only; kept, plus one label)

**Subjects** (existing prefixes minus "— downloading..."):
- `Form generated` — every `generateMutation` site, including production P46;
- `Grant package generated`;
- `Generated letters`;
- `Generated ${n} P8 affidavit${n === 1 ? "" : "s"}`;
- `P46 Demand generated` — test-only fallback;
- `Estate export (${n} stored file${n === 1 ? "" : "s"})` — drops "ready", because the archive is built at delivery.

| Outcome | Owner | Exact text / effect |
|---|---|---|
| Native `submitted` (auto) | Attempt handle, `info` | `{subject} — download requested. Check your browser's downloads.` |
| Fetch in flight (auto) | Attempt handle, `loading` | `{subject} — preparing the download…` |
| Fetch `handed-off` (auto) | Same toast id, `success` | `{subject} — download started.` |
| `refused` / `failed` (auto or button) | Attempt handle `error` (replaces the loading toast) | Existing sentence, unchanged |
| `invalid` | Attempt handle `error` (**new**; was silent) | `The download could not be completed. Please try again.` |
| `suppressed` | None | The in-flight attempt keeps its feedback |
| Button `submitted` / `handed-off` | None new | The browser shows the file, or the server page |
| Retry button in flight | The button | Disabled, spinner, `Downloading…` |
| Preview `handed-off` | Preview attempt handle | `ZIP download started.` (validated filename ends `.zip`), else `DOCX download started.` |
| Preview non-handoff | Preview attempt handle, then **rethrow** (preflight contract kept) | Sentence or `Download failed` |
| Link unusable (D6) | Panel | P8: the sentence. Generic: `{code} — {sentence}`. Download hidden; Dismiss stays |
| Regeneration action (**new label**) | Panel button | `Review and generate again` |
| Regeneration refresh | Existing `preflight-busy` overlay | Existing `Preparing {form}…` |
| Obsolete attempt (D7) | — | Nothing: its toasts are removed and later ones dropped |

`submitted` is never worded as a handoff, and `handed-off` never as saved, received or complete. The PG dialog copy
is unchanged. Only the P46 fallback's action becomes "generate".

### D3 — Helper contracts (`client/src/lib/attachmentDelivery.ts`; transport untouched)

```ts
export type DeliveryFeedback = {        // one attempt's feedback handle (D7)
  current(): boolean;                   // owner mounted on the same scope, slot not retired/replaced, same session as at begin
  info(text: string): void; loading(text: string): void; success(text: string): void; error(text: string): void;
};                                      // every method is a no-op once not current; loading→success/error reuse one id
export type DeliveryFeedbackOwner = { begin(slot: string): DeliveryFeedback; retire(slot: string): void };
export type FeedbackTarget = { owner: DeliveryFeedbackOwner; slot: string };
export function useDeliveryFeedbackOwner(scopeKey: string, active?: boolean): DeliveryFeedbackOwner;
export function deliverAttachment(delivery: PostDelivery, control?: HTMLElement | null, feedback?: FeedbackTarget): Promise<DeliveryOutcome>;
export function deliverAndAnnounce(delivery: PostDelivery, subject: string, options?: { feedback?: FeedbackTarget; onOutcome?: (o: DeliveryOutcome) => void }): void;
export function fetchDeliveryAttachment(delivery: PostDelivery, signal?: AbortSignal): Promise<DeliveryOutcome>; // unchanged
export function useDeliveryPending(delivery: PostDelivery | null | undefined): boolean;
export function subscribeDeliveryPending(listener: () => void): () => void; // the hook's store; exported for failure-safety tests
export function unusableLinkMessage(outcome: DeliveryOutcome): string | null;
```

**Ownership:**
- One internal runner, `deliver(delivery, control, subject | null, feedback?)`, serves both entry points.
  `deliverAndAnnounce` no longer calls `deliverAttachment`, so there is exactly one error toast per failed attempt.
- `onOutcome` runs at most once and only while the handle is current. It may only update recovery state.
- With no feedback target (tests/legacy), a default handle is always current and uses global toasts, i.e. r1
  behavior. Every app call site passes a target.

**Unchanged:** validation; the token read; the native form; the envelopes; the fresh `attemptId`; caps, ceilings and
deadlines; identity checks; the Blob policy.

### D4 — Same-delivery coordination (kept; fetch path only)

- **Key:** the `PostDelivery` object a preparation returned. The auto-download and its retry share the reference; a
  replacement is a new object.
- **Not keyed on** `attemptId`, and **not on descriptor content.** A content key would suppress a deliberate bulk
  regeneration and hand back the older file.
- **Registry:** a module `WeakSet` plus `subscribeDeliveryPending` listeners.
- **Who registers:** only fetch-path attempts, after validation, the control check and the token read.
- **Release:** exactly once, at settlement (D10).
- **Behaviors:**
  - A delivery that is pending, or a control that is busy, returns `suppressed`. There is no second fetch or buffer
    and no queued POST.
  - `invalid` never registers.
  - Independent deliveries and controls are never serialized.
  - After release, a retry reads the current token and draws a fresh `attemptId`.
- **Native:** never registers. The 2-s control hold and the immediate native re-post stay
  (`p7-draft.test.tsx:176-183`, `p8-download.test.tsx:234-242`, `postDownload.test.tsx:209-222`).
- **Lifetime vs. retirement:** retiring an attempt's *feedback* (D7) does not release the lock while its request still
  runs (no cancellation; Task 12 owns that).

### D5 — One visible failure owner (kept)

- Each attempt's handle owns its single transient announcement, and callers never toast delivery outcomes.
- Delivery failures never reach `onError`, so there is no false "X was not generated".
- The preview keeps one catch toast plus the rethrow, now through its own handle.
- The panel is the persistent recovery surface (Addendum 24.8). A refusal sentence there mirrors the existing
  generation-failure pattern of toast plus panel.

### D6 — Recovery mapping (corrected)

| Outcome | Download retry | Regeneration | Panel |
|---|---|---|---|
| `submitted`, `handed-off`, `suppressed`, `cancelled` | Kept | — | Unchanged |
| refused **409** (`downloadRoute.ts:185, :299, :345`, unreadable stored file `:411`), **400** (`:109, :143, :151, :159, :275`), **413** (`deliveryRouter.ts:210`); `invalid` | **Hidden.** The link cannot succeed unchanged, and dead retries after the rate check (`:190`) spend rate units | **D9** `Review and generate again` when a regeneration context exists; otherwise none (the form's own controls remain, with their reset limits recorded) | Server sentence **verbatim** (re-upload/repair guidance preserved); `role="alert"`; Dismiss |
| refused 401 / 403 / 404 | Kept: fresh attempt with the current credentials once access is restored | Not offered | Unchanged |
| refused 429 / 500 / 503 | Kept | Not offered; no rollback claim | Unchanged |
| failed network / timeout / redirect / invalid-response / too-large / incomplete / session-changed | Kept (existing sentences) | — | Unchanged |

**Panel state:**
- Both panels keep the descriptor and gain `refusal?: string` and `regeneration?` (D9).
- Updates are identity-guarded functional `setState` calls (`current?.delivery === delivery`) from the top level of
  FormsTab.
- The r1 claim that the form's own Generate preserves every choice is withdrawn.
- "Review & retry" after a *generation* failure is pre-existing and unchanged (its target loss is recorded).

### D7 — Feedback ownership: mounted owner, slot and session (new)

**Owners and slots:**

| Surface | Owner `scopeKey` (active) | Slots |
|---|---|---|
| FormsTab | `forms:${estateId}` | `p8-recovery`, `form-recovery`, `package`, `letters`, `p8-all` |
| DeliveriesCard (P46 test-only fallback) | `deliveries:${estateId}` | `p46` |
| FormPreviewModal | `preview:${estateId}` (active = `open`) | `preview` |
| Notes tab | `notes:${estateId}` | `notes` |
| Home | `home` | `export:${estateId}` |

**Lifecycle:**
- **Begin.** `begin(slot)` runs only when an attempt actually starts, after the suppression checks. A native attempt
  begins after a successful submit. Beginning retires the slot's previous attempt (replacement).
- **Retire, synchronously,** on any of:
  - owner unmount, `scopeKey` change (another estate), or `active=false` (layout-effect cleanup);
  - `retire(slot)` in the panel Dismiss handlers;
  - `retire(slot)` wherever a generation error replaces the panel (`onError` and the no-delivery branch).
- **Session:** the handle snapshots `{token, generation}` at `begin`, and `current()` requires the same session.
- **Retirement effect:** every toast the attempt created (loading/info/success/error) is dismissed at once. Later
  toasts and `onOutcome` are dropped.
- **Not cancellation:** the request is not cancelled, so the browser may still receive a handed-off file. That is
  the browser's own download UI, not app feedback.
- **Dispatch check:** `current()` runs synchronously immediately before every toast and before `onOutcome`. A
  retirement or session change between transport resolution and dispatch therefore always wins.
- **Effect:** obsolete feedback can never look like the current estate's or session's result.
- **Accepted consequence:** a superseded, dismissed or navigated-away attempt's later outcome is not announced. The
  current panel, its controls and the browser's download list remain.

### D8 — Native observation boundary (kept)

Native streaming is unchanged, with no buffering and no new caps. Native results stay "requested; check your browser".
A native refusal stays a page navigation, never a JavaScript status.

### D9 — Memory-only review/regeneration path (new)

**Capture (React state and closures only).** Nothing is persisted, logged or sent except the identical generate call
after an explicit user action.
- **Single-form preflight runs.** `runWithPreflight` is the one chokepoint. Immediately before it invokes the
  continuation — in its all-green branch (`:8370`) and in `handlePgProceed` (`:8439`) — it records
  `{ formCodes, formName, doMutate, renderContext }` in a ref, which is cleared in `finally`.
  - Recording happens only when `formCodes.length === 1 && renderContext.supportsOverrides === true` and the action
    is "generate". Previews, preview downloads, package and bulk never record.
  - `generateMutation.onSuccess` attaches it to the new panel state as `regeneration` only if
    `formCodes[0] === variables.formCode`.
  - The recorded continuation already closes over every original choice: LETTER recipient, P17 renouncer, P46
    delivery, P34 citation, deponent, ordinal, signatory, date and manual-P5 options. `renderContext.overrides`
    holds the merged per-run answers.
- **Consent forms (direct path; the original has no preflight).** `CONSENT_NOMINATION` /
  `CONSENT_APPOINT_ADMINISTRATOR` keep the exact mutation input (`variables`): target, consent payload, signatory and
  date.

**Action.** Shown only on a link-unusable panel that has a context.
1. The click raises the existing `preflight-busy` overlay ("Preparing {form}…").
2. **Refresh facts:** await invalidation of `estate.get`, `contact.list`, `document.list`, `delivery.list`,
   `delivery.getRecipients`, `citation.list` and `document.getLetterRecipients`.
3. **Gate runs:** `runWithPreflight(formCodes, formName, doMutate, { ...renderContext, reviewBeforeGenerate: true }, "generate")`.
   - The fresh preflight decides the gaps.
   - `reviewBeforeGenerate` opens the existing gap dialog **even when every check passes** ("Ready to generate
     {form}", the state P16's mandatory review already uses).
   - Nothing is generated until the user clicks Generate or Generate anyway there.
   - Warnings, inline editors, Generate anyway and hard blocks are unchanged.
4. **Consent:** reopen the existing consent dialog prefilled from the retained input (nominee, relationship, share or
   administrator; the name comes from the refreshed contacts). The retained signatory and date ride in the draft.
   The user clicks the existing `Generate DOCX`. No preflight is added to consent.
5. **Cancel** changes nothing: no generation, and the panel stays.

**Proposed additional client-state scope (approval needed before editing):**
- (i) the run ref plus the `regeneration` field on the two panel states;
- (ii) `reviewBeforeGenerate?: boolean` on `PreflightRenderContext` (`EstateDetail.tsx:7264`), plus one condition in
  `runWithPreflightInner` next to the existing `reviewP16`;
- (iii) optional `signatoryType` / `signatureDate` on the two consent draft states, used as
  `draft.x ?? lifted x` by their Generate buttons;
- (iv) the refresh invalidations.

There is no FormDetailsDialog change, and no change to legal defaults, deponent selection, applicability or
rendering.

### D10 — Failure-safe, exactly-once attempt lifecycle (new)

```
start: validate → (invalid: begin + error, return) → suppression → token read
  native: submitNativeForm  (a throw propagates; nothing registered or begun)  → begin → info (auto) → submitted
  fetch:  begin → guarded { register pending; hold control; loading (auto); start fetch }
          a synchronous throw inside the guard → finish(failed("invalid-response")), with no request sent
finish(outcome), once (attempt.done):
  1 release the control              (isolated)
  2 release pending + notify every listener (each listener isolated)
  3 if handle.current(): the result toast (isolated), then onOutcome (isolated); else nothing (retirement already
    dismissed)
```

- **"Isolated"** means try/catch with no logging (Task 9 decision: no console trail). A throwing toast, subscriber or
  `onOutcome`:
  - never skips a later step;
  - never rejects the returned Promise;
  - never re-runs the attempt (no second POST);
  - never reaches a mutation `onError`.
- **The one synchronous throw** `deliverAndAnnounce` can raise is a native `form.submit` throw (the existing
  contract, `p3-longform.test.tsx:316-343`).
- **The transport promise** is consumed with `.then(finish, () => finish(failed("invalid-response")))`.

## Files

| Kind | Path (EOL) | Change |
|---|---|---|
| App | `client/src/lib/attachmentDelivery.ts` (LF) | D3/D4/D7/D10: runner, registry and hook, owner/handle, lifecycle, `unusableLinkMessage`. Header comment says "no stored fallback token → native". About 110 lines |
| App | `client/src/pages/EstateDetail.tsx` (CRLF) | FormsTab:<br>• owner and slots, subjects, `onOutcome`;<br>• retry buttons (pending label, recovery);<br>• panel states, retire calls;<br>• run capture in `runWithPreflightInner`/`handlePgProceed`;<br>• `reviewBeforeGenerate`; the regeneration action; consent draft signing/date.<br>DeliveriesCard: owner and P46 action. Preview: owner and handle, ZIP copy. Notes: owner. About 80 lines |
| App | `client/src/pages/Home.tsx` (CRLF) | Owner, slot, subject. About 4 lines |
| Test (new) | `client/src/pages/EstateDetail.task13-recovery.test.tsx` (LF) | FormsTab, both transports: regeneration (D9), stale feedback (D7), failure safety (D10), P46 production path, slow-fetch suppression |
| Test (edited) | `attachmentDelivery.test.tsx` (LF) | Mock `:15` gains `loading`/`dismiss`. Announce test `:425-435` rewritten. "Independent controls" `:748-756` uses `{...form}`. New owner, lifecycle and same-delivery cases |
| Test (edited) | `EstateDetail.bearer-delivery.test.tsx` (LF) | Mock `:18`. Copy at `:214-215`, `:268-270`/`:285`, `:318`. Wait for `retry.disabled === false` before `:230-231`, `:258-259`. Preview ZIP case |
| Test (edited) | `Home.bearer-export.test.tsx` (LF) | Mock `:25`; copy at `:126` |
| Test (assertion only) | `EstateDetail.p3-longform.test.tsx` (CRLF) | `:249`, `:250` (`invocationCallOrder` reads `info`), `:265`, `:341` become `info` with the D2 text. `:330` adds "no info toast" |
| Test (assertion only) | `EstateDetail.{p5-draft,p7-draft,p11-draft,p8-download,preflight-busy}.test.tsx` (CRLF) | `info` with the D2 text at p5 `:326`, p7 `:173`, p11 `:151`, p8 `:246`/`:275`, preflight-busy `:145`. "No info toast" at p5 `:354` and p8 `:268`/`:284` |
| Test (assertion only) | `EstateDetail.preflight.test.tsx` (CRLF) | P46 fallback action becomes "generate" (`:654`) |
| Untouched | Server, `fallbackSession.ts`, `PreGenerateDialog.tsx`, `FormDetailsDialog.tsx`, `postDownload.test.tsx`, chatbot, `debug-collector.js`, RULES.md, queue | — |

Every candidate file is uniform LF or CRLF (census done), with no mixed files. A CR-normalized hash plus an EOL
census runs after each edit.

## Connected-feature matrix

| Surface | Prep owner | Delivery key / feedback | Recovery / regeneration | Proof |
|---|---|---|---|---|
| Single form:<br>• form row `:9561`;<br>• details `:8837` (prod P46, P34, P8);<br>• optional popup `:8969`;<br>• P19 `:9014`;<br>• LETTER recipient `:9073`;<br>• P17 `:9506` | `generateMutation` + PG dialog | `data.delivery`; FormsTab `form-recovery` / `p8-recovery` | Panel; D9 gate replay (captured run) | Unit, React, browser |
| Consent nomination / administrator `:9741`, `:9793` | `generateMutation` (direct) | Same | Panel; D9 prefilled consent dialog | React |
| P8 / generic retry `:9964`, `:9978` | — | Same object, same slot | Panel | Unit, React, browser (paused fetch) |
| Package / letters / all-P8 `:8215-8245` | Own mutations | Slots `package` / `letters` / `p8-all` | None (re-click = deliberate regeneration) | React, browser |
| P46 card fallback `:10101-10110`, `:10410` (**test-only**) | `p46Mutation` | DeliveriesCard `p46` | None | React only, labelled |
| Home export `Home.tsx:235-246` | `exportMutation` | Home `export:${estateId}` | None | React, browser |
| Notes `:11880` | — | Notes `notes` (button hold) | None | Regression, browser |
| Preview `:7391-7451` | Modal `generateDocxMutation` | Preview `preview`, active = open | PG rethrow | React, browser |
| PG dialog / preflight-busy / `runWithPreflight` | — | — | `reviewBeforeGenerate` used only by D9 | Existing suites plus D9 tests |
| Routes, audits, reports, transport/session, chatbot, collector, runtime listener | — | — | — | Unchanged; gates |

- **Input/render-selection contracts** are untouched. D9 replays them exactly: overrides, deponent, signatory, date,
  consent, citation, P9 proof, `generateAnyway`, delivery/citation ids and the ordinal.
- **Audit/report owners** are unchanged: delivery started/finished audits, Task 5 generation audits, Task 15 export
  reports. The notes audit stays absent (Task 10).

## Implementation steps (only after approval)

0. **Setup, before any code edit.**
   - Copy the plan into the repo and record its hash.
   - Re-verify identity, index and status. An unexpected change means **STOP**.
   - Create `.work/hybrid-remediation/task13/claude-pass01/` with `preflight.md`, `task-files.txt`, `qa-files.txt`
     and `reference-files.txt` (frozen sources, routes, `fallbackSession.ts`, `PreGenerateDialog.tsx`,
     `FormDetailsDialog.tsx`, `botClient.ts`, `postDownload.test.tsx`).
   - Take `qa/snapshot.cjs before` (byte copies, SHA-256, EOL census).
1. **Red.** Write the new/changed tests first, then run `run-gates.cjs claude-task13-red1 focus --test-file=…` on
   unchanged source and keep each behavioral failure in `red/`.
2. **Implement**, serially: helper first, then EstateDetail/Home (CRLF census after each edit).
3. **Green.** Run focus `claude-task13-focus1`, plus the QA-only test-type check (`qa/tsconfig.task13-tests.json`,
   `exclude: []`). Task 9's 9 pre-existing errors are kept separate (`postDownload.test.tsx:50` plus eight
   `EstateDetail.preflight.test.tsx` mock lines); any error on a Task 13 line is fixed.
4. **Mutants**, QA-only, with byte-exact restore and hashes before and after. Every mutant must be killed by an
   assertion:
   - M1: no registration.
   - M2: release only on handoff.
   - M3: native registers.
   - M4: the submitted copy equals the handoff copy.
   - M5: 401 counted as unusable.
   - M6: no panel identity guard.
   - M7: error toast without the loading id.
   - M8: the preview ignores `.zip`.
   - M9: announce reuses `deliverAttachment` (double error).
   - M10: a refusal leaves Download visible.
   - M11: no `done` guard (double cleanup).
   - M12: `onOutcome` not isolated.
   - M13: the dispatch check moved before the handoff.
   - M14: `begin` before the native submit.
   - M15: the regeneration skips `reviewBeforeGenerate`.
   - M16: the regeneration drops the captured ordinal.
5. **Final candidate bundle.**
   - Build with `run-gates.cjs claude-task13-build1 build`.
   - Restart the fixture through the owned launchers (identity checks below).
   - Run `qa/build-manifest.cjs`, which hashes **every served file**: `dist/public/index.html` plus every entry and
     lazy asset.
   - Only then start the browser runs.
6. **Real fictional browser QA** (below). Every CDP-loaded script/style response must hash-match the manifest.
7. **Independent read-only review** of the complete Task 13 delta, including the new test file. Four reviewers, all
   `model: opus`:
   - `pr-review-toolkit:silent-failure-hunter`;
   - a general-purpose security/a11y/truthfulness reviewer (the Review Council guard is not bypassed);
   - a general-purpose agent with `probate-integrity-gate`;
   - a claims audit after the final status.
   **Any application fix after step 5** means: rebuild, new manifest, then repeat the affected browser checks.
8. **Full gates**, serial and bound to the final hashes:
   `& 'C:\Program Files\nodejs\node.exe' '.work\hybrid-remediation\run-gates.cjs' claude-task13-pass1 check tests chatbot-check chatbot-tests build render`
   (label verified unused).
   - Read `results.json` and the logs.
   - Then `qa/manifest-recheck.cjs`: every served file must be byte-identical to the browser-tested manifest. If not,
     repeat the affected browser checks on these bytes.
9. **Close-out.**
   - Take `after`/`final` snapshots and reconcile hashes and EOL classes against `before`.
   - Write `review/task13-delta.diff` and `final-status.md`.
   - Restore and stop the fixture.
   - **STOP.** Acceptance is Nick's; Task 13 is not marked done; no SHIP claim; no next task.

## Verification

**Unit and React tests.** Real `Response`/`ReadableStream` via `browserResponse.testkit.ts`; production validation is
never relaxed; behavior and DOM-visible timing are tested, not just callbacks.

*Kept from r1:*
1. A slow fetch auto-download plus a retry click gives **1** POST; the retry shows "Downloading…" until settlement.
2. Native gives the info copy, never handoff copy.
3. The loading toast becomes success/error under one id; a failed auto-download shows exactly one error.
4. A 409/400/413 hides Download and shows the verbatim sentence with `role="alert"`.
5. Preview: ZIP vs DOCX copy.
6. `invalid` gives the generic error.
7. The P46 fallback uses action "generate".
8. Same descriptor from two controls gives one fetch; distinct descriptors both proceed.
9. The status matrix: 400/401/403/404/409/413/429/500/503 and every `failed` reason. Each gives one safe toast, no
   success toast, no file, and the D6 panel.

*D9 — regeneration:*
- **P8** (details: deponent Avery, ordinal "second", date D, signatory S). A 409 shows `Review and generate again`.
  The click awaits the invalidations and a fresh preflight. The dialog opens although all checks pass. **No generate
  call happens until Generate**, and then the input carries `deponentId: "avery"`, `affidavitOrdinal: "second"`,
  `signatureDate: D` and `signatoryType: S`.
- **P46 production** keeps its `deliveryId` and the demandant's date (not reset).
- **LETTER recipient** with an inline-fill override keeps its `targetBeneficiaryId` and overrides.
- **P17** keeps its renouncer.
- **Consent nomination** reopens prefilled, and only `Generate DOCX` regenerates (same payload, retained date).
- Cancel generates nothing and keeps the panel. Gaps found during review still warn, with Generate anyway enabled.
- A re-upload 409 sentence is shown verbatim. No context means no regeneration button.

*D7 — stale feedback.* Each case is run once while pending and once **between transport resolution and dispatch**
(triggered inside the mocked anchor `click`, i.e. the handoff instant, and inside the fetch stub's resolution):
- Cases:
  - panel Dismiss;
  - replacement (a newer generation in the same slot);
  - FormsTab unmount;
  - an `estateId` change;
  - preview close;
  - session change (token swap, and `clearFallbackSession`).
- Assertions:
  - the obsolete attempt's toasts are removed and no new ones appear;
  - no `onOutcome` and no panel change;
  - the pending lock is still released at settlement;
  - no focus change and no unhandled rejection;
  - the new owner's or attempt's feedback is intact.

*D10 — failure safety.* Each throw is injected separately:
- `toast.loading`, the result toast, `onOutcome`, and a `subscribeDeliveryPending` listener (on register and on
  release). The `holdControl` attribute write throws after registration.
- For each: no stuck pending state, no unhandled rejection, no second POST, cleanup runs once (counted), and inside
  FormsTab no "not generated" panel or `onError`.
- Unchanged:
  - a native submit throw still propagates with nothing registered, and a following native retry still posts;
  - independent deliveries still proceed.

*Must stay green:*
- 401, then retry with a fresh attempt.
- After a failure, the retry carries a swapped current token and a new `attemptId`.
- No token in any toast or console call.
- **Generate anyway stays warn-and-proceed**, with the deponent/date/consent/override/citation/P9-proof assertions
  (existing p3/p5/p7/p8/p11/p16/preflight suites).
- The preview rethrow (`preflight.test.tsx:460-529`).
- Registry hygiene: each new test settles every attempt and uses its own descriptor objects.
- Vitest fails on any unhandled rejection (no `dangerouslyIgnoreUnhandledErrors`).

**Real fictional browser.** Steps 5–8 bind it to the final served bytes.

*Harness.* Task 9's owned harness copied to `task13/claude-pass01/qa/`: `browser-launch.cjs`, `cdp.cjs`,
`snapshot.cjs`, `build-manifest.cjs`, `manifest-recheck.cjs`, `compare-docx.cjs`, `audit-correlate.cjs`.
- **New QA-only CDP Fetch pause:** `Fetch.enable` at the Response stage for `*/api/download/*` on the page session.
  Each paused request is continued in a `finally`, and Fetch is disabled afterwards.

*Identity.* The fixture `mysql-fixture.cjs --resume-owned-fixture` and `start-ui-task15.cjs`/`ui-server-task15.ts`
are reused unchanged.
- MySQL: `@@datadir`/`@@port` must match `.work/hybrid-remediation/fixture/db`/43316 before any write.
- UI launcher checks `status.json` and the `runtime.private.json` identity, refuses `.env*` and
  `AWS_*`/`STORAGE_S3_*`/`LEGAL_RECORD_STORAGE_APPROVED`, binds loopback 43117 and serves `dist/public`.
- The ports alone are not proof.
- A fresh isolated Chromium profile with disposable fictional users and sessions. Values and header contents are
  never printed (presence only).

*Captured.*
- Request count, header presence, status and CDP timestamps.
- Toast/panel DOM text with mutation timestamps.
- The downloaded-file SHA-256 against the network body and the server capture (`capture-deliveries.ts`, notes
  allowlist kept).
- Captures are armed one-shot.

*Scenarios.*
- Single P10 (Generate anyway), native and Bearer.
- **Paused-fetch suppression:** repeated retry clicks give 0 extra requests; release gives 1 file; a deliberate retry
  gives a new body hash.
- The real stale link: the preview regenerate replaces the row, then the old panel's Download gives a 409 with the
  verbatim sentence. **`Review and generate again`** then opens the review dialog; Generate delivers with the
  retained choices (P8 deponent and ordinal, or P46 delivery and date).
- Package, letters and all-P8.
- **P46 production path.** A disposable fictional estate is set up through the UI if the fixture has none, then
  deleted with an owned-row digest; otherwise labelled not-run.
- Home export, notes and the preview (DOCX; a ZIP form if the fixture supports one, else unit-only, labelled).
- Offline, then retry. An invalid Bearer token gives a 401 with retry kept and no regeneration.
- A cookie tab given a fixed fictional fallback value takes the fetch path.
- **Stale feedback in the browser:** with a paused download, then (a) navigate to another estate, (b) close the
  preview, (c) swap the token. On release: no obsolete toast on the new view, and the browser's file arrival is
  recorded separately.
- A native refusal is a page navigation.

*No re-runs.* No uncertain submission is replayed before its evidence has been read.

*Restoration.* History digest restored, disposable users and estate removed with digests, the failure_reports count
recorded, processes stopped by their verified trees, and no listeners left.

**Output and freeze.**
- Server untouched.
- Per-response transport equality.
- Native vs Bearer DOCX parts like-for-like for one form: only `dcterms:created`/`modified` may differ. Printed
  dates, answers and cover text are never normalized.
- Freeze guard plus 26 renders. No generated-byte persistence.
- Word/pixels **user-deferred-not-passed**; Safari/iOS/Android not tested.

## Retained deferrals (untouched)

- Dev/Preview delivery-body logging redaction: required before real client data; **OPEN**.
- No console trail.
- Chatbot rotation moves cookie tabs onto fetch.
- The runtime `message` listener check: **OPEN** before production.
- WebView proof outstanding. "Handed off" is not "saved".
- Word/pixels deferred. Task 15's browser gap is outstanding.
- Task 12 owns preview abort/close/body lifecycle.
- The native duplicate retry stays possible (unobserved submission; existing accepted behavior).
- A sync native submit throw still reports through the mutation error path.
- The preview gap-dialog overlay and the preview toast both follow one handoff (existing overlay).
- A loading toast cannot be closed by the user; it is bounded by the 15-min headers and 30-min body deadlines.
- "Review & retry" after a *generation* failure still drops targets (pre-existing).
- An obsolete attempt's late outcome is not announced (D7 consequence).

## Plan reviews and dispositions

| Review | Finding | Disposition |
|---|---|---|
| Plan agent (opus, r1) | Keying/timing sound; double error toast risk; loading toast must be fetch-only; incomplete test list; "Review & retry" drops targets; P8 must stay retryable; classification confirmed; click timing; hook wiring | All folded into D3/D6/D9/Files/Verification |
| Nick (r1) | Regeneration context; stale feedback ownership; failure-safe cleanup; final-bundle discipline | D9, D7, D10, steps 5–8 |

## Capability routing (`/find-skill`; `/orchestrate-swarms` is not installed)

- **Skills:**
  - `superpowers:writing-plans`;
  - `superpowers:test-driven-development` (red first);
  - `probate-integrity-gate` (read-only freeze/wording);
  - `superpowers:verification-before-completion`.
- **Agents:**
  - Plan/Explore for read-only critique;
  - after approval, serial implementation on the `EstateDetail.tsx` spine;
  - four parallel read-only reviewers (step 7).
- **Red flags:**
  - the god file and the frozen docgen;
  - the subagents-140 model pin (pass `model`);
  - the Review Council guard;
  - CDP traps (`allowAndName`, per-session emulation, ExtraInfo order, cookie banner);
  - six idle peer sessions.
