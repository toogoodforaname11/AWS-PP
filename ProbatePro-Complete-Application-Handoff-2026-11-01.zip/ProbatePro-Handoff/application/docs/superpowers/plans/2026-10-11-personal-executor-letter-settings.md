# Personal Executor Letter Settings Implementation Plan

> **For agentic workers:** Execute this focused repair natively, one testable step at a time.

**Goal:** Let personal-executor accounts configure their beneficiary-letter body, closing, letterhead, and existing letter-contact preferences without exposing lawyer-only profile fields.

**Architecture:** Keep the existing settings API, database fields, and letter renderer unchanged because they are already account-purpose neutral. Refactor the client Settings navigation and existing `FirmSettingsSection` into a role-aware presentation: lawyer accounts keep their Firm details surface, while personal executors receive a neutral Letters surface exposing the same letter-output controls and hiding professional firm profile inputs.

**Tech Stack:** React 19, TypeScript, Tailwind/Shadcn, tRPC, Vitest + Testing Library.

**Spec:** Inherited task context, user request to expose beneficiary-letter settings to personal executors, and `RULES.md` format-preservation requirements.

## Global Constraints

- Account purpose is a workspace preference, not an entitlement boundary for a setting that controls the account's own beneficiary letters.
- Do not change `server/docgen.ts`, database schema, API validation, official court-form wording, or document layout.
- Preserve the existing custom-letterhead option that suppresses sender/firm text while retaining the closing/signature block.
- Preserve the beneficiary-letter-only option to hide address, phone, and email from the signing block beside an uploaded DOCX letterhead template.
- Keep lawyer-only professional profile and service-contact fields hidden for personal executors.
- Keep labels neutral and professional for executor-facing controls.

## Review Focus

- A personal executor sees valid navigation links whose anchors exist in the rendered Settings page.
- A personal executor can save the body template and closing through the existing protected settings mutation.
- With a DOCX letterhead configured, a personal executor can persist both signing-contact suppression and text-letterhead suppression preferences.
- Lawyer accounts retain their existing Firm details anchor and save workflow.
- No server, schema, or document-generation path changes as part of this UI availability repair.

---

### Task 1: Expose shared letter settings to personal executors

**Files:**
- Modify: `client/src/pages/Settings.tsx`
- Modify: `client/src/pages/Settings.test.tsx`
- Create: `docs/audits/personal-executor-letter-settings.md`
- Modify: `todo.md`

**Interfaces:**
- Consumes: existing `trpc.settings.get`, `settings.update`, letterhead upload/delete mutations, and persisted fields `letterBodyTemplate`, `letterClosing`, `letterShowPerLine`, `hideBeneficiaryLetterSigningContact`, and `suppressFirmText`.
- Produces: an account-purpose-aware Settings presentation only; no new API or schema interface.

- [ ] **Step 1: Write a focused failing Settings regression**

  Set `settings.accountPurpose` to `"personal_executor"` and configure an existing DOCX letterhead fixture. Assert that `#letter-settings`, `#letter-template`, and `#letter-closing` are navigable; professional profile controls remain absent; a template save and closing save invoke the existing update mutation; the beneficiary signing-contact checkbox and sender-text suppression switch invoke their existing persisted fields.

- [ ] **Step 2: Run the focused test to verify the current role gate fails it**

  Run: `pnpm test -- client/src/pages/Settings.test.tsx --maxWorkers=1`

  Expected: FAIL because personal-executor navigation and all of `FirmSettingsSection` are intentionally hidden.

- [ ] **Step 3: Implement the role-aware presentation in `Settings.tsx`**

  Replace the executor navigation filter with a purpose-aware navigation list. Remove the component-wide executor early return. Present the existing letterhead/template/closing controls under a neutral Letters anchor for personal executors, conditionally hide only the Lawyer and Firm Profile input block, and use neutral executor copy plus an accessible name for the sender-text suppression switch. Preserve the existing mutation payloads and IDs used by lawyer accounts.

- [ ] **Step 4: Run the focused Settings test to verify the repair**

  Run: `pnpm test -- client/src/pages/Settings.test.tsx --maxWorkers=1`

  Expected: PASS, including the personal-executor regression and retained lawyer behavior.

- [ ] **Step 5: Validate the related letter contract and full application**

  Run: `pnpm test -- client/src/pages/Settings.test.tsx server/letter-template.test.ts --maxWorkers=1 && pnpm check && pnpm test -- --maxWorkers=1 && pnpm build && git diff --check`

  Expected: every command exits successfully.

- [ ] **Step 6: Record scope and checkpoint**

  Add one audit note and one completed tracker entry only after fresh successful validation. Review the scoped diff, verify the existing dev server health, then create one checkpoint documenting that personal executors can configure letter output while lawyer-only profile fields and all court-form/document-generation behavior remain unchanged.
