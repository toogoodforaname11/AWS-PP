# Public Walkthrough Landing Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the landing page’s simulated first-fold product carousel with the supplied ProbatePro walkthrough in a polished, accessible video frame, and sharpen the public information hierarchy around the real product demo.

**Architecture:** The supplied 2:54 walkthrough stays a user-controlled native HTML video, hosted through project storage with `preload="metadata"`, a compressed poster, and WebVTT captions derived from the supplied narration. `Landing.tsx` keeps its existing public SEO and authentication behavior while introducing a small self-contained `WalkthroughFrame` component. Existing Framer Motion handles restrained entrance motion; CSS provides a navy/slate double-border frame, focus treatment, and fine-pointer-only hover depth without adding new dependencies.

**Tech Stack:** React 19, TypeScript, Tailwind CSS, Framer Motion, Vite, Vitest, native HTML video.

**Spec:** User-supplied `/home/ubuntu/upload/walkthrough_v7.mp4`; walkthrough analysis and transcript at `/home/ubuntu/video_walkthrough_v7_analysis_20261013_001455.md` and `/home/ubuntu/upload/walkthrough_v7_converted_20261013_001409_transcription_20261013_001417.txt`.

## Global Constraints

- Use the user-supplied walkthrough only; do not fabricate product screens, claims, testimonials, legal content, or citations.
- Mark the recording as a fictional sample estate and retain user-controlled video playback; do not autoplay 29 MB of video.
- Use an explicit accessible caption track, a visible focus treatment, and `playsInline`.
- Preserve all authentication, SEO metadata, FAQ JSON-LD, public Terms/Privacy links, internal routes, estate data, court-form wording, document rendering, and legal content.
- Keep the page professional and restrained: no generic gradient-card clutter, fake browser controls, animation unrelated to user action, or button arrows.
- Do not add heavy dependencies; use the existing Framer Motion and Tailwind stack.

## Review Focus

- **Low-bandwidth opening:** The page must load poster/metadata rather than fetch the entire 2:54 video immediately.
- **Keyboard control:** The native video controls remain reachable and the “Watch walkthrough” anchor lands on the video frame.
- **Small screens:** The video maintains a 16:9 crop, preserves the double border, and does not cause horizontal overflow at 375px.
- **Motion preference:** Entrance and hover effects stay non-essential and the existing reduced-motion handling leaves video controls usable.
- **Truthfulness:** The visible “fictional sample estate” label and supplied captions match the actual walkthrough rather than making a performance, outcome, or legal-service claim.

---

### Task 1: Host walkthrough and accessibility assets

**Files:**
- Create: `/home/ubuntu/webdev-static-assets/probatepro-walkthrough-poster.jpg`
- Create: `/home/ubuntu/webdev-static-assets/probatepro-walkthrough.vtt`
- Modify: `client/src/pages/Landing.tsx`

**Interfaces:**
- Produces: `WALKTHROUGH_VIDEO_SRC`, `WALKTHROUGH_POSTER_SRC`, and `WALKTHROUGH_CAPTIONS_SRC` constants containing project-storage paths.
- Consumes: the user-provided H.264/AAC MP4, its supplied narration transcript, and the first-frame poster extracted without altering the original.

- [ ] **Step 1: Prepare a failing landing regression for a labeled product video**

Assert the rendered public page includes an element labeled `ProbatePro product walkthrough`, `controls`, `playsInline`, `preload="metadata"`, a poster, a captions track, and the visible fictional-sample disclosure.

- [ ] **Step 2: Run the focused landing test and verify the static product mockup cannot satisfy the video assertions**

Run: `pnpm exec vitest run client/src/pages/Landing.auth.test.tsx --maxWorkers=1`

Expected: FAIL because no public video element or captions track exists.

- [ ] **Step 3: Upload the original MP4, a sampled poster, and validated caption file through project storage**

Copy the user-provided original outside the repository, extract a 16:9 poster without overwriting the source, write a WebVTT file using the supplied narration timing, and use `manus-upload-file --webdev` for the three files. Do not put media under `client/public`.

- [ ] **Step 4: Add exact storage paths to `Landing.tsx` constants**

Keep asset URLs in a small data block near the landing metadata so `WalkthroughFrame` has no hard-coded media URL in its markup.

### Task 2: Build the bordered walkthrough frame and restructure the first fold

**Files:**
- Modify: `client/src/pages/Landing.tsx: hero section and public content components`
- Modify: `client/src/index.css: public walkthrough frame utilities`
- Test: `client/src/pages/Landing.auth.test.tsx`

**Interfaces:**
- Consumes: `WALKTHROUGH_VIDEO_SRC`, `WALKTHROUGH_POSTER_SRC`, and `WALKTHROUGH_CAPTIONS_SRC` from Task 1.
- Produces: `WalkthroughFrame(): React.ReactElement` and a stable `#walkthrough` section target.

- [ ] **Step 1: Replace the simulated carousel’s first-fold placement with `WalkthroughFrame`**

Use an editorial two-column hero on large screens and vertical stack on small screens: concise headline/primary sign-in action on the left, the real walkthrough on the right. Add a secondary text link to `#walkthrough` named `Watch walkthrough` without adding arrows.

- [ ] **Step 2: Add a restrained double border and frame metadata**

Render a semantic labelled section containing a small `Product walkthrough` header, `2:54` duration, the native video, `track kind="captions"`, and `Fictional sample estate` disclosure. Create a navy/slate outer ring, white inset border, modest shadow, and fine-pointer-only hover lift. Use a visible focus-within ring rather than an animation-only response.

- [ ] **Step 3: Reorder landing context for scanability**

Preserve the existing verified public content but lead with the real walkthrough, then the three audience/workflow cards, form coverage, workflow, and FAQs. Remove only the first-fold simulated carousel from the rendered hierarchy; do not change public legal-boundary copy or structured data.

- [ ] **Step 4: Extend the landing regression**

Verify the primary headline, sign-in action, walk-through link, source/video behavior, caption track, fictional-sample disclosure, and FAQ metadata coexist.

### Task 3: Validate responsive interaction and production safety

**Files:**
- Test: `client/src/pages/Landing.auth.test.tsx`
- Modify: `docs/audits/public-walkthrough-landing.md`
- Modify: `todo.md`

**Interfaces:**
- Consumes: the final public landing and hosted assets.
- Produces: audit record and tracker entry only after fresh successful validation.

- [ ] **Step 1: Run focused red/green regression, TypeScript, full serial tests, and production build**

Run:

```bash
pnpm exec vitest run client/src/pages/Landing.auth.test.tsx --maxWorkers=1
pnpm check
pnpm test -- --maxWorkers=1
pnpm build
```

Expected: every targeted test passes, the TypeScript check exits zero, the full suite has no failures, and the production build succeeds.

- [ ] **Step 2: Inspect desktop and 375px screenshots plus keyboard playback controls**

Use the project screenshot tool at desktop and 375px widths. Open the page in the browser, navigate to `#walkthrough`, and confirm native video controls receive keyboard focus without clipping or page overflow.

- [ ] **Step 3: Check scope and record the audited outcome**

Run `git diff --check`, inspect the scoped diff, confirm local/public preview health, then write the audit note and one precise `todo.md` completion entry. Save a WebDev checkpoint that states no internal probate or legal content changed.
