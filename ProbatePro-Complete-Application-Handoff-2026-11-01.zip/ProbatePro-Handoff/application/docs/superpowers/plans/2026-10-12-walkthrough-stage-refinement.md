# Walkthrough Stage Refinement Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the generic nested-card treatment around the public walkthrough with a precise, editorial media stage that feels native to a legal-workflow product.

**Architecture:** Repair the media-delivery boundary first: proxy the one fixed public walkthrough object through a same-origin, range-aware route which returns `inline` MP4 headers. Production CSP currently permits only same-origin media and the upstream CDN marks the MP4 as an attachment, which explains the mobile inline-playback failure. Then retain the existing native video, poster, caption loader, anchor, and accessibility contract while reworking only the `WalkthroughFrame` layout and its component-scoped CSS: an indexed, rule-led header; a single restrained video boundary; and a compact figure caption. The design uses existing navy, slate, and white tokens and does not add a component library or animated background.

**Tech Stack:** React 19, TypeScript, Tailwind utility classes, scoped CSS, Vitest, native HTML video.

**Spec:** User request of 2026-10-12: make the public walkthrough “proper sleek unique clean professional”; remove the AI-slop visual treatment. The supplied video must remain in place. Do not inspect the supplied screenshot again.

## Global Constraints

- Preserve video source, poster, captions, `controls`, `playsInline`, `preload="metadata"`, keyboard focus, and the fictional-sample disclosure.
- Serve the fixed public walkthrough only at a same-origin `/media/probatepro-walkthrough.mp4` route; forward one valid byte range, return `Content-Disposition: inline`, and never turn the route into a generic remote URL proxy.
- Do not change sign-in, SEO/JSON-LD, legal language, internal routes, settings, estate records, court forms, document generation, APIs, or database behavior.
- Use one primary media boundary; no nested rounded cards, shadow stacks, decorative inset borders, or duration pills.
- Keep responsive one-column behavior and a visible focus state; hover movement only on fine-pointer devices; respect the existing reduced-motion rule.
- Use direct, non-marketing copy and do not add dependencies.

## Review Focus

- Desktop hero: the media stage must retain hierarchy without a card-within-card appearance.
- Mobile: header, duration, video, and caption must remain readable and un-clipped at 375px.
- Keyboard: the native video must receive focus and the stage focus treatment must remain visible.
- Captions: the existing Blob-backed 22-cue track must still load after the markup refactor.
- Regression boundary: existing public SEO metadata, FAQ content, sign-in actions, and media URLs must remain unchanged.
- Mobile delivery: iOS receives a same-origin `video/mp4` response with byte-range support and no attachment disposition.

---

### Task 1: Repair same-origin mobile video delivery

**Files:**
- Create: `server/publicWalkthroughRoute.ts`
- Create: `server/publicWalkthroughRoute.test.ts`
- Modify: `server/_core/index.ts:9-16, 170-176`
- Modify: `client/src/pages/Landing.tsx:24-26`
- Test: `client/src/pages/Landing.auth.test.tsx:103-115`

**Interfaces:**
- Produces: `registerPublicWalkthroughRoute(app: Express): void`, mounted before Vite/static handling at `GET|HEAD /media/probatepro-walkthrough.mp4`.
- Consumes: one hard-coded CDN source URL and an optional single `Range` header.

- [ ] **Step 1: Write failing route and landing-source regressions**

Assert a valid range returns 206 with `video/mp4`, `Accept-Ranges: bytes`, the upstream content range, and `Content-Disposition: inline`; assert the landing video points to `/media/probatepro-walkthrough.mp4`.

- [ ] **Step 2: Run tests to verify the delivery contract fails**

Run: `pnpm exec vitest run server/publicWalkthroughRoute.test.ts client/src/pages/Landing.auth.test.tsx --maxWorkers=1`

Expected: FAIL because no same-origin route exists and the landing still points directly to the attachment CDN.

- [ ] **Step 3: Implement the constrained range-aware route and mount it**

Forward only a single syntactically valid byte range to the fixed source, stream successful 200/206 upstream bodies with inline headers, preserve content length/range, and fail safely for invalid range or unavailable upstream. Do not accept a URL parameter or user-controlled storage key.

- [ ] **Step 4: Verify HTTP behavior and green regressions**

Run the focused tests and `curl` both a full request and `Range: bytes=0-1023` against the same-origin route.

### Task 2: Replace the generic walkthrough shell

**Files:**
- Modify: `client/src/pages/Landing.tsx:535-592`
- Test: `client/src/pages/Landing.auth.test.tsx:103-115`

**Interfaces:**
- Consumes: `WALKTHROUGH_VIDEO_SRC`, `WALKTHROUGH_POSTER_SRC`, `WALKTHROUGH_CAPTIONS_SRC` and the existing caption-Blob lifecycle.
- Produces: semantic `section > header + figure` markup using `landing-walkthrough-stage`, `landing-walkthrough-title`, `landing-walkthrough-duration`, and `landing-walkthrough-caption` hooks.

- [ ] **Step 1: Write the failing layout contract test**

Assert that the walkthrough keeps its current media accessibility contract and renders the direct heading `Working file overview`, the non-pill duration `02:54`, and the `landing-walkthrough-stage` root hook.

- [ ] **Step 2: Run the landing test to verify it fails**

Run: `pnpm exec vitest run client/src/pages/Landing.auth.test.tsx --maxWorkers=1`

Expected: FAIL because the existing generic title and frame hook remain.

- [ ] **Step 3: Implement the editorial markup**

Replace the padded outer card, duplicate inner frame, uppercase marketing eyebrow, duration pill, and colored-dot caption with an indexed header, direct title, inline time, one `figure`/video boundary, and a compact factual caption. Keep the native video element and all of its source/caption behavior unchanged.

- [ ] **Step 4: Run the landing test to verify it passes**

Run: `pnpm exec vitest run client/src/pages/Landing.auth.test.tsx --maxWorkers=1`

Expected: PASS.

### Task 3: Define the single-boundary visual system

**Files:**
- Modify: `client/src/index.css:218-279`
- Test: `client/src/pages/Landing.auth.test.tsx`

**Interfaces:**
- Consumes: the stage, title, duration, media, and caption hooks from Task 1.
- Produces: one restrained video edge, rule-led metadata, high-contrast focus handling, fine-pointer-only hover feedback, and responsive spacing.

- [ ] **Step 1: Implement CSS for the editorial media stage**

Remove the outer gradient card, inset pseudo-element, broad shadow stack, nested video rounding, and hover lift. Use a thin navy media boundary, flat white/near-white ground, a compact header rule, tabular duration, and a fine-pointer-only border-color/shadow change. Keep focus visible without changing video controls.

- [ ] **Step 2: Run focused UI and type validation**

Run: `pnpm exec vitest run client/src/pages/Landing.auth.test.tsx --maxWorkers=1 && pnpm check`

Expected: PASS.

### Task 4: Verify the refined public stage

**Files:**
- Modify: `docs/audits/public-walkthrough-stage-refinement.md`
- Modify: `todo.md`

**Interfaces:**
- Consumes: final public landing implementation.
- Produces: a concise scope and validation record.

- [ ] **Step 1: Visually inspect desktop and 375px screenshots**

Confirm the stage uses a single media boundary, the full media remains visible, and no horizontal overflow appears.

- [ ] **Step 2: Inspect browser media state**

Confirm controls, duration, keyboard focus, and 22 caption cues on the final page.

- [ ] **Step 3: Run full final verification**

Run: `pnpm test -- --maxWorkers=1`, `pnpm build`, `git diff --check`, and HTTP health probes for `/` and `/probatepro-walkthrough.vtt`.

Expected: full suite, build, whitespace check, and health probes pass.

- [ ] **Step 4: Record audit and tracker entry, then checkpoint**

Document that the change only refines the public walkthrough stage and preserves all media, legal, product, and internal-workflow behavior.

## Self-Review

The plan makes one narrow visual change with one component, one stylesheet region, and one existing test file. It retains the tested media interface and adds an explicit markup contract, while final browser checks cover the accessibility behavior a DOM unit test cannot prove. No independent backend, legal, or product subsystem is included.
