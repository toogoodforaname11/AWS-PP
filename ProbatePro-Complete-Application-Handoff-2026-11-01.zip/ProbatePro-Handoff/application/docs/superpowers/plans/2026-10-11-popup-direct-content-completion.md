# Direct document-content popup completion implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use native implementation task-by-task with a focused regression cycle before each checkpoint.

**Goal:** Replace all remaining direct-document-content popup redirects in P9, P10, P11, P16, P44, P45, and P46 with honest in-popup completion controls.

**Architecture:** Keep `PreGenerateDialog` as the shared interaction surface and extend its typed apply payload only where needed. Render-context details such as deponent choice and signature date remain transient pending-action values; contact, delivery, applicant, and distribution facts use their existing canonical mutations and a re-check. `server/docgen.ts` remains the single source for DOCX and preview output; no renderer wording or geometry changes are permitted.

**Tech Stack:** React 19, TypeScript, tRPC 11, Drizzle/TiDB MySQL, Vitest, DOCX generation.

**Spec:** `docs/SPEC-popup-direct-content-completion.md`

## Global Constraints

- Preserve official court-form wording and all DOCX/preview layout, indentation, selected-only alternatives, signature geometry, and page flow.
- Never fabricate legal facts or default pending signing/delivery facts.
- Add a regression first, run it red, make it green, and then run the owning focused suite.
- Keep P9 attachment/order/dispensation evidence, generic readiness, and other non-rendered workflow facts outside popup completion.
- Maintain canonical write/re-check behavior for Contacts, Deliveries, applicant records, and distribution data.

## Review Focus

1. **Render-context propagation:** date/deponent/delivery selection must reach preflight, preview, download, generate, and generated-document snapshots without becoming an estate default.
2. **Canonical write sequencing:** delivery/contact/distribution edits must complete and invalidate cached data before re-check; failures retain the popup’s entered values.
3. **Authority boundary:** P9/P46 recipient and PGT controls must be server-derived from eligible canonical records, never free-text substitutes that create false delivery proof.
4. **Document parity:** every direct control must be tested against both DOCX-extracted text and preview sections where it alters visible form content.
5. **No scope leakage:** non-content prerequisites remain warnings/workflow actions, not controls that purport to fill court-form facts.

---

### Task 1: Shared pending form-detail context

**Files:**
- Modify: `client/src/components/PreGenerateDialog.tsx`
- Modify: `client/src/pages/EstateDetail.tsx`
- Modify: `server/routers.ts`
- Test: `client/src/components/PreGenerateDialog.test.tsx`
- Test: focused form-detail/router tests already covering generation context

**Interfaces:**
- Produces a typed popup apply payload for pending `selectedContactId`, `deliveryId`, `signatureDate`, and form-local transient values.
- Preserves existing `formOverrides` as a separate channel for legitimate estate-form values.

- [ ] **Step 1: Add focused regression cases for an in-popup signature date and selected deponent/target handoff.**
- [ ] **Step 2: Run the new regressions and confirm the current redirect-only behavior fails them.**
- [ ] **Step 3: Add the smallest typed pending-context payload and apply/re-check plumbing without changing document renderers.**
- [ ] **Step 4: Re-run the focused context tests and inspect generated request inputs.**

### Task 2: P11, P16, and P45 selected-affiant completion

**Files:**
- Modify: `client/src/components/PreGenerateDialog.tsx`
- Modify: `client/src/pages/EstateDetail.tsx`
- Test: `client/src/components/PreGenerateDialog.test.tsx`
- Test: existing P11/P16/P45 docgen and page-flow tests

**Interfaces:**
- Consumes Task 1’s pending deponent/date context.
- Uses existing canonical Contact/Settings updates for printed identity, address, postal code, and occupation/title.

- [ ] **Step 1: Add one failing direct-editor regression per P11, P16, and P45 missing-affiant gap.**
- [ ] **Step 2: Implement shared selected-affiant contact editor bindings, with organization and Settings-lawyer cases mapped to their actual consumers.**
- [ ] **Step 3: Add P11 jurat-city completion through the existing estate update path.**
- [ ] **Step 4: Run form-specific DOCX/preview parity regressions plus the dialog suite.**

### Task 3: P10 deponent/date and distribution completion

**Files:**
- Modify: `client/src/components/PreGenerateDialog.tsx`
- Modify: `client/src/pages/EstateDetail.tsx`
- Modify only if required for typed context: `server/routers.ts`
- Test: `client/src/components/PreGenerateDialog.test.tsx`
- Test: `server/p10-distribution.test.ts` and P10 DOCX/preview suites

**Interfaces:**
- Consumes Task 1’s pending deponent/date context.
- Reuses canonical distribution mutations/calculation; no synthetic distribution override is introduced.

- [ ] **Step 1: Add failing popup tests for P10 deponent, actual signing date, and distribution action paths.**
- [ ] **Step 2: Implement P10 applying-applicant selection and date controls.**
- [ ] **Step 3: Embed or reuse the existing distribution correction surface rather than duplicating WESA/will logic.**
- [ ] **Step 4: Verify testate and intestate/partial-intestate recalculation, plus DOCX/preview distribution parity.**

### Task 4: P44 and P46 direct signer/target completion

**Files:**
- Modify: `client/src/components/PreGenerateDialog.tsx`
- Modify: `client/src/pages/EstateDetail.tsx`
- Modify: `server/routers.ts` only for a narrow P46 delivery-recipient patch if no existing mutation supports it
- Test: `client/src/pages/EstateDetail.fix-applicability.test.tsx`
- Test: `client/src/components/PreGenerateDialog.test.tsx`
- Test: existing P44/P46 router and document tests

**Interfaces:**
- P44 uses pending signature detail and canonical applying applicant facts.
- P46 carries a canonical eligible `deliveryId` plus signing date; correction writes only the selected delivery row.

- [ ] **Step 1: Add failing tests that P44/P46 direct-content gaps have no Forms/Contacts redirect.**
- [ ] **Step 2: Implement P44 signature date and canonical applying-applicant completion without changing its lawyer/applicant caption logic.**
- [ ] **Step 3: Implement P46 eligible delivery selection, selected-row name/address correction, and signing date.**
- [ ] **Step 4: Verify P44 and P46 DOCX/preview output and canonical target/deponent snapshots.**

### Task 5: P9 canonical delivery completion

**Files:**
- Modify: `client/src/components/PreGenerateDialog.tsx`
- Modify: `client/src/pages/EstateDetail.tsx`
- Modify: `server/routers.ts` only for typed delivery/P46 apply support or server-issued target descriptors
- Test: `client/src/components/PreGenerateDialog.test.tsx`
- Test: `server/p9-delivery-proof.routes.test.ts`
- Test: `server/docgen*P9*` suites and delivery UI tests

**Interfaces:**
- Extends popup row edits with typed canonical delivery creation/update and P46 outcome edits.
- Uses authoritative recipient targets returned by server data; PGT classification remains linked-contact based.

- [ ] **Step 1: Add a failing P9 popup regression for actual ordinary/personal/electronic delivery facts and no redirect.**
- [ ] **Step 2: Implement a compact canonical delivery composer and per-row correction cards.**
- [ ] **Step 3: Add represented-recipient, PGT, acknowledgement, registered-mail correction, and P46-outcome controls only when server predicates expose the applicable row.**
- [ ] **Step 4: Run P9 route and DOCX/preview parity tests proving no delivery/date/acknowledgement is invented.**

### Task 6: Cross-form audit and release validation

**Files:**
- Modify: `docs/audits/popup-direct-content-completion.md`
- Modify: `todo.md`
- Test: all suites above plus full project suite

- [ ] **Step 1: Audit every remaining `Go to Forms` / `Go to Contacts` path in `PreGenerateDialog` and classify it as either direct content now handled or a deliberate non-content exception.**
- [ ] **Step 2: Add regressions preventing the scoped forms’ handled IDs from regressing to redirect-only controls.**
- [ ] **Step 3: Run focused suites, `pnpm check`, serial full tests, `pnpm build`, and `git diff --check`.**
- [ ] **Step 4: Record the final scope, exclusions, and verification evidence in the audit/tracker; checkpoint only after fresh passing output.**

## Self-review

- **Spec coverage:** Tasks 1–5 cover every audited direct-content gap in scope; Task 6 verifies no equivalent redirect remains and documents intentional exclusions.
- **Type consistency:** Task 1 is the sole producer of new pending action fields; later tasks consume it rather than introducing disconnected per-form payloads.
- **Scope discipline:** canonical delivery/contact/distribution data is explicitly separate from ephemeral signing/deponent context, and non-content evidence remains excluded.
- **Review focus coverage:** Task 1 covers propagation; Tasks 2–5 cover canonical writes and authority boundaries; every task includes DOCX/preview parity, with Task 6 enforcing final audit coverage.
