# Client Intake False Conflict Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Prevent an immediately subsequent client-intake application from using an already superseded estate revision after a successful partial application.

**Architecture:** Keep the existing database revision check unchanged. `ClientIntakeReview` will hold the latest confirmed revision returned by the apply/undo mutations, reconcile it when its parent receives a newer estate revision, and use that local confirmed token for the next mutation. This removes only the client-side false conflict window; a real external edit remains a server-side conflict.

**Tech Stack:** React 19, TypeScript, tRPC 11, Vitest, Drizzle/TiDB.

**Spec:** User report: applying client facts quickly produces the incorrect “changed while reviewing” warning; each defect is a separate task.

## Global Constraints

- Preserve existing owner scoping, submission state protection, revision checks, undo safety, and application selection logic.
- Do not weaken server-side optimistic concurrency or convert a real conflict into an overwrite.
- Do not modify estate data, court forms, document output, legal wording, or client intake field structure.

## Review Focus

- A successful partial apply immediately followed by a second apply must use the returned revision before any query refetch settles.
- A later parent-provided estate revision must replace the local token.
- A genuine server conflict remains visible and still refreshes the scoped review list.
- Undo also advances the local token for a following operation.
- Mutation results lacking a valid revision must not replace the current token.

---

### Task 1: Confirmed revision token in review UI

**Files:**
- Modify: `client/src/components/ClientIntakeReview.tsx`
- Test: `client/src/components/ClientIntakeReview.test.tsx`

**Interfaces:**
- Consumes: `approve` and `undoLastApplication` mutation results `{ revision: number }`.
- Produces: apply/undo mutation input with the most recently confirmed estate revision.

- [ ] **Step 1: Write the failing immediate-follow-up regression**

Add a component test that calls the approval success handler with `{ revision: 5 }` after an application started at revision `4`, then triggers the next application before query mocks change; expect `expectedRevision: 5`.

- [ ] **Step 2: Run the focused test to verify it fails**

Run: `pnpm exec vitest run client/src/components/ClientIntakeReview.test.tsx --maxWorkers=1`

Expected: the second mutation uses stale revision `4`.

- [ ] **Step 3: Implement a local confirmed revision token**

Initialize from the `revision` prop, synchronize only when the prop changes, advance it from successful apply/undo results, and use it in both mutation inputs.

- [ ] **Step 4: Run focused tests and typecheck**

Run: `pnpm exec vitest run client/src/components/ClientIntakeReview.test.tsx --maxWorkers=1 && pnpm check`

Expected: PASS.

### Task 2: Release verification

**Files:**
- Create: `docs/audits/client-intake-false-conflict.md`
- Modify: `todo.md`

- [ ] **Step 1: Run full validation**

Run focused component tests, `pnpm check`, `pnpm test -- --maxWorkers=1`, `pnpm build`, `git diff --check`, and local/public health probes.

- [ ] **Step 2: Record validated scope**

Document the false-conflict root cause, the preserved server guard, test evidence, and the separate remaining portal defects.
