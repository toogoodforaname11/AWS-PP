# Hybrid Steps 0–3 Remediation Implementation Plan

**Goal:** Resolve the reviewed storage, generation-provenance, delivery and UI failures, one task at a time, without changing any court-document wording, formatting, rendering or legal/form-selection logic.

**Architecture:** Preserve the existing application and its two distinct STS provider/client paths. Repair application authorization, atomic persistence/audit and input-bound ephemeral delivery around the frozen renderers. Use only fictional local fixtures and mocked external services. Keep all changes uncommitted for Nick's review.

**Tech Stack:** Existing TypeScript/React/Express/tRPC, Drizzle/MySQL, Vitest, DOCX/PDF renderers, existing pnpm lockfile and configuration.

**Spec:** Nick's 2026-10-21 goal-loop directive and attached 20-task list. Four previously reviewed output-behavior changes are approved: newest P9 selection for P2, current-P1/P9 Exhibit A re-render, P8 primary-affidavit override, and package/exhibit reconstruction. Preserve them; this is NOT approval for new wording/layout/legal changes.

## Global constraints

- NO touching legal document format or wording, citations, headings, paragraph/section/field order, geometry, tables, page breaks, checkbox/jurat/signature layout, typography, DOCX/PDF/HTML rendering or legal/form-selection logic.
- Do not edit `server/docgen.ts`, other renderers, prescribed text, official captures, `shared/types.ts`, form-selection rules or the document schema. Preserve captured legal authorities and RULES.md, including every AWAITING-NICK deferral and existing approved exception.
- No stage, commit, reset, stash, push, merge, branch switch, deploy, publish, checkpoint or production-worktree operation.
- No production database, storage, client records, accounts, AWS/vault credentials or live policy inspection. No migration, seed or external-service writes. Task 19 requires separate authorization and cannot be silently marked resolved.
- Continue on `security/hybrid-vault-review`, HEAD `db0d7e9161bc3899b75858fab58bce54e3d5247a`, selected local workspace only.
- All verification inputs are fictional. Strip inherited application credentials; never print secret-like values. No silent gate bypass, snapshot acceptance, skipped failing regression or broad dependency upgrade.
- Task 4 below means queue item 4, NOT hybrid Step 4. Hybrid Step 4 remains out of scope.
- One active implementation task at a time. Before edits record connected features; after edits run affected tests, full available gates and render/real-UI checks appropriate to those connections. Do not claim user-ready on unit tests alone.

## Evidence and project structure

- `.work/hybrid-remediation/baseline.json`: initial branch/HEAD/index and 84 original changed-file hashes plus protected-source hashes.
- `.work/hybrid-remediation/baseline.diff` and `baseline-source/`: immutable pre-remediation application-code evidence, not production data.
- `.work/hybrid-remediation/`: task-specific execution logs, fictional rendered fixtures and verification helpers. Not part of the application patch.
- `server/db.ts`, `server/documentReplacement.ts`, `server/affidavitHistory.ts`: transactional replacement/provenance and safe audit contracts.
- `server/storage.ts`, `server/storageRegistry.ts`, `server/_core/storageProxy.ts`: private-object authorization and legacy routing.
- `server/downloadRoute.ts`, `server/downloadExportsRoute.ts`, `server/_core/deliveryRouter.ts`, `shared/postDelivery.ts`: delivery identity, body validation, audit and resource limits.
- `client/src/lib/utils.ts`, `client/src/pages/EstateDetail.tsx`, `client/src/pages/Home.tsx`: authenticated delivery, preview lifecycle and truthful feedback.
- `server/failureReporting.ts`, `server/notesExportRoute.ts`: safe error mapping/reporting and notes delivery boundaries; PDF drawing/text stays frozen.

## Review focus

1. Simultaneous single/bulk generation must not leave partial/duplicate current records or missing required audit.
2. Retry, changed estate/contact/settings/attachment facts and changed overrides must never silently change a bound download's meaning.
3. Cookie-blocked authenticated users must get an actual attachment or visible retryable error without credentials in URLs.
4. Cancellation, disconnects, oversize responses and audit/report failures must release resources and remain truthful.
5. Legacy private access must preserve valid ownership and retained historical files without public-key or manifest bypass.

## Queue and current state

Original task numbers are retained. Dependency-first execution order: **1 → 2 → 3 → 16 → 4 → 5 → 14 → 6 → 7 → 8 → 15 → 9 → 13 → 10 → 11 → 12 → 17 → 18 → 19 → 20**. If a task exposes a prerequisite, record the dependency before changing the order. Each task gets its own evidence entry and acceptance decision.

- [x] **1 — Complete raw diff coverage.** Read all remaining raw diff lines in `server/storage-s3.test.ts` and `server/storage.test.ts`; current inventory is still 68 modified + 16 original untracked project files, plus two tooling receipts. No new production-code finding from those test-diff tails. Preserve baseline fingerprints. Connected features: review completeness only; no application edit.
- [x] **2 — Restore reproducible local tests.** Reproduce config loading, identify the execution-permission cause or other root cause, restore only the affected invocation/tool, then run the relevant tests. Connected: all serial Vitest collection, mock isolation, TypeScript/build gates. No application or prescribed-text edits.
- [x] **3 — Resolve private legacy/unmanifested reads.** Storage registry/facade/proxy plus the narrowly recorded trusted read-context plumbing are verified. Preserve approved two-role paths and legitimate retained reads. Cover public exact assets, private keys, ownership/category/state/disposition mismatches, missing rows and both providers. Final acceptance evidence: `.work/hybrid-remediation/task03/acceptance.md`.
- [x] **16 — Strengthen replacement estate consistency.** Exact locked/inserted/affected estate checks and entry snapshots passed independent review, 146 focused tests, 13 native MySQL cases, fresh full gates (5,571 root and 205 chatbot tests), all 26 renderer comparisons, and actual P1 UI replacement/download with unchanged Word parts and two pixel-identical pages. Evidence: `.work/hybrid-remediation/task16/acceptance.md`. Bulk/audit fixes remain separate Tasks 4/5.
- [x] **4 — Atomic bulk replacement.** Complete-set transactions, snapshot/conflict handling and the connected P8 metadata mismatch are independently reviewed and verified by 18 native MySQL scenarios, fresh full gates (5,668 root and 205 chatbot tests), 26 frozen renders and actual UI bulk/M1 delivery. All 17 comparable Word-rendered pages are pixel-identical; no generated bytes are retained by the application. Evidence: `.work/hybrid-remediation/task04/acceptance.md`. Missing-data warnings remain non-blocking; later audit/delivery tasks remain open.
- [x] **5 — Coherent generation audit.** Required generation audits, activities and provenance commit coherently; optional estate timeline remains best-effort. Independent complete-delta review approved; fresh full gates passed (5,989 root and 205 chatbot tests), 22 actual MySQL scenarios passed, all five real-UI failure/retry paths and optional timeline passed, all 26 frozen renders passed, and 12 actual UI DOCX files / 21 Word-rendered pages are unchanged. No generated application bytes retained. Evidence: `.work/hybrid-remediation/task05/acceptance.md`. Stop here per Nick's 17:46 instruction; no next task begins.
- [ ] **14 — Safe refusal/error boundary.** Preserve approved actionable messages through typed/explicit mappings; never forward arbitrary storage/query detail. Connected: generation, delivery, bulk/package, notes and staff reporting.
- [ ] **6 — Form input binding.** Bind authorized generation and delivery to render-affecting input/state without storing generated bytes or changing renderer behavior. Cover tamper, retries, ownership, expiry and data drift.
- [ ] **7 — Exhibit/format binding.** Preserve approved current-P1 re-render semantics, but reject stale or inconsistent P1 identity/context/container. Cover P9 Exhibit A, P1 attachments, P34 ZIP and ordinary DOCX.
- [ ] **8 — Export preparation binding.** Enforce a coherent generation/preparation/delivery contract for letters, all-P8, package and estate archive; stale/direct/tampered POST must not bypass provenance.
- [x] **15 — Export reporting.** Honor reportable safe failures once, preserve original error when reporting fails. Connected: unreadable attachments, generation refusal and staff reporting. **Closed/done by Nick's explicit decision, 2026-10-23 12:06 local; real-browser evidence remains outstanding and Word/pixels remain user-deferred-not-passed. This is user-authorized closure, not a new verification or SHIP claim; see the appended disposition.**
- [x] **9 — Cookie-independent delivery.** Authenticated fetch/attachment handling supports existing Bearer fallback without tokens in URLs/body fields. Preserve same-origin CSRF and native cookie sessions. **Accepted/done by Nick's decision, 2026-10-23 19:06 PDT, with the limitations and deferrals recorded in the appended disposition. This is remediation tracking, not a SHIP or production-readiness approval.**
- [x] **13 — Truthful UI outcomes.** Await observed HTTP success and handoff, show refusal/retry, never claim recipient receipt. Connected: FormsTab single/bulk/package, Home export, P46, notes and preflight state. **Done within its approved scope by Nick's decision, 2026-10-24 17:48 PDT, with the limitations and deferrals recorded in the appended disposition. This is remediation tracking, not a SHIP or production-readiness approval.**
- [x] **10 — Notes audit/IDOR.** Gate bytes on required audit and track transport outcomes and foreign-owner refusal, without changing PDF text/drawing commands. **Accepted/done by Nick's decision, 2026-10-25 08:10 PDT, with the limitations and deferrals recorded in the appended disposition. This is remediation tracking, not a SHIP or production-readiness approval.**
- [x] **11 — Notes resource bounds.** Enforce rate/concurrency/byte budgets and cleanup, preserve PDF output for in-budget inputs. Cover failure/disconnect/retry. **Accepted/done by Nick's decision, 2026-10-25 18:08 PDT, with the limitations and deferrals recorded in the appended disposition. This is remediation tracking, not a SHIP or production-readiness approval.**
- [x] **12 — Preview lifecycle.** Cancel superseded/closed/unmounted requests and bound response bytes; revoke object URLs. Preserve rendered preview wording/markup/layout. **Accepted by Nick with known limitations: accepted/done by Nick's decision, 2026-10-27 13:43 PDT (receipt), with the deferrals recorded in the appended disposition. This is remediation tracking, not a SHIP, deployment or production-security approval.**
- [x] **17 — Accurate documentation.** Update only non-authoritative storage/delivery docs to match implemented guarantees and explicit limitations. **Accepted within its documentation-only scope by Nick's decision, 2026-10-28 07:41 PDT, with the limitations and deferrals recorded in the appended disposition. This is remediation tracking, not a SHIP, deployment, security or compliance approval.**
- [x] **18 — Reverify safeguards.** Role split, purge chokepoint, KMS checks, production fail-closed, tenancy/manifest, CSRF and generated-byte non-retention; full serial gates and protected-output checks. **Accepted by Nick's decision, 2026-10-28 13:16 PDT (reply "accept"), within its verification-only scope, with the limitations, not-exercised items and new report-only observations recorded in the appended disposition. This is remediation tracking, not a SHIP, deployment, security or compliance approval.**
- [ ] **19 — Infrastructure policy evidence.** BLOCKED pending separate AWS/policy authorization or supplied policy evidence; no AWS access authorized by this queue. Do not substitute mocks for deployed policy proof.
- [ ] **20 — Final Steps 0–3 review.** Complete diff re-review, connected-feature matrix, full gates, real renderer/preview/UI evidence and SHIP/STILL-BLOCKED determination. Leave all Git changes uncommitted; no hybrid Step 4.

## Task evidence

### Task 1

- 2026-10-21: branch and HEAD unchanged from review; no nested AGENTS.md/CLAUDE.md found in scoped source tree; root AGENTS.md absent (normal).
- Read remaining raw storage-S3 test diff lines 400–1006 and storage facade test diff lines 80–262 completely.
- Snapshot captured 84 original changed project files; two existing `.manus/mcp-results/` receipts excluded from application inventory.

### Task 2 — active

- Reproduced existing isolated namespace test: exit 1 before collection. esbuild cannot read `../..` and cannot resolve the absolute Vitest config path under restricted execution.
- Root contains `.env.example` only; no runtime `.env` was read. Test subprocess inherited only OS execution paths and explicit test-mode flags.
- No dependency, project configuration, legal source or application edit made to mask the environment error.

### Task 2 — test execution verified, baseline build pending

The same unchanged namespace suite passes 16/16 using the tool's explicit execution-approval route. Root TypeScript passed (`tsc --noEmit --incremental false`); the full offline serial suite passed **320 files / 5,120 tests**, with the separately live `server/storage.live-uat.test.ts` excluded deliberately. Root test duration: 781.22 seconds. No dependency/configuration/permission/renderer workaround was required. Every future Vitest/esbuild command must use that approved execution route and scrubbed environment, not broad ACL changes. Logs: `.work/hybrid-remediation/gates/baseline-root/`.

The baseline gate runner checks protected legal-source hashes before and after each command, never invokes migrations, and logs only disposable fictional test settings with signing/encryption values redacted. Root and chatbot type checks and the repository's existing production build remain the compilation gates; the installed project-local pnpm is 10.18.0, while packageManager remains unchanged at its original pin. No global tool installation or package-manager update is authorized.

### Task 2 — complete

Root and chatbot type checks passed. Root serial tests: **320 files / 5,120 tests**. Chatbot serial tests: **15 files / 205 tests** in 11.35 seconds, using exclusively dedicated test-database paths verified absent before execution. The unchanged `pnpm run build` script passed with production compilation mode in 27.534 seconds; an unsupported argument in the new local harness was removed before the successful retry. Package manifests/lockfile and all protected sources are unchanged. Final build log: `.work/hybrid-remediation/gates/baseline-build-retry/build.log`. The 84 original changed-file hashes all match the prior review's initial capture; no intervening original-source changes.

### Task 3 — active; pre-edit connected-feature list

Affected boundaries: production startup reconciliation; authenticated storage redirects; private exact-byte reads; current and retained legacy/approved-provider manifest records; pending deletion and disposition refusal; exact public-asset allowlist; account/estate/category/retention identity. Consumers to preserve: uploaded wills/codicils/foreign grants, citation and legal evidence, priority-consent/dispensation files, firm letterheads, notes attachments, historical generated files and estate export, P1/P34 attachments, approved P9 Exhibit A and package reconstruction. Two role providers/clients, KMS checks, legal builders, form selection, and new generated-byte non-retention stay untouched.

Required evidence: public assets continue working without private manifest assumptions; valid manifested legacy and vault records remain readable; private missing/corrupt/mismatched/deletion-bound records refuse before provider access; startup never merely warns past private ownership/deletion drift; existing per-user/estate manifest checks remain enforced. Read-only independent review follows focused regressions, then parent-run full gates and connected route/render verification before marking resolved.

### Task 3 — implementation written; acceptance pending

The changed-file regressions passed **2 files / 167 tests** in 3.94 seconds, and root `tsc --noEmit --incremental false` passed. Protected legal-source hashes remained unchanged before and after. Evidence: `.work/hybrid-remediation/gates/task03-focused-v1/`. The full offline serial suite, companion gates, production build and 26-form renderer comparison are running under `task03-full-v1`; their results are not yet claimed. An independent read-only review is also in progress.

Application edits are limited to `server/storageRegistry.ts`, `server/storage.ts` and their test files. No renderer, legal wording/format/selection logic, schema, STS/KMS/purge provider or UI implementation was edited. The task remains open until full gates, independent review and connected route/UI proof finish.

The local real-UI fixture now has 28 tables in a newly created loopback-only MySQL instance. Its unchanged wide estate table requires 64 KiB InnoDB pages. Four non-document intake payload columns use the explicitly documented test-only TEXT + identical character-bound CHECK representation; application schema and document table definitions are unchanged. See `.work/hybrid-remediation/verification-runtime.md`. This does not establish live-schema or deployed-policy compatibility, and does not clear Task 19.

### Task 3 — recovered gates, UI and independent review still open

2026-10-21 10:35 local: connection recovered on the same local branch and HEAD. The two original fictional services were still running; their executable/port identities and UI health were verified before reuse. No duplicate services were started. The recovered complete root run passed **320 files / 5,226 tests** (`task03-full-v1`). A fresh completion run (`task03-completion-v2`) passed root and chatbot typechecks, **15 chatbot files / 205 tests**, the unchanged production build, and all **26 real DOCX/XML and structured-preview comparisons**. No frozen legal source differs. The integrity receipt `task03/resume-20261021-1019.json` confirms that only the two storage modules and their two tests differ from the pre-remediation source copies.

The previous independent review failed without a deliverable; it is not a pass. A new read-only Task 3 review is running. The live fictional UI's existing private will View control successfully passed the real authenticated storage proxy and displayed the exact one-page fictional PDF. P1 preview/generation verification is still pending. The fixture was found to have two applying contacts marked primary; this is test-input setup, not a storage regression. Through the existing UI, Morgan Example's fictional status is being changed to reserved rights, leaving Jane Smith as the applying primary, without changing executor ranking or any application/legal rule. No Task 3 acceptance or later-task start is claimed.

### Task 3 — review correction loop (still the only active implementation task)

The independent review at `task03/review-recovery.md` found H1 (a destructive-state/provider-dispatch race), M1 (all-tenant query amplification), and M2 (a valid will refused because of unrelated malformed codicil metadata). None is accepted or waived. The reviewed four-file pass is preserved at `task03/pass1-source/server/`.

**Measured/reproduced before further source edits:** `task03/pass1-route-measurements.json` records three serial groups of 20 actual authenticated private-proxy requests against the task-owned fictional MySQL/UI fixture. Every group used exactly **15 SELECTs per request**, including authentication/authorization. Normal access returned 307, then the exact 1,311-byte fictional PDF returned 200. No session, provider or database credentials appear in the receipt. Unauthenticated, case-alias and unmanifested requests were refused (401/404/404), without redirects. Temporarily changing only this fixture estate's codicil list to malformed JSON changed its valid will response to **502**; the original list was restored in a guarded `finally` block and the valid read worked again. This reproduces M2 through the real route; it is not a production-performance measurement.

**Connected features to recheck before accepting this correction:** authenticated private proxy; public exact allowlist and near misses; runtime/platform/vault dispatch; estate disposition and firm-asset detachment ordering; current and retained files; account/estate namespaces; will, foreign-grant, codicil and legal-order upload/save/read; priority consent and dispensation-order reads; P1/ancillary/curative attachments; P34 evidence; stored-P1/P9 and package reconstruction; historical versions and estate export; letterhead/settings resolution; note/support assets; transient reads/expiry; and startup/repair/lifecycle safety. All 14 connections in the independent review matrix remain required, not just the happy-path will.

**Permitted direction and scope:** fix final manifest validation and provider dispatch under correctly ordered estate-then-manifest protection; keep provider work/critical sections bounded. Replace per-file all-tenant reference enumeration with a bounded runtime plan that uses authenticated caller ownership and expected estate/category where necessary, while retaining strict global startup reconciliation. An owner filter alone must not hide a conflicting requested owner, estate or category. There must be no cross-request authorization cache or missing-context fallback that silently permits private reads. Where necessary, the storage API's trusted read context may be threaded through **non-rendering calls only** in `server/_core/storageProxy.ts`, `server/routers.ts`, `server/documentAssets.ts`, `server/estateExport.ts`, `server/downloadRoute.ts`, and `server/downloadExportsRoute.ts`, plus focused tests and a small storage-only helper. These are dependency repairs within Task 3, not new legal behavior or a start on another queue item. Prefer explicit context over ambient security state. Pure attachment selectors, package members/names/order, all four approved output behaviors, form inputs, citations, prescribed text, ZIP/DOCX/PDF/preview builders and every frozen source remain unchanged. No schema/index migration, provider/STS/KMS edit, UI feature, session/authentication redesign or Step 4 work is authorized.

Required regression evidence: both controlled read/destruction orderings, all provider mocks untouched on refusals, bounded runtime query/results and a many-object case, valid will plus unrelated malformed codicils/invalid sibling keys, and a genuine conflicting requested-category/owner control. Follow with fresh connected/full gates, exact frozen-render comparisons, a repeat of the real-route probe, real-UI acceptance and another independent review. Task 3 remains open until these agree.

### Task 3 — second correction verified at focused scope; database compatibility still open

Parent gate `task03-r2-parent-complete` passed **28 files / 762 tests** and root typecheck. Frozen legal-source hashes remained unchanged. The complete implementation/evidence handoff is `task03/followup-implementation.md`. Real UI replacement on the still-running older fixture produced one active and one retained will; both authenticated reads delivered the same verified 1,311-byte fictional PDF. No generated bytes were retained in application storage. That old service is not evidence for the newly loaded source.

**Additional pre-edit dependency:** `task03/database-lock-compatibility.md` records that the new account shared lock is not a portable TiDB guarantee, and that provider admission requires effective pessimistic transaction semantics. The repository explicitly supports TiDB; the owned test database is MySQL/InnoDB. Any correction must stay inside the current storage-only boundary and its tests, use effective supported locking or fail closed, preserve legitimate concurrent reads, bound contention/critical sections, never retry provider work already admitted, and not enable no-op behavior or change database globals/schema/configuration. Connected features are exactly the complete list above, now including the engine/transaction-mode and same-account concurrent-read paths. No AWAITING-NICK item or deployed-policy proof is silently resolved.

### Task 3 — actual InnoDB estate ordering established for R2

`task03/task03-r2-v2-real-locks.json` records the actual `withReadableStoredObjects` and `disposeEstate` functions against the owned MySQL 8.4.11 fixture with two connections and an observed InnoDB lock wait. When disposition held the estate lock and waited for its manifest row, the read refused and made zero provider callbacks; after destructive commit, it again refused. When the read admitted its callback first, disposition committed while that callback remained pending; only afterward was callback completion released. Thus the tested SQL locks did not cover slow provider completion. All test records were newly created fictional rows, and the callback made **zero provider/AWS calls**. An initial fixture-script insert referenced a nonexistent estate `updatedAt` column; it failed before row creation, was diagnosed from the unchanged schema, and corrected only in the QA harness. The successful two-case harness is preserved as `task03/verify-real-locks.r2.ts`.

This evidence is specifically for the recorded R2 source hashes and local InnoDB. It does not resolve the TiDB concern or replace final reruns after the current correction. The parent harness is being extended for actual firm detach and ordinary concurrent-read coverage. No later task or legal-output edit has started.

### Task 3 — owned-fixture query plans

`task03/task03-core-query-plans.json` records read-only EXPLAIN results on the small, owned MySQL fixture. Estate, manifest and account exact lookups used their primary keys; the contact estate lookup used `contacts_estate_id_idx`. The exact owner-unfiltered disposition lookup had **no usable estate index and a table-scan plan** (two fixture rows at measurement). Existing disposition indexes are primary `id`, `(userId, requestedAt)` and `state`. This confirms the reported residual limitation rather than hiding it or asserting a large-data/production latency guarantee. No schema or index was changed. Runtime returned-row/query-group bounds remain distinct from physical rows examined.

### Task 3 — native metadata integration failure; no acceptance

The R3 focused mocks/typecheck passed, but the parent real-engine positive read did **not** reach provider admission. The unchanged native MySQL metadata query returns the unaliased column as uppercase `ENGINE`, while the new validator expects lowercase `engine`. All three actual control-table rows reproduce this. A read-only comparison using an explicit `engine AS engine` alias returns the exact expected lowercase field. Evidence: `task03/r3-native-metadata.json`; failed real-engine label `task03-r3`. Thus negative-refusal tests alone were not sufficient: legitimate MySQL reads were universally refused.

**Pre-edit repair scope:** only the exact metadata-column alias in `server/storageRegistry.ts`, plus a fake-transport regression that reproduces MySQL's native unaliased field label. All connected features listed for Task 3 remain in scope for the same fresh gates, real-lock ordering tests, real UI and render checks. No lock/profile/authorization weakening, schema/configuration/dependency/renderer/wording change is authorized by this correction. The R3 independent review is in progress; final acceptance must use the corrected source hash and disclose any review-hash difference. The separate Word QA harness also exposed an unsupported application-level Hwnd lookup; it has not rendered anything yet and has not changed any DOCX.

### Task 3 — native-driver correction and broader real-engine proof

The installed-driver transport regression now reproduces native MySQL's uppercase unaliased `ENGINE` property. `task03-r3-native-red` failed exactly **1 test / 85 passed** on the unchanged production statement. The production correction is the explicit `engine AS engine` alias; two exact test SQL expectations were aligned, without relaxing any validator or assertion. `task03-r3-native-green` then passed **3 files / 253 tests** and root typecheck, with all frozen sources unchanged.

`task03/task03-r3-v2-real-locks.json` then passed **five actual InnoDB scenarios**: disposition wins, read admission wins over disposition, firm detach wins, read admission wins over firm detach, and two legitimate concurrent same-account reads. Destructive winners admitted zero provider callbacks. Previously admitted callbacks finished only after the destructive transaction committed, proving SQL protection was released before slow completion. Only synthetic rows and callbacks were used; **no provider/AWS calls** occurred. This remains local MySQL evidence, not deployed TiDB/policy proof.

The installed Microsoft Word renderer opened the existing **26 fictional baseline DOCX artifacts read-only** with macros and external-link updates disabled, exported **52 pages** to local QA PDFs, and verified every original DOCX hash unchanged. The P1 first attempt failed before export because Word lacks the assumed application-level Hwnd; the helper was corrected to verify ownership through the opened document window and to never quit an existing user process. PyMuPDF rasterization reports no text blocks outside physical page bounds across all 52 pages. The two P1 pages were directly visually inspected: readable content, intact continuation/signature blocks, no clipping or visible overlap. This is rendering evidence, not a new legal-content or authority approval. Source render/preview equality and real-UI acceptance still require the current full run.

Fresh full root/chatbot/typecheck/build/render gates are running as `task03-r3-full`. The independent R3 review is still pending; its findings/source hash must be reconciled with the minimal native-driver correction. The fictional UI is being restarted on the corrected source. No later task has begun.

### Task 3 F1 — pre-edit boundary for the final independent-review finding

The complete R2/R3 independent review finished on the native-alias-corrected registry hash `131f0db76fb049136e3e7cbc3e7b521649ebd57a301de14183ac1a3f00126d27`. It found no additional blocking/high source defect and one medium gap: successfully parsed non-array codicil metadata checks the raw spelling, while invalid JSON checks decoded escapes. Escaped slashes, Unicode escapes or case aliases can therefore hide the same requested-key ambiguity.

**Allowed correction:** unify the already bounded malformed/non-array requested-key hint check, decode JSON escapes once, fold once, and retain the existing key/list/row limits. Change only `server/storageRegistry.ts` and its real-registry/facade test file. No new key decoding rules, legal selectors, source providers, form rules, document bytes, layout, schema or dependencies. Leading-slash and trailing-space/case aliases must still refuse when they concern the requested key.

**Connected features to recheck:** exact reads and presigning through approved and legacy providers (including platform-only legacy), P1's available will and unchanged attachment names/bytes when codicils are genuinely unrelated, relevant ambiguity refusal with zero calls to either provider, startup's separately strict reconciliation, scoped query bounds, destructive ordering and retry guards, retained files, all existing downstream P1/P9/P34/letterhead/package/archive/notes consumers. The 26-form output freeze and broader gate/real-UI requirements remain unchanged. Add both negative spelling/container variants and positive unrelated wrong-container variants without removing existing assertions.

The in-progress `task03-r3-full` run was explicitly stopped as superseded before this correction; it is not final green evidence. Fresh complete gates will run after F1 is corrected, followed by a bounded independent review of this final delta. No later queue item has begun.

### Task 3 — decoded spelling corrected; requested-key equivalence follow-up

R4 reproduced the actual escaped/case gap with **21 failing / 110 passing** focused cases before the correction. After the shared hint check, **3 files / 298 tests** and root typecheck passed with frozen sources unchanged. The final-source loopback probe refused all five relevant malformed-container cases with **zero provider calls**, preserved both unrelated positives, and restored the fictional field after every case. Current and retained uploads still delivered the exact 1,311-byte PDF. Three 20-request samples each used **14 SELECTs/request**; local medians were 12.11/9.75/9.61 ms and p95s 16.52/13.67/11.11 ms, not production latency claims. All five actual InnoDB race/concurrency cases passed on R4.

The independent R4 review confirms all original test lines remain and finds one connected medium baseline residual: a permitted requested/manifest key with trailing whitespace is compared untrimmed in the hint path, while the existing array/reference equivalence uses lower-case plus `trimEnd()`. This needs correction before acceptance. The production change will reuse that **existing folded requested-key set**, not trim provider keys, normalize new character classes, change selection or touch a renderer. Add bidirectional requested-key variants (canonical, trailing ordinary space, case plus space, nonbreaking trailing space) to negative and unrelated positive read/sign coverage; prove exact original provider keys still pass on positives. The entire previously recorded Task 3 connection list and every original assertion remain required.

R4 full gates were stopped as superseded; no final-green claim is made. Complete gates will restart only after this bounded follow-up is independently source-reviewed, avoiding another premature full run. Hybrid Step 4, queue item 16, legal changes and Task 19 infrastructure access remain unstarted.

### Task 3 — final source review approved; acceptance gates running

R5's expanded requested-key matrix reproduced **75 failures / 173 passes** before the one-line fix. The fix reuses `foldedKeys` exclusively for comparison; it never rewrites a provider key. The complete **28-file / 978-test connected suite** and root typecheck then passed, with frozen legal sources unchanged. The independent `task03/r5-review.md` approves the exact registry hash `012ea6d15705d3913eadf293daca901317280187fab92dbc50ed6274a8b9c585`, with no residual finding or source drift. It confirms 108 negative and 48 positive matrix cases and unchanged original assertions, including exact original provider arguments.

Fresh complete gates are now running as `task03-r5-full`, after source-review approval. The real-engine harness adds ASCII-space and NBSP requested-key scenarios. Its first new scenario identifier was 42 characters against the unchanged 36-character estate ID column, so that QA-only insert failed before that scenario's records were created; the helper now uses shorter identifiers and checks the limit. No application schema/code was changed for that harness error. Final real-engine, actual-UI and render acceptance remain pending; no later queue item has begun.

### Task 3 — accepted; overall patch still not shippable

Final full gates passed: **321 root files / 5,477 tests**, **15 chatbot files / 205 tests**, both no-emit typechecks, unchanged production build and **26 frozen DOCX/XML/preview comparisons**. Independent R5 source review approves the final delta with no residual finding. Seven actual InnoDB scenarios pass, including disposal/detach ordering, concurrent reads and both padded-key cases. Final-code HTTP probes preserve legitimate current/retained bytes and refuse a second synthetic account before provider work.

The real UI produced a P1 ZIP through Forms → Lawyer signing → Preview → DOCX → Download, with all preflight-required fields present. It contained the single 11,643-byte DOCX and the exact 1,311-byte current will. HTTP 200 and 13,244 ZIP bytes are captured intentionally under QA only; provider PUT count and generated metadata rows retaining bytes stayed zero. The actual delivered DOCX rendered read-only in Word into two pages, both visually checked, no text outside the page and original DOCX bytes unchanged. Complete scope/limitations and connection matrix: `.work/hybrid-remediation/task03/acceptance.md`.

### Task 16 — active; exact replacement scope, before edits

**Intent:** strengthen the exported `db.replaceCurrentDocuments` primitive so internal mismatches and SQL collation aliases cannot archive/delete one estate's records or insert a different estate's record. This is queue item 16, not hybrid Step 4.

**Files:** restrict production changes to the existing primitive and a small local guard in `server/db.ts`; extend `server/db.replaceCurrentDocuments.test.ts`. Preserve `documentsReplacedBy`, `replacementCandidateWhere`, `versionRowFor`, `sameIdSet`, the database schema, all legal selectors/renderers, providers, callers and the four approved output behaviors. Existing direct transaction tests and all original assertions remain.

**Connected features to recheck:** (1) single-form generation's pre-render snapshot and provenance commit; (2) ordinary form replacement; (3) P9 deponent/legacy-blank identity; (4) the unchanged primary-affidavit family and P34 target/legacy-citation replacement semantics; (5) version metadata, date/deponent/target and intentionally retained historical references; (6) same-key concurrent winner/conflict behavior, row-lock/read ordering, archive/delete/insert failure rollback and safe 409 classification; (7) post-commit reference activation must not run after refusal; (8) all current route consumers and their unchanged real UI/form output. Bulk atomicity and coherent generation audit remain Tasks 4/5, not implicitly fixed here.

**Boundary to implement/test:** require literal equality of requested estate, locked estate, inserted estate and each affected row's estate. Check the inserted row's form/deponent/optional target against the requested replacement key using existing absent-value semantics, never a new selector. Take a stable local snapshot of primitive arguments before awaited work so subsequent caller mutation cannot defeat checks. Keep legitimate empty-versus-absent optional defaults and unrelated rows valid; do not globally reject an unrelated SQL-overincluded form merely to satisfy an affected-row guard. Refuse mismatches before any archive/delete/insert with static non-sensitive errors. Preserve optimistic expected-ID comparison and all rollback/conflict handling.

**Verification:** write direct-primitive red regressions for mismatched inserted estate/key, collated locked estate, foreign/collated affected rows, foreign expected IDs and mutation after entry; positive guards retain existing branch semantics/defaults and exact data. Run focused tests and typecheck through the scrubbed harness, obtain independent source review, then fresh full gates/render comparisons. Parent will use only new fictional database rows for real collation/rollback controls and drive the real UI's valid P1 replacement/download again. The inherited graph server was checked and is unavailable; bounded source tracing is the fallback. No new legal facts, authority change, migration, production access or Git mutation is authorized.

### Task 16 — source approved; native checks passed; full/UI gates running

Only `server/db.ts` (+27/-7 within the primitive/local guard) and its direct transaction test changed. The independent reviewer found no actionable defect; every original assertion-bearing test block, selector/helper/caller, all 55 frozen files and the four approved behaviors remain unchanged. Red: 40 new failures / 83 passes before production edits. Final focused green: **123 primitive/candidate tests + 23 companion tests = 146 passed**, plus root typecheck.

Parent actual MySQL controls passed **13 scenarios** under the real `utf8mb4_0900_ai_ci` estate collation: inserted estate/form/deponent/target refusal, collated locked/affected identity refusal, foreign expected ID refusal, actual duplicate-insert rollback of archive/delete, valid SQL defaults, unrelated alias-row survival, stable entry snapshots, P9 legacy/other-deponent preservation, and overlapping same-snapshot generation with exactly one winner/one conflict. All 26 newly created fictional estates and their test rows were cleaned up; zero provider operations. Receipt `.work/hybrid-remediation/task16/task16-final-v1-real-replacement.json` identifies the exact reviewed source hash. QA-only typecheck passed. Fresh complete gates run as `task16-full`; actual UI replacement/delivery and unchanged Word-part comparison remain pending. No later queue task or hybrid Step 4 started.


### Task 16 — accepted

Fresh full verification passed 321 root files / 5,571 tests, 15 chatbot files / 205 tests, both typechecks, the unchanged production build and all 26 real-renderer/preview comparisons. Thirteen native MySQL controls and the actual P1 UI replacement/download passed. All 13 Word parts and both Word-rendered page rasters match the earlier real-UI document. Current rows stayed 1; history increased by exactly 1; current/history storage references stayed zero. All 55 frozen sources, branch, HEAD and index remain unchanged. Complete evidence and explicit limitations are in `.work/hybrid-remediation/task16/acceptance.md`.

### Task 4 — active; pre-edit connected-feature and implementation boundary

**Actual scope:** `server/db.ts` gains an atomic multi-row replacement primitive and an uncapped pre-render snapshot reader; `server/affidavitHistory.ts`'s bulk persistence glue uses that primitive; only the persistence/snapshot glue of `document.generateAllP8` and `document.generatePackage` in `server/routers.ts` changes. Preserve the existing single primitive and its Task 16 safeguards. Tests may add direct transaction coverage and update only obsolete non-atomic expectations/mocks. Immutable pre-task copies of these modules, the existing selector and 14 connected test files are in `.work/hybrid-remediation/task04/before/`.

**Connected features that must still work:** ordinary and target-specific single forms; primary-family replacement; P9 newest-per-deponent/blank-legacy handling; P34 citation-target legacy handling; all-P8 generation (including retirement of the entire former P8 set, not just surviving co-applicant targets); grant-package P9/P8/P11 and ancillary/P34 provenance; version history with original dates/deponents/targets and intentionally retained old storage references; multiple valid generated rows in one package; zero-record package persistence; post-commit manifest activation/recovery; repeated and overlapping single/bulk or bulk/bulk generations; non-overlapping generations; existing ownership refusals, activity and audit callers; Home counts and actual POST deliveries. PGT contact auto-seeding and every legal choice, renderer argument and byte-building operation stay unchanged.

**Important discovery:** `generateAllLetters` currently renders one in-memory ZIP, then records an export audit/activity, but does not create/replace document rows. Preserve that behavior and its delivery regression coverage; do not invent letter provenance rows. Its audit failure remains Task 5. Likewise, do not claim Task 4 fixes existing audit false/rejection behavior, input binding, UI feedback or any later queue item.

**Required implementation contract:** capture an uncapped current-document snapshot before the expensive bulk render; do not take the optimistic snapshot only after rendering and do not use the 200-row `listDocuments` cap for replacement completeness. Inside one transaction, use the same estate-first locking discipline and fresh locking current-row read as the accepted single primitive; recompute and deduplicate the complete affected set; compare its IDs with the pre-render expected set; archive/delete/insert the entire new set or roll all of it back. Copy caller-owned arrays/records before awaited work, apply exact estate/key/insert checks to every member, and preserve the static conflict boundary. Preserve existing per-record `documentsReplacedBy` semantics for packages and the separate existing whole-P8-set replacement semantics for `generateAllP8`. Valid multi-deponent P8/P9 sets and shared old-row overlap are not duplicates to be rejected. Empty normal package rows remain a no-op and cannot erase old records. No arbitrary new output count cap, schema change, legal eligibility decision or renderer change is authorized.

**Evidence before acceptance:** focused red/green direct-primitive and route tests for failures at every write phase, >200 current rows, overlapping single/bulk and bulk/bulk attempts, unrelated-scope success, exact/aliased estate identity, mutation-after-entry, valid multi-row sets, one-time shared-row archiving, metadata preservation and no activation on rollback. Preserve unchanged legal assertions. An independent reviewer checks the exact task delta against the before copies. Parent then runs actual-engine fault/concurrency cases, full available gates, the 26-form freeze and actual UI bulk delivery/render/byte checks. All QA uses only the existing owned fictional database and loopback provider. Hybrid Step 4, production resources, AWS credentials/policies and every AWAITING-NICK decision remain out of scope.

### Task 4 QA refinement — complete-facts filing readiness

The expanded three-applicant fixture's direct, no-override P1 preflight revealed missing fictional birth-place and WESA-spouse facts. Earlier P1 downloads and identical Word/render comparisons prove delivery and output preservation, but alone do not prove complete factual readiness; the earlier statement that all required preflight facts were present is not being relied upon for final acceptance. Before final acceptance, complete these fixture facts consistently and explicitly, require zero unresolved P1/P9 preflight gaps without `generateAnyway`, and recheck actual P1 delivery/rendering on the accepted storage and single-replacement code as well as both bulk routes. No application legal requirement, wording, format, default or AWAITING-NICK decision is to change. This is a strengthened QA condition, not authorization to bypass warnings or invent facts in real records. Task 3/16 source/native/full-gate evidence remains valid; their broader complete-facts UI readiness is being revalidated rather than inferred from byte equality.

### 2026-10-21 resumption — warn-only clarification and Task 4 M1 boundary

Nick clarified that generation must not be blocked by missing fields, then authorized continuation. **The preceding extra QA requirement for zero unresolved P1/P9 gaps is withdrawn and superseded.** It was a fixture-runner assertion, not an application change. Acceptance will exercise the existing warn-and-proceed path, preserve existing blanks/missing-field treatment, and never fabricate facts or change prescribed text, formatting or layout. A missing-data warning is not itself a generation blocker or a reason to reject the patch. Authentication, estate ownership, storage isolation, atomicity and the separately recorded integrity/proof boundaries are not silently weakened. Existing AWAITING-NICK decisions remain untouched.

Task 4's atomic delta has independent source approval, 17 focused files / 454 tests and parent native MySQL evidence covering 18 scenarios. Final full/UI/render acceptance remains pending. The reviewer additionally found a baseline P8 metadata mismatch: the all-P8 renderer already uses the retained actual primary deponent, but its metadata validator omits that identity and falls back to the ranked primary. This is within the connected P8 flow that must work before acceptance.

**M1 pre-edit boundary:** thread the already-resolved retained-primary deponent ID into the existing metadata resolver call in `buildAllP8Zip`, if the executable reproduction confirms this is sufficient. Do not alter the applying/co-applicant selector, retained-history selection, validation rule, legal decision, renderer call/arguments, form set/order, filenames, buffer/ZIP building, schema, missing-data policy, or any other builder. Add focused regressions using the real metadata validator; preserve all existing assertions. Before copies, exact delta and final hashes belong under `.work/hybrid-remediation/task04/m1/`; only the metadata argument and necessary tests may change.

**Connected checks:** ranked primary equals actual primary; ranked primary differs from retained actual P3/P4 deponent; multiple applying applicants; correct P8 identities/targets and retirement of the entire prior P8 set; ordinary single-P8 and grant-package behavior; unchanged invalid-identity/history handling; generation/export callers; atomic rollback/conflict and history; exact frozen outputs and actual UI ZIPs. Require red/green tests, independent review of the bounded follow-up, fresh full gates, native verification, and browser/render evidence before Task 4 acceptance. This is not hybrid Step 4 or authorization to modify legal wording/format/selection.

### Task 4 resumption — warning acknowledgement and actual pre-fix UI baselines

The corrected QA setup produced HTTP 200 for P1 while its two existing spouse-field warnings remained (`ok:false`, `hardBlocked:false`). No application blocker or legal override was added. One explicit fictional personal-delivery record was then saved; P9 preflight had no gaps. In the actual browser, Generate All P8 produced a 20,294-byte ZIP. Grant Package displayed **Missing information for Grant Package** with an enabled **Generate anyway**, and acknowledgement produced HTTP 200 / 89,764 bytes with eight DOCX files, the identical fictional will PDF and cover text. These are deliberately captured QA-only artifacts, not application-stored generated bytes. The exact current/history snapshot is restored only inside the owned fictional database between before/after comparisons. Final-source comparison, real-engine/full gates and M1 review are still pending.

### Task 4 final-source acceptance — native and bulk output checks

The M1 follow-up is independently approved: exactly one production argument uses the retained primary identity already used by selection and rendering. Five intended red regressions become green; 33 focused tests and no-emit check pass. The final native batch rerun passes all 18 rollback/scope/identity/concurrency scenarios with disposable-row cleanup. The restarted UI's loaded router/DB/history hashes match the reviewed files.

Actual final-code P8 and grant-package POST downloads return HTTP 200. Before/after fictional metadata shapes and counts match (P8: 4 current / 3 history; package: 6 current / 4 history). All **180 DOCX package parts across 10 actual UI-delivered documents** match, apart from explicitly normalized package creation/modification instants; every Word part is byte-identical. Both non-DOCX package members (cover text and fictional will PDF) are byte-identical. Microsoft Word renders all 10 actual final files without modifying their source DOCX bytes; all **17 pages** have identical pixels, page geometry and text counts versus the pre-fix UI outputs, with no text outside physical pages. Generated current/history storage references and provider PUT counts remain zero. Full gate run `task04-final-full` and the actual-ranked-primary mismatch UI scenario remain pending; no overall SHIP claim.

### Task 4 — accepted

Final full gates: **325 root files / 5,668 tests**, **15 chatbot files / 205 tests**, both no-emit typechecks, production build and all 26 frozen DOCX/XML/preview fixtures pass. The 18 native MySQL scenarios and cleanup pass on the same source hashes. Actual UI P8/package outputs preserve all Word parts and 17 identical page rasters. The additional real-UI M1 case successfully generates Morgan's P3 and P8s for the correctly remaining applicants Jane/Riley; both P8 bodies reference Morgan, the entire old P8 set is archived, and unrelated metadata stays unchanged. All three M1 DOCX files render read-only to four valid pages. No generated storage references or PUT operations occur. Branch, HEAD, index and all 55 frozen sources are unchanged. Full acceptance and exact evidence: `.work/hybrid-remediation/task04/acceptance.md`. The patch as a whole is not yet cleared to ship.

### Task 5 — active; pre-edit connected-feature boundary

**Finding:** `recordDocumentGenerated` and `recordExportGenerated` are boolean best-effort recorders, but every generation/preparation caller ignores false. Single provenance is already committed when its success audit and Rule 22 override activity are attempted. Bulk export success may be recorded before a batch later conflicts; per-document generation audits/activity can then fail after the batch committed. Estate export also returns delivery after an ignored export-audit failure. These are audit/persistence failures, not missing-field warnings.

**Files and architecture:** extend only transaction/audit/persistence glue in `server/db.ts`, `server/affidavitHistory.ts`, and the five existing preparation mutations in `server/routers.ts` (`document.generate`, `generateAllLetters`, `generateAllP8`, `generatePackage`, `estate.export`). Add a small focused module only if it improves the safe boundary without a cycle. Extend existing single and batch primitives with an optional, snapshotted generation-effects value containing existing-schema audit/activity rows; required generation callers must always supply it. Commit required generation/export audit plus generation/override activity in the same transaction as their provenance/current/history changes. Provide an estate-locked effects-only transaction for letters/estate export and zero-provenance packages. Preserve the ordinary empty-batch no-op when no effects are requested. Do not use an outside-transaction callback/recorder that can leave orphan success events.

**Required contract:** a false/malformed write acknowledgement, rejected recorder/write, or late required activity/override write must cause a fixed safe retryable preparation refusal and leave the whole required success/provenance/history set uncommitted. No successful delivery descriptor may escape on failure. Require confirmed audit writes rather than treating any resolved driver response as proof. Clone effect rows and arrays before awaited work and reject literal estate mismatches. Retain existing event names, minimal details, digests, user/IP truncation rules, activity text, document IDs, history metadata, and post-commit activation behavior. No raw driver/query/credential details reach the browser. Do not claim a lost COMMIT acknowledgement proves rollback; the documented contract is coherent all-or-nothing durable state and an unconfirmed/retryable client result. No schema/outbox migration is needed. Preserve the best-effort contract of unrelated security/delivery-finish logging; a global behavior change to every audit caller is not authorized.

**Connected feature checklist:** (1) every single form and target-specific row; (2) per-document overrides and generate-anyway timeline provenance; (3) letters with no document rows; (4) all-P8 complete-set replacement and retained-primary metadata; (5) full and zero-provenance grant packages, including P9/P8/P11/P34; (6) estate archive preflight and ownership refusal; (7) successful audit payload identity/digest and event counts; (8) failure, rollback, retry, exact-estate validation and single/bulk contention; (9) current/version history and deliberate historical references; (10) unchanged delivery-start/finish/abort gates, safe reporting and no generated-byte retention; (11) real UI single/bulk/export preparation and visible preparation failures; (12) exact generated Word/preview output.

**Non-negotiable preservation:** no renderer/byte-building call, form selection, legal condition, eligibility decision, wording, formatting, schema, dependency, storage-role/KMS/namespace behavior, warning policy or AWAITING-NICK decision changes. Missing information still warns and permits the established Generate anyway path. PGT auto-seeding and other existing preparatory facts are not moved or redefined. No Tasks 6–15 delivery/UI work is folded in. No production/AWS access, external writes, Git mutation or hybrid Step 4.

**Verification:** record focused red cases before source changes; add direct transaction rollback/zero-ack/late-audit/activity failure cases and all-five-route false/rejection/retry coverage, preserving every original legal/output assertion. Independent review compares the full Task 5 delta with `.work/hybrid-remediation/task05/before/`. Parent owns fresh full gates, the 26-form freeze, guarded native MySQL rollback/concurrency checks and actual UI success/failure/output comparisons. Test-only fake drivers must exercise transactional audit writes rather than merely always report success. Graph capability is still unavailable; bounded source tracing is the documented fallback. Only one application source writer is active.

**Task 5 optional-timeline clarification:** estate export's `exported` activity is explicitly best-effort today. Preserve that contract rather than adding a new required timeline gate: attempt it only after the required export audit commits, catch its failure safely, and never leave an exported-success activity when the required audit failed. In contrast, the existing single-form/letters/P8/package generation activities and Rule 22 override activity are part of their required coherent commit. Do not alter the general `createActivity` or best-effort `createAuditEntry` semantics for unrelated callers.

### Task 5 continuation and parent baseline — 2026-10-21 17:04 local

The first writer implemented the transaction/effects core but explicitly returned **partial/blocked**, not accepted: six core files/464 tests passed and no-emit passed, while the connected run exposed 79 failures/372 passes in mocks that still expected out-of-transaction generation leaf writes. A single continuation writer is updating only those persistence test contracts and the narrowly identified required-effects safe-errno envelope; an independent source/test review follows. No legal/output assertion may be weakened. The complete task remains unchecked.

Before restarting the UI onto Task 5, the parent captured actual successful UI deliveries on the preserved Task 4 backend for P1, all letters, all P8, grant package and estate export. The package used its existing enabled **Generate anyway** control. P1/letters/P8/package supplied 12 DOCX files; read-only Word renders produced 21 pages, all original DOCX hashes unchanged and no text outside physical page bounds. The estate export contains the two legitimate current/retained fictional PDFs and structured metadata. Captures and immutable baseline DOCX/renders live only under `.work/hybrid-remediation/`; the application retains no generated bytes. Canonical fictional current/history metadata was restored between comparisons using the established identity-guarded QA helper, not any production record.

The parent-only QA code now has a one-shot, five-minute, estate-bound mysql2 transport fault adapter (generation/export events only), actual-driver rollback/retry/late-activity/constraint/commit-ack-loss/concurrency cases, a read-only UI state snapshot and exact UI ZIP/Word-part comparator. These are verification instruments, not application entry points or schema/trigger changes. Their fixture-only TypeScript check passed. Native fault runs, final UI failure/retry checks, final full gates, source review and final rendered-output comparison are still pending; none is inferred from the prior results.

### Task 5 native and first real-UI failure evidence — 2026-10-21 17:20 local

The completed bounded continuation gate passed **33 files / 994 tests** plus root no-emit. The parent native harness passed **21 actual MySQL scenarios**: single/batch/effects-only rejected or zero-row audit acknowledgements, late required activity and override activity failures, native unique-constraint failures, complete rollback plus successful retry, empty legacy no-op, literal estate alias refusal, entry snapshots, three real-COMMIT/lost-acknowledgement cases and a real two-waiter single/batch conflict with only one complete winner. All 42 disposable estates were cleaned up; no provider operation or schema change occurred. Receipt: `task05/task05-native-v1-real-audit.json`; its source hashes match the restarted fictional UI.

In the real dashboard, the parent selected **Export estate copy** for the fictional estate with one explicitly armed zero-affected-row audit response. The UI exposed the exact safe message, “Generation could not be confirmed. Refresh the estate and try again.” The preparation returned HTTP 500, no delivery request followed, all four provenance/history/audit/activity snapshots remained exactly equal, and provider write counters did not change. Receipt: `task05/estate-required-audit-failure-ui-coherence.json`. The adapter receipt proves it was the required export audit, not a delivery event, and the fault was consumed once. The first screenshot wrapper had an output-format error after locating the message; a subsequent actual DOM lookup independently confirmed that message without repeating the action. Full gates, independent review and remaining UI retries/output preservation are still outstanding.

### Task 14 — safe refusal/error boundary: implemented and verified; one freeze-proof item environment-blocked — 2026-10-22 local

**Scope (Nick):** D2 "task surfaces only" and D1 "names from records".

**Trust model.** Browser-facing words come only from:
- the private brand — a module-private WeakMap registered by `PublicRefusal` / `PublicTRPCError` constructors;
- an inventoried frozen-renderer identity table — 19 exact literals and 5 closed-parameter templates, plus 22 literals and 9 templates for preview only;
- a fixed Zod sentence;
- or the boundary's fixed text.

No message, cause, name, code or prefix is trusted. On the task surfaces — `document.*`, `estate.export`, errors with no path, and the three POST deliveries — every helper is total, metadata is a closed vocabulary, and reports carry only the catalog form code and the ownership-verified estate id.

**Changes.**
- 97 brand sites across `routers.ts`, `db.ts`, `documentAssets.ts`, `affidavitHistory.ts`, `_core/trpc.ts` and `estateExport.ts`.
- The Task 5 classes were re-based on `PublicTRPCError` with unchanged code, words and constructor.
- Added: a tRPC `errorFormatter`, which strips stacks everywhere; and a closed `onError` trace for withheld task-surface faults.

**Deliberate wording changes.** Listed in `task14/claude-pass01/implementation.md`: fixed not-mapped sentence, recorded values dropped from four preview templates and T6, Rule 14 and P34 storage detail moved to `cause`.

**Untouched.** No frozen file, renderer argument, legal selection, schema or dependency changed.

**Independent review.** Three lenses (silent-failure, security, probate integrity gate), two rounds plus final verification:
- every HIGH/MEDIUM finding was fixed;
- residual LOWs are recorded;
- the integrity gate found the freeze and all approved wording intact.

**Evidence.**
- Red: 75 failing HTTP/route/unit cases, and real-UI raw SQL in the Home toast and preview pane.
- Green: focused runs on the final bytes, and the full gates `claude-task14-pass3` (all six gates exit 0; 332 files / 6,235 root tests and 15 files / 205 chatbot tests passed; build passed; all 26 frozen render fixtures verified; all 55 protected hashes match).
- Native: Task 5 audit `task05/task14-native-v1`, 22 MySQL scenarios passed.
- Real UI: 28 recorded cases on the owned fictional fixture — faults with healthy retries for P1, preview, letters (preflight), all-P8, package (warning → Generate anyway), estate export, form delivery and notes; plus Rule 14 409, stale 409 and unauthenticated 401. Zero leak markers.
- Output: UI DOCX Word parts are byte-identical to the Task 5 final baselines for P1, letters, both all-P8 affidavits and the 8 package members; the estate export matches.

**STILL-BLOCKED item.** The read-only Word render for the pixel comparison hangs in this environment: a document opens read-only, then repagination or export never completes, on three attempts. Owned Word instances were stopped by PID. A pre-existing automation Word (PID 76000, started 2026-10-21 12:22) was not touched.

**Open for Nick.**
- Plan item 6: keeping `formStatus` reasons in not-applicable refusals.
- Rule 18 stays UNRATIFIED; Task 14 preserves its wording only.
- R2: lost-commit log identification.

Evidence: `.work/hybrid-remediation/task14/claude-pass01/`. Stop per instructions; Task 6 does not begin.

### Task 6 — content-bound single-form delivery: implemented and verified; acceptance contingent (Task 14; Word pixel step environment-blocked) — 2026-10-23 local

**Scope.** This follows Nick's approved revised plan,
`docs/superpowers/plans/2026-10-22-task06-content-bound-delivery-revised.md`.

**Mechanism.**
- `document.generate` mints a stateless HMAC binding: `fdb1.<issuedAtMs>.<renderSha256>.<mac>`.
  - The key comes from HKDF over the existing session secret; there is no fallback key.
  - The MAC covers the account, the release, the exact posted fields and the canonical digest of the
    main render.
- `POST /api/download/form` verifies the binding after ownership and before the budget, facts and
  assets. An invalid binding gets the 409 stale sentence.
- The route keeps the unchanged current-row check.
- After the real render, a digest mismatch is refused with 409 `StaleDeliveryError`.
- Snapshot-admission semantics are as approved: no final-byte re-check, no cancellation, and no
  exactly-once claim.

**Changes.**
- New: `server/formDeliveryBinding.ts`.
- `document.generate` plumbing in `server/routers.ts`.
- `server/downloadRoute.ts`, plus one closed name in `failureReporting.ts` and the shared input hash in
  `_core/deliveryRouter.ts`.
- Tests: 4 new suites; signed fixtures and the appendix-A1 hoisted fictional test secret in existing
  test files.
- QA-only: the `fixture/ui-server.ts` health list.
- No renderer, wording, schema, client, legal-selection, AWS or dependency change.

**Independent review.**
- Per-task spec and quality reviews: T1–T4 approved, with fix rounds on T2 and T3.
- Final three lenses (security, silent-failure, probate-integrity gate): BLOCKING 0.
- One Medium was fixed: a quadratic-backtracking `core.xml` regex reachable from an uploaded letterhead
  template. It is now linear and attribute-exact; the digests of 52 real documents are unchanged. The
  fix was re-reviewed.

**Evidence.**
- **Gates** `claude-task6-revised-pass1`: all six exit 0.
  - 336 files / 6,402 root tests and 15 files / 205 chatbot tests passed.
  - Build passed; all 26 frozen render fixtures verified; all 55 protected hashes match.
- **Regression sensitivity** (in-memory mutants on the final source): removing the MAC check, the
  digest comparison or the replay row check fails 24, 22 and 8 tests respectively; the control passes
  276/276.
- **Native MySQL ordering proof** `t6n-prove-5`:
  - a replacement before the snapshot gives 409;
  - an identical replacement after the snapshot gives 200 under the original id;
  - a changed printed fact gives 409;
  - zero residue and unchanged table checksums.
- **Native Task 5 audit** `task05/task06-native-v1`: 22/22 scenarios.
- **Real UI** (63 recorded cases):
  - 8 matched deliveries whose Word parts are byte-identical to the before cohort, apart from the two
    core timestamps;
  - tampering and a missing token;
  - printable, settings, letterhead and newer-P9 drift;
  - regeneration;
  - a real 11-minute expiry, on both transports;
  - Generate anyway with missing facts;
  - both retry buttons;
  - a post-fix template confirmation.
- Zero leak markers, and no generated-byte storage.

**STILL-BLOCKED item.** The Word pixel render: installed Word hangs on read-only open/export in this
environment. Task 6 made two attempts, with no pre-existing Word running; owned instances were stopped
by PID. This is the same limit as Task 14.

**Open for Nick.**
- **INT-1 (Medium, suspected).** TiDB row order for contacts, deliveries and inventory ties could turn
  an unchanged delivery into a 409. Settling it needs TiDB order checks, or a total `ORDER BY`; that
  change is outside the approved file list and needs a document-freeze review.
- **INT-2 (Low).** The binding's ~157 bytes push a narrow band of near-8 KB descriptors into a 413 at
  download.
- **SEC-2 (Low).** Set `GENERATOR_RELEASE` on every deploy; the `"1.0.0"` default merges releases in
  the MAC.
- **Frozen `docgen.ts`.** Two template-merge regexes backtrack on hostile templates, and the
  relationship regex never matches.
- **Residuals.**
  - The admission log line lacks the form code.
  - Node 24 throws a RangeError (a fail-closed 500) on an attribute run of 8 MB or more in the
    uploader's own template.
  - The "Kevin Kisser" fixture name is used across the repo.
- Confirm appendix A1 (the hoisted fictional test secret), which was applied by controller ruling.

Evidence: `.work/hybrid-remediation/task06/claude-pass01/` (`final-status.json`, `final-status.md`,
`task-only.diff`, `task-files.json`). Stop per instructions; Task 7 does not begin.

### Task 6 outstanding-issue repairs — verified permitted delta; full acceptance still open — 2026-10-23 08:29 local

Nick authorized “Resolve task 6 issues.” On 2026-10-23 at 07:52 local, Nick explicitly deferred the Word/pixel checks because of the local computer issue. **That evidence is user-deferred, not passed, and is not treated as an automation-failure blocker for these delivery-plumbing repairs.** No further Word retry is scheduled. Task 14 acceptance is not automatically granted; its historical receipts remain intact.

**Resolved in `task06/manus-repair01`:** lossless linear timestamp-text scanning replaces the delivery digest's RangeError/backtracking path (including an 8 MiB regression); the form route alone allows the exact signed-binding envelope (URL-encoded 8,349 bytes; JSON 8,353), with parser/declared/chunked guards while export/notes remain 8,192 bytes; both issuance and verification bind to a stable source/build fingerprint as well as the existing release, without changing frozen renderer/audit release fields; binding refusal logs carry canonical form/category only; expected race logs and re-zipped media controls are asserted; three older P7/P8/P9 manual test signers use the same fingerprint, with every original legal/proof assertion preserved. The first full suite exposed precisely those eight old-fixture failures; their focused red/green proof is 8 failed / 36 passed to 44/44 passed. No assertion was weakened to make them pass.

**Final stable-source gates `manus-task06-final2`: all six exit 0.** Root no-emit; **338 root files / 6,444 tests**; chatbot no-emit; **15 chatbot files / 205 tests**; production build; **26 real DOCX/XML/preview freeze fixtures**. The existing gate's 54 guarded protected paths and final task-only source/context fingerprint checks pass. No court wording, format, renderer, legal/selection logic, schema, `db.ts`, client, dependency, AWS or production change occurred.

**Fresh native/UI evidence:** the existing identity-guarded MySQL replacement/drift ordering proof passes **39 steps**, cleans all disposable rows, preserves its whole-table checksums and performs zero provider operations. Real browser actions deliver P1 ZIP **HTTP 200 / 13,520 bytes** and P19 DOCX **HTTP 200 / 9,240 bytes**, with P19's grant-issued date still blank. Actual attachment hashes match exactly one native generation/start/finish audit set and current provenance row per document; current generated-byte storage remains zero. P19 preview was loaded and visibly retained the blank seal date. The task-owned UI service and its attributable orphaned child were stopped; no user Word process or production service was stopped.

**Independent review:** the original wrong-directory diff erroneously represented the unchanged `verify-all-forms.test.ts` as an undeclared deletion. Only the evidence package was corrected. The final patch, manifest and after snapshots reconcile exactly **16 files** (5 application paths, 11 tests), with all hashes matching. Independent final review finds no additional issue in this repaired delta and confirms the three signer-only test edits reconstruct their before copies when reversed. Original defective and first corrected diff artifacts are retained for provenance.

**Still open under the freeze:** INT-1 is not solved by the digest repair. A controlled offline positive case with two same-category tied P11 inventory rows shows different body/canonical hashes when only sequence is reversed; two simpler negative controls remain equal. This proves output sensitivity, not that production/TiDB actually permuted rows. Sorting/ORDER BY can change court-visible sequence and first-contact selection, so a separately approved ordering policy/document-freeze review is required. The pre-existing frozen `docgen.ts` template-merger backtracking and Relationship parsing issue also remain unchanged and need a separately scoped exception; no new template-admission blockers were invented.

**Disposition:** permitted delivery-plumbing repairs verified; **Task 6 remains unaccepted and no SHIP claim is made** because the frozen issues and predecessor disposition remain open. Pixels are deferred by Nick, not falsely green. Branch/HEAD/index remain `security/hybrid-vault-review` / `db0d7e9161bc3899b75858fab58bce54e3d5247a` / empty. Nothing committed, pushed, published or deployed; no Task 7/15/next-task implementation.

Report: `outputs/task06-repair-report-2026-10-23.md`. Fresh evidence and machine disposition: `.work/hybrid-remediation/task06/manus-repair01/`; native receipt: `task06/claude-pass01/native/task06-manus-repair01-native-prove-receipt.json`. Earlier Claude handoffs are historical and were not rewritten.

### Task 15 — export failure reporting: implemented and verified under Nick's named ordering exception; NOT accepted — 2026-10-23 local

Nick approved plan r2 (`docs/superpowers/plans/2026-10-23-task15-export-failure-reporting.md`) with an explicit Task 15-specific exception: Tasks 7/8 are missing and Tasks 14/6 unaccepted. This is permission to proceed, **not** predecessor acceptance. New `server/exportFailureReporting.ts` plus plumbing in `downloadExportsRoute.ts`, `routers.ts` (`estate.export` only) and `notesExportRoute.ts` make **at most one** staff-report attempt per eligible failed invocation through the existing `createFailureReport`: trusted `report:true` refusals and faults are eligible; ordinary refusals are not. A row is written only when the report is admitted and the writer is healthy; reports skipped by saturation or by the per-user limit are logged as `saturated` / `rate_limited` and never counted, so not every failed invocation creates a row. Public statuses/messages, audits, byte gates and slots are unchanged; the write is detached and bounded (1 s wait, 2 unsettled per process, 8 per user per 60 s).

**Approvals (Nick, 2026-10-23), recorded as plan Amendment A1:** (1) the 8-per-minute per-user limit, approved only as a limit on staff failure reporting — never on generation, downloads, the notes PDF export, retries or Generate anyway; (2) the late-result diagnostic, approved only with the private reference, operation and closed outcome/category fields, no exception text, client contents, filenames, credentials or request data, and no second write or response. An independent read-only check found both conditions MET; guard tests now prove the same user's retry, other exports, bulk generation, notes export and Generate anyway proceed after the limit is reached.

**Final gates `claude-task15-pass3` (fresh, after the guard tests; source hashes recorded before and verified after): all six exit 0** — 339 root files / 6,513 tests, 15 chatbot files / 205 tests, both no-emit, build, 26 renders. Both additions were also inside the hashed source of the earlier all-green `claude-task15-pass2`. 13/13 mutants killed; native MySQL proof and the real fixture app over HTTP passed. **Real-browser evidence remains OUTSTANDING** — HTTP evidence does not substitute for React rendering, toasts and browser downloads; preserved instructions: `.work/hybrid-remediation/task15/claude-pass01/browser-check-pending.md`. Word/pixels user-deferred-not-passed. Evidence: `.work/hybrid-remediation/task15/claude-pass01/final-status.md`. Task 15 stays implemented but **not accepted**; no SHIP claim; checkbox unticked; nothing committed; no Task 9 or next-task work.

### User disposition — Task 15 done by decision; Task 9 selected next — 2026-10-23 12:06 local

Nick explicitly instructed: “ok lets consider 15 done and give me prompt 9 ill just finish most before we transition.” **Task 15 is closed/done by this user decision**, and its checkbox is now checked. This supersedes the earlier task-tracking disposition “implemented but not accepted” above; it is not a new technical verification or a SHIP/publication decision. The real-browser evidence remains outstanding; Word/pixels remain user-deferred-not-passed. Preserve existing Task 15 receipts and carry the recorded limitations/evidence gaps into any future integration/release review rather than relabelling them passed.

Nick separately stated that Task 9 is next and we have moved on from Tasks 7 and 8. Honor that selected order: **do not reopen 7/8, demand their acceptance as a generic prerequisite, or execute their prompts**. Their existing unchecked findings remain recorded, not newly verified or silently resolved. Only a specific indispensable dependency exposed by Task 9 may be raised with its exact scope before changes.

The updated Task 9 prompt is `outputs/claude-remaining-tasks/06-task-9-cookie-independent-downloads.md`. This operation changed only the Task 9 prompt, this queue disposition and QA fingerprints/backups. No Task 9 implementation, application transition/package/transfer, database query, AWS/production operation, Word/browser retry, commit, push or publication began. Task 9 starts with a plan for Nick's approval and stops after its own handoff; no automatic next task.

### Task 9 — cookie-independent delivery: implemented and verified on the final build; NOT accepted — 2026-10-23/24 local

Nick approved plan r2 (`docs/superpowers/plans/2026-10-23-task09-cookie-independent-delivery.md`). A cookie-only session keeps the unchanged native form; a session holding the Preview Bearer fallback now delivers through one same-origin fetch with the token only in `Authorization`, the native urlencoded body (the preview keeps its JSON), bounded and validated responses and an identity-checked handoff (new `client/src/lib/attachmentDelivery.ts` and `fallbackSession.ts`; callers in `EstateDetail.tsx` and `Home.tsx`; `main.tsx`, `useAuth.ts`, `Settings.tsx`; D5 header redaction in `debug-collector.js` and `vite.config.ts`). No server, docgen, renderer, shared type/const, schema or wording change.

**Final gates `claude-task9-pass1`: all six exit 0** — 346 files / 6,666 tests (+7 / +153 vs Task 15), 15 chatbot files / 205 tests, both no-emit, build, 26 renders; the served build stayed byte-identical to the browser-evidence manifest. 15/15 mutants killed on the final bytes. Native fixture: 45/45 identity, tenancy and envelope cases; healthy Bearer form and export audited once each (started + finished, matching hash). Real headless Chromium on the final build: cookie controls unchanged; Bearer-only Home export, forms, preview, P8 retry, letters, package, all-P8 and notes delivered with file = network body = capture; both stale 409s (row replacement, and a rendered-field digest with exact restoration); the offline sentence then a fresh-attempt retry; native and Bearer request bodies byte-identical for one descriptor. Freeze: native vs Bearer DOCX parts identical except core.xml timestamps. Three read-only opus reviews (security, silent failure, probate integrity) found no BLOCKING or HIGH issue; three security LOWs were fixed; an independent claims audit corrected the summary. Deviations, the D6 erratum (the 17-field JSON body is 8,351 B, not over 8,353) and the items left for Nick's decision (dev-log body capture, a client-failure console trail, duplicate auto-download/retry buffering, chatbot rotation moving cookie tabs onto the fetch path; the pre-existing Manus runtime message listener) are in `.work/hybrid-remediation/task09/claude-pass01/final-status.md`.

Task 9 stays **implemented but not accepted**; checkbox unticked; no SHIP claim. Limits: Chromium only (no Safari/iOS/Android WebView proof); "handed-off" is not "saved"; Word/pixels user-deferred-not-passed; Task 15's browser check still outstanding. Branch/HEAD/index `security/hybrid-vault-review` / `db0d7e9161bc3899b75858fab58bce54e3d5247a` / empty; nothing committed, pushed, published or deployed; the fixture is stopped; no next task started.

### User disposition — Task 9 accepted/done by decision — 2026-10-23 19:06 PDT

Nick accepted Task 9 for remediation tracking: **Accepted/done by Nick's decision, with the limitations and deferrals below.** This is not a SHIP or production-readiness approval. The checkbox is now checked; this supersedes the earlier task-tracking disposition "implemented but not accepted" above. The existing evidence, recorded deviations, JSON-size erratum (the Task 6-shaped 17-field JSON body is 8,351 B, not over 8,353) and reviewer substitution stand unchanged, and historical receipts are not rewritten.

Nick's decisions on the remaining items:

- **Development/Preview delivery-body logging — not approved; OPEN.** Retaining raw delivery bodies that contain estate data, overrides or consent answers is not approved. Narrowly scoped body redaction or suppression is **required before any real client data is used in a collector-enabled environment**. Credential (header) redaction alone does not resolve this. It is not fixed, and no implementation of it began under Task 9.
- **Developer console trail — not added.** No new logging feature now. Recorded diagnostic limitation: client-side delivery failures (redirect, invalid response, too large, incomplete, session change) show the generic sentence and leave no developer trail. Never log tokens, raw request bodies or private error text.
- **Duplicate buffering — deferred to Task 13; NOT resolved.** Shared busy-state coordination between an auto-download and its retry control belongs to Task 13. Recorded risk: a retry clicked while a slow Bearer response is still buffering starts a second full fetch, so the file can download twice and use up to about twice the memory, particularly for large ZIPs.
- **Chatbot rotation — chatbot unchanged.** Setting a fallback token (including the chatbot's adoption of `X-Rotated-Session`) can move a cookie-authenticated session onto the fetch path, with its buffering limits, even though server-side cookie priority remains intact. Not every cookie session always uses native submission: native submission applies only while no fallback token is stored. (The header comment of `client/src/lib/attachmentDelivery.ts` describes the cookie session without a stored token; it was not edited after verification, so source and receipts stay as verified.)
- **Runtime message listener — separate security finding, OPEN, to be resolved before production transition.** The Manus runtime `message` listener (`vite-plugin-manus-runtime`) does not validate `event.origin` or `event.source` before writing the session store. This closure does not approve trusting arbitrary messages that alter the session store.

Still outstanding: Safari/iOS/Android WebView verification; Word/pixels user-deferred-not-passed; Task 15's real-browser gap. "Handed off" is not proof that the file was saved.

For future models: these decisions, the Global constraints above and RULES.md Rule 29 (the hybrid-storage document format/wording freeze) remain in force. RULES.md is protected by the gate freeze guard, so the Task 9 decisions are recorded here and in `.work/hybrid-remediation/task09/claude-pass01/final-status.md` and `review/dispositions.md`. This acceptance authorizes no renderer, legal-logic, form-selection, schema, AWS or production change. Only documentation and status were updated; nothing was staged, committed, pushed, published or deployed; no vault or external archive was updated; Tasks 7/8 were not reopened and no next task began.

### Task 13 — truthful UI outcomes: implemented and verified (plan r2 + r3 amendment) — 2026-10-23/24 local

Nick approved plan r2 (`docs/superpowers/plans/2026-10-23-task13-truthful-delivery-feedback.md`). After his 2026-10-24 decisions he approved the r3 amendment (`docs/superpowers/plans/2026-10-24-task13-r3-amendment.md`), and he approved the copy and scope of its review-fix rounds r3.1 and r3.2. The four decisions were: #14, feedback survives tab switches within an estate; #15, a same-user token rotation shows the attempt's error; #16, the forced review shows the retained choices; and m06, accepted as an equivalent mutant.

**What changed.** Delivery feedback now reports only what was observed:
- "download requested" for a native submission;
- "preparing the download…" and then "download started" for a fetch handoff;
- the server's refusal sentence, or otherwise the generic sentence.

A same-delivery pending lock suppresses a second fetch and buffer while one is in flight. A stale link offers "Review and generate again", which reopens the review with a display-only block of the retained choices and replays the same request.

The changed files are `client/src/lib/attachmentDelivery.ts`, `client/src/pages/EstateDetail.tsx`, `client/src/pages/Home.tsx` (r2), `client/src/components/PreGenerateDialog.tsx` (r3, the review block only) and their tests. There is no server, docgen, renderer, preview-builder, shared-type, schema, form-selection or legal-wording change.

**Final gates `claude-task13-pass3`, on the r3 final bytes: all six exit 0.**
- 347 files / 6,784 tests: 40 more than r2's `claude-task13-pass1` (6,744).
- 15 chatbot files / 205 tests; no-emit; build; 26 renders; `FROZEN_LEGAL_SOURCES_UNCHANGED`.
- The served build stayed byte-identical to the build-5 browser-evidence manifest.

**Mutants:** r2 26 of 28 killed; r3 35 of 37; r3.1 41 of 44; r3.2 12 of 12. The survivors were expected: m06 (accepted) and the controls c11 and c48.

**Real headless Chromium on the fictional fixture:**
- r2, build 2: cases S2–S12.
- r3, builds 3–5: tab switch, rotation, leaving the estate, and the P8 stale-link review. Its replayed request body is byte-identical to the original's, and its DOCX differs only in the `core.xml` timestamps.

**Reviews:**
- r2: three read-only reviewers plus a claims audit.
- r3: code, security and integrity reviewers over two re-review rounds, plus an independent claims audit of about 170 claims, which corrected the summary.

**Evidence:** `.work/hybrid-remediation/task13/claude-pass01/final-status.md` (r2) and `.work/hybrid-remediation/task13/claude-pass02/final-status.md` (r3, final).

**Limits:**
- Chromium only, with no Safari/iOS/Android WebView proof.
- "Download started" is a handoff, not a saved file.
- Word/pixels: user-deferred-not-passed.
- Task 15's browser check is still outstanding.

**Workspace:** branch/HEAD/index `security/hybrid-vault-review` / `db0d7e9161bc3899b75858fab58bce54e3d5247a` / empty. Nothing was committed, pushed, published or deployed. The fixture was restored to its r3-start state and stopped.

### User disposition — Task 13 done by decision — 2026-10-24 17:48 PDT

Nick marked Task 13 done within its approved scope: **Done by Nick's decision, with the limitations and deferrals below.** This is remediation tracking, not a SHIP or production-readiness approval. The checkbox is now checked. The existing evidence, recorded deviations and reviewer substitutions stand unchanged, and historical receipts are not rewritten.

Nick's decisions and preferences:

- **VSA532 review line — confirmed, UI display only.** The forced review shows `Signatory` for VSA532 only when "Lawyer" was sent. This is r3.2's narrowing of his r3.1 "Show it" answer. It approves the review display only: **do not change the printed form, the form-selection logic or the P10 deponent behaviour.**
- **P10 deponent carry-over — pre-existing, left unchanged.** After a P8 for a co-applicant, the P10 details dialog starts with that co-applicant as deponent (`FormDetailsDialog.tsx:915-930`, frozen for Task 13). The dialog shows the deponent before generation. It is not changed, by Nick's instruction.
- **Every disclosed limitation and every unverified or deferred check is preserved.** No overall SHIP claim is made.
- **Stop:** no further Task 13 code change, and no other task was started.

Still open, not resolved by this closure:

- **Unverified checks:** Word/pixels user-deferred-not-passed; Safari/iOS/Android WebView not verified; Task 15's real-browser gap.
- **Development/Preview delivery-body redaction:** a Task 9 decision, OPEN. It is required before real client data is used in a collector-enabled environment.
- **The runtime `message` listener:** OPEN before production.
- **Chatbot rotation** moving cookie tabs onto the fetch path: recorded only.
- **The preview path's microtask gap:** INFO; F7's one-liner would apply.
- **The S2 residual:** a different-user token swap without `clearFallbackSession` reads as a rotation. No file, success or server text crosses.
- **`DATE_NOT_PRINTED` is an exception list:** a future builder that never prints the date would show a Date line.
- **c48** survives by design.
- **S12f** was not run: there is no in-page route from one estate to another.
- **Kept as before:**
  - Task 12 owns the preview's abort, close and body lifecycle;
  - "Review & retry" after a generation failure still drops its targets;
  - a native duplicate retry stays possible;
  - the recovery panel is per-mount state and is lost on a tab switch.
- **Task 9's "Duplicate buffering — deferred to Task 13".** Task 13 r2 implements the shared busy state on the fetch path: a second fetch of a delivery already in flight is suppressed, so there is no second buffer. In r2's browser case S2, three clicks on the disabled retry sent 0 requests. Native submissions keep the accepted duplicate re-post.

For future models: these decisions, the Global constraints above and RULES.md Rule 29 remain in force. RULES.md is gate-frozen, so the Task 13 decisions are recorded here, in the r3 amendment's appended decision record and in `.work/hybrid-remediation/task13/claude-pass02/final-status.md`. This closure authorizes no renderer, legal-logic, form-selection, schema, AWS or production change. Only documentation and status were updated. Nothing was staged, committed, pushed, published or deployed, no vault or external archive was updated, and no next task began.

### Task 10 — notes delivery audit and foreign-owner denial: implemented and verified; NOT accepted — 2026-10-24 local

Nick approved plan r3 (`docs/superpowers/plans/2026-10-24-task10-notes-delivery-audit.md`): Gate A saved the plan, and
Gate B ("proceed") authorized implementation.

**Decisions D1–D4:**
- **D1:** statuses unchanged (404 for a missing or alias id, 403 for a foreign id), plus one `idor_attempt` audit
  wrapped in `auditWritten`.
- **D2:** new `notes_delivery_started|finished|aborted|failed` events through `recordNotesDelivery`, using the existing
  allowlist.
- **D3:** no new wait boundary; a start write that never settles belongs to Task 11.
- **D4:** a refused start audit answers 503 "The document was generated but could not be audited. Please try again."
  and files at most one Task 15 report (`unexpected_generation_failure`).

**Changed files:**
- `server/notesExportRoute.ts`: route plumbing only; the frozen notes-PDF regions are byte-identical.
- `server/affidavitHistory.ts`: +5 CRLF lines, inserted byte-exact.
- `server/deliveryBearerAuth.test.ts`: two added cases.
- New `server/notesExportRoute.audit.test.ts`.
- No client, docgen, renderer, shared, schema, router, tRPC, reporting or db change.

**Evidence** (`.work/hybrid-remediation/task10/claude-pass01/final-status.md`):
- Red `claude-task10-red1` exit 1; focused runs green.
- 16/16 mutants killed on the final bytes.
- Golden notes PDFs byte-equal before and after (7 cases, pinned clock).
- Native fixture N1–N10: ordering proven by an identified lock barrier; the injected faults and a real 50 s lock
  timeout are labelled as such; N8 observational.
- Real Chromium B1–B4: download = capture = audit hash; the 503 page and the toast text; explicit healthy retries.
- **Full gates:**
  - `claude-task10-pass1` failed at `tests`: a vitest worker exited unexpectedly in
    `formDeliveryBinding.races.routes.test.ts`. That file alone passed 18/18.
  - **`claude-task10-pass2`: all six gates exit 0** — 348 files / 6,860 tests; chatbot 15 / 205; both no-emit checks;
    build; 26 renders. The build is identical to the browser manifest.
- **Reviews:** R1–R3 found no BLOCKING, HIGH or MEDIUM issue. R2's two test LOWs were fixed (test-only). The R4 claims
  audit was applied.

Task 10 stays **implemented but not accepted**: checkbox unticked, no SHIP claim.

**Limits:**
- L1: unbounded pending and append-only audit writes (Task 11).
- F1: non-Latin-1 or `"` in the notes filename (pre-existing).
- `references/file-storage.md:117` is now stale (Task 17).
- Every carried-forward item from Tasks 9, 13 and 15 still stands.

Nothing was staged, committed, pushed, published or deployed. The fixture is stopped, and no next task was started.

### User disposition — Task 10 accepted/done by decision — 2026-10-25 08:10 PDT

Nick replied "accept" (typed "acce[pt") to the Task 10 hand-back. **Task 10 is accepted/done by Nick's decision for
remediation tracking, with the limitations and deferrals below.** This is not a SHIP or production-readiness approval.

- The checkbox is now checked. This supersedes the earlier "implemented but not accepted" disposition above.
- The evidence, the receipts and the recorded `claude-task10-pass1` gate failure stand unchanged; nothing is
  rewritten.

**Still open (this acceptance resolves none of them):**
- **L1 → Task 11:**
  - an audit write (start or denial) that never settles holds its request;
  - concurrent unresolved writes and the growth of append-only audit rows are unbounded;
  - the notes route has no per-user budget.
- **L2:** a `started` row without a terminal row means "outcome not recorded". A lost ACK can leave a durable started
  row after a 503.
- **L3:** no Node-originated response `error` could be triggered natively on Node 24.13.1 (the approved narrow coverage
  exception). Native close-before-finish is observational only.
- **F1 (needs Nick's separate approval):**
  - a non-Latin-1 or CR/LF deceased name makes the notes export fail with `ERR_INVALID_CHAR`, and that 500 keeps
    `Content-Type: application/pdf`;
  - a `"` in a name injects Content-Disposition parameters.
- **Task 17:** `references/file-storage.md:117` ("The notes export writes no audit event") is now false.
- **Gate incident:** the cause of the worker exit in `claude-task10-pass1`
  (`formDeliveryBinding.races.routes.test.ts`) was never determined. pass2 on the final bytes was green.
- **Earlier carried-forward items:**
  - Dev/Preview delivery-body redaction is OPEN before real client data.
  - No developer console trail.
  - Chatbot rotation can move a cookie tab onto fetch.
  - The runtime `message` listener is OPEN before production.
  - Task 15's browser gap.
  - Safari/iOS/Android WebView unverified.
  - Word/pixels user-deferred, not passed.
  - Task 6/14 limits; Tasks 7/8 not reopened; no AWAITING-NICK item resolved.

**For future models:**
- D1–D4, the Global constraints and RULES.md Rule 29 remain in force.
- This acceptance authorizes no renderer, legal-logic, form-selection, schema, client, AWS or production change.
- Only documentation and status were updated. Nothing was staged, committed, pushed, published or deployed, and no next
  task began.

### Task 11 — notes PDF export resource bounds: implemented and verified — 2026-10-25 local

Nick approved the plan (`docs/superpowers/plans/2026-10-25-task11-notes-resource-bounds.md`):
- Gate A: plan-mode exit, after two rounds of decisions P1–P12.
- Gate B: "proceed with recommendations …".
- The plan's appended records (save errata, go-ahead, B6 erratum, B10 fix record) override its older lines.

**Decisions:**
- **Order.** The account gate runs after auth and before the estate lookup (P1). The process lease is taken after auth
  (P12).
- **Leases and rates.** Leases: 3 per process, 2 per account. Rates: 12 admitted attempts per account and 30 per
  process, per fixed 60 s window. Render windows: 15 s per process and 6 s per account, per 60 s.
- **Waits.** One 15 s pre-render deadline from handler entry. A 10 s start-ACK wait with exactly one late
  `notes_delivery_failed`/`start_ack_timeout`. A 300 s send deadline.
- **Caps.** 500,000 printed units, 20,000 mandatory breaks, longest segment 1,000, Σ L² 10,000,000.
- **Copy.** Three fixed sentences.
- **Behaviour.** P5: no cancellation. P8: no new staff reports. P11: scalar bytes and a structural retention gate.
- **B6.** "Fix the formula, continue (Recommended)": the memory stop metric is incremental `external`. 37.8 MB measured,
  against 64 MB.

**Changed files:**
- `server/notesExportRoute.ts`: route plumbing only; the frozen notes-PDF regions are byte-identical.
- New `server/notesExportLimits.ts`: leases, windows, waits and the input measure.
- `server/_core/deliveryRouter.ts`: three `FIXED_SENTENCES` entries.
- `server/notesExportRoute.audit.test.ts` and `server/downloadRoute.test.ts`: a two-line test-reset splice each.
- Five new test files.
- No client, docgen, renderer, shared, schema, db, sdk, tRPC or reporting change.

**Evidence** (`.work/hybrid-remediation/task11/claude-pass01/final-status.md`):
- **Red:** `claude-task11-red1` and `-red2` exit 1.
- **Focused:** `claude-task11-green7`, 14 files / 597 tests.
- **Mutants:** b5 20/20, and b10 27/27 on the final bytes.
- **Golden notes PDFs:** byte-equal (7 cases, pinned clock) at B1, at B6 and after the B10 fix.
- **B6:** worst in-budget render 1.27 s, against a 2.0 s stop.
- **Native N0–N10:** pass on the final bytes (`claude-task11-native3`), with a real-engine lock barrier, a real 50 s lock
  timeout and labelled injected holds.
- **Real Chromium B1–B5:** pass, served the gate-built assets.
- **Full gates `claude-task11-pass1`: all six exit 0.** 353 files / 6,955 tests; chatbot 15 / 205; both typechecks;
  build; 26 renders.
- **Reviews.** V1–V3 ran, each with a verifier.
  - V1-F1 was reproduced as HIGH and fixed in the measure. linebreak's LB21a state glued words across spaces, so a
    9,964-unit note passed every cap and rendered in about 2 s; 49 notes would take about 94 s (extrapolated).
  - The other findings were decided, out of scope or disclosed.
  - A bypass search and a conformance test (about 46.6 M checks) found nothing further over 2.0 s through the route.
  - The V4 claims audit of the final status was still running when Nick decided; its corrections are
    document-only (final-status.md §19).

Acceptance is recorded in the user disposition below (Nick's decision). There is no SHIP claim.

**Limits:**
- no cancellation (P5);
- first-come process caps: a few accounts can starve notes export, and only notes export;
- authentication holds no notes lease (P12);
- process-local per replica;
- render times are observations on this workstation;
- the NEL trailing unit (LOW);
- prototype-named tags print built-in function text (INFO, inside the frozen renderer);
- audit storage still grows (retention open);
- every carried-forward item from Tasks 9, 10, 13 and 15 still stands.

Nothing was staged, committed, pushed, published or deployed. No vault or external archive was updated. The fixture is
stopped, and no next task was started.

### User disposition — Task 11 accepted/done by decision — 2026-10-25 18:08 PDT

Nick replied "mark accepted" to the Task 11 progress report. He decided after B8 passed, while the V4 claims audit of
the final status was still running. **Task 11 is accepted/done by Nick's decision for remediation tracking, with the
limitations and deferrals below.** This is not a SHIP or production-readiness approval.

- The checkbox is now checked.
- The evidence and receipts stand unchanged; nothing is rewritten. V4's corrections, when applied, are document-only
  (`.work/hybrid-remediation/task11/claude-pass01/final-status.md` §19).

**Still open (this acceptance resolves none of them):**
- **No cancellation (P5).** A DB call that never answers keeps its lease, so notes export stays busy (503).
- **First-come process caps.** A few authenticated accounts can starve every user's notes export, and only notes
  export: two stalled readers hold all three leases, three accounts exhaust the process rate or render window.
- **Authentication holds no notes lease (P12).** Limits are process-local per replica. The production pool size
  and engine (TiDB) are not verified.
- **Render times are observations on this workstation.** The worst in-budget render was 1.27 s. Production CPU and
  contention are not verified.
- **NEL trailing unit (LOW).** A one-line change to count its printed ellipsis is offered, not made.
- **Prototype-named tags print built-in function text (INFO).** This is inside the Rule 29 frozen renderer; changing
  it needs Nick's approval.
- **Not shown natively:** uploads and package-export success. Safari/iOS/Android unverified. Word/pixels
  user-deferred, not passed.
- **Audit storage still grows.** Only creation is rate-bounded; retention is open.
- **Earlier carried-forward items:**
  - L2, L3, F1/O1;
  - `references/file-storage.md:117` (Task 17);
  - runtime-message validation and Dev/Preview body redaction;
  - the P10 carry-over and the preview gap;
  - chatbot cookie-to-fetch rotation;
  - Task 15's browser gap;
  - the Task 6/14 limits; Tasks 7/8 not reopened; no AWAITING-NICK item resolved.

**For future models:**
- The plan's decisions (P1–P12, the B6 erratum, the B10 fix record), the Global constraints and RULES.md Rule 29
  remain in force.
- This acceptance authorizes no renderer, legal-logic, form-selection, schema, client, AWS or production change.
- Only documentation and status were updated. Nothing was staged, committed, pushed, published or deployed, and no
  next task began: Task 12 is not started.

### Task 12 — preview lifecycle / response limits: implemented and verified — 2026-10-27 local

Nick approved the plan (`docs/superpowers/plans/2026-10-25-task12-preview-lifecycle-limits.md`, r5; sha256 after its
closure edit `1946c7f370a440d968da13af3085222c2aaa42c7d0408331bcd9bc635c3a5430`):
- Gate A: plan-mode exit after decisions P1–P12, three design reviews and two bounded revision rounds (r4, r5).
- Gate B: "Start Gate B of Task 12 now" (2026-10-27).
- The plan's appended §14 decision record overrides its older status lines; its H1 now reads r5.

**Decisions (P1–P12, in force):**
- **Routing (P1/P1a).** A tested link factory (`client/src/lib/trpcLinks.ts`): the `document.preview` query alone
  travels un-batched through a validation link and a bounded reader; every other operation keeps the batch link; the
  `X-Rotated-Session` handler moved verbatim as the factory's default `onResponse`.
- **Bounds (P2/P2a).** 4 MiB decoded 2xx envelope, 16 KiB refusal bodies, 15 s body idle, 60 s body total; the shared
  transport's 10 s header timer and two retries unchanged; never truncate; the decoded byte count is the only size
  authority.
- **Copy and retry (P3/P4).** One neutral client sentence ("The preview could not be loaded. Please try again.");
  server and transport envelope sentences unchanged; client-side causes and cancellations terminal, envelope errors keep
  React Query's three retries.
- **Transport (P5/P5b).** Abort-aware backoff wait; every discarded non-JSON ≥ 400 body cancelled.
- **Modal (P6/P7/P10/P11).** `subscribed: open`, `networkMode: "offlineFirst"`, `trpc.abortOnUnmount`, a
  generation-partitioned cache hash, usable data gated on a non-error result, the Alert copy rule; React Query defaults
  otherwise; Retry visible; Generate and Generate-anyway paths untouched; no new logging.
- **Session (P8).** Same-tab generation protection plus the next-render/reopen cache partition; accepted for this
  task's closure with the open cases in the disposition below.
- **Probe (P12).** Run after the pass-2 production build, in the owned fictional fixture only.

**Changed files:**
- New `client/src/lib/previewTransport.ts` (bounded reader, errors, validator, modal helpers, hash) and
  `client/src/lib/trpcLinks.ts` (link factory, validation link).
- `client/src/main.tsx`: lines 42-68 replaced by one factory call; imports adjusted; subscribers and Provider untouched.
- `client/src/pages/EstateDetail.tsx`: one import, the preview query's options, the gated `data` line and the Alert
  copy line; every frozen region byte-identical.
- `client/src/lib/trpcTransport.ts`: P5 abort-aware wait and P5b discarded-body cancel.
- Tests: new `previewTransport.test.ts`, `trpcLinks.test.ts`, `EstateDetail.preview-lifecycle.test.tsx`; T1–T4
  appended to `trpcTransport.test.ts`.
- No server, docgen, renderer, shared, schema, db, stub-suite or existing-test change.

**Evidence** (`.work/hybrid-remediation/task12/claude-pass01/final-status.md`, sha256 `0b605fdfcd526ea17870c229cd2765429c47466932680bb237960a862c35fa8c`):
- **Red:** `claude-task12-red1` exit 1 (33 failed / 13 guard passes); the fix-pass red U16.
- **Focused:** `claude-task12-focus2`, 10 files / 244 tests.
- **Mutants:** b4a 14/14, and b4a2 17/17 on the final bytes.
- **Frozen regions:** every pinned raw-CRLF region of `EstateDetail.tsx` byte-identical; only the approved hunks differ.
- **Golden outputs:** 28/28 identical (markup DOM, print HTML, mocked-jsPDF call log) for the 26 real fixtures plus two
  letterhead fixtures.
- **Full gates `claude-task12-pass2`: all six exit 0.** 356 files / 7,068 tests; chatbot 15 / 205; both typechecks;
  build; 26 renders.
- **B1 probe:** nine forms through the real modal; largest envelope 8,256 B (0.197 % of the ceiling); no documents row
  from any preview.
- **B6 real Chromium S1–S8:** pass on the final bytes: held previews abort on Escape and reopen fresh; the oversize
  refusal shows the neutral sentence with Retry and no download controls; a keystroke aborts a held request with the
  draft intact; Print and PDF work; DOCX from the preview with Escape mid-download still hands off the ZIP with no toast
  (Task 13 parity); sibling traffic completes during a held preview.
- **Reviews.** Four read-only lenses (code quality, security, silent failure, probate integrity): no Critical or
  Important; six low findings, all dispositioned (one one-line production fix proven red → green, test-strength edits,
  a record-shape rule for browser evidence).

Acceptance is recorded in the user disposition below (Nick's decision). There is no SHIP claim.

**Limits:**
- browser abort is not server cancellation (the server finishes a held response after the client closes);
- the ceiling bounds what the app reads, not what a fast link delivers before the reader cancels;
- P8 cases open for pre-rollout review (post-final-check window, cross-tab logout, server expiry/revocation, no-reload
  account change);
- outstanding, not passed: the understated-header-plus-oversize test, the real-handler mid-body rotation test, the
  Unicode-heavy and image/DOCX-letterhead measurements, heap use, mobile/WebView, Word/pixels;
- the Express 429 body now shows the neutral sentence; the dev debug collector reads whole bodies in dev/Preview;
- pre-existing, observed: the Ready-to-preview dialog stays mounted behind the modal; zoom persists across opens; a real
  tab/visibility change refetches the open preview;
- every carried-forward item from Tasks 6, 9, 10, 11, 13, 14 and 15 still stands.

Nothing was staged, committed, pushed, published or deployed. No vault or external archive was updated. The fixture is
stopped, and no next task was started.

### User disposition — Task 12 accepted/done by decision — 2026-10-27 13:43 PDT (receipt)

Nick replied to the Task 12 handoff with the decision list below (verbatim). **Task 12 is accepted/done by Nick's
decision for remediation tracking, "Accepted by Nick with known limitations".** This is not a SHIP, deployment or
production-security approval.

> My decisions:
>
> 1. Acceptance: Accept Task 12 as done for task-list progress on the isolated review branch, with the explicitly recorded deferrals below. Record “Accepted by Nick with known limitations.” This is not a SHIP, deployment or production-security approval.
>
> 2. P8: I accept the implemented same-tab generation protection and next-render/reopen cache partition for this task’s closure. Do not claim immediate or comprehensive session protection. Keep the post-final-check window, cross-tab logout, server expiry/revocation and unsupported no-reload account-change cases open for review before live rollout.
>
> 3. Deferred minors and missing evidence: Leave the duplicate types/error classes alone. Retain the understated-header-plus-oversize test and real-handler mid-body rotation test as outstanding—not passed. Also retain the missing Unicode-heavy and image/DOCX-letterhead measurement cases, unmeasured heap use, mobile/WebView checks and deferred Word/pixels. The small measured envelopes do not prove headroom for those untested cases.
>
> 4. Queue and preferences: Append the drafted Task 12 queue entry, update its checkbox to done, and replace “NOT accepted” with my acceptance and its limitations. Record this decision/preference list in the repository’s handoff documentation. Preserve historical evidence and other task statuses.
>
> 5. Documentation: Correct the plan heading to its actual revision, r5. Keep the verification methods and their disclosed limitations as recorded. Do not change application code merely to tidy deferred minors.
>
> 6. Boundaries: Correctly skipped the external Agent Archive service—do not create an account. No court wording, formatting, rendering, legal/selection, schema, AWS or production changes. No staging, commits, pushes, checkpoints, publication or deployment.
>
> Return the updated disposition and stop. Do not start another task yet.

- The checkbox is now checked.
- The evidence and receipts stand unchanged; only documentation and status were updated (this queue, the plan's H1 and
  §14, final-status.md's status header, §0 and its §6/§8/§9/§10/§11 wording, the pass ledger; the session plan copy
  outside the repository had its H1 corrected too).

**Still open (this acceptance resolves none of them):**
- **P8 before live rollout.** The post-final-check window, cross-tab logout, server expiry/revocation and the
  unsupported no-reload account change. No immediate or comprehensive session protection is claimed.
- **Outstanding, not passed.** The understated-header-plus-oversize test; the real-handler mid-body rotation test; the
  Unicode-heavy and image/DOCX-letterhead measurement cases; heap use; mobile/WebView checks; Word/pixels. The small
  measured envelopes do not prove headroom for those untested cases.
- **Left alone by decision.** The duplicate `FetchLike` declarations and the two error classes.
- **Disclosed.** Browser abort is not server cancellation; the ceiling bounds what the app reads; the Express 429 copy;
  the dev debug collector; the pre-existing dialog, zoom and focus-refetch behaviours.
- **Earlier carried-forward items:** the Task 13 preview-path microtask gap (P9) and the rotation/message-listener gap;
  L2, L3, F1/O1; `references/file-storage.md:117` (Task 17); runtime-message validation and Dev/Preview body redaction;
  chatbot cookie-to-fetch rotation; Task 15's browser gap; the Task 6/14 limits; Tasks 7/8 not reopened; no
  AWAITING-NICK item resolved.

**For future models:**
- The plan's decisions (P1–P12), its §14 decision record, the Global constraints and RULES.md Rule 29 remain in force.
- This acceptance authorizes no renderer, legal-logic, form-selection, schema, client, AWS or production change, and
  no code change to tidy the deferred minors.
- Only documentation and status were updated. Nothing was staged, committed, pushed, checkpointed, published or
  deployed, no external account was created, and no next task began: Task 17 is not started.

### Erratum (append-only) — Task 11 record, notes first-come caps wording — 2026-10-27 18:39 PDT

Recorded during the Task 17 closeout on Nick's instruction. The historical Task 11 record above (`:691-692`) is
unchanged; this entry corrects its lease arithmetic. That record says "two stalled readers hold all three leases, three
accounts exhaust the process rate or render window". In the implementation, three stalled requests can occupy the three
process leases: `server/notesExportLimits.ts:40` sets `globalLeases: 3`, `admitNotesExport` takes one lease per call
(`server/notesExportLimits.ts:123-125`), the handler calls it once per request (`server/notesExportRoute.ts:195`), and
`track` adds references to that same lease rather than taking a new one (`server/notesExportLimits.ts:168-183`). Two
requests from one account can occupy that account's two leases (`server/notesExportLimits.ts:41, 156`). The process and
account rate and render windows (`server/notesExportLimits.ts:43-46, 157-158`) can still be exhausted by a few accounts,
as the record says. Source: the Task 17 overclaim review, finding A1
(`.work/hybrid-remediation/task17/claude-pass01/review/overclaim-hunter.md`), verified by own read of the cited lines;
`references/file-storage.md` section 12 states the same arithmetic. No code was changed.

### Task 17 — accurate documentation: implemented and reviewed (documentation only) — 2026-10-27 local

- Scope: `references/file-storage.md` (re-anchored in place; the five false guarantees corrected; about 120 citations
  re-anchored; sections 10–15 added; deployment precondition 8; superseded list fixed; template text byte-identical),
  `docs/operations/storage-provider-due-diligence.md:60`, `docs/runbooks/storage-incident.md` (§3.B.4; §4.2
  implemented-state addendum), `docs/architecture/rule-10-conformance-baseline.md:34`. `README.md` unchanged (D9: the
  MinIO claim stays unverified). No application, test, schema, UI, configuration, `RULES.md`, `docgen.ts`, renderer,
  `shared/types.ts`, capture or legal-text change; 416 preserved source and test files hash-equal before and after.
- Documents the transactional generation audit (`GenerationCommitUnconfirmedError` → 500), the per-route body caps,
  the notes audit trail and limits, staff failure reporting, the client transport, the Task 6 binding (10 minutes from
  the signed issue timestamp; revocation qualified), the preview transport, and the Node 24 residual as the Task 6
  receipts record it (Node v24.13.1 red reproduction; scanner cases without RangeError; not re-executed); marks
  IAM/KMS/bucket/AWS/production facts unproven; Task 19 blocked.
- Reviews, by round: round one, two lenses on the first edited bytes (dropped-limitation hunter 6 findings; integrity
  gate none, two wording items); the overclaim hunter on the bytes after those fixes (5 findings; its first attempt
  hung and was stopped); a bounded final-fragment pass on the four lines reworded after the lenses (one low-severity
  attribution finding, fixed). Every finding fixed in the documents or disclosed. Citation checking was mechanical
  (paths, ranges, 101 anchors of 449); the frozen-anchor check did not pass as designed (59 misses, preserved);
  semantic verification covered the claims the reviews and the claim table opened, not all 449 citations.
- Limitations carried forward unchanged: Word/pixels user-deferred-not-passed; Task 14 STILL-BLOCKED; Tasks 7/8 open,
  not reopened; Tasks 6/14 not accepted; Tasks 10, 11, 12, 13, 15 residuals by queue line; no AWAITING-NICK item
  resolved. The Task 11 lease wording is corrected by the append-only erratum above.
- Evidence: `.work/hybrid-remediation/task17/claude-pass01/closeout.md` (sha256 in the handoff), `manifest-closeout.sha256`
  sha256 `7e6d443674fbc3c8d4cfea876d2eb869fe9d77cf8ac9338db10393ec50a50e42`, historical `final-status.md` sha256
  `f8885fe33fba79872e8afc634d9c3b66c50fe00f5814c69c5800c2ea6a94d9a3`, `outputs/task17-documentation-report-2026-10-27.md`
  sha256 `d012dc6ad78db2f6fa754218bac11d215f5307f21c72443fb53b9b2078e735dd`, `docs-only-closeout.diff` sha256
  `7b24371d385a4e01754661f6f597247da98b693703781620cdb801cf90a56607`. Nothing staged, committed, pushed, checkpointed,
  published or deployed; no external account created; Task 18 not started.
- Acceptance (decision record, the one bullet added to the drafted disposition at acceptance): Nick's one-word reply
  "accept" to the closeout handoff, recorded 2026-10-28 07:41 PDT, under the condition stated in `closeout.md` section
  10 (finding A1, corrected, not treated as material). Accepted within its documentation-only scope only: remediation
  tracking, not a SHIP, deployment, security or compliance approval; no other task accepted; no blocker cleared; every
  limitation above stands. The acceptance is also recorded in `closeout.md` section 11 (append-only; its sha256 after
  that addendum is in the plan's section 16 and in the handoff) and in the plan's section 16. Task 18 not started.

### Task 18 — security safeguard reverification: executed and accepted (verification only) — 2026-10-28 local

- Scope: queue item 18 only. Gate A (read-only investigation, plan saved write-once as
  `docs/superpowers/plans/2026-10-28-task18-security-safeguard-reverification.md`, Gate A sha256 `2eb720d57fcfb7348455c090549bd6736d46b172ae7867113ad26e29138e9828`,
  decision record appended at acceptance) and Gate B (execution on Nick's explicit authorization) in
  `.work/hybrid-remediation/task18/claude-pass01/`. No application, test, schema, configuration, renderer, legal,
  `RULES.md`, capture or receipt file changed; nothing staged, committed, pushed, checkpointed, published or deployed;
  no provider, AWS, Office or install action. Identity: branch `security/hybrid-vault-review`, HEAD
  `db0d7e9161bc3899b75858fab58bce54e3d5247a`, index empty; B0 and B6 identity re-proofs hash-equal on 615 census files.
- Gates (runner unchanged, fresh labels): six focused gates green (p1 410, p2 666, p3 690, p4 677, p5a 272, p5b 138
  tests); full serial gate `claude-task18-pass1` green — check; tests 356 files / 7,068; chatbot-check; chatbot-tests
  15 / 205; build (deterministic `dist/public/index.html` `8fd43766…`); render (26 frozen fixtures); every freeze
  line `FROZEN_LEGAL_SOURCES_UNCHANGED`.
- Probes (pass-local QA, importing no application code except `server/_core/env.ts` in scrubbed children): P1/P2
  static (SDK constructors and imports only in `storageProvider.ts`; 0 KMS references; 14 `storagePut` sites;
  `PutObjectCommand` only in the provider; no copy/multipart/presigned-POST); P3 tier matrix (120 cells: every
  fail-closed tier refuses 9 of 10 fictional profiles including the localhost profile; on the dev/test tier the six
  `AWS_*` names with no `STORAGE_*` name complete the seeded `us-east-1` profile — REG-52 observed).
- Journeys on the resumed fictional fixture with the pinned Task 13 harness (bundle identity: build manifest =
  served filesystem = browser-loaded assets): J1 P1 native delivery correlated by attempt (started/finished SHA =
  download = capture); same-descriptor re-POSTs inside the lifetime byte-identical except core timestamps on the cookie
  and Bearer paths; J2 P7 warn-only draft (empty facts as blanks, `Generate anyway` enabled, estate revision 7 → 7);
  J3 altered-binding and superseded-descriptor refusals 409 with no audit row and no read; J4 owner retained read 307
  (`private, no-store`) → 200 exact 1,311-byte will, other account 404, no session 401, no provider call for refusals;
  J5 armed `stored_objects` / `estate_notes` read faults refused with the fixed sentences and exactly one
  acknowledged staff row each, unarmed retries 200; J6 provider PUT counters 0 throughout, no generated row retains
  bytes, fixture deltas inside the plan's single allowlist, nothing restored.
- Independent review (B8, bounded read-only): `sound-with-changes` — 0 blocking, 0 high, 3 medium, 6
  informational, all documentary, applied as an appended corrections section (`b8-review.json`).
- Limitations and deferrals carried forward unchanged: Word/pixels user-deferred-not-passed; Tasks 6/7/8/14 open
  (D13/D14 unbound); REG-01…REG-59 preserved (REG-48 superseded by the Task 17 acceptance); not exercised: browser
  cross-site submission, native expiry/digest/started-ACK/lost-COMMIT refusals, the navigation-form stale re-POST,
  the P19 DOCX, Task 15 scenario B, preview in the browser, owner attachment view on a cookie session, rotation in
  the browser, second-click suppression, delete/purge paths, TiDB; deployment facts (IAM/STS trust and policies, KMS
  key identity and `kms:Decrypt` scoping, bucket state, real 403/404, versioned purge, production pool/engine/
  migrations, `GENERATOR_RELEASE`, deployed `NODE_ENV`) remain Task 19. New report-only observations for Nick's
  classification: REG-51…REG-58 (Gate A) and REG-60 (Bearer-only session: attachment "View" navigation refused 401,
  fails closed), REG-61 (the other fictional estate, one object queued for destruction: export prepared with
  `fileCount: 1`, delivery answered 500 via the staff-report path; cause unverified). Deviations recorded: two
  predecessor verifiers not run (they write outside the pass; reproduced inside it); one unplanned export of the
  other fictional estate; P7 used through its warn-only question although "not required for this estate".
- Evidence: `final-status.md` (sha256 before the acceptance addendum `69a37c8fab14af24ab95a623c546ea06a81730efdb6a8acf2e69d24484570535`), `manifest.sha256`
  (194 entries, sha256 `13c9009f23592bdbbf3ee7187c513c97743e67ec7f4183ece45131ab1d0f7036`),
  `outputs/task18-security-safeguard-reverification-2026-10-28.md` (sha256
  `dce2703929cd194954ca5f22c75a4f2521f7525ad3c45f612a19721a779da930`, unchanged by this acceptance).
- Acceptance (decision record): Nick's one-word reply "accept" to the Gate B handoff, recorded 2026-10-28 13:16 PDT. Accepted
  within its verification-only scope: remediation tracking, not a SHIP, deployment, security or compliance approval;
  no other task accepted; no blocker cleared; every limitation above stands; no hybrid Step 4; Task 19 still blocked;
  Task 20 not started. Also recorded in the plan's section 15 and in `final-status.md` section 7 (append-only).
