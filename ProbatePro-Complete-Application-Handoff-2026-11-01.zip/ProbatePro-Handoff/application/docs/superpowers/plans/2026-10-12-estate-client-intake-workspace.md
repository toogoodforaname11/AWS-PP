# Plan: Estate Client-Intake Workspace

1. Expand the shared client-intake payload and apply-selection contract with backward-compatible defaults for structured estate facts and repeatable contact/inventory rows.
2. Update the public client intake form to use the supplied template’s sections and client-friendly repeatable rows, retaining the existing submission/revision behavior.
3. Extend selected-fact approval so it validates selected rows, writes only selected client-reported rows, uses encrypted inventory writes, and retains revision conflict handling.
4. Create a per-estate Client Portal tab with the existing submission review plus scoped access controls; retain the global executor portal page for cross-estate management.
5. Add focused regressions for the portal form, item-level/all-verified review, selected application behavior, and tab/deep-link availability.
6. Run focused red-green tests, TypeScript, full serial tests, build, whitespace and scope review, runtime health, audit/tracker update, then checkpoint.
