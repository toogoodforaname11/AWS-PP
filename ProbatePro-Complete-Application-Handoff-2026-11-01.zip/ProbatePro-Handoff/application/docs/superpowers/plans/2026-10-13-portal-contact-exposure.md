# Portal Contact Exposure Repair Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ensure a bearer-link client can complete the intake without being able to retrieve or view estate contacts.

**Architecture:** The portal link remains scoped to one estate for its submission workflow, but the public portal surface exposes only the client form and the minimal estate context it already needs. Remove the contact-list procedure and its UI card rather than attempting to filter sensitive contact rows client-side.

**Tech Stack:** React 19, TypeScript, tRPC 11, Vitest.

**Spec:** User-reported portal retest issue on 2026-10-13: “Anyone with the link can still see the estate's contacts.”

## Global Constraints

- Treat the bearer-link portal as untrusted for estate-contact disclosure.
- Do not access, inspect, or modify real estate records while validating this repair.
- Preserve the separate client-intake submission and lawyer-review workflow.
- Do not alter court-form content, legal logic, document layout, or unrelated portal features.
- Use a focused red/green regression, then typecheck, serial tests, production build, whitespace, and runtime health before checkpointing.

## Review Focus

- A session with a valid portal link must have no `contacts` tRPC procedure to call.
- The portal UI must not request or render an estate Contacts card.
- The client must still receive the current form, lawyer-authored questions, and the access holder’s own prefill values.
- Unauthenticated portal calls must remain denied for the retained protected procedures.
- Existing lawyer-side contact management and intake review must remain unchanged.

---

### Task 1: Remove bearer-link contact disclosure

**Files:**
- Modify: `server/routers.ts: portal router`
- Modify: `client/src/pages/Portal.tsx: PortalContent`
- Modify: `server/portal.session.test.ts`
- Create: `client/src/pages/Portal.test.tsx`

**Interfaces:**
- Consumes: `portalProtectedProcedure` and `ctx.portalSession`.
- Produces: a portal router with no contact-list endpoint and a portal screen with no Contacts data request or rendered Contacts card.

- [ ] **Step 1: Write failing regressions**

Add a server assertion that a caller cannot resolve a `portal.contacts` procedure even with a valid portal session. Add a portal-page regression that mocks a valid session and confirms the client intake is present while the Contacts heading and contact query are absent.

- [ ] **Step 2: Run the focused regression to verify it fails**

Run: `pnpm exec vitest run server/portal.session.test.ts client/src/pages/Portal.test.tsx --maxWorkers=1`

Expected: FAIL because the portal router exposes `contacts` and `PortalContent` calls it.

- [ ] **Step 3: Remove the portal contact endpoint and card**

Delete `portal.contacts` from `server/routers.ts`. Remove the contacts query, role-label import, and Contacts card from `Portal.tsx`, retaining only the data required to render the client-intake form and its minimal estate context.

- [ ] **Step 4: Run the focused regression to verify it passes**

Run: `pnpm exec vitest run server/portal.session.test.ts client/src/pages/Portal.test.tsx --maxWorkers=1`

Expected: PASS.

- [ ] **Step 5: Verify the retained portal boundary**

Run the existing portal session and client-intake tests, then `pnpm check`, `pnpm test -- --maxWorkers=1`, and `pnpm build`. Confirm no unexpected contact query remains in `Portal.tsx`, `git diff --check` succeeds, and the unauthenticated local/preview root responses remain healthy.

## Self-Review

- The repair removes the server capability, not merely its display.
- The change does not modify lawyer-side contact APIs or estate data.
- Tests exercise both the capability boundary and the client page’s absence of a contact data request.
