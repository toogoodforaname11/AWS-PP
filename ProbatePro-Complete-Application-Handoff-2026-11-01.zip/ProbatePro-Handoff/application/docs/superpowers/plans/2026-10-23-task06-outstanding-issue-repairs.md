# Task 6 outstanding-issue repairs implementation plan

> **For agentic workers:** Execute only these Task 6 repairs under Nick's 2026-10-23 “Resolve task 6 issues” instruction. Use available shared workflow workers with disjoint file ownership. User constraints override generic commit/worktree instructions. No next task or prompt.

**Goal:** Resolve outstanding Task 6 plumbing and evidence defects without changing court-document output or legal/selection behavior.

**Architecture:** Keep signed content-bound delivery and existing admission/snapshot semantics. Fix transport overhead only on the single-form route; replace the digest timestamp regex with lossless linear scanning; bind to stable local source/build content in addition to the existing release string; tighten diagnostics/test controls. Attempt native read-only pixel diagnostics only with clearly task-owned Word instances.

**Tech stack:** Existing TypeScript/Express/Vitest/JSZip/Node crypto/fs and local QA helpers. No new dependency, schema, deployment or AWS configuration.

**Spec:** Task 6 handoff `.work/hybrid-remediation/task06/claude-pass01/final-status.md`; original/revised Task 6 plan; Rule 29; six focused investigations in `.work/hybrid-remediation/task06/manus-repair01/`.

## Global constraints

Preserve `security/hybrid-vault-review` at HEAD `db0d7e9161bc3899b75858fab58bce54e3d5247a`, dirty source and empty index. No Git mutations, publishing, other project or production worktree changes. No production/AWS/credential access, `.env` values, secret searches, migrations or schema changes. No docgen/renderer/wording/format/legal-selection edits or new completeness blocking. Preserve required coherent generation effects, lost-acknowledgement truthfulness, manifest authorization, generated-byte non-retention and all four approved existing output behaviors. No automatic acceptance of Task 14, Task 6 or pending Nick decisions.

## Review focus

1. Large timestamp start tags must not crash or hide non-timestamp drift: linear lossless scanner tests including 8 MiB and malformed input.
2. Formerly legal 8,192-byte requests including existing attemptId must still work with binding: JSON/form exact/over and chunked tests; other routes unchanged.
3. Same source/build across restart/replicas must share identity, different content must not: deterministic content fingerprint tests, no random identity or runtime default secret.
4. Expected refused deliveries must log canonical form only and preserve 409: exact no-leak assertions and contained test noise.
5. Re-zipping controls must prove actual package members/content: non-vacuous media assertions, real renderer parity and frozen hashes.

## Connected features

The pre-edit connected-feature matrix is `.work/hybrid-remediation/task06/manus-repair01/preflight.md`. Recheck every row after applicable edits: preparation/delivery; drafts/Generate anyway; replacement/archive/expiry; body/parameter/CSRF/auth budgets; release/keys; digest/media; row ordering; safe errors/audits; owned native/UI; Word pixels; test mocks and line endings.

## Repair steps

- [ ] **Timestamp digest:** modify only `server/formDeliveryBinding.ts` and relevant unit tests. Keep ZIP entry serialization/tags, raw-byte handling and two timestamp-text-only normalizations. Replace CORE_TIMESTAMPS with a nonrecursive forward scanner preserving all other bytes/attributes. Verify stress no RangeError, quoted-angle handling, malformed preservation, exact accepted-fixture parity and real package drift.
- [ ] **Transport overhead:** modify only `server/_core/deliveryRouter.ts` and related focused tests. Keep pre-binding request budget 8,192 bytes; form-download URL encoding gets +157 (8,349), JSON gets +161 (8,353), matching declared-length guard and parsers. Export/notes remain 8,192, parameterLimit remains 20, binding stays required. Add real signed boundary, chunked/header-only/one-byte-over, retained guards and incomplete-draft regressions. Do not add generation-time size/completeness refusal.
- [ ] **Artifact identity:** add a small Task 6-only helper/test, without changing frozen docgen GENERATOR_RELEASE or audit fields. Make issuance and verification use the same stable artifact/source fingerprint in addition to existing release identity. Loaded bundled ESM module bytes identify production build; source-mode fingerprint must include relevant server/shared source content, not only the helper's unchanged bytes. Cache for process lifetime; no PID/time/random fallback, no secret reads or external metadata. Missing artifact bytes fail safely before commit/costly reads. Verify same-content across paths/restarts, changed-content release refusal, and bundled production artifact behavior in an offline probe.
- [ ] **Diagnostics and controls:** add canonical form attribution to the binding-refusal log in `server/downloadRoute.ts`, and adapt exact tests. Contain/assert expected stale-render logs in race tests. Strengthen re-zipped template tests to compare all non-body members plus canonical body identity. Preserve existing fictional fixture and test-only signing setup unless a concrete unsafe behavior is reproduced; no repo-wide renaming or production fallback.
- [ ] **Word evidence:** phase-stamp a new QA-only diagnostic, not application renderer changes. Snapshot existing Word processes; do not attach/close user Word. If none, launch one isolated bounded macro-disabled read-only probe against fictional B_LETTER_TEXT; identify COM stage and only newly attributable process. No settings/profile/registry/install changes. On a repeated hang, stop only attributable owned process, preserve exact blocker, do not loop. If successful, render matched before/after cohorts and compare native page count/geometry/raw pixels; otherwise leave evidence open.
- [ ] **Verify:** run focused red/green through the scrubbed runner, then full root/chatbot typecheck/tests/build/frozen renders serially on stable final source. Compare changed-file EOL and protected hashes; actual UI/native verification only through guarded owned fixture. Independent review of full task-only delta and new files. Record resolved vs unresolved with exact evidence, no overall SHIP statement.

## Explicit unresolved freeze boundaries

INT-1 can change paragraph/recipient ordering when unordered collections are reread. Arbitrary ORDER BY or sorting would alter emitted sequence and possibly first-contact selection, so it is not authorized under the current freeze. Signed full ordering hints would expand protocol/body scope and require a separate reviewed policy; a content hash alone cannot reconstruct order. Keep INT-1 open unless controlled permutation proof yields a freeze-compatible fix; no production TiDB query.

The pre-existing docgen merger's backtracking and slash-excluding Relationship regex require direct frozen-renderer repairs or a separately approved calibrated template-admission policy. Do not edit docgen or invent caps/refusals and call these resolved. Surface the exact separate approval needed. Correct documentation status metadata only as current work evidence, without rewriting earlier acceptance receipts or ratifying alleged historical approvals.

## Handoff

Fresh task-only evidence, source hashes/EOL/diff, commands/counts, UI/native/pixel limits and independent-review findings go under `.work/hybrid-remediation/task06/manus-repair01/`. Preserve earlier handoffs. Update the queue with the new repair disposition only after verification, without accepting missing predecessor/evidence. Deliver a concise resolved/still-blocked decision and request only the material frozen-scope approvals still needed. Stop; no Task 7/15 execution.
