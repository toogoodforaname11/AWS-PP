# Task 10 — Notes delivery audit and foreign-owner denial — plan r3

**Status:** plan r3.
- **Gate A was approved by Nick on 2026-10-24** (plan-mode approval). This repository copy is the only change it
  authorizes.
- **Gate B (implementation) is NOT approved yet.**
- Task 10 is not done, and its queue checkbox stays unticked.

Queue item 10 only (not hybrid Step 4). Nothing is implemented yet. Not in scope: Task 11/12/13 work, other prompts,
commit/stage/push/publish/deploy, production or AWS, vault updates, and marking Task 10 done.

## Approval gates

1. **Gate A — plan save only (approved 2026-10-24).** Plan mode allowed writing only the session plan file, so this
   repository copy was saved after the plan-mode exit was approved.
   - Its body is that approved r3 text, with this status block and the review record (end of file) added.
   - It is new, untracked and LF. Its SHA-256 is reported in the session handoff, and work then **stopped**.
2. **Gate B — implementation.** Steps 0–11 start only after Nick's separate, explicit go-ahead.

## Changes from r2 (Nick's second review, 2026-10-24)

1. **T7 fixed.** A synthetic `error` after `close` is no longer injected.
   - Node 24.13.1 emits none after a response is destroyed (probes C/E), so the fake emitter needs no stand-in
     listener.
   - Route-owned listeners are identified and asserted removed by identity.
   - Error-before-close orderings stay covered. Production cleanup is unchanged.
2. **Task 13 state refreshed** from its `claude-pass02` handoff and the `claude-task13-pass3` receipt; the client
   hashes are updated.
3. **Protected, with no client edits:** `client/src/components/PreGenerateDialog.tsx` and Task 13's r3 Notes feedback
   (D11/D12).
4. **Cleanup aligned with Task 13 r3:** `audit_log` is append-only. New rows are recorded exactly and never deleted.
5. **Kept unchanged:** D1–D4 and the narrow native-error verification exception.

## Changes from r1 (Nick's review, 2026-10-24)

1. **Response errors are handled, not declared unreachable.** The route owns its `finish`/`close`/`error`
   listeners, uses one terminal guard, removes the listeners at `close`, and never sends a second response.
   - Every ordering is tested at emitter level, plus an injected emission on a real response.
   - A runtime probe on Node 24.13.1 is recorded (§4).
   - The only exception requested is narrow: no *Node-originated* response `error` could be triggered natively.
2. **Attempted writes are kept separate from durable rows.**
   - Tests are labelled honestly: mocked writer, unconfigured database, injected driver fault, real-engine lock
     timeout.
   - Ordering is proven by an identified INSERT/lock/zero-byte barrier, never by `createdAt, id` sorting.
   - QA-only bounded waits run before assertions and before cleanup.
3. **Reproducible, failure-safe verification.**
   - Every note timestamp is pinned, and locale and timezone are checked in the golden capture.
   - T5's socket sequence is spelled out, and N8 is observational.
   - Every owned lock, socket, writer, fault control and exact-row cleanup sits in a `finally`.
4. **Overclaims corrected.**
   - Awaiting plus the 200/min limiter does **not** bound unresolved concurrent writes; this is a Task 11
     limitation.
   - The old M6 (listeners attached before headers) is an equivalent mutant under the guard. It is now part of the
     design, not a must-kill mutant, and no working code is weakened to kill it.
5. **Unchanged:** D1–D4; the document/PDF freeze; statuses; Task 15 reporting; missing-data warn-and-proceed;
   isolation; deferrals. No filename, renderer, schema, client or next-task change.

## Context

`POST /api/notes/export-pdf` (`server/notesExportRoute.ts`) is the only delivery route that sends bytes with no audit
(`references/file-storage.md:116` says so). It has no required pre-byte `started` event, no transport outcome, and no
`idor_attempt` for a foreign owner.

The form route (`downloadRoute.ts:164-177, 383-407`) and export route (`downloadExportsRoute.ts:75-88, 119-147`)
already do all three. **Root cause:** Step 2 moved the handler to the POST delivery router, and Tasks 14/15 added its
error handling, but the audit gate was never added. Line 128 calls `sendAttachment(res, await notesPdf(...), …)` with
no recorder and no outcome callback.

**Goal:**
- Byte-identical PDFs, released only after a `started` write acknowledged exactly `true`.
- At most one terminal event scheduled per real attachment attempt.
- One safely scoped denial audit attempt.
- Unchanged public answers, renderer, filename, body caps and notes CRUD.

## State verified at planning time (2026-10-24 09:54–10:45 PDT, refreshed 17:48 PDT; read-only)

**Repository and queue**
- Branch `security/hybrid-vault-review`, HEAD `db0d7e9161bc3899b75858fab58bce54e3d5247a`, index empty.
- 78 modified and 64 untracked entries at 17:48, equal to Task 13's `close-state.txt`; preserved. Task 13's r3 added
  `PreGenerateDialog.tsx` and its r3 amendment plan.
- One pre-existing stash entry (2026-09-06, on `main`) belongs to neither task and is never touched.
- No project `AGENTS.md`; `.cursorrules` overrides nothing here.
- RULES.md Rule 29 (lines 1966-1980) is the document freeze only, with no "three exceptions".
- Queue: 1/2/3/16/4/5 accepted; 15 and 9 done by Nick's decision with recorded gaps; 13 unchecked.
- **Task 13 (current):** `.work/hybrid-remediation/task13/claude-pass02/final-status.md` (17:31) says "implemented
  and verified under the approved r3 amendment … NOT accepted". Plan: `2026-10-24-task13-r3-amendment.md`,
  `f6299fef…`.
  - Gates `claude-task13-pass3`: check, tests, chatbot-check, chatbot-tests, build and render all exit 0.
    347 files / 6,784 tests; 15 files / 205 tests; 26 renders verified; `FROZEN_LEGAL_SOURCES_UNCHANGED`.
  - Fixture restored and shut down (`close-state.txt`, 2026-10-25T00:28Z): no listener on 43117/43316/61096, no
    owned PIDs. Re-checked at 17:48: no listener on 43117/43316.
  - All seven `final-r3-hashes.sha256` entries match the current tree (`sha256sum -c` OK).
  - Task 13's own open item (the VSA532 "Show it" narrowing) is not Task 10's to decide.
  - **Peer session:** `ListAgents` still shows one peer in this worktree as *busy*. Task 13's work is closed, but
    every edit and gate phase re-verifies hashes first (step 0).
- **Task 13's Notes contract, preserved and not edited:**
  - NotesTab now receives the estate page owner `estate:${estateId}` from `AnimatedTabs`, with per-instance slots.
    Its feedback survives tab switches within an estate (D11).
  - Feedback currency follows the session generation. A same-user token rotation mid-download shows the GENERIC
    failure, and a refusal finished after a token change is downgraded to GENERIC (D12, r3.1 F7).
  - `NotesTab` is exported for tests.
  - The Export PDF descriptor and transport are unchanged.

**Runtime facts**
- Node v24.13.1, pdfkit 0.19.1, express 4.22, mysql2 3.15, vitest 2.1.4.
- `getDb()` gives a default mysql2 pool: 10 connections, no acquire timeout, unbounded queue.
- `createAuditEntry` returns `true` whenever its insert does not throw, `false` when the DB is unconfigured or the
  insert throws. It never rejects.
- No in-app code reads `audit_log`.

**Review graph**
- 2,416 nodes / 72 files at HEAD.
- It misses the untracked `downloadExportsRoute.ts` caller of `recordIdorAttempt` and other untracked modules. Those
  are treated as unindexed, not unused.

**Read-only probes**
- **F1:** `ERR_INVALID_CHAR` from the notes filename for a deceased name with a character above U+00FF or CR/LF.
- **pdfkit:** two renders under a fixed clock are byte-identical (file ID = md5 of `CreationDate`).
- **Response events on Node 24.13.1** (ephemeral loopback, no files written):

| Probe | Observed |
|---|---|
| A — normal `end(1 KB)`, keep-alive | `finish → close(destroyed=true)` |
| B — `write()` after end, inside `finish` | No `error` event; `close` follows |
| C — `write()` inside `close` | No `error` event |
| D — 64 MiB body, client pauses then resets | `finish` fired before the reset. Loopback buffering absorbed it, so a native close-before-finish is not reproducible on this machine. |
| E — `end()` after the client left | Already `close(destroyed=true)`; `end` returns; no `error` |
| F — `setHeader` non-Latin-1 | Throws `ERR_INVALID_CHAR` with `headersSent=false`; the 500 that follows emits `finish → close` |

**Fingerprints** (re-verified in step 0; any drift stops work)

| File | sha256 prefix | Line endings |
|---|---|---|
| `server/notesExportRoute.ts` | `e043b974054ab2a4` | CRLF ×137 |
| `server/affidavitHistory.ts` | `356178680c65c36d` | MIXED: 467 CRLF + 173 LF; lines 587-640 CRLF |
| `server/deliveryBearerAuth.test.ts` | `8ef9be840e33612d` | LF |
| `server/_core/deliveryRouter.ts` | `6d0f009ba606cfaf` | |
| `server/_core/trpc.ts` | `6b2e719866102e99` | |
| `server/exportFailureReporting.ts` | `81429bc961d237e9` | |
| `server/docgen.ts` | `7224c88e0f910911` | |
| `shared/types.ts` | `9a60dfb7e6c1624d` | |
| `drizzle/schema.ts` | `25f7c36250e816db` | |
| `RULES.md` | `648f49a7ac8a9e8b` | |
| `server/downloadRoute.test.ts` (not edited) | `4adb4c5b21677d36` | MIXED 2124/42 |
| `docs/superpowers/plans/2026-10-21-hybrid-remediation-queue.md` | `b92ffdab9c820a6a` | LF |

**Protected client and Task 13 files.** Read-only for Task 10; full SHA-256 values, all equal to Task 13's
`final-r3-hashes.sha256`. The old `d6d4…` / `6909…` values from 10:00 are superseded.

| File | sha256 |
|---|---|
| `client/src/pages/EstateDetail.tsx` (CRLF) | `efc61382917a939a931eab4e5195eaa50de3180a5bfe14825cb0adf23fd48ac6` |
| `client/src/lib/attachmentDelivery.ts` (LF) | `af06d770b5179a66b5e3dc0b89be584a2fb98c948b651923b7abc7a51e08933d` |
| `client/src/components/PreGenerateDialog.tsx` (CRLF) | `aeb48a9a148f091779ae68e2e2f451d15705b6b4d5d8ac41cbdf6162bb75bc8b` |
| `client/src/lib/attachmentDelivery.test.tsx` | `0420b87740dbdcd517b4603760ea810ccfbb8f305059b1904326163f8dda1590` |
| `client/src/pages/EstateDetail.task13-recovery.test.tsx` | `8b813fe5862858aa239587c84d9300b58694b47fbbdfce7ce989a338f5607f8f` |
| `docs/superpowers/plans/2026-10-24-task13-r3-amendment.md` | `f6299fef95fb70cfeab0f7f3150688f2304e7196fe521e0dd287718b19929468` |
| `client/src/lib/fallbackSession.ts` (LF) | `4dbfdcd6bd9441a8f1d03fdb0a9ee957ae33fd71fe2b067be9cc1aa3362d2a43` |

Frozen regions of `notesExportRoute.ts`, kept byte-identical:
- TAG_LABELS, lines 24-30 (`0b6bcf0934b60e2a`);
- `notesBody`, lines 32-36;
- `notesPdf`, lines 40-101 (`042fdbca63249450`);
- estateName/fileName, lines 126-127;
- the call text `notesPdf(estateName, estate.fileNumber, notes)`;
- the catch block, lines 129-136.

## Approved decisions (Nick, 2026-10-24; reaffirmed in the r1 review)

- **D1** Statuses unchanged.
  - Missing or alias id → 404 "Estate not found"; foreign exact id → 403 "Access denied" (sibling parity).
  - Accepted trade-off: confirming that an id the caller already holds exists. Ids are 21-character nanoids.
- **D2** New `notes_delivery_{started,finished,aborted,failed}` events through a new `recordNotesDelivery` using the
  existing private `deliveryEvent` allowlist.
- **D3** No new wait boundary (sibling parity). The never-settling start-write timeout is deferred to Task 11.
- **D4** The refused-start 503 files at most one Task 15 report, category `unexpected_generation_failure`, through the
  existing helper (export-route parity, `downloadExportsRoute.ts:135-140`). The form route's 503 files none; that
  difference is recorded.

## Evidence vocabulary (used in every test and receipt)

- **Recorder invocation:** a call to `recordNotesDelivery` / `recordIdorAttempt`, i.e. an attempted write. Unit tests
  with a mocked `createAuditEntry` assert invocations and the attempted row object only, never persistence.
- **Acknowledged:** the writer's answer was exactly `true`. The route treats only this as written.
- **Durable row:** a row read back from the owned fixture MySQL.
  - A failed ACK means one started-recorder invocation, not necessarily the absence of a row: N5b proves a row can
    persist while the ACK is lost.
  - A missing terminal row after an acknowledged start means "not recorded", not "not delivered".
- **Labels:**
  - **mocked writer:** a unit stub of the answer;
  - **unconfigured database:** no `DATABASE_URL`, `getDb()` is null, no SQL is issued;
  - **injected driver fault:** a QA adapter on a real pool connection;
  - **real-engine lock timeout:** an InnoDB wait actually exceeded;
  - **injected emission:** a QA `res.emit` on a real response.
- **Bytes:**
  - `bytes` in every event is the PDF's size, never a count of bytes delivered.
  - "0 attachment bytes" is claimed only where the server provably never wrote the attachment: refusals, the
    already-destroyed branch, or a throw before `end`. It is proven by a server-side spy or instrumentation.
  - `aborted` or `failed` after `end()` makes **no** zero-byte claim.

## Design

### 1. Authorization and denial (order unchanged; one inserted audit)

1. If `sdk.authenticateRequest` returns null, answer 401.
   - The cookie wins; an invalid cookie that is present never falls back to Bearer.
   - Deleted, revoked, expired, tampered and missing sessions land here.
   - No lookup and no audit.
2. Suspended → 403, with no lookup and no audit. `report.userId = user.id` is unchanged.
3. Strict `notesBody` fails → 400, with no lookup and no audit. This covers urlencoded duplicates (arrays), unknown
   fields and non-strings. With JSON duplicate keys the last value wins and ownership still applies.
4. `db.getEstate(estateId)`. **New:** if a row exists and `row.createdByUserId !== user.id`, make the siblings' exact
   call wrapped in the existing total `auditWritten`, and ignore its answer:

   ```ts
   await auditWritten(() => recordIdorAttempt({
     ip: (req.ip || "").slice(0, 64),
     userAgent: String(req.headers["user-agent"] ?? ""),
     estateId: row.id,
     requestingUserId: user.id,
     ownerUserId: row.createdByUserId,
   }))
   ```

   - A false, throw, rejection or unconfigured DB never permits access.
   - It never turns the expected 403/404 into a 500 or a staff report.
5. Unchanged lines 119-120: 404 for a missing or alias id, then 403 for a foreign owner.
   - Own-alias and missing ids write nothing.
   - `report.estateId` is set only after this point, so a foreign estate never reaches a staff report.
6. Only then `listEstateNotes(estateId, user.id)` and the unchanged render.

**Admission (corrected).** The per-IP `downloadLimiter` (200/min on `/api/notes`) bounds requests, and so denial
rows, per IP per minute.
- It does **not** bound concurrent *unresolved* writes, and awaiting does not either.
- Against a stalled DB, pending denial and start writes can accumulate on the shared pool's unbounded queue across
  requests and IPs.
- This is recorded as a Task 11 limitation (L1). No new limit is added.

### 2. Required-start byte gate

```ts
const pdf = await notesPdf(estateName, estate.fileNumber, notes);   // unchanged arguments; renderer untouched
const contentSha256 = createHash("sha256").update(pdf).digest("hex");
const auditReq = { ip: req.ip, headers: { "user-agent": req.headers["user-agent"] } };   // scalars only
const started = await auditWritten(() => recordNotesDelivery("notes_delivery_started", {
  req: auditReq, estateId: estate.id, userId: user.id,
  detail: { format: "pdf", ...deliveryAttempt(user.id, parsed.data), estateRevision: estate.revision,
    contentSha256, bytes: pdf.length },
}));
```

- Every non-`true` answer (false, undefined, null, 0, `"true"`, `{}`, a throw, a rejection, an unconfigured DB) is
  `false`.
- On `false` (D4):
  1. `prepareExportFailureReport(report, null, { category: "unexpected_generation_failure" })`;
  2. `renderDeliveryError(req, res, 503, "The document was generated but could not be audited. Please try again.")`;
  3. `if (prepared) void submitExportFailureReport(prepared)`;
  4. return.
- That sentence is the existing `PAGE_SENTENCES[503]` and is already in `FIXED_SENTENCES`, so a native navigation
  shows it with "Status 503" and the fetch path shows it in the existing toast.
- No attachment header and no PDF byte are sent. `no-store` / `no-referrer` and the small refusal body are allowed.
- No `documents`, `document_versions`, activity or storage write; nothing generated is retained.

### 3. Pending or uncertain start write (D3)

- No byte is sent while the write is pending. No timer, cancellation, retry, rollback or no-save claim.
- If the requester leaves while it is pending:
  - a later `true` meets a destroyed response: `aborted`, and the server never wrote the attachment;
  - a later `false` sends a 503 to a dead socket, which does nothing, and files the D4 report.
- A write that never settles holds that request and its PDF buffer (L1, Task 11).
- A lost ACK whose row persisted gives a 503 with a durable `started` row and no terminal event. Readers must treat
  "started with no terminal event" as "outcome not recorded".

### 4. Transport lifecycle: events, one guard, listeners

| Event | Scheduled when | Detail (existing allowlist) |
|---|---|---|
| `notes_delivery_started` | Required, before any attachment header or byte | format "pdf", attemptId, retryOf?, inputsHash, estateRevision, contentSha256, bytes |
| `notes_delivery_finished` | The response emitted `finish`: the attachment was handed to the transport. Never proof of receipt or save. | format, attemptId, contentSha256, bytes |
| `notes_delivery_aborted` | `close` before any `finish`, or the response was already destroyed when the send began | as finished |
| `notes_delivery_failed` | After an acknowledged start: a synchronous send throw, or a response `error` before any other terminal event | as finished, plus success false and a closed `failureClass` |
| `idor_attempt` (existing) | A foreign-owned exact or alias id, before the 404/403 | Existing text detail, with the stored id |

Pre-start query or render faults keep today's 500 "Failed to generate PDF" plus Task 15, and write no delivery event.

**Mechanism** (new code only in `notesExportRoute.ts`; `sendAttachment` is reused unchanged and called without
`onOutcome`):

```ts
type NotesStage = "finished" | "aborted" | "failed";

/** Task 10: the attachment's one terminal event, from scalars only (never the PDF, notes, estate or request). */
function notesOutcome(auditReq: { ip?: string; headers: { "user-agent"?: string } }, estateId: string,
    userId: number, sent: { format: "pdf"; attemptId?: string; contentSha256: string; bytes: number }) {
  let terminal = false;
  return (stage: NotesStage, failure?: string): void => {
    if (terminal) return;
    terminal = true;
    void recordNotesDelivery(`notes_delivery_${stage}`, { req: auditReq, estateId, userId,
      detail: failure === undefined ? sent : { ...sent, success: false, failure } });
  };
}

/** Task 10: the route's own listeners around the shared sendAttachment, removed at close. */
function sendNotesPdf(res: Response, pdf: Buffer, fileName: string, settle: (stage: NotesStage, failure?: string) => void): void {
  if (res.destroyed) return settle("aborted");            // requester gone: no header, no byte written
  const onFinish = () => settle("finished");
  const onError = (error: unknown) => settle("failed", failureClass(error));
  const onClose = () => {
    res.off("finish", onFinish); res.off("error", onError); res.off("close", onClose);
    settle("aborted");                                    // after a finish the guard keeps "finished"
  };
  res.on("finish", onFinish); res.on("error", onError); res.on("close", onClose);
  try { sendAttachment(res, pdf, "application/pdf", fileName); }
  catch (error) { settle("failed", failureClass(error)); throw error; }   // before the error answer is written
}
```

The handler calls `sendNotesPdf(res, pdf, fileName, notesOutcome(auditReq, estate.id, user.id, sent))`. A rethrow
reaches the unchanged catch: one 500 safe body (Content-Disposition removed, headers were not sent) and one Task 15
report.

**Why it is safe:**
- `close` always follows `finish` (probe A), so cleanup runs on every response.
- A destroyed response emits no `error` (probes C, E), so nothing is left unabsorbed after cleanup.
- The error answer after a throw emits `finish`/`close` (probe F). The guard already holds `failed` from the
  synchronous `settle`, so that answer is never reported as a PDF.

**Orderings** (each tested; "no second response" means the attachment and the error answer are each written at most
once):

| Ordering | Terminal event | Listeners after `close` |
|---|---|---|
| `finish → close` | finished | removed |
| `close` only | aborted | removed |
| `error → close` | failed | removed |
| `finish → error → close` | finished (late error absorbed, no crash, no second event) | removed |
| `error → finish → close` | failed | removed |
| `close` then a late `finish` | aborted (route listeners already gone; the late finish reaches none of them) | removed |
| `close` then a late `error` | Not injected and not reachable: Node 24.13.1 emits no response `error` after destroy (probes C/E), so no stand-in listener is needed and production cleanup stays as designed | removed |
| destroyed before send | aborted; the server never called `end` with the PDF | none attached |
| sync throw in `setHeader` (F1, probe F) | failed (failure "TypeError"); then the 500 | removed at the 500's close |

**Coverage exception requested (narrow):** a Node-originated response `error` could not be triggered natively on
Node 24.13.1 (probes B/C/D/E).
- That row is covered by emitter-level tests of the real handler and by an **injected emission** (`res.emit("error",
  …)`) on a real ServerResponse over a real socket.
- The handling itself is implemented, not excluded.

**Equivalent mutant (documented, not counted):** attaching the listeners before the headers, or skipping the removal
on the throw path, is unobservable under the guard plus close-cleanup. It is accepted as design and not "killed" by
weakening code.

### 5. Best-effort effects and Task 15

- Detached terminal and denial writes never retry, never send a second response and never leave an unhandled
  rejection (`recordAuditEvent` is total). A failure logs only the existing closed `[AuditLog] … not recorded:
  <class>` line.
- Task 15 is unchanged: query, render and sync-send faults are eligible via the existing catch (`answered:
  res.headersSent`). The 503 is eligible once (D4); preparation claims the attempt, so nothing reports twice.
- Denials, guard refusals and `idor_attempt` never create staff rows. A post-handoff transport or audit failure never
  becomes a failed-generation report.
- No new log line or diagnostic feature.

### 6. Exact file and interface scope

**`server/notesExportRoute.ts`** (uniform CRLF; Edit keeps it)
- Imports:
  - `createHash`;
  - `auditWritten` and `deliveryAttempt` (from `./_core/deliveryRouter`, beside the existing imports);
  - `recordIdorAttempt` (from `./_core/trpc`);
  - `recordNotesDelivery`.
- The idor block before line 119.
- Line 128 replaced by the render const, hash, start gate, 503 branch and `sendNotesPdf` call.
- The two module-level helpers above. Every frozen region stays byte-identical; nothing new is exported.

**`server/affidavitHistory.ts`** (MIXED line endings)
- Insert after line 637 with CRLF terminators matching its 587-640 run.
- Use a byte-exact Node splice, never the Edit tool.
- Prove it with an EOL census (LF stays 173, CRLF +5) and GNU `diff` with and without `--strip-trailing-cr` against
  `before/`.
- The inserted lines:

  ```ts
  /** The same four delivery events for POST /api/notes/export-pdf (Task 10). */
  export function recordNotesDelivery(event: `notes_delivery_${DeliveryStage}`, input: DeliveryEventInput): Promise<boolean> {
    return deliveryEvent(event, input);
  }
  ```

**New `server/notesExportRoute.audit.test.ts`** (LF)
- Mocked `./_core/sdk` and `./db`; `./affidavitHistory` spread with `recordNotesDelivery` wrapped as `vi.fn(actual…)`.
- `installDeliveryRoutes` with supertest, and real sockets via `listen(0, "127.0.0.1")` + `http.request`.
- Emitter-level cases drive the real `notesExportHandler` with a hand-built response (EventEmitter plus the few
  methods the handler uses).

**`server/deliveryBearerAuth.test.ts`** (LF)
- Tenancy test (:129-136): add `vi.spyOn(db, "createAuditEntry").mockResolvedValue(true)` (mocked writer), plus
  assertions that the started/finished invocations carry user A (17) and that Bearer B's 403 invoked `idor_attempt`
  for 18.
- Add one case without the spy, labelled **unconfigured database**: the real `createAuditEntry` answers `false` with
  no SQL, giving 503 with the sentence and no attachment.
- Every existing assertion is kept.

**`server/downloadRoute.test.ts`** (MIXED): not edited. Its db mock answers `true` and its `affidavitHistory` mock
spreads the real exports. Its notes tests (:1546-1692, :1957-1973) must stay green unchanged.

**Not touched:**
- `deliveryRouter.ts`/`sendAttachment`, `trpc.ts`, `exportFailureReporting.ts`, `db.ts`;
- `docgen.ts`, renderers and preview builders;
- `shared/*`, schema and migrations;
- `references/file-storage.md` (stale line goes to Task 17);
- notes CRUD, body caps, filename and output.

**No client edit at all.** In particular, these are verified unchanged by full SHA-256 before every edit phase,
before every gate, and at handoff:
- `PreGenerateDialog.tsx`, `EstateDetail.tsx` (NotesTab, its owner/slot wiring and its export for tests),
  `attachmentDelivery.ts` and `fallbackSession.ts`;
- Task 13's tests and its r3 plan.

Task 13's Notes feedback (D11/D12) is observed in the browser runs, never altered.

## 7. Verification (after approval)

**Common QA rules**
- **Bounded waits:** a QA-only helper polls every 10–25 ms up to 2 s (unit) or 15 s (native/browser) for the expected
  detached terminal and report invocations or rows, *before* any assertion and *before* cleanup.
  - On timeout, fail with the observed list.
  - These are not production timeouts.
- **`finally` cleanup:** every owned locker transaction (ROLLBACK and close), socket, server, deferred writer, fault
  arm, capture arm, browser and UI process this session started is released in `finally`.
- **Exact-row policy**, as in Task 13 r3 §13 and Task 15:
  - `audit_log` is **append-only**. Every new row (id, event, estateId, userId, detail) is recorded exactly, and
    none is deleted. A second bounded sweep after the waits records any late row matching this run's `attemptId`s
    or QA estate ids.
  - This run's own fictional QA estates and notes, and its own `failure_reports` rows, are removed by recorded id
    in `finally`.
  - Seeded fixture rows are never modified.
  - End counts must equal start counts plus exactly the recorded `audit_log` rows.
  - Never a table wipe; never a retry of an uncertain POST without evidence.
- **Labels:** every gate label is checked unused before use (`run-gates.cjs` rewrites `results.json` per
  invocation).

**Step 0 — preconditions** (after Gate B). Stop and ask if any fails.
- Task 13 still closed: `sha256sum -c` of its `final-r3-hashes.sha256` all OK, and no listener on 43117/43316.
- No peer session is editing this worktree. If `ListAgents` still shows a busy peer, ask Nick before the first edit.
- Branch, HEAD and index verified; names-only status still 78 modified / 64 untracked plus only what Task 10 itself
  adds. Every fingerprint above re-hashed.
- Unexpected drift in any Task 10 target, protected client file or Task 13 file means stop. Others' work is never
  reverted.
- New `.work/hybrid-remediation/task10/claude-pass01/` with:
  - `before/` copies, sha256 and Node EOL census of the task and reference files;
  - `prior-work.diff` against HEAD, separating earlier work from Task 10's delta.
- The repository plan copy saved at Gate A still has the SHA-256 reported then. Any later amendment Nick approves is
  appended there, never rewritten silently.

**Step 1 — golden notes-PDF capture, before any edit.** A QA-only vitest harness with its own config under `qa/`.
- **Environment:** copied from `run-gates.cjs`: no `DATABASE_URL`, no `.env`, `TZ=America/Vancouver`.
- **Clock:** `vi.setSystemTime(<fixed>)`. Every note has an explicit fixed `createdAt`; no implicit time anywhere.
- **Recorded and asserted equal on the post run:** `process.env.TZ`,
  `Intl.DateTimeFormat().resolvedOptions().{locale,timeZone}`, and Node/ICU versions.
- **Cases:**
  - empty;
  - one note;
  - pinned;
  - every TAG_LABELS key plus an unknown tag;
  - multi-page (y > 680);
  - an attachment-name reference;
  - emoji and Latin-1 text.
- **Output:** sha256, bytes and filename per case to `qa/golden-before.json`.

**Step 2 — red.** Write the tests, run `run-gates.cjs claude-task10-red1 focus --test-file=…`, expect exit 1, and
record each failing assertion in `red/`.

All tests assert exact values and run after the bounded waits:
- **T1 Owner success.**
  - 200, `%PDF-`, Content-Length equal to the whole body, unchanged filename regex, `no-store`.
  - Exactly one started invocation, and `express.response.setHeader('Content-Disposition')` / `end` not yet called
    when it runs (spies). Then one finished invocation.
  - started and finished `contentSha256` equal sha256(body), with the same bytes and `attemptId`; `retryOf` on a
    repeated `attemptId`.
  - Exact detail key sets. No detail contains names, filename, notes text, tags, attachment names, URL, token or error
    text.
- **T2 Empty notes.** The empty-state PDF still exports, audited the same way. No new block.
- **T3 Mocked-writer ACK matrix.** Cases: false, undefined, null, 0, `"true"`, 1, `{}`, a sync throw, a rejection, a
  recorder throw. Each must give:
  - 503 with the exact sentence (JSON); for `Sec-Fetch-Dest: document`, the HTML page with the sentence and
    "Status 503";
  - no Content-Disposition; `end` never called with the PDF;
  - **exactly one started-recorder invocation**;
  - exactly one `notes_export_pdf`/`unexpected_generation_failure` report invocation.
- **T4 Pending start write, real socket.** Sequence:
  1. Server on `listen(0)`; a deferred mocked writer.
  2. Raw `http.request` with the body.
  3. Wait until the started invocation is pending.
  4. Client `destroy()`; wait until `server.getConnections()` is 0.
  5. Resolve the writer.
  - `true`: `[started, aborted]`, and the spy shows `end` was never called with the PDF.
  - `false`: `[started]` only, no crash, one report invocation.
- **T5 Disconnect during the render, real socket.** Sequence:
  1. Server on `listen(0, "127.0.0.1")`.
  2. `listEstateNotes` replaced by a deferred.
  3. Raw request.
  4. Wait until `listEstateNotes` is called.
  5. Client `destroy()`.
  6. Wait until `getConnections()` is 0 *and* the server response has emitted `close` (observed through a QA wrapper
     on `express.response`).
  7. Resolve the deferred.
  8. Bounded wait for `[started, aborted]`.
  - Assert `end` was never called with the PDF and the client received no data.
  - `server.close()` and resolution of the deferred are in `finally`.
- **T6 Close before finish, real socket.** The established injection: an `express.response.end` spy destroys the
  socket instead of writing. Expect `[started, aborted]`, no finished, and no zero-byte claim.
- **T7 Emitter-level orderings.** Drive the real `notesExportHandler` with a hand-built response: an EventEmitter plus
  the methods the handler uses.
  - **Route-owned listeners are captured by identity.** The emitter's `on`/`once`/`addListener` are wrapped to record
    each function the handler adds. It has **no** baseline `error` listener.
  - **Orderings emitted:**
    - `finish → close`, `close` only, `error → close`, `finish → error → close` and `error → finish → close`
      (error-before-close coverage);
    - destroyed-before-send;
    - a sync `setHeader` throw;
    - `close` then a late `finish`.
  - **Excluded** (not emitted): a synthetic `error` after `close`. Node 24.13.1 emits none after destroy (probes
    C/E), and production cleanup is not changed to suit a fake.
  - **Assertions per ordering:**
    - exactly one terminal invocation with the right stage;
    - after `close`, `listeners(evt)` contains **none** of the recorded route-owned functions for `finish`, `close`
      or `error` (identity check, not a count);
    - the attachment `end` is called once and no error answer follows it;
    - nothing escapes as an uncaught error.
  - **Real responses (T4–T6, T9):** a test-only middleware mounted before `installDeliveryRoutes` snapshots
    `res.listeners(evt)` at request start. An `express.response.setHeader` spy snapshots them again at the first
    attachment header, when the route's listeners are already attached. The difference is the route-owned set, and
    after `close` none of it remains.
- **T8 Synchronous send failure.** Fictional "Łucja Testowa":
  - 500 `{error:"Failed to generate PDF"}`, no Content-Disposition, `end` never called with the PDF;
  - `[started, failed]` with failure "TypeError";
  - one report invocation, and no finished even though the 500 emits `finish`.
- **T9 Injected emission on a real response.** A QA spy emits `error` once the attachment `end` was called and before
  `close`. Expect failed or finished according to which came first, one event only, listeners removed, no crash, no
  second response.
- **T10 Denials.**
  - Exact foreign id: 403 and exactly one `idor_attempt` invocation with the sibling-identical fields. No
    `listEstateNotes`, no notes invocation, no report.
  - Foreign alias "E1": 404, invocation with the stored id.
  - Own alias and missing id: 404, no invocation.
  - idor writer false, rejection or throw: still 403 (never 500), no report.
  - idor writer pending while the requester leaves (real socket): no notes read, no crash, no second response. Once
    the writer settles, the refusal goes to a dead socket.
  - 401, suspended 403, 400 (including urlencoded duplicates) and cross-site 403: no lookup, no invocation.
- **T11 Retention.** The terminal invocation's `req` is exactly `{ip, headers: {"user-agent"}}`, never the Express
  request.
- **T12 Task 15 regressions.**
  - A render fault gives 500, one report and no delivery invocation.
  - A finished/aborted recorder answering false or rejecting gives no second response, no report, no unhandled
    rejection and no re-invocation.

**Step 3 — implement** as in §6. Then the line-ending checks, the frozen-region hashes and `git diff` of the two
source files against `before/` (Task 10 delta only).

**Step 4 — green.** `claude-task10-focus1…n` with the new file plus:
- `downloadRoute.test.ts`, `downloadExportsRoute.test.ts`, `deliveryBearerAuth.test.ts`;
- `_core/deliveryRouter.test.ts`, `_core/trpc.ownership-audit.test.ts`;
- `exportFailureReporting.test.ts`, `affidavitHistory.test.ts`, `notes.test.ts`, `formDeliveryBinding.routes.test.ts`.

**Step 5 — mutants.** QA-only, byte-exact restore, receipts. Each must be killed:
- M1: send before the start answer (T1, N1);
- M2: a truthy ACK accepted (T3);
- M3: no guard (T7, T8);
- M4: no idor audit (T10);
- M5: bare `await recordIdorAttempt` (T10, reject → 500);
- M6: no synchronous `settle("failed")` on a throw (T8: the 500 reads as finished);
- M7: `req` passed to detached writes (T11);
- M8: the 503 with no report, or a double report (T3);
- M9: idor for an own alias (T10);
- M10: no destroyed pre-check (T4/T5: no terminal event);
- M11: no listener removal at close (T7 listener counts);
- M12: no `error` listener (T7/T9 uncaught);
- M13: raw error text in `failure` (T8 exact "TypeError").

The old M6 is documented as an equivalent mutant (§4).

**Step 6 — freeze.** Re-run the golden harness with the same recorded environment.
- **Expected:** byte-equal per case. Any difference is reported, never normalised.
- Frozen-region hashes and the protected-source hashes stay equal.
- HTTP and browser runs (real clock) assert only per-response file = capture = audit hash.

**Step 7 — native fixture** (owned fictional MySQL only).
- Guarded launchers; data-directory/port/pid identity verified; inherited credentials stripped; `AWS_*`,
  `STORAGE_S3_*` and `LEGAL_RECORD_STORAGE_APPROVED` never set; private values never printed.
- An in-process harness as in Task 15's `verify-native-task15.ts` and Task 6's `verify-native-ordering.ts`:
  - the real pool;
  - the real delivery router on `http.createServer(app).listen(0, "127.0.0.1")`;
  - sessions minted with the fixture secret;
  - a raw socket client;
  - QA spies on `express.response` for server-side write evidence.
- **The barrier:** a root locker runs REPEATABLE READ `START TRANSACTION; SELECT id FROM audit_log FOR UPDATE`.
  - The blocked statement is identified by `information_schema.processlist` (app user, `insert into \`audit_log\``)
    and confirmed in `performance_schema.data_lock_waits` (blocking thread = the locker).
  - It is released by ROLLBACK in `finally`.

| Case | Expected | Label |
|---|---|---|
| N1 Ordering | While the started INSERT is blocked: the client has 0 bytes; no `Content-Disposition`/`end` call; no finished INSERT or row exists. After release: the started row exists, then the response arrives (body hash = row hash), then the finished row. | real engine |
| N2 Empty notes | Same as N1. | real engine |
| N3 Exact and alias foreign ids | 403 / 404; one durable `idor_attempt` each; no notes rows; no report. | real engine |
| N4 Missing id | 404; no row. | real engine |
| N5a Write fails | The started INSERT fails: 503, 0 attachment bytes, **no** started row, one durable `failure_reports` row. | real-engine lock timeout (actual `@@innodb_lock_wait_timeout` recorded), or injected driver fault from a Task 10 copy of the fault adapter, labelled as such |
| N5b ACK lost after persisting | The insert runs, then the adapter throws: 503, 0 attachment bytes, a **durable started row with no terminal row**. | injected (insert-then-ACK-loss) |
| N6 Blocked, client destroy, release | `aborted` row; server-side spy shows the PDF was never written. | real engine |
| N7 Sync send failure ("Łucja Testowa") | started + failed rows; 500; one report row. | real engine |
| N8 Close before finish during transfer | **Observational:** a QA-only large note set and a non-reading client. Record which event won; per probe D, finish is expected to win, and that is not a failure. | observational |
| N9 Cookie A + Bearer B | Rows carry A. An invalid cookie + Bearer gives 401 and no rows. | real engine |
| N10 Cross-site Origin | 403 from the guard; no rows. | real engine |

Fixture bookkeeping:
- Correlation uses a Task 10 copy of `audit-correlate.cjs`, extended to `notes_` and text-detail `idor_attempt`, keyed
  by `attemptId`/hash. No ordering is inferred from `createdAt`.
- Counts are taken before and after with `fixture-counts.cjs`.
- QA estates and notes are this run's own fictional rows. The seeded rows are never modified.

**Step 8 — build and real browser.**
1. `run-gates.cjs claude-task10-build1 build`, then a manifest.
2. Start a Task 10 UI-server variant: QA copies of `start-ui-task15.cjs` / `ui-server-task15.ts` plus the
   fault-adapter copy, with its own `sourceHashes` and ownership/identity guards. The shared fixture files are
   untouched, because Task 13's evidence hashes them.
3. Verify the served entry and lazy assets against the manifest.
4. `browser-launch.cjs` headless Chromium plus `cdp.cjs trace` (`allowAndName`).
   - Sessions come only from `/__fixture/login` and `?mode=bearer`.
   - `capture-next.json` is armed before each click and removed in `finally` if unconsumed.

| Run | What it checks |
|---|---|
| B1 Cookie-only native success | Download = capture = audit hash. |
| B2 Bearer fetch success | Download = network body = capture = audit hash. |
| B3 Cookie-native refusal (injected start fault) | The tab shows the 503 page with the sentence; no file is saved. Then Return and an explicit healthy retry delivers a file. |
| B4 Bearer refusal (injected start fault) | Task 13's estate-owner toast (D11) shows the 503 sentence verbatim, because no token change occurs in this run; under D12 a token change would make it GENERIC. No file is saved. The button is enabled again, and an explicit retry delivers a file. |

- No console errors.
- Task 13's hold/owner behaviour is observed, not changed.
- A native response body cannot be read with `Network.getResponseBody`, and that is not demanded.
- After each run, bounded waits for the rows, then cleanup in `finally`.

**Step 9 — full gates.** `run-gates.cjs claude-task10-pass1 check tests chatbot-check chatbot-tests build render`.
- Read the actual commands, exits and counts, and bind them to the final hashes.
- Recheck the gate build against the browser manifest; if it differs, re-run the affected browser runs or prove
  identity.

**Step 10 — independent read-only reviews.** General-purpose agents on Opus, because the Review Council guard blocks
specialist types; the model is passed explicitly.
- R1 security/IDOR/privacy.
- R2 lifecycle and silent failure.
- R3 probate integrity and freeze (`probate-integrity-gate`, read-only).
- R4 a claims audit of `final-status.md`.
- Only Task 10 findings are fixed; affected proof and gates are re-run under fresh labels.

**Step 11 — handoff.**
- `final-status.md` with:
  - branch/HEAD/index;
  - the Task 10-only inventory and diff;
  - preserved unrelated changes and line endings;
  - root cause;
  - the lifecycle table;
  - commands, exits and counts tied to the final bytes;
  - native rows, ACK and barrier order;
  - socket and browser evidence;
  - the freeze result;
  - reviews by severity;
  - every limitation.
- A queue evidence entry, append-only, with the checkbox unticked.
- Stop only processes this session started. **Stop.** Task 10 is not marked done, Task 13 is not accepted, and no
  SHIP claim is made.

## Connected-feature matrix

| Feature | Preservation contract | Recheck |
|---|---|---|
| Notes list and privacy | Own notes only (`listEstateNotes(id, user.id)`, 500 cap, newest first); no read before auth and ownership pass | T1/T10; `notes.test.ts` |
| Notes CRUD (tRPC) | Untouched | Full gates |
| PDF success and empty notes | Byte-identical for the same pinned inputs and environment; same type, length and filename; empty-state text; no new block | Golden before = after; `downloadRoute.test.ts:1560-1572`; T2 |
| Auth and sessions | Cookie first, Bearer fallback, no fallback from an invalid cookie, refusal statuses | `deliveryBearerAuth.test.ts` (all cases); N9 |
| CSRF/Origin guard, parsers, body caps | `deliveryRouter.ts` unchanged | Its suite; :1957-1973; T10; N10 |
| Required start audit | Exactly-`true` gate, existing 503 sentence, 0 attachment bytes | T1/T3/T4; N1/N5a/N5b; B3/B4 |
| Transport outcomes | One guard, listener cleanup, no second response | T4–T9; N6–N8 |
| Denial audit | One wrapped attempt, never permissive, statuses unchanged | T10; N3 |
| Task 15 reporting | Existing eligibility, limits and closed rows; 503 once; no report for denials | :1598-1657; T3/T8/T12; `exportFailureReporting.test.ts` |
| Native and Bearer UI | No client edit; Task 13 r3 Notes feedback (D11 estate owner, D12 session currency), hold and toasts preserved; `PreGenerateDialog.tsx` untouched | B1–B4; Task 13's client suites in full gates; protected-file SHA-256 checks at every phase |
| Note attachments | Only `📎 name` printed; no attachment bytes fetched; never in audit | Golden case; T1 detail scan |
| Shared helpers and their form/export consumers | Unchanged; one sibling recorder added | Form/export/formDeliveryBinding/affidavitHistory suites; `deliveryRouter.ts` and `trpc.ts` hashes unchanged |
| tRPC IDOR middleware | Unchanged | `trpc.ownership-audit.test.ts` |
| Generated-byte non-persistence | No storage, document, version or activity write | T1 no-call assertions; native counts change only in `audit_log`/`failure_reports` before cleanup |
| Docs | Not edited; stale line handed to Task 17 | Handoff |

## Limits and open findings (none fixed by Task 10)

- **L1 (Task 11).** A start or denial write that never settles holds its request and PDF. Concurrent unresolved writes
  are unbounded (pool 10 with an unbounded queue; the limiter counts requests, not pending writes; multiple IPs). The
  notes route has no per-user generation budget.
- **L2.** A "started" row with no terminal row means "outcome not recorded". A lost ACK can leave a durable started row
  after a 503 (N5b).
- **L3.** A native Node-originated response `error` is not triggerable on Node 24.13.1 (coverage exception above).
  Native close-before-finish is observational (probe D).
- **F1 Notes filename.** Non-Latin-1 names and CR/LF give `ERR_INVALID_CHAR`; a `"` gives a malformed header. Fixing
  either changes the delivered filename and needs separate approval.
- **Sibling routes.** A bare `await recordIdorAttempt` can turn a rejection into a 500; no post-start send-failure
  event; their 503s differ on reporting. Out of scope.
- **`idor_attempt`** rows do not name the surface. **`references/file-storage.md:116`** becomes false (Task 17).
- **Carried forward unchanged:**
  - Dev/Preview raw delivery-body capture is not approved before real client data.
  - No new developer console trail.
  - Chatbot rotation can move a cookie tab onto fetch.
  - The runtime `message` listener's origin/source validation is OPEN before production.
  - Task 15's browser gap; Safari/iOS/Android WebView unverified.
  - Word/pixels are user-deferred, not passed.
  - Task 6/14 limits stand; Tasks 7/8 are not reopened; Task 13 is not accepted; no AWAITING-NICK item is resolved.

## Repository preferences (recorded for future models)

1. One explicitly selected prompt at a time: plan, get approval, implement, hand off, stop.
2. Only this worktree, branch and HEAD. Preserve the dirty tree and every file's line endings. No
   stage/commit/reset/stash/push/merge/switch/checkpoint/deploy.
3. Rule 29 and the queue freeze apply. The notes PDF (TAG_LABELS, `notesPdf`, filename, render arguments) is frozen
   byte-for-byte.
4. No edits to `docgen.ts`, renderers or preview builders, `shared/types.ts`, schema, migrations or captures. No
   upgrades. Never weaken the freeze guard or its baseline.
5. Missing data never becomes a new hard block. Auth/ownership, audit acknowledgement and integrity refusals are
   separate safety boundaries.
6. Fictional, owned-fixture data only. No production, AWS or credentials.
7. No Word retry, installs, unrelated process kills or vault updates.
8. Two approval gates. Gate A: save the plan in the repository and stop. Gate B: implement, hand off and stop.
   Acceptance and task closure are Nick's alone. Task 13's work (including `PreGenerateDialog.tsx` and its Notes
   feedback) is preserved without client edits.
9. `audit_log` is append-only in the fixture. Only this run's own QA estates, notes and report rows are removed, by
   exact id.

## Review record (verbatim; for future models)

Source prompt: `outputs/claude-remaining-tasks/08-task-10-notes-audit-ownership.md` (Task 10 only; no other task
prompt was read).

**Decisions (Nick, 2026-10-24, plan-mode question; each answer was the recommended option):**

| Question | Answer |
|---|---|
| Denials | "Keep 404/403 (Recommended)" |
| Event names | "notes_delivery_* (Recommended)" |
| Audit wait | "Wait, like form/export (Recommended)" |
| 503 report | "Yes, once, like export (Recommended)" |

**Nick's review of r1 (2026-10-24):**

> Keep D1–D4, including deferring the never-settling audit timeout to Task 11. Revise r1 before application edits:
> Complete response-error handling. Don’t simply declare it unreachable. Define and test error/close/finish orderings, one terminal-event guard, listener cleanup and no second response. A transport failure does not prove zero bytes were sent. If retaining the exclusion, provide precise route/runtime evidence and request approval for that coverage exception.
> Separate attempted writes from durable rows. A failed ACK means one started-recorder invocation, not necessarily a persisted started row. Label unconfigured-DB and injected-fault tests accurately. Use an identified INSERT/lock/zero-byte barrier—not createdAt,id sorting—to prove ordering. Add QA-only bounded waits for detached terminal/report writes before assertions and cleanup; these are not production timeouts.
> Make verification reproducible and cleanup failure-safe. Pin every note timestamp and verify locale/timezone for golden captures. Specify T5’s socket sequencing. Treat N8 as observational when finish wins. Put owned lock/socket/writer/fault-control and exact-row cleanup in finally.
> Correct two overclaims. Await plus 200/minute does not bound unresolved concurrent audit writes; record the pending-denial/shared-pool limitation under Task 11. Recheck M6: the failed-settlement guard may make moving listeners alone an equivalent mutant. Don’t weaken working code to kill it.
> Preserve the PDF/document freeze, statuses, Task 15 reporting, missing-data warn-and-proceed, isolation and deferrals. Keep preferences and decisions in the repository plan. No filename/renderer/schema/client or next-task changes. Return the revised Task 10-only plan for approval and stop. Do not implement or mark Task 10 done yet.

**Nick's review of r2 (2026-10-24):**

> Keep D1–D4 and the narrow native-error verification exception. Fix T7 before implementation: either exclude the synthetic post-close error injection or give the fake emitter a documented baseline error listener. Assert that the route-owned listeners are removed. Keep error-before-close coverage; do not change production cleanup to satisfy the fake.
> Refresh the stale Task 13 state/client hashes from its claude-pass02 handoff and claude-task13-pass3 receipt. Protect PreGenerateDialog.tsx and preserve Task 13’s Notes feedback without client edits.
> Save these amendments and preferences in the repository plan, return it for approval, and stop. No implementation or task closure yet.

**r3:** Gate A was approved by Nick through the plan-mode exit on 2026-10-24. The approval gave no further text.

## Post-save notes (append-only)

**2026-10-24 18:05 PDT — Gate B approved.** Nick's message was "proceed". It also approves the step 0 note proposed
in the Gate A handoff.

At 17:54, Task 13's own session recorded "User disposition — Task 13 done by decision — 2026-10-24 17:48 PDT" in the
queue, ticked its checkbox and appended a decision record to its r3 plan. These are legitimate predecessor changes;
neither file is edited by Task 10. The new baselines:

| File | Old sha256 | New sha256 |
|---|---|---|
| `docs/superpowers/plans/2026-10-21-hybrid-remediation-queue.md` | `b92ffdab…` | `e278dac634c4edfcb6dc2092a739581654c2196c80895fdad6d3e9eb6f33031b` |
| `docs/superpowers/plans/2026-10-24-task13-r3-amendment.md` | `f6299fef…` | `5acfcf753706ccd9f1a7a81d93265780c7d1b1346c54a100469e717a304c448f` |

- The other six entries of Task 13's `final-r3-hashes.sha256` still match.
- The earlier "13 unchecked / not accepted" wording in this plan describes the 17:48 state. Task 13 is now **done by
  Nick's decision**, with its recorded limitations; that closure is not a SHIP claim.
- Step 0 at 18:05: all peer sessions idle, no fixture listener, branch/HEAD/index verified, status 78 modified /
  65 untracked.

**2026-10-24 — two corrections from the independent reviews.** Factual corrections only; no design change.
- **§5 log-line wording (R2 LOW-3).** When a real audit insert fails, `createAuditEntry` logs the closed line
  `[AuditLog] Failed to write: <Name> (code=…)` (`db.ts:2037`) and returns `false`. The
  `[AuditLog] <event> event not recorded: <class>` line (`affidavitHistory.ts:500`) appears only when the writer
  throws or rejects. Both are closed; neither carries row values.
- **Runtime facts (R3 INFO-2).** The installed vitest is 2.1.9; the manifest range is ^2.1.4.

**2026-10-25 08:10 PDT — Task 10 accepted/done by Nick's decision.** This is remediation tracking only, not a SHIP approval.
L1–L3, F1 and the Task 17 doc item remain open; see the queue disposition.
