# Client Intake Review Design Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make lawyer review and application of a submitted client intake easy to scan, compare, select, and act on without changing the established approval safeguards.

**Architecture:** Keep the existing `ClientIntakeReview` state, tRPC procedures, revision guard, selection array, dependency rules, and client submission contract unchanged. Refine the component into a clear review workspace: submission state and selector first, a compact decision summary second, then grouped field comparisons with an explicit selected-count action bar and a secondary correction path.

**Tech Stack:** React 19, TypeScript, Tailwind CSS, Shadcn UI, Lucide icons, Vitest and Testing Library.

**Spec:** `docs/superpowers/specs/2026-10-12-estate-client-intake-workspace.md`

## Global Constraints

- Do not change database schema, tRPC/API contracts, approval logic, revision guards, selection eligibility, or client data scope.
- Keep approval explicit: no submitted detail may apply until the lawyer chooses an existing Apply or Approve action.
- Retain name/description dependency protections and the existing unsaved-Intake edit block.
- Do not change court-form wording, document generation, legal logic, citations, or estate data outside an existing approval action.
- Use native interactive controls, visible focus states, accessible names, 24px+ touch targets, and reduced-motion-safe styling.
- Keep the review usable in the estate tab’s narrow container and on mobile without horizontal overflow.

## Review Focus

- A submission with no eligible facts must retain its existing empty state and never show a working bulk apply action.
- A submission with already-applied facts must preserve its review history and not offer those facts again.
- A dependent person/item field must remain blocked until identity/description is selected or already applied.
- Unsaved Intake edits must still disable all application actions with the existing explanatory message.
- Custom-question responses and reported context must remain review-only with no Apply control.

---

### Task 1: Review workspace hierarchy and regression coverage

**Files:**
- Modify: `client/src/components/ClientIntakeReview.tsx`
- Modify: `client/src/components/ClientIntakeReview.test.tsx`

**Interfaces:**
- Consumes: existing `Submission`, `clientIntakeReviewFields`, `approvedFields`, `selectedFields`, `approve`, and `requestRevision` interfaces.
- Produces: semantic review workspace landmarks and stable accessible labels for the compact review summary, selected-count action, comparison list, review-only context, and corrections panel.

- [ ] **Step 1: Write the failing UI regression**

Add a test with a submitted fixture that asserts the visible review summary, selected-count status, grouped comparison heading, and correction disclosure are present while review-only custom responses have no Apply button.

- [ ] **Step 2: Run the test to verify it fails**

Run: `pnpm exec vitest run client/src/components/ClientIntakeReview.test.tsx --maxWorkers=1`

Expected: FAIL because the new review workspace labels do not exist.

- [ ] **Step 3: Implement the component-only hierarchy refinement**

In `ClientIntakeReview`, retain all existing mutation calls and eligibility conditions. Add only visual/semantic wrappers, concise status treatment, a selected-facts count, readable submitted/current comparison labels, and a clear distinction between applyable and review-only information.

- [ ] **Step 4: Run focused component tests**

Run: `pnpm exec vitest run client/src/components/ClientIntakeReview.test.tsx client/src/components/EstateClientPortal.test.tsx --maxWorkers=1`

Expected: PASS.

### Task 2: Responsive polish and release verification

**Files:**
- Modify: `client/src/components/ClientIntakeReview.tsx`
- Modify: `client/src/components/ClientIntakeReview.test.tsx`
- Create: `docs/audits/client-intake-review-design.md`
- Modify: `todo.md`

**Interfaces:**
- Consumes: the workspace hierarchy from Task 1.
- Produces: container-safe desktop/mobile layout plus an audit record and tracker entry.

- [ ] **Step 1: Add a focused responsive/layout regression**

Assert the comparison rows preserve a single responsive review-list class and that batch action wording includes the selected count when an item is selected.

- [ ] **Step 2: Apply container-aware layout and interaction polish**

Use existing Tailwind primitives and CSS transitions only. Preserve mobile stacked actions; gate hover-only feedback through Tailwind’s supported hover media behavior and retain visible focus states.

- [ ] **Step 3: Run fresh verification**

Run focused review and estate workspace tests, `pnpm check`, `pnpm test -- --maxWorkers=1`, `pnpm build`, `git diff --check`, and local/public development health checks. Inspect a fictional fixture only if a browser fixture can be rendered without querying authenticated estate data.

- [ ] **Step 4: Record evidence and checkpoint**

Write the audit note, append one exact tracker entry after successful verification, inspect the scoped diff, then save a WebDev checkpoint with the verified scope.

## Self-Review

- **Spec coverage:** The plan retains estate-scoped submission selection, individual/bulk approval, review-only handling, revision requests, and all stated safeguards while changing only presentation.
- **Type consistency:** All state and procedure inputs stay inside `ClientIntakeReview`; no new external interface is required.
- **Review Focus:** The five workflow-risk cases map to Task 1 assertions and retained existing regressions.
- **Proportion:** Two UI-focused tasks match a component-only presentation change and avoid backend work.
