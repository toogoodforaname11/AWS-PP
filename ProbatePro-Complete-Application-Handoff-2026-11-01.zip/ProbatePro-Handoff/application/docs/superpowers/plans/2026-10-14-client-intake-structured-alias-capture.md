# Client Intake Structured Alias Capture Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let an executor report an alternate name in separate first, middle, and last-name fields so a lawyer can apply the selected parts to the existing structured AKA inputs without parsing a full-name string.

**Architecture:** Extend the existing encrypted client-intake payload and selected-field review contract with three optional structured alias fields. The portal uses native labelled inputs; the server mapping transfers only non-empty, lawyer-approved parts to the existing `akaFirstName`, `akaMiddleName`, and `akaLastName` estate columns. The free-text alias report remains separate, with the latest-report replacement behavior preserved.

**Tech Stack:** React 19, TypeScript, tRPC 11, Zod, Vitest, Playwright.

**Spec:** User report on 2026-10-14: portal aliases must not pile up, and an executor-provided structured AKA must not remain stuck on a stale value.

## Global Constraints

- Do not split or infer legal name parts from free-text input.
- Apply portal facts only after lawyer selection; do not overwrite unselected values.
- Preserve existing schema, authorization, court forms, document wording/layout, and existing estate records.
- Use fictional fixtures only; never access portal sessions or client data.
- Preserve accessible labels, keyboard operation, and responsive layout.

## Review Focus

- A full name entered only in the legacy free-text input never populates structured AKA fields.
- A selected first/middle/last structured report reaches exactly the corresponding existing estate fields.
- Blank structured values cannot clear existing AKA values.
- Applying a structured AKA does not reintroduce older portal aliases.
- The portal form, review labels, and desktop/mobile keyboard interaction remain legible and operable.

---

### Task 1: Structured alias contract and selected-field mapping

**Files:**

- Modify: `shared/clientIntake.ts`
- Modify: `server/clientIntakeMapping.ts`
- Test: `server/clientIntakeMapping.test.ts`
- Test: `server/routers.client-intake.test.ts`

**Interfaces:**

- Produces optional `deceasedAkaFirstName`, `deceasedAkaMiddleName`, and `deceasedAkaLastName` client-intake fields in the existing payload, apply-field list, labels, and revision support.
- Produces exact selected-field mapping to the existing `Estate` AKA columns.

- [x] **Step 1: Write mapping and route regressions** proving all three selected structured values map to their matching AKA columns, and legacy free-text aliases do not populate those columns.
- [x] **Step 2: Run the focused tests** and confirm the structured selection case fails before implementation.
- [x] **Step 3: Extend the payload/review contract and mapper** while allowing only non-empty selected values.
- [x] **Step 4: Re-run the focused tests** and confirm they pass.

### Task 2: Portal capture and review usability

**Files:**

- Modify: `client/src/components/ClientIntakeForm.tsx`
- Test: `client/src/components/ClientIntakeForm.test.tsx`
- Test: `client/src/components/ClientIntakeReview.test.tsx`
- Test: `client/src/pages/EstateDetail.intake-dedup.test.tsx`

**Interfaces:**

- Consumes the Task 1 fields and exposes them as optional labelled portal inputs.
- Preserves the existing free-text alias report as a separate field.

- [x] **Step 1: Write form and review regressions** for labelled separate inputs, a readable review row, and no direct structured inference from free text.
- [x] **Step 2: Run the focused tests** and confirm the new structured-capture assertion fails before implementation.
- [x] **Step 3: Add the labelled structured inputs and state/payload handling** using native form controls and existing field/error patterns.
- [x] **Step 4: Re-run focused tests and a fictional Playwright workflow** covering typing, submit payload, lawyer-selected application, keyboard focus, and phone-width containment.

### Task 3: Release verification

**Files:**

- Create: `docs/audits/client-intake-structured-alias-application.md`
- Modify: `todo.md`

- [x] **Step 1: Run affected suites, TypeScript, the serial suite, production build, whitespace review, and local/preview health checks.**
- [x] **Step 2: Record the factual root cause, scope, and fresh validation evidence.**
- [x] **Step 3: Save a WebDev checkpoint.**
