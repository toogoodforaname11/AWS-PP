# Task 18 handoff preferences — 2026-10-27

## Selected work and current state

Nick requested advice on the Task 17 handoff and the next task's prompt. The next task is **18 — reverify security safeguards**. This file and `outputs/claude-remaining-tasks/12-task-18-security-safeguard-reverification.md` prepare that task; neither runs its checks nor accepts Task 17/18. Actual status remains the authoritative queue and Nick's explicit decisions.

At preparation, Task 17's report and receipt say implemented, NOT accepted; its queue checkbox remains open. Its four main handoff hashes match the files inspected, and all 56 entries in `.work/hybrid-remediation/task17/claude-pass01/manifest.sha256` match. Artifact equality is not semantic acceptance. The final five rewordings/ten fragments have not received the independent lens review offered in the handoff. The proposed reply asks for one bounded final-fragment pass, keeps D9/README outside scope, preserves the Node 24 evidence uncertainty and allows an append-only lease-arithmetic erratum. That proposed reply is advice, not authorization transmitted to Claude.

Tasks 14/6/7/8 remain open. Do not reopen their implementation or silently close them under Task 18. User-accepted Tasks 15/9/13/10/11/12 retain their exact evidence limits. Task 19 remains separately blocked; Task 20 and hybrid Step 4 are not selected.

## Preferences and rules for every model

1. Work only in `C:\Users\nick\probate pro\probatepro-hybrid-review`, branch `security/hybrid-vault-review`, retained HEAD `db0d7e9161bc3899b75858fab58bce54e3d5247a`. Preserve dirty/untracked work and identify it with file hashes, not HEAD alone.
2. Task 18 is verification-only. Gate A saves bounded investigation, source inventory, proof matrix and verification plan; stop for approval. Gate B requires a separate explicit proceed. Decision answers alone do not start execution. Stop after the result for Nick's acceptance.
3. Do not edit application code, existing tests, renderer/drawing/preview code, document schema, legal logic/selection, configuration, dependencies, package locks, RULES.md, .cursorrules, authoritative captures or historical receipts. New QA/report evidence is not permission to repair a defect.
4. Absolute court-document freeze: no wording, citations, layout, structure, geometry, pagination, typography, jurat/signature/checkbox change. Preserve the four approved historical output behaviours and only genuinely recorded exceptions; do not invent an exception count.
5. Missing information stays warn-only; preserve blanks/drafts and Generate anyway. Integrity/authentication/audit/resource refusals are separate boundaries and must not be removed to pass a missing-data test.
6. No production/client data, RDS/AWS/S3/STS/KMS/vault access, real credentials, `.env*` reads, inherited DSNs, live UAT, migration, production seeds or external-service writes. Only scrubbed offline/mocked tests and identity-guarded local fictional UI/database checks after approved planning. No AWS/vault settings in the UI fixture.
7. No stage, commit, reset, stash, push, merge, branch/worktree switch, checkpoint, publish, deploy, app transfer or other-project action. Recording preferences here is not a Git commit. No tool/install/ACL or dependency changes without separate approval.
8. Keep evidence classes distinct: source inference, executable mock, real fictional browser, real local MySQL, frozen package comparison, historical receipt, estimate, deployed policy proof. A valid citation/manifest hash does not prove a semantic claim or security guarantee.
9. Word/pixel checks remain **user-deferred-not-passed**; do not run/repair Office, kill Word or repeat the user startup request. Preserve available non-Office checks without calling them pixel proof. Mobile/WebView and other accepted evidence gaps stay explicit.
10. Preserve runtime message/body-redaction/session residuals, notes limits/header/retention concerns, incomplete exhibit/export binding and Task 12 scope limits. Report gaps/new regressions, do not fix or accept them. Do not close the Node 24 residual from documentary inference alone.
11. Keep the true role-split, sole purge chokepoint, full Canada West KMS identity and exact SSEKMSKeyId checks, production fail-closed profile, manifest/tenant authorization, CSRF and generated-byte non-retention as explicit proof-matrix rows. Real deployed permissions are Task 19, not mocks.
12. Task-level acceptance/queue updates require Nick's authorization. No Task 18 SHIP or compliance assertion; the final review is Task 20 and deployment/policy evidence remains separate. Retain failed checks and deviations rather than relabel them passed.

## Evidence for this prompt-only preparation

Preparation evidence lives under `.work/task18-prompt-update-2026-10-27/`: original prompt, pre-update source/context and Git identity/index fingerprints, Task 17 manifest corroboration and final verification. Only the selected prompt and this preference record are intended user deliverables. No application checks, fixture/browser/service, database, AWS or Office was run. The queue, original Task 17 plan/report/receipt/documents and prior preference record are preserved.
