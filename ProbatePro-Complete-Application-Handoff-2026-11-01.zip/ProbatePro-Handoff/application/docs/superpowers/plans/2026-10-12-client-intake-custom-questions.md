# Estate-Specific Client Intake Questions Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let lawyers author review-only, case-specific questions for a single estate’s client intake before sharing its portal link.

**Architecture:** Persist a validated JSON question definition on the estate row. The lawyer-owned Client Portal tab edits this definition through dedicated owner-scoped procedures; the authenticated portal reads only its own estate definition. Submission payloads embed a question/answer snapshot, which the lawyer review shows as non-applicable context.

**Tech Stack:** React 19, TypeScript, tRPC 11, Zod, Drizzle/TiDB MySQL, Vitest, Tailwind/Shadcn.

**Spec:** `docs/superpowers/specs/2026-10-12-client-intake-custom-questions.md`

## Global Constraints

- Keep questions case-specific, free-text and review-only; no auto-application, legal inference, form content or notification.
- Enforce 20-question/500-character prompt and help/4,000-character response limits at shared validation boundaries.
- Preserve old intake payloads and submission history, and keep all records within the existing owner/portal estate scope.
- Do not change court forms, docgen, legal text, citations or portal token exposure.
- Use existing components, visible focus states and reduced-motion-safe interactions; add no dependencies.

## Review Focus

1. An old, question-free submission must still render and be reviewable after the schema extension.
2. A lawyer changing/deleting a question after send must not change the saved prompt/answer on an earlier submission.
3. A portal client must not obtain custom questions for a different estate or alter question configuration.
4. Required question validation must point to a labelled field and prevent submission without blocking unrelated optional answers.
5. Custom answers must not appear as an Apply option or change an estate, Contact or Inventory record.

---

### Task 1: Shared contracts and estate persistence

**Files:**
- Modify: `shared/clientIntake.ts`, `drizzle/schema.ts`
- Create: generated Drizzle migration under `drizzle/migrations/`
- Test: `server/clientIntakeMapping.test.ts`

**Interfaces:**
- Produces `clientIntakeCustomQuestionSchema`, `clientIntakeCustomQuestionsSchema`, `clientIntakeCustomAnswerSchema` and backward-compatible `ClientIntakePayload.customQuestions`.
- Adds `estates.clientIntakeCustomQuestions` with a JSON-string default of `[]`.

- [ ] Write schema regressions for empty/legacy payloads, duplicate IDs, limits and required blanks.
- [ ] Run the focused contract test to confirm the new behavior is initially absent.
- [ ] Add the validated models and `clientIntakeCustomQuestions` column; generate the migration, read it and apply it.
- [ ] Verify focused contracts, `pnpm db:check`, and migration idempotency.

### Task 2: Scoped configuration API

**Files:**
- Modify: `server/db.ts`, `server/routers.ts`
- Test: `server/routers.client-intake.test.ts`

**Interfaces:**
- Produces owner-only `clientIntakeQuestions.get` and `.update` with `{ estateId, questions, expectedRevision }`.
- Produces `portal.clientIntakeQuestions` scoped strictly to `ctx.portalSession.estateId`.

- [ ] Add failing owner/portal scope and snapshot-submission regressions.
- [ ] Add dedicated database update logic with revision protection and activity record, then wire procedures.
- [ ] Confirm old submissions continue parsing and portal submission stores its own question snapshot.
- [ ] Run router tests and TypeScript.

### Task 3: Lawyer authoring surface

**Files:**
- Create: `client/src/components/ClientIntakeQuestions.tsx`, `client/src/components/ClientIntakeQuestions.test.tsx`
- Modify: `client/src/components/EstateClientPortal.tsx`, `client/src/components/EstateClientPortal.test.tsx`

**Interfaces:**
- `ClientIntakeQuestions({ estateId, revision })` provides labelled add/edit/reorder/remove/save controls using the scoped API.

- [ ] Write red tests for adding a question, marking it required, saving the estate-specific definition and no question leakage across estates.
- [ ] Implement the compact authoring surface ahead of link management, with alert/error/loading states and keyboard-accessible controls.
- [ ] Re-run authoring/estate tab tests and inspect a fictional mobile/desktop fixture.

### Task 4: Client answer and lawyer-review experience

**Files:**
- Modify: `client/src/components/ClientIntakeForm.tsx`, `client/src/components/ClientIntakeReview.tsx`, `client/src/pages/Portal.tsx`
- Test: `client/src/components/ClientIntakeForm.test.tsx`, `client/src/components/ClientIntakeReview.test.tsx`

**Interfaces:**
- Client form consumes `portal.clientIntakeQuestions`, snapshots prompt/help/required/answer in `customQuestions`, validates required answers, and submits through existing `portal.submitClientIntake`.
- Lawyer review lists submitted custom answers under non-applicable review-only context.

- [ ] Write failing client form and review assertions for display, required errors, submission snapshot and absence of Apply controls.
- [ ] Implement responsive question rendering, error focus/labels and review-only answer presentation.
- [ ] Re-run focused client/review tests and browser-test fictional configuration, required feedback, successful submit and review display.

### Task 5: Whole-feature verification and checkpoint

**Files:**
- Create: `docs/audits/estate-client-intake-custom-questions.md`
- Modify: `todo.md`

- [ ] Run all focused tests plus `pnpm check`, `pnpm test -- --maxWorkers=1`, `pnpm build`, migration/schema checks and `git diff --check`.
- [ ] Validate a fictional browser flow at mobile and desktop widths, keyboard access and no portal cross-estate response.
- [ ] Record precise scope/validation evidence, update one tracker entry and save a checkpoint.

## Self-review

Every success criterion maps to a task: storage/compatibility to Task 1; security and snapshots to Task 2; lawyer configuration to Task 3; client validation and review-only display to Task 4; migration/full/browser verification to Task 5. No task adds question types, attachments, legal logic, notifications or automatic estate application.
