# Task 18 review preferences — 2026-10-28

## Status and authority

Nick requested review of `pasted_content_20.txt`, the proposed Task 18 Gate A plan. This new preference record and `outputs/task18-plan-review-2026-10-28.md` contain review advice only. They do not authorize Gate B, accept Task 17/18, change the original prompt/plan/queue or clear any predecessor gap. Actual authority remains Nick's explicit decisions and the authoritative queue.

## Consistent handoff requirements

1. Reverify only implemented Steps 0–3 under Task 18; report defects, do not repair them. No Task 19/20, hybrid Step 4, transfer, publication or Git write.
2. Absolute court-document freeze: no wording, citations, structure, typography, spacing, pagination, jurat/signature/checkbox, renderer arguments, DOCX/PDF/HTML-preview, legal logic or selection changes. Preserve recorded historical approvals; invent no new exception.
3. Missing information remains warn-only under the existing approved single-form behaviour; preserve Generate anyway and blanks. Do not weaken independent auth/ownership/integrity/audit/resource boundaries or silently change existing package/bulk semantics.
4. No production/client data, RDS/AWS/S3/STS/KMS/vault access, real credentials, live UAT, runtime/private-value dumps, migration/seed, installs, dependency/config/lock changes or Office action. Approved future execution uses scrubbed mocks and the exact identity-guarded fictional loopback fixture only.
5. Complete the relevant raw tracked-diff and full untracked-module/critical consumer review. Hash/symbol/comment maps and a saved patch are not substitute review evidence.
6. Verify the full built-asset map and actual browser-loaded assets against the pinned fixture. A mismatch is not permission to assume which build was served.
7. Pin copied helper hashes and declare their actual required inputs. Use new, separately named approved Task 18 QA readers for missing correlation features; do not edit original or copied historical helpers merely to force agreement. Separate bare render/generation SHA, canonical digest, delivered artifact SHA and provenance identity.
8. A SELECT failure is not started-audit ACK-failure evidence. Record actual route statuses and bounded best-effort staff-report outcomes. Unavailable native scenarios remain not exercised; mock coverage is a separate class.
9. Screen actual root/chatbot test membership, setup and flagged external boundaries before execution. Provider imports or inert boolean/command assertions alone are not evidence of actual AWS resolution. Unresolved risky commands remain held without secretly weakening/excluding tests or altering the runner.
10. No default metadata restore. Any later approved cleanup is narrowly specified and guarded, preserves retained references, saves evidence first and has its own QA ledger. It is not atomic whole-fixture rollback and never rewrites audit/activity/history to fabricate provenance.
11. Use one explicit allowed-output list under the Task 18 pass plus declared final deliverables/build/fixture outputs. Unexpected provider blob writes are findings. Preserve all other source/context and concurrent changes.
12. Compare all extracted DOCX/ZIP members on identical fictional inputs; only dcterms:created/modified text normalization is approved. The 26-form XML gate alone does not check binary media/all core properties. Word/pixels stay user-deferred-not-passed.
13. New observations require evidence-based severity/impact and proposed disposition, not automatic acceptance or implementation. Preserve Tasks 7/8 not reopened, open Task 14/6, Task 17 pending documentation acceptance and all user-accepted evidence limits. No SHIP/compliance/residency claims.
14. Return one concise revised saved plan and remaining decisions, then stop for explicit execution approval. This review requests no new broad tracer or panel cycle.

## Files changed by this review

Only new review-working files under `.work/task18-plan-review-2026-10-28/`, the review report and this preference record are intended. No existing application, tests, rules, original Task 18 prompt/plan, queue or predecessor receipts are edited. The final preservation receipt is saved in the review-working directory; no application checks were run.
