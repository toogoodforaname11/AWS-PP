# Client Intake Will Location Application Repair Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make a lawyer-approved client report of where the original will is kept persist to a visible, editable estate Intake field.

**Architecture:** The client portal already collects and reviews `willLocation`, but it is currently treated as an estate patch even though the only existing column is a retired `wills_search` field. Add a canonical `estates.willLocation` column, expose it in the existing Intake will section, and let the existing selected-field application and one-step undo operate on that estate value. Do not restore any Wills Search route, editor, or source of truth.

**Tech Stack:** React 19, TypeScript, tRPC, Drizzle/TiDB, Vitest.

**Spec:** User-reported Client Portal defect: Will location currently reports “Applied” but does not appear in Intake; each reported defect remains an independent task.

## Global Constraints

- Apply only lawyer-selected, non-empty client facts.
- Keep client first/middle/last and address component fields separate; do not change portal field layout in this task.
- Do not alter court forms, document rendering, legal logic/text, aliases, uploads, signatory selection, or other reported defects.
- Do not revive the retired Wills Search workflow or write to its legacy `willLocation` field.
- Use an additive migration; preserve revision and undo behavior.

## Review Focus

- Applying will location must change the visible estate Intake field, not merely mark a submission reviewed.
- Existing estates must receive a safe blank default through the additive migration.
- A blank client report must remain ineligible to clear a recorded estate value.
- A one-step undo must restore the prior estate will location with the same revision guard as other applied estate facts.
- No request path may write portal data to `wills_search.willLocation`.

---

### Task 1: Canonical estate will-location field

**Files:**
- Modify: `drizzle/schema.ts`
- Create: generated migration under `drizzle/`
- Modify: `server/clientIntakeMapping.test.ts`

- [ ] Add `estates.willLocation` as a non-null, 500-character string with an empty default.
- [ ] Generate, inspect, and apply the additive migration; run the schema check.
- [ ] Add a red mapper assertion showing a selected client `willLocation` targets the canonical estate patch.

### Task 2: Reviewed application and reversible Intake editor

**Files:**
- Modify: `client/src/pages/EstateDetail.tsx`
- Modify: `server/routers.client-intake.test.ts`
- Modify: `server/db.persistence.test.ts`
- Test: `client/src/pages/EstateDetail*.test.tsx`

- [ ] Add one normal Intake field beside the existing Will Date editor, labeled for where the original will is kept.
- [ ] Assert selected client location persists to `estates.willLocation`, appears in the normal estate update contract, and remains in the existing undo estate snapshot.
- [ ] Assert no selected client location is routed to a Wills Search patch or legacy Wills Search helper.

### Task 3: Release verification

**Files:**
- Create: `docs/audits/client-intake-will-location.md`
- Modify: `todo.md`

- [ ] Run focused red-green client-mapping, router/persistence, and Intake tests, then TypeScript, full serial tests, build, whitespace/diff checks, migration/schema check, and runtime health.
- [ ] Record the root cause, the canonical destination, explicit legacy-workflow exclusion, evidence, and one completion tracker entry.
- [ ] Save a checkpoint after fresh successful verification.

## Self-review

The plan covers the active failure chain: portal selection, schema-backed estate destination, normal Intake visibility, selected-only application, and undo safety. It intentionally excludes legacy Wills Search editing, client-field redesign, documents, form output, legal logic, and the other separately reported portal defects.
