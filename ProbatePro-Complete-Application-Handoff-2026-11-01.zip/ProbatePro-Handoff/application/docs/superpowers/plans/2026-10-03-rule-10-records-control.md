# Rule 10 Records-Control Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Give each ProbatePro account—whether an individual lawyer or a personal executor—reliable control over its own estate records through verified authorization, usable export, retention-aware disposition, and an auditable future vault boundary.

**Architecture:** Preserve the existing `createdByUserId` account-owner model and the storage manifest as the source of truth for record attribution. Add an explicit single-account purpose (`lawyer` or `personal_executor`) before launching an executor-specific experience; that purpose selects profile copy and recommended workflow but never proves legal authority over an estate. The vault remains a separate, provider-dependent phase: Manus stores only opaque references after direct-vault uploads are available.

**Tech Stack:** React 19, TypeScript, tRPC 11, Drizzle/TiDB MySQL, Vitest, existing storage lifecycle/outbox.

**Spec:** `docs/architecture/rule-10-conformance-baseline.md`

**Implementation status (2026-10-04):** Tasks 2 and 3 are complete under the current single-account authorization model. The server remains the source of account authorization for estates and private objects, and the dashboard now offers an authorized per-estate export. Task 0's purpose preference, neutral registration UI, and first-estate Full Intake handoff are implemented; executor-specific Terms/Privacy language and a legal review remain outstanding before public marketing of an executor-specific service. Task 4 remains an external provider, recovery, and counsel gate; Task 5 must not begin before Task 4 is approved.

## Global Constraints

- The product supports single-account **lawyer** and future single-account **personal executor** use. It does **not** yet have a shared firm/workspace/tenancy model.
- Account purpose is not proof that someone is legally appointed or authorized to administer an estate. Form roles remain estate-contact facts and ordinary authorization remains account-derived.
- The platform must not claim ownership of a lawyer’s client records or an executor’s estate records.
- Preserve official probate form wording, document layout, selected-only behavior, and form-generation results.
- Do not use or migrate real client data while establishing a new provider or vault; use synthetic fixtures only.
- Do not make a “Canadian-resident,” “Canada-only,” or compliance claim before provider, contract, recovery, and counsel review are complete.
- Never log raw SINs, document contents, signed URLs, authorization tokens, full filenames, or account details.
- No deletion path may bypass retention, legal hold, or verified provider-destruction controls.

## Review Focus

1. **Cross-account ID tampering:** another account’s estate/document/export ID must yield the same non-enumerating denial path as an absent record.
2. **Manifest drift:** a document must not be exported/downloaded when ownership metadata is missing, stale, deleted, or inconsistent with its estate.
3. **Deletion vs. export race:** an estate under active disposition must not export a partial or newly resurrected document set.
4. **Sensitive-content leakage:** filenames, document bytes, SINs, signed URLs, and tokens must not appear in logs, test failures, analytics, or user-visible generic errors.
5. **Provider cutover:** an object is not marked migrated until its checksum, owner/estate relation, reference activation, and legacy-destruction evidence all verify.
6. **Account-purpose confusion:** selecting personal executor must not create lawyer/firm claims, change a contact’s executor/applicant status, or grant access to another account’s estate.

---

### Task 0: Model the single-account personal-executor path before public launch

**Files:**
- Modify: `drizzle/schema.ts`
- Create: `drizzle/0166_dark_nextwave.sql` (generated account-purpose migration)
- Reuse: `server/db.ts` per-user settings helpers (no new owner parameter)
- Modify: `server/routers.ts`
- Modify: `client/src/components/OnboardingGate.tsx`
- Modify: `client/src/components/OnboardingGate.test.tsx`
- Modify: `client/src/pages/Settings.tsx`
- Modify: `client/src/pages/Settings.test.tsx`
- Modify: `client/src/pages/Terms.tsx`, `client/src/pages/Privacy.tsx` only after counsel-approved copy is supplied

**Interfaces:**
- Consumes: authenticated `ctx.user.id`, the existing single-account settings row, `createdByUserId`, and the persisted `formFocusedIntake` preference.
- Produces: `accountPurpose: "lawyer" | "personal_executor" | "unselected"` on settings and onboarding copy that distinguishes an individual lawyer from a personal executor without adding a firm or workspace identifier.

- [x] **Step 1: Write failing onboarding and settings tests for both account purposes**

  Assert `lawyer` shows the professional-profile path and recommends Form-focused mode. Assert `personal_executor` shows a personal profile path, defaults to the Full Intake/rule-guided view, does not require a firm name, and leaves all executor/applicant contact roles unchanged. Assert an existing lawyer account retains its current settings experience.

- [x] **Step 2: Run the focused tests to confirm the missing account-purpose contract**

  Run: `pnpm vitest run client/src/components/OnboardingGate.test.tsx client/src/pages/Settings.test.tsx --maxWorkers=1`

  Expected: FAIL because no persisted account-purpose distinction exists.

- [x] **Step 3: Add the settings contract and migration**

  Add a non-null `accountPurpose` setting with an `"unselected"` default. The server derives ownership from the session and accepts only `lawyer` and `personal_executor` as browser-selected values; `unselected` remains the server-side default. It must never accept an account owner, executor, applicant, or estate identifier from the browser as part of this preference. Existing firm profile fields remain separately updateable by their current Settings workflow.

- [x] **Step 4: Update first-run and Settings profile UX**

  Present **“How will you use ProbatePro?”** before profile fields: **Lawyer** and **Personal executor**. For a personal executor, use neutral personal-profile labels and Full Intake by default. Do not represent the person as lawyer, law firm, applicant, or executor solely because of the account-purpose choice. Keep the current firm fields available for lawyer accounts. Do not introduce a shared firm workspace in this task.

- [ ] **Step 5: Add purpose-aware legal-copy hooks only after counsel approval**

  Keep the existing Terms/Privacy language unchanged until counsel supplies approved wording. The future personal-executor copy must distinguish a user’s own estate-administration records from lawyer client records and must not claim probate/legal advice, executor appointment, Canadian residency, or regulatory compliance.

- [x] **Step 6: Re-run focused authorization and onboarding tests**

  Run: `pnpm vitest run client/src/components/OnboardingGate.test.tsx client/src/pages/Settings.test.tsx server/_core/trpc.ownership-audit.test.ts server/routers.estate-update.test.ts --maxWorkers=1`

  Expected: PASS; a purpose change alters only profile/workflow preference and cannot alter estate ownership or contact roles.

- [ ] **Step 7: Commit**

  ```bash
  git add drizzle/schema.ts drizzle/migrations server/db.ts server/routers.ts client/src/components/OnboardingGate.tsx client/src/components/OnboardingGate.test.tsx client/src/pages/Settings.tsx client/src/pages/Settings.test.tsx
  git commit -m "feat: add personal executor account purpose"
  ```

### Task 1: Freeze the individual-lawyer ownership and data-handling contract

**Files:**
- Create: `docs/architecture/rule-10-conformance-baseline.md`
- Modify: `RULES.md`
- Test: `client/src/pages/Privacy.test.tsx`

**Interfaces:**
- Consumes: current `estates.createdByUserId`, `stored_objects.userId`, and `stored_objects.estateId` controls.
- Produces: the durable product rule that account-derived ownership is the source of record attribution and that no compliance/residency claim is made without evidence.

- [ ] **Step 1: Add the individual-lawyer ownership decision and no-overclaim rule to `RULES.md`**

  State that the authenticated account controls its records for product access purposes; ProbatePro and providers do not acquire ownership; account IDs are server-derived; retention/disposition remains account-holder-directed subject to applicable obligations; and unverified residency/compliance claims are prohibited. Keep the lawyer-specific Rule 10 analysis explicitly limited to lawyer accounts.

- [ ] **Step 2: Update privacy-copy regression coverage before changing public privacy copy**

  Pin that the policy does not claim Canada-only storage, names a contact path for provider locations, preserves external-processor disclosure, and does not promise immediate file destruction where retention applies.

- [ ] **Step 3: Obtain counsel approval for any changes to Terms, Privacy, a DPA, or customer-retainer copy**

  Do not merge legal marketing copy based solely on this technical plan. Record the approved provider/subprocessor and retention language separately.

- [ ] **Step 4: Run the focused policy test**

  Run: `pnpm vitest run client/src/pages/Privacy.test.tsx --maxWorkers=1`

  Expected: PASS with no unapproved residency or compliance assertion.

- [ ] **Step 5: Commit**

  ```bash
  git add RULES.md docs/architecture/rule-10-conformance-baseline.md client/src/pages/Privacy.test.tsx
  git commit -m "docs: record lawyer records-control baseline"
  ```

### Task 2: Prove account-derived ownership on every existing estate/file operation

**Files:**
- Modify: `server/_core/trpc.ownership-audit.test.ts`
- Modify: `server/db.storage-authorization.test.ts`
- Modify: `server/routers.storage-lifecycle.test.ts`
- Modify only if a test exposes a gap: `server/db.ts`, `server/routers.ts`, `server/storageRegistry.ts`

**Interfaces:**
- Consumes: `assertEstateOwned(estateId: string, userId: number)`, `userCanAccessStorageKey(userId: number, storageKey: string)`, `StorageObjectMetadata`.
- Produces: regression proof that account/estate ownership is enforced for estate read/write, file access, file lifecycle, and disposition.

- [ ] **Step 1: Write failing cross-account router tests**

  Add cases where a second authenticated user attempts to read/update/delete another user’s estate, initiate an estate document operation, and retrieve an object key with a matching-looking prefix. Assert `NOT_FOUND`/non-enumerating denial and no provider call.

- [ ] **Step 2: Write failing manifest consistency tests**

  Cover a missing manifest, wrong `userId`, wrong `estateId`, non-active state, and a deleted/dispositioned object. Each must deny access even when the storage key resembles a valid namespace.

- [ ] **Step 3: Run the ownership tests to prove the gap or baseline**

  Run: `pnpm vitest run server/_core/trpc.ownership-audit.test.ts server/db.storage-authorization.test.ts server/routers.storage-lifecycle.test.ts --maxWorkers=1`

  Expected: failures only for the newly identified missing cases; otherwise record that the existing control already passes.

- [ ] **Step 4: Implement the smallest server-side fix if any new test fails**

  Keep `createdByUserId` and the manifest as the authorization sources. Do not trust an input `userId`, storage-key prefix, or browser-provided owner identifier.

- [ ] **Step 5: Re-run the ownership suite**

  Run: `pnpm vitest run server/_core/trpc.ownership-audit.test.ts server/db.storage-authorization.test.ts server/routers.storage-lifecycle.test.ts --maxWorkers=1`

  Expected: PASS.

- [ ] **Step 6: Commit**

  ```bash
  git add server/_core/trpc.ownership-audit.test.ts server/db.storage-authorization.test.ts server/routers.storage-lifecycle.test.ts server/db.ts server/routers.ts server/storageRegistry.ts
  git commit -m "test: prove lawyer record ownership boundaries"
  ```

### Task 3: Add an authorized account-held estate export

**Completed 2026-10-04.** `estate.export` verifies the authenticated estate owner before building and again after storing the archive. The ZIP contains a structured record snapshot plus only active/retained manifest-authorized estate objects attributed to the same account; internal object URLs/keys and prior transient exports are omitted. It is a transient 24-hour private object, is capped at 500 objects / 50 MB per object / 250 MB uncompressed source content, and is queued for destruction if a concurrent disposition wins the race. The dashboard action is labelled **Export estate copy**. Coverage includes manifest scope, locator removal, provider-read compatibility, cross-account denial, oversized data, concurrent-disposition cleanup, and the account-facing dashboard action.

**Files:**
- Create: `server/estateExport.ts`
- Create: `server/estateExport.test.ts`
- Modify: `server/routers.ts`
- Modify: `server/db.ts`
- Modify: `client/src/pages/Home.tsx`
- Modify: `client/src/pages/Home.storage-disposition.test.tsx`

**Interfaces:**
- Consumes: `assertEstateOwned`, `listEstateStorageKeys`, storage-manifest state, current estate/contact/inventory/document queries.
- Produces: `buildEstateExport({ estateId, userId }): Promise<{ filename, mimeType, buffer, objectCount }>` and a protected `estate.export` tRPC procedure.

- [ ] **Step 1: Write failing export-service tests**

  Use a synthetic estate. Assert an export includes readable structured estate data and only active, manifest-authorized file references/content; excludes deleted, foreign-owned, transient, and unmanifested objects; and does not contain raw tokens or signed URLs.

- [ ] **Step 2: Write failing router/UI authorization tests**

  Assert that export requires the authenticated owner, blocks while an estate disposition is underway, provides a visible retryable error on export failure, and never claims success before a download is initiated.

- [ ] **Step 3: Run export tests to confirm failure**

  Run: `pnpm vitest run server/estateExport.test.ts client/src/pages/Home.storage-disposition.test.tsx --maxWorkers=1`

  Expected: FAIL because the export service and procedure do not yet exist.

- [ ] **Step 4: Implement `buildEstateExport` and `estate.export`**

  Build a ZIP containing a machine-readable JSON record plus authorized files where present. Use manifest ownership/state as the document authority, a safe generated filename, no public object URLs, and an activity/audit event that contains only IDs/counts/action/outcome.

- [ ] **Step 5: Add the lawyer-facing export action**

  Add an accessible estate action labelled `Export file`. It must explain that exports respect record retention and do not destroy the original. Keep active disposition status visible and disable/deny export only while a destruction operation needs a consistent snapshot.

- [ ] **Step 6: Re-run focused export tests**

  Run: `pnpm vitest run server/estateExport.test.ts client/src/pages/Home.storage-disposition.test.tsx --maxWorkers=1`

  Expected: PASS.

- [ ] **Step 7: Commit**

  ```bash
  git add server/estateExport.ts server/estateExport.test.ts server/routers.ts server/db.ts client/src/pages/Home.tsx client/src/pages/Home.storage-disposition.test.tsx
  git commit -m "feat: add authorized lawyer file export"
  ```

### Task 4: Add the provider due-diligence and recovery gate before sensitive-data migration

**Preparation completed 2026-10-04; approval remains pending.** The provider questionnaire, synthetic restore record, and incident runbook have been created under `docs/operations/` and `docs/runbooks/`. They deliberately contain no inferred provider facts or compliance assertion. Task 4 cannot be marked approved until a chosen provider supplies written answers, a segregated synthetic restore passes, the incident tabletop is completed, and counsel reviews the applicable terms.

**Files:**
- Create: `docs/operations/storage-provider-due-diligence.md`
- Create: `docs/operations/restore-test-record.md`
- Create: `docs/runbooks/storage-incident.md`
- Test: manual synthetic restore record and tabletop exercise

**Interfaces:**
- Consumes: Rule 10-3/10-4 criteria, provider terms, backup configuration, and current storage manifest/export functions.
- Produces: an approved provider decision record, a tested recovery result, and a no-claims gate.

- [ ] **Step 1: Complete the provider questionnaire**

  Obtain answers in writing for storage region, backups, snapshots, logs, support access, subprocessors, encryption, account termination, export, destruction, incident notice, and access controls. Attach or link the actual terms internally; do not infer an answer from marketing copy.

- [ ] **Step 2: Configure daily encrypted backups and an independent recovery copy**

  A single Toronto VPS is permitted as a starting vault architecture, but the backup destination must be documented and tested. A second always-running VPS is optional, not a Rule 10 requirement.

- [ ] **Step 3: Perform a synthetic restore test**

  Restore a synthetic estate and documents into a segregated environment; verify checksum, export, owner authorization, and absence of cross-account access. Record actual recovery duration and data recovery point.

- [ ] **Step 4: Write the storage incident runbook**

  Include loss of control, suspected unauthorized access, failed destruction, provider outage, backup failure, and credential compromise. Define who investigates, when users/lawyers are informed, what evidence is retained, and when counsel/insurer review is needed.

- [ ] **Step 5: Obtain counsel approval before changing customer claims**

  Do not enable a Canadian-residency badge or say the system satisfies a legal obligation based on technical deployment alone.

- [ ] **Step 6: Commit**

  ```bash
  git add docs/operations/storage-provider-due-diligence.md docs/operations/restore-test-record.md docs/runbooks/storage-incident.md
  git commit -m "docs: add storage due diligence and recovery controls"
  ```

### Task 5: Introduce an optional Canadian sensitive-data vault after Task 4 approval

**Files:**
- Create: `server/vaultClient.ts`
- Create: `server/vaultClient.test.ts`
- Create: `shared/vaultTypes.ts`
- Create: `drizzle/migrations/<next>_sensitive_document_refs.sql`
- Modify: `drizzle/schema.ts`
- Modify: `server/routers.ts`
- Modify: `client/src/pages/EstateDetail.tsx`
- Modify: `server/storageRegistry.ts`
- Test: `server/vaultClient.test.ts`, `server/routers.storage-lifecycle.test.ts`, focused estate upload UI test

**Interfaces:**
- Consumes: approved `VAULT_URL`, short-lived service credentials, authenticated account purpose, `assertEstateOwned`, vault provider contract.
- Produces: `createVaultUpload`, `completeVaultUpload`, `getVaultDownload`, and a Manus-side `sensitive_document_refs` table that contains opaque vault IDs and safe metadata only.

- [ ] **Step 1: Write the vault API contract with the provider selected in Task 4**

  Use direct browser-to-vault upload, 5–10 minute scoped tokens, account/estate-bound authorization, safe document labels, random object IDs, checksum verification, file-type/size limits, quarantine/scan status, and retention-aware delete semantics.

- [ ] **Step 2: Write failing vault client and authorization tests**

  Cover expired, wrong-audience, wrong-account, wrong-estate, wrong-scope, replayed, and token-leaking cases for both lawyer and personal-executor accounts. Assert the Manus database receives only the opaque ID and safe metadata; signed URLs and raw content are never persisted.

- [ ] **Step 3: Implement the minimal vault client and reference schema**

  Do not move an existing document class yet. Keep existing storage behavior unchanged until the new reference path, access flow, audit path, and failure handling pass tests.

- [ ] **Step 4: Migrate one document class using synthetic data first**

  Start with a non-form-critical uploaded document class. Compare source/destination checksum and owner/estate metadata, activate the new reference, then create verified legacy-destruction evidence only after the approved migration window.

- [ ] **Step 5: Run focused tests and a staged migration reconciliation**

  Run: `pnpm vitest run server/vaultClient.test.ts server/routers.storage-lifecycle.test.ts --maxWorkers=1`

  Expected: PASS; reconciliation reports no unowned, mismatched, or dual-active object.

- [ ] **Step 6: Commit**

  ```bash
  git add server/vaultClient.ts server/vaultClient.test.ts shared/vaultTypes.ts drizzle/schema.ts drizzle/migrations client/src/pages/EstateDetail.tsx server/routers.ts server/storageRegistry.ts
  git commit -m "feat: add scoped sensitive document vault references"
  ```

## Self-Review

- **Spec coverage:** Task 0 adds the executor account-purpose boundary; Tasks 1–2 formalize account ownership and prove authorization; Task 3 adds a usable export; Task 4 covers provider agreement, backup, restore, and incident controls; Task 5 implements the optional sensitive vault only after the external dependencies are approved.
- **Step scan:** Each task has a bounded deliverable, named files, interfaces, tests, and validation commands. Provider/counsel decisions are deliberately separated from code changes.
- **Type consistency:** Existing `userId` and `estateId` terms are retained. `accountPurpose` is a presentation/policy enum, not a legal-authority or tenancy field. The future vault uses only `vaultDocumentId` and safe metadata in Manus.
- **Review focus:** Cross-account access, manifest integrity, executor-purpose confusion, export/disposition races, sensitive logging, and provider cutover are covered by Tasks 0–5.
- **Proportion:** The plan is intentionally phased because the provider and contractual controls are prerequisites; it does not introduce speculative vault code before those decisions are known.

## Execution Handoff

Plan complete and saved to `docs/superpowers/plans/2026-10-03-rule-10-records-control.md`. The first pending product work is **Task 0**, while Task 4 requires provider and counsel decisions outside the codebase. Do not begin the executor-specific onboarding or vault integration until the appropriate product/counsel decisions are approved.
