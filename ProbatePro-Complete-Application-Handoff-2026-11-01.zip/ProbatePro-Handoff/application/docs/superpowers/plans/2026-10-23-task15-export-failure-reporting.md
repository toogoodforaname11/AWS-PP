# Task 15 — Export failure reporting (revised plan r2; STOP for approval)

> **Amended 2026-10-23 (A1, approved by Nick) — see "Amendment A1" at the end.** A1 adds two approved
> post-review additions and supersedes this text's statements on row counts, skip outcomes, the one-log-line rule
> and existing budgets. Task 15 remains implemented but **not accepted**; no SHIP claim.

Revision r2 addresses the 2026-10-23 plan review (`.work/task15-plan-review-2026-10-23/`) in four areas:

- the refusal reporting matrix;
- the shared-pool admission policy;
- synchronous scalar-only preparation and lifecycle rules;
- strict acknowledgement validation.

The architecture is unchanged: Task 15 only, the existing writer, invocation-scoped ownership, a controlled payload and a bounded wait.

## Context

The queue's Task 15 says: "Honor reportable safe failures once; preserve original error when reporting fails" (queue `:55`).

The export error paths compute a trusted refusal. They never pass it, or an operational fault, to the staff writer. So an unreadable authorized letterhead or attachment keeps its 409 but never reaches staff.

The goal is one eligible staff-report attempt per failed server invocation, which gives one `failure_reports` row when the writer is healthy. Every public status and message, audit, byte gate, optional-timeline outcome and slot lifetime stays unchanged, including when reporting fails or stalls.

**Workspace verified, read-only:** branch `security/hybrid-vault-review`, HEAD `db0d7e9161bc3899b75858fab58bce54e3d5247a`, empty index. The tree is intentionally dirty and stays preserved. The pre-existing stash entry is not ours and is not touched.

## Predecessors and the requested ordering exception

Required order: 14 → 6 → 7 → 8 → **15**. Tasks 1, 2, 3, 16, 4 and 5 are accepted.

- **Task 14 is unaccepted.** Its pixel step is user-deferred, not passed.
- **Task 6 is unaccepted.** Its repairs are verified in `manus-task06-final2`. INT-1 and the frozen `docgen.ts` merger issues remain open.
- **Tasks 7 and 8 are missing.** Their checkboxes are unticked and `task07/`, `task08/` do not exist.

**Exception requested.** Approving this plan grants a Task 15-specific permission to proceed. It is not acceptance of Tasks 14, 6, 7 or 8. Task 15 acceptance stays contingent on their open evidence.

The plan review was not that exception. Only Nick's explicit approval naming it counts.

Risk: Task 8 will touch the same export files later, so expect a re-check when it lands.

## Root cause (bounded source trace; code-review-graph MCP unavailable)

- **`downloadExportsRoute.ts:132-152`** keeps the trusted status and message but never reads `refusal.report` and never calls `db.createFailureReport`. The start-audit 503 at `:125` is unreported.
- **`routers.ts:2661-2708` (`estate.export`).**
  - The manifest catch (`:2673-2683`) maps a 413 or a branded tRPC refusal, and otherwise sends a fixed 500. It has no report.
  - `assertEstateOwned` and `commitGenerationEffects` (`:2686`) are outside any try. A database fault, or the branded Task 5 "Generation could not be confirmed…" 500, reaches the tRPC boundary unreported.
  - The optional timeline failure is caught locally (`:2703-2707`).
- **`notesExportRoute.ts:124-128`** logs and sends 500 "Failed to generate PDF", with no report.

**Existing owners, not doubled:** `controlledGenerationError` (`generate_*`), `download_form` (`downloadRoute.ts:435-446`) and chatbot `recordChatbot`.

**Interfaces.** None of these changes.
- `PublicRefusal` stores `report` in a private WeakMap brand (`failureReporting.ts:49-56`).
- `generationRefusal` returns that flag for a branded refusal below 500. It returns null for a branded refusal at 500 or above, and null for any fault (`:268-276`).
- `classifyDocumentGenerationFailure` maps a `report: true` brand to `storage_failure` (`:327-340`).
- `db.createFailureReport` inserts through the cached shared Drizzle pool and **returns its input row** (`db.ts:358-362`). The installed mysql2 pool defaults are 10 connections, `waitForConnections: true` and `queueLimit` 0. The deployed DSN is not inspected and may override those defaults.

## Reporting matrix

Expectations assume a healthy writer. When reporting is saturated, timed out or unavailable, persistence is *skipped* or *unknown* and is logged as such.

| Failure | Writer expectation | Public outcome |
|---|---|---|
| Trusted unreadable-storage refusal (`PublicRefusal{report:true}`), e.g. the letterhead or attachment 409 | 1 eligible attempt, giving 1 row with a healthy writer, `storage_failure` | Each route's existing mapping. Delivery: 409 with its sentence. `estate.export` manifest catch: its own existing mapping. |
| Operational fault (`generationRefusal` returns null), including the branded Task 5 500, a DB fault before ownership (with `estateId ""`), a build or render fault, or a notes query or PDF fault | 1 eligible attempt, with its closed category | Existing fixed 500 or generic sentence; existing unconfirmed sentence |
| Required start audit not exactly true | 1 eligible attempt, explicit category `unexpected_generation_failure` | 503, no bytes, no fabricated transport event |
| Ordinary refusal with `report:false`: ownership NOT_FOUND (branded, `db.ts:610-624`), 403/404, applicability, stale binding, 413 size, 400 body | 0 writer calls | Unchanged, with the IDOR audit preserved |
| Handler returns that never throw: 401, suspension 403, busy 503, rate 429, Origin/CSRF/parser refusals before the handler | 0 writer calls | Unchanged |
| Success, a preflight whose optional timeline failed, a proven normal disconnect or abort, a handoff then finish or abort | 0 writer calls | Unchanged |

Positive tests use the real `PublicRefusal(…, {status:409, report:true})` constructor. Negative tests cover ownership NOT_FOUND and spoofed report flags, names, codes or causes.

## Helper: `server/exportFailureReporting.ts` (new; the only new logic)

```ts
type Op = "prepare_estate_export" | "download_letters" | "download_p8_all" | "download_package"
  | "download_estate_export" | "notes_export_pdf";
type Category = "storage_failure" | "generation_timeout" | "render_failure" | "unexpected_generation_failure";
export const EXPORT_REPORT_WAIT_MS = 1_000;
export const MAX_UNSETTLED_EXPORT_REPORTS = 2;   // process-local; see admission policy

export function exportFailureAttempt(operation: Op): Attempt;  // { operation, userId: null, estateId: "", claimed: false }
// Total, synchronous, never throws. Decides eligibility, claims the attempt and returns ONLY a scalar row (or null).
export function prepareExportFailureReport(attempt: Attempt, error: unknown,
  opts?: { category?: Category; answered?: boolean }): PreparedReport | null;
// Takes only the prepared scalar snapshot. Never throws or rejects; settles within EXPORT_REPORT_WAIT_MS.
export function submitExportFailureReport(prepared: PreparedReport): Promise<Outcome>;
// Outcome: "acknowledged" | "unconfirmed" | "timed_out" | "failed" | "saturated"
```

### `prepare` (synchronous, before any await or response)

`prepare` returns null in these cases:
1. `attempt.userId === null`;
2. `answered` is true, meaning headers already went out, so a later fault never claims a failed generation after bytes;
3. the attempt is already `claimed`, so a nested catch or concurrent path is a duplicate;
4. `generationRefusal(error)` gives a refusal with `report === false`, unless an explicit `category` is passed for the start-audit gate.

Otherwise it sets `claimed = true` synchronously. It then builds a frozen fresh literal:
- `id: nanoid()` (21 characters);
- `source: "document_generation"`;
- `operation`;
- `errorCode: category ?? classifyDocumentGenerationFailure(error)`;
- `userId` (the authenticated actor);
- `estateId` (the literal stored id, set only after the ownership check, otherwise `""`);
- `formCode: ""`;
- `reportStatus: "open"`;
- `occurredAt: Date.now()`.

The whole body runs inside `try/catch`, so a hostile error returns null **after** claiming. An attempt never reopens.

Nothing is spread. The error, request, response, body, notes, buffers and builder results never enter the snapshot.

### `submit` (asynchronous, scalar snapshot only)

**Admission:**
- If unsettled writes are at or above the cap, `submit` returns `saturated` and logs a closed line. The attempt stays claimed and there is no retry.
- Otherwise it reserves one slot and calls `Promise.resolve().then(() => db.createFailureReport(prepared.row))`, which turns a synchronous throw into a rejection.

**Settlement:**
- The reservation is released **exactly once**, through a once-flag, when the underlying write settles in either direction.
- A late rejection or late malformed result is consumed by that same handler.
- No second write happens and no late response is sent.

**Wait:**
- The write races an unref'd 1,000 ms timer, which is cleared on settle.
- The timer bounds *waiting* only and does not cancel the SQL.
- `timed_out` keeps the reservation until the write actually settles.

**Acknowledgement:** `acknowledged` only when all of these hold:
- the result is a non-null object;
- for each of the 9 written keys, `Object.getOwnPropertyDescriptor(result, k)` is a **data** descriptor whose `value` is `Object.is` the written value.

No getter or coercion is invoked. A proxy trap that throws, an ID-only object, mismatched fields, or `false`/`null`/`undefined` all give `unconfirmed`. A normal acknowledgement is not proof of a durable commit.

**Log:** exactly one closed line, `[export-report] ref=<id> op=<op> outcome=<outcome> failure=<failureClass(reportError)>`. It never contains a message, stack, cause, SQL, DSN, URL, filename, body, header, IP/UA or attemptId. The ref stays private; no browser reference is added.

### Admission policy (shared pool)

- **Cap.** At most **2** unsettled report writes per process. That is at most 20% of the verified library default pool of 10. It leaves at least 8 connections for application work, even if both report writes stall holding connections.
- **Why 2.** One stalled write doesn't immediately disable reporting. Export failures are rare and already per-user rate- and slot-limited (8 per 60 s).
- **Limits stated plainly.**
  - The deployed DSN may set a different pool size. The cap is process-local, not fleet-wide.
  - The existing unbounded writers (`controlledGenerationError`, `download_form`) and the audit recorders are not governed by this cap.
  - Failures beyond the cap are logged `saturated`, not reported.
- **Fallback.** If headroom cannot be established for a deployment, for example a configured pool of 2 or fewer, the safe fallback is the same cap with saturation logged. Any change to `db.ts`, a separate pool, credentials or infrastructure needs separate approval and is not proposed.

## Integration (four application files only)

### `server/downloadExportsRoute.ts`

**Setup:**
- Create the attempt after a successful parse: `OP[type]`, with `userId = user.id`.
- Set `attempt.estateId = estate.id` only after the exact-id and owner checks pass.

**Catch:**
1. **First**, with no awaits yet: `const prepared = prepareExportFailureReport(attempt, err, { answered: res.headersSent })`.
2. Then the existing log, the `export_delivery_failed` await and `renderDeliveryError`, unchanged in order and text.
3. Then `void submitExportFailureReport(prepared)` when `prepared` is set. Detached, bounded by the cap and the timer, never awaited by the handler, so the request's lifetime does not depend on reporting.

**Start-audit not exactly true:**
1. `prepare(attempt, null, { category: "unexpected_generation_failure" })`.
2. The existing 503.
3. A detached `submit`.

**Unchanged:** the slot cleanup on `res.once("close")`, the success path and `sendAttachment`'s finish/abort audit.

### `server/routers.ts` (`estate.export` only)

- Allocate the attempt at the start of the procedure body with `userId: ctx.user.id`. Each batched procedure call gets its own.
- Set `estateId` after `assertEstateOwned` returns.
- **Manifest catch:** `prepare` with the original error, *before* mapping. Keep the 413, branded and fixed-500 mapping as it is.
- **New outer `try/catch` around the body:** `const p = prepare(attempt, e); if (p) void submit(p); throw e;`. It rethrows the same object, so public output is unchanged. When the manifest catch already claimed, `prepare` returns null.
- The optional timeline failure remains a local catch, giving success and no report.

### `server/notesExportRoute.ts` (handler catch only)

- `userId` is set after auth and `estateId` after the ownership check.
- **Catch:** `prepare` first, then the existing log and 500 "Failed to generate PDF", then a detached `submit`.
- The PDF function, text, drawing, fonts, dates, filename and note scope are untouched.

### Lifecycle rules

- **Normal disconnect.** Proven only by observed lifecycle: `res.destroyed` before the build (an existing early return), or `close` without `finish` after `sendAttachment` (the existing aborted audit). Neither throws, so neither produces a report.
- **Abort naming.** A thrown `AbortError` or any other name is **never** treated as client cancellation; a provider abort is an operational fault.
- **Fault while the requester is gone.** A genuine fault thrown after the requester left before headers is still reported. The existing `renderDeliveryError` attempt to the gone socket is left as it is, and no additional response is added.
- **Headers already sent.** No report (`answered`), and no second response, because of the existing `headersSent` guard.

## Recorded dependencies (not changed)

- The `export_delivery_failed` await (`affidavitHistory.ts:484-503`) turns a rejection into false but can hang if the database hangs. The 1,000 ms report wait does not bound it or the total request duration, so this is not complete outage recovery.
- The `download_form` and `controlledGenerationError` writes are unbounded and outside the cap.
- The admin `storage_failure` copy reads "generated document".
- No export format changes (ZIP/PDF stay as they are). This is not an audit-policy rewrite.

## Verification (after approval)

**0. Evidence** in `.work/hybrid-remediation/task15/claude-pass01/`:
- Copy the plan to `docs/superpowers/plans/2026-10-23-task15-export-failure-reporting.md`.
- Write the preflight, re-reading AGENTS.md, .cursorrules, the four acceptance handoffs, `run-gates.cjs` and the launchers.
- Write the connected-feature matrix and a reference to the review.
- Save `before/` copies, SHA-256 hashes and a Node byte EOL census, and restore per-line terminators after edits.
- Correct the stale memories.

**1. Red.** Use the real route and router tests with the writer spied. The missing-writer failures to show:
- the letterhead 409 and the package-attachment 409, both via the real constructor;
- a manifest fault;
- an ownership-read DB fault;
- the commit and unconfirmed 500;
- the start-audit result false, throw and reject;
- a notes fault.

Save the red logs. Add `createFailureReport: vi.fn(async (row) => row)` to mocks that lack it.

**2. Green.** Make the smallest edits. Every existing status, message, legal and output assertion is kept.

**3. Helper suite**, with fake timers.
- **Eligibility and claim:** the matrix rows; spoofed `{report:true}`, name, code or cause gives no authority; hostile error getters, proxies and primitives return null after claiming.
- **Duplicates:** nested and concurrent calls on one attempt give one write. New invocations with a reused attemptId or Error object are independent.
- **Writer behaviour:**
  - acknowledgement: input-row return gives `acknowledged`; ID-only, mismatched fields, an accessor property, a throwing proxy trap and false/null/undefined give `unconfirmed`;
  - failure: a sync throw, a rejection and an unavailable writer give `failed`;
  - stalls: a hang gives `timed_out` while the reservation stays held; a late success or late malformed result after the timeout is consumed.
- **Accounting:** the reservation is released exactly once; the 3rd concurrent stall gives `saturated`.
- **Hygiene:** timers are cleared and there is no unhandled rejection.
- **Snapshot:** it contains only the 9 scalar keys, with no reference to the error, request or response. Synthetic SQL, DSN, token, URL and note-content markers are absent from rows, logs, JSON, HTML, tRPC output and audit metadata.

**4. Route and router.**
- Healthy letters, P8, package, estate and notes exports give 0 calls, with unchanged builders, contexts, members, filenames, bytes, audits, history and provenance.
- A foreign or unknown requested id is never `estateId`.
- Lifecycle cases: close-before-headers with a fault during the build gives 1 attempt and no extra response. Disconnect during the build without a fault gives 0. Disconnect while a report is pending changes nothing. Headers already sent gives 0. A thrown `AbortError` is reported.
- A stalled writer does not delay the response. Same-user recovery and other-user isolation hold after socket close.
- A batched tRPC request with 2 failing `estate.export` calls gives 2 attempts.
- Admin `list`, `detailPage`, `summary`, `trend` and `resolve` show the new operations, and a non-admin is denied.
- The incomplete-estate warning-and-proceed tests and the Task 6 MAC, replay and lifetime tests still pass, with no re-signing.

**5. Gates.** Read `run-gates.cjs` first.
- Focus: `claude-task15-focus1 focus --test-file=…` on the actual paths.
- Full: `claude-task15-pass1 check tests chatbot-check chatbot-tests build render`.
- Run the separate test-type diagnostic.
- Baseline is 6,444 root and 205 chatbot tests; counts may rise.

**6. Native and UI**, on the identity-guarded fictional fixture only.
- **Real MySQL:**
  - One reportable failure plus a fresh retry gives one row each with the expected scalars. Staff-only visibility holds, there is no foreign estate, audits and history are unchanged, and there are no generated storage references.
  - **Shared-pool stall:** a separate fixture session takes `LOCK TABLES failure_reports WRITE`, then N greater than 2 failures are injected. Prove at most 2 report inserts wait, the rest log `saturated`, an unrelated application query and audit complete promptly, and same-user and other-user sockets and slots recover. Then unlock and verify the pending rows settle.
  - Clean up only disposable owned rows.
- **Real React UI:** a preparation failure, a delivery failure then retry, a notes failure then retry, and a healthy output, using local deterministic injection.
- If no browser tool connects, report BLOCKED for that limit.

**7. Freeze.**
- The 26 frozen fixtures and protected hashes.
- Uncompressed archive members compared exactly. Only the DOCX `core.xml` created/modified text is normalized.
- Word and pixel checks are recorded as **user-deferred-not-passed**, with no Office automation.

**8. Independent review.** Read-only, on opus, in parallel:
- `pr-review-toolkit:silent-failure-hunter`: hangs, settlement, admission;
- `backend-design:security-reviewer`: privacy, IDOR, payload;
- a probate-integrity reviewer: Rule 29, statuses.

Fix confirmed in-scope findings. Reconcile the task-only diff from the declared paths with before/after copies and hashes.

**9. Handoff and STOP.**
- Report branch, HEAD and index; contracts; the diff; commands and counts.
- State the guarantees as limits: at most one writer invocation per invocation, process-local admission, unknown persistence possible.
- Report review findings by severity.
- Keep implementation-verified separate from acceptance. There is no SHIP claim.
- Nothing is staged, committed, stashed, pushed or deployed.

## Amendment A1 — post-review additions approved by Nick (2026-10-23)

Nick approved, narrowly, two additions that the independent review found necessary:

1. **Per-user staff-reporting limit.** `EXPORT_REPORTS_PER_USER = 8` per `EXPORT_REPORT_WINDOW_MS = 60 s`, outcome
   `rate_limited`. Approved **only as a limit on staff failure reporting**: it never limits generation, downloads, the
   notes PDF export, retries or Generate anyway. The window is module-private and read only inside
   `submitExportFailureReport`, whose outcome no request path awaits or reads; it shares no state with
   `documentGenerationAllowed`, the per-user export slot or any Generate anyway path. Skipped reports are identified
   honestly (`rate_limited`, like `saturated`) and are never counted as written.
2. **Late-result diagnostic.** One extra closed log line (`late_acknowledged` / `late_unconfirmed` / `late_failed`)
   when a write settles after the 1,000 ms wait. Approved **only** with the private reference, the operation and
   closed outcome/category fields — `ref=<row id> op=<operation> code=<closed category> outcome=<closed outcome>`, plus
   `failure=<closed failure class>` on failed outcomes — with no exception text, client contents, filenames,
   credentials or request data, and with **no second write and no second response**.

**Corrections to the r2 text above (A1 supersedes):**
- *"one eligible staff-report attempt per failed server invocation, which gives one `failure_reports` row when the
  writer is healthy"* and *"1 eligible attempt, giving 1 row with a healthy writer"* → **at most one staff-report
  attempt per eligible failed invocation; a row is written only when the report is admitted (not `saturated` or
  `rate_limited`) and the writer is healthy.** Ordinary refusals make no attempt. Not every failed invocation creates a row.
- The skip list and `Outcome` union also include `rate_limited`; the log adds a `late_*` line only after a timeout,
  carries `code=`, and carries `failure=` only on failed outcomes (supersedes *"exactly one closed line"*).
- *"already per-user rate- and slot-limited (8 per 60 s)"* is not true across the board: the notes route has no
  per-user generation budget (Task 11), `estate.export` is only under the general mutation limit, and download faults
  before the budget check are unbudgeted. The new reporting window is what bounds staff rows for those paths.
- The window is process-local; past 5,000 tracked users the oldest window is dropped, so the bound is per process and
  approximate under extreme user counts. `failureClass` stays closed while every `PublicRefusal` call site keeps its
  `name` within the typed union (Task 14 design; unchanged).

**Verification of A1:** both additions are in the source hashed before, and verified unchanged after, final gates
`claude-task15-pass2`. Guard tests for condition 1 were then added (retry, other exports, bulk generation, notes export
and Generate anyway all proceed after the window is exhausted), and everything was freshly re-verified in
`claude-task15-pass3`. An independent read-only check found both conditions MET. Real-browser evidence remains
**outstanding** (HTTP evidence does not substitute); see `.work/hybrid-remediation/task15/claude-pass01/browser-check-pending.md`.
