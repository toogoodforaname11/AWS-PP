# Client Intake Submission Retention Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Keep a client’s completed intake answers visible after the secure portal submission succeeds.

**Architecture:** The portal form owns its local intake state. Its successful submission callback must invalidate the submission list for status feedback without replacing the completed state with an empty form. This task changes only that callback and its focused component regression.

**Tech Stack:** React 19, TypeScript, tRPC React hooks, Vitest, Testing Library.

**Spec:** User-reported portal retest: after filling and sending the form, the form must not go blank.

## Global Constraints

- Keep the change scoped to the blank-after-submit defect; do not alter portal authorization, submitted-data persistence, lawyer review behavior, or court-form generation.
- Do not access real estate records or client data while validating.
- Preserve the existing success toast and submission-list invalidation.

## Review Focus

- Successful submission must retain all entered fields, including optional repeated people/items and custom answers.
- A failed submission must continue to keep entries intact and show the existing error path.
- A refreshed portal submission list may update status feedback without overwriting an ordinary submitted form.
- Revision-requested forms must still prefill the server-provided revision payload.
- Custom-question configuration refresh must retain the client’s existing answers.

---

### Task 1: Preserve completed portal intake after submission

**Files:**
- Modify: `client/src/components/ClientIntakeForm.tsx:343-356`
- Test: `client/src/components/ClientIntakeForm.test.tsx`

**Interfaces:**
- Consumes: `trpc.portal.submitClientIntake.useMutation({ onSuccess })` callback.
- Produces: A submitted form that retains the exact local `ClientIntakePayload` while the existing submissions query is invalidated.

- [ ] **Step 1: Write the failing component regression**

Capture the `useMutation` callback, complete a normal field plus a lawyer-authored custom answer, invoke `onSuccess`, and assert the entered values remain in the form.

- [ ] **Step 2: Run the focused test to verify it fails**

Run: `pnpm exec vitest run client/src/components/ClientIntakeForm.test.tsx --maxWorkers=1`

Expected: FAIL because the successful-submit callback recreates an empty form.

- [ ] **Step 3: Remove only the successful-submit state reset**

Keep the existing success toast and `clientIntakeSubmissions.invalidate()` call. Do not reset standard fields or custom-question answers.

- [ ] **Step 4: Run focused regression and typecheck**

Run: `pnpm exec vitest run client/src/components/ClientIntakeForm.test.tsx --maxWorkers=1 && pnpm check`

Expected: PASS.

- [ ] **Step 5: Verify the broader release**

Run the full serial test suite, production build, whitespace check, and local runtime health check before checkpointing.

## Self-Review

- Spec coverage: the plan directly covers the reported blank-after-submit behavior and does not combine any of the remaining portal defects.
- Scope: one component and its test; no server, schema, migration, or court-form files are required.
- Review-focus coverage: the focused test uses both an ordinary field and a custom answer; existing revision/custom-config tests retain coverage for the remaining state paths.
