# P5 Priority Control and Form-Focused Intake Audit Implementation Plan

**Status:** Complete — 2026-10-01

**Goal:** Make the Intake P5 WESA s.130 priority selection compact, readable, and accessible without altering its saved statutory selection; verify that fields visible in Form-focused Intake have a document or form-generation consumer.

**Architecture:** The existing Radix Select still saves `estate.applicantPriorityParagraph`. Its closed trigger now shows an abbreviated selection, while the bounded menu retains the full statutory wording. The Intake audit traced visible fields to document rendering, requirements, applicability, attachments, or generation completion logic; only verified case-file-only fields were removed from the compact mode.

## Completed work

### P5 priority dropdown polish

- [x] Added concise display labels for all WESA s.130 rows without changing their saved values or full statutory labels.
- [x] Constrained the control to a comfortable desktop width and the option panel to a responsive, scrollable width and height.
- [x] Added selected, hover, keyboard-focus, and short transition treatment; the regular select remains keyboard operable.
- [x] Added a regression proving the compact selection can change and retains the full legal option in the menu.

### Form-focused Intake field-consumer audit

- [x] Traced Form-focused Intake fields and conditional branches across `server/docgen.ts`, `shared/formRequirements.ts`, `shared/types.ts`, `server/routers.ts`, and document-attachment logic.
- [x] Preserved fields that populate a document or establish a required/available form, attachment, preflight fact, or completion path.
- [x] Removed two case-file-only companion fields from Form-focused Intake: manual codicil dates and the free-text grant-limitation note.
- [x] Retained the codicil count and limited-grant choice because they drive Form P9 delivery wording/attachment checks and the Form P19 limited-grant clause, respectively.
- [x] Recorded the complete source-level inventory in `docs/audits/form-focused-intake-consumer-inventory.md`.

## Scope constraints honored

No official P5 wording, generated document wording, renderer, document layout, form-generation logic, standard Intake behavior, or persistence contract changed.

## Verification

- [x] Focused dropdown, Intake, renderer, document-asset, requirement, and form-status regressions: 770 passed.
- [x] TypeScript: `pnpm check` passed.
- [x] Full serial suite: 4,328 passed; 3 skipped.
- [x] Production build: `pnpm build` passed.
- [x] `git diff --check` and scoped diff review passed; no document-renderer paths changed.
