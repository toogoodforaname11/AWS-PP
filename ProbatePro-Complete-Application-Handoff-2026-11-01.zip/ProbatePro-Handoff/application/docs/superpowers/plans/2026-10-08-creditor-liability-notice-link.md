# Creditor–Liability Notice Linkage Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let a lawyer safely link an identified Creditor contact to a recorded liability so an intestacy debt above $10,000 reaches the existing P1, notice-letter, and delivery-recipient flows without inventing a lender or delivery.

**Architecture:** Add one optional Inventory-to-Contact reference and keep it empty for legacy/unidentified liabilities. Centralize linked-liability value resolution in `shared/types.ts`, then pass the existing Inventory context into the current P1-recipient, form-status, letter, and delivery call paths. Inventory owns a compact selection and lawyer-oriented quick-add interaction; tRPC remains the validation boundary.

**Tech Stack:** React 19, TypeScript, Tailwind/Shadcn, Express 4, tRPC 11, Drizzle/TiDB MySQL, Vitest, DOCX + structured preview.

**Spec:** `docs/SPEC-creditor-liability-notice-link.md`

## Global Constraints

- Use an additive, generated Drizzle migration only; apply it through the reviewed WebDev SQL capability after plan approval.
- Never infer, create, or backfill a lender from Inventory description text, including “TD mortgage”.
- A creditor link changes recipient eligibility only; it must never mark P1 as sent or P9 delivery as made.
- Preserve P2’s existing high-value-unlinked-liability blank-fill safeguard and do not change P2/P9 official wording, geometry, checkboxes, or popup fields.
- Keep all form completion non-blocking. An unlinked or incomplete creditor remains a warning/blank state, not a false sworn fact or a hard block.
- Validate same-estate ownership and creditor classification on the server; never trust the client selection.
- Do not add dependencies, access user records, or change the separate P9-renderer and P44 tasks.

## Review Focus

1. **Unlinked $212,400 mortgage:** remains without a recipient and retains the existing P2 blank-fill protection; no Contact is invented. Covered in Task 3 document tests.
2. **Threshold and estate path:** exactly $10,000 or a creditor-only testate debt stays out; $10,000.01 on an intestacy enters the recipient set. Covered in Task 2 shared tests.
3. **Manual claim versus linked debt:** use the larger amount rather than adding values, so one debt is not double-counted. Covered in Task 2 shared tests.
4. **Data lifecycle:** cross-estate/non-creditor links are rejected; deletion clears a link; duplication remaps a link to the copied contact. Covered in Task 3 router tests.
5. **Lawyer quick-add flow:** saving a new Creditor contact requires actual entered identity, selects it in the liability draft, and cancelling creates nothing. Covered in Task 4 UI tests.

---

## File Structure

| File | Responsibility |
| --- | --- |
| `drizzle/schema.ts` | Add the optional `inventory.creditorContactId` field. |
| `drizzle/0168_*.sql` | Generated additive migration; no backfill or destructive SQL. |
| `shared/types.ts` | Canonical effective creditor-value helper and Inventory-aware notice/form helpers. |
| `server/db.ts` | Clear same-estate creditor links before deleting a contact. |
| `server/routers.ts` | Validate write payloads, duplicate-map contacts, and carry Inventory into delivery/letter/form flows. |
| `server/docgen.ts` | Pass `GenContext.inventory` into the existing P1 recipient resolver. |
| `client/src/pages/EstateDetail.tsx` | Liability-only Creditor selector, compact “Add creditor contact” dialog, query invalidation, and Inventory-aware forms status. |
| `shared/p1-notice-creditor-limb.test.ts` | Statutory threshold, no-will, and non-fabrication regression tests. |
| `server/routers.inventory.test.ts` | Inventory link validation, contact deletion, and duplication remapping tests. |
| `server/docgen-integration.test.ts` | P1/letter recipient integration regression. |
| `server/docgen.referenced-documents.test.ts` | P2 unlinked-liability safeguard regression remains explicit. |
| `client/src/pages/EstateDetail.notice-recipient.test.ts` | Liability editor/link/quick-add and recipient-visibility regressions. |
| `docs/audits/creditor-liability-notice-link.md` | Completion record stating the legal and task boundary. |
| `todo.md` | One precise completion record after fresh full validation. |

## Implementation Tasks

### Task 1: Add the explicit, empty-by-default link

**Files:**
- Modify: `drizzle/schema.ts:583-650`
- Create: generated `drizzle/0168_*.sql`
- Test: `server/routers.inventory.test.ts`

**Interfaces:**
- Produces: `Inventory["creditorContactId"]: string`, defaulting to `""`.
- Consumed by: Tasks 2–4.

- [ ] **Step 1: Add schema-driven regression fixtures**

Extend the Inventory router tests with the expected empty link for ordinary assets and newly created liabilities. Assert legacy-style rows without a supplied link remain unlinked rather than receiving a generated Contact id.

- [ ] **Step 2: Run the focused test to verify the new field is absent**

Run: `pnpm exec vitest run server/routers.inventory.test.ts --maxWorkers=1 -t='creditor contact link'`

Expected: FAIL because no persisted `creditorContactId` contract exists.

- [ ] **Step 3: Add `creditorContactId` to `inventory` in `drizzle/schema.ts`**

Use `varchar("creditorContactId", { length: 36 }).notNull().default("")`. Place it adjacent to `securityStatus`/`securedAssetId`, documenting that it is an identified creditor reference only for liabilities and carries no inference/backfill semantics.

- [ ] **Step 4: Generate and inspect the migration**

Run: `pnpm drizzle-kit generate`

Expected: one additive migration that adds the empty-default column only. Read the generated SQL before proceeding; reject any backfill, delete, table rewrite, or unrelated schema mutation.

- [ ] **Step 5: Re-run the focused test**

Run: `pnpm exec vitest run server/routers.inventory.test.ts --maxWorkers=1 -t='creditor contact link'`

Expected: PASS after the Task 3 router endpoint work is complete; retain the generated migration untouched until reviewed application.

### Task 2: Create the single canonical linked-creditor eligibility path

**Files:**
- Modify: `shared/types.ts:63-319, 2966-3010, 3652-4070`
- Test: `shared/p1-notice-creditor-limb.test.ts`
- Test: `shared/formStatus.test.ts`

**Interfaces:**
- Consumes: `Inventory.creditorContactId`, `isInventoryValueRecorded`, `probateItemValue`, `contactHasRole`, and `estateHasNoWillOfRecord`.
- Produces:
  - `isCreditorContact(contact: Pick<Contact, "role" | "recipientType">): boolean`
  - `effectiveCreditorClaimAmountCents(contact: Contact, inventory?: Inventory[]): number`
  - Optional `inventory: Inventory[] = []` argument on `p1NoticeRecipients`, `isP1NoticeRequired`, `buildNoticeDeliveryState`, `requiresPGT`, `formStatus`, `additionalFormsRequired`, and `grantPackageCodes` where their P1/P9 consequence is evaluated.

- [ ] **Step 1: Write failing shared eligibility tests**

Add these `p1NoticeRecipients(estate, contacts, inventory)` cases:

- a no-will estate includes a named Creditor with a linked, recorded `$212,400` mortgage even when `claimAmountCents` is `0`;
- exactly `$10,000.00` remains excluded and `$10,000.01` is included;
- a creditor-only linked liability on a testate estate remains excluded;
- an unlinked `$212,400` liability never invents a recipient;
- two linked debts aggregate, while a larger manually recorded claim wins instead of being added to the linked total.

Add `formStatus("P1" | "LETTER" | "P9", estate, contacts, inventory)` coverage proving the linked high-value creditor makes these forms required in the shared source of truth.

- [ ] **Step 2: Run the shared red loop**

Run: `pnpm exec vitest run shared/p1-notice-creditor-limb.test.ts shared/formStatus.test.ts --maxWorkers=1`

Expected: new linked-liability assertions fail against the Contact-only resolver.

- [ ] **Step 3: Implement canonical helpers and optional Inventory plumbing**

Implement `isCreditorContact` from the existing normalized role/recipient-type conventions. Implement `effectiveCreditorClaimAmountCents` as `Math.max(manualClaim, sum(recorded linked liabilities))`; never add manual and linked amounts.

Update `isCreditorOnlyNoticeRecipient` to use the effective amount and ensure every P1/P9-dependent helper passes the optional Inventory array through to the same resolver. Keep defaults `[]` so unrelated callers and legacy tests retain existing behavior.

- [ ] **Step 4: Run the shared green loop**

Run: `pnpm exec vitest run shared/p1-notice-creditor-limb.test.ts shared/formStatus.test.ts --maxWorkers=1`

Expected: PASS, including existing creditor-only and non-creditor entitlement tests.

### Task 3: Validate lifecycle writes and propagate the real Inventory context

**Files:**
- Modify: `server/routers.ts:348-357, 471-475, 2242-2338, 2981-3180, 3259-3263, 4661-4662, 4924, 5309-5391`
- Modify: `server/db.ts:913-918`
- Modify: `server/docgen.ts:1041-1055`
- Test: `server/routers.inventory.test.ts`
- Test: `server/routers.estateDuplicate.test.ts`
- Test: `server/docgen-integration.test.ts`
- Test: `server/docgen.referenced-documents.test.ts`

**Interfaces:**
- Consumes: Task 2 helpers and the `inventory.creditorContactId` column.
- Produces:
  - `assertCreditorLiabilityLink(estateId: string, category: string, creditorContactId: string): Promise<void>` internal router helper.
  - `requiredDeliveryRecipients(estate, contacts, inventory)` and `requiredPreflightRecipients(estate, contacts, deliveries, inventory)`.
  - `p1Recipients(ctx)` delegates with `ctx.inventory`.

- [ ] **Step 1: Write failing server-integrity tests**

In `server/routers.inventory.test.ts`, add tRPC-level assertions that create/update:

- accepts an empty link for a liability;
- accepts a same-estate Creditor contact;
- rejects a missing contact, cross-estate contact, non-creditor contact, and any non-liability link;
- clears an existing link when the item is reclassified away from `liability`.

Add deletion coverage proving `contact.delete` clears only matching same-estate Inventory links. Add `server/routers.estateDuplicate.test.ts` coverage proving the copied liability points to the copied creditor id—not the source contact id.

- [ ] **Step 2: Run the server red loop**

Run: `pnpm exec vitest run server/routers.inventory.test.ts server/routers.estateDuplicate.test.ts --maxWorkers=1`

Expected: new lifecycle assertions fail before validation, cleanup, and remapping exist.

- [ ] **Step 3: Implement server-side validation and lifecycle integrity**

Add the explicit `creditorContactId` input to `inventory.create`; normalize it to `""` unless the category is `liability`. For both create and partial update, load the stored item where needed, derive the post-update category/link, and call `assertCreditorLiabilityLink` before persistence.

In `db.deleteContact`, use one transaction to clear `inventory.creditorContactId` rows for the same estate before deleting the contact. In estate duplication, create a source-contact-id → duplicate-contact-id map and remap each liability’s creditor link from that map; never retain a source-estate id.

Thread Inventory into `requiredDeliveryRecipients`, preflight recipient calculation, delivery procedures, `document.getLetterRecipients`, P46 recipient calculation where it uses P1 recipients, and all router-side `formStatus`/package calls with loaded Inventory. Change `p1Recipients(ctx)` to call `p1NoticeRecipients(ctx.estate, ctx.contacts, ctx.inventory)`.

- [ ] **Step 4: Add failing document-flow regressions**

Add a no-will fixture with a named TD Creditor contact, linked recorded `$212,400` liability, and no manual claim amount. Assert P1/letter recipient resolution includes TD and the delivery-recipient source includes TD. Assert no delivery record is created and no P9 delivery statement is rendered.

Keep (or add) the explicit P2 regression where the same high-value liability is unlinked: P2 omits the false no-creditor sentence and uses the existing blank fill in DOCX and preview.

- [ ] **Step 5: Run server and document green loops**

Run:

```bash
pnpm exec vitest run server/routers.inventory.test.ts server/routers.estateDuplicate.test.ts --maxWorkers=1
pnpm exec vitest run server/docgen-integration.test.ts server/docgen.referenced-documents.test.ts --maxWorkers=1
```

Expected: PASS. The linked contact appears as an eligible recipient only; no test may indicate automatic sending or sworn delivery.

### Task 4: Build the lawyer-safe Inventory interaction

**Files:**
- Modify: `client/src/pages/EstateDetail.tsx:5571-5883, 5885-6548, 7787-9070`
- Test: `client/src/pages/EstateDetail.notice-recipient.test.ts`
- Test: `client/src/pages/EstateDetail.contacts-form-focused.test.tsx` only if the compact contact dialog reuses its selector semantics

**Interfaces:**
- Consumes: `creditorContactId` from Task 1 and `isCreditorContact` eligibility semantics exposed by the contact data returned from tRPC.
- Produces: a liability-only linked Creditor selector plus compact direct Creditor-contact creation, with the saved id immediately selected in the unsaved liability draft.

- [ ] **Step 1: Write failing UI regressions**

Cover these behaviors:

- the Creditor selector renders only when `item.category === "liability"` and lists only contacts whose role or recipient type marks them as creditors;
- an existing selected creditor id is retained on edit; choosing a non-liability category clears it before the mutation payload;
- “Add creditor contact” opens a compact nested dialog requiring the user-entered creditor name, creates a Contact explicitly classified as `creditor`, invalidates the Contact query, and selects the returned id in the current liability draft;
- cancelling that dialog creates no contact and leaves the Inventory draft unaltered;
- save invalidates Inventory, totals, recipient, readiness, form-status/preflight, delivery, and letter-recipient data.

- [ ] **Step 2: Run the UI red loop**

Run: `pnpm exec vitest run client/src/pages/EstateDetail.notice-recipient.test.ts --maxWorkers=1`

Expected: FAIL because the liability form has neither link selection nor quick-add behavior.

- [ ] **Step 3: Implement the selector and compact Creditor-contact dialog**

Fetch Contacts in `InventoryTab` and pass them into `InventoryFormFields`. Add the selector under the existing liability/security controls, with clear copy that linking identifies a potential notice recipient and does not record delivery.

Implement the compact nested dialog with name and address-for-service inputs. It must call `contact.create` with `role: "creditor"` and `recipientType: "creditor"`; it must not derive values from the liability description. Disable its save control until a nonblank legal name is entered, provide a visible field message, and keep cancellation side-effect free. On success, select the returned id in the current draft and invalidate contacts.

Include `creditorContactId` in create/update payloads only for liabilities; clear it in client state and payload when category changes. Add the specified query invalidations to existing mutation success paths. Fetch Inventory in `FormsTab` and pass it to every P1/LETTER/P9-dependent `formStatus`/package calculation so the visible catalog immediately reflects the link.

- [ ] **Step 4: Run the UI green loop**

Run: `pnpm exec vitest run client/src/pages/EstateDetail.notice-recipient.test.ts --maxWorkers=1`

Expected: PASS with existing recipient UI coverage preserved.

### Task 5: Apply the reviewed migration and complete verification

**Files:**
- Modify: `docs/audits/creditor-liability-notice-link.md`
- Modify: `todo.md`
- Update: WebDev checkpoint

**Interfaces:**
- Consumes: generated migration and all completed tasks.
- Produces: a documented, applied schema change and evidence-based completion record.

- [ ] **Step 1: Inspect the generated migration and request/confirm execution approval**

Read the exact `drizzle/0168_*.sql`. Confirm it is additive only (`ADD COLUMN` with empty default), contains no data backfill or destructive statement, and has no unrelated changes. Apply it only through the WebDev SQL capability under the approved plan.

- [ ] **Step 2: Run focused end-to-end coverage**

Run:

```bash
pnpm exec vitest run shared/p1-notice-creditor-limb.test.ts --maxWorkers=1
pnpm exec vitest run server/routers.inventory.test.ts server/routers.estateDuplicate.test.ts --maxWorkers=1
pnpm exec vitest run server/docgen-integration.test.ts server/docgen.referenced-documents.test.ts --maxWorkers=1
pnpm exec vitest run client/src/pages/EstateDetail.notice-recipient.test.ts --maxWorkers=1
```

Expected: PASS with exact $10,000, testate, unlinked, duplicate, delete, P1/letter, delivery-source, and P2-blank safeguards covered.

- [ ] **Step 3: Run repository-wide verification**

Run:

```bash
pnpm check
pnpm test -- --maxWorkers=1
pnpm build
git diff --check
git status --short
```

Expected: all commands exit `0`; review the final diff for only the planned schema, canonical recipient logic, persistence, UI, tests, and documentation changes.

- [ ] **Step 4: Record the completion boundary**

Write `docs/audits/creditor-liability-notice-link.md` stating that the release makes a linked, identified Creditor eligible for existing P1/letter/delivery-recipient flows; it does not create a creditor, send P1, attest P9, or repair P9 renderer content. Append exactly one matching `todo.md` entry only after fresh passing output.

- [ ] **Step 5: Save a WebDev checkpoint**

Use `webdev_save_checkpoint` with a message that names the explicit liability-contact link, threshold/no-will constraints, non-fabrication and non-delivery boundary, migration application, and fresh validation results.

## Self-Review

- **Spec coverage:** Tasks 1–4 cover the additive link, creditor validation, recipient integration, lifecycle integrity, lawyer workflow, and non-blocking behavior. Task 5 covers migration application, audits, and full verification.
- **Type consistency:** Every downstream helper receives `inventory?: Inventory[]`, defaulting to `[]`; `p1Recipients` already receives mandatory `GenContext.inventory`.
- **Review focus coverage:** Each of the five high-risk conditions is pinned to Tasks 2–4 and re-run in Task 5.
- **Scope discipline:** The plan deliberately leaves P2/P9 document wording/layout, delivery attestation, P44, and Consent/Nomination logic untouched.

## Execution Handoff

Plan complete and saved to `docs/superpowers/plans/2026-10-08-creditor-liability-notice-link.md`. **Native implementation** is recommended because the schema, canonical recipient API, router plumbing, document generator, and UI all depend on one another and a change to the shared interface must be verified coherently. A fresh whole-change review will follow the final validation.
