# Client Intake Latest Submission Selection Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Open the newest client intake submission after a lawyer reloads the estate Client Portal tab.

**Architecture:** The protected query already returns estate-scoped submissions ordered by descending submission time. The review component will defensively normalize that order before both choosing its automatic review target and rendering the submission selector, so an out-of-order cache or mocked response cannot make an older record the default. A lawyer’s explicit selection remains respected.

**Tech Stack:** React 19, TypeScript, tRPC, Vitest, Drizzle/TiDB MySQL.

**Spec:** User-reported retest finding: after a reload, the review panel opens an older submission rather than the newest one.

## Global Constraints

- Keep submission payloads, client identity data, estate ownership checks, and court-form code untouched.
- Do not infer, delete, or apply intake facts as part of selecting a submission.
- Preserve an explicit lawyer-selected submission through normal re-renders.
- Add a regression that is red against the former first-pending behavior.

## Review Focus

- Two pending submissions returned oldest-first: the newest timestamp must be active by default.
- A newer non-pending submission versus an older pending submission: newest still wins on first load.
- A lawyer click on an older submission: re-renders must retain that explicit selection.
- Equal timestamps: keep list handling stable without discarding either submission.
- Empty or loading result: preserve existing safe states.

---

### Task 1: Normalize and select client submissions

**Files:**
- Modify: `client/src/components/ClientIntakeReview.tsx`
- Test: `client/src/components/ClientIntakeReview.test.tsx`

**Interfaces:**
- Consumes: `Submission[]` from `clientIntake.listForEstate` with `submittedAt`.
- Produces: newest-first selector rendering and automatic selection of that newest submission when no valid explicit selection exists.

- [ ] **Step 1: Add a red review-component regression**

Provide an older pending submission first and a newer submission second. Assert the newer submission’s report is initially active rather than the older pending report.

- [ ] **Step 2: Run the focused test to verify the reported failure**

Run: `pnpm exec vitest run client/src/components/ClientIntakeReview.test.tsx --maxWorkers=1`

Expected: the new regression fails because the prior effect chooses the first `submitted` item.

- [ ] **Step 3: Normalize before selection and rendering**

Derive a newest-first submission array from `submittedAt`, use it for the `active` record, automatic fallback selection, and visible selector. Do not reset a valid explicit selection.

- [ ] **Step 4: Run focused tests and TypeScript**

Run: `pnpm exec vitest run client/src/components/ClientIntakeReview.test.tsx --maxWorkers=1 && pnpm check`

Expected: all focused tests and TypeScript pass.

- [ ] **Step 5: Run release verification and checkpoint**

Run the serial suite, production build, whitespace check, scope review, and local/preview health checks. Record the audit/tracker entry only after fresh successful output, then checkpoint the isolated repair.

## Self-Review

This plan changes one review component and one regression suite. It covers the reported reload default, resists response ordering differences, avoids data mutations, and leaves all portal session, API, database, review/apply, and court-form behavior outside scope.
