# Task 9 — Cookie-independent generated-document delivery (plan r2; STOP for approval)

> **Kept from r1, as Nick decided:**
> - D1: native form for cookie-only sessions; one authenticated fetch only when the supported fallback token exists.
> - D2: the shared existing `app_session_id` reader.
> - D3: 512 MiB ZIP / 64 MiB DOCX-PDF ceilings; 15-minute headers, 60-second idle and 30-minute body deadlines.
> - D4: success-only existing toasts.
>
> **r2** answers Nick's 2026-10-23 plan review. The changes are listed below. Nothing is implemented. Plan mode
> allowed writing only this file; step 0 copies it to `docs/superpowers/plans/` after approval. Task 9 only: no
> other task prompt is an input, Tasks 7/8 are not reopened, there is no Word retry, no app transition and no
> production/AWS access.

## r2 revision record

| Nick's point | r2 answer (section) |
|---|---|
| 1. Null-only handoff check | Activation-time **session snapshot (token + client session generation)**, checked when headers arrive and before handoff. Covers clearing, A→B non-empty replacement and cookie-preview logout. Rotation is cancelled conservatively and then explicitly retried. (Design → Session identity) |
| 2. Dev-log exception | **D5**: credential-bearing header maps redacted in the debug collector and at the Vite log sink. Both boundaries are tested with fictional sentinels. (Design → Diagnostics; Verification §2) |
| 3. JSON size claim | **D6**: the Bearer path keeps the native **urlencoded** envelope, the same serializer the Task 6 threshold test proves at 8,349 B. The preview keeps its pinned JSON. Boundary tests use the Task 6 all-17-field shape. (Design → Request) |
| 4. Bind browser proof to final build | QA-only **final build/source manifest**, hashing every served file and the touched sources; CDP-loaded asset hashes must match it. (§0, §6) |
| 5. Identity and stale drivers | QA-only **identity-case driver** with identity guards, disposable rows and a restoration receipt. **Two executable stale recipes**: a UI row-replacement 409, and a digest 409 on Bob Smith's postal address with mandatory restoration. (§5, §6) |
| 6. Notes capture | QA-only one-string capture-allowlist fix (`/api/notes/export-pdf`), one-shot arming, and per-response hash matching for native and Bearer notes. The notes audit stays not applicable. (§5, §6) |
| 7. Browser-shaped responses | Shared `browserResponse()` test factory with real `Response`/`ReadableStream` and `type: "basic"`/`"opaqueredirect"`. Production accepts only `basic`. (§2) |
| Smaller fixes | The Blob revoke is a **policy, not a guarantee**. Prefix **plus tail-marker** container checks, with genuine fixtures and truncation controls. Caller labels made explicit. The Task 13 prompt dropped as an input. No `AGENTS.md` is a fact. The Cloud Run recollection is removed. |

## Context

Nick selected Task 9 next (2026-10-23 12:06 local) and closed Task 15 by decision. Its real-browser check stays
outstanding, and Word/pixels stay user-deferred-not-passed. Tasks 7/8 keep their recorded findings.

**Workspace, verified read-only:**
- branch `security/hybrid-vault-review`, HEAD `db0d7e9161bc3899b75858fab58bce54e3d5247a`;
- index empty, 122 dirty paths preserved;
- one pre-existing stash entry, not ours, untouched;
- three idle peer sessions attached to this worktree.

**Governance:** `RULES.md` (Rule 29 freeze, Rule 28), `.cursorrules` and Nick's stated preferences. There is no
`AGENTS.md` in this repo.

## Root cause (bounded trace; code-review-graph at HEAD: `callers_of postDownload` = 9 sites; tests from grep)

1. **The native form carries no credential.** `client/src/lib/utils.ts:70` `postDownload` submits a hidden
   urlencoded form, and a form cannot carry `Authorization`. With cookies blocked, tRPC authenticates through the
   Bearer fallback (`client/src/main.tsx:46-65`). The attachment POST, though, arrives with neither credential, so
   `server/downloadRoute.ts:103` (and the export/notes equivalents) answers 401, which a navigation renders as the
   "Download not available" page.
2. **The preview modal's fetch also never sends the token.** `doDownloadDocx` (`EstateDetail.tsx:7409-7480`) looks
   for `"manus_session="`, but `COOKIE_NAME` is `"app_session_id"` (`shared/const.ts:1`). It also saves any 2xx
   body as a document, reads without a bound, has no timeout, and revokes the Blob URL right after `click()`.

**Server facts, read-only and unchanged:**
- **Cookie first:** `sdk.authenticateRequest` (`server/_core/sdk.ts:298-311`) reads Bearer only when no cookie
  exists. A present invalid cookie never falls through to another identity.
- **Rotation:** `X-Rotated-Session` is set only inside the tRPC context (`server/_core/context.ts:142`).
- **Delivery guard** (`server/_core/deliveryRouter.ts:186-215`):
  - It needs a trusted `Origin`. Fetch's default `cors` mode sends the real Origin on a same-origin POST; only
    navigations get `Origin: null` under `no-referrer`.
  - It needs `Sec-Fetch-Site` absent or `same-origin`.
  - It accepts a JSON or urlencoded body within the 8,349 (urlencoded form) / 8,353 (JSON form) / 8,192 caps.
  - Refusals answer JSON `{error}` to non-navigation requests (`:77-93`).
  - Success is one `sendAttachment` (`:142-163`).

## Decisions

**D1 — Transport selection (Nick, kept).** The fallback token is read once per activation, before any request.
- **No token:** the existing native form, unchanged (fields, urlencoded, same tab, 2-s window). The browser keeps
  streaming large exports, and no new client limit touches this path.
- **Token present:** one same-origin `fetch` with `credentials: "include"`, so a valid cookie still wins
  server-side. There is no user-agent guess and no cookie probing.
- **Preview modal:** keeps fetching for every session.
- **No native re-submission** ever follows a fetch failure.
- Future feedback ownership stays with queue items 13 (truthful UI) and 12 (preview lifecycle) (`queue:57, :60`).

**D2 — One token source (kept), plus one session generation (new for point 1).** `client/src/lib/fallbackSession.ts`
holds the existing parser. `main.tsx` `headers()` calls it, and `onResponse` rotation ownership stays where it is.
`botClient.ts` (chatbot) keeps its own copy.

**D3 — Ceilings and deadlines (Nick, kept; fetch path only).** They are not universal server bounds.

| Class | Ceiling | Server basis | Status |
|---|---|---|---|
| `application/zip` (all exports; P1, P9, P34 form ZIPs) | 512 MiB | Only the estate archive is explicitly bounded: ≤500 files, ≤50 MiB each, ≤250 MiB stored bytes (`estateExport.ts:7-9, 74-97, 162`). P1, letters and package have no total bound (codicil count, ≤200 letters × letterhead, uncapped P34 sets). | Accepted by Nick, extremes included |
| DOCX | 64 MiB | Text forms; LETTER embeds a ≤5 MiB image or a ≤10 MiB template (`docgen.ts:1363-1372, 6634-6731`) | Accepted |
| `application/pdf` (notes) | 64 MiB | ≤500 notes × ≤10,000 chars, text only (`db.ts:2088-2097`; `routers.ts:6677`) | Accepted |
| Refusal body (status ≥ 400) | 65,536 B | Fixed refusals ≤510 chars; renderer refusals ≤4,096 (`failureReporting.ts:244`); package names list ≤≈51 KB; no report id, stack or upstream text | Over the limit → generic sentence |

**Deadlines:**
- 900,000 ms to the response headers. An estate archive can spend 25 × 30 s in storage reads,
  `storageRegistry.ts:108-109, 728-738`.
- 60,000 ms with no body chunk.
- 1,800,000 ms for the body.
- The fetch path buffers up to the ceiling in the tab, about 2× transiently.

**D4 — Success-only existing toasts (Nick, kept).** An auto-download caller shows its existing text only for
`submitted` (native) or `handed-off` (fetch), through `void deliverAttachment(…).then(…)`. That keeps the
mutation's own pending time unchanged: TanStack 5.90.2 awaits `onSuccess`. There is no new wording.

**D5 — Credential redaction in development diagnostics (new; for approval).**
- The debug collector stores fetch request and response header maps raw: `client/public/__manus__/debug-collector.js:470-485`
  (request), `:503` (response).
- The Vite plugin injects it outside production (`vite.config.ts:81-98`) and appends the entries to
  `.manus-logs/*.log` (`:52-69, :107-117`).
- So `Authorization` and `X-Rotated-Session` are persisted in development today, for tRPC already and for Task 9's
  fetches next.
- **The fix is narrow, at two boundaries:**
  - **Collector:** both header maps go through the collector's existing `sanitizeValue`. Its key list (`:30-38`)
    already redacts any key containing `password`, `token`, `secret`, `key`, `authorization`, `cookie` or
    `session`.
  - **Sink:** `handlePayload` applies the same key rule to the `request.headers`/`response.headers` of each network
    entry before `writeToLogFile`. This guards any producer, including a cached old collector.
  - Non-sensitive diagnostics stay: status, URL, content type and length, disposition, and the already-sanitized
    bodies.
- No other logging change. Existing logs are not read, scanned or deleted. Production is unaffected.
- **Declared contingency:** if the test cannot import `vite.config.ts`, the plugin moves unchanged into a new
  `vite.debug-collector.ts`. That is an extra file, used only if needed.

**D6 — Encoding per path (new; for point 3).**
- **The Bearer fetch for the 9 native callers** keeps the native envelope: the body is
  `new URLSearchParams(Object.entries({ ...fields, attemptId })).toString()` with
  `Content-Type: application/x-www-form-urlencoded`.
  - That is the serializer the native form uses, and the one the Task 6 threshold test encodes with
    (`server/formDeliveryBinding.body-size.routes.test.ts:108-109`). It is proven at exactly 8,349 B admitted and
    8,350 refused through the real guard (`:211-238`).
  - The descriptor values are ids, codes, dates, the 148-byte binding and `JSON.stringify` output, so no raw CR/LF
    can make the native form longer. The body is therefore the native submission's bytes.
- **The preview keeps its pinned JSON envelope** (`EstateDetail.preflight.test.tsx:41-46`), so its existing 8,353 B
  behaviour is unchanged.
- **JSON is not used for the Bearer path**, because the Task 6 test pads per encoding: JSON spends more envelope
  bytes per field. A real all-17-field descriptor at the form threshold would exceed the JSON cap; Nick's typed
  counterexample gives 8,349 vs 8,359.
- No cap is raised, and nothing is re-POSTed in another encoding.

## Design

### `client/src/lib/fallbackSession.ts` (new)
- `readFallbackSessionToken(): string | null` follows `main.tsx:51-63` exactly. It takes the first `;` entry whose
  trim starts with `${COOKIE_NAME}=`. An empty value or a storage throw gives `null`.
- `fallbackAuthorizationHeader()` returns `{ Authorization: "Bearer …" }` or `{}`. It is used by `main.tsx`.
- `clientSessionGeneration(): number` reads an in-memory counter. It is not a store and holds no token.
- `clearFallbackSession()` increments the generation, then runs `try { sessionStorage.removeItem("manus-cookie") } catch {}`.
  It replaces the two existing removals:
  - `useAuth.ts:48`: logout cleanup, before the hard reload at `:56`.
  - `Settings.tsx:370`: account deletion, before the 520 ms in-app redirect at `:385`.
  - The store effect is identical to today; only the bump is added.

### Session identity at handoff (point 1)
- **Snapshot.** At activation, a snapshot `{ token, generation }` is taken. `token` is the exact string sent in
  `Authorization`, or `null` for a cookie-only preview fetch.
- **Valid** only while `clientSessionGeneration() === generation && readFallbackSessionToken() === token`. That is
  exact string equality; nothing is decoded and nothing is written.
- **When checked:** once when the response headers arrive, and again immediately before handoff. A mismatch aborts
  the request, with stop reason `session-changed`, and returns
  `{ kind: "failed", reason: "session-changed", message: "The download could not be completed. Please try again." }`.
- **Coverage:**

  | Case | Caught by |
  |---|---|
  | Token cleared (logout, account deletion) | generation and token |
  | A→B non-empty replacement | token |
  | Cookie-only preview logout | generation |

- **Same-user rotation** (a concurrent tRPC response writing a new token, `main.tsx:69-74`) is treated
  conservatively as a change. Nothing is handed off. The toast asks for a retry, and the explicit retry is a fresh
  activation that reads the rotated token and succeeds. Rotation happens at most once per half session lifetime
  (`SESSION_ROTATION_THRESHOLD_MS`, 15 days).
- **Residual, recorded:** a cookie changed by another tab is invisible here (an httpOnly cookie, per-tab
  `sessionStorage`). That response was authorized under the cookie that sent it, and goes only to the tab that
  asked for it.
- This is a client handoff guard. It does not claim the server mis-authorized anything, and it does not change
  server authentication.

### `client/src/lib/attachmentDelivery.ts` (new; replaces `postDownload`)
```ts
export type DeliveryOutcome =
  | { kind: "invalid" }      // descriptor refused: no request, no storage read, control untouched
  | { kind: "suppressed" }   // this control already has a delivery in flight
  | { kind: "submitted" }    // cookie-only native form posted; outcome not observable (unchanged path)
  | { kind: "handed-off"; filename: string; bytes: number }
  | { kind: "refused"; status: number; message: string }
  | { kind: "failed"; reason: "network" | "timeout" | "redirect" | "invalid-response" | "too-large" | "incomplete" | "session-changed"; message: string }
  | { kind: "cancelled" };   // caller abort
export function deliverAttachment(delivery: PostDelivery, control?: HTMLElement | null): Promise<DeliveryOutcome>;
export function fetchDeliveryAttachment(delivery: PostDelivery, signal?: AbortSignal): Promise<DeliveryOutcome>;
```
- **`postDownload` goes away.** It and its `WeakSet` move out of `utils.ts` (where `newAttemptId` stays), and the
  old name is deleted. Every caller is edited, so no Promise can pass for the old boolean.
- **`deliverAttachment` is a plain function, not `async`, and has no Promise executor around `form.submit()`.**
  - It runs validate → suppress → snapshot → native or fetch.
  - The native submit stays synchronous: `p8-download:234-242` and `p7-draft:178-182` assert it right after the
    click. A synchronous `form.submit()` throw still reaches `onError` (`p3-longform:323-330`), and the existing
    `finally` removes the form.
  - On `refused`/`failed` it shows exactly one `toast.error(message)`.
- **`fetchDeliveryAttachment`** (preview only) shows no toast and has no control. `signal` is the cancellation
  entry point; no Task 9 caller passes it.

### Request (fetch path)
- **Validate before credentials:** `isPostDelivery` (exact three paths, string fields), then
  `new URL(action, location.origin)` must have the same origin, the same pathname, and no search or hash.
  Failure gives `invalid`.
- **Request shape:** `fetch(action, { method: "POST", credentials: "include", redirect: "manual", headers, body, signal })`.
  - `headers` is a plain object: the D6 `Content-Type` plus `Authorization: Bearer <snapshot token>`.
  - `mode` stays the default `cors`, and there is no `keepalive`.
- **The token goes only in the header.** Never in the body, URL, hash, filename, Blob URL, toast, report or log.
- **One request per activation.** An explicit retry is a fresh activation with a fresh `attemptId` and snapshot.

### Response (fetch path)
- **Status rules, in order:**
  1. `opaqueredirect` or `redirected` → `failed/redirect`. Nothing is followed.
  2. Type other than `basic` → `invalid-response`.
  3. status ≥ 400 → `refused`.
  4. Any other non-200 → `invalid-response`.
  5. 200 → the attachment checks.
  Production requires `basic`; tests produce it (§2).
- **Abort on every non-handoff exit.** One `AbortController` per activation; a stop reason is recorded before every
  abort or cancel and checked after each await, before a `done` read counts as end of file. The server then sees the
  close (slot release `downloadExportsRoute.ts:103`, aborted audit `downloadRoute.ts:404`).
- **Refusal:** the status decides, never the type. The notes 500 arrives as JSON labelled
  `application/pdf; charset=utf-8`.
  - Read ≤65,536 B. If the type is `application/json`, the value is an object and its own `error` is a non-empty
    string, show that text.
  - Otherwise show "The download could not be completed. Please try again." (`deliveryRouter.ts:42`).
- **Attachment checks before reading:**
  - the media type is allowed for the action: form → DOCX or ZIP; export → ZIP; notes → PDF;
  - `Content-Disposition` matches `^attachment; filename="(.+)"$`, taken greedily, with no `\x00-\x1f`/`\x7f`, and
    an extension matching the type;
  - a declared `Content-Length` over the ceiling gives `too-large`, never read; malformed gives `invalid-response`.
- **Bounded read** (one shared reader; its limit is a parameter; actual bytes are counted):
  - over the limit gives `too-large`; a deadline gives `timeout`; a stream error gives `incomplete`;
  - with a declared length and no non-identity `Content-Encoding`, the received bytes must equal it, else
    `incomplete`.
- **Container markers** (a format check, not container validation):
  - **DOCX:** starts with `PK\x03\x04`.
  - **ZIP:** starts with `PK\x03\x04`, or is a complete 22-byte empty archive starting with `PK\x05\x06`.
  - **Both:** an end-of-central-directory `PK\x05\x06` must sit in the final 65,557 bytes.
  - **PDF:** starts with `%PDF-` and has `%%EOF` in its final 1,024 bytes.
  - **Failures:** zero bytes or a failed marker gives `invalid-response`.
  - **Limit, stated:** there is no inflation, CRC or object parsing. Interior corruption behind intact markers
    passes. Native downloads get no client check, as today.
- **Handoff:**
  1. The session check runs.
  2. `new Blob(chunks, { type })`, then `URL.createObjectURL`.
  3. A hidden `<a download>` is appended, clicked and removed.
  4. **Cleanup policy, not a guarantee:** the URL is revoked after 120,000 ms. A download prompt or a slow host
     that outlasts it fails, and the user retries.
- **Rotation:** the transport never writes the store, so it cannot bring back a token. The identity check, not the
  absence of a write, is what guards handoff.
- **Sentences (all existing; no new wording):**
  - timeout: "The server took too long to respond. Please try again." (`trpcTransport.ts:99`);
  - network: "Server is temporarily unavailable. Please try again in a moment." (`:100`);
  - everything else, including `session-changed`: the server fallback sentence.

### Control lifecycle (one shared `WeakSet`)
- Native: the unchanged 2-s window. Fetch: held for the actual request lifetime.
- Disable only an enabled control, and re-enable only what this call disabled.
- Focus returns only to a dropped, still-connected control. Focus the user moved is never taken back.
- No global lock: independent controls never block each other.

### Callers (9 `postDownload` sites + the preview fetch; existing guards stay in front)

| File:line | Trigger | Delivery | Edit |
|---|---|---|---|
| `EstateDetail.tsx:8161` | FormsTab single-form onSuccess (recovery state set first) | form | `void deliverAttachment(data.delivery).then((o) => { if (o.kind === "submitted" \|\| o.kind === "handed-off") toast.success(<existing text>); })` |
| `EstateDetail.tsx:8254` | package onSuccess | export `package` | same |
| `EstateDetail.tsx:8264` | all letters onSuccess | export `letters` | same |
| `EstateDetail.tsx:8274` | all P8 onSuccess | export `p8_all` | same |
| `EstateDetail.tsx:10140` | DeliveriesCard P46 onSuccess (test-only path; production P46 uses `:9661`) | form | same |
| `Home.tsx:241` | dashboard estate export onSuccess | export `estate` | same |
| `EstateDetail.tsx:9997` | `p8-download-retry` button | form P8 | `void deliverAttachment(p8DownloadReady.delivery, event.currentTarget)` |
| `EstateDetail.tsx:10011` | `document-generation-download-retry` button | form | same, with the control |
| `EstateDetail.tsx:11914` | Notes "Export PDF" button | notes | same, with the control |
| `EstateDetail.tsx:7409-7480` | FormPreviewModal `doDownloadDocx` | form (JSON, D6) | `fetchDeliveryAttachment(generated.delivery)`. `handed-off` shows the existing "DOCX downloaded". Anything else becomes `throw new Error(message ?? "Download failed")` into the existing catch (toast + rethrow to preflight). |

**Guards stay in front of every call:** the `isPostDelivery` throws at `EstateDetail.tsx:8123-8146, 8251-8253,
8261-8263, 8271-8273, 10139`, and the toast-and-return at `Home.tsx:237-240`. `invalid` resolves without throwing,
so `preflight:711-715`, `p3-longform:316-322` and `p8-download:260-269` depend on these guards.

## Connected-feature matrix

**Shared baseline for every delivery surface:**
- Token present → fetch: D6 encoding, Bearer + cookie, session snapshot. No token → native form, unchanged.
- Server path, unchanged: guard → cookie-first auth (401) → suspended (403) → exact id + owner (IDOR audit) →
  per-user rate unit (429).

| Surface | Body / cap | Binding / gates | Audit / report (server, unchanged) | Retry / control | Evidence |
|---|---|---|---|---|---|
| FormsTab single form, recovery, P8 retry, P46 path | urlencoded 8,349 (native and Bearer) | Task 6 binding 409; render digest 409 | Task 5 provenance; `document_delivery_started` gate 503; finished/aborted; `download_form` report | recovery buttons are the explicit retry | 7 submit-spy suites; new Bearer caller tests; native; browser |
| Preview Download | JSON 8,353 (pinned) | same | same | `downloadPending`; rethrow to `handlePgProceed` | preflight tests; new success test; browser |
| Package / letters / all-P8 | urlencoded 8,192 | builders and start-audit gate; package slot 503 | `export_delivery_*`; Task 15 export reports | user regenerates; no automatic regeneration | new Bearer caller tests; native; browser |
| Home estate export | urlencoded 8,192 | manifest-authorized reads; slot | same + Task 15 | none | new Home Bearer test; native; browser |
| Notes Export PDF | urlencoded 8,192 | none (Tasks 10/11) | Task 15 notes report; **no delivery audit** | lifetime lock | new Bearer caller test; native capture; browser |

**Shared state:**

| Surface | Token source | Behaviour |
|---|---|---|
| tRPC (`main.tsx`) | the shared reader (a pure move) | rotation `onResponse` unchanged |
| Logout / account deletion (`useAuth.ts:48`, `Settings.tsx:370`) | `clearFallbackSession()` | the same removal + a generation bump |
| Dev diagnostics (collector + Vite sink) | none | D5 header-map redaction |
| Retained files (`previewStoredFile`, `downloadFromUrl`) | none (navigation) | untouched |

## Files

- **Application:**
  - new `client/src/lib/fallbackSession.ts` and `client/src/lib/attachmentDelivery.ts`
  - `client/src/lib/utils.ts`: remove `postDownload`
  - `client/src/main.tsx`: `headers()` only
  - `client/src/_core/hooks/useAuth.ts:48`: one line
  - `client/src/pages/Settings.tsx:370`: one line
  - `client/src/pages/EstateDetail.tsx`: imports, 8 sites, `doDownloadDocx`
  - `client/src/pages/Home.tsx`: import + 1 site
  - `client/public/__manus__/debug-collector.js`: two header maps
  - `vite.config.ts`: sink header redaction; the plugin factory as a named export
  - contingency: new `vite.debug-collector.ts` (D5)
- **Tests:**
  - **new:** `client/src/lib/fallbackSession.test.ts`, `client/src/lib/attachmentDelivery.test.tsx`,
    `client/src/pages/EstateDetail.bearer-delivery.test.tsx`, `client/src/pages/Home.bearer-export.test.tsx`,
    `client/src/lib/debugCollector.redaction.test.ts`, `server/debugLogSink.redaction.test.ts`,
    `server/deliveryBearerAuth.test.ts`.
  - **edited, intentionally:**
    - `client/src/lib/postDownload.test.tsx`: the import, plus three boolean checks → outcome kinds
      (`:115`, `:203`, `:215-216`). Every other guarantee is kept.
    - `client/src/pages/EstateDetail.preflight.test.tsx`: its fetch stubs (`:309`, `:338`, `:472`, `:501`, `:572`)
      move to the `browserResponse` factory. Every assertion is kept.
  - **Expected unchanged:** the seven other submit-spy files. They set no token, so they take the synchronous
    native path.
- **QA-only, not in the application patch:**
  - `.work/hybrid-remediation/fixture/capture-deliveries.ts:11`: one string;
  - under `.work/hybrid-remediation/task09/claude-pass01/`:
    - `qa/`: harness copies with the ExtraInfo extension, `build-manifest.cjs`, the test-types tsconfig copy, and
      attribution extended to `client/` lines;
    - `native/`: `identity-cases.ts` plus its guarded runner.
- **EOL** (Node census):
  - CRLF: utils 101, main 88, useAuth 109, Settings 1,708, EstateDetail 12,155, Home 1,293, postDownload.test 224
    (untracked), EstateDetail.preflight.test 939, debug-collector 821, vite.config 187.
  - LF: capture-deliveries 54.
  - Each edited file keeps its class; new files are LF. The census is repeated after edits, and terminators are
    restored per line.
- **Untouched:**
  - all server code, including auth, CSRF, the guard, caps, binding, audits, slots, reporting, `notesExportRoute.ts`
    and the PDF drawing code;
  - `docgen.ts`, renderers, preview builders, `shared/types.ts`, `shared/const.ts`, schema and migrations;
  - `shared/postDelivery.ts`, `trpcTransport.ts`, `botClient.ts`, and `previewStoredFile`/`downloadFromUrl`;
  - dependencies.

## Preserved

- **Server delivery path:** cookie priority, tenancy, every public status and sentence, and the Origin and
  Sec-Fetch guard.
- **Task 6:** signed fields, digest, current-row and expiry semantics, `formDeliveryGeneratorRelease(GENERATOR_RELEASE)`,
  and the caps.
- **Task 4/5:** atomic replacement, actual-primary P8, required audit/activity/provenance, the best-effort timeline,
  and the "Generation could not be confirmed. Refresh the estate and try again." sentence. No automatic
  regeneration after uncertainty or a transport failure.
- **Task 15:** the reporting bounds, order and slots. Reports come from the server only; the client never retries,
  so it creates no duplicate rows.
- **Generation:** missing-data warn-and-proceed and Generate anyway. The four approved existing output behaviours.
  Rule 29. No generated-byte storage write.

## Recorded dependencies and limitations (not changed by Task 9)

- **Origin policy:** a Bearer context whose origin is not `probate-pro.com`, `www.probate-pro.com` or `APP_URL` gets
  403 at the guard (`deliveryRouter.ts:166-172`), on both transports. That is a deployment setting.
- **Retained files** (`/manus-storage/` navigation) still need a cookie.
- **"Handed-off" is not "saved".** The headless allow-downloads setting skips Chrome's prompt. The fetch-path click
  comes after awaits, without a user gesture, so real browsers may prompt after the first automatic download. A
  sandboxed host iframe needs `allow-downloads`. A cleared Chromium cookie only simulates Safari ITP or a WebView.
- **Cross-tab cookie change:** see Session identity.
- **CSRF guard:** its `{ "error": "forbidden_origin" }` would show verbatim, as the preview does today. Only a
  cross-origin, cookie-bearing request reaches it, and the same-origin fetch never is one.
- **Existing defects, left alone:**
  - the notes non-Latin-1 `Content-Disposition` 500 (shown as the generic refusal);
  - "DOCX downloaded" for preview ZIPs;
  - the chatbot's own token reader and rotation adoption;
  - its Bearer-first rate-limit read (`server/chatbot.ts:32-42`);
  - the silent 500-note cap on notes.

## Plan reviews

- **r1 adversarial Plan agent** (opus, read-only, against the code): no BLOCKING findings. Its HIGH and MEDIUM
  findings are folded in:
  - the refusal recipe;
  - the Cookie header seen only in ExtraInfo;
  - stop-reason reads;
  - jsdom/vitest facts and memory-safe ceiling tests;
  - notes and CDP evidence.
- **Nick's r1 review:** points 1–7 and the smaller fixes, answered by the r2 record above. The core design is kept as
  Nick asked.

## Capability routing (`/find-skill`; `/orchestrate-swarms` is not installed in this session)

- **Routing rows:** Security audit → security-reviewer; Testing → tdd-guide/test-runner. Triggers: high stakes,
  producer + validator, more than 3 files.
- **Skills:** `superpowers:writing-plans`, `superpowers:test-driven-development`,
  `superpowers:verification-before-completion`, and `probate-integrity-gate` (read-only).
- **Agents:**
  - done: 3 × Explore and 1 × Plan;
  - implementation inline (single domain);
  - review in parallel on `model: opus`: `backend-design:security-reviewer`, `pr-review-toolkit:silent-failure-hunter`,
    and a general-purpose reviewer applying `probate-integrity-gate`.

## Verification (after approval)

**0. Evidence** in `.work/hybrid-remediation/task09/claude-pass01/` (new; nothing old overwritten):
- Copy this plan to `docs/superpowers/plans/2026-10-23-task09-cookie-independent-delivery.md`.
- `preflight.md`: identity, governance, the matrix, and the approval reference.
- `before/` copies, `before-hashes.sha256` and `before-eol.jsonl` of every declared file, QA-only files included.
- **Concurrency:** identity and the `before/` hashes are re-verified right before the first edit, before the final
  gates and after the browser session. An unexpected change is a STOP.
- **Final build/source manifest** (`qa/build-manifest.cjs`), written after the final `build` and fixture restart. It
  holds SHA-256 of:
  - every file under `dist/public/**` (`index.html`, the 7 assets, `__manus__/debug-collector.js`, the rest);
  - the declared client sources and their delivery/auth dependencies: `shared/postDelivery.ts`, `shared/const.ts`,
    `deliveryRouter.ts`, `originPolicy.ts`, `sdk.ts`, `context.ts`, and the three route files;
  - the fixture QA files.
- `task-files.txt` and the task-only diff, reconciled against the before/after copies of exactly the declared paths;
  final hashes and the EOL census.

**1. Red first** (logs kept; a red must fail on a behaviour assertion):
- **Callers:** the new Bearer caller tests run against today's UI with a fictional token and no cookie. They see a
  header-less form submit, and no `Authorization` fetch.
- **Preview:** the request carries no `Authorization` (the `manus_session=` bug).
- **Transport:** a red unit test against today's `postDownload` fails the same way.
- **Diagnostics:** the collector boundary test finds both sentinels in the reported payload, and the sink test finds
  them in the appended text.
- **Browser:** today's build, with a pre-change `build` under a fresh label and a fixture restart. Bearer-only gives
  a 401 and the "Download not available" page, plus the preview toast. Headers are read from
  `requestWillBeSentExtraInfo`, after the cookie positive control (§6).

**2. Unit tests** (one behaviour each; harness facts: `Blob`, `AbortController` and `Headers` come from jsdom, while
`Response`, `ReadableStream` and `fetch` come from Node):
- **Factory:** `browserResponse(bytes | string, init, type = "basic")` returns a real `Response` with a real
  `ReadableStream` body, and `type` defined as `basic` or `opaqueredirect`. Bodies are `Uint8Array` or strings,
  never a jsdom `Blob`.
  - Stubs honour `init.signal`. The illegal-header stub calls `new Headers(init.headers)`.
  - `URL.createObjectURL`/`revokeObjectURL` are defined directly on `URL` and restored. Do not `stubGlobal("URL")`.
  - `HTMLAnchorElement.prototype.click` is stubbed (`utils.test.ts:26-28`).
  - Deadline and revoke tests use fake timers (`advanceTimersByTimeAsync`) in the unit file only; the deadlines use
    `setTimeout`, never `performance.now()`. The caller suites use real timers.
- **Token and session:**
  - the exact pair, first match, whitespace, an empty value, lookalikes (`xapp_session_id=`, `app_session_id_old=`)
    and storage throws;
  - `clearFallbackSession()` removes the key and bumps the generation, even when storage throws;
  - the snapshot cases, each with no Blob or anchor, a `session-changed` toast and a request aborted after headers:
    - **A→B non-empty replacement** before the headers and between headers and handoff;
    - **clearing**;
    - **cookie-only preview logout** (`clearFallbackSession()` with no token);
    - **same-user rotation**, then an explicit retry that reads the new token and gets a fresh `attemptId`;
  - a stray `X-Rotated-Session` never writes the store.
- **Credentials and encoding (D6):**
  - no token gives the native form, every `postDownload.test.tsx` guarantee, and zero fetches;
  - a token gives exactly one fetch with the exact init. The body equals
    `new URLSearchParams(Object.entries({ ...fields, attemptId })).toString()`, with
    `Content-Type: application/x-www-form-urlencoded` and the token only in `Authorization`;
  - **boundary:** a Task 6-shaped all-17-field descriptor at the form threshold, with the 148-byte binding, 2,000-byte
    override values and a 36-character `attemptId`, gives exactly an 8,349-byte Bearer body. The same fields in JSON
    exceed 8,353, which documents why D6 exists;
  - the preview keeps its exact JSON init. A preview 413 is a refusal with no re-POST.
- **Descriptor validation:** GET, query, hash, alternate-path and foreign actions; non-string fields; `undefined`.
  Each gives `invalid`: no fetch, no storage read (spied), the control untouched.
- **Responses:**
  - **Genuine fixtures:** a JSZip archive and DOCX (installed dependency), a valid minimal PDF ending `%%EOF`, and a
    complete 22-byte empty ZIP. Each gives a handoff with identical bytes and type, the server's filename, the
    anchor removed, and a revoke exactly at 120,000 ms.
  - **Truncation controls**, with no `Content-Length`: a ZIP and DOCX cut before their EOCD, a PDF cut before
    `%%EOF`, and the 4-byte `PK\x05\x06`. Each gives `invalid-response`.
  - **Bad responses:** HTML 200, JSON 200, a missing or `inline` disposition, an empty name, a control character,
    an extension or magic mismatch, zero bytes, and 204/206/304. Each gives `invalid-response`, with the request
    aborted.
  - **Pass-through:** the notes name with quotes and Latin-1 letters is passed unchanged.
  - **Length:** no `Content-Length`; a declared length over the ceiling is aborted and never read; a malformed
    length; a short body; gzip with a length mismatch, accepted within the ceiling.
  - **Ceiling:** exact and +1 at the 65,536 refusal limit; the 64/512 MiB classes by declared length only; the
    constants by value; one 64 MiB + 1 single-chunk cancel.
  - **Redirect:** gives `failed/redirect`, with one fetch call.
- **Timing:** headers, idle and trickle deadlines; a caller abort before the headers and mid-read; a deadline or
  abort while a `read()` is pending with no length gives `timeout`/`cancelled` and no Blob; the timers end back at
  the revoke timer only.
- **Refusals:**
  - 400/401/403/404/409/413/429/500/503 keep their real status and sentence (including the limiter 429 and a 51 KB
    closed-parameter sentence);
  - HTML 502/503, non-JSON, an empty `error` and an over-64 KiB body give the generic sentence;
  - the notes 500 labelled `application/pdf` is refused, never handed off;
  - no error ever produces a file or a success toast, and there is never a second POST.
- **Control:** held for the lifetime; a double-click gives `suppressed`; independent controls both run; a
  pre-disabled control stays disabled; focus rules; unmount.
- **Privacy:**
  - console spies;
  - the token appears in no URL, body, toast, anchor or console argument;
  - **collector boundary** (jsdom, the real `debug-collector.js`): a fetch with `Authorization: Bearer
    FICTIONAL-SENTINEL-…` whose response carries `X-Rotated-Session: app_session_id=FICTIONAL-SENTINEL-…`. After the
    2-s report, the `/__manus__/logs` payload holds neither sentinel, shows `[REDACTED]` for both, and keeps
    `content-type`;
  - **persistence boundary** (node, `node:fs` mocked, no disk write): the real plugin middleware receives the same
    sentinels in header maps, and the exact `appendFileSync` text holds none while keeping the non-sensitive headers.
- **Callers** (the new Bearer suites, real timers):
  - each site sends one fetch with the token;
  - a handoff gives the existing toast; a refusal gives only the error toast;
  - the retries make a fresh activation;
  - the preview's success shows "DOCX downloaded", and its refusal rethrows to preflight.
- **Mutants:** each must turn a test red, then be restored, with receipts:
  - the token check inverted;
  - the identity snapshot ignored;
  - the ceiling dropped;
  - redirects followed;
  - an immediate revoke;
  - the MIME check skipped;
  - the tail marker skipped;
  - JSON on the Bearer path;
  - collector headers unsanitized;
  - sink redaction removed;
  - a pre-disabled control re-enabled.

**3. Server tests** (test-only; server code unchanged):
- **`server/deliveryBearerAuth.test.ts`:**
  - It uses the real `sdk.authenticateRequest` with fictional `createSessionToken` tokens, a mocked `db`, and the
    real `installDeliveryRoutes`. It follows the `sdk.session-revocation.test.ts` pattern.
  - For each route:
    - Bearer-only reaches the authenticated path (404 for an unknown estate);
    - cookie A + Bearer B authenticates A;
    - an invalid cookie + Bearer B gives 401;
    - expired, malformed and absent tokens give 401;
    - a suspended user gives 403;
    - a deleted user gives 401;
    - a `sessionVersion` mismatch gives 401.
  - `Content-Type: application/x-www-form-urlencoded` with and without `;charset=UTF-8` passes the guard.
- **Thresholds:** the existing Task 6 threshold test stays the server proof of 8,349/8,350 (form) and 8,353/8,354
  (JSON).

**4. Gates:** read `run-gates.cjs` first; use fresh labels (`claude-task9-*` are free).
- Red: `claude-task9-red1 focus --test-file=…`. Focus: `claude-task9-focus1 …`.
- Full: `& 'C:\Program Files\nodejs\node.exe' '.work\hybrid-remediation\run-gates.cjs' claude-task9-pass1 check tests chatbot-check chatbot-tests build render`.
  6,513/205 is the historical baseline.
- The test-types diagnostic runs against a pre-edit baseline, with attribution extended to `client/`.

**5. Native fixture** (identity-guarded; owned fictional data only):
- **Start:**
  - MySQL: `node .work/hybrid-remediation/fixture/mysql-fixture.cjs --resume-owned-fixture` (background, port
    43316; checks `@@datadir`/`@@port`).
  - App: `node .work/hybrid-remediation/fixture/start-ui-task15.cjs` → `http://127.0.0.1:43117`. The DSN is rebuilt
    from the private runtime file only; `AWS_*`/`STORAGE_S3_*` are refused.
  - Restart the fixture after every `build`: it hashes `dist/public/index.html` once at startup.
  - `VITEST=true` there makes the per-user 429 unreachable, so the 429 stays a unit-test case.
- **Notes capture correction (QA-only):**
  - In `capture-deliveries.ts:11`, `'/api/notes/export'` becomes `'/api/notes/export-pdf'`. Before/after hashes are
    recorded, then the fixture is restarted.
  - One arm per case, with a fresh label. It is consumed by rename, and `capture-next.json` must be absent after
    each case.
- **Identity driver (`native/identity-cases.ts` + guarded runner):**
  - **Guards:** before any mutation, `@@datadir`, `@@port` 43316 and `database()` are checked.
  - **Tokens:** minted in-process with the fixture secret, never printed or written: valid A, valid B
    (`hybrid-local-qa-other`), expired (a short expiry, then waited past), malformed and absent.
  - **Disposable users** with fixed ids `task09-qa-suspended` (`suspendedAt` set), `task09-qa-deleted` (its row
    deleted after minting) and `task09-qa-revoked` (`sessionVersion` 0→1). All are removed in `finally`.
  - **Restoration receipt:** the users-table digest, excluding the disposable ids, before and after, plus the
    disposable ids' absence.
  - **Cases × the three routes,** with `Origin: http://127.0.0.1:43117` and `Sec-Fetch-Site: same-origin`.
    Authentication is shown by an unknown estate's 404 when authenticated vs 401 when not, on the form and export
    routes; tenancy by notes on A's estate:
    - Bearer-only (404 / notes 200 for A);
    - cookie A + Bearer B (notes on A's estate 200; with Bearer B alone, 403);
    - an invalid cookie + Bearer B (401, never B);
    - expired, malformed and absent (401);
    - suspended (403);
    - deleted and revoked (401);
    - Origin missing or foreign, and cross-site `Sec-Fetch-Site` (403, before authentication).
  - **Receipt:** statuses and sentences only, with a JWT-shape scan that must find 0.
- **Also over HTTP:**
  - healthy form and export bytes match the `*_delivery_started` `contentSha256`, with started and finished once per
    success;
  - notes: the capture hash only; audit not applicable;
  - ordinary refusals add 0 `failure_reports` rows;
  - no new generated storage references;
  - slot release;
  - non-admin FORBIDDEN on staff reports.
- **Cleanup:** only Task 9's disposable rows, by id; generated history is restored with
  `task04/ui-history-fixture.cjs`.

**6. Real browser** (own headless cached Chromium; the proven Task 6/14 precedent):
- **Harness:** copies of `task06/claude-pass01/qa/browser-launch.cjs` and `cdp.cjs`. The browser uses a fresh
  profile, a dead proxy for anything not on loopback, and `--no-sandbox`, recorded as required here.
  - **Header proof:** `Network.requestWillBeSentExtraInfo` is matched by `requestId`. Only names are recorded:
    whether `app_session_id` is present, whether `Authorization` is present, its scheme and its length.
  - **Body proof:** request body SHA-256 (`getRequestPostData`), plus a hashed base64 response body, with the buffers
    raised above the largest fixture output. A network hash is required only for fetch responses.
  - **Native downloads:** file hash = capture hash = audit hash.
  - **Manifest:** every loaded `/assets/*` response hash must match the final manifest.
  - **Fallback:** Playwright MCP. If no browser can reach 127.0.0.1, that is diagnosed and recorded as an evidence
    gap; nothing is installed.
- **Positive control first:** the default `/__fixture/login` cookie session must show the cookie present, with no
  `Authorization`, on its native deliveries (single form, one export, notes). Files match their captures and audits.
- **Bearer-only** (`/__fixture/login?mode=bearer`, the real SDK-backed login): single form auto-download, P8 retry,
  package, letters, notes, Home export and the preview Download. For each:
  - Authorization is present and the session cookie absent;
  - tRPC still carries Authorization;
  - the file is handed off, with no navigation;
  - file hash = audit and capture (form/export) = network body;
  - notes: file hash = capture = network.
- **Stale (i), UI only (Task 6 B11(d) precedent):**
  1. FormsTab Generate P2 → handed off, and the recovery alert holds descriptor D1.
  2. Preview P2 → Download DOCX. The preview's own generate replaces the P2 row, and the download is handed off.
  3. Press FormsTab "Download P2" (the `EstateDetail.tsx:10011` control). It gives 409 "This download link is out
     of date. Generate the document again.": an error toast, no file, no success toast, no navigation.
  4. Recovery: Generate P2 → handed off.
- **Stale (ii), digest on a rendered field (Task 6 B3 precedent):**
  1. Generate the LETTER for the fictional "Bob Smith" → handed off.
  2. Contacts → Edit Bob Smith → postal address "456 Oak Ave, Vancouver, BC V6B 2B2" → "457 Oak Ave, Vancouver,
     BC V6B 2B2" → Save.
  3. Re-deliver the prepared descriptor:
     - by the `Download LETTER` recovery control, if the alert survives the edit (observed first);
     - otherwise by an in-page Bearer re-post from the harness, with values never read out. That is server digest
       proof; (i) covers the transport's refusal UI.
  4. Expect 409.
  5. **Mandatory restoration:** set exactly "456 Oak Ave, Vancouver, BC V6B 2B2", reopen it to verify, and
     re-deliver. Expect 200, with `word/document.xml` identical to the original delivery.
- **Network retry:** one recovery click under `Network.emulateNetworkConditions({ offline: true })` gives the
  network sentence. Back online, the same button gives a fresh `attemptId` and a handoff.
- **Warn-and-proceed:** a form with missing data shows the warning, and Generate anyway delivers over Bearer.
- **Bracketing:** each case gets `ui-case`-style state deltas. The cookie banner is handled as recorded.
  Supported-browser download observations and their limits are recorded honestly.

**7. Freeze and output:**
- The `render` gate's 26 fixtures and the protected hashes.
- **Before/after legal content:** the same fictional inputs, before over the native path and after over the Bearer
  path. Every DOCX part, including DOCX inside ZIPs, is compared byte for byte except the `docProps/core.xml`
  created/modified text (`task06/.../compare-cohorts.cjs`).
- **Not normalized:** the timestamped estate-export `exportedAt` and README `Prepared:` lines, and the package
  `Generated:` date if the day changes. They are listed as expected-different, with per-response byte proof instead.
- **Notes PDF:** the frozen source (`notesExportRoute.ts` hash unchanged) plus per-response byte equality (file =
  capture = network). Cross-run raw equality is not claimed, because of the date and PDFKit creation metadata.
- Word/pixels: **user-deferred-not-passed**.

**8. Independent review** (read-only, opus, in parallel):
- `backend-design:security-reviewer`: credential destinations, identity snapshot, the diagnostics boundary,
  CSRF/Origin.
- `pr-review-toolkit:silent-failure-hunter`: streams, stop reasons, timers, cleanup.
- A probate-integrity reviewer: Rule 29, caller compatibility, warn-and-proceed, Task 4/5/6/15 invariants.

Confirmed in-scope findings are fixed and the affected tests rerun. The final full gates and the manifest refer to
the final hashes.

**9. Handoff and STOP:**
- branch, HEAD and index;
- the root cause; the transport, identity, encoding, ceiling and diagnostics policies;
- the declared delta and preserved prior work;
- commands and counts;
- the cookie/Bearer/CSRF/privacy proof; UI, native and frozen-byte evidence; gaps;
- review findings by severity;
- implementation-verified kept apart from Nick's acceptance; no SHIP claim; Task 15's browser gap still open.

Nothing is staged or committed, and no next task starts.
