# Task 11 handoff preferences and retained rules — 2026-10-25

This is a repository handoff/preferences record, not an implementation plan or approval of numerical limits. It supplements the authoritative RULES.md and queue; it does not change legal rules or existing acceptance evidence.

## Preferences for every model working on this selected task

1. **Task 11 only**, plan first, explicit Nick approval before application edits. No Tasks 7/8 reopening, Task 12/17 work, hybrid Step 4 or automated next-task progression. Save the actual proposed plan separately and stop for approval.
2. Work only in `C:\Users\nick\probate pro\probatepro-hybrid-review`, branch `security/hybrid-vault-review`, HEAD `db0d7e9161bc3899b75858fab58bce54e3d5247a`; verify at execution. Preserve dirty predecessor work and EOL classes. No stage/commit/reset/stash/push/merge/branch/worktree/checkpoint/publish/deploy.
3. **Court and notes PDF wording/format/rendering/legal/form-selection freeze** under Rule 29. No document schema, migration, official capture, `shared/types.ts`, `server/docgen.ts` or drawing/text changes. Preserve affirmed default, lawyer-signing model, capitalized defined terms, spaced citations and no fabricated sworn facts. Identify exact non-text buffer-control changes inside a renderer and seek separate approval before editing them; no layout workaround.
4. Preserve the four existing approved output behaviors and all AWAITING-NICK deferrals. Do not invent “three Rule 29 exceptions.” Unused-field hiding is only for separately authorized form editing; none is authorized here.
5. Incomplete estate information remains warning-only; Generate anyway/draft/blank behavior stays available. Safety admission, audit, authentication and authorization are distinct integrity boundaries.
6. Absolute production/AWS/data isolation. No production database/storage/records/accounts, AWS/S3/STS/KMS/vault credentials, live policy inspection, secret searching/display or external-service writes. No new AWS_* / STORAGE_S3_* / LEGAL_RECORD_STORAGE_APPROVED configuration. Task 19 remains separate.
7. No dependency/toolchain/lockfile upgrades or tool installation. No Office retry, settings change, unrecognized process stop, peer fixture takeover or uncertain browser-click replay. Prove fictional fixture ownership, source/build identity and no busy peer before mutations.
8. Keep the preferences/rules list and new explicit approvals in repository plan/evidence for future models. Never overwrite RULES.md, old receipts or historical dispositions just to make status look green.
9. Task 10 is **accepted/done by Nick's 2026-10-25 08:10 PDT decision**, per appended queue disposition and final-status §17. Preserve D1–D4, controlled 503, strict-true start ACK, one-terminal scheduling, safe privacy fields, owned listener cleanup and Task 15 at-most-one eligible staff-report attempt.
10. Task 13 is done within approved scope by Nick's decision. Preserve estate-owned Notes feedback, cookie-native/Bearer paths, rotation/refusal hardening and the display-only VSA532 Lawyer rule; no client edits by default.
11. Task 11 must explicitly address actual pending work and caller waits, per-user/process-wide fairness, bounded queues/map state and PDF/input memory. Promise.race is not SQL/CPU cancellation. Do not recycle live-job permits early or erase append-only audit history. Creation-rate limits are not finite lifetime retention or cluster-wide enforcement.
12. Numeric resource limits, altered admission/denial precedence, audit deadline/late-outcome policy, new public refusal wording or necessary non-text renderer plumbing need explicit plan decisions/approval. No shared-pool/global-audit refactor, filename/response fix or partial-note export implied.
13. Distinguish historical evidence, fresh gates, real-engine faults, injected faults and user closure. Report all gaps; no skipped failing regression, new legal snapshots or broad PDF metadata normalization. Real UI and native evidence are needed beyond unit tests. No overall SHIP claim or acceptance without Nick.
14. Preserve existing independent budgets: notes must not consume the form-generation counter or the staff-report counter. Saturation must not interfere with other accounts, forms/Generate anyway, letters/packages, notes CRUD, uploads or ordinary navigation.
15. Keep F1/O1 filename/Content-Type issues (separate approval), stale storage docs (Task 17), runtime-message/body-redaction issues, P10 carry-over, preview/panel behavior, Task 15 browser gap, test incident, Safari/iOS/Android and Word/pixel deferrals open. No silent AWAITING-NICK resolution.

## Current source facts to retain in the actual plan

`db.listEstateNotes` already selects the user's estate notes in createdAt DESC order with LIMIT 500. Preserve this selected set; do not claim it exports unlimited/all retained notes or change ordering/truncate it silently. The PDF currently buffers chunks and concatenates; required start can hold that buffer across a pending audit. Terminal audits are detached. The shared edge limiter is 200/minute/IP and is not a pending-work limit. Notes has no current per-account export bucket. Recorded shared-pool queue facts and Task 10 L1 must be rechecked, not assumed cancelled by timers.

## Authoritative pointers

- `RULES.md` Rule 29; `.cursorrules`; applicable AGENTS.md/CLAUDE.md.
- `docs/superpowers/plans/2026-10-21-hybrid-remediation-queue.md`, appended Task 10 acceptance.
- `docs/superpowers/plans/2026-10-24-task10-notes-delivery-audit.md` and `.work/hybrid-remediation/task10/claude-pass01/final-status.md` §§5/12/15/17.
- `.work/hybrid-remediation/task10/claude-pass01/pass2-source-before.sha256` and `reference-before-hashes.sha256`.
- `outputs/claude-remaining-tasks/09-task-11-notes-resource-bounds.md` — current complete Claude handoff prompt.

Only this preferences record and the selected prompt are authored by this update; application code, original task plans, queue, rules and Git index are unchanged. No Task 11 implementation has begun.
