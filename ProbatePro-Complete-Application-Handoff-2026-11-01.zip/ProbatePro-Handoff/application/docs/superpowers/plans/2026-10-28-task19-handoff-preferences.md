# Task 19 handoff preferences — 2026-10-28

## Status and authority

Nick requested the next task prompt and then explicitly confirmed Task 18's acceptance. The queue selects Task 19: infrastructure-policy evidence. This preference list and the updated prompt prepare that task; they do not execute it, grant AWS access, accept Task 19, change the queue or authorize Task 20. Task 17 was accepted at 07:41 on 2026-10-28. Task 18 was accepted at 13:16 PDT the same day within its verification-only scope, recorded in the queue, plan section 15 and final-status section 7. Every limitation, not-exercised item and report-only observation stands; this is not policy clearance, a SHIP verdict or a deployment/security/compliance approval. Task 19 remains blocked, Task 20 has not started and no fixture cleanup was approved. Recheck later explicit decisions without overwriting historical reports or manifests.

## Preferences for every model handling this handoff

1. Keep preferences and format/isolation/approval rules in the repository for continuity. A new decision record is not permission to stage or commit it.
2. Use only `C:\Users\nick\probate pro\probatepro-hybrid-review`, branch `security/hybrid-vault-review`, HEAD `db0d7e9161bc3899b75858fab58bce54e3d5247a`; preserve the dirty tree, index and concurrent work. No Git writes, checkpoints, publish/deploy, transfer or production-worktree operation.
3. Task 19 is offline evidence work only. Gate A inventories approved redacted inputs and the missing-evidence checklist. With no approved artifacts, return BLOCKED/AWAITING-NICK and stop. Gate B requires separate approval and remains offline. No automatic next task or broad tracer/panel cycle.
4. No AWS/STS/S3/KMS/RDS/vault authentication, connector/CLI/API calls, live policy/log/object inspection, policy simulation, database connection or infrastructure test traffic. Existing credentials/login availability grant no permission. A later live task requires an exact separate authorization.
5. Never request/read/copy secrets, ExternalIds, signed URLs, DSNs, `.env*`, credential stores or private QA runtime files. Inspect only approved sanitized inputs. Preserve originals in place; use aliases and sanitized findings in repository outputs, not raw private policies/account IDs/contracts.
6. Freeze all court-document wording, formatting, rendering, legal/selection logic, official captures, schema and `RULES.md`. Preserve recorded approvals and exceptions without inventing new ones. Missing data remains warn-only under approved single-form behaviour; do not change package/bulk rules or integrity checks.
7. No application, test, config, dependency, schema or existing documentation edits. No migrations/seeds, installs, service/fixture/browser/Office startup, builds or rerun gates for an offline checklist.
8. Use current source only as the expected contract. Proposals, mocks, local MySQL/UI, passing tests and desired policy snippets are not deployed proof. Track artifact capture time, environment/resource correspondence, active versions, completeness, redactions and effective-control gaps.
9. Keep bootstrap, runtime and purge identities distinct; preserve the sole `providerDeleteExact` purge consumer and legitimate exact-version enumeration. The expected Canadian vault profile is `ca-west-1` with the full matching key ARN; do not assume deployed settings from source checks.
10. Treat staging and production evidence separately. No live client data in staging. The active application stack is MySQL; old PostgreSQL blueprints are proposals, not migration instructions. Local 64 KB pages do not prove RDS compatibility. No schema import or database connection is part of Task 19.
11. Preserve all Task 18 report-only observations and corrected evidence limits, including REG-61's unverified cause. Do not reopen Tasks 7/8, close Tasks 6/14, or waive application gaps through a policy review.
12. Word/pixels stay user-deferred-not-passed. Canadian storage does not establish Canadian-only processing, deployment safety or compliance. No SHIP assertion.
13. Save only declared new sanitized Task 19 working/report/decision files. Verify deliverables and pre/post source/context/Git preservation. Report missing evidence truthfully. Nick decides acceptance; draft queue wording only and stop.

## Handoff files

- Prompt: `outputs/claude-remaining-tasks/13-task-19-infrastructure-policy-evidence-blocked.md`.
- Current predecessor report: `outputs/task18-security-safeguard-reverification-2026-10-28.md`.
- Predecessor details: `.work/hybrid-remediation/task18/claude-pass01/final-status.md` and `proof-matrix-completion.md` including appended corrections.

This prompt update changes no application or task-acceptance state. Its prompt-only verification receipt is saved under `.work/task19-prompt-update-2026-10-28/`.
