# Client Intake Contact Relationship Repair Plan

**Goal:** Ensure that a client-reported relationship arrives in the lawyer’s per-field review and can be applied to the matching estate contact.

**Root cause:** The server mapper already writes a selected relationship to `contacts.relationship`. The portal’s Family & other persons category control, however, was presented as a relationship choice while leaving the separate `relationship` input blank. As a result, the lawyer never received a relationship fact to select or apply unless the client independently filled an ambiguously labelled free-text field.

**Repair:** Keep the distinct relationship field, label it clearly, and when a family category has an exact supported contact relationship (`spouse`, `child`, `parent`, or `sibling`), place that client-reported value in the separate relationship field. If the client types a more precise relationship, preserve it; changing an auto-populated category adjusts only that auto-populated value. The category still does not assign a legal role.

## Constraints preserved

- Contacts are created or changed only through lawyer-selected facts or Apply all ready facts.
- No relationship is inferred from a person’s name or from an executor role.
- The existing client → estate mapping remains responsible for writing selected values.
- Existing address, email, occupation, inventory, document, court-form, and role behavior is unchanged.

## Regression coverage

- Three independently selected relationships (client, executor, family member) each produce the correct contact patch.
- Selecting a family category pre-fills the dedicated relationship field and submits it as a separately reviewable fact.
- A client-entered relationship is not replaced by a later category change.

## Validation

- `pnpm exec vitest run server/clientIntakeMapping.test.ts client/src/components/ClientIntakeForm.test.tsx --maxWorkers=1` — **27 passing**
- `pnpm check` — **passing**
- `pnpm test -- --maxWorkers=1` — **4,558 passing / 3 skipped**
- `pnpm build` — **passing**
- `git diff --check` — **passing**
- Local and preview root health checks — **HTTP 200**
