# Task 12 — Preview lifecycle / response limits — plan r5 (Gate A proposal; approved 2026-10-27)

**Status:** plan r5, Gate A proposal after Nick's two 2026-10-27 revision rounds (r1: 2026-10-25; r2: decisions; r3:
three design reviews; r4: first revision round), 2026-10-27.
- Nothing is implemented, and no application edit is authorized. **Gate B is not approved** (Nick, 2026-10-26: "Do not
  start Gate B yet").
- Every P-item in §"Decisions requested" was answered by Nick on 2026-10-26: each row carries its **Decided** text and
  §11 holds his words verbatim. P5 and P8 were decided against the r1 recommendation; the design below follows the
  decisions. The two rerun design reviews (minimal-change, verification) completed on 2026-10-26 (22 minutes, 79 read-only
  tool calls); every accepted finding is folded in below and §12 records each finding's disposition. Nick confirmed
  P1 (factory) and P1a (mechanical handler move) on 2026-10-27 against the reviewer dissent and asked for seven
  revisions, folded in as r4; his second, bounded set of corrections is folded in as r5. §13 records both messages
  verbatim with the mapping. P8 is deliberately **not** marked resolved (Nick).
- Exiting plan mode authorizes **only** saving this text as
  `docs/superpowers/plans/2026-10-25-task12-preview-lifecycle-limits.md` (new, untracked, LF), reporting its SHA-256,
  and **stopping**. It does not start Gate B, and it does not touch the already-present
  `docs/superpowers/plans/2026-10-25-task12-handoff-preferences.md` (5,429 B, matches Nick's attached text).

Queue item 12 only (not hybrid Step 4). Not in scope:
- Tasks 7/8 (not reopened), 14/6 (unchecked, not repaired), 17 and later, the final review, any other prompt;
- commit/stage/push/publish/deploy, production or AWS, vault writes, `.env` reads;
- marking Task 12 done, SHIP, or accepting another task;
- fixing the separately recorded rotation/`message`-listener gap or the Task 13 preview-path microtask gap (raised as a
  decision, never applied silently).

## Approval gates

1. **Gate A — this plan.** Plan mode allows writing only the session plan file. Exiting plan mode authorizes only the
   save described in the status block. Nothing is run, no fixture is started, no gate label is consumed.
2. **Gate B — implementation.** Steps B0–B8 (§9) start only after Nick's separate, explicit go-ahead. The P-item
   answers exist (2026-10-26) but do not grant Gate B: Nick's instruction with them was "Do not start Gate B yet".
   Choosing numbers, saving this plan or requesting the prompt does not grant Gate B.

## Capability routing (find-skill, recorded)

| Phase | Capability |
|---|---|
| Gate A investigation (done) | Workflow of eight read-only Explore agents (governance, identity/tooling, modal, transport/auth, server payload, library semantics, tests/gates, vault/routing) plus one completeness critic; then three read-only Plan agents as an adversarial design panel (minimal-change, correctness, verification lenses). The correctness lens completed (sound-with-changes: 7 defects, 8 improvements, 11 test gaps, all folded in below); the minimal-change and verification lenses stalled 1–3 minutes after launch, each with a Bash call waiting on a permission prompt, and never returned; Nick chose a rerun on 2026-10-26. The first rerun was stopped after 5 minutes when a 22-call read batch looked stalled, which turned out to be this environment's 10–15 s per-call overhead; rerun 2 (`wf_633ce9e4-d65`: Bash banned, at most three calls per message, exact library paths) completed in 22 minutes; both verdicts `sound-with-changes` (minimal-change: 8 defects, 8 improvements, 7 test gaps; verification: 10 defects, 9 improvements, 11 test gaps), dispositions in §12. Own reads of every surface file and the installed tRPC/React Query sources. |
| Gate B implement | Main session only, plan-driven (`superpowers:test-driven-development`, `superpowers:verification-before-completion`); no subagent edits. |
| Gate B verify | Task-owned QA copies under `.work/hybrid-remediation/task12/claude-pass01/` (Task 10/11/13 pattern); gates only via `run-gates.cjs` in the background with an unused label. |
| Gate B review | Read-only reviewers on Opus (code review, security, silent-failure, probate-integrity lens on the Task-12-only delta, pointed at this worktree, no SHIP verdict). Specialist agent files pin a retired model id; pass `model` explicitly or use general-purpose agents. |

Routing rows that applied: "Frontend build", "Testing → tdd-guide → test-runner (runner replaced by run-gates.cjs)",
"Code review (+security-reviewer)", "TypeScript". Six of the seven orchestration triggers fired (multi-domain,
research + synthesis, plan + code + QA, producer + validator, high stakes, ambiguous numeric scope). `code-review-graph`
was consulted: it is built at HEAD but indexes only 73 files and does not contain `trpcTransport.ts`,
`attachmentDelivery.ts`, `main.tsx` or `shared/types.ts`; every caller trace below was confirmed with Grep.

## Context

Queue item 12 (`docs/superpowers/plans/2026-10-21-hybrid-remediation-queue.md:60`): "Cancel superseded/closed/unmounted
requests and bound response bytes; revoke object URLs. Preserve rendered preview wording/markup/layout." Task 13 handed
the preview over explicitly: "Task 12 owns the preview's abort, close and body lifecycle" (queue :521). Task 11 is
accepted (queue :59, 2026-10-25 18:08 PDT); the Task 12 prompt :17 and preferences #13 still say "Task 11 is unchecked",
which is stale against the queue and is recorded here as such, not as a prerequisite gap.

**What is wrong today (all VERIFIED in the current tree and the installed libraries):**
- The preview query (`client/src/pages/EstateDetail.tsx:7419-7426`) runs with `{ enabled: open }` only. tRPC passes
  `signal: null` to the operation because `abortOnUnmount` is off everywhere, so React Query never sees its signal read
  and, when the observer leaves, calls `cancelRetry()` instead of `cancel({ revert: true })`. **Close, supersession,
  unmount and P17 keystrokes never abort the request or its body.** The late result is written into the old key's cache,
  and a late failure still reaches the global console logger and login redirect in `main.tsx:26-32`.
- The modal is a single always-mounted instance (`EstateDetail.tsx:10038-10071`) with fallback props
  `formCode="P1"` and `open={!!previewForm}`. A plain P1 preview therefore keeps an **identical query key when closed**;
  `enabled:false` on an unchanged key cancels nothing.
- The transport's 10 s timer and caller-abort listener are removed the moment a `Response` is returned
  (`client/src/lib/trpcTransport.ts:92-95`). tRPC then reads the whole body with `await res.json()`
  (`@trpc/client` `httpUtils-BNq9QC3d.mjs:112`): **no byte ceiling, no body-time bound, no abort.**
- Every query shares one `httpBatchLink`. A batch aborts only when *all* its operations abort, and a null signal means
  never (`httpBatchLink-CaWjh1oW.mjs:17,125-135,190`); one synthetic error body fails every co-batched operation (:202).
  A slow preview also holds back every query batched with it.
- Retries multiply: the transport retries twice (1.5 s, 3 s) and React Query retries three times (1 s, 2 s, 4 s), so a
  hung preview can run ≈12 server renders over ≈145 s before the inline error (INFERRED composition of verified
  defaults).
- Raw client-side error text can reach the Alert: a non-JSON 200 produces the engine's `SyntaxError` text, and JSON that
  is not a tRPC envelope produces tRPC's "Unable to transform response from server", both shown verbatim at
  `EstateDetail.tsx:7793`.

**Goal:** the read-only preview owns its request end to end. Close, supersession, unmount and every render-input change
stop the browser's request and body work; no stale result, error, loading state or toast ever reaches a newer or
reopened preview; the body is bounded in bytes and time before any JSON decoding; refusals are neutral, retries are
bounded, unrelated queries and mutations are structurally isolated; and every legal region stays byte-identical.

**Non-goals:** no server cancellation claim (nothing in the preview call graph consumes the request signal; mysql2 has
no abort), no change to legal markup/print/PDF/renderers, no new endpoint, provider, client or dependency, no global
cancellation/cache/retry policy, no debounce or draft reset for P17, no Object URL (none is owned by the preview).

## State verified at planning time (2026-10-25, read-only; Nick's local time)

**Repository and queue**
- Branch `security/hybrid-vault-review`, HEAD `db0d7e9161bc3899b75858fab58bce54e3d5247a`; worktree of
  `probate pro/probatepro`; index empty; porcelain **78 ` M` + 75 `??`**. The one new entry since Task 11 closed is the
  preferences file. All 26 fingerprints in `.work/task12-prompt-update-2026-10-25/source-before.json` still match.
- Queue: 1/2/3/16/4/5 accepted; 15/9/13/10/11 done by Nick's decisions (not SHIP); 14/6/7/8 open and not reopened;
  12 next, unchecked; "Task 12 is not started" (queue :717).
- RULES.md sha256 `648f49a7…` equals both `baseline.json` entries; Rule 29 (:1966-1980) has no exceptions list. The four
  approved output behaviours live only in the queue (:9), the prompt (:29) and the preferences (#6).
- `.work/hybrid-remediation/task12/` does not exist; no `gates/*task12*` or `render-checks/*task12*` label exists, so
  `claude-task12-pass1` and `task12/claude-pass01` are free. A refusal still consumes a label (`run-gates.cjs:13-14`).
- Fixture: no listener on 43117/43316, no `mysqld`, no `mysql.pid`, no `endpoint.json`; `fixture/status.json` still
  says `ready: true` (stale, never cleared). One peer Claude session (`probatepro-hybrid-review-aa`, idle) exists;
  identity unknown. Gate B step 0 rechecks both.
- Task 11 touched no Task 12 surface file; its V4 corrections are applied (`task11/claude-pass01/final-status.md:750`).

**Pre-task fingerprints** (full SHA-256 recorded at B0; prefixes here; EOL from raw byte counts in Node, never Git Bash
`grep -c`/`sed -n`, which strip or miscount CR)

| File | State | EOL | sha256 prefix |
|---|---|---|---|
| `client/src/pages/EstateDetail.tsx` (edit target) | ` M` | CRLF 12,374/0 | `efc61382917a939a` (= Task 13 final-r3) |
| `client/src/main.tsx` (edit target) | ` M` (3+/15−) | CRLF | `2bd05a07271d9a25` |
| `client/src/lib/trpcTransport.ts` (P5 only) | clean | CRLF | `3e40f6c0cbf9015d` |
| `client/src/lib/trpcTransport.test.ts` (P5 only) | clean | CRLF | `89ad89b0b10e17e7` |
| `client/src/lib/trpc.ts` (protected) | clean | CRLF | `7dcd66f834423063` |
| `client/src/lib/printDocument.ts` (FROZEN) | clean | CRLF | `34afef60f172daa9` |
| `client/src/lib/printDocument.test.ts` (protected) | clean | CRLF | `997516ba8edc9a13` |
| `client/src/lib/attachmentDelivery.ts` (protected) | `??` | LF | `af06d770b5179a66` |
| `client/src/lib/attachmentDelivery.test.tsx` (protected) | `??` | LF | `0420b87740dbdcd5` |
| `client/src/lib/fallbackSession.ts` (protected) | `??` | LF | `4dbfdcd6bd9441a8` |
| `client/src/lib/browserResponse.testkit.ts` (reused) | `??` | LF | `3b685148a8b4e8419` |
| `client/src/lib/utils.ts` (protected) | ` M` | CRLF | `d58876f7555a8ec0` |
| `server/routers.ts` (protected, MIXED EOL) | ` M` | 6,449 CRLF / 343 LF | `1c30a5391f41b3c8` |
| `server/docgen.ts` / `shared/types.ts` / `drizzle/schema.ts` / `RULES.md` (FROZEN, runner-checked) | | CRLF | `7224c88e…` / `9a60dfb7…` / `25f7c362…` / `648f49a7…` |
| `.work/hybrid-remediation/run-gates.cjs` | | LF | `ac2828bef1392631` |

**Frozen regions of `EstateDetail.tsx` (raw CRLF bytes, `sed -b`/Node; identical to `baseline-source`)**

| Region | Current lines | Raw sha256 |
|---|---|---|
| section-to-markup block (`<div className="space-y-2 font-serif …">` … `</div>`) | 7798-7875 | `2202fe4db02847dee2e98ba49b7eaf2be049379ab43d9c1cc19de4fc4e273c59` |
| ternary + markup + fallback (`) : data?.sections ? (` … `Unable to load preview.</p>`) | 7797-7877 | `30bb9939582f77c007dd89c24f7bde0c045e467c9cdb464eff099a71ee165ec3` |
| `openPrintWindow` | 7507-7513 | `b7e73fe2360490bcb57a3180c2add600add93444a6e88f204a8260c6462e1ffd` |
| `pdfLoading` state + `handleSavePdf` (inline jsPDF) | 7515-7683 | `9bfaf35b3819cae237233e7c6e4c586ca0dff13cf081f2f121b06887d853b2a5` |
| `handlePrint` | 7685-7689 | `51a4c4b834cb2374eee7f316abbf6c1ad25667748bfc4da04860087bd5d7d3ad` |
| print + PDF together | 7507-7689 | `017fda45105031d4389e6f8e816793060eb7336e4aa09de198ea9a98e0886260` |
| import line 58 `import { renderPrintDocument } from "@/lib/printDocument";` | 58 | `489ab499720e748b0678552b1f9f44707fb5610b55f3cf74a68e2eb4690df612` |
| loading skeleton + Alert head (frozen; the single edit line 7793 sits between this row and the next, outside every frozen region) | 7782-7792 | `0ff8f6361c01ae4b881b36a57fe622a253907995586a933d14bd4df2c1815d88` |
| Alert tail + Retry button (frozen) | 7794-7796 | `bade294c54c2bd8923b77e10a10a1f2eaedbdfb2a6e2cb0a23a5ab5fff47ff98` |
| whole loading/error region 7782-7796 (pre-edit reference only; not a B4 check, because 7793 changes) | 7782-7796 | `eab888d7b4de41d4b06524b8b7c9ae7ef7f80a4d1f867dc15ff79d832eeb1508` |

The runner's `freeze()` protects 55 files, none under `client/`; the render gate hashes server DOCX XML and
`buildPreviewSections` JSON for 26 forms. Neither covers the modal, so Task 12 owns its own raw-byte region check (§9).

**Runtime facts (installed versions)**
- `@trpc/client`, `@trpc/react-query`, `@trpc/server` 11.18.0 (`@trpc/tanstack-react-query` not installed);
  `@tanstack/react-query` and `query-core` 5.90.2; `superjson` 1.13.3; React 19.2.1; vitest 2.1.9; jsdom 29.1.1;
  TypeScript 5.9.3; Node v24.13.1 (bundled undici 7.18.2); no msw/happy-dom.
- Per-call `trpc: { abortOnUnmount: true }` is a current (non-deprecated) option; the deprecated one is the Provider
  prop (`getQueryKey.d-CruH3ncI.d.mts:41-45` vs `:166-175`). The hook accepts `skipToken`, and the key drops the input for
  it, giving `[["document","preview"],{type:"query"}]` (`getQueryKey-BY58RNzP.mjs:166`).
- React Query: a revert cancel restores the pre-fetch state with `fetchStatus: "idle"` and dispatches no `error`
  action (`query.js:248-256, 289-299`); `cancelQueries` defaults to `revert: true`; late results after a cancel are
  ignored (`retryer.js:28-48`); a same-key fetch while in flight dedupes (`query.js:168-178`); `refetch()` cancels the
  in-flight fetch silently when data exists (`cancelRefetch`).
- `httpLink` passes `op.signal` to fetch (`httpLink-oiU8eqFi.mjs:59`) and `headers({ op })` (:62); `splitLink` routes per
  operation (`splitLink-B7Cuf2c_.mjs:35`); both are exported by `@trpc/client`; the server has no batching options and
  takes the same path for a single GET.
- Server `document.preview` (`server/routers.ts:4767-4903`) is a protected **query** that writes nothing (ownership,
  one-merge overrides, applicability, P9 proof, P8 ambiguity 400, ordinal history; `buildPreviewSections` is synchronous
  and its only caller). Request-level side effects remain: `upsertUser lastSignedIn`, the `idor_attempt` audit row on a
  foreign estate, rotation headers. No compression middleware, no Content-Length (chunked), express adapter, no
  response-size limit; the Express `apiLimiter` is 200 requests/min/IP and counts an un-batched preview as one request.
- Payload: text-only `PreviewSection[]` (`docgen.ts:6735-6760`); the letterhead image is a `/manus-storage/<key>` URL
  string, never bytes; the DOCX-letterhead section is one short text section. The P9 Exhibit A re-render, packages and
  exhibit reconstruction are **not** on the preview path (DOCX only).
- jsdom tests: `fetch`/`Response`/`ReadableStream`/`TextDecoder` are Node's; `AbortController`/`AbortSignal`/
  `Uint8Array`/`Blob`/`Headers` are jsdom's (cross-realm: compare bytes with `Array.from`; set storage before fake
  timers). Reusable kit: `browserResponse`, `chunkedStream`, `stalledStream` in `client/src/lib/browserResponse.testkit.ts`.
- Every client test that renders the modal stubs `@/lib/trpc` with plain objects or proxies and renders no
  `QueryClientProvider`; the preflight static mock's preview stub ignores options and its `useUtils` has no
  `document.preview`; the p5-draft proxy records preview inputs only when `options?.enabled` is truthy. **Any new React
  Query hook inside the modal would throw in those suites**, so the design uses none.

## Connected-feature matrix (prompt :56)

| Surface | Request identity | Link / cache / batch | Auth / rotation | Observer | Body reader / timer / controller | Downstream control | Frozen region | Existing test |
|---|---|---|---|---|---|---|---|---|
| `FormPreviewModal` preview query (`EstateDetail.tsx:7419-7426`) | RQ key = exact input (undefined dropped; P17 drafts and `generateAnyway` included) | shared `httpBatchLink`, GET `?batch=1&input=`; RQ defaults (retry 3, staleTime 0, gcTime 5 min, refetch on focus) | `headers()` → `fallbackAuthorizationHeader`; cookie via `credentials: "include"`; `onResponse` stores `X-Rotated-Session` | one observer; `enabled: open`; never unmounts with FormsTab | transport controller (headers only, 10 s); tRPC `res.json()` unbounded | DOCX/PDF/Print/zoom/Edit address need `data?.sections` | markup 7798-7875 | `preflight.test.tsx:305-331, 385-411, 727-825`; `p5-draft:270-298` |
| P17 address editor (7394-7418, 7762-7779) | drafts re-key the query per trimmed change | same | same | same | same | download reuses `effectivePreviewOverrides` | none | `preflight.test.tsx:385-411` |
| Modal DOCX download (7440-7505) | `document.generate` mutation (batch POST) then `fetchDeliveryAttachment(delivery)` with **no signal** | mutation loader; own `fetch` | Bearer in `Authorization` only; cookie path included | `useDeliveryFeedbackOwner(\`preview:${estateId}\`, open)` | attachment's own controller, 64 MiB/512 MiB, 900 s/60 s/30 min | `runWithPreflight(…, "download")` | none | `task13-recovery.test.tsx:1076-1119`; `bearer-delivery:295-359`; `p8-download:290-303` |
| Print (`openPrintWindow`, `handlePrint`, `printDocument.ts`) | n/a | n/a | n/a | n/a | 250 ms timer inside the frozen region | needs `data?.sections` | 7507-7513, 7685-7689, whole `printDocument.ts` | `printDocument.test.ts`; `preflight.test.tsx:757-825` |
| PDF (`handleSavePdf`) | n/a | n/a | n/a | n/a | jsPDF's own `saveAs` URL (revoked by the library after 40 s) | needs `data?.sections` | 7515-7683 | `preflight.test.tsx:757-825` |
| Co-mounted queries on the Forms tab (auth.me, settings.get, deadline.list polling, document.list/versions/retainedFiles, contact.list, inventory.list, readiness.*, delivery.*, …) | their own keys | same batch link; dispatched per `setTimeout(dispatch)` tick | same | own observers | same transport | unrelated | none | their suites |
| `previewStoredFile` (`utils.ts:18-28`) | navigation (`window.open`) | none | proxy redirect | none | none | n/a | none | `utils.test.ts` |
| Object URLs | none owned by the preview (modal 7360-7884 has no `createObjectURL`) | | | | | upload previews, inventory template, attachment `handOff` (120 s), chatbot export, jsPDF internal | | `attachmentDelivery.test.tsx:382-396`, `botClient.test.ts` |

## Decisions requested (Gate A)

| # | Decision | Recommended | Alternative |
|---|---|---|---|
| P1 | **Isolation mechanism** (a narrowly routed `main.tsx` link change, prompt :62) | A `splitLink` that sends only the `document.preview` **query** to an un-batched `httpLink`; both links share one `createTrpcTransportFetch({ onResponse })` instance, `superjson` and `fallbackAuthorizationHeader`. Every other operation keeps the identical `httpBatchLink` configuration. Link construction moves verbatim into a new `client/src/lib/trpcLinks.ts` factory so tests exercise the real wiring (`main.tsx` renders at import and cannot be imported by tests). **Sub-decision P1a:** move the six-line `X-Rotated-Session` handler (`main.tsx:57-64`) into the factory as its default `onResponse`, so the `sessionStorage` write is testable on both links (L4); `main.tsx` then passes nothing. **Decided (2026-10-26):** the tested link factory, and P1a: the rotation handler moves into the factory with its behaviour unchanged. **Reviewer dissent (minimal-change, 2026-10-26; recorded, not applied):** on P1, an inline `splitLink` in `main.tsx` (about 10 changed lines, the lifecycle test building the same six link lines itself) is the smaller shape, and the factory buys only a real-wiring import in tests; on P1a, the preservation list names the handler by location ("X-Rotated-Session handling in main.tsx onResponse"), the one shared transport instance already runs it for both links (`trpcTransport.ts:73`), and the move buys only L4. **Nick, 2026-10-27:** keep both; confirmed. | Inline the `splitLink` in `main.tsx` and replicate the configuration in tests (no factory); or keep the rotation handler in `main.tsx` and have L4 assert only that the same `onResponse` is invoked for a preview GET and a batch request. Keeping `httpBatchLink` alone is not viable: a batch holding a preview cannot be aborted, and one failure fans out to every co-batched operation. |
| P2 | **Numeric ceilings** (prompt :60) | See §2: ceiling **4 MiB** of decoded body bytes of the full tRPC/SuperJSON envelope; refusal-body bound **16 KiB**; body idle **15 s**; body total **60 s**; the transport's 10 s per-attempt header timer and 2 retries unchanged. Approve the bounded fictional measurement probe at B1 (P1, P2, P10/P11 long-form, LETTER with image and DOCX letterhead, Unicode) that confirms headroom before the number is final. **Decided (2026-10-26):** 4 MiB provisionally, 16 KiB refusals, 15 s body idle, 60 s body total, subject to the approved P12 probe; return with evidence if 8 MiB is needed; **never truncate** — a refusal is all-or-nothing, and no partial preview is ever parsed, rendered or cached (§2 steps 6–7). **Reader simplified after review (2026-10-26, flagged in §12):** the Content-Length pre-gate and the identity-length mismatch rule are removed, so the decoded-byte count is the only size authority (a lying, absent or proxy-rewritten header changes nothing, and a truncated body fails closed in tRPC's parse); and a 2xx whose content-type is not JSON is refused before any byte is read, with the same neutral sentence. Neither changes anything a user sees. | **8 MiB** ceiling, which also covers the theoretical all-astral 500-row P10 worst case; or different time values. **Sub-decision P2a** (raised by the correctness reviewer): keep the shared transport's 10 s per-attempt header timer and 2 retries for the preview (recommended; one shared instance), or give the preview link its own `createTrpcTransportFetch` instance with a longer header timeout (changes the server-compute bound and the visible timing; not recommended without a measured need). **Decided (2026-10-26):** keep the existing header timer and retry settings initially and document the combined retry/elapsed-time budget, now the last two rows of the Budgets table. |
| P3 | **Refusal copy** (prompt :72) | One new client sentence for every client-side failure (ceiling, body time, incomplete, malformed JSON, non-tRPC JSON, non-JSON 200): **"The preview could not be loaded. Please try again."** Server and transport envelope messages (which carry `error.data`) keep showing verbatim, exactly as today. The Alert heading "Preview could not be generated", the "Retry preview" button and "Unable to load preview." are unchanged. **Decided (2026-10-26):** approved, preserving only existing safe public server messages. Those are exactly what reaches the client today: Task 14's error formatter (`server/_core/trpc.ts:11-26`) rewrites every `document.*` error to a branded public sentence or `GENERIC_FAILURE_SENTENCE`, strips the stack and the path, and the transport's three synthetic envelope sentences are fixed client text (`trpcTransport.ts:81,98-100`). `previewErrorMessage` therefore surfaces nothing new; a non-envelope body such as the Express 429 gets the neutral sentence. | Reuse the transport's "Server is temporarily unavailable. Please try again in a moment." for all client-side failures (misleading for an oversize body); or keep showing raw engine/library text (violates prompt :71). |
| P4 | **Preview retry policy** | One rule on the preview query only: `retry: (count, error) => !!error.data && count < 3`. Server and transport envelope errors (they carry `data`) keep today's three React Query retries; every client-side cause (`PreviewTransportError` ceiling/body-time/incomplete, a truncated or non-JSON 200, non-tRPC JSON) is terminal, because re-downloading up to the ceiling three more times is the hazard. The transport's own 2 retries are unchanged. **Decided (2026-10-26):** approved; cancellations and every client-side failure (ceiling, body time, incomplete, malformed, session-ended) are terminal. | Terminal only for `PreviewTransportError`, keeping 3 retries for parse failures (up to four ceiling-sized downloads); or a preview transport with `maxRetries: 0` (changes visible timing). |
| P5 | **Shared transport change** (prompt :69 "no restart during backoff") | **No shared change.** During the transport's backoff an aborted caller cannot stop the next loop iteration, but that iteration pre-aborts its controller (`trpcTransport.ts:60`) and calls `fetchImpl` with an already-aborted signal (:68), which a spec-compliant `fetch` rejects without any network request; React Query has already discarded the operation. The behaviour is documented, and the lifecycle test exercises "abort during backoff" with an abort-honouring stub (R11), asserting no network attempt after the abort. **Decided (2026-10-26):** the minimal abort-aware wait **is approved**, with cleanup and no-further-attempt tests; the r1 recommendation in this cell is superseded, and §5 (exact change) and §9 (T1–T3, L6) now include it. **P5b (Nick, 2026-10-27; flagged in §12):** the same file also cancels the body of every non-JSON ≥ 400 response it discards (`trpcTransport.ts:75-82`: `void response.body?.cancel().catch(() => undefined)` before each `continue` and before `return unavailableResponse(...)`), because the outer preview reader never sees those responses and cannot release their streams; cleanup for all operations, nothing read or logged, T4 as its test. | A three-line change in `trpcTransport.ts` (abort-aware `wait`, throw the abort reason instead of re-invoking `fetchImpl`), behaviour-preserving for non-aborted callers, with two added cases in `trpcTransport.test.ts`. Only worth it if a strict `fetchImpl` call-count assertion is required. |
| P6 | **Close cancellation for the same-key (plain P1) case** | Add `subscribed: open` beside `enabled: open`. React Query 5.90.2 unsubscribes the observer when `subscribed` is `false` (`useBaseQuery.js:54-62` → `onUnsubscribe` → `destroy()` → `removeObserver`), which is the same revert-cancel path as a key change, on the **same key**: no new hook, no `skipToken` import, the stub suites keep receiving the input object, a loaded preview keeps its cached sections during the dialog's fade-out, and a reopen re-subscribes and fetches (stale). Typed end to end (`types.d.ts:9,27`; tRPC's `UseTRPCQueryOptions` extends `UseBaseQueryOptions`). Must be proven by the lifecycle tests (R3) before it is kept. **Decided (2026-10-26):** `subscribed: open`. | Pass `skipToken` as the input while closed (`open ? input : skipToken`): the closed key differs from every open key, so the same cancel path runs; needs one `@tanstack/react-query` import in `EstateDetail.tsx` and shows the fallback text during the fade-out. An explicit exact-key `cancelQueries` via `useQueryClient`/`useUtils` is rejected: it needs provider or mock extensions in the stub suites. |
| P7 | **Cache and freshness** | Keep React Query defaults per query (staleTime 0, gcTime 5 min): a same-input reopen within 5 min shows the cached sections at once and refetches in the background, exactly as today; close cancels an in-flight fetch, so a reopen after a cancelled first load fetches fresh. No `placeholderData`, no global change. **Decided (2026-10-26):** approved, provided stale completions cannot populate a reopened or different preview or overwrite another observer's state. Design evidence: a cancelled attempt's late result is ignored by its own retryer (`retryer.js:28-48`), a completed attempt writes only its own key, and an observer on another key never receives it; R1–R3 and R7 prove it. | A preview `staleTime` or `gcTime` override (behaviour change, not needed for the contracts). |
| P8 | **Session guard** | None beyond the existing transport behaviour: the preview hands off no bytes and shows only formatter-approved text; a token-equality guard would self-cancel on a legitimate Bearer rotation, because `onResponse` stores the rotated token before the body is read; the generation counter changes only on logout, which hard-reloads, or on account deletion from a page where the modal is not mounted. **Decided (2026-10-26):** not approved unconditionally. Required: suppress results from a previous logged-out or account-changed session using the existing session identity, keep normal token rotation valid, add no authentication system. **Specified guard (generation only; §2 steps 1, 1a and 6):** `createPreviewTransportFetch` records `clientSessionGeneration()` (`client/src/lib/fallbackSession.ts:34-36`) before the request and compares it after the headers and again after the last body chunk; a mismatch cancels the body or reader, drops every byte and throws `PreviewTransportError("session-ended")` (terminal per P4, neutral sentence per P3). The generation is bumped only by `clearFallbackSession()` (`fallbackSession.ts:39-46`), called on sign-out just before the reload (`client/src/_core/hooks/useAuth.ts:47-48`) and after account deletion (`client/src/pages/Settings.tsx:371`); a same-user `X-Rotated-Session` rotation only rewrites the stored token in `main.tsx` and never touches the generation, which is what the attachment feedback owner already relies on (`attachmentDelivery.ts:206-209`). The download path's `sameSession()` additionally compares the token (`attachmentDelivery.ts:81-83`), accepted Task 9 behaviour there and deliberately **not** copied here because it would fail a legitimate rotation mid-preview. U13 and the R12 extension prove it. **Partially addressed 2026-10-27; not marked resolved (Nick):** three layers on the existing per-tab generation are specified, and P8 stays open for Nick's explicit decision on the limitations retained at the end of this cell. (1) Transport: the wrapper's checks after the headers and after the last chunk (above). (2) Final acceptance: a result that passes the wrapper is written by React Query into a cache entry whose hash includes the generation current at the observer's last render (`previewQueryKeyHash` = `hashKey([key, clientSessionGeneration()])`, honoured per query by `hashQueryKeyByOptions`, `utils.js:81-83`, and `queryCache.build`, `queryCache.js:15`), so a session end makes that entry unreachable at the modal's next render and a reopen fetches fresh. (3) Cached-data reuse: the same hash rule; no entry from a previous generation can be read back, with React Query defaults otherwise unchanged (P7) and no other client code touching `document.preview` (verified: the modal is its only caller). Rotation: `X-Rotated-Session` rewrites only the stored token; the generation, the hash and in-flight requests are untouched (U13, U15, R19). **Limitations retained for Nick's explicit decision, not claimed as covered:** (a) the next-render limitation: the partition takes effect at the modal's next render, so a result that settles inside the same macrotask as the session end, after the wrapper's final check, is rendered until that render; (b) the unsupported identity flows: a sign-out in another tab does not bump this tab's generation (per-tab counter, pre-existing for every query; the next request fails server-side and the existing login redirect runs); server-side expiry or revocation without a client sign-out leaves the generation unchanged (same pre-existing handling); a same-tab account switch without a reload has no flow in this app (login is a full navigation, sign-out reloads at `useAuth.ts:55`, account deletion routes to `/goodbye` at `Settings.tsx:384-388`) and is not claimed. | Generation-only guard: a preview that completes after `clientSessionGeneration()` changed is treated as cancelled (dead code in practice; adds a check at the modal boundary). |
| P9 | **Task 13 download residuals** | Out of scope, recorded: a late download toast can reappear if any preview of the same estate is reopened before an earlier modal download settles; `downloadPending` survives close; the S4 microtask-gap one-liner remains "a follow-up for Nick" (dispositions-r3 :39-41). **Decided (2026-10-26):** approved, kept out of scope. | Bring any of the three into Task 12 (each is a change to accepted Task 13 behaviour). |
| P10 | **Controls on refusal** | Keep: DOCX/PDF/Print/zoom/Edit-address already require `data?.sections`, so a preview refusal hides them inside the modal, as any preview error does today; Forms-row generation, Generate anyway and the preflight gate are untouched, which satisfies prompt :31. **Decided (2026-10-26):** approved for unavailable preview-dependent controls; the Alert's "Retry preview" stays visible as the recovery path, and the Forms-row Generate and Generate-anyway paths are neither hidden nor disabled. | Show the DOCX button on refusal (new behaviour; a new generate path from a refused preview). |
| P11 | **Console trail** | Unchanged: `main.tsx:30` keeps logging real query errors (including the new neutral preview refusals, which carry no body); cancellations never reach it because a revert cancel dispatches no error. No new logging anywhere. **Decided (2026-10-26):** approved; existing global logging stays outside this task, and this does not clear existing logging concerns. New failures attach nothing sensitive: `PreviewTransportError` carries only a `reason` code and the neutral sentence, never a `cause` holding response data, headers, bytes, URLs, tokens or raw error text (§2). | Filter preview refusals out of the global subscriber (a global change). |
| P12 | **Measurement probe at B1** | Approve one bounded fictional probe on the owned fixture copy: open the listed forms through the real modal with CDP capture, record decoded envelope bytes per form, stop. No production. **Decided (2026-10-26):** approved. **Corrected 2026-10-27 (Nick):** the probe is not write-free and is no longer called read-only: signing the fictional fixture user in updates `users.lastSignedIn` (`upsertUser`), the session cookie may rotate, and the fixture status files change; the preview procedure itself writes no `documents` or audit row for an owned estate (asserted by row counts). The receipt records the exact artifact hashes it ran against (served `index.html`, the client bundle, the UI-server source hashes) and these expected updates. It runs after B5, because the build it measures is B5's output. | Skip the probe and accept the static estimate as the only justification. |

## Design

### 1. Routing (P1)

```
trpc.createClient({ links: createAppTrpcLinks() })                       main.tsx, unchanged subscribers/Provider (P1a)

createAppTrpcLinks({ fetchImpl?, onResponse?, retryDelayMs? }):            new client/src/lib/trpcLinks.ts (LF)
  // the app passes nothing; the three optional hooks exist for the tests and are forwarded unchanged
  const transportFetch = createTrpcTransportFetch({ fetchImpl, onResponse: onResponse ?? storeRotatedSession, retryDelayMs })   // ONE instance, shared
  return [ splitLink({
      condition: (op) => op.type === "query" && op.path === "document.preview",
      true:  [previewValidationLink,                                   // r5: validates the transformed envelope first
               httpLink({ url: "/api/trpc", transformer: superjson, headers: fallbackAuthorizationHeader,
                          fetch: createPreviewTransportFetch(transportFetch) })],
      false: httpBatchLink({ url: "/api/trpc", transformer: superjson, headers: fallbackAuthorizationHeader,
                        fetch: transportFetch }) }) ]
```
- The preview is the only operation on the `true` branch; it is never batched, so its cancellation or cap can never touch
  another operation, and no other operation can land on the bounded link. Mutations (including `document.generate`)
  stay on the batch link's mutation loader exactly as today.
- `headers` is the same function on both links; the token travels only in `Authorization` (the input stays in the GET
  URL as today); `credentials: "include"` and the `X-Rotated-Session` write happen inside the shared transport for both.
- Server-visible difference: the preview arrives as a single GET without `batch=1`, with its own `createContext` (one
  `upsertUser`, one rotation check, one `apiLimiter` count). The procedure, auth and formatter paths are identical.

### 2. Bounded reader (P2, P3, P4) — new `client/src/lib/previewTransport.ts` (LF)

`createPreviewTransportFetch(inner)` wraps the **returned Response** of the shared transport (a reader placed inside the
transport as `fetchImpl` would have its refusals retried twice, `trpcTransport.ts:84-91`). Contract, in order:
1. `const generationAtStart = clientSessionGeneration()` (P8), then `const response = await inner(input, init)` — the
   shared transport still owns the 10 s header timer, retries, the
   synthetic 503 and the rotation write.
1a. If `clientSessionGeneration() !== generationAtStart` → cancel the body (errors swallowed) and throw
   `PreviewTransportError("session-ended")` (P8): the tab's session ended by sign-out or account deletion while the
   request was in flight. A same-user token rotation never changes the generation, so it passes.
2. If `init.signal` is already aborted → cancel the body (`response.body?.cancel()`, errors swallowed) and throw its
   reason (an `AbortError`). The transport removed its own listener when it returned, so an abort landing between the
   transport's return and the wrapper's first read must be caught here, or the stream and connection stay open until
   GC. The wrapper then attaches its own `{ once: true }` listener for the body phase.
3. Status 204/205/304 or no body → return the response unchanged (tRPC's parse then fails → neutral sentence). A 2xx
   whose `content-type` does not include `application/json` → cancel the body unread and throw
   `PreviewTransportError("not-json")`: the same neutral sentence, but zero bytes downloaded instead of up to the ceiling
   of an HTML login or proxy page (the transport intercepts non-JSON only for status ≥ 400, `trpcTransport.ts:75`).
4. `limit = response.status >= 400 ? PREVIEW_REFUSAL_BODY_LIMIT_BYTES : PREVIEW_BODY_CEILING_BYTES`.
5. `Content-Length` and `Content-Encoding` are ignored: the decoded-byte count in step 6 is the only size authority
   (preferences #11), so a lying, absent or proxy-rewritten header can neither refuse a good body nor admit a bad one,
   and a truncated body fails closed in tRPC's parse. (r1's pre-gate and identity-mismatch rules were dropped on review.)
6. Reader loop over `response.body.getReader()` in the shape of `attachmentDelivery.ts:415-470` (`stop` reason,
   `halt`, per-chunk `touch`, `finally` cleanup) minus its session checks and container markers: running total of
   decoded `value.byteLength`; `> limit` → `halt("too-large")`; idle timer (armed before the first read, reset per
   chunk) and total timer → `halt("body-timeout")`; stream error → `incomplete`; abort during the loop → the reader is
   cancelled and the signal's own reason is rethrown (one abort contract with step 2; never a `PreviewTransportError`).
   Each chunk is also fed to one streaming `TextDecoder` (`decode(value, { stream: true })`), so the ceiling counts
   bytes while the body accumulates as text: no chunk array, no joined `Uint8Array`, a split multi-byte sequence
   reassembled for free, and exactly the non-fatal UTF-8 decoding `res.json()` would apply. **A stop decided
   while a `read()` is pending outranks that read's own result** (`if (stop) …` right after each `await reader.read()`),
   so an abort or timeout never yields a truncated `Response`. After the final chunk, `clientSessionGeneration()` is compared with `generationAtStart` once more (P8);
   a mismatch cancels the reader, drops the buffer and throws `session-ended`. `halt` aborts nothing upstream (the
   transport already returned); it cancels the reader
   (`reader.cancel().catch(() => undefined)`), which also ends a pending read.
7. Success → `new Response(text, { status: response.status, headers: { "content-type": <original content-type
   or "application/json"> } })` (the decoder's flushed text, so no cross-realm typed array is ever handed to Node's
   `Response` under jsdom) — no `statusText` (a non-reason-phrase value would throw) and no copied
   `content-length`/`content-encoding` (misleading on an already-decoded buffer; nothing downstream reads them: tRPC
   only calls `res.json()`, and `onResponse` already ran on the original). `finally` clears both timers and the abort
   listener; **every** non-success exit (pre-read abort, non-JSON refusal, ceiling, timers, stream error, session end, abort
   during read) cancels the reader or the body before throwing.
- The wrapper does **not** parse JSON and never inspects, logs or rewrites sections: SuperJSON meaning and every legal
  string pass through untouched. Truncated or non-JSON bodies fail inside tRPC and are mapped to the neutral sentence by
  the modal rule (§3); they are never shown raw.
- `PreviewTransportError` has exactly two own fields: `reason` (`"not-json" | "too-large" | "body-timeout" |
  "incomplete" | "session-ended"`) and `message`, the approved neutral sentence (P3). An abort is never a
  `PreviewTransportError`: the signal's reason is rethrown, pre-read or mid-read alike. It never carries a `cause`,
  headers, bytes, a URL, a token or engine text (P11). No helper inspects it at runtime: `previewRetry` and
  `previewErrorMessage` key on `error.data`; tests reach the thrown error through `TRPCClientError.cause`, because tRPC
  wraps whatever a link throws.

**Budgets (P2; all values proposed — not approved)**

| Budget | Value | Scope | Enforced at | When exceeded | Released by | Rationale |
|---|---|---|---|---|---|---|
| `PREVIEW_BODY_CEILING_BYTES` | **4,194,304** (alt 8,388,608) | decoded body bytes of the whole tRPC/SuperJSON envelope of a 2xx preview | reader loop (the decoded-byte count; headers are ignored) | `too-large` → neutral sentence; terminal (no RQ retry); reader cancelled, chunks dropped | — | Static estimate: typical 2–20 KB (≈200–2,000× headroom), heavy plausible inventory forms 30–250 KB (≈16× at 250 KB), DB-bounded theoretical P10/P11 ≈1.8 MB ASCII (fits) up to ≈7 MB all-astral (refused preview-only; 8 MiB alternative covers it), LETTER with a pathological 10,000-character template is unbounded (disclosed). Client cost at the ceiling is a nominal estimate (parse plus SuperJSON copy, roughly 2–3× the body); the probe measures wire and decoded **bytes**, not heap, so it proves no memory bound, and no heap measurement is planned. **Byte estimate, checked by the B1 probe; the memory figure stays unproven.** |
| `PREVIEW_REFUSAL_BODY_LIMIT_BYTES` | **16,384** | bodies with status ≥ 400 | reader loop | `too-large` → neutral sentence | — | tRPC error envelopes for `document.*` carry a fixed public sentence plus `code`/`httpStatus` (< 1 KB); 16 KiB is ≥16× headroom and bounds hostile error pages; not the attachment path's 64 KiB, which was justified for route JSON refusals. |
| `PREVIEW_BODY_IDLE_TIMEOUT_MS` | **15,000** | gap between body chunks | idle timer | `body-timeout` → neutral sentence; terminal | cleared in `finally` | A stalled stream after headers is detected within 15 s; proxy buffering of a ≤4 MiB body is far below this. |
| `PREVIEW_BODY_TOTAL_TIMEOUT_MS` | **60,000** | first body byte → end | total timer | `body-timeout` | cleared in `finally` | 4 MiB at 100 KB/s is 42 s; typical bodies arrive in well under 1 s. |
| Header time | 10,000 ms per attempt (existing) | transport | unchanged | synthetic 503 after retries | — | Not a Task 12 policy. |
| Transport retries | 2 (existing, 1.5 s / 3 s) | transport | unchanged (P5 only changes the aborted case) | — | — | Not a Task 12 policy. |
| React Query retries | 3 (existing); errors without `error.data` → 0 (every client-side cause and every cancellation, P4) | per-call `retry` on the preview query only | query layer | — | — | Oversize/timeout/parse refusals must not re-download; envelope errors keep today's timing. |
| Combined budget A, headers never arrive (nominal, P2a) | ≈145 s, 12 server renders | per preview load | transport × React Query | the Alert with the transport's synthetic sentence | — | Per React Query attempt: 10 s + 1.5 s + 10 s + 3 s + 10 s = 34.5 s to a synthetic 503; four attempts (initial + 3 retries) with delays 1 s, 2 s, 4 s → 4 × 34.5 + 7 = 145 s. Unchanged by this task. With P5, an abort during any backoff wait ends it at once. R17 observes it. |
| Combined budget B, one success body stalls after headers (nominal, P2a) | ≈205 s | per preview load | transport × React Query × body timers | the Alert with the neutral sentence | — | Body-timeout is terminal (P4), so exactly one success-body phase can occur: three header-failed attempts (103.5 s) + delays (7 s) + the final attempt's two header failures (24.5 s) + headers arriving just inside the 10 s timer (10 s) + the body total timer (60 s) = 205 s. r3 said 195 s by assuming instant headers; corrected by Nick. A body that only idles is cut at 15 s. Today the body phase is unbounded. |
| Combined budget C, a slow JSON error body on every attempt (nominal, P2a) | ≈385 s | per preview load | transport × React Query × body timers | the Alert with the server's public sentence | — | A JSON ≥ 400 envelope carries `data`, so React Query retries it: each attempt can spend 24.5 s on two header failures, 10 s on headers and up to 60 s streaming a ≤ 16 KiB refusal body = 94.5 s; 4 × 94.5 + 7 = 385 s. Constructed worst case, Nick's figure. |
| What these figures are | nominal worst-case estimates from verified defaults | | | | | Not typical preview times (typically well under 1 s end to end) and not server-compute limits: the server keeps computing after a client abort. B and C are computed, not measured. |

### 3. Modal lifecycle (P6, P7) — `EstateDetail.tsx`, outside every frozen region

```ts
const previewQuery = trpc.document.preview.useQuery(
  { /* the identical input object literal, lines 7421-7423, byte-for-byte */ },
  {
    enabled: open,
    subscribed: open,
    networkMode: "offlineFirst",          // the first attempt always runs, so a close can always cancel (offline row below)
    retry: previewRetry,
    queryKeyHashFn: previewQueryKeyHash,  // the tab's session generation partitions the cache (P8)
    trpc: { abortOnUnmount: true },
  },
);
const { isLoading } = previewQuery;
const data = previewQuery.isError ? undefined : previewQuery.data;   // r5: usable data only from a non-error, non-refusal result
```
- **Request identity** = the React Query key (hash of the exact input; `undefined` fields drop out; object identity is
  irrelevant). `generateAnyway`, consent objects, selected/deponent/beneficiary/delivery/citation/ordinal, signatory,
  date and the effective P17 overrides are all part of it, unchanged in semantics.
- **State machine per key:** `idle → fetching(attempt n: headers → body → parse) → success | error | reverted`.

| Event | Effect |
|---|---|
| open with input K | observer on K; fetch if stale (cached sections show immediately if present) |
| input changes K→K′ (P17 keystroke, contact/deponent/ordinal/date/consent/override change) | observer moves to K′; K has no observer → `cancel({revert:true})` → `op.signal` aborts → transport controller abort (before headers) or reader cancel (during body); K′ fetches; the user's inputs are never reset |
| close | `subscribed` turns false → the observer unsubscribes from K (`destroy()` → `removeObserver`) → the same cancellation as a key change; K keeps any cached sections for gcTime; nothing fetches while closed (`enabled: open`) |
| unmount (tab/estate change) | observer destroyed → same cancellation |
| Retry button | `refetch()` (`cancelRefetch`) → in-flight attempt cancelled silently, fresh fetch |
| same-key reopen within gcTime | cached sections render; background refetch (unchanged default) |
| same-key reopen while K is still being cancelled | K's retryer is already rejected, so the new fetch starts fresh (`query.js:168-171` skips the dedupe branch for a rejected retryer) |
| late result/error after any cancel | ignored by the retryer (`resolve`/`reject` are no-ops once settled); no cache write, no `error` action, no toast, no console line, no redirect |
| PreviewTransportError | `error` state with the neutral sentence; no RQ retry; Alert + Retry button |
| offline at open (`navigator.onLine` false) | `networkMode: "offlineFirst"` runs the first attempt anyway: the browser fetch rejects, the transport retries twice (abort-aware waits), returns its synthetic 503, and React Query's retry sleep then **pauses** until the tab is online **and focused** (`canContinue`, `retryer.js:41,95-97`); the signal was consumed by the first attempt, so a close that removes the query's **last observer** (the exact key + generation hash) takes the revert-cancel path (`query.js:146-152`), and a later online-and-focused tab resumes nothing (`run()` returns on a settled retryer, `retryer.js:70-73`); a preview still open when the tab is online and focused resumes and loads; a second observer on the same key keeps the query alive; other observers' paused queries resume on the same condition |
| malformed payload (validation link rejects before the promise resolves) | query `error` action with a data-less `TRPCClientError` (terminal per P4) and **no cache write**: a first load leaves the key without data; a same-key refetch keeps the earlier valid data in the cache (`query.js:360-371` touches no `data`) but the modal's gate hides it, so preview-dependent controls hide and the frozen Alert shows the neutral sentence with Retry; a valid Retry restores both |
| refusal or server error after valid cached data | same as above: cache unchanged, gated `data` undefined, controls hidden, Alert with the neutral (refusal) or public (server) sentence; a valid Retry restores both |
| session ended while cached data exists | the modal's next render hashes the key with the new generation (`previewQueryKeyHash`), so the old entry is unreachable and a reopen fetches fresh; the orphaned entry is garbage-collected after gcTime |
| server/transport envelope error | unchanged: shown verbatim; RQ retries 3 as today |

- **Cleanup owned per attempt:** the transport's controller and timer (existing), the wrapper's abort listener, idle and
  total timers, the reader (cancelled on every non-success exit) and the chunk buffer (dropped on refusal). The modal
  owns no AbortController, Blob URL, effect or toast for the preview.
- **Copy rule at the Alert (P3):** `previewErrorMessage(error) = error.data ? error.message : PREVIEW_UNAVAILABLE_SENTENCE`.
  Server tRPC errors and the transport's synthetic envelopes carry `data`; client-side causes (`PreviewTransportError`,
  `SyntaxError` from `res.json()`, tRPC's `TransformResultError`) do not.
- **Payload validation (preview-branch link, r5):** `validatePreviewPayload` runs inside `previewValidationLink`, a
  tiny tRPC link placed on the preview branch ahead of `httpLink` (a `splitLink` branch chains an array of links,
  `splitLink-B7Cuf2c_.mjs:26-39`). `httpLink` has already applied the SuperJSON output transform when it emits the
  envelope (`httpLink-oiU8eqFi.mjs:69-71`), so the link validates `envelope.result.data` after transformation and
  before the client resolves the query promise (`index.mjs:93-96`): a malformed payload makes the link call
  `observer.error(TRPCClientError.from(new PreviewPayloadError()))`, the promise rejects, React Query records an
  `error` (no `data` on the error → terminal per P4) and **never writes the payload to the cache**; a well-formed
  payload is forwarded by reference (the transport still never parses). The frozen loading/error region then renders
  the Alert with the neutral sentence and a working Retry, the modal's gated `data` is `undefined`, nothing from the
  payload is rendered, and the global subscriber logs its existing `[API Query Error]` line with the neutral text only.
  **Gate (r5, outside every frozen region):** `const data = previewQuery.isError ? undefined : previewQuery.data`, so
  after a failed same-key refetch, where React Query keeps the earlier data in the cache (`query.js:360-371`), the
  markup and every preview-dependent control (DOCX, PDF, Print, zoom, Edit address) see no data until a non-error,
  non-refusal result arrives (R20, R21). Accepted exactly as `PreviewSection`
  (`server/docgen.ts:6735-6760`) and the frozen markup's dereferences (7799-7873) require: `sections` is an array;
  every element is a non-null object whose `type` is one of the ten literals; `text`, `imageUrl` and `deliveryMethod`
  are strings or absent; `recipientLines` is absent or an array of strings; `rows` is absent or an array of objects
  whose `cells` is an array of strings, whose `colSpans` is absent or an array of finite numbers and whose `cellAligns`
  is absent or an array of the three literals; each optional boolean field (`bold`, `italic`, `center`, `checked`,
  `hideUnchecked`, `hideMarker`, `indent`, `suppressRule`, row `header`, row `italic`) is absent, `true` or `false`,
  never coerced (`1`, `"true"` and `null` are rejected); `align` is absent or one of its three literals; unknown extra
  fields are allowed; `formCode`/`formName` are not required (nothing in the modal reads
  them, and the frozen handlers use only `data?.sections`, 7517, 7533, 7686-7687). Legitimate empty drafts pass:
  `sections: []`, empty strings, empty `rows`, missing optional fields. The validator never alters, filters, normalises
  or re-creates a section (Rule 29); `data` keeps the inferred `Output | undefined` type, so 7507-7689 compile unchanged; line
  7427 becomes the two gated lines of the code block above. The stub suites never run the links, and their stubs
  report no `isError`, so their `{ sections: [] }` stubs (p8-download:35, bearer-delivery:43, task13-recovery:66,
  preflight-busy:38, preflight:201-206, p5-draft:86) reach the modal exactly as today and keep their header controls.
- Batch isolation (§1) means a preview cancel or cap can only ever affect the preview's own request.
- **Option plumbing:** `subscribed`, `retry` and `trpc.abortOnUnmount` reach `useBaseQuery` through tRPC's option
  spread (`shared-JtnEvJvB.mjs:469-471` → `useBaseQuery.js:54,58`), and the consumed-signal flag is reset per attempt
  inside `fetchFn` (`query.js:217`), which is why a close during a React Query backoff still takes the revert-cancel
  path (R11).

### 4. Cache, batch and auth policy (P7, P8)

- No global cache purge, observer reset, `cancelQueries` call, `defaultOptions`, Provider `abortOnUnmount` or
  `createTRPCReact` config. Only the preview call carries `trpc.abortOnUnmount`, `retry`, `subscribed`, `networkMode: "offlineFirst"`,
  `select` and `queryKeyHashFn`; no QueryClient default, no `onlineManager` change, no other query is affected.
- Batching for every other query is unchanged (same link, same `setTimeout(dispatch)` window, no `maxURLLength`).
- Auth: same `fallbackAuthorizationHeader`, same cookie inclusion, same rotation write, same login redirect for
  `'Please login (10001)'`. Tokens never enter the URL, the body or any log; the preview adds no logging. The only
  session logic added is the P8 generation guard inside the wrapper: it reads the existing per-tab generation
  (`clientSessionGeneration()`), never the token, and adds no authentication layer.
- Redirects: tRPC and the transport pass no `redirect` option, so the preview follows redirects as every tRPC call does
  today. Changing that is out of scope (noted).

### 5. Exact file and interface scope (edit map)

**`client/src/main.tsx`** (CRLF; Node byte-exact splice, see the edit mechanism below): lines 42-68 become
`const trpcClient = trpc.createClient({ links: createAppTrpcLinks() });` (P1a: the six-line rotation handler and the
`headers()` wrapper with its four-line auth comment move into the factory verbatim); imports of `httpBatchLink`,
`superjson`, `createTrpcTransportFetch` and `fallbackAuthorizationHeader` move with the links; `TRPCClientError`, the
QueryClient, both cache subscribers and the Provider tree (70-76) are byte-identical.

**New `client/src/lib/trpcLinks.ts`** (LF): `createAppTrpcLinks({ fetchImpl?, onResponse?, retryDelayMs? })` as in §1;
the three optional hooks are forwarded to `createTrpcTransportFetch` unchanged and the app passes none of them. It
holds the moved `headers()` wrapper and comment, the moved rotation handler as the default `onResponse`, one
`linkOptions` object shared by both links, and the one-line routing condition; nothing is exported for tests only.
(r5) It also defines `previewValidationLink`, and the preview branch is the chain
`[previewValidationLink, httpLink(...)]`: the link subscribes to `next(op)`, validates `envelope.result.data` with
`validatePreviewPayload`, and on failure calls `observer.error(TRPCClientError.from(new PreviewPayloadError()))`
instead of forwarding, so the promise rejects before any cache write; it uses `observable` from
`@trpc/server/observable` and `TRPCClientError` from `@trpc/client`, both already dependencies of the links.
B2a creates the file first as a verbatim batch-only move (no `splitLink` yet); B3 adds the preview branch.

**New `client/src/lib/previewTransport.ts`** (LF): constants, `PreviewTransportError`, `createPreviewTransportFetch`,
`previewErrorMessage`, `previewRetry`, `PREVIEW_UNAVAILABLE_SENTENCE`, and (r4/r5) `PreviewPayloadError`,
`validatePreviewPayload` (called only by the validation link in `trpcLinks.ts`) and `previewQueryKeyHash`; every
export has an application caller. It imports
`clientSessionGeneration` from `@/lib/fallbackSession` (existing, untracked LF), the pure `hashKey` function from
`@tanstack/react-query` (a re-export of query-core, `index.js:2`; not a hook), a type-only `inferRouterOutputs` from
`@trpc/server` and the type-only `AppRouter` exactly as `client/src/lib/trpc.ts` imports it, and nothing else: in
particular nothing from `@/lib/trpc` and no React Query hook, because `EstateDetail.tsx` is loaded by the four stub
suites that mock `@/lib/trpc` with plain objects (they ignore every option, so `select` and the hash never run there).

**`client/src/pages/EstateDetail.tsx`** (CRLF, 12,374 lines; byte-exact edits, raw-byte census before/after; the
file imports nothing from `@tanstack/react-query` today, and with P6 as recommended it still does not):
- one import line added beside line 58 (`previewErrorMessage`, `previewRetry`, `previewQueryKeyHash` from
  `@/lib/previewTransport`);
- the options argument of the call (within lines 7424-7426) replaced by the one in §3, and line 7427
  `const { data, isLoading } = previewQuery;` replaced by the two gated lines in §3; the input object literal
  (7421-7423) is kept verbatim;
- line 7793 `{previewQuery.error.message}` → `{previewErrorMessage(previewQuery.error)}`;
- every other line, including the frozen regions in the table above and lines 10038-10071, is unchanged; the P17
  editor, `effectivePreviewOverrides`, `effectiveGenerateAnyway`, the download path (`fetchDeliveryAttachment` with no
  signal) and the feedback owner are untouched.

**Edit mechanism for the CRLF targets (review finding, adopted):** Node byte-exact edits are primary, never the Edit
tool alone: the `task06/claude-pass01/qa/line-edit.cjs` pattern (per-line replace / insertAfter that keeps each line's
own terminator) for the import insertion after 58 and the 7424-7427 and 7793 replacements; a ~10-line `Buffer` splice
that asserts exactly one occurrence of the CRLF-joined 42-68 block for `main.tsx`; the
`task15/claude-pass01/qa/eol-census.cjs` census after every write (bare LF or lone CR → restore from `before/` with the
`task06/.../restore-eol.cjs` pattern). The Edit tool is a secondary option with the same census.

**`client/src/lib/trpcTransport.ts`** (CRLF; P5 approved 2026-10-26): `wait(ms)` becomes `wait(ms, signal?)` (lines
35-37): it resolves after `ms` exactly as today, and rejects at once with the signal's abort reason (`signal.reason`,
else a `DOMException` named `AbortError`) if the signal is already aborted or aborts during the wait; its timer and
listener are cleared on either exit. The two call sites `await wait(retryDelayMs(attempt))` (lines 78 and 89) pass
`callerSignal`. Nothing else changes: at line 78 the rejection reaches the existing `catch`, whose
`if (callerSignal?.aborted) throw error` rethrows it; at line 89 it propagates out of the `catch`, and `finally` still
clears the attempt's timer and listener. Non-aborted callers keep identical timing and responses. **P5b (2026-10-27):**
at lines 75-82, the statement `void response.body?.cancel().catch(() => undefined);` is inserted before the
`await wait(...)`/`continue` at 78-79 and before `return unavailableResponse(...)` at 81, so every non-JSON ≥ 400
response the transport discards has its body stream cancelled; JSON responses (returned at 83) and the thrown-error
path (84-91, no response object) are untouched.
**`client/src/lib/trpcTransport.test.ts`** (CRLF): T1–T4 added (§9); every existing case untouched.

**New tests** (LF): `client/src/lib/previewTransport.test.ts`, `client/src/lib/trpcLinks.test.ts`,
`client/src/pages/EstateDetail.preview-lifecycle.test.tsx`.

**QA only, under `.work/hybrid-remediation/task12/claude-pass01/`:** `before/`, `after/`, hashes and EOL census,
`qa/frozen-regions-task12.cjs` (Node raw bytes), the B1 probe receipt, a task-owned UI launcher/server copy bound to
Task 12 hashes with a labelled preview-only delay/chunk fault adapter, browser plans and records, review dispositions,
`final-status.md`.

**Not touched:** `server/docgen.ts`, every renderer and preview builder, `shared/*`, `drizzle/*`, `server/routers.ts`
and every server file, `client/src/lib/printDocument.ts`, `attachmentDelivery.ts`, `fallbackSession.ts`, `utils.ts`,
`trpc.ts`, `PreGenerateDialog.tsx`, the four stub suites and every existing test, `vitest.config.ts`,
`vitest.setup.ts`, `tsconfig.json`, `package.json`, `pnpm-lock.yaml`, `RULES.md`, the queue (until the handoff appends
Task 12's own record), the vault, memory files, `render-fixtures.json` and `render-baseline/*`.

### 6. Object URLs (queue :60 "revoke object URLs")

**Not applicable to the preview path, with source evidence:** `FormPreviewModal` (7360-7884) contains no
`createObjectURL`/`revokeObjectURL`; the rendered sections are DOM, the letterhead image is a storage URL string, and
print uses a window document. The URLs that exist belong to other owners and keep their current revocation: upload
previews (`EstateDetail.tsx:3504/3533`, `3739/3765/3775/3810/3821`), the inventory template (`6233/6238`, revoked
synchronously), the attachment `handOff` (`attachmentDelivery.ts:660/670`, 120 s, Task 9/13 policy), the chatbot export
(`botClient.ts:233/242`, 1 s) and jsPDF's internal `saveAs` inside the frozen PDF region (40 s, library-owned). Task 12
creates none, so the creation/revocation count for the preview is 0/0 and is asserted as such (R15).

## 7. Disclosures (prompt :64, prefs #12)

- **Browser abort is not server cancellation.** Nothing in `document.preview`'s call graph consumes the request abort
  signal, mysql2 has no abort API, and `buildPreviewSections` is synchronous. A cancelled preview still completes its
  queries, render and JSON stringify on the server; only the bytes are dropped at write time.
- The ceiling is enforced on **decoded** body bytes (the only bytes a fetch body stream exposes); the app server sends
  no `Content-Encoding` and no `Content-Length`, so decoded equals wire there. A platform proxy may compress; the B1
  probe records `encodedDataLength` versus decoded length per response so the distinction is measured, not assumed.
- The development debug collector (`client/public/__manus__/debug-collector.js`, injected only when
  `NODE_ENV !== "production"`) clones and reads full JSON bodies regardless of any app ceiling. The build gate produces a
  production build, and B6's preflight asserts that the fixture serves exactly that build with no collector tag (the
  fixture launcher itself runs with `NODE_ENV=development`, `fixture/start-ui.cjs`, and `vite.config.ts:99-115` injects
  the collector unless the build ran in production); dev/Preview-environment exposure remains the recorded open item.
- Memory and GC figures are estimates; the probe measures envelope bytes, not heap.
- Fixture evidence is MySQL 8.4.11 on one workstation and Chromium only; mobile/native browsers, Word parity and pixel
  checks remain user-deferred-not-passed.
- The client stops waiting for headers after the transport's 10 s timer × 3 attempts and for a body after the new
  body timers; neither bounds anything on the server, which keeps computing after a client abort or timeout. Every elapsed-time figure in the
  Budgets table is a nominal worst-case estimate built from verified defaults, not a typical preview time and not a
  server-compute limit.
- The Express rate limiter's 429 body (`{ error: "Too many requests…" }`, `server/_core/index.ts:167-176`) is not a
  tRPC envelope: today it shows tRPC's raw "Unable to transform response from server"; under P3 it shows the neutral
  sentence. Un-batching adds at most one request per preview open against a 200/min/IP budget.
- Offline (fixed in r4 at Nick's request): with the default `networkMode: "online"` React Query pauses before the
  queryFn runs, the signal is never consumed, a close only calls `cancelRetry()`, and `pause().then(run)`
  (`retryer.js:117-122`) still runs the request on reconnect into a key with no observer, whose result a same-input
  reopen within gcTime would reuse. `networkMode: "offlineFirst"` on the preview query makes the first attempt run at
  once (`canFetch`, `retryer.js:9-11`), so the signal is consumed and a close is a real revert-cancel; the only visible
  difference offline is that the first attempt fails immediately and the transport's two retries run before React Query
  pauses for reconnect, while today's paused state already shows the fallback text (R18). Nothing changes server-side.
- The B1 probe is fixture-only but not write-free (P12); its receipt lists the expected fictional writes.
- The P17 reopen can fire one wasted request built from the previous drafts before the reset effect re-keys the query
  (effect order: the reset effect at 7399 runs before `useBaseQuery`'s `setOptions` effect). That is pre-existing; with
  abort on, the superseded request is now cancelled. A real React Query test records the observed sequence (R6).
- Close shows the fallback props ("P1 — ", fallback text or cached P1 sections) for the ~200 ms dialog fade-out
  (pre-existing, INFERRED from `dialog.tsx:130`; not browser-verified). Not changed.

## 8. Retained open evidence (not resolved here)

Word/pixels user-deferred-not-passed; unverified Safari/iOS/Android WebView; Task 15 browser gap; Task 6/14 limits;
Dev/Preview delivery-body redaction and the runtime `message` listener before real client data; Task 10 F1
filename/header issue; the Task 13 preview-path microtask gap (P9); `previewStoredFile`'s `noopener` return-value quirk (pre-existing, out of scope).

## 9. Verification (after Gate B approval)

**Vocabulary:** *observed* (a real React Query/tRPC/stream run), *estimate* (static arithmetic), *injected fault*
(the task-owned preview-only delay/chunk adapter or a test stub), *native* (the untouched fixture path). Every table in
`final-status.md` labels each row with one of these.

**B0 — preconditions** (stop and ask on any failure): branch/HEAD/index; porcelain 78/75 plus Task 12's own files;
every fingerprint above re-hashed in full; `ListAgents` shows no busy peer and Task 11's files are stable; no listener
on 43117/43316; create `task12/claude-pass01/` with `before/` byte copies of the edit targets and protected files,
`before-hashes.sha256`, a Node EOL census, `prior-work.diff` (names only in the receipt), and `frozen-regions-before.json`
(raw CRLF hashes of the table above, computed in Node from the `before/` copy). Also a **golden capture from the
current source before any edit** (the Task 11 B1 model): the markup-block DOM, the `renderPrintDocument` HTML and the
mocked-jsPDF call log for the 26 `render-baseline/*.preview.json` fixtures plus two task-owned letterhead fixtures
(image and DOCX, under `task12/claude-pass01/qa/`, never in `render-baseline/`), rendered with the existing static-mock
pattern (`preflight.test.tsx:195-207`) through a `run-qa-vitest.cjs` copy (`task11/claude-pass01/qa/run-qa-vitest.cjs`:
serial, scrubbed env, fixed clock) and serialized to `task12/claude-pass01/golden/`.

**B1 — measurement probe (P12 approved; executed after B5, because the pass1 production build it measures is produced
by B5's `build` gate):** start the owned MySQL fixture (`--resume-owned-fixture`) and a Task-12-owned UI server copy
serving that build, with the served `index.html`, bundle and UI-server source hashes recorded in the receipt; the
preview is by then a single un-batched GET and every captured body is exactly one envelope (pre-edit, the capture would
be a batch array holding co-issued queries too); through the real modal with CDP network capture, open P1, P2, P3
long-form, P10 and P11 with the long-form fixture, LETTER with image letterhead and with DOCX letterhead, P17, and a
Unicode-heavy estate; record per response `Buffer.byteLength(body, "utf8")` of `Network.getResponseBody` (decoding
`base64Encoded` bodies; a JS string length would undercount UTF-16 surrogates), the per-request sums of
`Network.dataReceived` `dataLength` (decoded) versus `encodedDataLength` (wire) for the compression check, status,
content-type and timing; stop the fixture. Receipt under `probe/`. If any measured envelope exceeds 25 % of the
provisional 4 MiB, stop and report with evidence before any ceiling change (Nick: 8 MiB only with evidence). The
receipt also lists the expected fictional writes (the fixture user's `lastSignedIn`, any session rotation, fixture
status files) and asserts zero new `documents`/audit rows for the owned estate. A ceiling change after the probe is a
one-constant edit followed by B5 again under a new label.

**B2a — pure refactor first (no behaviour change).** Create `client/src/lib/trpcLinks.ts` as a verbatim move of
`main.tsx`'s batch-only link construction (one `httpBatchLink`, the same `headers()` wrapper and comment, the same
transport and rotation handler, no preview routing yet) and wire `main.tsx` to it; run the six named existing suites
plus `check` under a fresh label (`claude-task12-refactor1`) with the CRLF census. Nothing new is tested yet; this step
exists so the red tests can import the real factory instead of failing at import.

**B2b — red.** Add the three new test files and the T1–T3 cases in `trpcTransport.test.ts`. The lifecycle suite imports
the B2a factory and renders the current modal, so R1, R3, R3b, R5, R8, R9, R11, R12, R18, R19, R20 and R21 fail **behaviourally** (no
cancellation, crashes or fallback text on malformed payloads, controls left usable on a failed refetch, raw messages,
retries, offline resumption) and are the reds that matter; T1–T3 fail behaviourally against the current `wait`.
`previewTransport.test.ts` fails at import until B3 and is recorded as *red by construction*, proven afterwards by green
plus the B4a mutants. Run through `run-gates.cjs claude-task12-red1 focus --test-file=…` (expect exit 1) and record
per-test failures. Guard-only cases (R7, R10, R12–R16, L4, U4, U12) are labelled *guard*; R6 is labelled *observed*.

Unit — `client/src/lib/previewTransport.test.ts` (real `ReadableStream` bodies via `chunkedStream`/`stalledStream`,
fake timers where timers matter, `Array.from` byte comparison):
- U1 ceiling −1 / at / +1 as decoded bytes, with the boundary chunk split inside a 4-byte UTF-8 sequence; the reader
  stops reading at the first chunk that crosses the limit (pull count asserted with `highWaterMark: 0`); the streaming
  decoder reassembles the split sequence, so the −1 and at cases round-trip the astral character exactly.
- U2 headers are ignored: Content-Length absent, non-numeric, overstated, understated or over the limit, with and without
  `content-encoding: gzip`, all give the outcome the body's decoded byte count alone dictates (accepted under the limit,
  `too-large` over it); a 2xx with `content-type: text/html` is refused with reason `not-json` after zero reads.
- U3 refusal bodies: status 400/500 JSON under and over 16 KiB; the under case reaches tRPC unchanged. U3a a realistic
  `BAD_REQUEST` envelope with `data.zodError` for the preview input stays under the 16 KiB bound and its public sentence
  shows verbatim, never the neutral one.
- U4 status 204 and a `null` body pass through unchanged.
- U5 abort before the wrapper runs, during the first read, between chunks; the stream's `onCancel` fires exactly once,
  `stream.locked` reflects the cancelled reader, `vi.getTimerCount()` is 0, and the thrown error is the signal's reason
  (never a `PreviewTransportError`).
- U6 idle timeout with a stalled stream and total timeout with a trickle; both cancel the reader and clear all timers.
  U6a a stream that never yields its first chunk (`stalledStream` after headers) is cut by the 15 s idle timer, proving
  it is armed before the first read.
- U7 stream error mid-body → `incomplete`; the rebuilt `Response` is never produced.
- U8 success: the rebuilt `Response` carries only the status and `content-type` and a byte-identical body; Unicode
  (astral, combining, NBSP) round-trips exactly through `res.json()` and SuperJSON, and U8/U12 call `res.json()` inside
  the jsdom environment, not only under Node.
- U9 `previewErrorMessage`: a `TRPCClientError` with `data` → its message; without `data` → the neutral sentence.
  `previewRetry`: any error without `data` → false at count 0; errors with `data` → true below 3, false at 3. (The
  inline shape guard has no unit of its own; R3b covers it in the modal.)
- U10 abort after the inner fetch resolved but before the wrapper's first read: the body is cancelled (`chunkedStream`
  `onCancel` fires once) and the wrapper rejects with the abort reason, never returning a `Response`.
- U11 abort or timeout while a `read()` is pending whose stream then reports `done`: the stop outranks `done`, so the
  wrapper rejects instead of handing tRPC a truncated body.
- U12 the rebuilt `Response` carries only `status` and `content-type`; a synthetic transport 503 (string body, no
  Content-Length) passes through intact and parses as the same envelope.
- U13 session guard (P8): `clearFallbackSession()` between the inner fetch's return and the first read → the body is
  cancelled (`onCancel` once), no `Response`, the rejection is a `PreviewTransportError` with reason `session-ended`;
  the same bump between two chunks → reader cancelled, bytes dropped; a rotated token written to `sessionStorage`
  between chunks (what `main.tsx`'s `onResponse` does on `X-Rotated-Session`) → accepted and the `Response` rebuilt
  byte-identical; the error object has only `reason` and `message` (no `cause`, headers or bytes).
- U14 `validatePreviewPayload`: returns the same object reference for every valid payload (empty `sections`, empty
  `text`, empty `rows`, missing optional fields, unknown extra fields); throws `PreviewPayloadError` (no `data`, the
  neutral message) for a non-object, a non-array `sections`, a `null` or non-object element, an unknown `type`, a
  non-string `text`/`imageUrl`/`deliveryMethod`, a non-array `recipientLines` or a non-string line, a non-array `rows`,
  a row without an array `cells`, a non-string cell, a non-array or non-numeric `colSpans`, a `cellAligns` entry
  outside the three literals, a non-boolean value in any optional boolean field (`1`, `"true"` and `null` rejected;
  absent, `true` and `false` pass), or an `align` outside its three literals; it never mutates, coerces or normalises
  (asserted on a deep-frozen fixture).
- U15 `previewQueryKeyHash`: equals `hashKey([key, generation])`; two generations give different hashes for the same
  key; a rotated token does not change it.

Transport — `client/src/lib/trpcTransport.test.ts` (CRLF; P5):
- T1 a 503 HTML response, then an abort during the 1.5 s backoff (fake timers, not advanced): the call rejects at once
  with the signal's reason, `fetchImpl` was called exactly once, `vi.getTimerCount()` is 0 afterwards.
- T2 a thrown network error, then an abort during the backoff (the `catch`-path wait): the same assertions.
- T3 a signal already aborted when the backoff starts: immediate rejection, no second `fetchImpl` call; the existing
  non-aborted retry cases keep their recorded timings and are the regression.
- T4 (P5b) a discarded non-JSON 503 body: its stream's `onCancel` fires exactly once per discarded attempt, before the
  retry wait and before the synthetic envelope is returned; a JSON response's body is never touched.

Links — `client/src/lib/trpcLinks.test.ts` (real `createTRPCClient` with the factory and a recording fetch stub):
- L1 `document.preview` query → exactly one GET on the preview branch, URL without `batch=1`, input in `input=`,
  `Authorization` from `fallbackAuthorizationHeader` when a token is stored and absent when not; no token in the URL.
  The recorded `input=` is decoded with `superjson.deserialize(JSON.parse(decodeURIComponent(param)))` before asserting.
- L1a a Bearer token rotated (stored) between two preview requests is carried by the second request's `Authorization`;
  cookie mode sends none (per-request `headers()`).
- L2 two other queries issued in one tick and a mutation never pass through the bounded reader (the stub records which
  fetch received each request); the batch URL and POST shape themselves are library behaviour and are not asserted.
- L3 a preview issued in the same tick as another query → two requests; aborting the preview's signal aborts only the
  preview request; the other resolves.
- L4 `X-Rotated-Session` on a preview response and on a batch response: with P1a the `sessionStorage` write is
  asserted for both; otherwise the same `onResponse` is asserted to be invoked for both.
- L4a (folded into L3 on review: library plumbing) the preview request's `init.signal` is the operation's own signal,
  asserted only through the abort in L3.
- L5 a bounded-reader refusal on the preview leaves a concurrent batch untouched and resolves it.
- L6 (P5 approved) caller abort during the transport backoff through the real links: no further `fetchImpl` call; the
  rejection is the abort reason.
- L7 the validation link: a malformed preview envelope rejects the query promise with a `TRPCClientError` whose message
  is the neutral sentence and whose `data` is `undefined`, before any React Query cache write; a valid envelope
  resolves with the same object reference; the link never sees non-preview operations (they take the batch branch).

Lifecycle — `client/src/pages/EstateDetail.preview-lifecycle.test.tsx` (the **real** `trpc` proxy from
`client/src/lib/trpc.ts` with its type-only `AppRouter` import, a real `QueryClient` created per test, real
`trpc.Provider`/`QueryClientProvider` as in `main.tsx:70-76`, links from
`createAppTrpcLinks({ fetchImpl: stub, retryDelayMs: () => 0 })` where the stub is asserted to have been called so a
forgotten stub can never fall through to real fetch; the stub serves a fictional mini-router
(`initTRPC.create({ transformer: superjson })` with `document.preview` and `settings.get`) through
`@trpc/server/adapters/fetch`'s `fetchRequestHandler`, so single, batch and `TRPCError` envelopes are exact without
importing `server/routers.ts`, re-streamed through `chunkedStream`/`stalledStream` for the streaming cases; `sonner`
mocked and `(globalThis as any).React = React` as in `task13-recovery.test.tsx:13-14`,
`vi.setConfig({ testTimeout: 45000 })`, the `hasPointerCapture`/`scrollIntoView` shims. **Timers:** real timers by
default with a test-only `QueryClient` `defaultOptions.queries.retryDelay: 0` (the retry count stays default, so
`previewRetry` is what is observed) and the transport's `retryDelayMs: () => 0` through the factory; cases that need a
window to abort in (R11, R17, T1–T3, U6) use `vi.useFakeTimers({ shouldAdvanceTime: true })` with `vi.waitFor` and
`advanceTimersByTimeAsync`, `sessionStorage` set before the fake timers, and an `advanceTimersByTimeAsync(0)` after each
batch-link issue so the batch dispatches):
- R1 slow A then fast B: B's sections render; A's late success never replaces them; A's late error never shows the
  Alert; the loading state belongs to B only.
- R2 the stub ignores abort: the same guarantees hold (late A result dropped by the retryer; no console error, no
  redirect spy call).
- R3 close during headers / during body (a close during parse is not claimed: `res.json()` on an in-memory body settles
  in microtasks and is unobservable); `fetchImpl`'s signal is aborted; the reader is cancelled; reopen
  with the same input (including plain P1 with no ids) starts a fresh request (second `fetchImpl` call), shows
  `isLoading` on the first reopen render and renders; a same-key reopen within gcTime with data shows the cached
  sections at once and refetches, and closing during that refetch leaves the cached data in place (revert).
- R3c closed for longer than gcTime (fake timers, > 5 min), then reopened with the same input: exactly one fresh
  `fetchImpl` call, no throw, no act warning (the unsubscribed observer re-attaches to a query the GC removed and
  `setOptions` rebuilds it, `queryObserver.js:48-58,84-119`).
- R3d a window-focus event while closed triggers no fetch and no act warning (the observer is off the query's list).
- R3a a replica of `main.tsx`'s cache subscriber (subscribe to `queryClient.getQueryCache()`, spy `console.error`)
  records zero `error` actions for every cancelled key and exactly one for a ceiling refusal; the login-redirect
  predicate (`'Please login (10001)'`) is never satisfied by a cancellation.
- R3b payload validation in the modal: `{ sections: [] }` with no formCode still renders the `preview-download-docx`
  control (a legitimate empty draft); each malformed shape — `sections: "x"`, `sections: [null]`, a section with
  `type: "bogus"`, `text: {}`, `recipientLines: "x"`, `rows: [{ cells: "x" }]`, `rows: [{ cells: [{}] }]`,
  `colSpans: "2"` — renders the frozen Alert with the neutral sentence and a working Retry, never the fallback text and
  never a thrown render; after Retry answers with a valid payload the sections render; blank strings, empty rows and
  missing optional fields render as today. After a first-load rejection the key holds no data (`getQueryData` is
  `undefined`): the malformed payload is never cached.
- R4 unmount during headers and during body: abort, no state writes, no act warnings.
- R5 each render input changed while pending: P17 city and province keystrokes, selected contact, deponent, ordinal,
  signing date, consent object, per-document override, generateAnyway; each cancels the previous request and sends the
  new exact input (asserted from the recorded URL), never resetting the user's choice.
- R6 P17 reopen sequence: records whether the pre-reset request fires; if it does, it is cancelled (observed, labelled).
- R7 co-issued sibling query (a wrapper component calling `trpc.settings.get.useQuery`) in the same tick: the preview's
  cancel and the preview's cap refusal leave it resolved with its data (the Task 13 suites already pin
  `document.generate`, so its half of r1's R7 was dropped on review).
- R8 ceiling refusal: the Alert shows the neutral sentence, `fetchImpl` is called exactly once (no RQ retry); Retry
  preview sends a new request; a server BAD_REQUEST envelope still shows its public sentence verbatim and is retried per
  default.
- R8a close while a Retry-after-refusal fetch is in flight: the revert restores the previous error state silently
  (`query.js:241,250-253`), no second `[API Query Error]` line, no Alert flash on the closed render, and the reopen
  refetches via `retryOnMount`.
- R8b a `fetchImpl` that rejects with a network `TypeError` on all three transport attempts: the transport returns its
  synthetic 503 envelope (with `data`), React Query retries it per default, and the Alert shows the transport sentence
  verbatim, proving P4 does not make network failures terminal.
- R9 truncated JSON, non-JSON 200 (`text/html`), non-tRPC JSON (`{error:"…"}`), wrong MIME with valid JSON: neutral
  sentence; no raw engine or library text in the DOM. The non-JSON 200 case also asserts zero body reads (the `not-json`
  pre-refusal); the others assert reads ≤ the ceiling, so the download cost of every refusal is pinned.
- R10 valid empty `sections: []` renders the frozen fallback path exactly as today (no sections → "Unable to load
  preview." is **not** shown; an empty array is sections).
- R11 abort before request (closed before dispatch), during RQ backoff after a transport 503, after completion: no
  second request after the abort; a later fresh request succeeds. A close during the React Query backoff after a server
  error additionally asserts zero further `fetchImpl` calls and zero `error` actions (the consumed flag stays set
  through the sleep, `query.js:217`; the retryer returns on its resolved thenable, `retryer.js:98-103`). The
  transport-backoff abort is T1–T3 and L6.
- R12 cookie mode (no stored token) sends no `Authorization`; Bearer mode sends it on the preview link; logout
  (`clearFallbackSession()` then unmount) aborts the in-flight preview and shows nothing; logout while the body is
  streaming and the modal stays mounted (P8) → no section of the old session is rendered or cached, no toast, the Alert
  shows only the neutral sentence, and a rotated token mid-body changes nothing.
- R13 cancelled preview never calls `document.generate` (mutation stub asserts zero calls).
- R14 the four frozen behaviours are observed unchanged on the same fixture sections: P11 two official signature lines,
  merged multiline rows in modal/print/PDF (reusing the exact assertions of `preflight.test.tsx:727-825` against the
  real-provider render), Edit address and zoom controls, and the DOCX button still calls `fetchDeliveryAttachment`
  **without a signal** (spy asserts `signal === undefined`).
- R15 Object URL: `URL.createObjectURL`/`revokeObjectURL` spies record 0/0 for every preview path in this file.
- R16 existing `EstateDetail.task13-recovery.test.tsx:1076-1098` ("closing the preview mid-download drops its result")
  and the other five named suites run unchanged in the focused run.
- R17 hung server (fake timers): a `fetchImpl` that never answers → 3 transport attempts × 4 React Query attempts = 12
  `fetchImpl` calls and the transport's timeout sentence in the Alert at ≈145 s, which turns the Budgets row from
  computed into observed.
- R18 offline (`onlineManager.setOnline(false)` before opening): (a) the first attempt runs and `fetchImpl` rejects
  with a network `TypeError`, the transport's two retries follow (zeroed waits), the synthetic 503 arrives and React
  Query pauses in its retry sleep (`fetchStatus: "paused"`); close → revert cancel; `setOnline(true)` → zero further
  `fetchImpl` calls; a same-input reopen → exactly one fresh request; (b) a preview still open when the tab is back
  online **and focused** (`onlineManager.setOnline(true)` plus `focusManager.setFocused(true)`) resumes and renders,
  and stays paused while online but unfocused; (c) a sibling `settings.get` query paused offline resumes on the same
  condition after the preview's close (other observers' requests preserved); (d) with the default `networkMode` (the
  B4a mutant) the closed preview resumes on reconnect and the reopen reuses it, which is the red that justifies the
  option; (e) a second observer on the same key (a wrapper with an identical `useQuery`) keeps the query alive when the
  modal closes: the revert-cancel fires only when the last observer of that exact key and generation leaves.
- R19 session end with cached data: a loaded preview, then `clearFallbackSession()`, then a re-render and a reopen with
  the same input → the observer moves to a new hash, a fresh request is sent, the old entry's sections are never
  rendered; a rotated token instead → the same hash, cached sections shown, background refetch as today.
- R20 cache correctness and gating: a valid preview renders with the preview-dependent controls visible; a same-key
  refetch (Retry, or a focus refetch) answered with a malformed payload → the query is in `error`, the cache still
  holds the earlier valid payload and never the malformed one (`getQueryData` deep-equals the first response), the
  modal's gated `data` is `undefined`, so DOCX/PDF/Print/zoom/Edit-address are hidden and the frozen Alert shows the
  neutral sentence; Retry answered with a valid payload → the controls return and the sections render.
- R21 refusal after valid cached data: the same sequence with an oversize (ceiling) refetch → terminal refusal, cache
  unchanged, controls hidden, Alert with the neutral sentence; a server `BAD_REQUEST` refetch behaves the same with its
  public sentence; a valid Retry restores both.

**B3 — green.** Implement §5 in this order: `previewTransport.ts`, the preview branch in `trpcLinks.ts` (the B2a
factory gains the `splitLink` and `httpLink`), `EstateDetail.tsx` (Node byte-exact edits; CRLF census after each), then
`trpcTransport.ts` (P5 and P5b). Re-run the focused files until green.

**B4 — frozen-region proof.** `qa/frozen-regions-task12.cjs`: reads `before/` and the current file as raw bytes in Node,
checks that each region in the table occurs exactly once with the pinned raw hash, that the file is still uniform CRLF
with no lone CR, that `printDocument.ts` and import line 58 are unchanged, and that every GNU `diff` hunk lies inside the
approved edit map (imports, 7424-7427, 7793). Then re-runs the B0 golden capture against the edited source (same QA-only vitest config through the
`run-qa-vitest.cjs` copy: serial, scrubbed env, fixed clock, the `Math.random` skeleton excluded) and diffs the
markup-block DOM, the `renderPrintDocument` HTML and the mocked-jsPDF call log for the 26 + 2 fixtures byte for byte.
The `before/` copy is hashed, never imported: its nine `../../../shared/*` imports (`EstateDetail.tsx:34-57`) cannot
resolve from the mirrored tree. Byte identity of frozen code plus identical golden output is the proof; no snapshot is
created or accepted. Post-edit line numbers (every region after the inserted import shifts by +1) are recorded in
`final-status.md`; the hash check is content-based, so it is unaffected.

**B4a — mutants (QA-only, never left in the tree).** Each applied alone to a scratch copy, run through the focused files
and killed by a named test: drop `subscribed: open` (R3); drop `trpc.abortOnUnmount` (R3/R4); `>` → `>=` at the ceiling
(U1); remove the `if (stop)` precedence after `read()` (U11); invert `error.data ?` in `previewErrorMessage` (R8/R9);
make `previewRetry` return true for data-less errors (R8); make the `splitLink` condition always false (R7/L1); make
`wait` ignore its signal (T1); remove `networkMode` (R18d); let the validator accept a `null` element (U14/R3b/R20);
coerce a string flag to boolean in the validator (U14); remove the `isError` gate on `data` (R20/R21); make
`previewQueryKeyHash` ignore the generation (R19); remove P5b's body cancel (T4). Receipt under `qa/mutants/`.

**B5 — focused and full gates.** `run-gates.cjs claude-task12-focus1 focus --test-file=<the three new files and the six
named existing files>`; then, against stable final bytes,
`& 'C:\Program Files\nodejs\node.exe' '.work\hybrid-remediation\run-gates.cjs' claude-task12-pass1 check tests chatbot-check chatbot-tests build render`
in the background (~16 min), reading `results.json` and every exit code, never `tail`. A new label for every rerun;
no snapshot acceptance, no skipped failing regression, no `server/storage.live-uat.test.ts`. A QA-only tsconfig
type-checks the new tests (the root `check` gate excludes tests).

**B6 — real UI** (only the owned fictional fixture): ownership preflight (`ownership-*.cjs` pattern: 43316 listener PID
equals `mysql.pid`, served `index.html` hash equals disk, `/__fixture/health` source hashes equal the final bytes; the served `dist/public/index.html` hash equals the pass1
`build` gate's output and contains no `/__manus__/debug-collector.js` tag, because `fixture/start-ui.cjs` runs the UI
copy with `NODE_ENV=development`; the fault adapter is registered in the UI copy's `sourceHashes`, matches exactly
`req.path === "/api/trpc/document.preview"` and wraps `res.write`/`res.end` to hold or chunk); the
Task-12-owned UI server copy serves the pass1 production build with the labelled preview-only delay/chunk fault
adapter (holds and slow-chunks only `document.preview` responses for run-owned estates; never DB or audit resources).
Scenarios S1–S8: slow preview then Escape then reopen (network shows the first request aborted and the second
completing); A→B selection while A is held; ceiling refusal (adapter pads a fictional body past the ceiling) then Retry;
incomplete draft with Generate anyway still previews; zoom/fullscreen/P17 edit (each keystroke supersedes the previous
request); print and PDF controls unchanged; DOCX download from the preview then Escape mid-download (file still handed
off, no toast — Task 13 parity); a co-batched tab query keeps working during a held preview. Evidence: CDP network
records with per-response byte counts, screenshots, the audit table correlated for the generated downloads only (the
read-only preview must create no `documents`/audit row — asserted by row counts before/after).

**B7 — independent review.** Read-only reviewers over the complete Task-12-only delta and new files (code, security,
silent-failure, probate-integrity lens pointed at this worktree), findings ranked by severity; in-scope fixes repeat
B3–B5 under fresh labels.

**B8 — handoff.** Branch/HEAD/index and names-only status; task-only inventory and diff; preserved predecessor hashes;
the exact request/byte/time/cache/batch/auth contracts as implemented; red/green and full gate results tied to final
hashes; frozen-region and output-identity receipts; real-UI records; the probe receipt; findings by severity; remaining
limitations; acceptance-needed status. Append Task 12's own evidence entry to the queue only as authorized; accept
nothing; **stop and wait for Nick.**

## 10. Rejected alternatives (recorded, not chosen)

- A global `abortOnUnmount` (Provider or `createTRPCReact`) or QueryClient `defaultOptions`: changes every query.
- A byte ceiling inside `createTrpcTransportFetch`: applies to every operation and gets ceiling refusals retried.
- A second tRPC client/provider or a raw `useQuery` with `client.document.preview.query`: prompt :52 and the stub
  suites (`useQueryClient` throws without a provider).
- `httpBatchStreamLink`: still all-ops abort and an unbounded error body.
- Server-side size caps or abort handling in `document.preview`: new server behaviour in a protected, MIXED-EOL file.
- `methodOverride: "POST"` to keep overrides out of the URL: global link and server change.
- Mounting the query only while open (inner component): moves the frozen regions.
- Debouncing P17 or resetting drafts to force a key: changes user inputs.
- A token-equality session guard for the preview (the download path's `sameSession()`, `attachmentDelivery.ts:81-83`):
  it would self-cancel on a legitimate rotation; the generation-only guard was chosen (P8).
- `networkMode: "always"` for the offline fix: never pauses, so offline retries burn through to an error instead of
  waiting for reconnect; `offlineFirst` keeps the wait and still consumes the signal on the first attempt.
- `useUtils().document.preview.cancel()` on close for the offline case: needs provider or mock extensions in the four
  stub suites, and the paused retryer is the real problem, which the network mode removes.

## 11. Decision record (Nick, 2026-10-26, verbatim)

Received while the rerun design reviews were in flight; recorded unedited, then mapped onto the P-rows above.

> I choose P1’s tested link factory and P1a’s unchanged rotation-handler move. For P2, use 4 MiB provisionally, 16 KiB
> refusals, 15 s body idle and 60 s body total, subject to the approved P12 bounded fictional probe. Return with evidence
> if 8 MiB is needed; never truncate.
>
> Keep P2a’s existing header/retry settings initially and document the combined retry/elapsed-time budget. Approve P3’s
> neutral copy, preserving only existing safe public server messages. Approve P4 with cancellation/client failures
> terminal, and P5’s minimal abort-aware wait with cleanup/no-further-attempt tests. Choose P6’s subscribed flag.
>
> Approve P7/P9/P10/P11 with the preservation conditions above. Do not treat P8 as blanket approval: specify how
> logout/account-change results are suppressed using existing identity without breaking legitimate rotation.
>
> “Keep as is” decisions
> P7 — Cache defaults: approve, provided stale completions cannot populate a reopened/different preview or overwrite
> another observer’s state.
> P8 — No session guard: do not approve unconditionally. Require suppression of results from a previous
> logged-out/account-changed session using existing auth/session identity. Normal token rotation must remain valid. No
> new authentication system.
> P9 — Task 13 residuals: approve keeping them out of scope.
> P10 — Hidden controls on refusal: approve for unavailable preview-dependent controls. Keep visible retry/recovery, and
> do not disable the main Generate/Generate anyway paths.
> P11 — Console trail unchanged: approve leaving existing global logging outside this task. No new logs or sensitive
> preview/token/header/raw-error data attached to new failures. This does not clear existing logging concerns.
>
> Record these decisions and return the revised plan. Preserve all court wording, formatting, rendering, legal logic and
> existing download behavior. Do not start Gate B yet.

**Mapping.** P1 factory; P1a handler moved, behaviour unchanged. P2 4 MiB / 16 KiB / 15 s / 60 s provisional, never
truncate, 8 MiB only with probe evidence; P2a settings kept, combined budget documented (Budgets table). P3 neutral
copy, server messages limited to the existing public ones (already guaranteed by the Task 14 formatter). P4 client-side
and cancellation failures terminal. P5 **alternative chosen**: abort-aware wait plus T1–T3 and L6. P6 `subscribed`.
P7 approved with its condition (R1–R3, R7). P8 **conditional → generation-only guard specified** (§2 steps 1, 1a, 6;
U13; R12). P9 approved. P10 approved with Retry visible and the Generate paths untouched. P11 approved with the
error-content rule. P12 probe approved. Court wording, formatting, rendering, legal logic and the existing download
behaviour stay as the frozen regions and the Task 13 contract require. Gate B: **not started** (explicit).

## 12. Review dispositions (2026-10-26)

Three read-only Plan-agent reviews of this plan: adversarial-correctness (first run, folded into r1), minimal-change
and verification-strategy (rerun `wf_633ce9e4-d65`, 22 minutes, both `sound-with-changes`). Each finding below was
checked against the cited slice or by computation before it was accepted; "flag" means Nick decides.

**Minimal-change lens** — D1 factory vs inline: **not applied, flag** (Nick chose the factory; dissent recorded in P1).
D2 P1a move: **not applied, flag** (Nick chose the move; the location wording of the preservation list is the
reviewer's strongest point). D3 Content-Length pre-gate and identity-mismatch rule: **accepted**, both removed (§2
step 5; U2 rewritten). D4 U8 wording: **accepted**. D5 two abort contracts: **accepted**, one rule (signal reason
rethrown; `cancelled` removed from the reason list). D6 budgets row wording: **accepted**. D7 type-predicate /
unnecessary helper: **accepted**, inline one-liner, `isPreviewPayload` and U9's guard cases dropped. D8 test-only
exports: **accepted**, `isPreviewTransportError` and `PREVIEW_PROCEDURE_PATH` dropped. I1 text rebuild: **accepted**
(§2 steps 6–7). I2 non-JSON 2xx pre-refusal: **accepted, flag** (new reason `not-json`, same sentence, zero bytes).
I3 one timer instead of two: **rejected** (Nick fixed both timers in P2). I4 keep `headers()` wrapper and comment,
share `linkOptions`: **accepted** inside the factory. I5 trim R6/R7/R13: **partly accepted** (R7's generate half
dropped; R6 kept as observed; R13 kept because the prompt names it). I6 hung-server case: **accepted** (R17). I7
post-edit line numbers: **accepted** (B4). I8 no `@/lib/trpc`/hook imports in `previewTransport.ts`: **accepted**
(§5). N1–N2: flag (above). N3 simpler reader: accepted, flag. N4 probe as precondition: Nick already decided
(provisional 4 MiB, probe approved). N5 non-JSON pre-refusal: accepted, flag. N6 timers: Nick decided. G1 gcTime
reopen: **accepted** (R3c). G2 close during Retry: **accepted** (R8a). G3 cross-realm rebuild: resolved by I1, U8/U12
run in jsdom. G4 focus while closed: **accepted** (R3d). G5 = I6. G6 non-JSON byte cost: **accepted** (R9). G7
replica drift: moot with the factory.

**Verification lens** — D1 red-first impossible for new modules (high): **accepted**, B2 split into B2a pure refactor
and B2b red, with "red by construction" labelled. D2 before-copy render cannot import (high; the nine
`../../../shared/*` imports verified at `EstateDetail.tsx:34-57`): **accepted**, golden capture at B0 (Task 11 model).
D3 frozen table pins the edited region: **accepted**, 7782-7796 split into 7782-7792 and 7794-7796 with raw hashes
computed today. D4 no timer policy: **accepted** (lifecycle preamble; `retryDelayMs` forwarded by the factory), flag as
a verification choice. D5 P5 inconsistency: resolved by Nick's P5 approval (L6 unconditional, T1–T3; R11 wording
corrected). D6 probe counting (batched capture, UTF-16 lengths, header-inclusive wire size): **accepted**, B1 moved
after B3 with `Buffer.byteLength` and `Network.dataReceived` sums. D7 fixture serves a dev-launched build
(`vite.config.ts:99-115` verified): **accepted**, B6 preflight asserts the collector-free pass1 build; §7 corrected.
D8 CRLF edit mechanism assumed: **accepted**, Node byte-exact path primary (helpers verified under task06/task15), flag.
D9 B0–B11 / U8 / U5 inconsistencies: **accepted** (gates line, U8, U5 fixed). D10 no mutant step: **accepted** (B4a),
flag the mutant list. I1 real envelopes via `@trpc/server/adapters/fetch`: **accepted**. I2 superjson-decode recorded
URLs: **accepted** (L1, R5). I3 golden capture: = D2. I4 harness checklist: **accepted** (preamble). I5 cache-subscriber
replica: already R3a. I6 option plumbing note: **accepted** (§3). I7 generic guard signature: superseded by the inline
one-liner. I8 idle timer armed before the first read: **accepted** (§2 step 6, U6a). I9 fault adapter spec:
**accepted** (B6). N1 red strategy: (a) chosen, flag. N2 golden vs before-render: golden chosen, flag. N3 mutants:
added, flag. N4 timing policy: chosen, flag. N5 probe placement: post-B3, flag (fits "provisional"). N6 P5 framing:
moot (approved). N7 frozen split: done. N8 edit mechanism: Node primary, flag. N9 B6 preflight: added. G1: T1–T3/L6.
G2 network `TypeError` ×3: **accepted** (R8b). G3 first-byte stall: **accepted** (U6a). G4 per-request `headers()`:
**accepted** (L1a). G5 mutants: B4a. G6 close during RQ backoff: **accepted** (R11). G7 guard labels: **accepted**
(B2b). G8 "close during parse" unobservable: **accepted**, dropped from R3. G9 batch dispatch under fake timers:
covered by the timer policy. G10 zodError envelope under 16 KiB: **accepted** (U3a). G11 QA tsconfig type-check:
already in B5, now also covers the inline guard's narrowing.

**Items for Nick at exit (none blocks saving the plan):** P1 and P1a confirmed on 2026-10-27. Still his to
acknowledge: the simpler reader (no pre-gate) and the `not-json` pre-refusal; the four r4 mechanisms that answer his
revision requests — `networkMode: "offlineFirst"` (a per-query change in offline behaviour), the whole-payload
validator in the preview-branch link (malformed payloads reject before any cache write and show the Alert), the
`isError` gate on the modal's usable data, the generation-partitioned cache hash with P8's retained limitations
awaiting his explicit decision, and P5b's discarded-body cleanup in the shared transport — and the Gate B verification
choices (B2a refactor-first, golden capture, B4a mutant list, timer policy, post-B5 probe, Node edit path), which are
recommendations he may change before Gate B.

## 13. Nick's revision requests (2026-10-27, verbatim) and their mapping

> Keep my approved P1 factory and P1a mechanical rotation-handler move. Revise the plan before implementation:
> Fix offline cancellation. A preview paused before its query runs can survive closing, resume on reconnect and be
> reused on same-input reopen. Add tests covering those paths and preserve other observers' requests.
> Strengthen malformed-response validation. Checking only that sections is an array still admits null sections and
> malformed rows/cells that crash the preview. Reject malformed responses whole with the neutral message and Retry;
> preserve legitimate empty drafts and all legal content.
> Complete P8's session protection. Show how old-session results are suppressed through final acceptance and
> cached-data reuse, including account changes without breaking normal rotation. Flag unsupported cases rather than
> claiming coverage.
> Fix measurement sequencing. The probe cannot use the "pass1 build" before that build exists. Record exact artifact
> hashes and expected fictional authentication/context updates instead of calling the probe no-write.
> Address discarded preview response bodies. The outer reader cannot clean up original non-JSON error bodies discarded
> by the shared transport.
> Correct resource claims. The stated single-body retry path is approximately 205 seconds, not 195; other constructed
> retry paths can approach 385 seconds. These are nominal estimates—not normal preview times or server-compute limits.
> Network-byte measurements also do not prove a 12 MB memory bound.
> You MUST Preserve court wording, formatting, rendering, legal/selection logic, Generate anyway and existing
> downloads. Return the revised plan. Do not start Gate B or another task yet.

**Mapping.** P1/P1a: confirmed, dissent closed. Offline: `networkMode: "offlineFirst"` on the preview query (§3 code,
state-machine row, §7, R18a–d, mutant). Malformed responses: `validatePreviewPayload` as `select` with the exact
`PreviewSection` shape (§3 bullet, U14, R3b, mutant); legitimate empty drafts and every legal string pass untouched. P8:
three layers on the existing generation plus the named unsupported cases (P8 row, state-machine row, U15, R19,
mutant). Measurement: B1 moved after B5, artifact hashes and expected fictional writes recorded, "read-only"/"no-write"
wording removed (P12 row, B1, §7). Discarded bodies: P5b in the shared transport with T4 and a mutant. Resource claims:
budgets A/B/C corrected to 145 s / 205 s / 385 s and labelled nominal; the memory figure marked unproven (Budgets
table, §7). Preservation: the frozen regions, the Task 13 download contract, Generate anyway and the Forms-row paths are
untouched (§5, P10). Gate B: not started.

**Second round (2026-10-27, verbatim):**

> Keep the approved design and decisions. Before Gate B, make these bounded corrections:
> Move malformed-response validation out of select into the preview-only result path, after tRPC/SuperJSON
> transformation but before the query promise succeeds. Malformed data must never become a cache success.
> Gate usable modal data on a non-error/non-refusal result outside frozen markup. Add a valid preview → malformed
> same-key refetch → valid Retry test proving cache correctness and hidden preview-dependent controls. Also test refusal
> after valid cached data.
> Validate optional boolean fields as actual booleans. Preserve absent/true/false and legitimate empty drafts; reject
> malformed values without coercion.
> Qualify reconnect behavior as online and focused, and cancellation as final-observer behavior for the exact
> key/generation.
> Keep the session-generation partition, but do not mark P8 fully resolved. Clearly retain its next-render and
> unsupported identity-flow limitations for my explicit decision.
> Align the P5b cleanup/edit/test descriptions and remove stale resource claims. Preserve all court wording, formatting,
> rendering, legal/selection logic, Generate anyway and existing downloads.
> Return the small revised plan. Do not start Gate B, mark Task 12 done or start another task yet.

**Mapping (r5).** Validation moved from `select` into `previewValidationLink` on the preview branch, after the SuperJSON
output transform and before the promise resolves, so a malformed payload is never a cache success (§1, §3, §5, L7,
R3b). Usable modal data gated on `!isError` outside every frozen region (§3 code and bullet); R20 (valid → malformed
same-key refetch → valid Retry: cache correctness, hidden controls) and R21 (refusal after valid cached data) added,
with mutants. Optional booleans validated as `true`/`false`/absent without coercion, `align` as its literals (§3, U14,
mutant). Reconnect qualified as online **and** focused, cancellation as last-observer behaviour for the exact key and
generation (§3 offline row, R18b/e). P8 kept partial: partition retained, "resolved" wording removed, the next-render
and identity-flow limitations retained for Nick's explicit decision (P8 row, §12). P5b aligned across the P5 row, the
§5 edit map (lines 75-82), B3 and T4; the discarded-body item removed from §8; the "server compute bound" wording
replaced (§7). Court wording, rendering, legal/selection logic, Generate anyway and existing downloads untouched. Gate
B not started; Task 12 not marked done.

## 14. Decision record — Task 12 accepted/done by Nick's decision (2026-10-27 13:43 PDT (receipt), verbatim)

This appended record overrides the older status lines above ("Gate B is not approved", "Gate B not started", "Task 12
not marked done", and the P8 row's and the status block's "not marked resolved / open for Nick's explicit decision"
wording: decision 2 below resolves P8 for this task's closure). Gate B
ran on Nick's explicit "Start Gate B of Task 12 now" (2026-10-27) and ended with the handoff
`.work/hybrid-remediation/task12/claude-pass01/final-status.md`. Nick then decided:

> My decisions:
>
> 1. Acceptance: Accept Task 12 as done for task-list progress on the isolated review branch, with the explicitly recorded deferrals below. Record “Accepted by Nick with known limitations.” This is not a SHIP, deployment or production-security approval.
>
> 2. P8: I accept the implemented same-tab generation protection and next-render/reopen cache partition for this task’s closure. Do not claim immediate or comprehensive session protection. Keep the post-final-check window, cross-tab logout, server expiry/revocation and unsupported no-reload account-change cases open for review before live rollout.
>
> 3. Deferred minors and missing evidence: Leave the duplicate types/error classes alone. Retain the understated-header-plus-oversize test and real-handler mid-body rotation test as outstanding—not passed. Also retain the missing Unicode-heavy and image/DOCX-letterhead measurement cases, unmeasured heap use, mobile/WebView checks and deferred Word/pixels. The small measured envelopes do not prove headroom for those untested cases.
>
> 4. Queue and preferences: Append the drafted Task 12 queue entry, update its checkbox to done, and replace “NOT accepted” with my acceptance and its limitations. Record this decision/preference list in the repository’s handoff documentation. Preserve historical evidence and other task statuses.
>
> 5. Documentation: Correct the plan heading to its actual revision, r5. Keep the verification methods and their disclosed limitations as recorded. Do not change application code merely to tidy deferred minors.
>
> 6. Boundaries: Correctly skipped the external Agent Archive service—do not create an account. No court wording, formatting, rendering, legal/selection, schema, AWS or production changes. No staging, commits, pushes, checkpoints, publication or deployment.
>
> Return the updated disposition and stop. Do not start another task yet.

**Applied (documentation only):** the H1 above now reads r5 (decision 5); the queue row is checked and carries the
acceptance with its limitations, and the Task 12 evidence and user-disposition sections are appended to the queue
(decision 4); final-status.md §0 records this list verbatim with the P8 wording of decision 2 and the retained
outstanding items of decision 3; no application code changed (decision 5); nothing staged, committed, pushed,
checkpointed, published or deployed, no external account created (decision 6). Everything decided here is remediation
tracking, not a SHIP, deployment or production-security approval.
