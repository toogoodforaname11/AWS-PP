# Task 13 — r3 amendment: Nick's 2026-10-24 decisions (#14, #15, #16, m06). STOP for approval

> Plan mode allows writing only this file. This **amends** the approved plan r2. r2 is preserved byte-for-byte at
> `docs/superpowers/plans/2026-10-23-task13-truthful-delivery-feedback.md` (SHA-256 `ad82143e…a7a8`, unchanged).
> Everything in r2 stands unless replaced here.
>
> **Step 0 after approval:** copy this file byte-for-byte to `docs/superpowers/plans/2026-10-24-task13-r3-amendment.md`
> and record its hash before any other write.
>
> Task 13 only. It is not marked done, nothing is committed or staged, and no other task prompt is read. Every r2
> boundary still applies:
> - no court-document, legal, render or form-selection change, and no mutation-input change;
> - missing information is never a new hard block;
> - fictional loopback fixture only;
> - no AWS, production or `.env`.

## Context
Task 13 r2 is implemented, verified and claims-audited (`.work/hybrid-remediation/task13/claude-pass01/final-status.md`),
but **not accepted**. Its §10 escalated three design questions, and §6.15 a surviving mutant. Nick's answers
(AskUserQuestion, 2026-10-24):

| # | Nick's decision | Here |
|---|---|---|
| 14 | Feedback survives tab switches **within an estate**; leaving the estate still drops it | D11 |
| 15 | A same-user token rotation mid-download **still shows** the attempt's error | D12 |
| 16 | **Draft for approval:** exact review copy showing the retained choices, plus a guard against superseding a newer generation | D13 (exact copy) |
| m06 | Accepted as an equivalent surviving mutant | Recorded only |

**Correction to how I described #15 when asking.** Task 9 maps `session-changed` to the existing generic sentence
"The download could not be completed. Please try again." (`client/src/lib/attachmentDelivery.ts:60-61`). No new copy
is proposed.

## Facts (read-only, this session; corrected after the plan critique)
**Sessions**
- `generation` (`client/src/lib/fallbackSession.ts:12`) is bumped only by `clearFallbackSession()` (`:39-46`).
- Feedback currency today is `sameSession` = generation **and** token (`attachmentDelivery.ts:81-83, :217`).
- The transport's `sameSession` checks (`:434, :470, :500`, with the handoff running synchronously after `:500`)
  mean that after any token change no file can be handed off. The attempt ends `session-changed`, or with a
  network/timeout/redirect/invalid-response failure (`:463-469`).

**Tabs and owners** (`client/src/pages/EstateDetail.tsx`)
- The tab container is `AnimatedTabs` (`:578`). It is rendered without a key (`:303`), has no early returns, and its
  keyed `motion.div` (`:763-780`) remounts the tab content. Under `mode="wait"` the exiting element keeps the props it
  was rendered with.
- The tab owners are FormsTab `forms:` (`:8062`), DeliveriesCard `deliveries:` (`:10305`, rendered by FormsTab at
  `:9811`) and NotesTab `notes:` (`:11784`). The preview (`:7400`) and Home are unchanged.
- No test renders the whole page.
- TanStack v5 hook-level callbacks still fire after unmount, holding the last render's closures.

**What a generation sends and replaces**
- `generateMutation.onSuccess(data, variables)` (`:8151`) attaches the retained gate run (`:8201`). `variables` is
  the exact request sent.
- Affidavit deponents travel as `selectedContactId` (`:8695-8698`), P8/P17 as `deponentId`, and letters/consents as
  `targetBeneficiaryId`.
- The server forces the signatory for affidavits (`executor`), P34 (`citor`), P46 (`demandant`) and PGT forms
  (`server/routers.ts:4330-4338`). Only P1, P2 and P44 offer a signatory choice (`FORM_DETAILS`,
  `client/src/components/FormDetailsDialog.tsx:174-180`, already imported by EstateDetail at `:40`).
- The date prints unchanged (`renderSignatureDate`, `routers.ts:429-431`).
- Replacement (`server/documentReplacement.ts:18-35`):
  - a target-record form replaces that form for that target;
  - P9 replaces P9 for that deponent;
  - a primary affidavit (P3–P7) replaces any current primary affidavit;
  - every other form replaces the current document with the same form code.

**Review dialog** (`client/src/components/PreGenerateDialog.tsx`, CRLF, 2381 lines, one of the 35 reference files)
- Ready state: `Ready to ${actionWord} ${formName}` / "All required fields are present…" (`:2138, :2148`).
- Header notes go in `DialogHeader` (the P45 note, `:2153-2157`).
- `pgPendingRef` is set before `setPgOpen(true)` (`EstateDetail.tsx:8517-8520`), and the dialog already reads it at
  render (`:10109, :10112`).

## D11 — #14: the estate page owner, passed as a prop and namespaced per tab instance
`client/src/lib/attachmentDelivery.ts` (LF) adds:
```ts
/**
 * Task 13 r3: the estate page's owner when one is passed, so an attempt's feedback survives a tab switch. It is
 * namespaced per surface instance, so a remounted tab and its unmounted predecessor never replace each other's
 * attempts. With no page owner, this surface's own owner (r2: e.g. a tab rendered alone).
 */
export function useEstateFeedbackOwner(pageOwner: DeliveryFeedbackOwner | undefined, fallbackScopeKey: string): DeliveryFeedbackOwner {
  const own = useDeliveryFeedbackOwner(fallbackScopeKey, pageOwner === undefined);
  const instance = useId();
  return useMemo(() => (pageOwner
    ? { begin: (slot, options) => pageOwner.begin(`${instance}:${slot}`, options), retire: (slot) => pageOwner.retire(`${instance}:${slot}`) }
    : own), [pageOwner, own, instance]);
}
```

`EstateDetail.tsx`:
- `AnimatedTabs` adds `const estateFeedback = useDeliveryFeedbackOwner(`estate:${estateId}`);` and passes
  `feedbackOwner={estateFeedback}` to FormsTab and NotesTab in `tabContent` (`:654, :657`).
- FormsTab forwards the prop to DeliveriesCard (`:9811`).
- The three hooks become `useEstateFeedbackOwner(feedbackOwner, "forms:/deliveries:/notes:${estateId}")`.
- The comments at `:8060`, `:10304` and `attachmentDelivery.ts:179-183` are updated.

**Why a prop, not context** (critique #1). During an estate→estate exit animation the old tab keeps its frozen
props, so it holds the old owner. The estate change has already retired that owner, so the old tab's late results
stay silent (as in r2). A context value would have switched the exiting tab to the new estate's owner, and its late
results would have spoken on the new estate's page.

**Behaviour**
- **Tab switch:** the attempt continues under that tab instance's namespace, and its toast resolves on whatever tab
  is showing.
- **Behaviour change, disclosed and tested:** a generation that finishes after a tab switch is now announced. r2
  already started its download, but silently.
- **Returning to Forms:** this creates a new instance with its own namespace (critique #6).
- **Leaving the estate:** an unmount or a new `estateId` retires everything.
- **Unchanged:** the recovery panel is still per-mount state, so it is lost on a tab switch, and the old instance's
  `onOutcome` updates an unmounted tab (a React no-op). The tab animation is unchanged.

## D12 — #15: feedback currency by session generation
`createFeedback` (`attachmentDelivery.ts:204-217`):
```ts
  // Task 13 r3 (Nick, 2026-10-24): feedback follows the tab's session generation, which only ending the session
  // bumps. A same-user token rotation keeps it; the transport's own token check (Task 9) still fails that read.
  const generation = trackSession ? clientSessionGeneration() : null;
  …
  const current = () => !retired && ownerCurrent() && (generation === null || clientSessionGeneration() === generation);
```
- Feedback no longer reads the token. `currentSession()` stays for the transport snapshot (`:318`), and the
  transport checks are unchanged.
- **Rotation mid-download:** the attempt's failure is shown in place of the loading toast, or as an error toast for
  a button attempt; normally this is GENERIC. `onOutcome(failed)` keeps the panel's Download (r2 D6), and a retry
  reads the rotated token.
- **Ending the session** still silences the attempt.
- **A rotation between handoff and dispatch** no longer suppresses "download started", because the file did start.
- **Residual for the security review:** a token swapped to a *different* user without `clearFallbackSession` looks
  the same as a rotation, so that old attempt's generic error would be shown. No success or file can cross. This is
  tied to the open runtime `message` listener finding (an r2 retained deferral).

## D13 — #16: retained choices in the forced review (exact copy, for approval)
`PreGenerateDialog.tsx` gains an optional prop `retainedChoices?: ReadonlyArray<{ label: string; value: string }>`.
It renders only when the prop is provided, inside `DialogHeader` after `DialogDescription` and before the P45 note:
```tsx
{retainedChoices && (
  <div className="rounded-md border border-border/70 bg-muted/20 px-3 py-2 text-xs leading-relaxed text-foreground" data-testid="pre-generate-retained-choices">
    <p>This uses the choices from your earlier attempt. Generating again replaces the current version, even if it is newer than this attempt.</p>
    {retainedChoices.length > 0 && (
      <dl className="mt-1 grid grid-cols-[auto_1fr] gap-x-3 gap-y-0.5">
        {retainedChoices.map((choice) => (
          <React.Fragment key={choice.label}><dt className="text-muted-foreground">{choice.label}</dt><dd>{choice.value}</dd></React.Fragment>
        ))}
      </dl>
    )}
  </div>
)}
```

**Exact copy for approval.** The sentence is "This uses the choices from your earlier attempt. Generating again
replaces the current version, even if it is newer than this attempt." The lines come from the request that was
actually sent, and a line is omitted when its value is absent:

| Label | Value | Source |
|---|---|---|
| `For` | the contact's name | `deponentId ?? selectedContactId ?? targetBeneficiaryId`, looked up in `contact.list` |
| `Affidavit number` | the override exactly as typed (e.g. `2nd`) | `affidavitOrdinal`; omitted when automatic |
| `Date` | `YYYY-MM-DD` | `signatureDate` (printed unchanged) |
| `Signatory` | `Executor (applicant)` or `Lawyer` (the details dialog's own labels, `FormDetailsDialog.tsx:1216-1217`) | `signatoryType`, **only** for forms whose `FORM_DETAILS` offers a signatory (P1, P2, P44) |

**Wiring (EstateDetail.tsx).**
- `onSuccess` adds `choices: retainedChoicesOf(variables, contacts)` to the gate run it attaches (`:8201`). This is
  a small pure function next to `retainedRun`.
- The `Regeneration` gate variant gains `choices?`.
- `regenerate` passes `retainedChoices: regeneration.choices` in its render context (`:8616`).
- `PreflightRenderContext` gains a display-only `retainedChoices?`.
- FormsTab passes `retainedChoices={pgPendingRef.current?.renderContext?.retainedChoices}` (`:10096`), as
  `selectedContactId` already does.
- The block never appears on a normal Generate.
- **Consent (correction):** the consent dialog reopens with the retained person and share. The retained date and
  signatory are sent but not shown (unchanged, disclosed).

**The guard is a warning, not a block** (critique #5). The review already generates nothing until the user acts,
and the sentence states that confirming replaces the current version even if it is newer. There is no detection
logic and no new block (Rule 5).

**Freeze.**
- `PreGenerateDialog.tsx` moves from the reference set (35 → 34) to the task files: CRLF, with a census and a
  `before-r3` copy.
- Unchanged: the title, description, gap/override logic, legal guidance, applicability, form selection and every
  mutation input. The replayed body must stay byte-identical (browser check).

## m06
Record "accepted as equivalent by Nick, 2026-10-24". No code.

## Files (task-only; r2's untouched list still applies, except `PreGenerateDialog.tsx`)
| File (EOL) | Change |
|---|---|
| `client/src/lib/attachmentDelivery.ts` (LF) | D11 `useEstateFeedbackOwner` (about 10 lines); D12 currency (about 4 lines); comments |
| `client/src/pages/EstateDetail.tsx` (CRLF) | D11: page owner, 2 props plus a forward, 3 hook swaps. D13: `retainedChoicesOf`, `choices`, render-context field, dialog prop. About 40 lines |
| `client/src/components/PreGenerateDialog.tsx` (CRLF) | D13 prop and block (about 15 lines) |
| `client/src/lib/attachmentDelivery.test.tsx` (LF) | D11 and D12 tests |
| `client/src/pages/EstateDetail.task13-recovery.test.tsx` (LF) | D11, D12 and D13 tests |
| `.work/…/qa/mutants.cjs` (QA) | r3 mutants; m13/m15 re-targeted; m29 retired |
| `docs/superpowers/plans/2026-10-24-task13-r3-amendment.md` (new) | Step 0 copy |

## Tests and mutants
**Red-first** tests fail on unchanged source, behaviourally or because the new export is absent (accepted in r2's
`red/red-evidence.md`). **Guards** already pass and must stay green.

**D11**
- *Red* helper: a page owner keeps an attempt's feedback after the surface that began it unmounts; the result
  replaces its loading toast.
- *Red* helper: two instances on one page owner never replace each other's slot attempts.
- *Guard* helper: the page owner retires everything on unmount or a new scope.
- *Guard* helper: the r2 no-owner unmount tests are unchanged.
- *Red*, FormsTab with `feedbackOwner` in a wrapper: a tab switch (FormsTab unmounts) during a held Bearer download
  keeps the toast.
- *Red*, same wrapper: a generation that finishes after the switch is announced.
- *Red*, same wrapper: the old instance's late result does not silence a new instance's attempt.
- *Guard*, wrapper with `AnimatePresence mode="wait"` and the keyed `motion.div`: estate A → B while A's generation
  is held, then release. There must be no loading or started toast for A on B (critique #1; jsdom exit timing is to
  be confirmed in red).

**D12**
- *Red* (rewrites `attachmentDelivery.test.tsx:1065`): a rotation during the flight keeps the feedback;
  `toast.error(GENERIC, { id })`; `onOutcome` gets `failed/session-changed`; no file.
- *Guard*: `clearFallbackSession` during the flight drops it.
- The `:1079` table: "the session changes" becomes "the session ends" (*guard*). *Red*: a rotation after the
  handoff still announces `download started`.
- *Red* (rewrites recovery `:803`): a rotation mid-download shows the error in place of the loading toast, and the
  panel keeps Download. *Guard*: ending the session stays silent.

**D13**
- *Red*: the P8 stale-link review shows the exact sentence, `For: Riley Example QA`, `Affidavit number: 2nd` and
  `Date`, with **no** `Signatory`.
- *Red*: a P3 review shows `For` from `selectedContactId`.
- *Red*: a P1/P2/P44 review shows `Signatory`.
- *Red*: with the affidavit number automatic, there is no `Affidavit number` line.
- *Red*: the block keeps the original date after the Signature Date field changes.
- *Guard*: a normal Generate review shows no block.
- *Guard*: the replayed input is unchanged (existing D9 assertions).

**Mutants** (QA-only, byte-exact restore; each must be killed):

| Mutant | What it breaks |
|---|---|
| m31 | feedback compares the token again |
| m32 | feedback ignores the generation |
| m33 | the hook ignores `pageOwner` |
| m37 | no per-instance namespace |
| m34 | choices read from current state |
| m35 | block shown without `retainedChoices` |
| m36 | block never rendered |
| m39 | `Affidavit number` shown when automatic |
| m40 | `Signatory` shown for a form without a signatory choice |
| m41 | `For` ignores `selectedContactId` |

**r2 list**
- m13 and m15 are re-targeted to their rewritten lines.
- m29 is retired as equivalent under D12: feedback begun before a rotation now stays current. Documented.
- m06 is accepted (Nick).

**Not unit-killable, disclosed:** the `AnimatedTabs` prop wiring, because no page-level harness exists. It is
covered by the browser cases below.

## Verification (evidence in `.work/hybrid-remediation/task13/claude-pass02/`)
0. **Step 0.**
   - Copy the plan; re-verify identity and the index (status 140 → 141).
   - Take a `before-r3` snapshot of the 5 code/test files plus `mutants.cjs`, and an EOL census; set the reference
     set to 34.
1. **Red:** `run-gates.cjs claude-task13-r3-red1 focus` over the r2 focus files. The red-first tests fail and the
   guards pass.
2. **Implement**, one file at a time (helper, then EstateDetail, then PreGenerateDialog), with an EOL census after
   each edit.
3. **Green:** `claude-task13-r3-focus1`, plus the test-only type check: no error on an r3 line.
4. **Mutants:** the r3 list plus the adjusted r2 list.
5. **Build:** `claude-task13-build3`.
   - Restart the fixture through the owned launchers, with the identity checks.
   - Write `manifest-build3` and bind the assets.
   - Use a fresh QA browser profile and fictional sessions.
   - Save the fixture history as `task13-r3-start`.
6. **Browser** (E2E Runner; same stop-on-uncertainty brief; every outcome wait matches failure texts):
   - **S12d tab switch:** a held Bearer P10 auto-download, then switch to another estate tab, then release:
     `Form generated — download started.` appears on that tab, and the file arrives.
   - **S12e tab switch plus rotation:** held, switch, `swapToken`, release. The read is aborted, the generic error
     replaces the loading toast, and there is no file. After `restoreToken`, a deliberate retry from Forms
     succeeds.
   - **S12c′, rotation in the same tab:** the error is now shown.
   - **S12a′, leaving the estate:** feedback is still dropped and the file still arrives.
   - **S12f estate→estate** with a cached estate: run **only** if the QA user's dashboard lists a second owned
     estate. Otherwise it is not run, with the unit guard covering it; no estate is created.
   - **S3′ stale-link chain with `2nd`:**
     - the review shows the exact block (`For`, `Affidavit number`, `Date`; no `Signatory`);
     - there is no request until Generate;
     - the replayed body is byte-identical to the original's;
     - compare-docx shows a timestamp-only difference.
7. **Reviews,** parallel, read-only, Opus:
   - `Code Reviewer`;
   - a general-purpose security reviewer for D12, given the residual above (the Review Council guard blocks plugin
     security agents);
   - general-purpose with `probate-integrity-gate` for `PreGenerateDialog.tsx`.
8. **Gates:** `run-gates.cjs claude-task13-pass2 check tests chatbot-check chatbot-tests build render`, then
   `manifest-recheck manifest-build3`.
9. **Close-out.**
   - `after` / `final` snapshots; r3 delta diff; `claude-pass02/final-status.md`.
   - A `Reality Checker` claims audit.
   - Fixture restore to `task13-r3-start`, then shutdown.
   - **STOP:** hand back. Task 13 is not marked done and no SHIP claim is made.

## Plan-critique dispositions (`Plan` agent, Opus, read-only)
| # | Finding | Disposition |
|---|---|---|
| 1 | High: a context owner leaks across estates during the exit animation | **Fixed:** owner passed as a prop (frozen in the exiting element), plus an estate-switch guard test |
| 2 | High: "Signatory" is false for forms with a forced signatory | **Fixed:** shown only where `FORM_DETAILS` offers a signatory |
| 3 | Medium: "For" misses `selectedContactId` deponents | **Fixed:** `deponentId ?? selectedContactId ?? targetBeneficiaryId` |
| 4 | Medium: mutant accounting | **Fixed:** m13/m15 re-targeted; m29 retired; m39–m41 added |
| 5 | Copy over-claims "same person"; no newer-version warning | **Fixed:** copy rewritten; the guard is called a warning |
| 6 | Instances in one estate share slots; late generations are now announced | **Fixed:** per-instance namespace; the behaviour change is disclosed and tested |
| 7 | D12 safe; residual for a different-user swap; other failure kinds possible | **Disclosed** (facts and D12) |
| 8 | Some "red" tests already pass | **Fixed:** labelled red-first or guard |
| 9 | Consent display overstated; `Fragment`; stale comments | **Fixed** |

## Unchanged from r2
- D1–D10, except that D11 replaces D7's tab owners and D12 replaces D7's session rule. D9's review gains D13's block.
- Every r2 retained deferral and Task 9 decision is unchanged:
  - dev-log body redaction;
  - the runtime `message` listener;
  - chatbot rotation transport;
  - Safari/iOS/Android;
  - Word/pixels user-deferred-not-passed;
  - Task 12's preview lifecycle;
  - "Review & retry" target loss.

## Orchestration (`/orchestrate custom`, routed by `/find-skill`)
1. `Plan` critique: done.
2. **Nick's approval.**
3. `TDD Guide` writes the red tests and guards, in the two LF test files only.
4. I implement, one file at a time.
5. Mutants.
6. Build, then `E2E Runner`.
7. `Code Reviewer`, security reviewer and integrity reviewer, in parallel.
8. Gates.
9. `Reality Checker`.
10. Hand back.

The bundled agents run with `model: opus`. The fixture, browser and gate steps are serial.

## Decision record (appended after the hand-back; not part of the approved text above)
The approved text above is unchanged: the file's first 20,832 bytes still hash to `f6299fef…`. This section was
appended at Nick's request on 2026-10-24.

**Nick's decisions, 2026-10-24 17:48 PDT:**
- **VSA532 review line confirmed.** The forced review shows `Signatory` for VSA532 only when "Lawyer" was sent. This
  is r3.2's narrowing of his r3.1 "Show it" answer.
  - It approves the UI display only.
  - Do not change the printed form, the form-selection logic or the P10 deponent behaviour.
- **Task 13 is done within its approved scope, by Nick's decision.**
  - This is remediation tracking, not a SHIP or production-readiness approval.
  - Every disclosed limitation and every unverified or deferred check stays as recorded in
    `.work/hybrid-remediation/task13/claude-pass02/final-status.md` (§6 and §9–§12).
- **Stop:** no further Task 13 code change, and no other task is started.

**Still open, not resolved by this decision:**
- **Unverified or deferred checks:**
  - Word/pixels: user-deferred, not passed;
  - Safari/iOS/Android: not tested;
  - Task 15's browser gap: outstanding.
- **Earlier findings, still open:**
  - Dev/Preview delivery-body redaction (a Task 9 decision, OPEN);
  - the runtime `message` listener (OPEN before production);
  - chatbot rotation (recorded only).
- **Task 13 residuals:**
  - the preview path's microtask gap (INFO);
  - the S2 different-user residual;
  - the `DATE_NOT_PRINTED` exception list (L2);
  - c48 survives by design;
  - S12f was not run.
- **Pre-existing, unchanged by Nick's instruction:** the P10 deponent carry-over in `FormDetailsDialog`
  (`:915-930`).
- **Kept as before:**
  - Task 12 owns the preview lifecycle;
  - "Review & retry" after a generation failure still drops its targets;
  - a native duplicate retry stays possible;
  - the recovery panel is per-mount state.
