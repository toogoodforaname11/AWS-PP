# Task 17 — Accurate documentation — plan r3 (Gate A, decided; Gate B not authorized), 2026-10-27

**Status:** Gate A investigation complete. r2 folded in the three-lens read-only design panel (§12). r3 applies Nick's
2026-10-27 decisions D1–D8 and his targeted corrections (§15, verbatim, with the "Applied" checklist). Nick authorized
**only** the Gate A plan/evidence save and the decision-record update; **Gate B is not authorized** and starts only on a
separate, explicit go-ahead. At the Gate A save only this plan copy and `.work/hybrid-remediation/task17/claude-pass01/`
were written; no other repository file changed.

Queue item 17 only (`docs/superpowers/plans/2026-10-21-hybrid-remediation-queue.md:61`). Not in scope: Tasks 18–20, Tasks
7/8 (not reopened), Tasks 6/14 (unchecked, not repaired), hybrid Step 4, any application/test/schema/UI/config edit, any
git, production, AWS, `.env`, fixture, browser, Office or gate-runner operation, SHIP or acceptance of anything.

## Approval gates

1. **Gate A — this plan (authorized by Nick, §15; executed on plan-mode exit).** Plan mode allowed only this file. Exiting
   plan mode performs only:
   (a) saving this text (with §12 and §15) as `docs/superpowers/plans/2026-10-27-task17-accurate-documentation.md` (new,
   untracked, LF);
   (b) creating the fresh `.work/hybrid-remediation/task17/claude-pass01/` holding: `before/` byte copies of the four edit
   targets; `before-hashes.json` and `eol-census-before.json` (the §2 census: 70 files, plus a tree digest of every
   `*.test.ts`/`*.test.tsx` under `server/` and `client/`, plus the cited-file set produced by a dry run of the B3
   extractor over the current docs, plus `RULES.md` and `.cursorrules` listed as the instruction set and the recorded
   absence of any `CLAUDE.md`/`AGENTS.md`/`README.md` in the root, `docs/`, the three target folders and `references/`);
   `porcelain-before.txt` (path + XY of every `git status --porcelain` entry) and the stash count; `citations.json` (the
   B3 anchor map built from §5, hashed); `impact-matrix.md` (§3–§7 of this plan); `tracer-reports/` (the three
   read-only tracer outputs verbatim); `panel-report.json` (the §12 source); `gate-a-notes.md`;
   (c) reporting their hashes; then **stopping**;
   (d) the decision record: Nick's answers are already in §15 of this text and are saved with it.
   No document in `references/` or `docs/` other than that saved plan is touched at Gate A.
2. **Gate B — the edits.** Steps B0–B9 (§11) start only after Nick's separate, explicit go-ahead. The §15 decisions
   shape Gate B but do not grant it.
3. **Acceptance** belongs to Nick. Task 17's queue evidence entry is drafted in the handoff and appended/checked only on
   his explicit authorization.

The approval/preference record for this task already exists and is unchanged:
`docs/superpowers/plans/2026-10-27-task17-handoff-preferences.md` (sha256 `43df4da072bd17fd…`, equal to
`.work/task17-prompt-update-2026-10-27/verification.json`). No second preferences file is created.

## Capability routing (find-skill, recorded)

| Phase | Capability |
|---|---|
| Gate A investigation (done) | Own reads of the four governing files, the queue (838 lines), the six candidate docs and the key source regions; three parallel read-only Explore tracers (storage/config; generation/delivery/audit; notes/reporting/client/preview), 54–61 tool calls each, no Bash, no edits; a read-only Node census (SHA-256, size, EOL, git state) of 70 files. Then a three-lens read-only Plan panel over r1 (Workflow `wf_3fc6a6df-403`: minimal-change/scope, truthfulness/overclaim, verification/evidence; 17–19 tool calls each, Read/Grep only; all three `sound-with-changes`), dispositions in §12. Nick's corrections (§15) were each re-checked against source before r3. |
| Gate B edits | Main session only, plan-driven; no subagent edits; Edit tool batched by paragraph, then an EOL census per file (§11 B2). |
| Gate B review | Three read-only reviewers on the final bytes (§11 B7). Specialist agent files pin a retired model id; pass `model` explicitly or use general-purpose agents (memory). |

Routing rows that applied (`capability-routing.md`): "Documentation → doc-updater" (row 51) and "Code review →
code-reviewer + security-reviewer" (row 32). `doc-updater` is a codemap generator and is not used as a writer: this pass
is hash-pinned prose against frozen source. Orchestration triggers fired: multi-domain (storage, delivery, client,
notes), research + synthesis, producer + validator, high stakes. `code-review-graph` is built at HEAD
(`db0d7e9161bc…`, 75 files) but does not index `_core/deliveryRouter.ts`, `notesExportLimits.ts`,
`exportFailureReporting.ts`, `attachmentDelivery.ts`, `previewTransport.ts` or `fallbackSession.ts` (all untracked), so
every trace below is bounded direct tracing (Grep + offset Read), as the prompt's fallback requires. No remote service
was used. The Obsidian vault has no live ProbatePro item (BRAIN.md: none; DASHBOARD.md: one historical 2026-07-05 line).

## 1. Context

`references/file-storage.md` (314 lines, CRLF, tracked, ` M`) carries a "Hybrid vault compatibility note (2026-10-19,
re-anchored 2026-10-20)" that is the only repository description of the implemented storage, delivery and audit contract.
Tasks 3, 16, 4, 5, 14, 6 (+repair), 15, 9, 13, 10, 11 and 12 changed that contract after 2026-10-20. The note now states
**five materially false guarantees** and roughly 120 drifted `path:line` citations, and it is silent on six implemented
areas (client transport, form-delivery binding, notes audit/limits, staff reporting, preview limits, what is proven where).
A runbook reader acting on it today would: expect 8 KB bodies on the form route (it is 8,349/8,353 B), believe generation
audit is best-effort (it is transactional), believe the notes export leaves no audit trace (it does), expect
`userCanAccessStorageKey` to be the read gate (it has no non-test caller) and expect a "counts-only drift warning" at
startup (startup now refuses). The HEAD version of the file is the pre-hybrid template, so the 2026-10-20 note exists only
in the working tree; it is preserved by a `before/` copy before any edit.

**Goal:** make the non-authoritative technical docs state what the code does now, with every guarantee traceable to a
current source line and every limitation carried forward verbatim or by link; add nothing the code does not do; touch no
legal content, no source, no test, no historical receipt.

## 2. State verified at planning time (2026-10-27, read-only)

**Workspace.** `C:\Users\nick\probate pro\probatepro-hybrid-review`, worktree of `probatepro`, branch
`security/hybrid-vault-review`, HEAD `db0d7e9161bc3899b75858fab58bce54e3d5247a`; porcelain 163 entries (83 `??`); one
shared stash entry (not ours; not touched); three worktrees listed (main, this, `p9-p10-sync-20260906`); nothing staged.

**Queue.** 12 checked (1, 2, 3, 16, 4, 5, 15, 9, 13, 10, 11, 12), 8 unchecked (14, 6, 7, 8, 17, 18, 19, 20); "Task 17 is
not started" (queue :838). Task 12 accepted with known limitations 2026-10-27 13:43 PDT (:792-831). Tasks 7/8 not reopened
(:432). `.work/hybrid-remediation/task17/` does not exist; `claude-pass01` is free.

**Target-folder instructions.** No `CLAUDE.md` or `AGENTS.md` exists in the repository root, and no `CLAUDE.md`,
`AGENTS.md` or `README.md` exists in `docs/`, `docs/architecture/`, `docs/operations/`, `docs/runbooks/` or `references/`
(the Gate A save script's inventory; an earlier truncated glob had missed the root file). The root `README.md` (78 lines,
tracked, clean) is a project readme with no editing rule. Its "Local development — file storage" section claims that a bare
`pnpm dev` with no `STORAGE_S3_*` configuration auto-defaults to a local MinIO profile, whereas the current note describes
the development/test fallback as the platform store (`_core/env.ts:240-248`): **unverified here, not an approved edit
target, raised as D9**. Its "Documentation" section points to the ProbatePro Obsidian vault
(`C:\Users\nick\OneDrive\Desktop\Probate Software`), whose `CLAUDE.md` carries a review-before-edit rule (satisfied by the
Gate A/B protocol) and the docgen formatting freeze (consistent with Rule 29), and no documentation-editing rule; the vault
is read-only for this task and not updated (project precedent, queue :458). Recorded in `gate-a-notes.md`; re-checked at B0.

**Receipt provenance (historical, not fresh).** `task12/claude-pass01/final-status.md` sha256 `0b605fdfcd526ea1…` equals
the queue-recorded hash (:756) and the prompt-prep baseline (`source-before.json`); its header reads "Accepted by Nick with
known limitations … not a SHIP, deployment or production-security approval". Task 10/11/9/13/15/6/14 reports are present
at the paths the queue names (table below). RULES.md `648f49a7…`, `server/docgen.ts` `7224c88e…`, `shared/types.ts`
`9a60dfb7…`, `drizzle/schema.ts` `25f7c362…` equal the prefixes Task 12 recorded: frozen sources are unchanged since Task
12 closed. Gate counts (7,068 root tests etc.) are cited nowhere in the proposed docs (D8).

**Pre-task fingerprints** (sha256 prefix; EOL from a byte census in Node, never Git Bash `grep`; full hashes go to
`before-hashes.json`).

| File | git | EOL | sha256 prefix |
|---|---|---|---|
| `references/file-storage.md` (EDIT) | ` M` | CRLF 314/0/0 | `be416e2ba7c555eb` |
| `docs/operations/storage-provider-due-diligence.md` (EDIT, 1 line) | clean | CRLF 102 | `03e239dfdd9e5cd5` |
| `docs/runbooks/storage-incident.md` (EDIT, addendum) | clean | CRLF 139 | `2592de83650c0847` |
| `docs/architecture/rule-10-conformance-baseline.md` (EDIT, 1 row) | clean | CRLF 78 | `a16812b25b66770…` |
| `docs/architecture/individual-lawyer-canadian-vault-checklist.md` (no edit) | clean | CRLF 158 | `79c468d160fb7a63` |
| `docs/architecture/hybrid-canadian-vault-blueprint.md` (no edit) | clean | CRLF 306 | `24f595ec539f99ab` |
| `docs/audits/estate-disposition-legacy-storage-diagnosis.md` (historical) | clean | CRLF 42 | `bd043378ea9b5bb7` |
| `docs/operations/restore-test-record.md` (no edit) | clean | CRLF 106 | `03c2ee8d8277be4e` |
| `RULES.md` (PROTECTED) | ` M` | CRLF 1980 | `648f49a7ac8a9e8b` |
| `.cursorrules` (PROTECTED) | clean | CRLF 182 | `4d0e0bb90475ce17` |
| queue `2026-10-21-hybrid-remediation-queue.md` (not edited at Gate B) | `??` | LF 838 | `5f2e4ec3f6c526a7` |
| `2026-10-27-task17-handoff-preferences.md` (not edited) | `??` | LF 23 | `43df4da072bd17fd` |
| `server/docgen.ts` / `shared/types.ts` / `drizzle/schema.ts` (FROZEN) | ` M`/clean/` M` | CRLF | `7224c88e` / `9a60dfb7` / `25f7c362` |
| `server/storage.ts` / `storageRegistry.ts` / `storageProvider.ts` / `storageNamespace.ts` | ` M`×3, `??` | mixed 89/84; mixed 1041/712; CRLF; CRLF | `a3eedd60` / `012ea6d1` / `507fcd92` / `71c35d03` |
| `server/_core/storageProxy.ts` / `env.ts` / `index.ts` / `trpc.ts` / `deliveryRouter.ts` | ` M`×4, `??` | mixed 30/37; CRLF; CRLF; CRLF; CRLF 261 | `9ba5c6da` / `aa887f8d` / `ad2a9fd2` / `6b2e7198` / `d1594d2f` |
| `server/db.ts` / `documentReplacement.ts` / `affidavitHistory.ts` / `routers.ts` | ` M`, `??`, ` M`, ` M` | mixed; CRLF; mixed; mixed 6449/343 | `32c57258` / `f4c01aee` / `38f875b8` / `1c30a539` |
| `server/formDeliveryBinding.ts` / `formDeliveryArtifact.ts` / `downloadRoute.ts` / `downloadExportsRoute.ts` / `shared/postDelivery.ts` | `??`, `??`, ` M`, `??`, `??` | LF; LF; mixed 430/19; CRLF; CRLF | `8403a470` / `0772620c` / `224c1af5` / `caa3cfbc` / `576b7662` |
| `server/exportFailureReporting.ts` / `failureReporting.ts` / `notesExportRoute.ts` / `notesExportLimits.ts` | `??`, ` M`, ` M`, `??` | LF; CRLF; CRLF; LF | `81429bc9` / `6a152dfb` / `a01e403a` / `d97f5333` |
| `server/estateExport.ts` / `documentAssets.ts` / `schemaCheck.ts` / `package.json` / `drizzle/meta/_journal.json` | ` M`, ` M`, clean, ` M`, ` M` | mixed; mixed; CRLF; CRLF; CRLF | `f70e2ceb` / `46405db3` / `c03bcfe5` / `4640e1f4` / `97d0ea11` |
| `client/src/lib/attachmentDelivery.ts` / `fallbackSession.ts` / `trpcLinks.ts` / `previewTransport.ts` / `trpcTransport.ts` / `utils.ts` | `??`×4, ` M`×2 | LF×4; CRLF×2 | `af06d770` / `4dbfdcd6` / `5ca67f6d` / `be2ce613` / `62ee5cae` / `d58876f7` |
| `client/src/pages/EstateDetail.tsx` / `Home.tsx` / `main.tsx` / `public/__manus__/debug-collector.js` | ` M`×4 | CRLF | `1506b207` / `4073a6b0` / `1fc8d396` / `05711cbb` |
| Predecessor reports: task12 / task10 / task11 / task09 / task13-pass02 / task15 final-status, task06 manus-repair01 json, task14 json + STILL-BLOCKED, `outputs/task06-repair-report-2026-10-23.md` | `??` | LF | `0b605fdf` / `e648e73f` / `7ecc3cac` / `2cfef758` / `fa2f4c7d` / `e0a6b38e` / `e56b4f82` / `ac4f8264` / `f6bf0a26` / `a8424fd3` |

**Census extension at Gate A save (panel D-1, V4):** the saved `before-hashes.json` also carries (i) a tree digest and
per-file hashes of every `*.test.ts`/`*.test.tsx` under `server/` and `client/`; (ii) every file the matrix cites that the
table above omits, all verified to exist: `server/_core/originPolicy.ts`, `server/_core/sdk.ts`,
`server/scripts/validateStorageProvider.ts`, `migrateLegacyStorage.ts`, `confirmLegacyStorageDestruction.ts`,
`shared/serverManagedEstateFields.ts`, `server/storagePublicAssets.ts`, `client/src/_core/hooks/useAuth.ts`,
`client/src/pages/Settings.tsx`, `client/src/components/chatbot/botClient.ts`, `server/deliveryBearerAuth.test.ts`,
`.work/hybrid-remediation/task03/database-lock-compatibility.md`, `task03/acceptance.md`, `task16/acceptance.md`,
`task04/acceptance.md`, `task05/acceptance.md`, `task15/claude-pass01/browser-check-pending.md`; (iii) whatever else the B3
extractor resolves from the current docs. The four edit targets are uniform CRLF with no lone CR and no `.gitattributes`
exists; `core.autocrlf` is unknown, so a CRLF flip would be invisible to `git diff` and the Node census is the only EOL
evidence. No source file is edited.

## 3. Documentation inventory and disposition

| Document | Disposition | Why (consequence of the stale text) |
|---|---|---|
| `references/file-storage.md` | **EDIT** (§6) | The implemented-contract note; five false claims, ~120 drifted citations, six missing areas. |
| `docs/operations/storage-provider-due-diligence.md` | **EDIT, one line** (§7 O1) | §3 names `pnpm storage:validate`; the script is `storage:validate-provider` (`package.json:17`). An operator would run a missing script. |
| `docs/runbooks/storage-incident.md` | **EDIT, dated addendum in §4.2 + one cross-reference at §3.B.4** (§7 O2) | §3.B.4 says "expire/revoke where supported" without saying what is supported; an incident lead would not know what refuses later requests, what cannot be revoked, and that nothing revokes an already-admitted response. |
| `docs/architecture/rule-10-conformance-baseline.md` | **EDIT, one table row** (§7 O3; D4c) | §3 "Existing technical controls" names `userCanAccessStorageKey` as the fail-closed gate; it has no non-test caller. §2 (dated decisions) untouched. |
| `docs/architecture/individual-lawyer-canadian-vault-checklist.md` | no edit (D4d: no) | "not implemented" VPS design; no implemented-guarantee claim. Its §8 prohibited claims still hold. |
| `docs/architecture/hybrid-canadian-vault-blueprint.md` | no edit (D4d: no) | "Architecture proposal — not implemented"; a different design from the implemented S3 hybrid. |
| `docs/audits/estate-disposition-legacy-storage-diagnosis.md` | historical, no edit | An audit receipt; its remediation boundary still matches the worker (`storageRegistry.ts:1668-1672`). |
| `docs/operations/restore-test-record.md`, `references/launch-security-audit.md`, `references/auth-production-verification.md` | no edit | Templates / no storage-delivery claim (keyword sweep over `references/` matched only file-storage.md). |
| `README.md` (repository root; found at the Gate A save) | **candidate, not an edit target; D9 pending** | Its "Local development — file storage" paragraph claims a MinIO auto-default for a bare `pnpm dev`; the current note says development keeps the platform-store fallback (`_core/env.ts:240-248`). Unverified at Gate A (the read-only check was declined); if stale, a developer would set up MinIO that the code does not use. |
| Queue, task plans, handoff preferences, `.work/` receipts, `outputs/` reports | historical, no edit | Evidence stays as recorded; the queue entry is drafted only (gate 3). |
| `RULES.md`, `.cursorrules`, captures, legislation text, `server/docgen.ts`, renderers, `shared/types.ts`, all source and tests | PROTECTED, read-only | Prompt §3. Stale **source comments** found (`_core/index.ts:192-193` "their own 8 KB bodies"; `downloadRoute.ts:4` "8 KB JSON or form body"; `shared/serverManagedEstateFields.ts:14-16` "scopes to nothing"; `attachmentDelivery.ts:10-11` already recorded by Task 9) are listed for Nick in §13, not edited. |

## 4. Verdict summary for `references/file-storage.md`

Verdicts: TRUE (claim and citation current), DRIFT (claim true, line moved), STALE (claim false or materially incomplete),
UNPROVEN (a deployed/AWS/browser fact code cannot prove). Counts over the note's ~150 claims: TRUE 58, DRIFT 71, STALE 17,
UNPROVEN 9. Every STALE row is in §5 with its current source; every DRIFT row is re-anchored by §6 and re-checked by B3
(mechanically) and B7/B8 (semantically).

**The five materially false guarantees**

| # | Doc line | States | Current fact (verified by own read) |
|---|---|---|---|
| F1 | 108–110 | "two 8 KB parsers … each limited to 8 KB … Content-Length over 8,192 → 413" | Four parsers. Form route: 8,353 B JSON / 8,349 B urlencoded (`BODY_LIMIT_BYTES + 161 / + 157`, `_core/deliveryRouter.ts:20-25`, chosen at `:184-187`, `:257`); export and notes stay 8,192. |
| F2 | 114 | "`generateAllLetters` writes no row" | Writes no `documents` row, but commits one `export_generated` audit row and one `document_generated` activity row under the estate lock (`routers.ts:4625-4631`; `db.ts:1139-1156`). |
| F3 | 115 | "Generation is recorded once, by the mutations, best-effort: the recorder never throws and the mutations do not act on its answer" | Required audit + activity rows are `GenerationEffects` written inside the provenance transaction, each insert acknowledged as exactly one row (`db.ts:1082-1121`); failure throws `GenerationCommitUnconfirmedError` (500, "Generation could not be confirmed. Refresh the estate and try again.") or a replacement conflict before any descriptor (`:1123-1137`). `recordDocumentGenerated` / `recordExportGenerated` have no non-test caller. Only `estate.export`'s `exported` timeline activity stays best-effort (`routers.ts:2704-2717`). |
| F4 | 117 | "The notes export writes no audit event" | `notes_delivery_started` gated on a recorder answer of exactly `true` within 10 s, then one of finished/aborted/failed best-effort; `idor_attempt` on a foreign estate (`notesExportRoute.ts:241-266`, `:112-126`, `:154-163`; `affidavitHistory.ts:638-641`). |
| F5 | 119 | "`GENERATOR_RELEASE` … written to every generation event and to every started and failed delivery event" | Notes delivery events carry no `generatorRelease` (`notesExportRoute.ts:245, 252`; the `DeliveryEventDetail` whitelist `affidavitHistory.ts:591-606` would admit it, the route never passes it). The binding MACs a separate composite fingerprint (`formDeliveryGeneratorRelease`, `formDeliveryArtifact.ts:51-62`) that is never written to an event. |

**Other STALE rows:** §4 read-routing table (dev/test row and "no row" row; `storedObjectIsOnApprovedProvider` gone), §5
preview-route/proxy gate (`userCanAccessStorageKey` unused), §6 line 107 "streams the bytes once" (a valid binding admits
repeated POSTs; no exactly-once), line 107/112 descriptor fields (now carry `binding`), line 109 `bodyTypeAccepted`
(renamed `acceptedBodyType`), line 110 parser-error mapping (non-parser errors → 500), line 112 409 ordering (binding 409
before the rate unit, the current-row stale-link 409 after it), line 116 `inputsHash` (also excludes `binding`), §9
"drift warning counts only, never blocks startup" (startup now refuses), superseded-list item 175 ("no-row objects stay";
they fail startup), superseded items 167/169/172 (quote, label, citation).

## 5. Documentation impact matrix — `references/file-storage.md`

Columns: section/line · stale claim · reader/runbook consequence · source contract (current `file:line`, symbol) ·
evidence/limits · proposed correction. **Citation legend (panel V2):** an unprefixed path is under `server/`; every other
path is repo-relative (`shared/…`, `client/src/…`, `drizzle/…`, `RULES.md`, `.work/…`). Short basenames in this plan
(`attachmentDelivery.ts`, `EstateDetail.tsx`, …) are written repo-relative in the doc text.

**Canonical sentences carried into every affected row (Nick, §15):**

- *Binding lifetime.* A binding expires 600,000 ms (10 min) after its signed issue timestamp (`nowMs < issuedAtMs + TTL`,
  `formDeliveryBinding.ts:30, 113`); an issue timestamp more than 60,000 ms in the future is refused (`:31, 114`), a
  clock-skew tolerance that adds no lifetime. Expiry is checked once, at admission (`downloadRoute.ts:180-186`), never
  after.
- *Revocation.* Row replacement or archive by a later generation (`downloadRoute.ts:288-299`) and a changed render digest
  (`:313, 345`) refuse **subsequent** requests that observe them; they do not revoke an already-admitted response.
  Invalidating every binding by changing the session secret, `GENERATOR_RELEASE` or the build fingerprint takes effect
  only in serving processes that have loaded the new value (`formDeliveryBinding.ts:55-58` reads `ENV.cookieSecret` from
  the process environment on each call; `formDeliveryArtifact.ts:57-61` caches the fingerprint for the process lifetime),
  so an old worker keeps verifying old bindings until it is restarted. These sentences describe behaviour; they prescribe
  no containment step: regenerating documents or editing database rows is not a procedure.

### 5.1 Storage, configuration, reads (§1–§5, §7–§9, preconditions, superseded list)

| Ref | Section:line | Stale claim | Consequence | Source contract | Evidence / limits | Correction |
|---|---|---|---|---|---|---|
| S1 | §4:88 | Dev/test: "Platform store always; no manifest lookup" | Operator misreads a refused dev read as a provider fault | `storage.ts:107-121` `readsFromLegacyPlatform` (approved_s3 + platform → throw `:115-119`); `withReadableStoredObjects` `storageRegistry.ts:652-745`; public exemption `storage.ts:146-147, 170-171` | Task 3 acceptance | Bytes still come from the platform, but every private read needs a readable, identity-consistent `legacy_forge` manifest; an `approved_s3` row is refused in platform-only mode; only the eight `PUBLIC_STORAGE_ASSETS` skip the manifest. |
| S2 | §4:90 | "legacy_forge, or **no row** (public assets, pre-manifest files) → platform, read-only"; `storedObjectIsOnApprovedProvider` `:353-360` | Reader expects unmanifested private files to read; they are refused and block startup | `storageRegistry.ts:689-692` (missing row refused), `:1289-1294` (startup invalid unless a public asset); symbol gone | Task 3 | Only `legacy_forge` rows read from the platform (read-only helpers `storageProvider.ts:173-182`); an unmanifested key is refused unless it is one of the eight public assets, and blocks startup. Replace the dead symbol with `readsFromLegacyPlatform` (`storage.ts:112-121`) and `withReadableStoredObjects`. |
| S3 | §4 (new bullets) | Gate conditions and bounds undocumented | Runbook cannot explain a private-read refusal | `storageRegistry.ts:682` (estate missing/foreign), `:689-692` (count/user/estate/category), `:701` (account missing or disposition tombstone), `:703-706` (identity, lifecycle active/retained `:228-239`, byte metadata), `:707-708` (runtime reference conflict), callback only `:709-715`, errors generic `:741-744`; bounds `:107-112, 542, 732` (≤500 requests/call, chunks of 20, ≤500 reference rows, ≤1 MiB codicil JSON, 8 lock attempts, 30 s); "never an authorization cache" `storage.ts:128`, `storageRegistry.ts:650` | Task 3 acceptance; local MySQL/InnoDB evidence only (`.work/hybrid-remediation/task03/acceptance.md`); TiDB unverified | Add ≤7 bullets: refusal-before-provider conditions, bounds, no cross-request cache; a later disposition cannot be overtaken by a new dispatch but does not revoke an admitted operation or an already-issued presigned URL (`storageRegistry.ts:644-650`), which stays valid until it expires (≤900 s). |
| S4 | §5:101 | Preview route `routers.ts:3299` and proxy use `userCanAccessStorageKey` (`db.ts:663-664`) | Reviewer audits the wrong function | `previewFile` `routers.ts:3350-3365` and `_core/storageProxy.ts:35-36, 53-57` call `findAccessibleStoredObject` and pass a read context `{userId, estateId, category}` to `storageGetSignedUrl`; `userCanAccessStorageKey` `db.ts:665-666` has no non-test caller | Task 3 | Rewrite the sentence; list the read-context callers (`routers.ts:386-388, 1321, 1457, 2009, 3240, 3359-3363`; `documentAssets.ts:219-233`; `estateExport.ts:156-157`; `downloadRoute.ts:354, 359, 365`; `downloadExportsRoute.ts:114`). |
| S5 | §9:146 | "Drift warning: counts only … never blocks startup (`storageRegistry.ts:828-841`)" | Operator expects a warning where startup refuses | symbols absent; identity/lifecycle mismatches throw `storageRegistry.ts:1296-1297, 1304-1305, 1308-1324` | Task 3 | Delete the bullet; state that a reference with a mismatched owner, category, retention or lifecycle fails startup with a counts-only message (`:1305, 1323`). |
| S6 | Superseded:175 | "`legacy_forge` and no-row objects stay on the platform store" | Same as S2 | `storageRegistry.ts:1289-1301`, `_core/index.ts:74`, `:1241-1246` | Task 3 | "Only `legacy_forge` rows and the eight unmanifested public assets stay; any other unmanifested reference fails startup." |
| S7 | Superseded:167, 169, 172 | Quote not verbatim (backticks); "(KMS paragraph)" is the IAM paragraph's last sentence; citation `:893-898` | Minor; link integrity | file-storage.md:180-181, 224-226; `storageRegistry.ts:1329-1335` | — | Fix quote, label and citation. |
| S8 | Preconditions (new item 8) | Private-read database requirement absent | Deployment to an unsupported engine/isolation refuses every private read | `requireStorageReadLockingEngine` `storageRegistry.ts:503-517`: session isolation `READ-COMMITTED` or `REPEATABLE-READ`; MySQL `8.0.x` or `8.4.x` (optionally `-commercial`) with the Community or Enterprise version comment, or TiDB v8 (a `5.7.x-TiDB-v8.y.z` or `8.0.x-TiDB-v8.y.z` version string with the comment `TiDB Server (Apache License 2.0)`) with `tidb_txn_mode=pessimistic`; any other engine or version refuses; `requireStorageReadInnoDBTables` `:520-527`: `estates`, `stored_objects`, `users` must be InnoDB `BASE TABLE`s (MySQL) | Task 3 (`.work/hybrid-remediation/task03/database-lock-compatibility.md`, `task03/acceptance.md`), Task 11 limit "production pool size and engine (TiDB) not verified" (queue :693-694) | **D5 (decided: yes).** Add precondition 8, labelled **code-enforced at read time; production engine and pool unverified**. |
| S9 | §7 table, §8 | IAM rows cite code lines as if they proved the grant | Reader takes a policy as proven | Code requires: runtime `s3:ListBucket` (`storageProvider.ts:623-640, 755`), KMS via `SSEKMSKeyId` (`:541-542, 594-600`); purge lists/deletes only (`:694, 740, 752`); never reads or calls KMS on that path (`:723-758`) | **Unproven in deployment:** IAM grants, trust policies/ExternalId, KMS key policy and `kms:ViaService`, bucket state, AWS 403-vs-404, `SSEKMSKeyId` echo, versioned purge, production startup, 0173 applied, `GENERATOR_RELEASE` set, Forge variables (Task 19 blocked) | Add one sentence above §7: "Code lines show what the application sends or checks; whether the deployed grant or policy exists is unproven until Task 19." Extend §8 with the list. |
| S10 | §1–§3, §5, §9, preconditions | 31 citations drifted (claims true) | Links point at wrong lines | `_core/index.ts:55, 59, 64-67, 69, 72-74`; `storageRegistry.ts:1672` (sole `providerDeleteExact` call), `1241-1246`, `1668-1671`, `1325-1327`, `1353-1371`, `1532-1538`, `1022-1027`, `1095`, `1489`, `1499-1512`, `1724-1727`, `1329-1335`; `storage.ts:52-67, 54-55, 57-65, 75-88, 84, 112-121, 133-135, 155-157`; `routers.ts:313-315, 343-345, 357-384, 539-553, 2976-2977, 4945-4950, 6533, 6689-6694`; `db.ts:615-616, 637-663, 660-661, 693-694`; `estateExport.ts:30-32, 43`; `downloadExportsRoute.ts:86-87` | tracer table (storage) | Re-anchor each (D2). |
| S11 | §2:42, §5:98, §1:33 | Precision | Operator expects the S3 presign lifetime on the platform path, or key privacy on legacy keys | presign lifetime is the S3 path only (`storageProvider.ts:140-152` Forge); key privacy holds on the vault path only (`storage.ts:54-55` keeps legacy keys); operator scripts call the gate at `scripts/validateStorageProvider.ts:5-6`, `migrateLegacyStorage.ts:57-58`, `confirmLegacyStorageDestruction.ts:25-26` | — | Add the qualifiers (the purge-provider bootstrap-pair note is dropped: no reader consequence, panel I-1). |
| S12 | — | Withdrawn (panel I-1) | — | — | — | The proxy's 502-on-`pending_reference` quirk stays in §13 for Nick, not in the doc; the proxy's cookie-versus-Bearer fact moves to N3 as one sentence. |

### 5.2 Generation, delivery, audit (§6, lines 107–124)

| Ref | Line | Stale claim | Consequence | Source contract | Evidence / limits | Correction |
|---|---|---|---|---|---|---|
| G1 | 107 | "The browser posts those fields once … streams the bytes once" | Exactly-once implied; a repeated POST or a refused stale link misread | binding lifetime (canonical sentence); current-row check `downloadRoute.ts:288-299`; digest check `:313, 345`; fetch path suppresses a duplicate in flight (`client/src/lib/attachmentDelivery.ts:334`), the native form does not | Task 6 "no exactly-once claim" (queue :333-334); Task 13 S2; retained bytes zero is a fixture observation (queue :376, :410) | "Each POST re-renders from the current row — a current-fact re-render, not an immutable historical replay — and streams one response. A valid binding admits repeated POSTs until it expires (10 min from its signed issue timestamp, checked at admission) while the row it names is still the current row of the same render and the bare render digest is unchanged; a replaced or archived row or a changed printed fact refuses subsequent requests with 409 and revokes nothing already admitted. No repeat is detected or refused as such; no exactly-once or guaranteed-erasure claim is made. The application retains no generated bytes (observed on the fixture only); the binding's digest and the delivery descriptor identify a render, they are not a retained copy. The client's fetch path suppresses a second click while one delivery is in flight; the native form does not." |
| G2 | 107 | Procedure/builder/return lines; fields | — | `routers.ts:4276, 4610, 4639, 4697, 2662`; builders `:1529-1543`; returns `:4596, 4632, 4690, 4740, 2718`; `delivery.fields.binding` `:4571` | — | Re-anchor; add "the form descriptor also carries `binding`". |
| G3 | 108–110 | F1 (8 KB) | 413 at 8,193–8,353 B on the form route misdiagnosed | `_core/deliveryRouter.ts:20-25, 177-187, 189-218, 220-223, 226-237, 240-261` | Task 6 repair (queue :406) | Rewrite the three bullets: guard order unchanged (405, 400, 403, 415, 413); per-route/type caps; four parsers; parser errors 413/415/400, other errors 500 with class-only log; mount order `_core/index.ts:192-197, 201-207, 210-211`; handler map `:250-254`. |
| G4 | 111 | Citations | — | `deliveryRouter.ts:65-71, 258`; `_core/index.ts:87-89, 104-106, 156, 159-160, 122-128`; `_core/originPolicy.ts:89-92` | Browser Origin behaviour is an **unproven deployment fact** in the legend (platform behaviour outside the application) | Re-anchor; keep the browser sentences with that label. |
| G5 | 112 | Fields; 409 ordering; digest scope | Stale-link refusals misattributed | `formBody` `downloadRoute.ts:73-93` (`binding` ≤256); exact-id 404 / foreign-owner 403 `:176-177`; binding refusal 409 (missing, malformed, MAC mismatch, expired, future) after auth/ownership, before the rate unit `:180-186`; unusable key → 500 + report; current-row (stale-link) 409 after the unit `:190, 293-299`; post-render digest mismatch 409 `StaleDeliveryError` + `document_delivery_failed` status 409 `:313, 345, 420-429`; digest covers the bare render, not the final ZIP `:343-345` vs `:353-367`; `exportBody` `downloadExportsRoute.ts:27-35`; `notesBody` `notesExportRoute.ts:40-43` | Task 6; Tasks 7/8 not done | Re-anchor; add the binding field and the three 409 cases with the canonical lifetime sentence; state the digest scope as a retained Task 7/8 limitation. |
| G6 | 113 | Citations only | — | `downloadRoute.ts:6-7, 347-350, 384-386, 396` | — | Re-anchor. |
| G7 | 114 | F2; provenance lines | Letters audit misread as absent | `routers.ts:4625-4631`; `db.ts:1139-1156`; `storageKey: ""` at `routers.ts:1427, 4582, 4669`, `affidavitHistory.ts:457`; activation `:417-428`; package helpers `routers.ts:4718, 4722` | Task 5 | Rewrite. |
| G8 | 115 | F3 | Operators treat a 500 as "nothing saved"; reviewers believe audits can silently drop | `db.ts:1082-1156` (`GenerationEffects`, `assertGenerationWriteAcknowledged`, `writeGenerationEffects`, `commitGenerationEffects`), single `:1206`, batch `:1279`; `documentGeneratedAuditRow` `affidavitHistory.ts:537-539` at `routers.ts:4588-4592, 4681-4685, 4731-4735`; `exportGeneratedAuditRow` `:574-576` at `routers.ts:4628, 4680, 4730, 2700`; detail keys `:526-533, 566-570`; no digest for `estate.export` `routers.ts:2696-2700` | Task 5 acceptance; lost-COMMIT-ACK rule (`db.ts:1088`, prompt §5) | Rewrite: required audit/activity rows commit atomically with the provenance row where one is written (`db.ts:1206`, `:1279`), and for letters and estate exports under the estate row lock alone (`commitGenerationEffects`, `db.ts:1140-1156`); "could not be confirmed" is not "nothing was saved" and not a safe automatic replay; `recordDocumentGenerated`/`recordExportGenerated` are compatibility recorders with no non-test caller; the `exported` timeline activity stays best-effort. |
| G9 | 116 | `inputsHash` definition; citations | — | `deliveryRouter.ts:131-137`; `affidavitHistory.ts:491-502`; `downloadRoute.ts:384-401`; `downloadExportsRoute.ts:120-141`; `deliveryInputsHash` `formDeliveryBinding.ts:46-52` excludes `attemptId` **and** `binding`; keys `downloadRoute.ts:392-398`, `downloadExportsRoute.ts:127-132`, `deliveryAttempt` `deliveryRouter.ts:108-128`; `retryOf` map `:98-101, 121-127` process-local, keyed `userId:attemptId`, shared by all three routes | — | Re-anchor; fix the hash definition; add "process-local, per replica"; note notes is gated the same way with a 10 s wait. |
| G10 | 117 (first half) | Citations; failed cases | — | finished/aborted `void` (`downloadRoute.ts:404`, `downloadExportsRoute.ts:144`); failed awaited, answer ignored (`:423`, `:162`); keys whitelist `affidavitHistory.ts:591-606, 610-621`; "never proof of receipt" `deliveryRouter.ts:142`, `affidavitHistory.ts:626` | — | Re-anchor; add that a digest-mismatch 409 also writes `document_delivery_failed`. |
| G11 | 117 (end) | F4 | Audit reviewers look for no notes trace | see §5.3 N1 | Task 10/11 | Replace with a pointer to the new notes section. |
| G12 | 118 | "one fixed sentence" | — | `renderDeliveryError` `deliveryRouter.ts:75-96`; `FIXED_SENTENCES` `:45-57` (20 entries incl. three notes sentences `notesExportLimits.ts:16-18`); page shows the sentence only if fixed, else `PAGE_SENTENCES[status] ?? OTHER_PAGE_SENTENCE` | Task 11, 14 | Rewrite; list the sentences or cite the set. |
| G13 | 119 | F5 | Audit correlation by release fails for notes; binding scope misread | `docgen.ts:6618` default `1.0.0` (TRUE); `notesExportRoute.ts:245, 252`; `formDeliveryArtifact.ts:19-62` (bundle hash in production; source hash of `server/`, `shared/`, schema, `package.json`, lockfile otherwise; cached per process) | Task 6 SEC-2 (set `GENERATOR_RELEASE` per deploy) | Rewrite. |
| G14 | 120 | Bucket scope; ordering | Notes/estate.export admission misread | `_core/trpc.ts:150-161, 215-226` (8 per 60 s per user, fixed window, in-memory, process-local); shared by `document.generate`, `generatePackage`, `generateAllLetters`, `generateAllP8`; not the `estate.export` mutation, not notes; spent at `downloadRoute.ts:190` (after the binding check) and `downloadExportsRoute.ts:97` (after the busy check); `downloadLimiter` 200/60 s per IP `_core/index.ts:182-190`; `usersBuildingInMemory` `downloadExportsRoute.ts:43-45, 90-93, 98-104`; suspended 403 `:105`, `:69`, `notesExportRoute.ts:188` | — | Re-anchor; add scope and "process-local". |
| G15 | 121 | Citations; unbound exhibit | Reader assumes the exhibit is bound | `p9ExhibitP1Row` `routers.ts:1436-1441`, `renderP9ExhibitA` `:1443-1466`, callers `:4497, 4511`, `downloadRoute.ts:310, 359`; `renderSha256` is the bare P9 render `routers.ts:4478-4479`, `downloadRoute.ts:343-345, 356-361`; fields carry no P1 row id `routers.ts:4553-4569` | Approved output behaviour 2 (preserved); Task 7 not done | Re-anchor; add: "Nothing binds the exhibit's P1 identity, bytes or ZIP container (Task 7, open)." |
| G16 | 122 | Activity now transactional | — | `routers.ts:4536, 4629, 4687`; `db.ts:1120`; `package_generated` `:4737`; `exported` best-effort `:2704-2717` | Task 5 | Rewrite. |
| G17 | 123 | Bulk archive path | — | `replaceGeneratedDocumentRecord` `affidavitHistory.ts:340-359` → `db.ts:1196`; `replaceGeneratedDocumentRecords` `:365-393` → `replaceCurrentDocumentsBatch` `db.ts:1222-1288`; no-migration rule `storageProvider.ts:167-171` | Tasks 16/4 | Re-anchor; "keep their bytes" classed as source inference with the scope sentence "no migration path exists in code; not re-verified against stored objects". |
| G18 | 124 | Rule 29 span | — | `RULES.md:1966-1980` | — | `1966-1980`. |
| G19 | 109–110 (new bullet) | Auth vs guard undocumented | Bearer path misread as a CSRF gap | guard never reads `Authorization`; auth inside the handler after the parsers (`downloadRoute.ts:102`, `downloadExportsRoute.ts:66`, `notesExportRoute.ts:183`); `_core/sdk.ts:298-317` cookie first, Bearer only with no cookie token; an invalid cookie never falls back (401); `credentialedBrowserOriginGuard` acts only with Origin + a session/portal cookie (`_core/originPolicy.ts:89`) | Task 9; `server/deliveryBearerAuth.test.ts` | Add. |

### 5.3 Material absent today (new sections; D3 decided: all six)

| Ref | New section | Silence today → consequence | Content (each ≤14 bullets; every bullet cites `file:line`) | Source contract | Limits to carry |
|---|---|---|---|---|---|
| N1 | Notes export: audit and limits (Tasks 10/11) | The doc says notes writes no audit event (F4); an audit reviewer looks for no notes trace and an operator has no notes limits to size a deployment | events and order; byte gate "exactly `true`" (`notesExportRoute.ts:239-246`); 10 s ACK wait → 503 "…could not be confirmed…" and one late `notes_delivery_failed`/`start_ack_timeout` (`:247-254`; `notesExportLimits.ts:272-294`); a 503 "could not be confirmed" can coexist with a durable `notes_delivery_started` row (lost ACK), and a started row with no terminal row means "outcome not recorded", not "not delivered" (Task 10 L2, queue :589-590); refused ACK → 503 + one staff report (`:256-262`); finished/aborted/failed selection, best-effort (`:112-126, 131-148, 264-268`); 300 s send deadline (`:267-268`; limits `:301-333`); no `notes_delivery_*` row for pre-render refusals or a thrown render (`:269-276` → 500 + report), the foreign-estate `idor_attempt` row being the one exception (`:154-163, 213-216`; 404 alias / 403 exact `:205-219`); limits table (`notesExportLimits.ts:38-55`: leases 3/process, 2/account; 60 s fixed window; 12 admitted/account, 30/process; render 15 s/process, 6 s/account; 1,000 tracked accounts; 15 s pre-render deadline from handler entry `:170`; input caps 500,000 UTF-16 units, 20,000 breaks, 1,000-unit segment, Σ L² 10,000,000 → 413); order of checks (auth takes no lease `:182-184`; process lease `:195-196`; account gate `:197-199`); render time charged after rendering (`:233`); body 8,192 (`_core/deliveryRouter.ts:185`); per-IP limiter applies (`_core/index.ts:190`); `documentGenerationAllowed` does not (its only callers `downloadRoute.ts:190`, `downloadExportsRoute.ts:97`) | own reads + tracer | **Process-local per replica** (`notesExportLimits.ts:2`); **no cancellation** ("cancels nothing" `:6-7`; `settleWithin` cancels no SQL `:246-248`; only `res.destroyed` at send time → aborted `:131`); a tracked promise that never settles keeps its lease (503 busy); first-come process caps: two stalled readers hold all three leases and a few accounts can exhaust the process rate or render window, notes export only (queue :691-692); audit rows are append-only, only creation is rate-bounded, retention open (queue :702); L2/L3/F1/O1 by link (queue :589-596, :697-699); Task 11 "still open" list by link (queue :689-710) |
| N2 | Staff failure reporting (Task 15) | The doc never mentions staff reports; a reviewer expects one row per failure or confuses report limits with generation admission | at most one attempt per eligible invocation: the attempt is claimed before the row is built and stays claimed if preparation throws (`exportFailureReporting.ts:102-107, 123-126`; `routers.ts:2682-2684`); eligible: faults, `report:true` refusals and explicit gate categories; `PublicTRPCError` always `report:false` (`failureReporting.ts:64-69`); the write is best-effort and bounded three ways: callers never wait (`notesExportRoute.ts:259-260, 274-275`; `downloadExportsRoute.ts:138-139, 169-170`; `routers.ts:2684, 2721-2723`), a 1,000 ms settle bound (`:33, 176`), at most 2 unsettled writes per process (`:35, 157`); 8 rows per user per **sliding** 60 s window: admitted timestamps are filtered to the last 60,000 ms on each check (`:65-70`); tracked users are capped at 5,000 and the least-recently-used window is forgotten past the cap (`:71-72`; process-local, "a fleet-wide budget needs shared state"); saturation is checked before the per-user window (`:156-158`); `saturated` and `rate_limited` are logged, not written and not counted; outcomes: acknowledged, unconfirmed, timed_out, failed, saturated, rate_limited (`:30`); the reservation is released when the write settles however late, and a settlement after the bound logs one of late_acknowledged, late_unconfirmed, late_failed instead of a second answer (`:178-191`); "acknowledged" means the writer's normal answer matched the row's nine fields, not a durable commit (`:14-16, 130-141`); nothing is retried and the wait bound cannot cancel the SQL (`:13-16`); log fields `ref, op, code, outcome, failure` only, never exception text, SQL, request or document content (`:144-145`) | own reads of `:1-42, 56-95, 96-198` | not one row per failure; reporting limits are separate from, and never gate, generation, export or notes admission, retries or Generate anyway (Amendment A1, queue :424; the counters are read only inside `exportFailureReporting.ts`); Task 15 browser gap by link (queue :426; `.work/hybrid-remediation/task15/claude-pass01/browser-check-pending.md`) |
| N3 | Client delivery transport and feedback (Tasks 9/13) | The doc describes only a native form POST; an operator treats a browser handoff as receipt and does not know the Bearer fetch path, its ceilings, the rotation caveat or how stored-file reads authenticate | decision rule: native form iff no stored fallback token (`client/src/lib/attachmentDelivery.ts:335-341`; the native branch `:336-341` makes no session comparison); token source `client/src/lib/fallbackSession.ts:9-26`; a cookie tab can hold a token via `X-Rotated-Session` (`attachmentDelivery.ts:10-11`; `client/src/lib/trpcLinks.ts:22-25`); token in `Authorization` only (`:477`), body = fields + `attemptId` (`:473, 478`), same-origin path, no query/hash (`:72-74`), `credentials: "include"`, `redirect: "manual"` (`:481`); ceilings 512 MiB ZIP / 64 MiB DOCX / 64 MiB PDF, 64 KiB refusal, 900 s headers / 60 s idle / 1,800 s total (`:34-38`); native path has no ceiling (`:33`); `sameSession` after headers, per chunk, before handoff (`:81-83, 454-457, 490-493, 520`); response checks (`:488-519, 570-578, 622-627`); pending lock vs 2 s native disable (`:130, 334, 352-353, 113-119`); "download requested" / "preparing" / "download started" (`:339, 359, 367`); the preview modal's DOCX download is the one caller that always uses a fetch, with the JSON envelope, no toast and no control, and with no stored token that fetch carries only the cookie session (`:397-403`; `client/src/pages/EstateDetail.tsx:7497-7503`, "a handoff, not a saved file"); Object URL at handoff, revoked after 120 s (`:660, 670`; "bounded cleanup policy, not a guarantee" `:39`); one sentence with the four-way distinction: server write finish (bytes handed to the transport, `_core/deliveryRouter.ts:142`) ≠ browser handoff (`attachmentDelivery.ts:16-17`) ≠ disk save ≠ recipient receipt; stored-file reads: GET `/manus-storage/*` answers 307 to a short-lived signed URL with `private, no-store`, and because a navigation cannot carry `Authorization`, retained-file reads need the cookie session even though `sdk.authenticateRequest` accepts Bearer (`_core/storageProxy.ts:28, 53-61`; `_core/sdk.ts:298-317`; Task 9 plan :364) | Task 9/13 final-status; own reads | "handed-off" ≠ saved ≠ received (`:16-17`); Chromium-only evidence; mobile/WebView unverified; chatbot rotation moving cookie tabs onto fetch (queue :453); runtime `message` listener OPEN (queue :454); no developer console trail: a client-side delivery failure shows the generic sentence and leaves no trail, and on that delivery path no token, raw body or private error text is logged (queue :451, :602 — the rule as applied to this path, not a global logging assurance); the development debug collector reads whole bodies in dev/Preview builds — the OPEN Dev/Preview body-redaction decision, stated by link to queue :450 and :784 rather than by collector line cites (panel I-2) |
| N4 | Preview transport and session partition (Task 12) | The doc is silent on the preview; a reader assumes previews share the batch link and have no byte bound, or that Escape cancels server work | constants 4,194,304 B (provisional per the source comment `client/src/lib/previewTransport.ts:13`; headroom measured on one fixture sample only) / 16,384 B / 15,000 ms / 60,000 ms (`:14-20`); transport 10 s header timer, 2 retries at 1.5 s / 3 s (`client/src/lib/trpcTransport.ts:1-2, 56`); only `document.preview` queries travel unbatched (`client/src/lib/trpcLinks.ts:72-74`; installed `client/src/main.tsx:40`); decoded byte count is the only size authority (`previewTransport.ts:89-90`; Content-Length never read); payload validated before the query resolves, never a cache success (`trpcLinks.ts:31-46`; `previewTransport.ts:150-154`); data gated on non-error (`EstateDetail.tsx:7436`); options `:7426-7433` incl. `queryKeyHashFn` = `hashKey([key, clientSessionGeneration()])` (`previewTransport.ts:161-163`) and `abortOnUnmount`; retries: envelope errors ≤3, client causes terminal (`:111-114`); physical (fetch) cancellation happens only when the last observer of the exact query key + session generation unsubscribes (`subscribed: open`, `trpc.abortOnUnmount`), sibling queries and other keys are not cancelled (queue :770 "sibling traffic completes during a held preview"); this is React Query observer semantics, not an application guarantee, and never cancels SQL or rendering | Task 12 final-status §3, §9 | browser abort ≠ server cancellation (no abort consumed; mysql2 no abort); ceiling bounds what the app reads, not what the link delivers; P8 verbatim from Nick's decision 2 (post-final-check window, cross-tab logout, server expiry/revocation, no-reload account change open; only this tab's logout `client/src/_core/hooks/useAuth.ts:47-48` or deletion `client/src/pages/Settings.tsx:369-371` bumps the generation); offline retry resumes online **and focused**; no preview-owned Object URL, but `createObjectURL` exists at `client/src/lib/attachmentDelivery.ts:660`, `client/src/pages/EstateDetail.tsx:3505, 3740, 6234`, `client/src/components/chatbot/botClient.ts:233`; `handleSavePdf` uses jsPDF `doc.save` (`EstateDetail.tsx:7685`; library internals unverified); the largest measured envelope is cited by link only (queue :765; Task 12 final-status §6), one sample, not headroom (D8); outstanding tests/measurements verbatim (queue :822-824) |
| N5 | Form-delivery binding (Task 6) and what is not bound | §6 predates Task 6; a reader does not know what a form delivery is bound to, how long a link lives, or that exports and exhibits are not bound | format `fdb1.<issuedAtMs>.<renderSha256>.<mac>` (`formDeliveryBinding.ts:34`); the canonical lifetime sentence (10 min from the signed issue timestamp, 60 s future-skew refusal, checked once at admission; `:30-31, 113-114`; `downloadRoute.ts:180-186`); key via HKDF over `ENV.cookieSecret` read from the process environment on each call, no fallback (`:55-58`); MAC covers the domain, `userId`, the composite release fingerprint, `issuedAtMs`, the fields digest (`deliveryInputsHash`) and the bare render digest (`:46-52, 61-65`); issued at `routers.ts:4571`, verified after ownership before the budget (`downloadRoute.ts:180-186`); outcomes (G5); the canonical revocation sentence (subsequent requests refused; nothing admitted revoked; secret/release/fingerprint changes act per serving process; no containment step prescribed); the binding's digest and the delivery descriptor identify a render; they are not a retained copy of the bytes | Task 6 pass01/repair01; own reads | snapshot admission: no final-byte re-check, no cancellation, no exactly-once (queue :333-334 — stated by the approved plan, a decision record, not by a code comment); digest excludes the ZIP container and Exhibit A (G15); INT-1 TiDB row-order 409 risk (queue :414); INT-2 repaired in `manus-repair01` (queue :406): the pre-binding 8 KB field budget is unchanged, so descriptors near 8,192 B of fields still 413; SEC-2; frozen `docgen.ts` regex issues; Node 24 8 MiB attribute-run 500 (queue :383-397); Task 6 unaccepted; Tasks 7 (exhibit/container) and 8 (export-preparation binding) not implemented — export deliveries verify no binding |
| N6 | What this note proves (reader's key) | Without a legend a reader cannot tell a code fact from a fixture observation or a deployment assumption | one legend, used verbatim here and in final-status §3: **source inference** (every `file:line`), **historical local observation** (the `.work/` receipts: headless Chromium on one workstation, native MySQL fixtures; each cited with receipt path, receipt sha256 and whether its recorded source hash equals the pinned hash), **injected test**, **estimate**, **unproven deployment fact** (IAM, KMS, bucket state, AWS and browser platform behaviour); a decision-record statement is cited to its queue line and labelled as such; Canadian AWS storage ≠ Canadian-only processing, PIPA/LSBC compliance or a completed rollout (`RULES.md:1893-1896` Rule 26, `:1978-1980` Rule 29); **the target remains the Manus application plus a Canadian AWS database plus the Canadian AWS S3 vault; this patch proves neither the migration, the connection nor the deployment**; Task 19 blocked | prompt §5/§6 | Word/pixels user-deferred-not-passed; Task 14 STILL-BLOCKED; Tasks 7/8 not reopened; no AWAITING-NICK item resolved |

## 6. Edit map — `references/file-storage.md` (D1(a), D2 default — decided)

Structure: re-anchor the existing note **in place**, heading becomes "Hybrid vault compatibility note (2026-10-19,
re-anchored 2026-10-20 and 2026-10-27)"; the preamble gains the citation legend (§5) and **one pin line** naming paths
only, no hash: "Citations are current for the 2026-10-27 working tree at HEAD `db0d7e91…`; the cited files include
untracked modules, so HEAD alone pins nothing; the per-file hashes of every cited source are in
`outputs/task17-documentation-report-<date>.md` and `.work/hybrid-remediation/task17/claude-pass01/manifest.sha256`"
(a hash inside the doc would have to be computed from a manifest that itself hashes the doc; §11 B9 fixes the order).
Keep the original template text (lines 178–315) unedited; extend "Superseded statements". The 2026-10-20 text survives in
`claude-pass01/before/file-storage.md`. **Insertion point** for the six new sections: after §9 "Phase 2 safeguards"
(current :151) and before "Deployment preconditions" (:153), numbered §10–§15, so the preamble can say "Sections 5, 6 and
10–15 describe the implemented code" and the Superseded list (:163-176) stays where it is.

| Part | Edit | Rows |
|---|---|---|
| Heading + preamble (:11-13) | third date; citation legend; one pin line (paths only); "Sections 5, 6 and 10–15 describe the implemented code" | — |
| §1 Configuration (:15-33) | citations only (`_core/index.ts:64-67`, scripts' gate lines) | S10, S11 |
| §2 Roles (:35-43) | citations (`storageRegistry.ts:1672`); presign qualifier | S10, S11 |
| §3 Bucket proof (:45-82) | citations (`_core/index.ts:55, 59, 65-67`) | S10 |
| §4 Read routing (:84-94) | rewrite the table's three rows; replace the dead symbol; add the gate bullets | S1, S2, S3 |
| §5 Private writes (:96-103) | rewrite the preview/proxy sentence; callers list; citations; key-privacy qualifier | S4, S10, S11 |
| §6 Generated documents (:105-124) | rewrite lines 107, 108–110, 112, 114, 115, 117, 118, 119, 120, 121, 122; re-anchor the rest; add the auth bullet | G1–G19 |
| §7 Minimum IAM (:126-137) | one labelling sentence; citations unchanged (verified) | S9 |
| §8 Still unproven (:139-141) | extend with the unproven list | S9 |
| §9 Phase 2 safeguards (:143-151) | delete the drift bullet; replace with the refusal rule; citations | S5, S10 |
| **New §10–§15** (inserted after :151) | §10 client transport (N3); §11 binding (N5); §12 notes (N1); §13 reporting (N2); §14 preview (N4); §15 reader's key (N6) | N1–N6 |
| Deployment preconditions (:153-161) | citations; **new item 8** (database engine; cites `.work/hybrid-remediation/task03/database-lock-compatibility.md` by exact path; labelled code-enforced, production-unverified) | S8, S10 |
| Superseded statements (:163-176) | fix 167, 169, 172; rewrite 175; nothing from the re-anchored note is listed (D1(a)) | S6, S7 |
| Template text (:178-315) | **unchanged**; B6 proves each protected block byte-identical | — |

Estimated size: +110 to +140 lines (new sections) and ~120 citation edits; the file stays one document.

## 7. Edit map — other docs (D4 decided: O1 yes; O2 yes as corrected; O3 in place; O4 no)

| Ref | File | Stale claim → consequence | Edit (source contract) |
|---|---|---|---|
| O1 | `docs/operations/storage-provider-due-diligence.md:60` | `pnpm storage:validate` → an operator runs a script that does not exist | "`pnpm storage:validate` passes" → "`pnpm storage:validate-provider` passes" (`package.json:17`). Nothing else. |
| O2 | `docs/runbooks/storage-incident.md` §4.2 "Credential or token compromise" (after its last bullet, :78) + one cross-reference sentence at §3.B item 4 (:50) | "expire/revoke where supported" names no mechanism → an incident lead does not know what refuses later requests, what cannot be revoked, and that nothing revokes an already-admitted response | Dated sub-list "What can be expired or revoked (implemented state, 2026-10-27)", ≤4 bullets, **each limitation beside its claim**: (1) a presigned storage GET URL is requested for ≤900 s (default 300 s; `server/storageProvider.ts:40-42, 566-569`); the application has no per-URL revocation, and whether AWS honours a URL after signing-credential rotation or a bucket-policy deny is platform behaviour, unproven here; (2) a form-delivery binding expires 10 min after its signed issue timestamp, with a separate 60 s future-skew refusal that adds no lifetime, checked once at admission (`server/formDeliveryBinding.ts:30-31, 113-114`; `server/downloadRoute.ts:180-186`); row replacement or archive by a later generation and a changed render digest refuse **subsequent** requests that observe them (`server/downloadRoute.ts:288-299, 313, 345`) and revoke nothing already admitted; changing the session secret, `GENERATOR_RELEASE` or the build fingerprint invalidates bindings only in serving processes that have loaded the new value, including old workers only after restart (`formDeliveryBinding.ts:55-58`; `server/formDeliveryArtifact.ts:57-61`); this describes behaviour and prescribes no containment: regenerating documents or editing database rows is not a procedure; (3) the Bearer fallback is a server session, revoked server-side; a tab's own generation changes only on its own logout or account deletion (`client/src/lib/fallbackSession.ts:38-46`), so server-side revocation does not clear a tab's stored token by itself; (4) pointer: the acknowledged-before-send `*_delivery_started` trace (an exact `true` recorder answer; finished/aborted best-effort; Task 10 L2), generated-byte non-retention and descriptors carrying no token are described in `references/file-storage.md` §6 and §10–§15. The §3.B.4 sentence: "See §4.2, implemented-state addendum." No other runbook line changes. |
| O3 | `docs/architecture/rule-10-conformance-baseline.md:34` (§3 table row "Fail-closed document authorization") | Evidence cell names a function with no non-test caller → a reviewer audits the wrong gate | Evidence cell → "`server/db.ts` `findAccessibleStoredObject(userId, storageKey)` plus `server/storageRegistry.ts` `withReadableStoredObjects` with a server-resolved read context (as of 2026-10-27; `userCanAccessStorageKey` remains in `server/db.ts` but has no non-test caller)". The dated parenthetical is mandatory. Contribution cell unchanged. §2 decisions untouched. |
| O4 | checklist, blueprint | — | **Decided: no edit.** |

## 8. Protected portions (never edited; B6 proves them byte-identical)

file-storage.md lines 1–9 (template warning with the LSBC Rule 10-3 "uncaptured citation" caveat), 57–80 (deny-only
policy JSON, verified TRUE), 178–315 (original template text and LSBC/AWS links); every legal reference, capture and
authority text; `RULES.md`, `.cursorrules`; all source, tests, schema, config; queue and predecessor records; the Task 17
preferences file. No new Rule 29 exception is described; the four approved output behaviours are named only as preserved
(G15). No compliance, residency or "Canada-only" wording is added (RULES.md Rule 26 bullet 4; checklist §8).

## 9. Carried-forward limitations (verbatim pointers, all retained)

Word/pixels user-deferred-not-passed (queue :404, :430); mobile/WebView unverified (:442, :491, :511); Task 15
real-browser gap (:426, :456; `task15/claude-pass01/browser-check-pending.md`); Task 6 limits INT-1, SEC-2, frozen-regex,
Node-24 (:383-397, :414) with INT-2 recorded as repaired in `manus-repair01` (:406) while the pre-binding 8 KB field
budget stands; Task 14 STILL-BLOCKED Word render (:310; `task14/claude-pass01/STILL-BLOCKED.md`); Tasks 7/8 not reopened
(:432); Task 13 preview microtask gap P9 and S2 residual (:515-516); rotation/runtime `message` listener OPEN (:454,
:513); Dev/Preview delivery-body redaction OPEN before real client data (:450, :512); no developer console trail (:451,
:602); chatbot cookie-to-fetch rotation (:453, :514); Task 10 L2/L3/F1 (:589-596) and Task 11 NEL/O1 (:697-699); notes
first-come process caps (:691-692); audit storage grows, retention open (:702); Task 12 P8 cases and outstanding
tests/measurements (:820-824); duplicate `FetchLike` declarations and the two error classes left alone (:825); deployed
policy evidence (Task 19, :63). None is resolved by Task 17; none is reworded into a pass. B7's dropped-limitation hunter
checks every pointer above appears in the after-text with its queue line.

## 10. Decisions (Gate A) — decided by Nick, 2026-10-27 (§15)

| # | Decision | Decided |
|---|---|---|
| D1 | Structure of file-storage.md | **(a)**: re-anchor in place, preserve the original (`before/` copy); one pin line naming paths, no in-doc hash table. |
| D2 | Citations | **Default**: re-anchor every `path:line`; B3 checks them mechanically, B7/B8 semantically. |
| D3 | New sections N1–N6 | **(a)**: all six. |
| D4 | Other docs | O1 yes; O2 yes with the §15 corrections; O3 in place with the dated parenthetical; O4 no. |
| D5 | Precondition 8 (database engine) | **Yes**, clearly labelled code-enforced and production-unverified. |
| D6 | Handoff paths | **Yes**: `outputs/task17-documentation-report-<Gate B date>.md` + `claude-pass01/final-status.md`; plan at `docs/superpowers/plans/2026-10-27-task17-accurate-documentation.md`. |
| D7 | Gate B review method | **Default** (§11 B7). |
| D8 | Gate counts in the docs | **(a)**: no gate-count recital in the technical documentation; measured values by link only with the one-sample label. |
| D9 (opened at the Gate A save; awaiting Nick) | Root `README.md` "Local development — file storage" paragraph: (a) at Gate B B0 verify the MinIO dev-default claim against `_core/env.ts` read-only and, only if stale, correct that one paragraph as a fifth docs-only target under the same B-step controls (before copy, census, citation check, protected-block equality); (b) leave the README untouched. | **(b) until answered.** Choosing (a) adds one target to §3, §6 and B5. |

## 11. Verification (Gate B, only after a separate explicit go-ahead)

- **B0 Identity and baseline.** Branch/HEAD as §2. Recompute every hash in `before-hashes.json` (the 70 files, the test
  tree digest, the cited-file set) and compare with Gate A: **stop on any difference, including the four edit targets**
  (their line locators in §5–§8 are Gate A numbers). Re-glob the four target folders for `CLAUDE.md`/`AGENTS.md`/`README.md`;
  stop if one appeared. Confirm no fixture, service, browser, Office or gate runner is started at any step
  (`run-gates.cjs:12-18` creates `gates/<label>` before its `.env` refusal, so even a refused invocation consumes a label).
  Save `porcelain-b0.txt` and the stash count. `citations.json` (frozen at Gate A, hashed) is the only anchor source.
  Expected status at B0: everything equals Gate A.
- **B1 Before.** Prove `sha256(before/<file>) == Gate A hash` for each of the four targets; no re-copy.
- **B2 Edits.** Edit tool on the four targets only, per §5–§7, §10 and §15, batched by paragraph (~20–30 calls on
  file-storage.md, each `old_string` unique); after each file's batch a Node EOL census (uniform CRLF, no lone CR, BOM
  unchanged, final terminator unchanged); a flip is repaired by rewriting the bytes with the original terminator before
  continuing. `git diff` cannot show a CRLF flip (no `.gitattributes`; `core.autocrlf` unknown): the census is the only EOL
  evidence. Expected status after B2: only the four targets differ from Gate A.
- **B3 Citation check — mechanical only.** It proves that every cited path resolves, every range is in bounds and every
  anchor occurs there, across **all four documents**; it does not prove a semantic verdict, which stays with B7 (three
  lenses) and B8 (the claim and limitation table). Read-only Node script, saved with its sha256 and command line. Grammar:
  inside backtick code spans only, `PATH:LOC(, LOC)*` with `PATH=[A-Za-z0-9_./-]+\.(ts|tsx|js|cjs|md|json|sql)`,
  `LOC=\d+(-\d+)?`; `;`-separated spans inside one parenthesis; the symbol-first form "`sym`, `path:loc`". Resolution:
  (1) literal repo-root path, (2) `server/` + path; both exist → AMBIGUOUS; neither → UNRESOLVED; never a basename search.
  Line model: read bytes, split on `\n`, strip one trailing `\r`, never split on a lone `\r`, ignore a BOM (reproduces
  Read/rg numbering on the mixed-EOL files; verified on `routers.ts:4625/2697` and the `db.ts` symbols). Checks:
  `a ≤ b ≤ lineCount`; the anchor from `citations.json` (symbol, or a quoted fragment for symbol-less lines such as RULES.md
  bullets) must occur as an exact substring within `[a,b]`; a range over 40 lines needs an end anchor or is REVIEW.
  Statuses: OK, MISS, UNRESOLVED, AMBIGUOUS, OUT_OF_RANGE, REVIEW. Run twice: against `before/` (the DRIFT baseline, kept)
  and against the final `after/` snapshots (zero MISS required). Every MISS, including on
  `RULES.md`/`.cursorrules`/`docgen.ts`/`types.ts`/`schema.ts`, is fixed only in the doc. The report lists per citation:
  doc file:line, raw text, resolved path, status, matched line; totals; and the cited-file set with sha256 (feeds B5).
- **B4 Links and anchors.** Every relative path in the edited docs exists (including the `.work/…/task03/…` and
  `task15/…` paths named in §5); headings unique within each doc; no external fetch; no linked script executed.
- **B5 Source preservation.** Preserved set = (70-file list ∪ cited files ∪ every path named in `tracer-reports/` ∪ the
  test tree) **minus the four approved documentation targets**: every hash equal to Gate A. The four targets are verified
  separately: `before/` hashes equal Gate A (B1); the after bytes differ from `before/` only by the approved diff (B6,
  reviewed against §5–§7 and §15); EOL census (B2); protected-block equality (B6). Porcelain: `git diff --cached` empty;
  stash count unchanged (1); set difference exactly the three clean docs → ` M`, `references/file-storage.md` still ` M`,
  and the allowlisted `??` additions (the saved plan, `.work/hybrid-remediation/task17/` as a whole,
  `outputs/task17-documentation-report-<date>.md`); any other delta → stop. Intervening pass-dir files (B3 reports, B7
  reviewer outputs, `after/`) are preserved, never deleted.
- **B6 Diff and protected blocks.** `git diff -- <four docs>` saved as `docs-only.diff` with a line summary. Node byte
  check: each protected block of §8, taken as exact bytes from `before/file-storage.md`, occurs exactly once in the edited
  file; each of the other three docs minus its one line/row/addendum is byte-identical to `before/`. A grep of the
  after-text for constrained words (exactly once, guaranteed, immutable, comprehensive, compliant, Canada-only,
  Canadian-resident, residency, SHIP, accepted, passed, verified in production, revoke) lists every hit with its sentence;
  the overclaim hunter starts from that list.
- **B7 Independent review (D7 default).** After B3 and B5 pass, three read-only lenses on the final bytes: an overclaim
  hunter (reads the full before/after of the four docs, not only the diff); a dropped-limitation hunter (mechanical duty:
  every §9 pointer present in the after-text with its queue line); a probate-integrity gate briefed for **this
  worktree's** `RULES.md` (hash recorded; the house skill loads the main checkout by default), the docs-only diff, and
  exactly the prompt §3/§5 checks (no new Rule 29 exception; no Rule 26 compliance/residency wording `RULES.md:1893-1896`;
  warn-only Generate anyway not reworded as a prohibition; the four approved output behaviours named only as preserved);
  absent runtime artifacts are expected, not a gap. Inputs: `docs-only.diff`, `before/` and `after/` copies,
  `impact-matrix.md`, `before-hashes.json` + the B3 cited-file hashes + the B3 report, the prompt §5 table, §9 and §15
  verbatim. Forbidden: Bash, edits, tests/app/runner, `.env*`, each other's output, any verdict vocabulary beyond
  findings. Each lens's model id and input hashes are recorded; each finding is dispositioned (fixed in doc / disclosed /
  rejected with reason) in final-status §8. Semantic claim and limitation review is this step and B8, not B3.
- **B8 Claim table.** final-status §3: claim → current source → evidence class (the single §5.3 N6 legend: source
  inference / historical local observation / injected test / estimate / unproven deployment fact) → limitation, with the
  pinned hashes; every historical-local-observation row carries receipt path, receipt sha256 and whether the receipt's
  recorded source hash equals the current pinned hash.
- **B9 Handoff and artifact-hash order.** (1) write `after/` copies of the four docs and every other artifact; (2) write
  `manifest.sha256` listing every pass-dir file except itself, `final-status.md` and the report; (3) `final-status.md`
  cites the manifest's hash and the `after/` hashes; (4) `outputs/task17-documentation-report-<date>.md` cites
  `final-status.md`'s hash; (5) the report's own hash and the manifest hash appear in the handoff message and in the
  drafted queue entry. No file contains its own hash. Contents: inventory, diff, claim table, corrections and deferrals,
  commands actually run, source-preservation result, current disposition ("implemented, NOT accepted"), the drafted queue
  entry (not appended), approvals needed. **Stop.**

Budget: B0–B9 are documentation and read-only checks only; nothing in this task runs the application or a test.

## 12. Design-panel dispositions (Gate A, Workflow `wf_3fc6a6df-403`, 2026-10-27)

Three read-only Plan lenses over r1; verdicts all `sound-with-changes`. Every defect was checked against source regions
already read in this session before acceptance; the two highest-stakes ones (T1 "replayable", T2 "wholesale-only") are
contradicted by `downloadRoute.ts:288-299`, which the session read directly.

| Id | Sev | Finding (short) | Disposition → where |
|---|---|---|---|
| D-1 | med | Census lacks tests and an explicit instruction set | Folded → gate 1(b), §2 census extension, B0/B5 |
| D-2 | low | In-doc 12-row hash table contradicts D8 | Folded → D1(a) one pin line naming paths only |
| D-3 | low | Appending Nick's answers is an unauthorized docs/ edit; §14 collision | Folded → §15 is in the saved text; gate 1(d) |
| D-4 | low | §5.3/§7 lack consequence/stale-claim columns | Folded → §5.3 and §7 column added; §3 is part of impact-matrix.md |
| D-5 | low | O2 location undecided; two off-topic bullets | Folded → O2 at §4.2 + §3.B.4 cross-ref; trimmed to revocation facts + pointer |
| D-6 | low | No target-folder instruction check recorded | Folded → §2 "Target-folder instructions", B0 |
| I-1 | — | Drop S12; trim S11 | Folded → S12 withdrawn (502 quirk stays in §13; proxy auth fact in N3); S11 trimmed |
| I-2 | — | Collector line cites → link to queue :450 | Folded → N3 limits |
| I-3 | — | D2/D7 are defaults, not decisions | Folded → D2/D7 marked default; ids kept for continuity |
| I-4 | — | State the insertion point | Folded → §6 |
| I-5 | — | B1 verify, not re-copy; B0 stops on doc-target drift | Folded → B0/B1 |
| I-6 | — | O3 dated parenthetical mandatory | Folded → O3 |
| T1 | med | "replayable" overstates; "replay 409" mislabel | Folded → G1 rewritten; "current-row (stale-link) 409" in §4/G5 |
| T2 | med | O2 "wholesale only" false; row replacement refuses later requests | Folded → O2 bullet 2 (with Nick's §15 qualification: subsequent requests only; nothing admitted revoked; per-process verifier state; no containment prescribed) |
| T3 | med | N4 lacks final-observer rule / siblings not cancelled | Folded → N4 content |
| T4 | med | Three prompt §5 distinctions missing (re-render ≠ replay; digest ≠ copy; bytes ephemeral) | Folded → G1, N5 |
| T5 | med | Notes L2 in-doc (503 can coexist with a durable started row) | Folded → N1 content |
| T6 | low | §9 missing console trail, retention, first-come caps | Folded → §9, N1, N3 |
| T7 | low | 8,256 B in N4 vs D8 | Folded → by link only |
| T8 | low | "no row for pre-render refusals" vs `idor_attempt` | Folded → N1 wording |
| T9 | low | O3 "no caller" → "no non-test caller" | Folded → O3, §1 |
| T10 | low | INT-2 is repaired (queue :406) | Folded → §9, N5 |
| T11 | low | 4 MiB is "provisional" in source | Folded → N4 |
| T12 | low | G8 "with provenance" true only for single/batch | Folded → G8 |
| I1–I7 | — | issuedAtMs in MAC list; "always" as the named exception; window type; AWS revocation unproven; "durable" → acknowledged-before-send; four-way sentence; native-path session cite | Folded → N5; N3 (resolved by own read: always one fetch, JSON envelope, `:397-403`); N2 (resolved: sliding, `:65-70`); O2; O2/N1; N3; N3 (`:336-341`) |
| V1 | med | B0 must stop on doc-target drift; B1 proves before/ | Folded → B0/B1 |
| V2 | med | Citation resolution rule (shared/ at root; client basenames; never basename search) | Folded → §5 legend, §6 preamble, B3 |
| V3 | med | B5 porcelain expectation wrong (untracked .work/ and outputs/) | Folded → B0/B5 allowlist + stash count |
| V4 | med | Census omits cited files; in-doc pin under-covers | Folded → §2 census extension; B3 emits the cited-file set; D1(a) pin line |
| V5 | low | Protected blocks need a byte check | Folded → B6 |
| V6 | low | One evidence legend; "historical" qualifier; ad-hoc labels | Folded → N6, B8, G4, G17, N5 |
| V7 | low | Integrity-gate skill loads the main checkout; brief it for the worktree | Folded → B7 |
| E1–E7 | — | Checker rules; keep Edit + census, batch edits; reviewer inputs/prohibitions; constrained-word grep; artifact hashes; exact `.work` paths; drop redundant spot check | Folded → B3, B2, B7, B6, B9, S8/B4, B5 |

Panel gaps disclosed and not closed here: no lens re-verified all ~150 verdicts (B3 checks citations mechanically; B7/B8
review semantics); `core.autocrlf` unread (B2 assumes the worst case); the Task 10/11 plans' decision-record placement was
not re-read (Task 12's §11/§14 precedent is confirmed); the integrity-gate `SKILL.md` was read to line 80 only (B7's
brief is explicit regardless).

## 13. Observations outside Task 17 (for Nick; not edited, not resolved)

1. Stale source comments: `_core/index.ts:192-193` ("their own 8 KB bodies"), `downloadRoute.ts:4` ("8 KB JSON or form
   body"), `shared/serverManagedEstateFields.ts:14-16` ("storageGetSignedUrl, which scopes to nothing"). Source is
   read-only under Task 17.
2. `_core/storageProxy.ts` answers 502 (not 404) for a `pending_reference` row: the pre-check admits the state (`db.ts:656`)
   and the registry refuses it (`storageRegistry.ts:229`). Observed in code; not documented (panel I-1), not changed.
3. The shared tRPC transport retries mutations as well as queries on a header timeout or network error
   (`client/src/lib/trpcTransport.ts:62-100` never checks `op.type`); pre-existing, unchanged by Task 12; not a Task 17 matter.
4. In any non-production build the debug collector stores request bodies and the raw first 10,240 chars of large text
   responses (`client/public/__manus__/debug-collector.js:487, 559-562, 619, 647`) — this is the OPEN Task 9 decision,
   restated in N3 by link only.
5. Settled by own read: the notes `started` detail passes the `DeliveryEventDetail` whitelist (`affidavitHistory.ts:591-606,
   610-621`), so `format`, `attemptId`, `retryOf`, `inputsHash`, `estateRevision`, `contentSha256` and `bytes` all reach the
   row and `generatorRelease` is simply absent (F5 stands). No open item.

## 14. What the Gate A save does and does not authorize

Does: gate 1 items (a)–(d) above, then stop and wait. Does not: any edit to `references/` or to any `docs/` file other than
the saved plan, Gate B, the queue entry, acceptance, SHIP, any git/production/AWS/fixture operation, or any other task.

## 15. Decision record — Nick, 2026-10-27 (verbatim) and the "Applied" checklist

> The Task 17 documentation-only scope is sound. My decisions are:
> D1: (a), re-anchor in place and preserve the original.
> D2: Default.
> D3: (a), all six sections.
> D4: O1 yes; O2 yes with the correction below; O3 in-place with the dated parenthetical; O4 no.
> D5: Yes, clearly labelled code-enforced and production-unverified.
> D6: Yes.
> D7: Default.
> D8: (a), no gate-count recital in the technical documentation.
> Before Gate B, make these targeted corrections:
> Correct binding lifetime: it expires 10 minutes from the signed issue timestamp. The separate 60-second allowance tolerates future clock skew; it does not add a minute after expiry. State that expiry is checked at admission.
> Qualify revocation claims: replacement, archive and digest changes can refuse subsequent requests that observe them. They do not revoke an already-admitted response. Put this limitation beside the runbook claim, not only elsewhere. Secret/release/build invalidation depends on the verifier state loaded in every serving process, including old workers. Do not prescribe regeneration or direct database edits as containment.
> Fix B5: exclude the four approved documentation targets from the preserved-source hash union. Verify those four through before hashes, approved diffs, EOL checks and protected-block equality. Make status expectations appropriate to each stage and preserve intervening review files.
> Narrow B3's claim: checking paths, ranges and anchors does not mechanically prove every semantic verdict. Cover citations across all four documents and retain semantic claim/limitation review. Specify final after/ snapshots and an artifact-hash order that does not require a file to contain its own hash.
> Restore the incomplete N2 row: the supplied row stops mid-outcome list. Document the sliding reporting window, tracked-user eviction, at-most-one-attempt/best-effort behavior, late outcomes and no-retry/no-cancellation limits. Reporting limits must remain separate from generation/export admission. Resolve the two open source questions before writing their statements.
> Remove the unsupported "83 cited files are untracked" count, keep logging assurances narrowly scoped, and retain the complete target: Manus application + Canadian AWS database + Canadian AWS S3 vault, without implying deployment or connection is proved.
> This authorizes only the Gate A plan/evidence save and decision-record update. Return the corrected plan and a short correction checklist, then stop. Gate B is not yet authorized. Preserve all existing restrictions, preferences, deferrals and task statuses. No application changes or next task.

**Applied in r3 (each re-checked against source):**

| Correction | Source re-read | Where |
|---|---|---|
| Binding lifetime: 10 min from the signed issue timestamp; 60 s future-skew refusal adds no lifetime; checked at admission | `formDeliveryBinding.ts:30-31, 113-114` (`nowMs < issuedAtMs + TTL`; `issuedAtMs <= nowMs + skew`); `downloadRoute.ts:180-186` | §5 canonical sentence; G1, G5, N5, O2 bullet 2 |
| Revocation qualified beside the claim; nothing admitted revoked; per-process verifier state incl. old workers; no containment prescribed | `downloadRoute.ts:288-299, 313, 345`; `formDeliveryBinding.ts:55-58`; `formDeliveryArtifact.ts:57-61` | §5 canonical sentence; G1, N5, O2 bullet 2, §3 O2 row |
| B5: four targets excluded from the preserved union and verified by before hashes, approved diff, EOL, protected blocks; stage expectations; intervening files preserved | — | §11 B0, B2, B5 |
| B3 narrowed to mechanical path/range/anchor checks over all four docs; semantic review retained in B7/B8; final `after/` snapshots; artifact-hash order with no self-hash | — | §11 B3, B7, B9; §6 pin line names paths only |
| N2 row restored (the r2 cell broke on `\|` characters): sliding window, LRU eviction past 5,000, one attempt/best-effort, late outcomes, no retry/cancel, separate from admission; both open source questions resolved | `exportFailureReporting.ts:65-73, 102-107, 123-126, 156-191`; `attachmentDelivery.ts:397-403`; `EstateDetail.tsx:7497-7503` | §5.3 N2, N3; S8 cell rewritten for the same reason |
| "83 cited files are untracked" removed; logging assurance scoped to the delivery path; full target stated without implying deployment or connection | — | §6 pin line; N3 limits; N6 |
| Found at the Gate A save (not a Nick correction): the repository root has a `README.md` the earlier glob missed; the first saved plan copy was replaced minutes later with this corrected text in the same Gate A save, before any other use | root `README.md` lines 34-49, 60-66 (read-only); vault `CLAUDE.md` grep | §2 "Target-folder instructions"; §3 README row; D9 |

Gate B remains unauthorized. No application change; no next task.

**Gate B go-ahead (2026-10-27).** Nick replied "proceed" (with the standing orchestration and find-skill commands) to the Gate A handoff. Read as the separate, explicit Gate B go-ahead for this plan as decided in section 15; D9 was not answered, so its default (b) applies and the root README.md is not touched. Recorded before the first Gate B edit.


## 16. Closeout record — Nick, 2026-10-27 18:39 PDT (verbatim) and what was done

> Please finish Task 17 as follows:
> Do one bounded read-only review of the last ten wording fragments and their cited source lines. Do not repeat the full application review or start tests, services, browsers or AWS checks.
> Record the citation-check deviation accurately: the original frozen-anchor check did not pass as designed; the replacement check established paths/ranges and limited anchors—not semantic verification of all 444 citations. Preserve the original results. Correct the drafted queue statement that says all three lenses reviewed the "final bytes"; describe the earlier reviews and this final-fragment pass separately.
> D9: leave README unchanged. Keep the MinIO claim unverified. Do not expand Task 17 to a fifth document.
> Do not close the Node 24 residual from inference alone. Leave its specific verification status unresolved unless an existing receipt explicitly identifies the relevant regression, runtime and result. Do not install anything or repair code.
> Add an append-only erratum for the Task 11 lease wording: three stalled requests can occupy three process leases; two requests from one account can occupy that account's two. Cite the implementation and preserve the historical record unchanged.
> If the final-fragment review finds no material issue, I accept Task 17 within its documentation-only scope and authorize you to append the corrected disposition and check its queue row. Record the final review, remaining limitations and current hashes in the closeout evidence. Preserve previous receipts and hashes as historical evidence.
> If it finds a material issue, report it and stop before acceptance rather than silently expanding the work.
> This accepts no other task, clears no deployment/security/compliance blocker, and makes no SHIP claim. No application, test, schema, configuration, renderer, legal-output, AWS or production changes. Nothing staged or committed. Stop after the closeout; do not start Task 18 automatically.

**Done after 18:39 PDT (documentation and evidence only; the closeout receipt is
`.work/hybrid-remediation/task17/claude-pass01/closeout.md`, its hash in the handoff message):**

- Node 24 residual: existing receipts identify the regression (pre-repair `formDeliveryBinding.ts:38-39`,
  `task06/claude-pass01/sdd/review-ff-verdict.md:66-68`), the runtime (Node v24.13.1,
  `task06/manus-repair01/hostile-template-investigation.md:9`; `scanner-verification.json:58-60` for the red
  reproduction) and the result (`scanner-implementation.md:32, 38`: gate exit 0; 7 and 8 MiB unquoted and 8 MiB quoted
  cases without RangeError). `references/file-storage.md` line 179 now states that record with those citations as a
  historical local observation, not a fresh verification and not an inference. No code touched, nothing installed.
- The bounded read-only review (one agent, 20 tool calls, Read/Grep only) covered the four lines reworded after every
  earlier lens: file-storage 120, 179, 188 and runbook 84. It found one issue it classed "material, low severity":
  line 179 attached Node v24.13.1 to the green scanner cases while `scanner-verification.json` records the version only
  for the red reproduction. Verified by own read (`:39-60`) and corrected with the reviewer's minimal rewording plus its
  "standalone copy" precision note; every other fragment holds.
- Citation-check deviation recorded in the closeout receipt as Nick stated it; the original B3 results are preserved
  unchanged (`b3-before.json`, `b3-after.json`, `b3-after-doc-anchored.json`); closeout runs went to new file names.
- The drafted queue statement "three read-only lenses on the final bytes" is replaced in the closeout receipt by the
  per-round description (round one on `777ea2f7…`; the overclaim hunter on `bc1adf26…`; the final-fragment pass on
  `09e25a35…`; the one rewording after it).
- D9: `README.md` unchanged; the MinIO claim stays unverified; no fifth document.
- The Task 11 lease erratum was appended to the queue (append-only; the historical record at `:691-692` unchanged).
- Because the review reported a material issue, acceptance is **not** recorded: the Task 17 disposition is not
  appended, row 61 is not checked, and the closeout stops here for Nick's decision. Nothing staged, committed, pushed,
  checkpointed, published or deployed; no external account created; Task 18 not started.
