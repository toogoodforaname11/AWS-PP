# Client Intake Other-Names Mapping Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Preserve client-reported full deceased aliases in the canonical alias list without incorrectly treating an alias as an AKA first name.

**Architecture:** The portal payload already supplies a full `deceasedAliases` value. The mapper will preserve that value in `estates.deceasedAliases` and set only the fact’s explicit `hasOtherNames` flag. The existing Intake editor will retain a canonical full alias in the list editor whenever there is no structured primary AKA, rather than moving it into lawyer-only AKA name parts.

**Tech Stack:** TypeScript, React 19, Vitest, Drizzle estate model.

**Spec:** `docs/superpowers/specs/2026-10-12-client-intake-other-names.md`

## Global Constraints

- Preserve client primary-name and structured-address inputs; never collapse separately mapped fields.
- Do not infer legal identity/name parts from a reported full alias.
- No migration, document-generation, court-form wording/layout, legal/citation, historical-data, or unrelated portal changes.
- Retain the canonical estate alias list as the only source for printed/reconciled aliases.

## Review Focus

- A single two-word reported alias must remain intact rather than becoming an AKA given name.
- A selected portal alias must not overwrite pre-existing lawyer-entered structured AKA fields.
- An empty selected alias must continue to reject before any estate write.
- A canonical alias with blank AKA parts must remain visible and editable in Intake.
- A lawyer who intentionally enters structured AKA parts must retain the existing structured-primary alias behavior.

---

### Task 1: Preserve Full Client Alias Semantics

**Files:**
- Modify: `server/clientIntakeMapping.ts:55-69`
- Test: `server/clientIntakeMapping.test.ts`

**Interfaces:**
- Consumes: `buildClientIntakeApplication(payload, selections, estateId, submissionId)`
- Produces: `estatePatch` with canonical `deceasedAliases` and `hasOtherNames` only for a selected full alias.

- [ ] **Step 1: Write mapper regressions**

Add tests that select `deceasedAliases` with `TEST Alias` and with `A; B`, asserting intact canonical list output, `hasOtherNames: "yes"`, and no structured AKA keys.

- [ ] **Step 2: Run mapper regression to verify failure**

Run: `pnpm exec vitest run server/clientIntakeMapping.test.ts --maxWorkers=1`

Expected: FAIL because the current mapper writes `akaFirstName`/`akaMiddleName`/`akaLastName`.

- [ ] **Step 3: Remove inferred AKA writes from `buildClientIntakeApplication`**

Normalize full aliases only into `deceasedAliases`; set the explicit other-names flag; do not manufacture or clear structured AKA state.

- [ ] **Step 4: Run mapper regression to verify success**

Run: `pnpm exec vitest run server/clientIntakeMapping.test.ts --maxWorkers=1`

Expected: PASS.

### Task 2: Keep an Unstructured Canonical Alias Editable in Intake

**Files:**
- Modify: `client/src/pages/EstateDetail.tsx:1160-1180,1691-1717`
- Test: `client/src/pages/EstateDetail.intake-dedup.test.tsx`

**Interfaces:**
- Consumes: estate `hasOtherNames`, `deceasedAliases`, `akaFirstName`, `akaMiddleName`, `akaLastName`.
- Produces: the existing Alias editor, with a list-editor fallback when aliases have no structured primary AKA.

- [ ] **Step 1: Write Intake regression**

Render an estate with `hasOtherNames: "yes"`, `deceasedAliases: "TEST Alias"`, and blank structured AKA parts. Assert the full alias appears in the list editor and all three structured input values remain blank.

- [ ] **Step 2: Run Intake regression to verify failure**

Run: `pnpm exec vitest run client/src/pages/EstateDetail.intake-dedup.test.tsx --maxWorkers=1`

Expected: FAIL because the list editor is not exposed for a single unstructured alias.

- [ ] **Step 3: Preserve unstructured aliases in the synchronizer and list editor**

Do not clear a canonical alias when structured AKA parts are empty. Expose the list editor when aliases exist without a structured primary alias, and keep the current primary-plus-additional behavior when structured name parts are present.

- [ ] **Step 4: Run focused tests and full verification**

Run: `pnpm exec vitest run server/clientIntakeMapping.test.ts client/src/pages/EstateDetail.intake-dedup.test.tsx --maxWorkers=1 && pnpm check && pnpm test -- --maxWorkers=1 && pnpm build && git diff --check`

Expected: all commands exit 0.

### Task 3: Record and Checkpoint the Isolated Repair

**Files:**
- Create: `docs/audits/client-intake-other-names.md`
- Modify: `todo.md`

- [ ] **Step 1: Record the root cause, constraint adherence, tests, and exact scope**
- [ ] **Step 2: Verify local and preview root HTTP health**
- [ ] **Step 3: Save the validated WebDev checkpoint**

## Self-Review

- Spec coverage: Task 1 covers canonical application and non-inference; Task 2 covers lawyer visibility/editability; Task 3 covers evidence and release discipline.
- Type consistency: Existing mapper and estate state names are used unchanged.
- Review Focus: each listed failure mode has a test in Task 1 or Task 2.
- Proportion: one mapper, one editor, and their direct regressions only.

## Execution Handoff

The task is a small, ordered root-cause repair whose code paths are already established. Native execution is used under the user’s standing instruction to complete each reported defect as its own validated task.
