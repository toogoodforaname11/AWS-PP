# Form-focused intake implementation plan

1. Add the default-false per-user setting to Drizzle schema, protected settings API default and validation, and an additive migration.
2. Add a Settings preference card with a persisted accessible switch and clear, bounded copy.
3. Read the preference in IntakeTab and FormsTab.
4. Wrap only curated non-document fields/sections in form-focused visibility guards; preserve all inputs and writes in standard mode.
5. Change FormsTab rendering only when enabled: keep catalog order and existing rows but replace Required/Optional group containers with one All forms group.
6. Add Settings, Intake, and Forms tab regressions; apply and validate the migration; run focused tests, typecheck, full serial tests, build, whitespace, and scope checks.
