# Task 19 narrowed-review preferences — 2026-10-28

## Authority

This note records the review of Nick's supplied `pasted_content_23.txt`. It does not execute Gate A, grant access, accept Task 19, change the queue, or authorize another task. The existing Task 19 handoff preferences remain governing. The review recommends a corrected Gate A save without another broad panel; Nick must explicitly authorize it.

## Preferences for every model

1. Remain on the authorized local review worktree and preserve all existing source, prompt, rule, queue, predecessor and acceptance records. No Git writes, transfer, publication or deployment.
2. Read only the named safe baseline inputs and declared new task outputs needed for verification. No personal-vault search, external journal/transcript read, platform-state scan, credentials, private profiles or captured-document access. Hashing and screening are reads.
3. Keep the work an offline checklist save. No AWS/RDS/STS/S3/KMS/vault access, policy simulation, production data, fixture startup/cleanup, install, build, test rerun or Office action.
4. Incorporate the small reviewed corrections before writing; no additional broad panel/full planning round is needed. Conditional review advice is not itself execution approval.
5. The final read-only run must verify all completed declared outputs and their hash references, all named baseline inputs, the final task-file set and Git identity/index. Preserve the three-run design; do not add recursive hashes or self-referential manifests. Stop on mismatches.
6. Describe absence narrowly: no approved infrastructure artifact supplied or identified for this task. Check exact output collisions, not a device-wide evidence absence. Proposed verification stays labelled not yet run.
7. Keep policy absence, policy/resource identity, version/revision identifiers, capture time and artifact digest distinct. A missing version identifier is not an absent policy.
8. Retain unresolved application gaps and network-policy evidence limits. No change to document wording, formatting, renderers, legal/selection logic, schema, RULES.md, approved exceptions or warn-only behavior.
9. Finish BLOCKED / AWAITING-NICK — infrastructure evidence not supplied. Do not tick/append the queue, accept Task 19, start Gate B or Task 20, or alter Task 17/18's recorded acceptance scope and deferrals.
10. Save future decisions/preferences inside the declared repository scope only; no external memory writes. Nick alone authorizes the next action.

## Review locator

`outputs/task19-narrowed-plan-review-2026-10-28.md` contains the supporting plan-line references and suggested reply. Neither file stages or commits anything.
