# Client-Intake Application Undo Plan

## Goal

Add a quick, lawyer-only **Undo** control beside the most recently applied client-intake change set in an estate’s Client Portal review. It must restore only the values written by that application and must never overwrite an intervening lawyer edit.

## Design

- Store one encrypted, submission-local snapshot of the most recent application transaction:
  - selected field keys;
  - estate/contact/inventory values immediately before the application; and
  - the exact persisted values immediately after the application.
- Persist the snapshot on the existing `client_intake_submissions` record through an additive migration. This supports the requested immediate recovery path without inventing a generic audit/editor history.
- Add a protected `clientIntake.undoLastApplication` procedure. It will:
  - assert estate ownership;
  - load the submission scoped to that estate;
  - verify an undo snapshot exists;
  - restore the prior estate values only at the expected estate revision;
  - restore contact/inventory fields only where their current values still match the recorded after-values;
  - delete rows created solely by that transaction only if they still match the transaction’s exact after-state;
  - clear the snapshot in the same transaction;
  - create an activity entry after the atomic reversal succeeds.
- Reject stale or conflicting undo requests with a refresh/review message. Never silently overwrite later intake or manual edits.
- Expose only an `undoAvailable` boolean to the lawyer UI; the snapshot itself stays server-side and encrypted.
- Add a concise Undo button beside the applied-change state. It is visible only while the server reports a reversible recent application. A successful undo refreshes the estate and submission caches.

## Boundaries

- No client portal session may undo or apply estate facts.
- No legal conclusion, contact classification, court form, document wording/layout, notification, or deadline behavior changes.
- No blanket undo of unrelated estate edits.
- Existing partial application, selection, revision-request, and identity dependency rules remain intact.

## Validation

1. Red/green router tests for snapshot persistence, scoped ownership, successful reversal, stale-estate rejection, and intervening contact/inventory write rejection.
2. Persistence tests for atomic compare-and-swap reversal and encrypted snapshot storage.
3. Review component test for Undo visibility and mutation payload.
4. Run focused tests, `pnpm check`, database migration/check, full serial tests, production build, whitespace checks, runtime health, audit, tracker entry, and checkpoint.
