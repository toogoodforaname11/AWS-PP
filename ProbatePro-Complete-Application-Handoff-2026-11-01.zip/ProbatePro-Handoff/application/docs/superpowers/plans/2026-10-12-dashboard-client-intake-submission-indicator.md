# Dashboard Client Intake Submission Indicator Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Surface a concise, action-oriented dashboard signal when a client intake with current case-specific questions awaits lawyer review.

**Architecture:** Add a compact, owner-scoped aggregate of client-intake submission states without loading submission payloads into the dashboard. The dashboard combines that aggregate with the estate’s current question configuration and renders an icon-led inline control that routes to the existing Client Portal tab.

**Tech Stack:** React 19, TypeScript, tRPC 11, Drizzle/TiDB MySQL, Vitest, Tailwind, Lucide.

**Spec:** `docs/superpowers/specs/2026-10-12-dashboard-client-intake-submission-indicator.md`

## Global Constraints

- Never return client names, emails, submission IDs, prompts, answers, or payload data to the dashboard.
- Use existing owner-scoped estate lookup; no input can select an estate for the aggregate.
- Do not modify court forms, documents, legal/citation text, intake application, portal login, or database schema.
- Use an icon plus plain-language label; no coloured-dot indicator, counter, or generic decorative treatment.
- Preserve responsive, keyboard-accessible estate-row interaction and `prefers-reduced-motion` behaviour.

## Review Focus

- A non-owner must never cause a submission aggregate query for another estate; test the route with owner-derived IDs only.
- Submission states other than `submitted` must not misleadingly present as ready for lawyer review.
- An estate with no current case-specific questions must not show the custom-intake signal even if it has generic portal submissions.
- The dashboard control must stop card-click propagation and route exactly to the existing Client Portal tab.
- Missing or failed status data must degrade to no signal rather than an empty-state or dashboard failure.

---

### Task 1: Owner-scoped pending-review summary

**Files:**
- Modify: `server/db.ts`
- Modify: `server/routers.ts`
- Test: `server/routers.client-intake.test.ts`

**Interfaces:**
- Produces `db.getClientIntakePendingReviewStats(estateIds: string[]): Promise<Record<string, { pendingReview: boolean }>>`.
- Produces `clientIntake.dashboardStatus` with no input and records containing `{ hasCustomQuestions: boolean; pendingReview: boolean }`.

- [ ] **Step 1: Write the failing router regression**

Exercise a caller with two owned estate IDs; assert the aggregate receives only those IDs and returns booleans without caller-supplied estate selection.

- [ ] **Step 2: Run the focused router test to verify it fails**

Run: `pnpm exec vitest run server/routers.client-intake.test.ts --maxWorkers=1`

Expected: FAIL because `dashboardStatus` is not defined.

- [ ] **Step 3: Implement the minimal DB aggregate and protected no-input route**

The DB function reads only `estateId` and `status` for the supplied IDs. The route derives IDs with `listEstates(ctx.user.id)`, detects non-empty current custom-question configuration safely, and returns booleans only.

- [ ] **Step 4: Run the focused router test to verify it passes**

Run: `pnpm exec vitest run server/routers.client-intake.test.ts --maxWorkers=1`

Expected: PASS.

### Task 2: Estate-row submission signal

**Files:**
- Modify: `client/src/pages/Home.tsx`
- Modify: `client/src/pages/Home.storage-disposition.test.tsx`

**Interfaces:**
- Consumes `trpc.clientIntake.dashboardStatus.useQuery()`.
- Produces `data-testid="client-intake-status-<estateId>"` only for `{ hasCustomQuestions: true, pendingReview: true }`.

- [ ] **Step 1: Write the failing dashboard regression**

Mock an eligible status record. Assert the label is visible, contains no client data, has no `rounded-full` class, and routes to `/estate/estate-1?tab=client-portal` without triggering the row navigation. Assert ineligible records are absent.

- [ ] **Step 2: Run the focused dashboard test to verify it fails**

Run: `pnpm exec vitest run client/src/pages/Home.storage-disposition.test.tsx --maxWorkers=1`

Expected: FAIL because the dashboard does not query or render the status.

- [ ] **Step 3: Implement the inline, icon-led review control**

Use a native button in the existing document-indicator row, a `ClipboardCheck` icon, exact label `Client intake received`, the project’s navy/surface tokens, a brief property-specific interaction transition, and a visible focus ring. Keep it responsive and stop propagation before navigating to Client Portal.

- [ ] **Step 4: Run the focused dashboard test to verify it passes**

Run: `pnpm exec vitest run client/src/pages/Home.storage-disposition.test.tsx --maxWorkers=1`

Expected: PASS.

### Task 3: Integration verification and checkpoint

**Files:**
- Create: `docs/audits/dashboard-client-intake-submission-indicator.md`
- Modify: `todo.md`

- [ ] **Step 1: Run affected regressions, TypeScript, full serial tests, and production build**

Run focused router/dashboard suites, `pnpm check`, `pnpm test -- --maxWorkers=1`, and `pnpm build`.

- [ ] **Step 2: Review scope and runtime health**

Run `git diff --check`, inspect the scoped diff, verify local HTTP health, and confirm no client record was read for validation.

- [ ] **Step 3: Record audit/tracker and checkpoint**

Document owner scope, privacy boundary, visual treatment, test results, and exclusions; append one completed tracker entry after all verification succeeds; save a WebDev checkpoint.
