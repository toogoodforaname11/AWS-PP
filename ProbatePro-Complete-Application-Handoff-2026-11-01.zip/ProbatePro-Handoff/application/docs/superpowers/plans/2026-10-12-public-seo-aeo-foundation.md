# Public SEO and AEO Foundation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use native task-by-task implementation with a failing-test-first loop. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Improve discovery and answer-engine readiness for ProbatePro’s public, pre-login marketing surface while ensuring authenticated estate and portal routes are not indexed.

**Architecture:** Keep public search content on the unauthenticated landing page and treat every account/workspace route as private. Add a small React head manager for title, description, canonical, robots, and JSON-LD, then pair it with static `robots.txt` and `sitemap.xml` files so crawlers receive a usable response before JavaScript loads.

**Tech Stack:** React 19, TypeScript, Wouter, Vite static assets, Vitest + Testing Library.

**Spec:** User request on 2026-10-12 for SEO, competitor, AI SEO/AEO, and programmatic-SEO-informed improvements. Research evidence: Google Search Central’s generative AI and people-first content guidance, Google structured-data policies, current `probate-pro.com` fetch, and current public competitor pages.

## Global Constraints

- Do not change any internal estate-file content, official court-form language, legal wording, legal citations, document generation, or form layout.
- Do not index estate files, portal links, Settings, How It Works, Executor Portal, or other authenticated/private application routes.
- Do not create programmatic location, form, or legal-guidance pages without unique reviewed content and a separate task.
- Schema must describe only visible page content; do not add ratings, customer counts, legal claims, or facts not evidenced in the page.
- Keep public copy factual, product-focused, and clear that the product is a workflow/document-preparation tool rather than legal advice.

## Review Focus

- Crawlers receive actual text directives from `/robots.txt` and actual XML from `/sitemap.xml`, rather than the SPA fallback.
- The public landing page has one descriptive BC-probate-oriented title, description, canonical URL, social metadata, and visible matching FAQs.
- JSON-LD is valid JSON, mirrors visible landing content, and contains no unsupported testimonials, ratings, or pricing claims.
- Private workspace routes expose a `noindex, nofollow` instruction after app rendering and are also blocked in `robots.txt`.
- Existing sign-in behavior, privacy/terms copy, legal citations, forms, estate data, and portal authorization behavior remain unchanged.

---

### Task 1: Add reusable page metadata and structured-data support

**Files:**
- Create: `client/src/components/Seo.tsx`
- Create: `client/src/components/Seo.test.tsx`
- Modify: `client/index.html`

**Interfaces:**
- Produces: `Seo({ title, description, path, index, structuredData })`, which updates the document title, description, canonical link, robots directive, social meta tags, and optional JSON-LD.
- Consumes: `https://probate-pro.com` as the public canonical origin and trusted, static page-copy objects only.

- [ ] **Step 1: Write failing metadata tests**

  Verify a public page creates a canonical URL, indexable robots directive, title, description, and serializable JSON-LD. Verify a private page switches robots to `noindex, nofollow` and canonicalizes its private path.

- [ ] **Step 2: Run the focused metadata test**

  Run: `pnpm exec vitest run client/src/components/Seo.test.tsx --maxWorkers=1`

  Expected: FAIL because no shared SEO component exists.

- [ ] **Step 3: Implement the minimal `Seo` component and upgrade static default metadata**

  Keep the static HTML default aligned with the landing title/description and add canonical/social defaults. Use DOM upsert helpers with stable data attributes; serialize JSON-LD safely; do not introduce an external metadata dependency.

- [ ] **Step 4: Run the metadata test**

  Run: `pnpm exec vitest run client/src/components/Seo.test.tsx --maxWorkers=1`

  Expected: PASS.

### Task 2: Improve the visible pre-login landing page for high-intent BC probate queries

**Files:**
- Modify: `client/src/pages/Landing.tsx`
- Modify: `client/src/pages/Landing.auth.test.tsx`

**Interfaces:**
- Consumes: `Seo`, a static `LANDING_FAQS` object, and only existing factual product capabilities.
- Produces: visible role-specific overview and FAQ content, plus matching `SoftwareApplication`, `Organization`, and `FAQPage` JSON-LD.

- [ ] **Step 1: Extend landing coverage with a failing SEO-content test**

  Assert the pre-login page exposes the BC-probate audience statement, a visible workflow/settings/Executor Portal overview, five FAQ questions, and a matching JSON-LD graph.

- [ ] **Step 2: Run the focused landing test**

  Run: `pnpm exec vitest run client/src/pages/Landing.auth.test.tsx --maxWorkers=1`

  Expected: FAIL because the public overview, FAQs, and structured data are absent.

- [ ] **Step 3: Add factual product content without changing court-form or legal language**

  Add a compact public overview for lawyer and personal-executor workflows and FAQ answers directly supported by existing UI behavior. Keep existing form list/court-rule text untouched. Render `Seo` with a descriptive title, canonical root, public description, and JSON-LD that mirrors the visible content.

- [ ] **Step 4: Run the focused landing test**

  Run: `pnpm exec vitest run client/src/pages/Landing.auth.test.tsx --maxWorkers=1`

  Expected: PASS with existing authentication/recovery assertions retained.

### Task 3: Establish crawl boundaries for public and private routes

**Files:**
- Create: `client/public/robots.txt`
- Create: `client/public/sitemap.xml`
- Create: `client/src/public-seo-assets.test.ts`
- Modify: `client/src/pages/Settings.tsx`
- Modify: `client/src/pages/HowItWorks.tsx`
- Modify: `client/src/pages/ExecutorPortal.tsx`

**Interfaces:**
- Consumes: `Seo` and static asset paths served by Vite from `client/public`.
- Produces: crawlable public root/legal pages and explicit crawl blocks/noindex metadata for authenticated workspace routes.

- [ ] **Step 1: Write failing static-asset and private-route assertions**

  Validate that robots disallows private workspace paths but allows public crawl, sitemap lists only `/`, `/terms`, and `/privacy`, and the Settings/How It Works/Executor Portal route components each create a `noindex, nofollow` robots directive.

- [ ] **Step 2: Run the focused crawl-boundary test**

  Run: `pnpm exec vitest run client/src/public-seo-assets.test.ts client/src/pages/HowItWorks.test.tsx client/src/pages/ExecutorPortal.test.tsx client/src/pages/Settings.test.tsx --maxWorkers=1`

  Expected: FAIL because static assets and private metadata are absent.

- [ ] **Step 3: Add static files and private route metadata**

  Add `robots.txt` and `sitemap.xml` under Vite’s public directory. Add only head metadata calls to the three private components; do not alter their workflow, legal, or access-control content.

- [ ] **Step 4: Run the focused crawl-boundary suite**

  Run: `pnpm exec vitest run client/src/public-seo-assets.test.ts client/src/pages/HowItWorks.test.tsx client/src/pages/ExecutorPortal.test.tsx client/src/pages/Settings.test.tsx --maxWorkers=1`

  Expected: PASS.

### Task 4: Validate and record the on-site SEO/AEO repair

**Files:**
- Create: `docs/audits/public-seo-aeo-foundation.md`
- Modify: `todo.md`

- [ ] **Step 1: Inspect public assets and rendered metadata**

  Run local `curl` checks for `/`, `/robots.txt`, and `/sitemap.xml`; assert robots response text and XML content are no longer the SPA fallback. Inspect generated landing schema with a focused test rather than adding a claim about search rankings.

- [ ] **Step 2: Run project validation**

  Run: `pnpm check && pnpm test -- --maxWorkers=1 && pnpm build && git diff --check`.

  Expected: all commands exit successfully.

- [ ] **Step 3: Record evidence and checkpoint**

  Write an audit note with the observed baseline failures, implementation, search-source findings, and validation output. Append exactly one tracker entry, inspect the scoped diff, health-check the existing development server, and save a checkpoint.
