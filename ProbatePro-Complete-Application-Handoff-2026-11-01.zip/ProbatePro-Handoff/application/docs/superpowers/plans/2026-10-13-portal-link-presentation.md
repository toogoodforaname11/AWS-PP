# Portal Link Presentation Repair Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let a lawyer reliably see and copy a newly issued estate-scoped client-intake link without an ambiguous copy action silently rotating it.

**Architecture:** Keep the raw token issuance contract unchanged: the server returns it only when creating or intentionally replacing an access link, while persistence retains only its hash. In the estate Client Portal surface, retain the just-issued URL only in component memory, display it in an accessible short-lived issuance panel, and offer an explicit copy action. Rename the row-level token-rotation control to an explicit replacement action so it cannot be mistaken for copying an existing link.

**Tech Stack:** React 19, TypeScript, tRPC 11, Sonner, Vitest.

**Spec:** User-reported portal retest issue on 2026-10-13: “Grant Access no longer shows or copies the link, and using the copy icon creates a second link.”

## Global Constraints

- Do not persist, cache, log, or list a raw portal token after the issuance response; the database keeps only its hash.
- Do not access, inspect, or modify real estate records while validating this repair.
- An existing link cannot be copied after the issuance moment; the interface must state an intentional replacement action instead of pretending otherwise.
- Preserve the existing estate ownership check, one-time redemption, expiry, revocation, and client-intake workflow.
- Do not alter court-form content, legal logic, document layout, or unrelated portal behavior.
- Use a focused red/green regression, then typecheck, serial tests, production build, whitespace, and runtime health before checkpointing.

## Review Focus

- A successful Grant Access action shows the exact newly issued URL in the estate-scoped Client Portal and attempts a clipboard copy without relying on clipboard availability.
- A browser that blocks or lacks clipboard access leaves the issued URL visibly available for manual copy rather than losing it or throwing.
- The row action says “Replace link,” not “Copy,” and only invokes the existing controlled reissue procedure when deliberately selected.
- The raw URL is only React component state and disappears when the lawyer dismisses it or leaves the estate-scoped workspace.
- Scoped portal links and server-side hashed-token guarantees remain unchanged.

---

### Task 1: Present issued links and clarify replacement

**Files:**
- Modify: `client/src/pages/Settings.tsx: PortalAccessSection`
- Modify: `client/src/components/EstateClientPortal.test.tsx`

**Interfaces:**
- Consumes: `portalAccess.create` and `portalAccess.reissue` mutation results `{ accessToken, expiresAt }`.
- Produces: an ephemeral `issuedLink` presentation panel with a copy action and an explicitly named row-level replacement action.

- [ ] **Step 1: Write failing estate-scoped portal regressions**

Add a test that creates an estate-scoped link and asserts a labelled newly issued URL remains visible and is copied. Add an assertion that an existing access row offers “Replace link” and no ambiguous copy action.

- [ ] **Step 2: Run the focused regression to verify it fails**

Run: `pnpm exec vitest run client/src/components/EstateClientPortal.test.tsx --maxWorkers=1`

Expected: FAIL because newly issued tokens are discarded and the row uses a copy icon to call `reissue`.

- [ ] **Step 3: Retain the just-issued URL only in component memory**

Add an accessible issuance panel above the access list. On create or deliberate replacement, derive the portal URL from the mutation response, place it in ephemeral local state, attempt a safe clipboard copy, and retain the URL for the lawyer when copying is unavailable. Do not add it to a query cache, server API, database row, or log.

- [ ] **Step 4: Make reissue unambiguous**

Replace the row-level copy-icon control with a labelled “Replace link” action that calls the existing reissue mutation. Retain email replacement functionality with copy that accurately states it issues a new link.

- [ ] **Step 5: Run focused verification**

Run: `pnpm exec vitest run client/src/components/EstateClientPortal.test.tsx --maxWorkers=1 && pnpm check`

Expected: PASS.

- [ ] **Step 6: Complete release checks**

Run: `pnpm test -- --maxWorkers=1`, `pnpm build`, `git diff --check`, and local/preview HTTP health checks. Confirm the portal access security suite still proves only the raw issue-time secret is returned.

## Self-Review

- The design does not weaken the server’s hashed-token-only list contract.
- The issued URL has an explicit accessible label and a manual-copy fallback.
- Replacement is no longer visually or semantically described as copy.
- Existing portal access security and client intake workflows remain under their current ownership and authorization controls.
