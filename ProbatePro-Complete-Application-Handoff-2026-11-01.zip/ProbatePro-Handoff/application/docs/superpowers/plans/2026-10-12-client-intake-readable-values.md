# Client Intake Review — Readable Values

## Goal
Remove internal stored tokens from the lawyer-facing Client Portal review surface while preserving the existing client-intake submission, selection, and application contracts.

## Scope
- Display clear labels for client-review scalar values (`willStatus`, First Nation answer).
- Display clear labels for person and estate-item subfields.
- Display clear labels for inventory category/location tokens and reported document tokens.
- Use the same formatting for the current Intake comparison value when it is a scalar field.

## Guardrails
- Do not change stored enum values, selection keys, server mapping, estate data, review state, or form/document output.
- Do not combine structured client input fields; this display-only task preserves the existing payload contract.
- Keep unknown/empty values absent as today.

## Validation
1. Add a red regression proving internal tokens do not appear in review values.
2. Run focused shared/client review tests, TypeScript, full serial tests, production build, whitespace/scope review, and runtime health.
3. Record the audit and tracker entry only after fresh passing output.
