# Staging integration verification record

This record covers the reviewed Windows snapshot integrated into **ProbatePro — Hybrid Staging**. It is evidence for an isolated saved staging version, not a SHIP decision, production-readiness claim, infrastructure acceptance or completion of every historical task. The final checkpoint handoff is kept outside the repository and binds the committed source digest, final clean-CI receipts, Manus version and canonical repository identity.

## Automated source gates

The application source was exercised through the actual pinned clean-CI entry point in a fresh private candidate with no copied dependencies, runtime state, credentials or database files. The completed application-source run `post-popup05` passed:

| Gate | Result |
| --- | --- |
| Root TypeScript check | Passed |
| Root serial tests | **370 files / 7,571 tests passed** |
| Chatbot TypeScript check | Passed |
| Chatbot tests | **15 files / 205 tests passed** |
| Build | Passed |
| Strict frozen render comparison | **26 / 26 verified** |

The sole root-suite exclusion remained `server/storage.live-uat.test.ts`. The runner reported all six gates complete, stable source, unchanged protected inputs and passing isolation controls. Its application-source digest was `883823a48d0e09e167e98db45e9b0ed86ff4fd82e0e040a30acad03fa16c1f10`. Documentation-only consolidation after that run is included in the separate final candidate used for the checkpoint; the external handoff records that candidate's own digest and receipts rather than relabelling this earlier identity.

The strict DOCX comparator checks every archive member and permits only the two previously approved timestamp-content normalizations. It does not regenerate baselines. This is not Word pixel evidence.

## Final-build native/browser evidence

All observations below used the owned loopback service, deliberately fictional account/estate/data, real application session validation and native MySQL persistence. The storage provider and selected faults were fixture-controlled. This was not real Manus OAuth, public HTTPS Preview, AWS, RDS/TiDB or production evidence.

- **Single-form popup and warn-only generation.** A real P5 preflight request was deliberately failed through an authenticated, estate-owned fixture fault. The UI said “Requirements could not be checked — Generate will re-check.” The visible Generate retry restored the existing warnings without inventing answers. **Generate anyway** then produced a real P5 DOCX. The saved browser file exactly matched the captured response; its canonical bare-DOCX digest matched the signed preparation digest; native generation plus delivery-started/finished events matched the same document/attempt. No generated row retained bytes. Evidence: `final-p5-after-preflight-retry.json` and `final-p5-after-preflight-retry-digest.json` in the private native evidence directory.
- **Replacement/history metadata.** After final P5 generation, the fictional native fixture contained two documents/two versions and 22 audit rows, with zero generated rows retaining bytes and zero historical rows carrying storage references. This is fixture replacement/history evidence, not exactly-once or exhibit/container-binding proof.
- **Unicode notes filename, Bearer path.** The final client transport saved `Notes - Łukasz O’Neill QA - 2026-10-31.pdf` through the actual Bearer/fetch route. The browser added only its ordinary `(1)` duplicate-file suffix. The file matched the captured 1,726 response bytes and both notes delivery audit events. Every PDF byte matched the unchanged imported renderer replay, with zero normalized bytes and own-user notes only. Evidence: `final-notes-unicode-bearer.json` and `final-notes-unicode-bearer-parity/result.json`.
- **Estate export/archive.** The visible **Export estate copy** control produced a browser-saved ZIP. The sandbox-saved file exactly matched the captured response, passed CRC and safe-member-path checks, and correlated to export delivery start/finish audits. It contained `records.json`, `README.txt` and one explicitly fictional stored PDF under `files/`; no private runtime or production object was included. Evidence: `final-estate-export-saved.json` and `final-estate-export-saved-structure.json`.
- **Narrow layout and preserved package restriction.** In an isolated Firefox context at **390 × 844**, the Forms document and single-form missing-information popup had no horizontal overflow. The popup fitted inside the viewport and used vertical scrolling. Its PGT selector accepted a value and enabled Apply; the edit was cancelled without saving. The Grant Package popup had **zero inline editors**, retained its navigation actions and no Apply control, as Nick directed. Both popups fitted horizontally at that viewport.
- **Build identity.** The private UI launcher required the source-matched clean build and verified every served build-file hash. `/manus-routes.json` returned HTTP 200 with the actual 13 page routes. Public Preview remained stopped and was not represented as validated.

The private evidence root is `/home/ubuntu/probatepro-integration-evidence/native-ui-20261030/`; it is intentionally excluded from Git. Screenshots and logs are supporting observations, not substitutes for the saved-byte/native receipts above.

## Independent review

Read-only independent reviews covered the server/privacy repair delta, portable verification/CI tooling, the complete popup correction and its follow-up acknowledgement boundary, and the final PDF-only client-header delta. Reproduced findings were repaired and rerun; superseded candidates were stopped and retained as non-final evidence. The last targeted supplements reported no new introduced defect in their scoped final deltas. These reviews did not execute the application and do not replace the gates/browser receipts or close historical policy tasks.

## Explicitly open limitations

1. **INTEG-PDF-01 — garbled Unicode estate-name text in notes PDFs.** The final Bearer PDF visibly garbles `Łukasz O’Neill QA` even though its filename and byte-for-byte source replay are correct. This is present in the unchanged imported renderer. No font, text-drawing, layout or renderer change was made; a separate scoped Nick decision is required.
2. **Word/native pixels remain USER-DEFERRED-NOT-PASSED.** Matching XML/package/PDF bytes are not Word rendering proof. No Office retry was performed.
3. **Historical dispositions remain.** Tasks 6, 14, 19 and 20 are not accepted; Tasks 7/8 remain moved past and unimplemented; Task 15's exact historical browser A–D set was not recreated by these overlapping journeys. Task 19 Gate A has no real infrastructure evidence. The all-task ledger preserves every other limited closure and residual.
4. **Binding limits remain.** Bare-DOCX digest correlation does not establish exhibit, attachment, wrapper, export-container or preparation binding, exactly-once generation, or full provenance for every delivery class.
5. **Environment limits remain.** The disposable MySQL fixture and loopback provider do not prove RDS/TiDB engine/page-size/transaction/pool compatibility, deployed schema, real OAuth, public Preview cookies/CSP, mobile WebViews, Canadian-only processing, compliance or production readiness.
6. **AWS and publication remain stopped.** No AWS/S3/STS/KMS/vault login, policy collection, configuration, credential, managed-database override/migration, production access, Publish, deployment, custom domain or hybrid Step 4 was performed.

## Saved-version boundary

A Manus checkpoint/private canonical repository records this reviewed staging state; it does not waive the limitations above. Automatic publishing stays off. The existing `toogoodforaname11/probatepro` repository and production project are not targets. The final external handoff records the exact allowlisted commit, confirmed Manus version, completed canonical transfer and remaining blockers, then stops for Nick's separate AWS authorization.
