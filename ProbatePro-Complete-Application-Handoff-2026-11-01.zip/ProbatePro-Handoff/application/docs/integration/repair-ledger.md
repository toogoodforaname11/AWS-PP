# Repair ledger — initial destination diagnosis

*2026-10-30 · Initial diagnoses retained below; current execution evidence recorded separately*

**No repair has final end-to-end acceptance yet.** The original diagnoses below are preserved, but the following destination-only results supersede their initial “not implemented” status. Historical Task 20 remains **STILL-BLOCKED**; this ledger grants no task acceptance, SHIP, publication, Step 4, production-readiness, security/compliance or Canada-only assurance.

## Final staging disposition

The permitted destination repairs now have focused red/green evidence, independent final-delta reviews, complete clean-source gates and source-bound fictional native/browser checks. The final application-source run passed **370 root files / 7,571 tests**, **15 chatbot files / 205 tests**, both typechecks, build and **26 strict renders**. Actual saved P5 DOCX, Unicode notes PDF and estate-export ZIP bytes were correlated with native generation/delivery evidence. The single-form popup correction and preserved bulk/package restriction were also checked at 390 × 844. See [final verification](final-verification.md).

This supersedes the older pending statements below for those executed checks only. It does not resolve INTEG-PDF-01 (garbled Unicode estate-name text in the unchanged notes renderer), Word pixels, moved-past Tasks 7/8, unaccepted Tasks 6/14/19/20, exact Task 15 A–D scenarios, public Preview/real OAuth, deployed infrastructure or any AWS/production obligation. The final saved version is staging evidence, not SHIP.

## Current destination execution

Notes filenames were separately approved by Nick at 2026-10-30 13:39:22 -07:00. `notes-filename-red01` reproduced seven failures; `notes-filename-green02` passed root TypeScript and all 221 tests across the seven connected notes/delivery files after explicit fault injection replaced tests that had depended on valid Unicode names breaking. The PDF renderer region and all 407 protected-source hashes remain unchanged. See [notes approval and evidence](notes-filename-approval.md). Actual browser/native and final-source checks remain pending.

PR-03 was reproduced by `dev-seeding-red01` (30 failed, 132 passed) and its three-line implementation passed `dev-seeding-green01` (162/162). Both real mocked-entrypoint and environment validation suites pass. No runtime/purge provider source was changed, and no AWS setting was configured in the project.

PR-02 was reproduced by `debug-redaction-red01` (64 failed, 2 passed). `debug-redaction-green01` passed JavaScript syntax checking, root TypeScript and all 66 collector/sink tests. The assertions exercise real collectors and middleware with mocked I/O; this is not historical log cleanup or native-browser proof. Remaining proposals are reviewed but unapplied unless a later evidence entry says otherwise. All private gate receipts remain under `/home/ubuntu/probatepro-integration-evidence/gates/`.

PR-01 was reproduced at the real delivery/generation callers by `audit-waits-red01` (101 failed, 74 passed). `audit-waits-green01` passed root TypeScript and all 706 tests across 11 connected files, including the existing HTTP/refusal, replacement, reporter-quota and notes-lease suites. It reuses the immutable 10-second audit, 15-second IDOR and 1-second reporting waits; no quota is added to direct form/generation reports. Only in-time exact acknowledgement permits bytes. SQL is not cancelled and pool capacity is not thereby freed; native/UI/final-source evidence remains pending.

PR-04 was reproduced by `attachment-label-red01` (53 failed, 279 passed), including actual first/wrong-attachment and untrusted/global attribution failures. The initial implementation typecheck exposed an iterator incompatible with the unchanged compiler target; an equivalent indexed loop corrected that syntax without changing configuration. `attachment-label-green02` passed root TypeScript and 714 tests across seven connected files. Trusted ordinals identify later failures; unknown failures remain generic. Native/UI/final-source evidence remains pending.

PR-05 was reproduced by `delivery-envelope-red01` (11 failed, 48 passed): oversized generation resolved and committed instead of refusing before replacement. `delivery-envelope-green01` passed root TypeScript and 586 tests across ten connected files. The unchanged caps now cover the signed descriptor and client attempt envelope before commit, including both form encodings and JSON. Answers are not truncated or normalized; Generate anyway and existing resource refusals remain. Native browser wire evidence remains pending.

PR-06 was reproduced by `export-preflight-red01` (33 failed, 24 passed) through real router/list/facade/registry composition with fictional database transport. `export-preflight-green01` passed root TypeScript and 640 tests across eight connected files. Provider-free admission now precedes preparation success; actual delivery still revalidates. It does not implement Task 8 or establish the cause of historical REG-61. Native/UI/final-source evidence remains pending.

## Evidence and governing scope

The [approved integration plan][P] authorizes the parent's permitted destination-only repair loop and isolated fictional verification, subject to its freeze, policy and isolation boundaries. The [current Task 20 final report][R], including **Corrections C1–C10**, governs over conflicting earlier report text. The [Task 18 known gaps and preservation contracts][K] and [task reconciliation][T] preserve historical decisions; the [tooling ledger][TL] records pending installation and gate portability.

**Historical evidence:** every Windows-source test, browser/native journey, render comparison and acceptance receipt remains historical here, including evidence Task 20 called “fresh” within its own pass. **Fresh diagnosis:** the six private reports linked below provide static traces and proposed cases only; none reports source repairs or test execution, and no failed investigation was supplied. This ledger is a documentary synthesis, not an additional code review or runtime proof.

Use `/home/ubuntu/probatepro-integration-evidence/import-2026-10-30/source` as the immutable imported-source comparison baseline, **not scaffold HEAD**. Preserve imported source bytes/line endings, historical receipts and protected baselines. This authoring task writes only `docs/integration/repair-ledger.md`: no application/configuration/test/rule edits or execution, services, network, database, AWS, production, secret access or Git writes.

The register is a preservation/risk record, **not 61 new required implementation features**. Duplicate findings are grouped below; omitted informational detail remains in R/K, not silently closed. Proposed repairs must preserve authentication, exact ownership, namespace/manifest/reference gates, atomic effects, audit-before-bytes and intentional non-retention. Rules 28/29, both separate non-parameterized STS paths, runtime/purge separation and the exact `providerDeleteExact` purge chokepoint remain unchanged.

## Permitted repair candidates — features and files before edits

All six entries have disposition **source-diagnosed; reproduction pending; not implemented or verified by these investigations**. Intended files are proposals, not an assertion that edits have occurred. Parent must serialize the overlapping `routers.ts`, storage facade/registry and delivery-test changes.

### PR-01 — REG-14 audit/report waits, one grouped repair

**IDs:** REG-14; U5-F1, U3a-F2, U3c-F1, U4b1-F3; overlapping U3b-F4. [Investigation][AW].

**Connected features:** form and letters/P8/package/estate delivery; exact started ACK before bytes; failed-delivery/IDOR audits; four controlled generation mutations; stable report/reference identity; estate/package response-close slots; existing reporting quotas; notes actual-promise leases and late-ACK behavior; non-retention.

**Intended files:** `server/downloadRoute.ts`, `server/downloadExportsRoute.ts`, `server/routers.ts` (controlled-error/import only), `server/exportFailureReporting.ts` (additive scalar-row wait helper); `server/downloadRoute.test.ts`, `server/downloadExportsRoute.test.ts`, `server/exportFailureReporting.test.ts`, and `server/routers.generation-effects.test.ts` or the existing generation-boundary suite.

**Diagnosis and smallest change:** the export reporter bounds only its own insert; the preceding audits and direct form/generation reports can remain pending. Bound route callers with `settleWithin` semantics and immutable existing notes defaults: **10,000 ms** for started/failed audits, **15,000 ms** for IDOR audits. Only an in-time exact `true` permits attachment bytes; timeout follows the existing refusal branch, wording, status and report eligibility. Bound direct form/generation report waits at `EXPORT_REPORT_WAIT_MS` (**1,000 ms**), preserving the exact scalar row/reference, one writer invocation, cleared timers and closed late diagnostics. Do not use `prepareExportFailureReport` to remint IDs or enroll these callers in export-report quotas.

Late observers must receive scalar snapshots, not request/response, render buffers or errors. No late response, attachment, retry or compensating write. Keep slot release owned by response `close`, never a late callback or unconditional `finally`. Leave `affidavitHistory`, `auditWritten`, notes leases and notes' intentional late terminal write unchanged; do not reuse notes `awaitStartAck` for form/export.

**Pending reproduction/regressions:** defer started/failed/IDOR/report promises at real callers; cover exact deadlines, in-time true/non-true, late resolve/reject and disconnect. Preserve foreign exact-ID 403 versus collation-only 404, no unauthorized build/budget spend, all four generation envelopes and report IDs. Prove timed-out request A cannot clear newer request B's slot; retain report reservation/rate and notes lease/late-ACK tests. Bounds do not cancel SQL, free pool capacity or establish an end-to-end request deadline; REG-30/U6-F2 stays separate.

### PR-02 — Diagnostic redaction, one sink-wide repair

**IDs:** REG-15/REG-50; U5-F2/F3, U8-F5/F6. [Investigation][DR].

**Connected features:** development-only Vite injection; fetch/XHR telemetry; console/error/UI/session capture; periodic/forced/requeued reports; normal/shortened unload beacons; all three `.manus-logs` append channels and parsed-body/raw-stream ingress. Actual application traffic and production no-injection must remain unchanged.

**Intended files:** `vite.config.ts`, `client/public/__manus__/debug-collector.js`, `server/debugLogSink.redaction.test.ts`, `client/src/lib/debugCollector.redaction.test.ts` only.

**Diagnosis and smallest change:** key/header masking leaves bodies, free text, alternate channels and parser errors exposed. Make the append boundary authoritative with source-aware safe-metadata projections for every channel. Replace every supplied non-null body with a fixed marker; drop unknown/free-text carriers. Normalize record/tuple-list headers, redact sensitive names regardless of value shape, fail closed on malformed containers, and retain validated method, safe route identity, status, duration, media type and numeric length. Stop telemetry fetch clone/text and XHR responseText reads. Sanitize before buffering and on every report/beacon path, without changing original requests, responses, errors or console behavior. Validate payload/channel shapes before writes; both catches return the same constant safe 400 JSON.

**Pending reproduction/regressions:** drive the real plugin through parsed and streamed ingress with fictional sentinels, malformed JSON/channels and append faults. Cover duplicate/mixed-case/array-valued headers, neutral-key JSON, long text, spoofed body markers, URLs and console/session bypasses. Drive real collector wrappers across force/interval/requeue/beacon/shortened-beacon paths and restore installed globals/listeners. Preserve useful metadata, null bodies, success, non-POST and production guards. Existing server tests **do exist**, but pin unsafe pass-through; replace those assertions with affirmative redaction, not skipped coverage. Retaining arbitrary console/session text prevents a full sink-privacy claim. Existing logs remain uninspected and unchanged; prospective redaction is not historical cleanup.

### PR-03 — Development/test seeding guard

**IDs:** REG-52 / U1-F6. [Investigation][DS].

**Connected features:** import-time environment defaults; dedicated-vault/Forge selection and warnings; mocked startup proof/reconciliation; explicit local profiles; production/unset/unknown-tier fail-closed behavior. Credential providers and purge remain unchanged.

**Intended files:** `server/_core/env.ts`, `server/env.validation.test.ts`, `server/_core/index.startup-storage.test.ts`.

**Diagnosis and smallest change:** the seed guard omits six consumed AWS inputs. Append `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_ROLE_ARN`, `AWS_EXTERNAL_ID`, `AWS_PURGE_ROLE_ARN`, `AWS_PURGE_EXTERNAL_ID` to `STORAGE_ENV_KEYS`. Preserve the existing `every(...trim())`, development/test and `VITEST` conditions. Any nonblank input suppresses synthesis before ENV capture; do not change defaults, validators, providers, startup behavior or explicit profiles.

**Pending reproduction/regressions:** remove `VITEST` before fresh imports; test all six and each individually, padded nonblank values, absent/empty/whitespace-only inputs, explicit storage inputs and full local profiles. Assert **no input mutation**, not merely selector-false. Preserve unconfigured seeding and all fail-closed/role/KMS coverage. AWS-only mocked test startup must call exactly `validateSchema`, not storage proofs, while explicit complete profiles still run all four proofs. Use only fictional literals and mocked collaborators. Import alone is not an observed AWS request; C9 distinguishes AWS STS from local S3 traffic.

### PR-04 — Accurate multi-attachment refusal attribution

**IDs:** U2-F1 / C1. [Investigation][AL].

**Connected features:** P1 generation/delivery, numbered grant-package notice attachments, certified ancillary attachments, private signing/admission, duplicate-key reuse, sequential fetch/ZIP order, single-file WESA s. 58, lawyer refusals and label-free staff reporting.

**Intended files:** `server/documentAssets.ts`, `server/storage.ts`, private-read attribution in `server/storageRegistry.ts`; `server/documentAssets.test.ts`, `server/storage.read-boundary.test.ts`.

**Diagnosis and smallest change:** a later item rejects the shared signing promise, which the first spec catches and mislabels. Retain batching and protected per-chunk admission. Carry only a registry-branded, request-local original-input ordinal, preferably in a private WeakMap with a safe facade accessor. Preserve ordinals through deduplication/grouping/chunking; attribute only demonstrably keyed validation/provider failures, including synchronous dispatch throws under the existing locks. Preserve only trusted safe refusals through the registry catch, suppressing raw details. Handle batch-sign rejection separately from per-file fetch failure; unknown/global/ambiguous failures get generic attachment-group 409, never an assumed first label. Preserve `report:true`; staff remains label-free `storage_failure`.

**Pending reproduction/regressions:** valid first/unreadable later attachments, ancillary labels, synchronous/asynchronous provider failures and later-chunk ordinals; generic DB/engine/disposition/timeout/ambiguous cases and forged indexes. A refused chunk dispatches no provider and the rejected batch starts no attachment fetch; earlier admitted chunks may already have signed. Preserve exact successful bytes/names/`nameFor` order, repeated-key deduplication, conflict refusals, query budgets, 500-request/20-object-chunk/30-second limits, locked synchronous dispatch, release-before-completion and no post-admission retry. No singleton signing, diagnostic retry or cross-operation authorization cache.

### PR-05 — Admit the complete delivery envelope before replacement

**IDs:** U4b1-F2, related REG-06 / C7. [Investigation][DE].

**Connected features:** atomic replacement/history, provenance and success/override activity, signed inputs/render digest, client attemptId, native/Bearer urlencoded delivery, JSON preview delivery, Generate anyway and 413 review/regenerate recovery.

**Intended files:** new `shared/deliveryEnvelope.ts` and `shared/deliveryEnvelope.test.ts`; `server/routers.ts`; constant import/re-export only in `server/_core/deliveryRouter.ts`; `server/document-generation.audit.test.ts` or a dedicated sibling; `server/formDeliveryBinding.body-size.routes.test.ts`; optional serializer-parity tests in `client/src/lib/attachmentDelivery.test.tsx` without client behavior changes.

**Diagnosis and smallest change:** generation signs original override fields and commits before measuring the eventual POST. Immediately after binding and before `replaceGeneratedDocumentRecord`, measure final fields plus a maximum-length **36-character placeholder attemptId**: JSON UTF-8 **≤8,353 bytes** and urlencoded **≤8,349 bytes**, including a separate native CR/LF-normalized measurement copy. Never mutate signed/returned values or return the placeholder. Throw branded `PublicTRPCError({ code: "PAYLOAD_TOO_LARGE", message: "The request is too large." })`; plain `PublicRefusal(413)` would become BAD_REQUEST here. Use a dependency-light helper, not an import of the handler-bearing delivery router.

**Pending reproduction/regressions:** actual generation with the existing oversized ASCII/textarea and Unicode fixtures; exact form 8,348/8,349/8,350 and JSON 8,352/8,353/8,354 boundaries; binding/attempt overhead; escaping and native serializer parity. Oversize must leave predecessor/history/audit/activity unchanged, without fault report or storage write; fitting values and missing-data Generate anyway still work. Preserve independent route caps, 148/157/161 binding assertions, 8,192-byte non-form caps and parameter limit 20. A JSON-calibrated fixture already oversized as a form becomes a pre-commit refusal, not permission to enlarge caps or weaken route tests. No truncation, answer dropping, legal/schema changes or encoding fallback.

### PR-06 — Export preparation/read admission, one REG-61-related mechanism

**IDs:** REG-61-associated U4b1-F1 / U3c-F2 / U4b2-F1, grouped once. [Investigation][EP].

**Connected features:** estate-export preparation/fileCount/descriptor, active/retained manifests, exact identities and references, lifecycle/locking/provider compatibility, count/size limits, preparation success/optional activity, delivery audits/reporting, empty structured-only exports and non-retention.

**Intended files:** `server/storage.ts`, `server/routers.ts`, comment-only clarification in `server/storageRegistry.ts`; `server/storage.read-boundary.test.ts`, `server/routers.estate-export.test.ts`, and a focused `server/routers.estate-export-admission.test.ts` if needed to cross existing mocks. No executable `db.ts` or `estateExport.ts` change.

**Diagnosis and smallest change:** preparation's list/count/size checks are weaker than delivery admission. Add `storagePreflightReadManyExact(requests): Promise<void>` using the existing complete `withReadableStoredObjects` gate. Its synchronous callback calls only the existing `readsFromLegacyPlatform` compatibility guard and returns `Promise.resolve(undefined)`; no provider primitive. In the existing inner preflight try, get the bounded candidates, await the helper with each key/category and authenticated exact user/estate scope, then assign fileCount. Reject the whole preparation, not a filtered list. Preserve success commit, optional activity, generic error mapping, single-report behavior, locks/limits/retries and synchronous protected dispatch for real reads/signs.

**Pending reproduction/regressions:** a composition red case must use real preparation/list/facade/registry with fictional DB transport and mocked providers; helper-throw mocks alone do not prove the connection. Cover conditional identity/reference/collation/legacy-metadata gaps; label tombstone/destruction-state fixtures as defensive, not ordinary current-writer outcomes. Preserve active/retained/empty and 20/21/500 cases, 501/size refusals, commit/optional-activity outcomes and later-batch failure with zero provider calls. Revalidate at delivery after a lifecycle change; retain exact archive behavior and no retained bytes.

**Historical incident remains open:** the REG-61 fixture had no disposition row; the tombstone theory is not its established cause. A separate reproduction is still required. This advisory provider-free preflight neither proves provider availability nor binds preparation to future bytes; it does not implement Task 8 or create a new independent finding (C2).

## Pending integration work — not additional application features

| Work item | Connected features and intended scope | Pending evidence / restriction |
| --- | --- | --- |
| Installation portability, DEP-01 | Root/chatbot pnpm build-permission configuration and native esbuild/Tailwind consumers; exact delta follows [tooling ledger][TL]. | Preserve package-manager pin, packages, lockfiles, patches and line endings; no upgrade. Inspect installer permissions and obtain scrubbed frozen-install/native-consumer receipts before gates. Installation success is not application verification. |
| Gate portability, GATE-01 | New destination/private adaptation of the existing serial runner; original `.work/hybrid-remediation/run-gates.cjs` and receipts remain untouched. | Review lifecycle hooks, discovery/startup side effects and environment/network isolation. Keep all six gates, serial flags, the sole excluded live-storage UAT, stop-on-failure and protected checks before/after. Parent records exact new paths before edits/execution. |
| Preview fixture dependency, U7b-F7 | `client/src/lib/previewTransport.test.ts` and a parent-declared versioned fixture directory containing only the required verified fictional payloads. | The suite depends on 28 review-tree `.work` fixtures and fails without them. Establish portable provenance/hash-preserving placement before repository saving; do not commit private `.work`, fabricate replacements, relax counts or skip coverage. The 26 accepted render baseline pairs are likewise immutable, not regenerated goldens. |
| Idle diagnostic gates, REG-29 | `client/src/pages/EstateDetail.p5-draft.test.tsx`, `server/formDeliveryBinding.races.routes.test.ts`, `server/notesExportRoute.limits.test.ts` are diagnostic targets, **not approved speculative edits**. | Task 20 root check passed historically; tests exited 1: 2 failed / 7,010 passed / 7,068 total, 56 unreported and two worker exits. P5 timed out, then had duplicate DOM elements; resource-pressure/cascade causation is unproven. Reproduce on an idle isolated machine and explain the failures; do not increase timeouts or weaken assertions to force green. Chatbot check/tests, build and render did not run and remain pending. |
| Native/UI and final-build portability | Private disposable fictional MySQL/SQLite fixtures, reviewed launch/gate tooling and actual application routes/UI; no authentication bypass. | Parent must establish process/port/datasource identity, scrubbed environment and source/build-bound browser/native correlations. Keep managed DB blank/unused. Missing real-auth/Preview dependencies are blockers, not permission to invent an identity or use production. No such execution is evidence from this ledger. |

The approved integration plan supplies current authority for permitted isolated reruns; Task 20's older “new authorization required” statement is historical. It does not waive frozen, policy, credential or infrastructure boundaries.

## Approval-needed decisions — no implicit policy changes

| Item | Decision boundary and affected behavior |
| --- | --- |
| REG-27 / U6-F1/F5, notes filename F1/O1 | Separately approved at 2026-10-30 13:39:22 -07:00: header-only Unicode/escaping repair, ordinary ASCII names unchanged, exact approved legacy fallback; PDF contents, formatting and renderer unchanged. Implemented and focused checks pass as recorded above; native/browser/final evidence remains pending. This is not a broader filename or legal-output policy exception. |
| REG-30 / U6-F2; REG-31/32/33/49 | Notes P5 deliberately does not cancel DB work. Keep actual-promise leases, first-come 3-process/2-account caps and late-ACK semantics. Three stalled requests occupy three process leases; shared DB capacity can still affect other features (C10). Cancellation/timeouts, reserved capacity, cap/retention policy or mysql2 global changes need a distinct decision plus deployment evidence. PR-01 is caller-wait bounding only. |
| U1-F1, public assets | Choose platform-only public assets versus manifest-provider routing before any storage repair/migration. Startup can verify vault manifests while runtime serves Forge; not exercised under the current no-migration design. No public-asset migration or infrastructure action is authorized. |
| Remaining classifications/design limits | Preserve Nick's classification boundary for REG-51–58 and REG-60/61, except that narrow proposed repairs above may proceed within P. They do not ratify the whole register, approve read-side SSE changes, close the runtime-message listener, or explain REG-61. Audit retention and optional NEL-bound changes remain decisions, not incidental cleanup. |
| Scope expansion | New audit/report caps, dropped audits/IDOR attempts, shared generation/report quotas, different deadlines, retries or late compensating writes are not included. Any approved security/product-policy change must be scoped separately rather than hidden in a repair. |

## Frozen-scope exclusions and user decisions

- **Tasks 6/14 stay unaccepted.** REG-09/FROZEN-MERGER (template/Relationship regexes), REG-34's prototype-named notes tags and any rendering-region change require a separate freeze exception. Notes tag output cannot be “fixed” through a silent renderer or legal-input change. Preserve REG-34's NEL/residual false-refusal and name-based retention-gate limitations.
- **REG-05 is only partly superseded:** expected-ID set ordering is already normalized; TiDB/render-input ordering remains unproven. Imposing a new order can change court-visible order or selection and is not an authorized cleanup. REG-10's repair receipt versus missing version-stamped green evidence remains unresolved; no documentary closure.
- **Tasks 7/8 remain open and moved past, not reopened.** Do not execute their prompts, implement exhibit/container/export-preparation binding, demand generic prerequisite acceptance, or imply those guarantees exist. PR-06 is admission only.
- Preserve every **AWAITING-NICK / UNRATIFIED** item, including Rules 7/18/19/20, Task 14's formStatus/Rule 18/R2 decisions and its unanswered unblocking options. No schema/migration/index, court wording/layout, renderer, preview-builder, legal or selection change.
- Preserve the four approved output behaviors: newest current P9 per deponent for P2; current-P1 re-render for P9 Exhibit A; P8 primary-affidavit override; package/exhibit reconstruction. Missing data stays warn-only with Generate anyway, without weakening ownership, integrity, audit or resource safety. Preserve the P10 carry-over decision and no Agent Archive account instruction. [R][R] §§2–6; [K][K] decision/preservation contracts.

## External-evidence blockers — not solvable by local green tests

| Blocker | Evidence still required / stop boundary |
| --- | --- |
| Task 19 / REG-41, REG-54/55 | [Gate A][T19] remains BLOCKED / AWAITING-NICK: no supplied infrastructure artifacts; all 20 expected-contract rows not evidenced. Deployed bootstrap/runtime/purge trust and permissions, bucket controls, approved KMS identity/policy and read-side enforcement remain unproved. Configured-value comparisons and mocked SDK calls are not policy proof. No AWS access or credential request/configuration now. |
| Engine, schema and pool / REG-42/43, U1-F8 | Establish actual MySQL 8.0/8.4 or pessimistic TiDB v8 mode/isolation, locking/transaction semantics, migration state, pool/query timeout/keepalive and replica facts under separately authorized evidence scope. Do not widen the engine pin. A disposable 64 KiB-page fixture, including any historical four-column TEXT+CHECK physical adapter, proves neither RDS/TiDB compatibility nor deployed schema; keep application schema unchanged. |
| Release/hosting/residency / REG-07/08/32 | Single-bundle artifact identity, per-deploy `GENERATOR_RELEASE`, host/network/replica configuration and Canadian processing/residency remain deployment facts. Canadian storage is not Canadian-only processing or compliance. No publication, production use or hybrid Step 4. |
| Word/pixels / REG-01/02 | **USER-DEFERRED-NOT-PASSED.** No Office retry or acceptance inferred from matching parts, a replacement renderer or hashes. C3 preserves the unruled-out internal `word/document.xml` byte differences. Permitted output comparisons must use accepted immutable fixtures and only authorized normalizations; they cannot erase the deferral. |

## Historical dispositions retained, not expanded into repair tickets

The [task reconciliation][T] contains every task's source disposition. All historical limitations remain in force, including details not repeated here; no queue checkbox or acceptance record is changed.

| Tasks / register families | Preserved disposition and limits |
| --- | --- |
| 1/2; 3/16/4/5 | Accepted only within review/execution/private-read/replacement/generation-audit scopes. No deployed-policy proof, exactly-once/idempotent retry, or locks lasting through slow provider completion (REG-44/45/46). The withdrawn complete-facts requirement stays withdrawn. |
| 6/14; REG-02–11 | Implemented/repaired but explicitly unaccepted; freeze/ordering/Word and evidence decisions above remain. Preserve Task 6's residual admission-log/fixture/Appendix A1 questions, Task 14 R2 and prior refusal wording. Historical INT-2/SEC-2 repairs do not close these tasks or the new envelope finding. |
| 7/8; REG-12 | Unchecked, moved past by user decision; absent binding guarantees remain recorded without reopening. |
| 15; REG-13/14 | Closed/done by user decision, not new verification. Browser scenarios A–D remain outstanding; later partial overlap is not their completion. At most one eligible reporting attempt is not guaranteed persistence; shared notes/export reservations and process-local limits remain. |
| 9/13; REG-15–23/50/59/60 | Limited user closures stand. Redaction must precede real client data; runtime `message` origin/source validation stays open before production. Chatbot rotation, absent client diagnostic trail, session/microtask/recovery/native-repost limits and P10 carry-over are not blanket new repair features. Cookie/native versus Bearer bounds remain asymmetric; stored-version GET navigation cannot carry Bearer. Chromium handoff is not saved-file receipt; mobile/WebView evidence remains absent. |
| 10/11; REG-24–35/49 | Limited closures stand with F1/O1, no-cancellation/retention decisions, first-come arithmetic erratum, native error-coverage limits and mock-only isolation cases. A started row without terminal means outcome unrecorded, not non-delivery. REG-24's old request/PDF-retention wording is superseded by scalar audit inputs tracked by actual-promise leases; unresolved SQL is not thereby cancelled. REG-29 recurred, still unexplained. |
| 12; REG-36–40/58 | Accepted with known limitations only. Partial same-tab/P8 session guard, post-final-check/cross-tab/expiry/no-reload gaps, provisional 4 MiB ceiling, heap/Unicode/letterhead/understated-header/mobile/pixel evidence and DOCX close-without-abort remain. jsdom mid-body rotation coverage is not comprehensive real-handler/browser proof. Browser abort is not server cancellation; no unrequested transport tidy-up. |
| 17/18; REG-48 and later observations | Documentation-only and verification-only acceptance respectively; REG-48's earlier “not accepted” text is stale. D9/MinIO and recorded evidence/count discrepancies remain. Historical green gates do not replace Task 20's failed/incomplete run or pending destination verification. |
| 19/20 | Task 19 blocked/unaccepted; Task 20 review finished but unaccepted and STILL-BLOCKED. Earlier “Task 20 not started” text is historical, not current. Review completion accepts nothing. |

### Corrections C1–C10 applied

| Correction | Controlling reading in this ledger |
| --- | --- |
| C1 | Attachment mislabel is lawyer-facing only; staff stores closed errorCode, no label. |
| C2 | Three medium findings were new: U1-F1, U2-F1, U4b1-F2. The export-asymmetry trio belongs to REG-61, not a fourth new finding. |
| C3 | Text-level date/citation explanations do not establish complete `word/document.xml` byte equality. |
| C4 | Review history records four resumes, then a fifth step replacing fan-out with headless sessions; not “three resumes.” |
| C5 | U5-F5 is tagged REG-14 and U6-F5 REG-27; neither is register-free or a new implementation ticket. |
| C6 | A generation rate unit is spent, not held for later release; the render buffer is held across the audit wait. |
| C7 | Observed 413 makes the link unusable, hides retry and offers Review and generate again; regeneration supersedes the row, while prior provenance/success audit remains. |
| C8 | Export archive bytes are held across the started audit, not the failed-build path where no archive exists. |
| C9 | Seeded credential resolution targets AWS STS in the seeded region; only S3 targets local MinIO. No actual request was established by the diagnosis. |
| C10 | Notes leases constrain that route, but unanswered queries also consume the shared mysql2 pool; other features are not universally unaffected. |

## Parent evidence required before any repair closure

1. Record the precise allowed file delta and an original-behavior red reproduction for each candidate. Implement minimally, serialize overlapping edits and retain each report's complete regression matrix. No skips, assertion weakening, fabricated baselines or speculative timeout increases.
2. Produce fresh source-bound green evidence for connected behavior, then idle full serial gates and permitted strict output comparisons. Capture commands, exits, counts, exclusions, environment/build identity and protected-source comparison against the immutable import; normalize only the authorized timestamp text, not whole DOCX members.
3. Correlate actual fictional UI/route attempts with native audit/provenance rows and delivered bytes, keeping bare-render, validation-archive and delivered-container digests distinct. Prove final browser-loaded build identity. Missing fixtures/authentication/native/browser evidence stays an explicit gap, not a pass.
4. Obtain the independent final-delta review required by P. Keep permitted-repair completion separate from historical task acceptance, Word deferral and external evidence. Source-frozen or policy-dependent expansion stops for Nick; AWS, production, managed-DB use, publication and Step 4 remain prohibited.

[P]: ../../plan.md
[R]: ../../outputs/task20-final-steps-0-3-review-2026-10-30.md
[K]: ../../.work/hybrid-remediation/task18/claude-pass01/known-gaps.md
[T]: task-reconciliation.md
[TL]: tooling-ledger.md
[T19]: ../../.work/hybrid-remediation/task19/claude-pass01/final-status.md
[AW]: /home/ubuntu/probatepro-integration-evidence/investigations/audit-waits.md
[DR]: /home/ubuntu/probatepro-integration-evidence/investigations/debug-redaction.md
[DS]: /home/ubuntu/probatepro-integration-evidence/investigations/dev-seeding.md
[AL]: /home/ubuntu/probatepro-integration-evidence/investigations/attachment-label.md
[DE]: /home/ubuntu/probatepro-integration-evidence/investigations/delivery-envelope.md
[EP]: /home/ubuntu/probatepro-integration-evidence/investigations/export-preflight.md
