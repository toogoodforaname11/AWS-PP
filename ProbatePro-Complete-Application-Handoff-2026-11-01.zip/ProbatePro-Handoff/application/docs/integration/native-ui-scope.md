# Native/browser fixture scope — 2026-10-30

This is private verification of the imported application and permitted repairs, not deployment, production acceptance, or a substitute for Task 19. The managed staging database remains unused. The only database eligible for this fixture is the freshly created loopback MySQL instance identified by its owned server UUID, exact data directory, database, port and unchanged application-schema fingerprint.

The fixture uses MySQL 8.4.13 with 64 KiB pages and the previously documented four-column TEXT+CHECK physical adapter. The adapter preserves each 10,000-character bound and literal default; it is not an application-schema edit, migration, or evidence of standard RDS 16 KiB or TiDB compatibility. Native rows contain only intentionally fictional people, estates, attachments and notes.

## Application boundary

The existing fixture design mounts the real tRPC router/context, delivery handlers, origin guard, storage proxy, real MySQL query/persistence functions and the served production build. It does not invoke the ordinary application startup entry point or use its managed resources. External storage and OAuth are not contacted. A loopback-only mock implements the existing provider protocol for fictional uploaded attachments; it is not AWS/S3/STS/KMS policy evidence.

A private test issuer calls the existing SDK to sign sessions for fixture-created users. Actual requests still use the existing cookie/Bearer model, JWT signature/expiry checks, native user lookup, session-version revocation and authorization. This is **fictional session issuance, not a real Manus OAuth sign-in**, and no user identity/context is monkeypatched. Harness code and generated secrets remain private and are not installed as application authentication or published in Preview. A loopback test UI does not establish cross-site HTTPS Preview login behavior.

## Evidence and capture

Before startup, verify the complete static route declaration and source/build fingerprints. Capture only deliberately armed fictional deliveries, recording byte counts/digests separately from application persistence. Such private QA capture is intentional evidence, not application storage or a non-retention exception. Correlate attempts with native audit/provenance and report rows; distinguish server handoff from an actual browser-saved file.

Use bounded, estate-scoped fault adapters for controlled failures, late acknowledgements and preview delivery. No database trigger, application policy change, blanket deletion, or production credential is permitted. Preserve historical Task 15 scenarios as outstanding if the original A–D instructions were not supplied; new overlapping browser cases must not be falsely labelled their exact completion.

Verify normal, retry, failure, stale/expired/tampered, ownership and incomplete-data flows; inspect controls and layout at desktop and narrow widths. Compare immutable accepted document/preview fixtures using only the approved normalization contract. Any missing image/template DOCX golden, native pixel, OAuth, deployed-policy or historical-incident evidence stays explicit. Word remains USER-DEFERRED-NOT-PASSED; no Office action is authorized.

### Native test-mode correction before startup

Source inspection found that `VITEST` on the development tier exempts the costly-route and direct-document generation limits. Leaving it enabled throughout the historical harness would therefore not exercise the ordinary limits. A first startup without it was correctly stopped by the private guard: the application's existing development fallback had transiently seeded local storage defaults in that disposable child. No listener survived, no AWS access occurred, and no project/environment configuration was changed.

The private `entry.ts` now preloads **only** `server/_core/env.ts` with its existing seeding exemption, removes `VITEST` immediately, checks that all forbidden storage/approval names remain absent, then dynamically imports the UI harness. Every router, SDK and request handler loads and runs with `NODE_ENV=development` and no `VITEST`. The provided fictional encryption key means the env module's encryption helper never needs its test-key fallback. This is a declared fixture seam, not ordinary-startup evidence or an application-policy change. Live UUID/directory/name checks, real session validation, native database authorization and the ordinary request limits remain required. No real Manus OAuth or public HTTPS Preview claim is made.
