# Integration tooling ledger

## DEP-01 — explicit native-tool permissions on pinned pnpm 10

Before edits, the imported root workspace has no build-script permission list, and the existing destination installation records esbuild, @tailwindcss/oxide and core-js as ignored builds. The imported chatbot uses `allowBuilds: { esbuild: true }`, which must not be assumed compatible with the pinned pnpm 10.4.1. This is installation-policy compatibility, not permission to upgrade packages.

Connected features are TypeScript/TSX execution, Vitest, Vite's Tailwind build, the root esbuild bundle and chatbot builds. The minimal destination change adds pnpm-10 `onlyBuiltDependencies` entries for the required root esbuild and @tailwindcss/oxide installers, keeps core-js's optional postinstall explicitly blocked, and translates the chatbot's existing esbuild permission to `onlyBuiltDependencies`. Preserve every package/lockfile byte, the package-manager pin, override/patch settings and original line endings. Run both frozen installs with an isolated HOME, empty npm config and an explicit non-secret child environment; inspect actual ignored-build output, rebuild previously blocked required tools and execute the esbuild consumer before any gates. No application startup, migration or database connection is part of installation.

Status: planned; fresh installation receipt belongs under `/home/ubuntu/probatepro-integration-evidence/dependency-setup-2026-10-30/`. Do not infer application success from installation success.

## GATE-01 — cloud-safe execution and fixture portability

Keep the original transferred gate runner and historical baselines untouched. A destination runner must retain serial worker flags, the sole excluded live-storage test, all six gates, frozen checks before/after and stop-on-first-failure. It must refuse environment files, generate disposable test settings, isolate SQLite paths, redact output, block non-loopback test networking and write fresh source-bound results outside the application. No managed database DSN or provider credential may reach tests/builds.

Task 20's P5 timeout and the two unexpected worker exits remain unexplained. Reproduce them on an idle machine before any repair assertion; do not change timeouts, skip tests or weaken assertions to get green.

The preview suite currently depends on 28 explicitly transferred fictional `.work` payload fixtures. Before repository saving, promote only required, verified fictional fixture bytes into a dedicated versioned test-fixture directory and point the test there; do not commit private `.work` material. The 26 accepted fictional DOCX/preview baseline pairs are immutable test assets, not fresh generated captures. Any repository promotion must preserve their recorded hashes and provenance. A stronger comparison must include every DOCX member, normalizing only `dcterms:created` and `dcterms:modified` text, rather than ignoring the entire core metadata part.

Status: pending. Fresh strict comparison and fresh gates have not yet run.

## FIXTURE-01 — fresh native resources, not a deployment rehearsal

The cloud CPU architecture must be checked before selecting a portable MySQL binary. Use an official checksum-verified binary in the private evidence tree, not a system service, a copied Windows database or an existing database. Bind only loopback; verify process, port, data-directory and database identity before writes. Recreate the established 64 KiB InnoDB page assumption explicitly. If the four overwide intake payload columns need the historical TEXT plus 10,000-character CHECK fixture adapter, record it only in disposable DDL, without modifying the application schema or any migration.

Task 19 stays blocked. A portable MySQL fixture, including a different 8.4 patch release on Linux, cannot prove RDS/TiDB row-size, transaction, pool, migration or residency compatibility. No ordinary app server or fixture server has started yet.

### DEP-01 diagnostic correction — first install stopped

The first root install exited 0, but its ignored-build output showed that the required scripts were still blocked. The chatbot install exited 1 with `ERR_PNPM_IGNORED_BUILDS`. Source inspection established that the global launcher is **pnpm 11.25.0**, which delegates to 10.4.1 for the pinned root but uses 11 for the unpinned nested chatbot. It rewrote the chatbot YAML's esbuild permission into an unresolved placeholder. Separately, the actual cached pnpm 10.4.1 code reads permission lists from its early configuration path, not workspace YAML, and requires a nonempty workspace `packages` field.

The diagnosed correction is to execute the cached, identity-checked **10.4.1 CLI directly for both packages**, add `packages: [.]` to the chatbot workspace, keep reviewed permission lists in YAML and explicitly forward the same narrow lists as supported CLI flags for this older pin. Preserve the failed chatbot dependency directory outside the app rather than delete it. No package-manager upgrade, broad script allowance, interactive approval or package/lockfile change is authorized. Fresh recovery logs and the actual consuming-tool check must pass before application gates run.

References: the installed 10.4.1 implementation's `only-built-dependencies` option and `getOptionsFromRootManifest`; [pnpm 10 configuration](https://pnpm.io/10.x/settings); [pnpm 11 migration behaviour](https://pnpm.io/blog/releases/11.0). The original failed attempt remains evidence, not a pass.

### DEP-01 verified recovery — installation only

Recovery 1 completed both frozen installs under pnpm 10.4.1 with package/lock hashes unchanged and a working esbuild consumer, but actual ignored-build output still listed the required native installers. Therefore its exit-zero rebuild was **not** accepted as proof. Inspection of 10.4.1 showed that its default empty manifest allowlist overrides direct list flags. Recovery 2 instead forwards `only-built-dependencies-file` to a temporary JSON array **derived from the reviewed YAML list**, without changing either package manifest. This supported compatibility bridge executed all four installed root esbuild installers, @tailwindcss/oxide's installer and both chatbot esbuild installers, each reporting Done. Both actual `pnpm ignored-builds` outputs then reported None. Core-js remained intentionally unapproved.

Receipts: `dependency-setup-2026-10-30/recovery01/result.json` records frozen installation and package/lock preservation; `recovery02/results.json` and its saved rebuild/ignored-build logs record the effective permission correction. Final CI/install tooling must use the same pinned executable and YAML-derived permission-file bridge, not the ambient global launcher. Application gates and UI/native verification remain pending.

The QA network guard's self-test passed: loopback HTTP succeeds, while a non-loopback socket and fetch are refused locally before external traffic. The first official MySQL download endpoint returned HTTP 403 without creating an archive. The matching official CDN answered HTTP 200 for the same package; its published checksum must still match before extraction/execution.

### GATE-01 initial diagnosis — no speculative application fix

Fresh `import-idle-diagnostic01` ran the imported application source with the repaired tooling, no review agents/builds/application services, serial one-worker/no-file-parallelism/no-cache flags and scrubbed, loopback-only settings. A low-CPU official binary download continued in the background; it was not a database service. Root TypeScript check exited 0 (32,965 ms). The three Task 20 failure files all passed: **3 files / 68 tests**, no worker exits (focused gate 24,859 ms). All 407 protected hashes and the runner's source-before/source-after manifests remained equal.

This does **not** establish why Windows Task 20 timed out or why those workers exited. It establishes a fresh Linux non-reproduction on the unchanged imported application bytes; no timeout, assertion or application workaround was added. The full final-source suite remains necessary. Exact commands and source identity: `/home/ubuntu/probatepro-integration-evidence/gates/import-idle-diagnostic01/`.

## Full-suite diagnosis — integrated-full01 (2026-10-30)

The first portable full run passed root TypeScript checking, then failed the root suite: 33 files failed / 327 passed; 736 tests failed / 6,710 passed among 7,446 reported tests. The later four gates did not run. The before/after source manifests matched and protected sources remained unchanged. This is retained failure evidence, not an acceptance result.

A minimal native-HTTP control reproduced `EQAOFFLINE` at the guard's Unix-socket classifier. The guard incorrectly classifies Node HTTP's null TCP path as a Unix socket. Focused diagnostic `full-suite-diagnosis02` additionally showed that coercing an unspecified listener host to an explicit hostname makes its address unavailable synchronously, breaking Supertest's normal `listen(0)` contract. The repair must keep default listeners strictly on loopback while preserving this synchronous address contract; it must not permit remote hosts, wildcard listeners, arbitrary Unix sockets, external DNS or UDP. Connected surfaces are native HTTP, Supertest, the delivery and auth route suites, TCP/HTTPS/fetch, and the private fixture launcher.

The same focused run identified two storage-facade collection failures: an eager re-export reads `storageReadFailureIndex` from partial registry mocks even when the notes tests never use attachment attribution. The proposed repair is a lazy function facade delegating to the same trusted registry accessor, not weaker mocks or different failure attribution. Connected surfaces are notes CRUD, notes/export isolation, facade imports, and multi-attachment attribution.

The CI contract still expects inline shell commands from the historical workflow. The replacement must follow the actual CI entry point through pinned bootstrap and six-gate execution, retaining least privilege, immutable action pins, both frozen installs, serial root/chatbot checks, build, the sole live-UAT exclusion and the strict render comparison. No required assertion is to be replaced by a comment or removed merely to obtain green results.

The first diagnostic helper itself used an unexported redaction function and exited before producing useful results. Its one orphan test worker was verified against the project/process identity and stopped; its stale lock was preserved, not discarded. The existing sanitizer is now exported, and the private diagnostic runner checks that export before spawning and owns/cleans its child process group. These tooling failures do not justify changing application security or document behavior. Fresh connected and full gates remain required.

### Second complete-run attempt and independent tooling review

`integrated-full02` passed the root typecheck, complete root suite and chatbot typecheck. It stopped on one chatbot test (204 passed / 1 failed of 205); build and render did not run. The isolated `chatbot-env-red01` reproduction identifies the omitted `chatbot/.env.example`, which the transfer deliberately excluded along with every environment file. Do not skip or weaken its copyable-example assertions. Author a new credential-free documentation template from the existing runtime contract, with an empty API key, reserved invalid example endpoint, unchanged model/defaults and no database/AWS/production credentials. Permit only that exact byte-pinned template in verification; all runtime environment files and unreviewed hooks must remain refused. This is a new documentation artifact, not a copied environment or runtime configuration.

The alternate independent read-only tooling review completed on stable source (`independent-tooling-review-pass02/review.json`). It found three concrete guard/ownership defects: mixed listener path/port options bypass loopback coercion; the public `dgram.Socket` constructor bypasses the UDP factory prohibition; chatbot data-link cleanup checks only the destination, not the created link's device/inode identity. Reproduce each using loopback-only dummy services and new task-owned links, then reject ambiguous listener options, close the ordinary UDP-constructor/prototype paths, and require exact symlink identity before cleanup. No remote packet is needed for reproduction. Connected surfaces are Node CJS/ESM networking, native HTTP/Supertest, the guarded UI, chatbot disposable storage and all six gates.

Add the controls as a verification preflight so these failures are caught before a lengthy suite. Include `.github/dependabot.yml` in the source fingerprint because the CI contract reads it. The review did not inspect all fixture/provenance/dependency inputs or run tools; those evidence gaps must be supplied in the separate integrated final review. Its first attempt returned a non-stop completion and was not accepted; the corrected attempt preserved completion metadata and visible output. No application, document renderer, legal selection or schema change is authorized by these tooling findings.

### Clean-candidate bootstrap invocation correction

The first private candidate copied 1,267 screened source/context files with identical verification-source hashes, no dependencies/build outputs/runtime data, and a disabled local push URL. The actual CI entry point verified/provisioned the unchanged Corepack integrity pin and completed the root frozen install and required native rebuilds. It stopped because pnpm 10.4.1's read-only `ignored-builds` command rejects `--store-dir`. The exact failing flags reproduced exit 1 (`Unknown option: store-dir`); the otherwise identical metadata query without that install-only flag returned exit 0 and `None`. Keep store isolation on install/rebuild; omit that unsupported flag only from the read-only metadata query. No package, lock, permission expansion or app test change is involved. Preserve the failed candidate and rerun the actual entry point in a new candidate, rather than recycling its evidence label.
