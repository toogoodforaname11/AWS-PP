# Notes-download filename approval

Nick approved this separate repair on **2026-10-30 at 13:39:22 −07:00**: “Approve the notes-filename repair.”

The approved payload is limited to notes PDFs' download headers:

- Keep the filename pattern `Notes - [estate name] - YYYY-MM-DD.pdf`.
- Correctly encode the Unicode filename for modern browsers.
- Remove unsafe header-control characters.
- Use `Notes - Estate - YYYY-MM-DD.pdf` as the fallback for older browsers unable to read Unicode filenames.
- Keep ordinary ASCII filenames unchanged.
- Leave the PDF's contents, formatting and renderer unchanged.

This is not approval to change any PDF drawing/text, court wording/layout, legal/selection logic, schema, notes-tag behaviour, cancellation, leases, caps, audit policy, retention, source task acceptance, AWS/infrastructure or publication. Any shared helper must preserve other delivery headers' existing behaviour unless the change is strictly necessary for this approved notes header and is separately covered by regression evidence. No header injection or raw parser/error text may be introduced.

Connected features to recheck before closure: ordinary notes download; names with Ł, curly apostrophes and other Unicode; quotes/backslashes/control characters; exact existing filename pattern/date; legacy fallback; MIME/error headers; audit-before-bytes; failed/late sends and existing leases; cookie/native and Bearer/fetch delivery; unchanged PDF bytes under the established fictional comparison conditions.

Status: approved and implemented in the destination. Focused, final-source and native/browser filename evidence is recorded below; PDF-content defect INTEG-PDF-01 remains separately open and no production acceptance is granted.

## Implementation and focused evidence

The destination now builds an ASCII-safe `Content-Disposition` for notes only. It preserves the ordinary ASCII header, encodes Unicode through `filename*=UTF-8''…`, uses the approved generic legacy fallback, removes control characters, and quotes backslashes/quotes safely. Partial attachment headers are removed if notes sending fails before headers are sent. Other form/export filenames retain their existing behavior. No dependency or schema change was required.

- **Red:** `notes-filename-red01`, 7 failed / 2 passed. Unicode/control names produced 500 responses or unsafe/non-ASCII dispositions; quote/backslash names were not encoded safely.
- **First connected run:** `notes-filename-green01`, 218 passed / 3 failed. The new 9-case suite and six connected files passed; an existing timer test still intentionally used a valid Unicode name to induce a header failure. Its now-successful mocked response held a lease, causing two later cleanup failures. This was diagnosed from the exact assertions and response lifecycle, not treated as a reason to change production caps/timers.
- **Preserved failure coverage:** existing T7/T8 and R14 cases now inject an actual `TypeError` from `setHeader` instead of relying on a legitimate name being broken. All failure/audit/timer/listener assertions remain; the real-response failure additionally requires JSON MIME.
- **Green:** `notes-filename-green02`: root TypeScript exit 0; 7 files / **221 tests passed**, no skips or timeout increases. Notes PDF drawing/text source is byte-identical to the immutable import, and all 407 protected hashes remain equal. The real-route tests correlate the delivered PDF hash/length to mocked started/finished audit writes; these mocked writes are not native durable-row proof.

Exact logs and source identities are private under `/home/ubuntu/probatepro-integration-evidence/gates/`; the implementation receipt is under `repairs/notes-filename/`. Full final-source gates, browser downloads and native durable audit evidence are still outstanding. The approval does not close source Tasks 6, 14, 19 or 20 or change the historical STILL-BLOCKED determination.

## Native/browser follow-through — 30 October, 20:29 −07:00

The final-source cookie path saved `Notes - Łukasz O’Neill QA - 2026-10-31.pdf`, matched the captured response exactly, and matched every byte of the immutable source renderer replay (1,726 bytes; zero normalized bytes; own notes only). This does not establish Bearer-path success.

The actual Bearer browser then reproduced a connected defect: the server returned a valid 200 PDF and the approved extended filename header, but the client rejected it with its generic download failure and did not hand a file to the browser. `attachmentDelivery.ts` still recognizes only the old quoted filename header. The private capture is `native-ui-20261030/captures/notes-unicode-bearer-red.json`; the error screenshot is `/home/ubuntu/screenshots/127_0_0_1_2026-10-31_03-29-21_7125.webp`.

The follow-through repair is limited to accepting this approved PDF-only extended header in the existing client transport. The ordinary header behavior (including the existing quoted/Latin-1 regression), cookie/native path, DOCX/ZIP parsing, authentication, body/type/size/completeness checks, cancellation, retry policy and feedback must remain intact. No PDF renderer, document/schema or package-policy change is permitted. The connected red tests use the real notes-header builder and public delivery functions. Earlier full gates remain valid for their recorded source, not for this forthcoming correction.

### Separate frozen-renderer finding — INTEG-PDF-01

Visual inspection of the actual Unicode cookie-path PDF shows its estate-name line as garbled glyphs, while the ASCII title and note body remain readable. The text extractor likewise returns a garbled name rather than `Łukasz O’Neill QA`. The actual file is `native-ui-20261030/browser-downloads/notes-unicode-cookie.pdf`; its already-recorded source replay is byte-identical with zero normalizations. This is therefore present in the unchanged imported notes renderer, not caused by the filename header or new client parser.

**Disposition: confirmed, unresolved, frozen-renderer boundary.** No PDF font, text drawing, layout or renderer code is changed. The approved filename repair is not authority to repair PDF content. Exact source parity and a correct saved filename must not be reported as Unicode PDF-content correctness or production readiness. A separate explicit renderer decision is required before addressing this issue.

The client follow-through reproduced **7 failed / 15 passed** in `notes-header-client-red01`, then passed root typecheck (`notes-header-client-check01`) and **415 tests across 10 files** (`notes-header-client-green01`). The new PDF-only parser accepts the exact approved server header, rejects invalid UTF-8/encoding, control characters, wrong extensions and duplicate extended parameters, and retains the original ordinary/Latin-1/quoted header behavior. No existing test assertion was removed or weakened. Document, dependency-pin and protected-source checks stayed unchanged. Fresh full-source gates, independent supplemental review and actual Bearer-browser re-verification remain required.

## Final follow-through

The independent PDF-only client-delta review found no concrete introduced defect and explicitly left runtime/final-source verification to the parent. The `post-popup05` clean application-source run then passed all six gates. On its source-matched build, the actual Bearer browser saved the full Unicode filename, matched all 1,726 captured response bytes and correlated both native notes delivery events. The unchanged renderer replay matched every PDF byte with zero normalization. The duplicate `(1)` suffix came from the browser's existing download directory, not the application filename.

This closes the approved **filename/header** repair only. INTEG-PDF-01 remains a confirmed unresolved renderer/content limitation; exact byte parity does not make the garbled estate-name line correct. See [final verification](final-verification.md).
