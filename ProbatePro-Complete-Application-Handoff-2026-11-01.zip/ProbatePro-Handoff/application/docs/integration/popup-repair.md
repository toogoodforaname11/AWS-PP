# Single-form missing-information popup repair

## Authority and scope

Nick requested fillable missing fields in generation popups on 30 October 2026, then explicitly selected **“Fix single-form popups; keep the bulk/package restriction”** at 17:11:47 -07:00. Keep the existing styling, field relevance filters, Generate anyway behavior, hard security/evidence refusals, and canonical field meanings. Do not change shared legal/selection requirements, the override allowlist, schema, document wording or rendering. Bulk/package inline editing remains disabled. The original Windows source and its queue remain untouched.

## Observed source and UI evidence

The immutable baseline comparison shows the imported `PreGenerateDialog.tsx` differs from original `db0d7e9` only in Task 13 retained-choice presentation; its inline-edit catalog was not replaced during integration. The real fictional P5 browser flow exposed an uneditable `estate.willStatus` row. The private synthetic census (`popup-regression-20261030/census-before01.json`) identifies 44 rendered Intake fallback/residue rows, 31 with named fields. Those numbers are a UI wiring inventory, not proof that every combination is legally applicable. Several residues are OR sentinels/legacy aliases, and some predicates are record/conflict warnings rather than missing scalar values.

## Narrow implementation

Add client-only typed canonical completion controls in `client/src/components/CanonicalPopupFields.tsx` for the existing Intake fields missing from the single-form popup. Copy existing labels, option tokens, multi-select rules, structured affidavit shape and coupled writes from `EstateDetail.tsx`; reuse protected shared coupling helpers without editing them. Do not widen `shared/inlineFieldControls.ts` or server override acceptance. Present controls only for the existing displayed form-content gaps and their relevant follow-ups, never generic property editing or server-managed fields.

Wire these drafts into `PreGenerateDialog.tsx` and the existing owner-scoped, CAS-aware `estate.update` continuation in `EstateDetail.tsx`. Canonical-only values must save before the authoritative re-check, not pretend to work as unsupported document-only overrides. Preserve checkbox semantics for unrelated transient values. Only explicit user changes are submitted; retain typed values after failure and bank only confirmed submitted values. Existing specialized contact/upload/inventory editors remain responsible for their own record types. Diagnose any connected dropped-field or unreachable-editor defect separately with a red regression before changing it.

## Connected checks

New component regressions must first reproduce missing controls in the unchanged dialog, then cover text/date/select/multi-select/structured answers, coupled will/electronic facts, no inferred facts, save failure/retry, hidden inactive controls and unchanged bulk/package behavior. Parent wiring must prove save → fresh preflight → generation ordering, current CAS revision, no stale or discarded answers, cancellation and exactly one client invocation. Run the existing popup, inline-fill, form-specific generation, regeneration/retry and server override/input tests, followed by all six serial gates and strict immutable renders. Rebuild and reverify the source-bound native fictional browser flow before any completion claim.

## Current status

Diagnosis and private census complete; no popup implementation or new passing regression evidence yet. Public Preview remains stopped. The task-owned native UI service was stopped before popup tests; its fictional MySQL data, download captures and earlier evidence are preserved. Prior clean-CI and browser results remain evidence for the earlier source, not final acceptance of this correction.
