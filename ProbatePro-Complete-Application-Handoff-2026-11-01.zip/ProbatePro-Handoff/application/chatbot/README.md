# ProbatePro Companion Chatbot

A per-user AI assistant for ProbatePro. It talks to the app exclusively through the
app's own HTTP API under the signed-in user's forwarded session token — so it can only
ever see and touch that user's estates, enforced by the app itself (`assertEstateOwned`).

> ⚠ **Topology (as shipped): the bot runs IN-PROCESS inside the main server**, mounted
> at `/chatbot` by `server/chatbot.ts` (`CHATBOT_EMBEDDED=1`), not as a separate service.
> It was *designed* as a standalone process (that mode still exists unembedded on
> `127.0.0.1:3100`), but the embed means the app now also owns `server/chatbot.ts`, the
> `server/_core/index.ts` mount + two CORS headers, and a `chatbot/` prod-build step — it
> is **no longer** "a 2-line widget mount." The in-process embed also **downgrades
> isolation from structural to by-convention** — see *Security residuals* below.

## What it does

- Chat about the user's estates (reads via the app API: estates, contacts, inventory,
  readiness, distribution, deadlines, documents)
- **Drop files or folders** (will, death certificate — PDF/DOCX/images/text) and it
  extracts facts and **proposes** intake values / contacts / inventory items
- All writes are **propose → human Apply**: the model can never mutate data itself
- Knows which page/tab the user is on; can suggest (never force) navigation

## LLM backend

The agent talks to the built-in **Forge API** (OpenAI-compatible) via raw `fetch`,
mirroring the app's own proven Forge usage (`server/routers.ts` / `server/_core/llm.ts`):
`POST ${BUILT_IN_FORGE_API_URL}/v1/chat/completions`, Bearer `BUILT_IN_FORGE_API_KEY`,
tools as plain JSON Schema, a manual tool loop. No `openai` SDK / `zodFunction` (that stack threw
on Zod-v4 strict schemas and took the chatbot down). Default model **`gpt-5-mini`**
(`CHATBOT_MODEL` overrides — use any Forge-served, tool-capable model).

## Run it (dev)

Embedded is the shipped mode — the app's own `pnpm dev` (repo root) serves the bot at
`origin/chatbot`; the built-in Forge key supplies the model. The widget probes the bot on
idle; if the bot is down the app renders exactly as before — no widget at all. Both the
embedded assistant and EstateDetail AI-assisted import are fail-closed unless
`AI_PROCESSOR_APPROVED=true`. Keep the flag false until the processor agreement/terms
and public privacy package have been approved; the rest of ProbatePro remains available.

Standalone dev is still possible. Copy `.env.example` to `.env` and supply both Forge
settings; startup fails before listening unless the approval flag is true, both Forge
settings are present, and the URL is valid:

```sh
cd chatbot
Copy-Item .env.example .env
# Replace BUILT_IN_FORGE_API_KEY in .env; keep or change BUILT_IN_FORGE_API_URL,
# set AI_PROCESSOR_APPROVED=true only in an approved environment, and optionally
# override CHATBOT_MODEL. NOTE: chatbot/.env applies to STANDALONE mode only —
# in the shipped EMBEDDED mode the parent process reads the ROOT .env, and a
# flag set here is never read.
pnpm install
pnpm dev              # listens on 127.0.0.1:3100
```

- Tests: `pnpm test` · Typecheck: `pnpm check` · Prod: built by the app's `pnpm build`
- Conversations live in `chatbot/data/chatbot.db` (SQLite, gitignored). Delete the file
  to wipe all history. Never contains session tokens or file bytes.
- Conversation messages, proposals, and feedback are automatically pruned after 30 days
  by default; field-name-only security audit events after 365 days. Operators may shorten
  or extend those bounded windows with `CHATBOT_RETENTION_DAYS` and
  `CHATBOT_AUDIT_RETENTION_DAYS`.

## Origins / CSRF

The chatbot enforces its **own** browser-origin gate on every authenticated route (GET +
mutating), **independent of the parent app's CORS allowlist** (which is broad —
`*.manus.*`, `*.run.app` — and must not be the chatbot's trust boundary). A request is
allowed only when the browser `Origin` is absent (same-origin GET / server-to-server),
**same-origin** (a secure `Origin` authority matching the request `Host`), `localhost`/`127.0.0.1` **only when
the request `Host` is also local** (finding 2 — a malicious `localhost:5173` page is not
trusted against a production host), or an **exact** configured origin. Wildcards are never
trusted; `X-Forwarded-Host` is never trusted. HTTP is allowed only on loopback; every
non-local browser origin must be HTTPS.

The **parent app** now applies the same posture to its OWN authenticated routes: a
credentialed cross-origin request to `/api/trpc` (or any authed route) is rejected before it
reaches a procedure (`server/_core/index.ts`), closing the app-wide variant of this hole
(finding 1) — an attacker on a parent-allowed origin can no longer bypass `/chatbot` and read
the victim's estates directly through tRPC.

- Same-origin `/chatbot` (the shipped topology) works with **no config** on any host
  (`probate-pro.com`, `*.run.app`, `*.manus.space`) because the widget is same-origin.
- A **custom domain behind a Host-rewriting proxy** must set `APP_URL` (or
  `CHATBOT_BROWSER_ORIGINS`, a CSV of exact origins) to the public origin, or the gate
  will (fail-secure) 403 the widget.
- Standalone dev only: leave `ALLOWED_APP_ORIGINS` unset (trusts exactly
  `APP_BASE_URL`'s origin); never set a port/host wildcard — the service drops insecure
  regex values with a warning.

## Security posture

- The forwarded JWT is memory-only: never stored, never logged (sink-level redaction),
  never shown to the model; the Forge auth header uses the Forge key only
- Deny-by-default procedure registry (`src/allowlist.ts`) — `estate.previewFile`, docgen,
  deletes and settings are structurally unreachable
- The model never sees storage keys (opaque doc-id indirection)
- Field allowlists bound what can even be *proposed*; every value carries provenance and
  requires a human Apply click; every applied/rejected write is audited in SQLite
- Dropped-file content enters prompts wrapped as untrusted data; sworn-document drafting
  is out of scope by system prompt AND by tool surface
- **Cross-origin**: the browser-origin gate (above) runs BEFORE session validation, so a
  disallowed origin never triggers an `auth.me` call and can never receive a rotated
  session token. **Route-level** two-user isolation (conversations/proposals) is proven in
  `test/security-isolation.test.ts`; cross-user ESTATE/document reads are enforced APP-SIDE
  (`assertEstateOwned`, covered by the app's own tests) — the bot always forwards the
  requester’s OWN JWT, so a foreign estate id is rejected by the app, not the bot. It is
  **not** a full browser→app→DB integration proof.
- **Rate-limit isolation**: in the shipped embedded topology, the parent app verifies the
  signed session JWT locally before the chatbot's edge limiter and writes only the verified
  subject to `res.locals`. A valid first request therefore bypasses the shared unverified
  `cold:` bucket even while rotating forged tokens exhaust it, then receives the normal
  post-auth per-user limit. The hint never authorizes a handler; the chatbot still runs its
  exact-origin and app-backed authentication gates. Standalone mode has no app signing key
  and remains loopback-only.

## Security residuals & AWAITING decisions

These are open on purpose — **not** silently accepted. Track them here:

1. **Structural isolation (AWAITING Nick).** The in-process embed removed the separate-
   process boundary; the bot now runs in the same runtime as `JWT_SECRET` and the app DB
   pool. It stays safe only because its modules never import them — enforced as a **gate
   tripwire** (`test/security-isolation.test.ts` blocks app-tree imports, the app DB/ORM
   stack, and app-secret reads; run via root `pnpm test:all` — there is no repo CI yet, so
   it must run in the manual gate sequence). This is a tripwire, not a hard boundary. **Decision
   (2026-08-01): keep the embed + tripwire; restoring a separate process behind a same-
   origin `/chatbot` proxy is the recommended future *structural* hardening — Nick's call
   on when it is worth the ops cost.** It is not a current exploit (the cross-origin hole
   is closed).
2. **Forge-processor use is fail-closed (Rule 19 — UNRATIFIED). The recorded counsel
   launch blocker remains OPEN as Nick recorded it; the "core-app blocker CLOSED"
   reclassification written here on 2026-08-04 was ChatGPT's proposal, not a Nick
   ruling, and was restored to a proposal on 2026-08-05.** Chat messages, estate data, and dropped-file
   content are sent to the Forge model endpoint. The Privacy Policy discloses the AI processor
   (§2 purposes, §4 sharing, §9 third parties — covering both the assistant and EstateDetail
   AI-assisted import). The widget repeats the processor disclosure in its empty state and
   persistent footer. AI-assisted import adds a point-of-use disclosure and requires the user
   to confirm authorization for that document. Unless `AI_PROCESSOR_APPROVED=true`, the
   embedded widget is not mounted, the standalone bot refuses to start, and AI import rejects
   before creating a record or calling Forge. The rest of ProbatePro remains available.

   Do not set the flag true until the Privacy Officer / counsel has approved the public privacy
   package, an executed DPA with the Forge provider is in place (retention, training,
   subprocessor, security, and jurisdiction terms), and any consent step counsel requires
   beyond the in-app notice has been implemented. The flag is an operational assertion of that
   approval, not a substitute for it. **Proposed reading (AWAITING Nick):** with the gate
   in place these external approvals block AI enablement rather than a core-app launch with
   AI disabled. Note before adopting it: the counsel package Nick recorded at `3b96b94` is
   app-wide (Terms/Privacy naming + governing-authority description), and the 2026-08-05
   storage arc further rewrote public retention/jurisdiction claims — counsel review of the
   legal-copy package remains an open pre-launch item for the core app regardless of the
   AI gate.
3. **Closed (scoped) — model data minimization for STRUCTURED reads.**
   `get_estate_snapshot` requires explicit, purpose-scoped sections and projects
   allowlisted fields: SIN/TIN, bank account number, account holder, bank address,
   internal ownership IDs, and storage locators are never sent to Forge **through the
   snapshot projections**. ⚠ The guarantee does NOT extend to `read_document`: it sends
   a stored document's full extracted text, and generated P10/P11 forms embed bank
   account number/holder/address on their face — so a user asking the assistant to read
   a generated form transmits those values. The Privacy Policy §4 discloses this
   full-text behaviour explicitly (2026-08-04 adversarial re-review).

### Closed app-storage isolation arc (2026-08-02 current worktree)

`/manus-storage/<key>` and `estate.previewFile` now require a real staff account and
server-resolved ownership before Forge is asked to sign the key. Estate uploads resolve through
an estate owned by that user; historical generated documents join their current/version row to
the owning estate; note, letterhead, and transient export keys use server-created user namespaces.
Portal JWTs are deliberately insufficient because the current portal has no file feature. Public
landing assets use exact full-key matching, not a suffix allowlist. Generic estate/contact/note/
delivery writes can no longer register a leaked key as owned, unsafe path segments are rejected,
and transient ZIP/download paths are user-namespaced.

The app suite includes route-level cross-account, suffix-bypass, raw-preview, locator-poisoning,
path-validation, and fail-closed regressions. This closes the static/application authorization
defect; live DB + real Forge download UAT is still required before calling the deployment proven.

## Kimi follow-up validation (2026-08-02 current worktree)

The eleven reported chatbot findings and their minor follow-ups were re-opened against
`787ce8f`, reproduced where possible, and repaired in the current uncommitted worktree:

- the Windows embedded-service import now uses a `file://` URL; invalid chatbot configuration
  throws across the optional mount boundary instead of terminating the parent process; the
  embedded auth callback always targets its actual loopback port;
- the Forge client performs real SSE assembly, handles JSON fallback, forwards cancellation,
  enforces a 60-second timeout, and treats truncated streams/upstream failures as failures. A
  partial or synthetic assistant answer is never persisted as success;
- Markdown sanitization handles CommonMark fence variants and reference/shortcut images. Raw HTML
  rendering is disabled and the live renderer suppresses images, preventing model-controlled
  remote-resource fetches;
- conversation export and account-wide clear are connected to visible, keyboard-accessible UI.
  Clear is transactional and removes all proposals belonging to the user, including orphaned
  rows, without touching another account;
- load/delete failures are surfaced; unread state advances only after a persisted terminal reply;
  copy, input, delete, focus, observer, and object-URL lifecycles have explicit accessibility and
  failure behavior; the panel no longer attempts to outrank every app overlay;
- configuration and dependencies now describe the actual Forge `gpt-5-mini` contract. The old
  commit-message model claim is historical and cannot be rewritten, but it is not the runtime or
  current documentation contract.

The follow-up also corrected a legal/product label missed by the report: the official B.C. Form
P10 contains numbered paragraphs 1–6 followed by Exhibit A Parts I–III; it has no official
“Part 3.” The app's Distribution card is a Nick-approved supplementary workflow that feeds the P10
distribution output, and is now described that way in UI metadata, the corpus, and the prompt.
No court-form wording, `server/docgen.ts`, preview mirror, readiness logic, generation/package path,
schema, or migration was changed by that correction.

Current automated evidence: `pnpm check:all` passed; `pnpm test:all` passed **2,624 app tests in
136 files** and **146 chatbot tests in 11 files**; `pnpm build` passed; and a Windows production-mode
dynamic-import smoke mounted the compiled handler with a floating loopback port. Targeted route,
streaming, sanitization, UI, database-isolation, product-help, and embedded-mount regressions also
pass. The UI contracts now explicitly cover renderer-level image suppression, composer/typing/hint
accessibility, stable copy-button observation, and keeping every Kairo layer below app `z-50` overlays.

This is not live-deployment proof. This environment has no browser runtime, Forge URL/key, app auth
secrets, or live database URL, so a real two-user browser→chatbot→Forge→app→database turn and a real
Forge object-store download/clear remain required before deployment can be called proven. Structural
separate-process isolation, processor disclosure/DPA, `inventory.accountNumber` minimization, and
product/legal sign-off on corpus scope and wording remain explicit AWAITING decisions.
