/**
 * PROPOSE-then-APPLY (mirrors the app's own aiImport.process -> applyImport
 * pattern, routers.ts:4335-4520, and security constraint C-11).
 *
 * A propose_* tool NEVER mutates the app. It validates against the bot-side
 * allowlists, builds a human-reviewable diff with per-field provenance, stores
 * the exact payload in bot SQLite, and emits a proposal event the widget
 * renders with Apply/Reject. Only the user's Apply click — a REST endpoint,
 * never a model tool — executes the STORED payload verbatim. The model cannot
 * modify a proposal between propose and apply.
 */
import {
  INTAKE_FIELD_ALLOWLIST,
  CONTACT_FIELD_ALLOWLIST,
  CONTACT_BOOL_FIELDS,
  INVENTORY_CATEGORIES,
  INVENTORY_LOCATIONS,
} from "./allowlist.js";
import { AppError, appMutation, appQuery, type AppSession } from "./appClient.js";
import * as store from "./db.js";

export type ProvenancedValue = { field: string; value: string; source: string };
export type DiffRow = {
  key: string;
  label: string;
  oldValue: string;
  newValue: string;
  source: string;
};
export type ProposalDiff = {
  kind: "intake" | "contacts" | "inventory" | "contact_updates";
  estateId: string;
  estateName: string;
  rows: DiffRow[];
  /** For contacts/inventory: one group of rows per created record. */
  groups?: DiffRow[][];
};

export type Rejection = { field: string; reason: string };

const MAX_VALUE_LEN = 2000;

function structuralCheck(field: string, value: string, rule: { maxLen?: number; validate?: (v: string) => string | null }): string | null {
  if (typeof value !== "string") return "value must be a string";
  if (value.length > (rule.maxLen ?? MAX_VALUE_LEN)) return `too long (max ${rule.maxLen ?? MAX_VALUE_LEN})`;
  return rule.validate ? rule.validate(value) : null;
}

// ── Intake ───────────────────────────────────────────────────────────────────

export function validateIntakeUpdates(updates: ProvenancedValue[]): {
  accepted: ProvenancedValue[];
  rejected: Rejection[];
} {
  const accepted: ProvenancedValue[] = [];
  const rejected: Rejection[] = [];
  const seen = new Set<string>();
  for (const u of updates) {
    if (seen.has(u.field)) {
      rejected.push({ field: u.field, reason: "duplicate field in one proposal" });
      continue;
    }
    seen.add(u.field);
    const rule = INTAKE_FIELD_ALLOWLIST[u.field];
    if (!rule) {
      rejected.push({ field: u.field, reason: "not on the intake allowlist (forbidden or unknown column)" });
      continue;
    }
    if (!u.source || !u.source.trim()) {
      // Provenance is mandatory (C-17): no source, no proposal.
      rejected.push({ field: u.field, reason: "missing source (say which document or message states this)" });
      continue;
    }
    const err = structuralCheck(u.field, u.value, rule);
    if (err) {
      rejected.push({ field: u.field, reason: err });
      continue;
    }
    accepted.push(u);
  }
  return { accepted, rejected };
}

export async function createIntakeProposal(args: {
  userId: number;
  conversationId: string | null;
  session: AppSession;
  estateId: string;
  accepted: ProvenancedValue[];
  signal?: { aborted: boolean };
}): Promise<{
  proposal: store.ProposalRow | null;
  diff: ProposalDiff | null;
  /** Fields skipped because the estate already holds exactly that value. */
  unchanged: string[];
}> {
  // Fresh ownership-checked read for old values — also proves the estate is the
  // user's own before anything is stored.
  const estate = (await appQuery(args.session, "estate.get", { id: args.estateId })) as Record<
    string,
    unknown
  >;

  // A proposed value equal to the stored one is NOT a change, and carrying it
  // breaks the feature three ways:
  //   1. the card renders "Victoria → Victoria" rows, so the user cannot see
  //      what Apply would actually do;
  //   2. a card made ENTIRELY of them applies cleanly and changes nothing —
  //      indistinguishable from a broken Apply, which is what was reported;
  //   3. detectIntakeDrift (below) guards EVERY field in the diff, so 11
  //      untouched fields become 11 extra ways for an unrelated Intake edit to
  //      refuse the one real change with a conflict.
  // Filtering here — the one place holding both the stored and proposed value —
  // fixes all three, and narrows the drift guard to the fields actually written.
  const unchanged: string[] = [];
  const changed = args.accepted.filter((u) => {
    if (String(estate?.[u.field] ?? "") !== u.value) return true;
    unchanged.push(u.field);
    return false;
  });
  // Nothing to write: create NO proposal row and NO card. An empty card the user
  // must dismiss is worse than a plain "the estate already says that".
  if (changed.length === 0) return { proposal: null, diff: null, unchanged };

  const rows: DiffRow[] = changed.map((u) => ({
    key: u.field,
    label: INTAKE_FIELD_ALLOWLIST[u.field]!.label,
    oldValue: String(estate?.[u.field] ?? ""),
    newValue: u.value,
    source: u.source,
  }));
  const diff: ProposalDiff = {
    kind: "intake",
    estateId: args.estateId,
    estateName: String(estate?.estateName || estate?.deceasedLastName || args.estateId),
    rows,
  };
  const payload = {
    procedure: "estate.update",
    input: {
      id: args.estateId,
      data: Object.fromEntries(changed.map((u) => [u.field, u.value])),
    },
  };
  // Re-check abort right before the write (finding C2): the entry-check in the
  // tool leaves a one-round-trip window (the estate.get above) during which a
  // Stop could otherwise still land a hidden proposal row.
  if (args.signal?.aborted) throw new AppError("Cancelled — no proposal created.", "ABORTED", 499);
  const proposal = store.createProposal({
    userId: args.userId,
    conversationId: args.conversationId,
    estateId: args.estateId,
    kind: "intake",
    payload,
    diff,
  });
  return { proposal, diff, unchanged };
}

// ── Contacts ─────────────────────────────────────────────────────────────────

export type ProposedContact = {
  fields: Record<string, string>;
  bools?: Partial<Record<(typeof CONTACT_BOOL_FIELDS)[number], boolean>>;
  source: string;
};

export function validateContacts(contacts: ProposedContact[]): {
  accepted: ProposedContact[];
  rejected: Rejection[];
} {
  const accepted: ProposedContact[] = [];
  const rejected: Rejection[] = [];
  contacts.forEach((c, i) => {
    if (!c.source || !c.source.trim()) {
      rejected.push({ field: `contact[${i}]`, reason: "missing source" });
      return;
    }
    if (!c.fields?.role || !c.fields.role.trim()) {
      rejected.push({ field: `contact[${i}]`, reason: "role is required" });
      return;
    }
    for (const [key, value] of Object.entries(c.fields)) {
      const rule = CONTACT_FIELD_ALLOWLIST[key];
      if (!rule) {
        rejected.push({ field: `contact[${i}].${key}`, reason: "not on the contact allowlist" });
        return;
      }
      const err = structuralCheck(key, value, rule);
      if (err) {
        rejected.push({ field: `contact[${i}].${key}`, reason: err });
        return;
      }
    }
    for (const key of Object.keys(c.bools ?? {})) {
      if (!(CONTACT_BOOL_FIELDS as readonly string[]).includes(key)) {
        rejected.push({ field: `contact[${i}].${key}`, reason: "not a recognized boolean field" });
        return;
      }
    }
    accepted.push(c);
  });
  return { accepted, rejected };
}

/**
 * Roles the app auto-ranks (routers.ts:1803 via contactHasRole). Mirror the
 * app's EXACT comma-token membership (shared/types.ts:76-80) — a substring test
 * would over-state the disclosure for a role like "co-executor" that the app
 * does NOT auto-rank.
 */
const EXECUTOR_ROLES = new Set(["executor", "alternate_executor", "applicant"]);
function isExecutorRole(role: string | null | undefined): boolean {
  return (role || "")
    .split(",")
    .map((r) => r.trim().toLowerCase())
    .some((r) => EXECUTOR_ROLES.has(r));
}

export async function createContactsProposal(args: {
  userId: number;
  conversationId: string | null;
  session: AppSession;
  estateId: string;
  accepted: ProposedContact[];
  signal?: { aborted: boolean };
}): Promise<{
  proposal: store.ProposalRow | null;
  diff: ProposalDiff | null;
  /** Names refused because that person is already on the estate. */
  duplicates: string[];
}> {
  const [estate, existingContacts] = (await Promise.all([
    appQuery(args.session, "estate.get", { id: args.estateId }),
    appQuery(args.session, "contact.list", { estateId: args.estateId }).catch(() => []),
  ])) as [Record<string, unknown>, Array<Record<string, unknown>>];

  // DUPLICATE GUARD. Asked to CHANGE someone's role, the model had only a
  // create tool, so it "corrected" people by proposing them again — leaving one
  // estate holding two Emma Carters and two David Carters, and a beneficiary
  // consent list naming the same person twice. Roles drive Rule 25 notices, PGT
  // involvement and distribution, so a duplicated party is a legal defect, not
  // untidiness. The prose instruction "do not re-propose people already on the
  // estate" could not enforce itself; this can. Editing an existing person is
  // propose_contact_updates.
  const normalize = (v: unknown) =>
    String(v ?? "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  const existingNames = new Set(existingContacts.map((c) => normalize(c.name)).filter(Boolean));
  const duplicates: string[] = [];
  const fresh = args.accepted.filter((c) => {
    const key = normalize(c.fields.name);
    if (!key || !existingNames.has(key)) return true;
    duplicates.push(c.fields.name!);
    return false;
  });
  if (fresh.length === 0) return { proposal: null, diff: null, duplicates };
  args = { ...args, accepted: fresh };

  // DERIVED-CHANGE DISCLOSURE (finding #5): creating the first executor with no
  // executorRank makes the app auto-set it to primary/rank 1 (routers.ts:1803).
  // That legally-consequential write is invisible on the payload, so surface it
  // on the card. Mirror the app's "first executor-ish contact with no existing
  // primary wins" rule across this batch (contacts are created sequentially).
  const primaryTakenAtPropose = existingContacts.some(
    (c) => isExecutorRole(String(c.role ?? "")) && c.executorRank === "primary",
  );
  let primaryTaken = primaryTakenAtPropose;
  const hasExecutorish = args.accepted.some((c) => isExecutorRole(c.fields.role));

  const groups: DiffRow[][] = args.accepted.map((c) => {
    const rows: DiffRow[] = [
      ...Object.entries(c.fields).map(([key, value]) => ({
        key,
        label: CONTACT_FIELD_ALLOWLIST[key]!.label,
        oldValue: "—",
        newValue: value,
        source: c.source,
      })),
      ...Object.entries(c.bools ?? {}).map(([key, value]) => ({
        key,
        label: key,
        oldValue: "—",
        newValue: value ? "yes" : "no",
        source: c.source,
      })),
    ];
    if (isExecutorRole(c.fields.role)) {
      const becomesPrimary = !primaryTaken;
      if (becomesPrimary) primaryTaken = true;
      rows.push({
        key: "executorRank",
        label: "Executor rank (set by the app)",
        oldValue: "—",
        newValue: becomesPrimary
          ? "primary — rank 1 (auto-assigned; confirm in Contacts)"
          : "not primary (ranked by the app; confirm in Contacts)",
        source: "app rule",
      });
    }
    return rows;
  });
  const diff: ProposalDiff = {
    kind: "contacts",
    estateId: args.estateId,
    estateName: String(estate?.estateName || args.estateId),
    rows: [],
    groups,
  };
  const payload = {
    procedure: "contact.create",
    inputs: args.accepted.map((c) => ({
      estateId: args.estateId,
      ...c.fields,
      ...Object.fromEntries(Object.entries(c.bools ?? {}).map(([k, v]) => [k, v ? 1 : 0])),
    })),
    // The executor-rank disclosure on the card is computed from the CURRENT
    // executor landscape (finding #4). Record it so Apply can detect a change
    // (staff added/removed a primary executor between propose and apply) and
    // refuse rather than write a rank the user didn't review.
    executorDisclosure: { primaryTakenAtPropose, hasExecutorish },
  };
  if (args.signal?.aborted) throw new AppError("Cancelled — no proposal created.", "ABORTED", 499);
  const proposal = store.createProposal({
    userId: args.userId,
    conversationId: args.conversationId,
    estateId: args.estateId,
    kind: "contacts",
    payload,
    diff,
  });
  return { proposal, diff, duplicates };
}

// ── Contact updates (edit an existing person) ────────────────────────────────

export type ProposedContactUpdate = {
  contactId: string;
  fields: Record<string, string>;
  bools?: Partial<Record<(typeof CONTACT_BOOL_FIELDS)[number], boolean>>;
  source: string;
};

export function validateContactUpdates(updates: ProposedContactUpdate[]): {
  accepted: ProposedContactUpdate[];
  rejected: Rejection[];
} {
  const accepted: ProposedContactUpdate[] = [];
  const rejected: Rejection[] = [];
  updates.forEach((u, i) => {
    if (!u.contactId || !String(u.contactId).trim()) {
      rejected.push({ field: `update[${i}]`, reason: "contactId is required — read it from contact.list" });
      return;
    }
    if (!u.source || !u.source.trim()) {
      rejected.push({ field: `update[${i}]`, reason: "missing source" });
      return;
    }
    if (!Object.keys(u.fields ?? {}).length && !Object.keys(u.bools ?? {}).length) {
      rejected.push({ field: `update[${i}]`, reason: "no fields to change" });
      return;
    }
    for (const [key, value] of Object.entries(u.fields ?? {})) {
      const rule = CONTACT_FIELD_ALLOWLIST[key];
      if (!rule) {
        rejected.push({ field: `update[${i}].${key}`, reason: "not on the contact allowlist" });
        return;
      }
      const err = structuralCheck(key, value, rule);
      if (err) {
        rejected.push({ field: `update[${i}].${key}`, reason: err });
        return;
      }
    }
    for (const key of Object.keys(u.bools ?? {})) {
      if (!(CONTACT_BOOL_FIELDS as readonly string[]).includes(key)) {
        rejected.push({ field: `update[${i}].${key}`, reason: "not a recognized boolean field" });
        return;
      }
    }
    accepted.push(u);
  });
  return { accepted, rejected };
}

/**
 * Propose CHANGES to people already on the estate.
 *
 * Exists because its absence caused real data damage: with only a create tool,
 * "switch the executor's role" produced a second copy of that person carrying
 * the corrected role. This writes through the app's own contact.update, which
 * asserts estate ownership and strips id/estateId/priorityConsentDocumentKey
 * (routers.ts contact.update), and — like every propose_* path — it creates a
 * REVIEW CARD. Nothing reaches the estate until the user clicks Apply.
 */
export async function createContactUpdatesProposal(args: {
  userId: number;
  conversationId: string | null;
  session: AppSession;
  estateId: string;
  accepted: ProposedContactUpdate[];
  signal?: { aborted: boolean };
}): Promise<{
  proposal: store.ProposalRow | null;
  diff: ProposalDiff | null;
  /** Field keys skipped because the contact already holds that value. */
  unchanged: string[];
  /** contactIds that are not on this estate. */
  unknownContacts: string[];
}> {
  const [estate, contacts] = (await Promise.all([
    appQuery(args.session, "estate.get", { id: args.estateId }),
    appQuery(args.session, "contact.list", { estateId: args.estateId }),
  ])) as [Record<string, unknown>, Array<Record<string, unknown>>];

  const byId = new Map(contacts.map((c) => [String(c.id), c]));
  const unchanged: string[] = [];
  const unknownContacts: string[] = [];
  const groups: DiffRow[][] = [];
  const inputs: Array<{ id: string; estateId: string; data: Record<string, unknown> }> = [];

  for (const u of args.accepted) {
    const current = byId.get(String(u.contactId));
    if (!current) {
      unknownContacts.push(u.contactId);
      continue;
    }
    const rows: DiffRow[] = [];
    const data: Record<string, unknown> = {};

    for (const [key, value] of Object.entries(u.fields ?? {})) {
      // Same rule the intake path learned: a value equal to the stored one is
      // not a change. Carrying it makes the card unreadable and widens the
      // drift guard over fields the user never meant to touch.
      if (String(current[key] ?? "") === value) {
        unchanged.push(key);
        continue;
      }
      rows.push({
        key,
        label: CONTACT_FIELD_ALLOWLIST[key]!.label,
        oldValue: String(current[key] ?? ""),
        newValue: value,
        source: u.source,
      });
      data[key] = value;
    }
    for (const [key, value] of Object.entries(u.bools ?? {})) {
      const now = Number(current[key] ?? 0) === 1;
      if (now === value) {
        unchanged.push(key);
        continue;
      }
      rows.push({
        key,
        label: key,
        oldValue: now ? "yes" : "no",
        newValue: value ? "yes" : "no",
        source: u.source,
      });
      data[key] = value ? 1 : 0;
    }

    if (!rows.length) continue;
    // Name the person on the card — an edit diff without it reads as a set of
    // orphan values, and the user is being asked to authorize a change to a
    // specific party.
    rows.unshift({
      key: "__contact",
      label: "Editing",
      oldValue: "",
      newValue: String(current.name || u.contactId),
      source: "existing contact",
    });
    groups.push(rows);
    inputs.push({ id: String(u.contactId), estateId: args.estateId, data });
  }

  if (!inputs.length) return { proposal: null, diff: null, unchanged, unknownContacts };

  const diff: ProposalDiff = {
    kind: "contact_updates",
    estateId: args.estateId,
    estateName: String(estate?.estateName || args.estateId),
    rows: [],
    groups,
  };
  const payload = { procedure: "contact.update", inputs };
  if (args.signal?.aborted) throw new AppError("Cancelled — no proposal created.", "ABORTED", 499);
  const proposal = store.createProposal({
    userId: args.userId,
    conversationId: args.conversationId,
    estateId: args.estateId,
    kind: "contact_updates",
    payload,
    diff,
  });
  return { proposal, diff, unchanged, unknownContacts };
}

// ── Inventory ────────────────────────────────────────────────────────────────

export type ProposedInventoryItem = {
  category: string;
  description: string;
  valueCents: number;
  location?: string;
  source: string;
};

export function validateInventory(items: ProposedInventoryItem[]): {
  accepted: ProposedInventoryItem[];
  rejected: Rejection[];
} {
  const accepted: ProposedInventoryItem[] = [];
  const rejected: Rejection[] = [];
  items.forEach((item, i) => {
    if (!item.source?.trim()) {
      rejected.push({ field: `item[${i}]`, reason: "missing source" });
      return;
    }
    if (!(INVENTORY_CATEGORIES as readonly string[]).includes(item.category)) {
      rejected.push({
        field: `item[${i}].category`,
        reason: `must be one of ${INVENTORY_CATEGORIES.join(", ")}`,
      });
      return;
    }
    if (!item.description?.trim() || item.description.length > 500) {
      rejected.push({ field: `item[${i}].description`, reason: "required, max 500 chars" });
      return;
    }
    if (!Number.isInteger(item.valueCents) || item.valueCents < 0) {
      rejected.push({ field: `item[${i}].valueCents`, reason: "must be a non-negative integer (CENTS)" });
      return;
    }
    if (item.location && !(INVENTORY_LOCATIONS as readonly string[]).includes(item.location)) {
      rejected.push({
        field: `item[${i}].location`,
        reason: `must be one of ${INVENTORY_LOCATIONS.join(", ")}`,
      });
      return;
    }
    accepted.push(item);
  });
  return { accepted, rejected };
}

export async function createInventoryProposal(args: {
  userId: number;
  conversationId: string | null;
  session: AppSession;
  estateId: string;
  accepted: ProposedInventoryItem[];
  signal?: { aborted: boolean };
}): Promise<{ proposal: store.ProposalRow; diff: ProposalDiff }> {
  const estate = (await appQuery(args.session, "estate.get", { id: args.estateId })) as Record<
    string,
    unknown
  >;
  const fmt = (cents: number) => `$${(cents / 100).toLocaleString("en-CA", { minimumFractionDigits: 2 })}`;
  const groups: DiffRow[][] = args.accepted.map((item) => [
    { key: "category", label: "Category", oldValue: "—", newValue: item.category, source: item.source },
    { key: "description", label: "Description", oldValue: "—", newValue: item.description, source: item.source },
    { key: "value", label: "Value", oldValue: "—", newValue: `${fmt(item.valueCents)} (${item.valueCents}¢)`, source: item.source },
    ...(item.location
      ? [{ key: "location", label: "Location", oldValue: "—", newValue: item.location, source: item.source }]
      : []),
  ]);
  const diff: ProposalDiff = {
    kind: "inventory",
    estateId: args.estateId,
    estateName: String(estate?.estateName || args.estateId),
    rows: [],
    groups,
  };
  const payload = {
    procedure: "inventory.bulkCreate",
    input: {
      estateId: args.estateId,
      items: args.accepted.map((item) => ({
        estateId: args.estateId,
        category: item.category,
        description: item.description,
        value: item.valueCents,
        location: item.location ?? "unknown",
        valueRecorded: 1,
      })),
    },
  };
  if (args.signal?.aborted) throw new AppError("Cancelled — no proposal created.", "ABORTED", 499);
  const proposal = store.createProposal({
    userId: args.userId,
    conversationId: args.conversationId,
    estateId: args.estateId,
    kind: "inventory",
    payload,
    diff,
  });
  return { proposal, diff };
}

// ── Apply (user-clicked REST endpoint — NEVER a model tool) ──────────────────

/** Thrown when the estate changed since a proposal was built (finding #3). */
export class ProposalConflict extends Error {
  constructor(public readonly fields: string[]) {
    super("estate changed since this proposal was created");
    this.name = "ProposalConflict";
  }
}

/**
 * Which intake fields drifted since propose time (finding #3). `oldValue` in
 * each diff row is the value at propose time; if the CURRENT estate value no
 * longer matches, a staff edit (or another apply) landed in between and the
 * stored newValue would silently clobber it. Returns the human labels of the
 * drifted fields — empty means it is safe to apply.
 */
export function detectIntakeDrift(
  rows: DiffRow[],
  current: Record<string, unknown>,
): string[] {
  const drifted: string[] = [];
  for (const row of rows) {
    const now = String(current?.[row.key] ?? "");
    if (now !== row.oldValue) drifted.push(row.label);
  }
  return drifted;
}

/**
 * One-line record of what an applied proposal changed.
 *
 * The assistant has NO other way to learn the user clicked Apply: the card's
 * outcome lives in React state and never reaches this service, and no tool reads
 * proposal status. Without this it answers "No — I did not apply any changes to
 * the estate" to a user who just applied them. Written into the conversation, so
 * it lands in the history the next turn is built from AND gives the user a
 * durable transcript line instead of only a badge on a card in a scrolling tray.
 */
export function describeAppliedProposal(proposal: store.ProposalRow): string {
  let labels: string[] = [];
  try {
    const diff = JSON.parse(proposal.diff) as ProposalDiff;
    const rows = diff.rows?.length ? diff.rows : (diff.groups ?? []).flat();
    labels = Array.from(new Set(rows.map((r) => r.label).filter(Boolean)));
  } catch {
    // A malformed diff must not suppress the note — that the apply HAPPENED
    // matters more than naming the fields.
  }
  return labels.length
    ? `✅ Applied — now saved on the estate: ${labels.join(", ")}.`
    : "✅ Applied — your approved changes are now saved on the estate.";
}

/** The exact query-key set estate.update's onSuccess invalidates (EstateDetail.tsx:758-774). */
export const INTAKE_INVALIDATION_KEYS = Object.freeze([
  "readiness.check",
  "readiness.timeline",
  "deadline.list",
  "estate.list",
  "delivery.getRecipients",
  "document.preflight",
  "document.preflightMany",
  "estate.get",
]);

export async function applyProposal(
  userId: number,
  session: AppSession,
  proposal: store.ProposalRow,
): Promise<{ invalidate: string[] }> {
  const payload = JSON.parse(proposal.payload);
  const diff = JSON.parse(proposal.diff) as ProposalDiff;
  const invalidate: string[] = [...INTAKE_INVALIDATION_KEYS];

  if (proposal.kind === "intake") {
    // STALE-WRITE GUARD (finding #3): re-read the estate NOW and refuse to apply
    // if any target field changed since this proposal was built — an intake
    // update overwrites, so a yesterday-proposal must never clobber today's edit.
    const current = (await appQuery(session, "estate.get", { id: proposal.estate_id })) as Record<
      string,
      unknown
    >;
    const drifted = detectIntakeDrift(diff.rows, current);
    if (drifted.length) throw new ProposalConflict(drifted);
    const expectedRevision = Number(current.revision);
    if (!Number.isInteger(expectedRevision) || expectedRevision < 1) {
      throw new AppError(
        "The estate revision could not be verified. Refresh the estate and review this proposal again.",
        "ESTATE_REVISION_UNAVAILABLE",
        409,
      );
    }
    // Use the revision from the apply-time re-read, not the proposal-time
    // snapshot. detectIntakeDrift above already guards every field this patch
    // can overwrite; unrelated intervening edits therefore remain intact while
    // the app router's atomic compare-and-swap closes the final read/write race.
    await appMutation(session, "estate.update", {
      ...payload.input,
      expectedRevision,
    });
  } else if (proposal.kind === "contacts") {
    // EXECUTOR-RANK DRIFT (finding #4): the card disclosed who becomes the primary
    // executor from the executor landscape at propose time. Re-read it; if a
    // primary executor was added or removed since, the app would now assign a
    // DIFFERENT rank than was reviewed (who swears as primary applicant is a legal
    // fact) — refuse and make the user re-review rather than write a surprise rank.
    const disc = payload.executorDisclosure as
      | { primaryTakenAtPropose: boolean; hasExecutorish: boolean }
      | undefined;
    if (disc?.hasExecutorish) {
      // No .catch(): if we can't re-read the executor landscape we must NOT apply
      // an unverified rank disclosure — let the read failure fail the apply.
      const nowContacts = (await appQuery(session, "contact.list", {
        estateId: proposal.estate_id,
      })) as Array<Record<string, unknown>>;
      const primaryTakenNow = nowContacts.some(
        (c) => isExecutorRole(String(c.role ?? "")) && c.executorRank === "primary",
      );
      if (primaryTakenNow !== disc.primaryTakenAtPropose) {
        throw new ProposalConflict(["executor rank / primary applicant"]);
      }
    }
    // contact.create has no batch endpoint — writes are sequential. On a
    // mid-loop failure, report how many landed so the user reconciles the
    // Contacts tab instead of seeing a misleading "nothing was changed".
    let created = 0;
    try {
      for (const input of payload.inputs) {
        await appMutation(session, "contact.create", input);
        created++;
      }
    } catch (err) {
      store.auditEvent("bot_write_partial", userId, proposal.estate_id, {
        proposalId: proposal.id,
        created,
        total: payload.inputs.length,
      });
      throw new AppError(
        `Added ${created} of ${payload.inputs.length} contact(s) before an error — check the Contacts tab before retrying.`,
        (err as AppError).code ?? "PARTIAL_CONTACTS",
        502,
      );
    }
    invalidate.push("contact.list", "distribution.compute", "activity.list");
  } else if (proposal.kind === "contact_updates") {
    // STALE-WRITE GUARD, same doctrine as intake: an edit OVERWRITES, so re-read
    // each contact and refuse if any reviewed field moved since propose time.
    // Staff may have corrected the same person in the Contacts tab meanwhile,
    // and silently clobbering that is exactly what the drift guard exists for.
    const nowContacts = (await appQuery(session, "contact.list", {
      estateId: proposal.estate_id,
    })) as Array<Record<string, unknown>>;
    const byId = new Map(nowContacts.map((c) => [String(c.id), c]));
    const drifted: string[] = [];
    // groups[i] ↔ inputs[i] is the join: createContactUpdatesProposal pushes one
    // group AND one input per accepted contact inside the same guard (the ONLY
    // constructor of contact_updates payloads), so the shared index is stable.
    // This used to match by display name, which compared one "John Smith"'s diff
    // against the OTHER John Smith's row when two contacts shared a name
    // (father/son — routine on a probate file), false-conflicting or missing
    // real drift (LOGIC-007).
    const groups = diff.groups ?? [];
    const inputs = payload.inputs as Array<{ id: string }>;
    for (let i = 0; i < groups.length; i++) {
      const group = groups[i]!;
      const target = group.find((r) => r.key === "__contact");
      const input = inputs[i];
      const current = input ? byId.get(input.id) : undefined;
      if (!current) {
        drifted.push(`${target?.newValue ?? "a contact"} (no longer on the estate)`);
        continue;
      }
      for (const row of group) {
        if (row.key === "__contact") continue;
        const isBool = (CONTACT_BOOL_FIELDS as readonly string[]).includes(row.key);
        const now = isBool
          ? Number(current[row.key] ?? 0) === 1
            ? "yes"
            : "no"
          : String(current[row.key] ?? "");
        if (now !== row.oldValue) drifted.push(`${target?.newValue ?? ""} — ${row.label}`.trim());
      }
    }
    if (drifted.length) throw new ProposalConflict(drifted);

    let updated = 0;
    try {
      for (const input of payload.inputs) {
        await appMutation(session, "contact.update", input);
        updated++;
      }
    } catch (err) {
      // contact.update has no batch endpoint either — report how many landed so
      // the user reconciles rather than blind-retrying a partial write.
      store.auditEvent("bot_write_partial", userId, proposal.estate_id, {
        proposalId: proposal.id,
        kind: "contact_updates",
        updated,
        total: payload.inputs.length,
      });
      throw new AppError(
        `Updated ${updated} of ${payload.inputs.length} contact(s) before an error — check the Contacts tab before retrying.`,
        (err as AppError).code ?? "PARTIAL_CONTACT_UPDATES",
        502,
      );
    }
    invalidate.push("contact.list", "distribution.compute", "activity.list");
  } else {
    // inventory.bulkCreate is one call over a NON-transactional per-item loop
    // app-side (finding #5): a mid-loop failure can leave some items written, so
    // give the same "verify before retrying" guidance the contacts path does
    // instead of a bare error the user might blindly re-Apply into duplicates.
    const itemCount = Array.isArray(payload.input?.items) ? payload.input.items.length : 0;
    try {
      await appMutation(session, "inventory.bulkCreate", payload.input);
    } catch (err) {
      store.auditEvent("bot_write_partial", userId, proposal.estate_id, {
        proposalId: proposal.id,
        kind: "inventory",
        total: itemCount,
      });
      throw new AppError(
        `The inventory save failed partway — some of the ${itemCount} item(s) may already be saved. Check the Inventory tab before retrying.`,
        (err as AppError).code ?? "PARTIAL_INVENTORY",
        502,
      );
    }
    invalidate.push("inventory.list", "inventory.totals", "distribution.compute", "activity.list");
  }

  // Structured write audit (C-20) — who/when/estate/what. PII-LIGHT (finding
  // #8): store the changed field NAMES only, never the values. The audit log is
  // retained across conversation deletion, so it must not become a durable copy
  // of estate PII; the reviewable values live in the proposal row (deleted with
  // its conversation).
  const changedFields = (diff.rows?.length ? diff.rows : (diff.groups ?? []).flat()).map((r) => r.key);
  store.auditEvent("bot_write_applied", userId, proposal.estate_id, {
    proposalId: proposal.id,
    kind: proposal.kind,
    fields: Array.from(new Set(changedFields)),
  });
  return { invalidate };
}
