/**
 * LOAD-BEARING SECURITY FILE — the bot-side field and procedure allowlists.
 *
 * The app's `estate.update` accepts `z.record(z.string(), z.any())` with NO
 * server-side field whitelist (server/routers.ts:1287-1290), so this file is
 * the ONLY guard between the LLM and arbitrary estate-column writes. Philosophy
 * (security constraint C-16): the bot may propose exactly the fields a human
 * can type into the Intake tab and that a dropped document can evidence —
 * nothing workflow-, docgen-, or statute-deciding.
 *
 * Deliberately EXCLUDED classes (do not add without a ruling):
 *  - identity/bookkeeping: id, createdByUserId, fileNumber, createdAt/updatedAt
 *  - workflow state: status (the ready_to_file gate exists for humans), fileType
 *  - statute-deciding facts: grantType, hasWill, partialIntestacy,
 *    testatePortionCents/Recorded, willType, oathType, spouseStatus,
 *    priorRights*, applicantPriority* — these answer legal questions and belong
 *    to the lawyer, not an extraction
 *  - server-normalized/derived columns (routers.ts:1297-1336): p19* clauses,
 *    ancillary*Certified, testatePortionRecorded, variation dates
 *  - oath city: domicileCity is the OATH city ONLY (Nick ruling 2026-07-26,
 *    repo RULES.md Rule 12) — never extraction-fillable. Residence goes to
 *    deceasedResidenceCity.
 *  - every *StorageKey / *FileName / *FilePath / codicilFiles column
 *  - dedicated identifiers and banking secrets: deceasedSIN, deceasedTIN,
 *    accountNumber, accountHolder, bankAddress (never sent to or proposed by
 *    the model; staff enter them directly in the app)
 *
 * Snapshot-tested in test/allowlist.test.ts — schema drift must fail loudly.
 */

const YES_NO = new Set(["yes", "no"]);

/**
 * True only for a REAL calendar date in YYYY-MM-DD form (finding #6).
 * Shape-only checking accepted "2026-02-31" / "2026-99-99", which then flowed
 * toward sworn forms and statutory deadlines. This round-trips through UTC the
 * same way shared/date-utils.ts parseYmd does, so the bot and the app agree on
 * validity. Kept as a local copy — the bot imports nothing from shared/.
 */
export function isValidYmd(v: string): boolean {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
  if (!m) return false;
  const y = +m[1];
  const mo = +m[2];
  const d = +m[3];
  const dt = new Date(Date.UTC(y, mo - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === mo - 1 && dt.getUTCDate() === d;
}

export type FieldRule = {
  label: string;
  /** returns an error string, or null when valid */
  validate?: (value: string) => string | null;
  maxLen?: number;
};

const date = (label: string): FieldRule => ({
  label,
  validate: (v) => (isValidYmd(v) ? null : "must be a real calendar date (YYYY-MM-DD)"),
});
const yesNo = (label: string): FieldRule => ({
  label,
  validate: (v) => (YES_NO.has(v) ? null : 'must be "yes" or "no"'),
});
const str = (label: string, maxLen = 255): FieldRule => ({ label, maxLen });

/** Estate columns the bot may PROPOSE (Apply still requires a human click). */
export const INTAKE_FIELD_ALLOWLIST: Readonly<Record<string, FieldRule>> = Object.freeze({
  estateName: str("Estate name"),
  registry: str("Probate registry", 128),
  courtFileNumber: str("Court file number", 64),

  deceasedFirstName: str("Deceased's first name", 128),
  deceasedMiddleNames: str("Deceased's middle names"),
  deceasedSecondMiddleName: str("Deceased's second middle name", 128),
  deceasedLastName: str("Deceased's last name", 128),
  deceasedAliases: str("Other names / aliases", 1000),

  dateOfBirth: date("Date of birth"),
  dateOfDeath: date("Date of death"),
  maritalStatus: str("Marital status", 64),

  deceasedAddress: str("Deceased's address (legacy single-line)", 500),
  addressStreet: str("Address — street"),
  addressUnit: str("Address — unit/suite", 64),
  addressCity: str("Address — city", 128),
  addressProvince: str("Address — province", 128),
  addressPostalCode: str("Address — postal code", 16),
  addressCountry: str("Address — country", 128),
  deceasedPostOfficeBox: str("Post office box", 100),
  deceasedResidenceCity: str("Former residence city (P17 'formerly of')", 128),

  deceasedGender: str("Gender", 32),
  deceasedOccupation: str("Occupation"),
  placeOfBirth: str("Place of birth"),

  hasOtherNames: yesNo("Has other names"),
  akaFirstName: str("AKA first name", 128),
  akaMiddleName: str("AKA middle name", 128),
  akaLastName: str("AKA last name", 128),

  willDate: date("Date of will"),
});

/**
 * Roles the bot may assign — the union of what a HUMAN can pick in the app's
 * contact-role UI (EstateDetail.tsx CONTACT_ROLES + the quick-add dropdown) and
 * every role token the readiness/distribution/docgen logic RECOGNIZES
 * (contactHasRole targets across shared/types.ts, server/docgen.ts,
 * server/routers.ts). A model-invented role (e.g. "heir", "next_of_kin") would
 * create a contact the app silently ignores — no notice, no distribution share
 * (Kimi #3). `role` is comma-separated (contactRoles tokenizes on ","), so a
 * value is valid only when EVERY token is recognized. `heir` is deliberately
 * EXCLUDED: its canonical form is `beneficiary` (the UI maps "Beneficiary /
 * Heir" → beneficiary), so accepting it would create a divergent token.
 */
export const KNOWN_CONTACT_ROLES: ReadonlySet<string> = Object.freeze(
  new Set([
    // user-assignable in the app's role picker
    "beneficiary",
    "executor",
    "alternate_executor",
    "administrator",
    "trustee",
    "applicant",
    "lawyer",
    "creditor",
    "spouse",
    "guardian",
    "will_witness",
    "child",
    "intestate_successor",
    // recognized by app logic (not in the picker but valid + honoured)
    "treaty_fn",
    "citor",
  ]),
);
// NOTE: `intestate_successor_candidate` is deliberately EXCLUDED (ChatGPT #5).
// It is a display-only badge (EstateDetail.tsx) with NO consumer in P1/readiness/
// distribution/docgen — a contact given only that role is silently ignored by the
// legal pipeline. The canonical honoured token is `intestate_successor`.

export function isKnownContactRole(role: string): boolean {
  const tokens = role
    .split(",")
    .map((r) => r.trim().toLowerCase())
    .filter(Boolean);
  return tokens.length > 0 && tokens.every((t) => KNOWN_CONTACT_ROLES.has(t));
}

/**
 * Contact fields the bot may propose on contact.create. NOTE: the server's
 * create whitelist SILENTLY DROPS unknown keys (routers.ts:1659-1811, two past
 * bugs recorded there) — so we reject loudly here instead, and everything we
 * pass is verified to be on the server's list.
 */
export const CONTACT_FIELD_ALLOWLIST: Readonly<Record<string, FieldRule>> = Object.freeze({
  role: {
    label: "Role",
    validate: (v) => {
      if (!v.trim() || v.length > 64) return "required, max 64 chars";
      // Enforce a RECOGNIZED role — the app ignores anything else (Kimi #3).
      if (!isKnownContactRole(v)) {
        return `unknown role "${v}" — use one or more of: ${[...KNOWN_CONTACT_ROLES].join(", ")}`;
      }
      return null;
    },
  },
  name: str("Name"),
  email: str("Email", 320),
  phone: str("Phone", 64),
  relationship: str("Relationship to deceased", 128),
  address: str("Address", 500),
  residentialAddress: str("Residential address", 500),
  postalAddress: str("Postal address", 500),
  cityCountry: str("City / country", 255),
  occupation: str("Occupation"),
  nameAsInWill: str("Name as written in the will"),
});
/** Boolean-ish contact fields (coerced to 0/1). */
export const CONTACT_BOOL_FIELDS = Object.freeze(["isMinor", "isPredeceased"] as const);

export const INVENTORY_CATEGORIES = Object.freeze([
  "real_property",
  "tangible",
  "financial",
  "liability",
  "unknown",
] as const);
export const INVENTORY_LOCATIONS = Object.freeze(["in_bc", "outside_bc", "unknown"] as const);

/**
 * Deny-by-default registry of app tRPC procedures the bot may call (C-7).
 * `estate.previewFile` (mints signed URLs — ownership IS checked app-side via
 * userCanAccessStorageKey, routers.ts:1606, but the bot has no business
 * minting download links), `document.generate`/docgen, `estate.delete`, and
 * `settings.*` are structurally unreachable: appClient refuses anything
 * not on this list, no matter what the model emits.
 */
export const ALLOWED_PROCEDURES: ReadonlySet<string> = Object.freeze(
  new Set([
    "auth.me",
    "settings.get",
    "estate.list",
    "estate.get",
    "estate.update",
    "contact.list",
    "contact.create",
    // Edit an existing person. Reached ONLY through a contact_updates proposal
    // the user must Apply — the model cannot call it. Without it the assistant
    // answered "change this executor's role" by creating a second copy of that
    // person, duplicating parties on a probate file.
    "contact.update",
    "inventory.list",
    "inventory.totals",
    "inventory.bulkCreate",
    "document.list",
    "readiness.check",
    "readiness.timeline",
    "distribution.compute",
    "deadline.list",
    "requiredDoc.list",
    "activity.list",
    // Content-free, HMAC-authenticated telemetry emitted by the embedded route's
    // catch path. It remains unreachable to model tool selection.
    "failureReports.recordChatbot",
  ]),
);

/** App routes the bot may SUGGEST (widget renders a chip; only a user click navigates). */
// Rule 24 (2026-08-17): "documents" removed — the tab is gone from the app.
const NAV_RE =
  /^(\/|\/deadlines|\/settings|\/estate\/[A-Za-z0-9_-]+(\?tab=(intake|contacts|inventory|forms|client-portal|readiness|notes|activity))?)$/;

export function isAllowedNavPath(path: string): boolean {
  return NAV_RE.test(path);
}
