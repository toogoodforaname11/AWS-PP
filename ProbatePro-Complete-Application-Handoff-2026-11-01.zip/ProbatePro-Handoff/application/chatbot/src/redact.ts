/**
 * Sink-level secret scrubber (security constraint C-3).
 *
 * The forwarded app JWT is a full-privilege, non-revocable 30-day bearer secret,
 * and the Forge key is at rest in .env. Neither may ever reach a log line,
 * a serialized error, an NDJSON event, or a model prompt. Applied at the sinks
 * (logger + error serializer + stream writer), not at call sites, so a missed
 * call site fails safe.
 */

const JWT_RE = /eyJ[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{4,}\.[A-Za-z0-9_-]{4,}/g;
const ANTHROPIC_KEY_RE = /sk-ant-[A-Za-z0-9_-]{8,}/g;
const FORGE_KEY_RE = /(?:sk-[A-Za-z0-9_-]{16,}|forge[_-][A-Za-z0-9_-]{12,})/gi;
const AUTH_HEADER_RE = /(authorization"?\s*[:=]\s*"?)(?:Bearer\s+)?[^"\s,;]+/gi;
const SESSION_PAIR_RE = /(app_session_id=)[^\s;"']+/g;

/**
 * Value-based scrub — a belt to the pattern-based braces above. The Forge key's
 * FORMAT is issued by Manus and we don't control it (it may be a bare
 * hex/base64/UUID token the `sk-`/`forge-` pattern misses); registering its
 * literal value at startup guarantees it is stripped from every sink even so.
 * Only values ≥8 chars are stored, so a short/empty config can never blank
 * ordinary text.
 */
const literalSecrets = new Set<string>();

export function registerSecret(value: string | undefined | null): void {
  if (typeof value === "string" && value.length >= 8) literalSecrets.add(value);
}

function redactLiteralSecrets(text: string): string {
  let out = text;
  for (const secret of literalSecrets) {
    if (out.includes(secret)) out = out.split(secret).join("[REDACTED_KEY]");
  }
  return out;
}

export function redact(text: string): string {
  return redactLiteralSecrets(text)
    .replace(JWT_RE, "[REDACTED_JWT]")
    .replace(ANTHROPIC_KEY_RE, "[REDACTED_KEY]")
    .replace(FORGE_KEY_RE, "[REDACTED_KEY]")
    .replace(AUTH_HEADER_RE, "$1[REDACTED]")
    .replace(SESSION_PAIR_RE, "$1[REDACTED]");
}

/** Redacting console logger — the only logger this service uses. */
export const log = {
  info(...args: unknown[]): void {
    console.log("[chatbot]", ...args.map(toSafeString));
  },
  warn(...args: unknown[]): void {
    console.warn("[chatbot]", ...args.map(toSafeString));
  },
  error(...args: unknown[]): void {
    console.error("[chatbot]", ...args.map(toSafeString));
  },
};

export function toSafeString(v: unknown): string {
  if (typeof v === "string") return redact(v);
  if (v instanceof Error) {
    return redact(`${v.name}: ${v.message}${v.stack ? `\n${v.stack}` : ""}`);
  }
  try {
    return redact(JSON.stringify(v));
  } catch {
    return "[unserializable]";
  }
}
