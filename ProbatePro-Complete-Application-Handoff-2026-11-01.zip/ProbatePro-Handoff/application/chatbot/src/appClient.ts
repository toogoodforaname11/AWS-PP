/**
 * Raw superjson tRPC client for the ProbatePro app API.
 *
 * Chosen over `import type { AppRouter }` deliberately: the typed import drags
 * the entire server type graph (express, drizzle-orm, mysql2, docx, pdfkit...)
 * into this package's typecheck and breaks the bot's build whenever the app's
 * server imports change — violating "completely separate". The bot calls ~15
 * stable procedures; their shapes are validated with zod at THIS trust boundary.
 *
 * Wire format (the app's tRPC v11 transformer is superjson — mandatory):
 *   query:    GET  {base}/api/trpc/{proc}?input=<urlencoded JSON of superjson.serialize(input)>
 *   mutation: POST {base}/api/trpc/{proc}   body = JSON of superjson.serialize(input)
 *   success:  { result: { data: <superjson payload> } }
 *   error:    { error: { json: { message, code, data: { code, httpStatus } } } }
 *
 * Auth: `Authorization: Bearer <jwt>` — server/_core/sdk.ts:299-312 accepts it.
 * No Origin header is ever sent, so the app's CORS callback short-circuits.
 */
import superjson from "superjson";
import { redact } from "./redact.js";
import { ALLOWED_PROCEDURES } from "./allowlist.js";

export class AppError extends Error {
  constructor(
    message: string,
    public readonly code: string,
    public readonly httpStatus: number,
  ) {
    super(redact(message));
    this.name = "AppError";
  }
}

export type AppSession = {
  /** The user's forwarded JWT. Lives in this request's memory only — never persisted. */
  token: string;
  /**
   * App base URL for this request. ALWAYS the operator-configured APP_BASE_URL
   * (auth.resolveAppBase) — never caller-derived. The credential destination is
   * decoupled from the X-App-Origin header on purpose (finding #1).
   */
  baseUrl: string;
  /**
   * Called when the app rotates the session (X-Rotated-Session response header).
   * Receives the raw header value ("app_session_id=<jwt>[; ...]") for relay to
   * the widget, exactly as client/src/main.tsx:73-78 adopts it.
   */
  onRotate?: (rawHeaderValue: string) => void;
  /** Absolute chat-turn cancellation, shared by parsing, Forge, and app calls. */
  signal?: AbortSignal;
};

// Global concurrency cap: the bot shares the app's 200 req/min per-IP bucket
// with the user's own browser — never monopolize it.
const MAX_IN_FLIGHT = 8;
let inFlight = 0;
const waiters: Array<() => void> = [];

async function acquire(): Promise<void> {
  if (inFlight < MAX_IN_FLIGHT) {
    inFlight++;
    return;
  }
  await new Promise<void>((resolve) => waiters.push(resolve));
  inFlight++;
}

function release(): void {
  inFlight--;
  const next = waiters.shift();
  if (next) next();
}

const COOKIE_NAME = "app_session_id";

function requestSignal(session: AppSession): AbortSignal {
  const timeout = AbortSignal.timeout(60_000);
  return session.signal ? AbortSignal.any([session.signal, timeout]) : timeout;
}

function adoptRotation(session: AppSession, res: Response): void {
  const rotated = res.headers.get("x-rotated-session");
  if (!rotated) return;
  // Header format mirrors the cookie pair; extract the fresh JWT for our own
  // remaining calls and relay the raw value to the widget.
  const prefix = `${COOKIE_NAME}=`;
  const pair = rotated.split(";").find((s) => s.trim().startsWith(prefix));
  const token = pair?.trim().slice(prefix.length);
  if (token) session.token = token;
  session.onRotate?.(rotated);
}

async function call(
  session: AppSession,
  proc: string,
  input: unknown,
  method: "GET" | "POST",
  attempt = 0,
): Promise<unknown> {
  // Deny-by-default (security C-7): a procedure not on the allowlist is
  // unreachable no matter what any caller — or the model — asks for.
  if (!ALLOWED_PROCEDURES.has(proc)) {
    throw new AppError(`Procedure not allowed: ${proc}`, "FORBIDDEN_PROCEDURE", 403);
  }
  const serialized = superjson.serialize(input);
  const url =
    method === "GET"
      ? `${session.baseUrl}/api/trpc/${proc}?input=${encodeURIComponent(JSON.stringify(serialized))}`
      : `${session.baseUrl}/api/trpc/${proc}`;

  await acquire();
  let res: Response;
  try {
    res = await fetch(url, {
      method,
      headers: {
        authorization: `Bearer ${session.token}`,
        ...(method === "POST" ? { "content-type": "application/json" } : {}),
        // NO Origin header — server-to-server; the app's CORS never evaluates us.
      },
      body: method === "POST" ? JSON.stringify(serialized) : undefined,
      signal: requestSignal(session),
    });
  } finally {
    release();
  }

  adoptRotation(session, res);

  if (res.status === 429 && attempt === 0) {
    if (session.signal?.aborted) {
      throw new AppError("App request cancelled", "ABORTED", 499);
    }
    const parsedRetryAfter = Number(res.headers.get("retry-after") || 2);
    const retryAfter = Number.isFinite(parsedRetryAfter) ? Math.max(0, parsedRetryAfter) : 2;
    await new Promise<void>((resolve, reject) => {
      const finish = () => {
        session.signal?.removeEventListener("abort", onAbort);
        resolve();
      };
      const timer = setTimeout(finish, Math.min(retryAfter, 30) * 1000);
      const onAbort = () => {
        clearTimeout(timer);
        session.signal?.removeEventListener("abort", onAbort);
        reject(new AppError("App request cancelled", "ABORTED", 499));
      };
      session.signal?.addEventListener("abort", onAbort, { once: true });
      // Close the check/listener race: AbortSignal does not replay an abort
      // event to listeners registered after it fired.
      if (session.signal?.aborted) onAbort();
    });
    return call(session, proc, input, method, 1);
  }

  const text = await res.text();
  let body: any;
  try {
    body = JSON.parse(text);
  } catch {
    throw new AppError(
      `App returned non-JSON (${res.status}) for ${proc}`,
      "BAD_GATEWAY",
      res.status,
    );
  }

  if (body?.error) {
    const err = body.error.json ?? body.error;
    throw new AppError(
      err?.message || `App error on ${proc}`,
      err?.data?.code || "UNKNOWN",
      err?.data?.httpStatus || res.status,
    );
  }
  if (!res.ok) {
    throw new AppError(`App HTTP ${res.status} on ${proc}`, "HTTP_ERROR", res.status);
  }
  return superjson.deserialize(body.result.data);
}

export const appQuery = (session: AppSession, proc: string, input?: unknown) =>
  call(session, proc, input, "GET");

export const appMutation = (session: AppSession, proc: string, input: unknown) =>
  call(session, proc, input, "POST");

/**
 * Fetch stored file bytes via the app's /manus-storage proxy under the user's
 * token. The storageKey here is NEVER model-supplied — callers must resolve it
 * from the user's own ownership-checked reads (see tools.ts docId indirection;
 * the proxy itself is authenticated but not ownership-scoped).
 */
export async function fetchStoredFile(
  session: AppSession,
  storageKey: string,
  maxBytes = 25 * 1024 * 1024,
): Promise<{ bytes: Buffer; contentType: string }> {
  const res = await fetch(`${session.baseUrl}/manus-storage/${storageKey}`, {
    headers: { authorization: `Bearer ${session.token}` },
    redirect: "follow", // 307 to the signed URL
    signal: requestSignal(session),
  });
  if (!res.ok) {
    throw new AppError(`Storage fetch failed (${res.status})`, "STORAGE_ERROR", res.status);
  }
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.byteLength > maxBytes) {
    throw new AppError("Stored file exceeds the 25 MB read cap", "FILE_TOO_LARGE", 413);
  }
  return { bytes: buf, contentType: res.headers.get("content-type") || "application/octet-stream" };
}
