// pdf-parse ships no types and its package entry runs debug code when imported
// under ESM (module.parent check) — the standard workaround is importing the
// lib file directly, which needs this shim.
declare module "pdf-parse/lib/pdf-parse.js" {
  interface PdfParseResult {
    numpages: number;
    text: string;
  }
  function pdfParse(dataBuffer: Buffer, options?: Record<string, unknown>): Promise<PdfParseResult>;
  export default pdfParse;
}
