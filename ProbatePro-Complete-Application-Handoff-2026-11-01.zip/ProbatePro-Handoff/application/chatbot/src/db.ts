/**
 * Bot-local SQLite store (node:sqlite built-in, WAL).
 *
 * Completely separate from the app's TiDB — no shared schema, no migration gate.
 * EVERY query is scoped by user_id derived from auth.me (client-supplied IDs are
 * never trusted), mirroring the app's own assertEstateOwned discipline so the
 * bot cannot become the cross-user leak the app prevents (security HOLE C).
 *
 * Never stored here: JWTs (any form), attachment bytes, the Forge key.
 *
 * ponytail: node:sqlite over better-sqlite3 — this is a win32-arm64 box with no
 * native toolchain, and Node 24's built-in has the same synchronous API.
 */
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { createRequire } from "node:module";
import type { DatabaseSync as DatabaseSyncType } from "node:sqlite";
import { ENV } from "./env.js";

// Runtime require: vite/vitest's builtin list predates node:sqlite and would
// try (and fail) to bundle a static import; Node resolves this at runtime.
const requireBuiltin = createRequire(import.meta.url);
const { DatabaseSync } = requireBuiltin("node:sqlite") as {
  DatabaseSync: new (path: string) => DatabaseSyncType;
};

// Test-mode safety (ChatGPT #10): never open the developer/operator default DB
// under vitest — CHATBOT_DB_PATH must point at a dedicated test file (set in
// vitest.config.ts). Guards against a misconfigured run mutating real data.
if (process.env.VITEST && /(^|[\\/])chatbot\.db$/.test(ENV.dbPath)) {
  throw new Error(
    "[chatbot] test run refused the default chatbot.db — set CHATBOT_DB_PATH to a test path",
  );
}

const dbFile = path.resolve(process.cwd(), ENV.dbPath);
fs.mkdirSync(path.dirname(dbFile), { recursive: true });

const db = new DatabaseSync(dbFile);
db.exec("PRAGMA journal_mode = WAL;");
// Wait (up to 5s) for a competing writer instead of throwing "database is
// locked": WAL allows one writer, and a second connection opening concurrently
// (a second process, or parallel test workers) would otherwise fail the boot
// sweep. A short block is always preferable to a hard failure here.
db.exec("PRAGMA busy_timeout = 5000;");

db.exec(`
CREATE TABLE IF NOT EXISTS conversations (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  scope TEXT NOT NULL DEFAULT 'global',
  title TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_conv_user ON conversations(user_id, updated_at DESC);

CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  conversation_id TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('user','assistant')),
  content TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversation_id, created_at);

CREATE TABLE IF NOT EXISTS audit (
  id TEXT PRIMARY KEY,
  event TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  estate_id TEXT,
  detail TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS feedback (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  message_id TEXT NOT NULL,
  conversation_id TEXT NOT NULL,
  rating TEXT NOT NULL CHECK (rating IN ('up','down')),
  comment TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_feedback_msg_user ON feedback(message_id, user_id);
`);

// Proposals schema is kept separate so a schema change (the 'applying' status,
// finding #2) can be reconciled on an OLDER db — SQLite cannot ALTER a CHECK
// constraint, so `CREATE TABLE IF NOT EXISTS` alone would leave a pre-existing
// table with the narrower CHECK, and the atomic-claim UPDATE would then throw.
const PROPOSALS_SCHEMA = `
CREATE TABLE IF NOT EXISTS proposals (
  id TEXT PRIMARY KEY,
  conversation_id TEXT,
  user_id INTEGER NOT NULL,
  estate_id TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('intake','contacts','inventory','contact_updates')),
  payload TEXT NOT NULL,
  diff TEXT NOT NULL,
  -- 'applying' is the atomic claim: a proposal is moved pending->applying in one
  -- UPDATE before the app write, so a concurrent Apply sees it is no longer
  -- pending and stops. A row stranded in 'applying' (process died mid-apply) has
  -- an unknown outcome and is reset to 'failed' at boot (see below), never
  -- silently retried.
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','applying','applied','dismissed','failed')),
  error TEXT,
  created_at INTEGER NOT NULL,
  resolved_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_prop_user ON proposals(user_id, status);
`;
db.exec(PROPOSALS_SCHEMA);

// Migration: rebuild proposals (rows preserved) when an older DB's stored DDL
// predates the 'applying' status. Rare (the service is uncommitted), but the
// alternative is a claim-time throw, so close it rather than document around it.
{
  const ddl = (
    db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='proposals'").get() as
      | { sql?: string }
      | undefined
  )?.sql;
  // 'contact_updates' joins the CHECK for the edit-an-existing-person path. On a
  // DB created before it, inserting that kind throws a CHECK violation, so the
  // rebuild has to cover this too — same reason as 'applying': SQLite cannot
  // ALTER a CHECK, and CREATE TABLE IF NOT EXISTS leaves the narrower one.
  if (ddl && (!ddl.includes("'applying'") || !ddl.includes("'contact_updates'"))) {
    db.exec("DROP INDEX IF EXISTS idx_prop_user;");
    db.exec("ALTER TABLE proposals RENAME TO proposals_old;");
    db.exec(PROPOSALS_SCHEMA);
    db.exec(
      `INSERT INTO proposals (id, conversation_id, user_id, estate_id, kind, payload, diff, status, error, created_at, resolved_at)
       SELECT id, conversation_id, user_id, estate_id, kind, payload, diff, status, error, created_at, resolved_at FROM proposals_old;`,
    );
    db.exec("DROP TABLE proposals_old;");
  }
}

// Single-process service: at boot nothing is in flight, so any 'applying' row is
// stranded from a previous run's crash/kill — mark it failed so it is observable
// and never re-applied (its app-side outcome is unknown; the user re-proposes).
db.exec(
  "UPDATE proposals SET status = 'failed', error = COALESCE(error, 'Interrupted while applying — the change may already have been saved. Verify the estate before re-proposing.') WHERE status = 'applying';",
);

export const newId = (): string => crypto.randomUUID();

// ── Conversations ────────────────────────────────────────────────────────────

export type ConversationRow = {
  id: string;
  user_id: number;
  scope: string;
  title: string | null;
  created_at: number;
  updated_at: number;
};

export function createConversation(userId: number, scope: string, title?: string): ConversationRow {
  const row: ConversationRow = {
    id: newId(),
    user_id: userId,
    scope,
    title: title ?? null,
    created_at: Date.now(),
    updated_at: Date.now(),
  };
  db.prepare(
    "INSERT INTO conversations (id, user_id, scope, title, created_at, updated_at) VALUES (?,?,?,?,?,?)",
  ).run(row.id, row.user_id, row.scope, row.title, row.created_at, row.updated_at);
  return row;
}

export function getConversation(userId: number, id: string): ConversationRow | undefined {
  return db
    .prepare("SELECT * FROM conversations WHERE id = ? AND user_id = ?")
    .get(id, userId) as ConversationRow | undefined;
}

export function latestConversation(userId: number, scope: string): ConversationRow | undefined {
  return db
    .prepare(
      "SELECT * FROM conversations WHERE user_id = ? AND scope = ? ORDER BY updated_at DESC LIMIT 1",
    )
    .get(userId, scope) as ConversationRow | undefined;
}

export function listConversations(userId: number): ConversationRow[] {
  return db
    .prepare("SELECT * FROM conversations WHERE user_id = ? ORDER BY updated_at DESC LIMIT 50")
    .all(userId) as ConversationRow[];
}

export function touchConversation(userId: number, id: string, title?: string): void {
  if (title !== undefined) {
    db.prepare(
      "UPDATE conversations SET updated_at = ?, title = COALESCE(title, ?) WHERE id = ? AND user_id = ?",
    ).run(Date.now(), title, id, userId);
  } else {
    db.prepare("UPDATE conversations SET updated_at = ? WHERE id = ? AND user_id = ?").run(
      Date.now(),
      id,
      userId,
    );
  }
}

export function deleteConversation(userId: number, id: string): boolean {
  const owned = getConversation(userId, id);
  if (!owned) return false;
  db.exec("BEGIN IMMEDIATE;");
  try {
    db.prepare("DELETE FROM feedback WHERE conversation_id = ? AND user_id = ?").run(id, userId);
    db.prepare("DELETE FROM messages WHERE conversation_id = ?").run(id);
    // Cascade the estate-data-bearing proposal rows too (finding #8) — deleting a
    // conversation must not orphan its diffs/payloads (which hold estate PII).
    // The audit log is retained on purpose (it stores field NAMES only, no
    // values — see proposals.applyProposal) so the security trail survives.
    db.prepare("DELETE FROM proposals WHERE conversation_id = ? AND user_id = ?").run(id, userId);
    const result = db.prepare("DELETE FROM conversations WHERE id = ? AND user_id = ?").run(id, userId);
    db.exec("COMMIT;");
    return result.changes === 1;
  } catch (error) {
    db.exec("ROLLBACK;");
    throw error;
  }
}

export function deleteAllConversations(userId: number): number {
  db.exec("BEGIN IMMEDIATE;");
  try {
    db.prepare("DELETE FROM feedback WHERE user_id = ?").run(userId);
    db.prepare(
      "DELETE FROM messages WHERE conversation_id IN (SELECT id FROM conversations WHERE user_id = ?)",
    ).run(userId);
    // Remove every proposal owned by this account, including a legacy/orphaned
    // row whose nullable conversation_id cannot be reached from conversations.
    db.prepare("DELETE FROM proposals WHERE user_id = ?").run(userId);
    const result = db.prepare("DELETE FROM conversations WHERE user_id = ?").run(userId);
    db.exec("COMMIT;");
    return Number(result.changes); // node:sqlite types changes as number|bigint; row counts fit a number
  } catch (error) {
    db.exec("ROLLBACK;");
    throw error;
  }
}

export function pruneExpiredData(now = Date.now()): { conversations: number; messages: number; proposals: number; feedback: number; audit: number } {
  const chatCutoff = now - ENV.retentionDays * 24 * 60 * 60 * 1000;
  const auditCutoff = now - ENV.auditRetentionDays * 24 * 60 * 60 * 1000;
  db.exec("BEGIN IMMEDIATE;");
  try {
    const proposals = db.prepare("DELETE FROM proposals WHERE created_at < ?").run(chatCutoff);
    const messages = db.prepare("DELETE FROM messages WHERE created_at < ?").run(chatCutoff);
    const feedback = db.prepare(
      "DELETE FROM feedback WHERE created_at < ? OR NOT EXISTS (SELECT 1 FROM messages WHERE messages.id = feedback.message_id)",
    ).run(chatCutoff);
    const conversations = db.prepare("DELETE FROM conversations WHERE updated_at < ?").run(chatCutoff);
    const audit = db.prepare("DELETE FROM audit WHERE created_at < ?").run(auditCutoff);
    db.exec("COMMIT;");
    return {
      conversations: Number(conversations.changes),
      messages: Number(messages.changes),
      proposals: Number(proposals.changes),
      feedback: Number(feedback.changes),
      audit: Number(audit.changes),
    };
  } catch (error) {
    db.exec("ROLLBACK;");
    throw error;
  }
}

export function feedbackRowCountForTest(userId: number): number {
  if (!process.env.VITEST) throw new Error("Test-only helper");
  const row = db.prepare("SELECT COUNT(*) AS count FROM feedback WHERE user_id = ?").get(userId) as { count: number };
  return Number(row.count);
}

export function ageConversationForTest(userId: number, conversationId: string, timestamp: number): void {
  if (!process.env.VITEST) throw new Error("Test-only helper");
  if (!getConversation(userId, conversationId)) throw new Error("Conversation not owned");
  db.prepare("UPDATE conversations SET created_at = ?, updated_at = ? WHERE id = ? AND user_id = ?")
    .run(timestamp, timestamp, conversationId, userId);
  db.prepare("UPDATE messages SET created_at = ? WHERE conversation_id = ?").run(timestamp, conversationId);
  db.prepare("UPDATE proposals SET created_at = ? WHERE conversation_id = ? AND user_id = ?").run(timestamp, conversationId, userId);
  db.prepare("UPDATE feedback SET created_at = ? WHERE conversation_id = ? AND user_id = ?").run(timestamp, conversationId, userId);
}

// ── Messages ─────────────────────────────────────────────────────────────────

export type StoredMessageContent = {
  text: string;
  /** Browser-generated idempotency key for a retry-safe user turn. */
  requestId?: string;
  /** Metadata stubs only — raw bytes are never persisted. */
  attachments?: Array<{ name: string; mime: string; size: number }>;
  /** Compact tool trace for UI display; results truncated at write time. */
  toolTrace?: Array<{ name: string; ok: boolean }>;
};

export type MessageRow = {
  id: string;
  conversation_id: string;
  role: "user" | "assistant";
  content: string;
  created_at: number;
};

export function appendMessage(
  conversationId: string,
  role: "user" | "assistant",
  content: StoredMessageContent,
): MessageRow {
  const row: MessageRow = {
    id: newId(),
    conversation_id: conversationId,
    role,
    content: JSON.stringify(content),
    created_at: Date.now(),
  };
  db.prepare(
    "INSERT INTO messages (id, conversation_id, role, content, created_at) VALUES (?,?,?,?,?)",
  ).run(row.id, row.conversation_id, row.role, row.content, row.created_at);
  return row;
}

export function listMessages(userId: number, conversationId: string): MessageRow[] {
  // Ownership check first — a conversation id from another user returns [].
  if (!getConversation(userId, conversationId)) return [];
  return db
    .prepare("SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC")
    .all(conversationId) as MessageRow[];
}

// ── Proposals ────────────────────────────────────────────────────────────────

export type ProposalRow = {
  id: string;
  conversation_id: string | null;
  user_id: number;
  estate_id: string;
  kind: "intake" | "contacts" | "inventory" | "contact_updates";
  payload: string;
  diff: string;
  status: "pending" | "applying" | "applied" | "dismissed" | "failed";
  error: string | null;
  created_at: number;
  resolved_at: number | null;
};

export function createProposal(args: {
  userId: number;
  conversationId: string | null;
  estateId: string;
  kind: ProposalRow["kind"];
  payload: unknown;
  diff: unknown;
}): ProposalRow {
  const row: ProposalRow = {
    id: newId(),
    conversation_id: args.conversationId,
    user_id: args.userId,
    estate_id: args.estateId,
    kind: args.kind,
    payload: JSON.stringify(args.payload),
    diff: JSON.stringify(args.diff),
    status: "pending",
    error: null,
    created_at: Date.now(),
    resolved_at: null,
  };
  db.prepare(
    `INSERT INTO proposals (id, conversation_id, user_id, estate_id, kind, payload, diff, status, created_at)
     VALUES (?,?,?,?,?,?,?,?,?)`,
  ).run(
    row.id,
    row.conversation_id,
    row.user_id,
    row.estate_id,
    row.kind,
    row.payload,
    row.diff,
    row.status,
    row.created_at,
  );
  return row;
}

export function getProposal(userId: number, id: string): ProposalRow | undefined {
  return db
    .prepare("SELECT * FROM proposals WHERE id = ? AND user_id = ?")
    .get(id, userId) as ProposalRow | undefined;
}

/** Pending proposals the user can still Apply/Reject (finding #4 re-hydration). */
export function listPendingProposals(userId: number, estateId?: string): ProposalRow[] {
  const sql =
    "SELECT * FROM proposals WHERE user_id = ? AND status = 'pending'" +
    (estateId ? " AND estate_id = ?" : "") +
    " ORDER BY created_at ASC";
  const stmt = db.prepare(sql);
  return (estateId ? stmt.all(userId, estateId) : stmt.all(userId)) as ProposalRow[];
}

/**
 * Atomically claim a pending proposal for application (finding #2).
 * Returns true only for the ONE caller that flips pending->applying; every
 * concurrent Apply, retry, or double-click sees false and must 409. This is the
 * idempotency guard — the check-then-act in the old apply route let two
 * requests both pass a `status === 'pending'` read across the network await.
 */
/**
 * Atomically dismiss a PENDING proposal (ChatGPT #8). Mirrors claimProposal:
 * only the row still `pending` transitions to `dismissed`; a concurrent Apply
 * (now `applying`/`applied`) or a double-Reject returns false so the caller
 * 409s instead of falsely reporting "Rejected".
 */
export function dismissProposal(userId: number, id: string): boolean {
  const res = db
    .prepare(
      "UPDATE proposals SET status = 'dismissed', resolved_at = ? WHERE id = ? AND user_id = ? AND status = 'pending'",
    )
    .run(Date.now(), id, userId);
  return res.changes === 1;
}

export function claimProposal(userId: number, id: string): boolean {
  // resolved_at is left NULL — it means "reached a terminal state", set only by
  // resolveProposal. A claimed-but-unresolved row is identifiable by status
  // 'applying' + resolved_at NULL (used by the boot sweep above).
  const res = db
    .prepare(
      "UPDATE proposals SET status = 'applying' WHERE id = ? AND user_id = ? AND status = 'pending'",
    )
    .run(id, userId);
  return res.changes === 1;
}

export function resolveProposal(
  userId: number,
  id: string,
  status: "applied" | "dismissed" | "failed",
  error?: string,
): void {
  db.prepare(
    "UPDATE proposals SET status = ?, error = ?, resolved_at = ? WHERE id = ? AND user_id = ?",
  ).run(status, error ?? null, Date.now(), id, userId);
}

// ── Audit (security constraint C-20) ─────────────────────────────────────────

export function auditEvent(
  event: string,
  userId: number,
  estateId: string | null,
  detail: unknown,
): void {
  db.prepare(
    "INSERT INTO audit (id, event, user_id, estate_id, detail, created_at) VALUES (?,?,?,?,?,?)",
  ).run(newId(), event, userId, estateId, JSON.stringify(detail), Date.now());
}

// ── Feedback ───────────────────────────────────────────────────────────────────

export type FeedbackRow = {
  id: string;
  user_id: number;
  message_id: string;
  conversation_id: string;
  rating: "up" | "down";
  comment: string;
  created_at: number;
};

/** Upsert feedback for a message (one rating per user per message). */
export function upsertFeedback(
  userId: number,
  messageId: string,
  conversationId: string,
  rating: "up" | "down",
  comment = "",
): FeedbackRow {
  // Ownership check: the conversation must belong to this user.
  if (!getConversation(userId, conversationId)) {
    throw new Error("forbidden");
  }
  const existing = db
    .prepare("SELECT * FROM feedback WHERE message_id = ? AND user_id = ?")
    .get(messageId, userId) as FeedbackRow | undefined;
  if (existing) {
    db.prepare("UPDATE feedback SET rating = ?, comment = ?, created_at = ? WHERE id = ?").run(
      rating,
      comment,
      Date.now(),
      existing.id,
    );
    return { ...existing, rating, comment, created_at: Date.now() };
  }
  const row: FeedbackRow = {
    id: newId(),
    user_id: userId,
    message_id: messageId,
    conversation_id: conversationId,
    rating,
    comment,
    created_at: Date.now(),
  };
  db.prepare(
    "INSERT INTO feedback (id, user_id, message_id, conversation_id, rating, comment, created_at) VALUES (?,?,?,?,?,?,?)",
  ).run(row.id, row.user_id, row.message_id, row.conversation_id, row.rating, row.comment, row.created_at);
  return row;
}

/** Remove feedback for a message (toggle off). */
export function removeFeedback(userId: number, messageId: string): boolean {
  const res = db
    .prepare("DELETE FROM feedback WHERE message_id = ? AND user_id = ?")
    .run(messageId, userId);
  return res.changes === 1;
}

/** Get all feedback for a conversation (for hydrating the UI). */
export function listFeedback(
  userId: number,
  conversationId: string,
): Array<{ messageId: string; rating: "up" | "down"; comment: string }> {
  if (!getConversation(userId, conversationId)) return [];
  return (
    db
      .prepare("SELECT message_id, rating, comment FROM feedback WHERE conversation_id = ? AND user_id = ?")
      .all(conversationId, userId) as Array<{ message_id: string; rating: string; comment: string }>
  ).map((r) => ({ messageId: r.message_id, rating: r.rating as "up" | "down", comment: r.comment || "" }));
}
