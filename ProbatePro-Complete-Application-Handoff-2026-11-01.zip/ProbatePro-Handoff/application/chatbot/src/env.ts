/**
 * Environment / config for the chatbot service.
 *
 * Deliberately dependency-free: a ~15-line .env parser instead of dotenv, so the
 * service's secret loading shares nothing with the app's `dotenv/config` path.
 * The app is NEVER read from here — no JWT_SECRET, no DATABASE_URL.
 */
import fs from "node:fs";
import path from "node:path";
import { registerSecret } from "./redact.js";

// ponytail: KEY=VALUE lines only — no multiline/export/quote-escaping support;
// upgrade to dotenv if a value ever needs it.
function loadDotEnv(): void {
  const file = path.resolve(process.cwd(), ".env");
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, "utf-8").split(/\r?\n/)) {
    const m = /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/.exec(line);
    if (!m) continue;
    if (line.trimStart().startsWith("#")) continue;
    const key = m[1];
    let value = m[2];
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = value;
  }
}

loadDotEnv();

const appBaseUrl = (process.env.APP_BASE_URL || "http://localhost:3000").replace(/\/+$/, "");

function retentionDays(name: string, fallback: number, minimum: number, maximum: number): number {
  const raw = process.env[name];
  const value = raw === undefined || raw === "" ? fallback : Number(raw);
  if (!Number.isInteger(value) || value < minimum || value > maximum) {
    throw new Error(`${name} must be an integer from ${minimum} to ${maximum}`);
  }
  return value;
}

/** The scheme+host+port of a URL, or the input unchanged if it won't parse. */
function originOf(u: string): string {
  try {
    return new URL(u).origin;
  } catch {
    return u;
  }
}

function isLocalAuthority(host: string | undefined): boolean {
  return !!host && /^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(host);
}

function parseSecureBrowserOrigin(value: string): URL | null {
  try {
    const parsed = new URL(value);
    if (!(["http:", "https:"] as const).includes(parsed.protocol as "http:" | "https:")) return null;
    if (parsed.username || parsed.password || parsed.pathname !== "/" || parsed.search || parsed.hash) return null;
    if (parsed.protocol === "http:" && !isLocalAuthority(parsed.host)) return null;
    return parsed;
  } catch {
    return null;
  }
}

export const ENV = {
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  // Default to a model this Forge deployment actually serves. The app's own
  // Forge calls use gpt-5-mini / gemini-3-flash-preview (server/routers.ts);
  // `claude-sonnet-4-6` (the prior default) is NOT served here and failed every
  // turn. Override with CHATBOT_MODEL to any Forge-served, tool-capable model.
  model: process.env.CHATBOT_MODEL || "gpt-5-mini",
  port: Number(process.env.CHATBOT_PORT || 3100),
  host: process.env.CHATBOT_HOST || "127.0.0.1",
  appBaseUrl,
  // SECURITY (finding #1): the DEFAULT CORS/CSRF allowlist is EXACTLY the app's
  // own origin — never a localhost port-wildcard. The old `.*:\d+` default let
  // any local page pass CORS (read estate responses) and pass the CSRF check.
  // Operators with a genuine multi-origin dev setup override via a CSV/regex in
  // ALLOWED_APP_ORIGINS. Note: this allowlist governs the browser origin ONLY;
  // it NEVER chooses where the JWT is forwarded — see auth.resolveAppBase.
  allowedAppOrigins: process.env.ALLOWED_APP_ORIGINS || originOf(appBaseUrl),
  dbPath: process.env.CHATBOT_DB_PATH || "./data/chatbot.db",
  retentionDays: retentionDays("CHATBOT_RETENTION_DAYS", 30, 1, 365),
  auditRetentionDays: retentionDays("CHATBOT_AUDIT_RETENTION_DAYS", 365, 30, 2_555),
} as const;

// Value-based redaction: scrub the actual Forge key from every log/error/prompt
// sink by exact value, so a key whose format the sk-/forge- pattern misses can
// never leak (e.g. via a Forge error body that reflects the Authorization
// header). Registered here — the one config chokepoint both the standalone and
// embedded entry points import.
registerSecret(ENV.forgeApiKey);

/**
 * A `/regex/` origin entry is INSECURE if it is unanchored (so `/localhost/`
 * matches `localhost.evil.tld`) or matches a wildcard/port-range (so
 * `/^http:\/\/…:\d+$/` matches ANY port). Such entries are DROPPED with a loud
 * warning (Kimi #3 + the unanchored-regex foot-gun). The shipped `.env.example`
 * now uses one exact localhost origin, and a copied or operator-supplied config
 * must NOT re-open the caller channel the finding-#1 fix closed. The app's own
 * exact origin is always trusted separately, so the legit widget still works.
 */
function isInsecureOriginRegex(src: string): boolean {
  // Safe ONLY if anchored AND a fixed literal: after removing the anchors and any
  // escaped dots, no regex metacharacter may remain. This rejects wildcards
  // (`.*`), char classes / port ranges (`[0-9]{2,5}`), alternation (`|`),
  // unescaped dots (`trusted.example.com` matching `trusted-example.com`), and
  // `\d`/`\w`/`\s` classes — every way a hand-written regex could match beyond a
  // single exact origin. Operators wanting several origins use a CSV of exacts.
  if (!(src.startsWith("^") && src.endsWith("$"))) return true;
  const core = src.slice(1, -1).replace(/\\\./g, "");
  return /[.*+?()[\]{}|]|\\[dwsSDW]/.test(core);
}

/** Origin matchers: the app's exact origin is ALWAYS trusted; operator entries add to it. */
const matchers: Array<(origin: string) => boolean> = (() => {
  const appOrigin = originOf(appBaseUrl);
  const out: Array<(origin: string) => boolean> = [(o) => o === appOrigin];
  for (const entry of ENV.allowedAppOrigins.split(",").map((s) => s.trim()).filter(Boolean)) {
    if (entry.startsWith("/") && entry.endsWith("/") && entry.length > 2) {
      const src = entry.slice(1, -1);
      if (isInsecureOriginRegex(src)) {
        console.error(
          `[chatbot] SECURITY: ignoring insecure ALLOWED_APP_ORIGINS regex ${entry} ` +
            `(unanchored or port/host wildcard). Use exact origins, e.g. ALLOWED_APP_ORIGINS=${appOrigin}`,
        );
        continue;
      }
      const re = new RegExp(src);
      out.push((o) => re.test(o));
    } else {
      const exact = entry.replace(/\/+$/, "");
      if (exact !== appOrigin) out.push((o) => o === exact);
    }
  }
  return out;
})();

export function isAllowedOrigin(origin: string | undefined): boolean {
  if (!origin) return false;
  const parsed = parseSecureBrowserOrigin(origin);
  if (!parsed) return false;
  const normalized = parsed.origin;
  return matchers.some((fn) => fn(normalized));
}

// The EXACT browser origin(s) the widget is served from — an EXPLICIT backstop
// allowlist for reverse-proxy setups where the browser Origin legitimately
// differs from the request Host. Kept INDEPENDENT of the parent app's broad CORS
// allowlist (`*.manus.*`, `*.run.app`), which reflects credentials and therefore
// must NOT be the chatbot's trust boundary (ChatGPT finding 1). Wildcards are
// DELIBERATELY absent; sources are the app's known custom domain, an explicit
// APP_URL, an operator CHATBOT_BROWSER_ORIGINS CSV, and the app base.
const EXACT_BROWSER_ORIGINS: string[] = (() => {
  const out = new Set<string>(["https://probate-pro.com", "https://www.probate-pro.com"]);
  const add = (u?: string) => {
    const t = (u ?? "").trim();
    if (t) out.add(originOf(t).replace(/\/+$/, ""));
  };
  for (const e of (process.env.CHATBOT_BROWSER_ORIGINS ?? "").split(",")) add(e);
  add(process.env.APP_URL);
  add(appBaseUrl);
  return [...out].filter(Boolean);
})();

/**
 * Whether a browser `Origin` may make credentialed requests to the chatbot — the
 * chatbot's OWN CSRF/read trust boundary, enforced on EVERY authenticated route
 * (GET + mutating) and identically whether embedded or standalone. The parent
 * CORS allowlist is never consulted (ChatGPT finding 1). Allowed:
 *   - `undefined` — same-origin GET / server-to-server / curl send no Origin;
 *   - localhost / 127.0.0.1 — dev;
 *   - **same-origin**: a secure Origin's authority equals the request `Host` (the
 *     widget is mounted INSIDE the app, so its Origin host always matches the
 *     host it is served from — deployment-agnostic, needs no config);
 *   - an EXACT configured app origin (APP_URL / probate-pro.com / CSV override).
 * A cross-origin page (e.g. `evil.manus.space` → `probate-pro.com`) has an Origin
 * host that differs from the target Host and is not in the exact list → rejected.
 */
export function isAllowedBrowserOrigin(origin: string | undefined, host?: string, requestProtocol = "https"): boolean {
  if (!origin) return true; // same-origin GET / server-to-server: no Origin header
  const parsed = parseSecureBrowserOrigin(origin);
  if (!parsed) return false; // malformed, non-HTTP(S), or insecure non-local Origin
  const o = parsed.origin;
  const originHost = parsed.host;
  // localhost/127.0.0.1 is trusted ONLY when the request Host is ALSO local
  // (ChatGPT finding 2): a malicious `http://localhost:5173` page must not be
  // trusted against a production host just because the parent CORS reflects
  // localhost — `isAllowedBrowserOrigin("http://localhost:5173","probate-pro.com")`
  // must be false.
  if (isLocalAuthority(originHost)) {
    return !!host && isLocalAuthority(host) && o.toLowerCase() === `${requestProtocol.toLowerCase()}://${host.toLowerCase()}`;
  }
  // Same-origin: a secure browser Origin's authority equals the request Host.
  if (host && originHost === host) return true;
  // Or an EXACT configured app origin (reverse-proxy backstop).
  return EXACT_BROWSER_ORIGINS.includes(o);
}

type ForgeRuntimeConfig = {
  forgeApiKey: string;
  forgeApiUrl: string;
};

export function validateEnv(config: ForgeRuntimeConfig = ENV): void {
  const error = forgeConfigError(config);
  if (error) {
    // Fail loud before this service listens. Throw instead of process.exit so
    // the parent app's optional embedded mount can catch the failure and keep
    // serving the rest of ProbatePro; standalone startup still exits non-zero.
    console.error(`[chatbot] FATAL: ${error}`);
    throw new Error(`Chatbot configuration invalid: ${error}`);
  }
}

export function forgeConfigError(config: ForgeRuntimeConfig): string | null {
  if (!config.forgeApiKey.trim()) return "BUILT_IN_FORGE_API_KEY is required";
  if (!config.forgeApiUrl.trim()) return "BUILT_IN_FORGE_API_URL is required";
  let parsed: URL;
  try {
    parsed = new URL(config.forgeApiUrl.trim());
  } catch {
    return "BUILT_IN_FORGE_API_URL must be a valid URL";
  }
  if (parsed.username || parsed.password || parsed.search || parsed.hash) {
    return "BUILT_IN_FORGE_API_URL must not contain credentials, a query, or a fragment";
  }
  if (parsed.protocol !== "https:" && !(parsed.protocol === "http:" && isLocalAuthority(parsed.host))) {
    return "BUILT_IN_FORGE_API_URL must use HTTPS (HTTP is allowed only for localhost/127.0.0.1)";
  }
  return null;
}
