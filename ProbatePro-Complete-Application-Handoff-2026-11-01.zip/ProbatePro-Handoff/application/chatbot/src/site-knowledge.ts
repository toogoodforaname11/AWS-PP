/**
 * Curated PRODUCT-HELP corpus for the assistant's "how do I / where is X" answers.
 *
 * GLOBAL product knowledge ONLY — never any tenant/estate data (privacy: this path
 * takes a query, returns static content, touches no user data). Every entry carries
 * the code/authority source used to review it. Tests verify route compatibility,
 * source-file existence, and a focused retrieval eval. Those guards catch structural
 * drift; they do not pretend that prose can never become stale after a UI change.
 *
 * `route` is one of the chatbot's REAL suggest_navigation destinations:
 *   - a top-level path: "/", "/deadlines", "/settings"
 *   - an estate tab token: intake|contacts|inventory|forms|client-portal|readiness|notes|activity
 *   - null: a conceptual answer with no single destination
 */

// Rule 24 (2026-08-17): the Documents tab was removed — its checklist card
// lives in Readiness, the AI import in Intake.
export type EstateTab =
  | "intake"
  | "contacts"
  | "inventory"
  | "client-portal"
  | "forms"
  | "readiness"
  | "notes"
  | "activity";

export type HelpRoute = "/" | "/deadlines" | "/settings" | EstateTab | null;

export type HelpEntry = {
  id: string;
  title: string;
  route: HelpRoute;
  keywords: string[];
  /** 1–3 sentence, code-true how-to. Shown to the user (via the tool result). */
  answer: string;
  /** Code/authority citation returned with the answer so its basis is inspectable. */
  source: string;
};

/** The app's real estate-tab tokens. Drift-tested against EstateDetail.tsx + NAV_RE. */
export const ESTATE_TABS: readonly EstateTab[] = [
  "intake",
  "contacts",
  "inventory",
  "forms",
  "client-portal",
  "readiness",
  "notes",
  "activity",
];

/** The app's real top-level routes (besides an estate). Drift-tested against NAV_RE. */
export const TOP_LEVEL_ROUTES = ["/", "/deadlines", "/settings"] as const;

export const SITE_KNOWLEDGE: HelpEntry[] = [
  {
    id: "review-client-portal-intake",
    title: "Review and apply client intake",
    route: "client-portal",
    keywords: ["client", "executor", "portal", "intake", "review", "apply", "link"],
    answer: "Open the estate’s Client Portal tab to issue the client’s intake link and review submitted answers. Use each field’s Apply button or Apply all unapplied facts after verification. Answers remain separate until applied; family reports are not automatically classified as beneficiaries.",
    source: "client/src/components/EstateClientPortal.tsx; client/src/components/ClientIntakeReview.tsx",
  },
  {
    id: "edit-beneficiary-letter-wording",
    title: "Edit the beneficiary-letter wording",
    route: "/settings",
    keywords: ["beneficiary", "letter", "wording", "template", "edit", "closing", "text", "body"],
    answer:
      "The beneficiary letter's wording is a firm-wide template in Settings — the Letter Body Template (and the Closing Block). Editing it changes the letter for every estate; there is no per-estate letter editor.",
    source: "client/src/pages/Settings.tsx (letterBodyTemplate/letterClosing); shared/letter-template.ts",
  },
  {
    id: "generate-beneficiary-letters",
    title: "Generate the beneficiary letters for an estate",
    route: "forms",
    keywords: ["beneficiary", "letter", "generate", "produce", "download", "send", "print"],
    answer:
      "The letters themselves are generated per estate from the Forms tab (they download together as a zip). To change their wording, edit the template in Settings.",
    source: "client/src/pages/EstateDetail.tsx (document.generateAllLetters / getLetterRecipients, in FormsTab)",
  },
  {
    id: "record-beneficiary-share",
    title: "Record a beneficiary's share / distribution",
    route: "forms",
    keywords: ["share", "distribution", "beneficiary", "percentage", "bequest", "p10", "part 3", "split"],
    answer:
      "Beneficiary shares and specific bequests are recorded in the Distribution card on the Forms tab; this feeds the supplementary Distribution section that ProbatePro appends to its generated P10. The official Form P10 does not call that section Part 3.",
    source: "client/src/pages/EstateDetail.tsx DistributionCard (distribution.updateShare); drizzle/schema.ts contacts.share/shareType",
  },
  {
    id: "generate-court-form",
    title: "Generate or preview a court form",
    route: "forms",
    keywords: ["form", "generate", "preview", "download", "p1", "p2", "p3", "grant", "package", "court"],
    answer:
      "Where ProbatePro supports generation, generate, preview, and download the BC probate forms and grant package from the Forms tab. Prescribed court-form text is not edited in the app; correct the source data and regenerate, then review the result before swearing or filing.",
    source: "client/src/pages/EstateDetail.tsx FormsTab (document.generate / document.preview / document.generatePackage); references/SupremeCourtCivilRules.md Appendix A.1",
  },
  {
    id: "p8-p9-are-affidavits",
    title: "What are forms P8 and P9",
    route: "forms",
    keywords: ["p8", "p9", "affidavit", "delivery", "additional applicant"],
    answer:
      "P8 is the Affidavit in Support of Application for Estate Grant and P9 is the Affidavit of Delivery. ProbatePro generates them from the Forms tab when the app's applicability rules require them; ask the supervising lawyer which affidavit is required for the matter.",
    source: "references/SupremeCourtCivilRules.md Appendix A.1 (Forms P8 and P9); shared/types.ts (p8ApplyingCoApplicants / formStatus); server/docgen.ts",
  },
  {
    id: "deadlines-are-computed",
    title: "Why a deadline still shows / how to mark a deadline done",
    route: "/deadlines",
    keywords: ["deadline", "mark", "done", "complete", "dismiss", "clear", "statutory", "calendar"],
    answer:
      "Deadlines are computed from recorded estate events and dates. There is no manual mark-done, complete, or dismiss control: record the real completion fact in its source workflow, and the deadline engine will recalculate the event, which may remain visible with a completed status.",
    source: "client/src/pages/Deadlines.tsx (read-only event list); shared/deadline-engine.ts (completion facts and completed statuses)",
  },
  {
    id: "create-new-estate",
    title: "Create a new estate file",
    route: "/",
    keywords: ["new", "create", "estate", "file", "add", "start", "open"],
    answer:
      "Create a new estate from the dashboard (the home page) — use the New Estate action (or Ctrl+N).",
    source: "client/src/pages/Home.tsx (createMutation; Ctrl+N shortcut)",
  },
  {
    id: "upload-will",
    title: "Upload the will (or codicil / foreign grant)",
    route: "intake",
    keywords: ["upload", "will", "codicil", "foreign grant", "attach", "file", "document"],
    answer:
      "The will, codicil, and foreign-grant files are uploaded on the Intake tab, alongside the estate/will/deceased details.",
    source: "client/src/pages/EstateDetail.tsx IntakeTab (uploadMutation / uploadCodicilMutation / uploadForeignGrantMutation)",
  },
  {
    id: "add-contact-beneficiary",
    title: "Add a beneficiary, executor, or spouse",
    route: "contacts",
    keywords: ["add", "beneficiary", "executor", "spouse", "contact", "person", "delivery", "address"],
    answer:
      "Add people — executors, beneficiaries, the spouse — with each one's role, delivery method, and address on the Contacts tab.",
    source: "client/src/pages/EstateDetail.tsx ContactsTab (emptyContact role/address/deliveryMethod)",
  },
  {
    id: "record-inventory",
    title: "Record assets and debts",
    route: "inventory",
    keywords: ["inventory", "asset", "debt", "liability", "property", "value", "total", "record"],
    answer:
      "Record assets and debts (by category) and read the totals on the Inventory tab.",
    source: "client/src/pages/EstateDetail.tsx InventoryTab (inventory.list / inventory.totals)",
  },
  {
    id: "wills-search-vsa532",
    title: "Record the Wills Notice search result (VSA 532)",
    route: "intake",
    keywords: ["wills search", "vsa 532", "vsa532", "notice", "search", "result", "certificate"],
    answer:
      "Record the VSA 532 certificate result once, in Intake, under \"Wills Notice Search Result (from the certificate)\" — the result (and the notice date, when one was found) drives the sworn wording on P4/P6/P7. Track receipt of the certificate itself with the required-documents checklist on the Readiness tab. The Form 532 search request can be generated on demand from the Forms tab if the search has not been run yet.",
    source: "client/src/pages/EstateDetail.tsx IntakeTab (estates.vsaCertificateResult / vsaWillsNoticeDate); RULES.md Rules 21 and 24",
  },
  {
    id: "required-documents-checklist",
    title: "The required-documents checklist / import a document",
    route: "readiness",
    keywords: ["required", "documents", "checklist", "import", "upload", "source"],
    answer:
      "The required-source-documents checklist is at the top of the Readiness tab; the AI-assisted document import is at the bottom of the Intake tab. (The former Documents tab was removed — both features moved, nothing was dropped.)",
    source: "client/src/pages/EstateDetail.tsx RequiredSourceDocumentsCard / AiImportCard (requiredDoc.list/upsert; aiImport.process); RULES.md Rule 24",
  },
  {
    id: "record-death-certificate-received",
    title: "Record that the death certificate was received",
    route: "readiness",
    keywords: ["death certificate", "certificate", "received", "required source", "checklist"],
    answer:
      "On the Readiness tab, check Government-issued death certificate in Required Source Documents. That checklist feeds the Readiness result; it is separate from attaching a file in chat.",
    source: "client/src/pages/EstateDetail.tsx RequiredSourceDocumentsCard (Required Source Documents); shared/types.ts REQUIRED_DOCUMENTS; shared/formRequirements.ts p2_death_certificate_source",
  },
  {
    id: "check-readiness",
    title: "Check whether a file is ready to file",
    route: "readiness",
    keywords: ["ready", "readiness", "checklist", "blocker", "filing", "pass", "fail"],
    answer:
      "The Readiness tab shows the filing checklist — what passes, fails, or needs attention before filing.",
    source: "client/src/pages/EstateDetail.tsx ReadinessTabContent (readiness.check)",
  },
  {
    id: "change-firm-info",
    title: "Change firm / lawyer details",
    route: "/settings",
    keywords: ["firm", "lawyer", "name", "address", "contact", "details", "settings"],
    answer:
      "Change firm and lawyer details (name, address, contact) in Settings.",
    source: "client/src/pages/Settings.tsx (firm/lawyer fields)",
  },
  {
    id: "checkbox-appearance",
    title: "Change generated-form checkbox appearance",
    route: "/settings",
    keywords: ["checkbox appearance", "checkbox", "box", "size", "bold", "generated docx"],
    answer:
      "Use Checkbox Appearance in Settings to change the checkbox size and bold preference used across generated DOCX court forms.",
    source: "client/src/pages/Settings.tsx CheckboxAppearanceCard",
  },
  {
    id: "upload-letterhead",
    title: "Upload firm letterhead",
    route: "/settings",
    keywords: ["letterhead", "upload", "logo", "header", "docx", "template"],
    answer:
      "Upload firm letterhead (an image or a DOCX template) in Settings, under Firm Letterhead.",
    source: "client/src/pages/Settings.tsx (uploadLetterhead / uploadLetterheadDocx)",
  },
  {
    id: "portal-access",
    title: "Give a client / executor portal access",
    route: "/settings",
    keywords: ["portal", "client", "executor", "access", "invite", "login"],
    answer:
      "Manage executor / client portal access in Settings, under Executor / Client Portal Access.",
    source: "client/src/pages/Settings.tsx (Executor / Client Portal Access card)",
  },
  {
    id: "notes-tab",
    title: "Add notes to an estate",
    route: "notes",
    keywords: ["note", "notes", "memo", "comment"],
    answer: "Free-form notes for the estate live on the Notes tab.",
    source: "client/src/pages/EstateDetail.tsx NotesTab",
  },
  {
    id: "activity-tab",
    title: "See the estate's history",
    route: "activity",
    keywords: ["activity", "history", "log", "who", "changed", "audit"],
    answer: "The Activity tab shows the estate's history — who did what, and when.",
    source: "client/src/pages/EstateDetail.tsx ActivityTab (activity.list)",
  },
  {
    id: "add-executor",
    title: "Add an executor",
    route: "contacts",
    keywords: ["executor", "alternate", "administrator", "applying", "renounce", "status"],
    answer:
      "Add an executor on the Contacts tab: add the contact and give them the Executor (or Alternate Executor) role, then set their executor status (e.g. Applying, Renounced).",
    source: "client/src/pages/EstateDetail.tsx ContactsTab (executor / alternate_executor role; Executor Status select)",
  },
  {
    id: "set-delivery-method",
    title: "Set how a person is served the P1 notice",
    route: "contacts",
    keywords: ["delivery", "method", "served", "notice", "mail", "personal", "electronic", "date"],
    answer:
      "Set a person's P1 delivery method (ordinary mail, personal, electronic) and delivery date in that contact's details on the Contacts tab.",
    source: "client/src/pages/EstateDetail.tsx ContactsTab (P1 Delivery Method + Delivery Date)",
  },
  {
    id: "mark-minor-incapable",
    title: "Mark a contact as a minor or mentally incapable",
    route: "contacts",
    keywords: ["minor", "incapable", "under 19", "pgt", "committee", "guardian"],
    answer:
      "Mark a beneficiary or other contact as a minor (under 19) or mentally incapable in their details on the Contacts tab; this drives the PGT / committee delivery fields.",
    source: "client/src/pages/EstateDetail.tsx ContactsTab (isMinor / isMentallyIncapable; PGT-relevant status)",
  },
  {
    id: "consent-renunciation-upload",
    title: "Record a beneficiary's priority consent / renunciation",
    route: "contacts",
    keywords: ["consent", "renunciation", "priority", "attach", "upload", "waiver"],
    answer:
      "Record a beneficiary's priority consent / renunciation on the Contacts tab. Each contact has a document-reference field; when there are two or more beneficiaries, a drag-and-drop file attach also appears in the Beneficiary Consent card below the contact list.",
    source: "client/src/pages/EstateDetail.tsx (per-contact priorityConsentDocumentKey reference ~L3858; Beneficiary Consent card drop-zone ~L4453, shown for 2+ beneficiaries)",
  },
  {
    id: "mark-contact-predeceased",
    title: "Mark a contact as predeceased / link a representative",
    route: "contacts",
    keywords: ["predeceased", "died before", "representation", "stirpes", "deceased", "s.24"],
    answer:
      "On the Contacts tab, use the Predeceased checkbox on the contact record and, when applicable, link the surviving descendant to that predeceased parent. The app uses those recorded relationships for its WESA s. 24 representation calculation; confirm the legal result with the supervising lawyer.",
    source: "client/src/pages/EstateDetail.tsx (isPredeceased / representsPredeceasedParentId); shared/types.ts (WESA s. 24 distribution logic); references/WillsEstatesAndSuccessionAct.md s. 24",
  },
  {
    id: "enter-deceased-details",
    title: "Enter the deceased's name and dates",
    route: "intake",
    keywords: ["deceased", "name", "date of death", "date of birth", "dod", "dob"],
    answer:
      "Enter the deceased's name, date of birth, and date of death (date of death is required) under Deceased Information on the Intake tab.",
    source: "client/src/pages/EstateDetail.tsx IntakeTab (deceasedFirstName/deceasedLastName/dateOfBirth/dateOfDeath)",
  },
  {
    id: "choose-grant-type",
    title: "Choose or change the grant type",
    route: "intake",
    keywords: ["grant", "type", "probate", "administration", "ancillary", "resealing"],
    answer:
      "Choose or change the grant type on the Intake tab. The available choices include probate, administration with or without a will, ancillary variants, and resealing; the supervising lawyer must decide which type applies.",
    source: "client/src/pages/EstateDetail.tsx IntakeTab (grant type); shared/types.ts normalizeGrantType",
  },
  {
    id: "change-court-registry",
    title: "Choose or change the court registry",
    route: "intake",
    keywords: ["court registry", "registry", "vancouver", "victoria", "filing court"],
    answer:
      "Choose the Court Registry in the Filing & Court section of the Intake tab.",
    source: "client/src/pages/EstateDetail.tsx IntakeTab (Filing & Court / registry)",
  },
  {
    id: "set-domicile-residence",
    title: "Set the deceased's domicile / last address",
    route: "intake",
    keywords: ["domicile", "residence", "residential", "address", "ordinary", "country", "city"],
    answer:
      "Set the deceased's domicile and last residential address on the Intake tab.",
    source: "client/src/pages/EstateDetail.tsx IntakeTab (domicile / residence fields)",
  },
  {
    id: "add-inventory-item",
    title: "Add an asset or a debt",
    route: "inventory",
    keywords: ["asset", "debt", "liability", "add", "account", "property", "value", "item"],
    answer:
      "Add an asset or a debt/liability (with its category and value) on the Inventory tab; the totals update automatically.",
    source: "client/src/pages/EstateDetail.tsx InventoryTab (inventory.create; category real_property/financial/liability)",
  },
  {
    id: "csv-import-inventory",
    title: "Bulk-import inventory from a CSV",
    route: "inventory",
    keywords: ["csv", "import", "bulk", "spreadsheet", "upload inventory"],
    answer: "Bulk-import inventory items from a CSV file on the Inventory tab.",
    source: "client/src/pages/EstateDetail.tsx InventoryTab (handleCsvImport / inventory.bulkCreate)",
  },
  {
    id: "estate-totals-probate-fee",
    title: "See estate totals and the probate-fee estimate",
    route: "inventory",
    keywords: ["total", "totals", "probate fee", "estimate", "gross", "net", "value"],
    answer:
      "The estate's asset/debt totals and the probate-fee estimate are shown on the Inventory tab, computed from the recorded values.",
    source: "client/src/pages/EstateDetail.tsx InventoryTab (inventory.totals); shared/types.ts probateFee",
  },
  {
    id: "generate-grant-package",
    title: "Generate the grant-package drafts",
    route: "forms",
    keywords: ["grant", "package", "filing", "all forms", "bundle", "submission"],
    answer:
      "Generate the grant-package DOCX files from the Forms tab. Generation does not by itself mean the file is ready to file: review the Readiness result, the preflight gaps, and each generated document before filing.",
    source: "client/src/pages/EstateDetail.tsx FormsTab (document.generatePackage / runWithPreflight); client/src/pages/EstateDetail.tsx ReadinessTabContent",
  },
  {
    id: "record-grant-issued-date",
    title: "Record that the grant was issued",
    route: "forms",
    keywords: ["grant issued", "issued date", "mark grant issued", "p19", "sealed grant"],
    answer:
      "In the Forms tab, use the P19 — Grant Certificate card to enter the grant-issued date or choose Mark Grant Issued. P19 is issued by the court; ProbatePro does not generate it.",
    source: "client/src/pages/EstateDetail.tsx P19GrantCard; shared/types.ts formStatus (P19 court-issued)",
  },
  {
    id: "record-citation",
    title: "Record and track a citation",
    route: "forms",
    keywords: ["citation", "citor", "cited person", "p34", "service", "response"],
    answer:
      "Use the Citation tracker in the Forms tab to record a cited person, service, response, evidence, and any Form P34 action the app makes available.",
    source: "client/src/pages/EstateDetail.tsx (CitationTracker in FormsTab); client/src/components/CanonicalLegalEvents.tsx",
  },
  {
    id: "redownload-document",
    title: "Re-download a previously generated document",
    route: "forms",
    keywords: ["re-download", "redownload", "download again", "previous", "version", "generated"],
    answer:
      "Re-download a previously generated document from the Forms tab, which lists the generated documents and their versions.",
    source: "client/src/pages/EstateDetail.tsx FormsTab (document.list / document.versions)",
  },
  {
    id: "edit-form-wording",
    title: "Edit the wording of a court form",
    route: "forms",
    keywords: ["edit form", "change form", "wording", "form text", "customize form"],
    answer:
      "You can't directly edit prescribed court-form text in ProbatePro. Correct the underlying data, regenerate the supported form, and review the result before it is sworn, signed, or filed; not every court form is an affidavit.",
    source: "references/SupremeCourtCivilRules.md Appendix A.1; server/docgen.ts (generated forms consume recorded data)",
  },
  {
    id: "find-estate",
    title: "Find one of your estate files",
    route: "/",
    keywords: ["find", "search", "open", "estate", "file", "list", "which"],
    answer: "All your estates are listed on the dashboard (the home page); open one from there.",
    source: "client/src/pages/Home.tsx (estate.list)",
  },
  {
    id: "delete-estate",
    title: "Permanently delete an estate file",
    route: "/",
    keywords: ["delete estate", "delete", "remove estate", "permanently delete", "trash"],
    answer:
      "On the dashboard, use the trash action on the estate card and confirm Delete. This permanently deletes the estate and its associated records and cannot be undone; use Archive instead if you may need the file later.",
    source: "client/src/pages/Home.tsx (delete action / Delete estate file confirmation / archive action)",
  },
  {
    id: "no-automatic-reminders",
    title: "Does the app send deadline reminders / email alerts?",
    route: null,
    keywords: ["reminder", "alert", "email", "notify", "notification", "automatic"],
    answer:
      "No — the app doesn't send automatic reminders or email alerts. The Deadlines page is something you open and check; it doesn't notify you.",
    source: "client/src/pages/Deadlines.tsx (pull-based; no notification/alerting system found)",
  },
  {
    id: "no-global-document-search",
    title: "Is there a global document search / file browser?",
    route: null,
    keywords: ["search documents", "file browser", "global search", "find document", "all files"],
    answer:
      "No global document search or file browser exists — documents live within each estate (the Readiness-tab required-documents checklist + the generated files under the Forms tab).",
    source: "client/src/pages/Home.tsx; client/src/pages/EstateDetail.tsx (no global document-search route; estate Readiness and Forms surfaces); RULES.md Rule 24",
  },
  {
    id: "assistant-scope",
    title: "What the assistant can and can't do",
    route: null,
    keywords: ["assistant", "chatbot", "you", "help", "can you", "do for me"],
    answer:
      "I can read and summarize this file's data, draft proposed changes for you to review and Apply, and point you to the right tab. I can't change data directly, generate or file documents, or give legal advice.",
    source: "chatbot/src/tools.ts (read + propose-only registry; suggest_navigation); agent.ts guardrails",
  },
];

/**
 * Deterministic keyword scorer over the corpus. No embeddings — the corpus is small,
 * keyword match is fast, testable, and dependency-free.
 * ponytail: keyword search; swap for embeddings only if the corpus grows past ~a few hundred entries.
 */
const STOPWORDS = new Set([
  "how", "what", "where", "when", "why", "who", "does", "can", "could", "should",
  "the", "this", "that", "these", "those", "with", "from", "your", "you", "for",
  "are", "and", "but", "not", "its", "has", "have", "would", "about",
  "into", "onto", "get", "set", "use", "using", "want", "need", "app", "page",
  // These product nouns are too broad to establish relevance on their own.
  "estate", "file", "files", "form", "forms", "document", "documents",
]);

export function searchHelp(query: string, limit = 3): HelpEntry[] {
  const q = query.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  if (!q) return [];
  // De-duplicate exact tokens. Substring matching made `date`, `file`, and other
  // generic fragments return confident but unrelated help answers.
  const terms = [...new Set(q
    .split(/[^a-z0-9]+/)
    .filter((t) => (t.length > 2 && !STOPWORDS.has(t)) || /^p\d+$/.test(t)))];
  if (terms.length === 0) return [];

  const scored = SITE_KNOWLEDGE.map((e) => {
    const normalize = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
    const title = normalize(e.title);
    const answer = normalize(e.answer);
    const keywordPhrases = e.keywords.map(normalize);
    const keywordTokens = new Set(keywordPhrases.flatMap((value) => value.split(" ").filter(Boolean)));
    const titleTokens = new Set(title.split(" ").filter(Boolean));
    const answerTokens = new Set(answer.split(" ").filter(Boolean));
    let score = 0;
    let matched = 0;
    for (const t of terms) {
      if (keywordTokens.has(t)) {
        score += 4;
        matched++;
      } else if (titleTokens.has(t)) {
        score += 2;
        matched++;
      } else if (answerTokens.has(t)) {
        score += 1;
        matched++;
      }
    }
    if (keywordPhrases.some((phrase) => phrase.includes(" ") && q.includes(phrase))) score += 8;
    if (title.includes(q)) score += 4;

    // A multi-word question must match most of its meaningful terms. A single
    // exact distinctive token (e.g. `citation`, `p8`) may stand alone.
    const required = terms.length === 1 ? 1 : Math.ceil(terms.length * 2 / 3);
    return { e, score, matched, required };
  })
    .filter((s) => s.matched >= s.required)
    .sort((a, b) => b.score - a.score || a.e.id.localeCompare(b.e.id));
  return scored.slice(0, limit).map((s) => s.e);
}
