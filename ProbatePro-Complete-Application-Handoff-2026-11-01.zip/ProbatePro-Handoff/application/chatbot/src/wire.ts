/**
 * NDJSON wire helpers. Kept separate from index.ts (which has boot side effects)
 * so it is unit-testable in isolation.
 */
import { redact } from "./redact.js";
import type { BotEvent } from "./tools.js";

/**
 * Serialize an NDJSON event for the wire. Everything is redacted at this sink
 * EXCEPT `session_rotated`, whose entire payload IS the fresh token being
 * relayed to the widget that already owns this session — redacting it would
 * store "app_session_id=[REDACTED]" and brick the session. It is never logged.
 */
export function serializeEvent(event: BotEvent): string {
  const json = JSON.stringify(event);
  return event.type === "session_rotated" ? json : redact(json);
}
