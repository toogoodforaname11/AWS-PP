/**
 * ProbatePro Companion Chatbot — embedded in the main app at /chatbot, with an
 * optional loopback-only standalone mode for isolated development.
 *
 * Binds 127.0.0.1 by default (security C-21). Auth on every route is the
 * user's forwarded app JWT (Bearer or same-host cookie ride-along); the bot
 * has no app credential of its own; the Forge key authorizes only the model call. CORS is an
 * exact-origin allowlist with credentials; every state-changing route requires
 * JSON content-type, so cross-site requests are preflight-gated (no CSRF).
 */
import express, { type Request, type Response, type NextFunction } from "express";
import rateLimit from "express-rate-limit";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { ENV, isAllowedOrigin, isAllowedBrowserOrigin, validateEnv } from "./env.js";
import { authenticate, edgeRateLimitKey, hasVerifiedRateLimitIdentity, type AuthedContext } from "./auth.js";
import { runChat, type AssistantResponseStyle, type PageContext } from "./agent.js";
import type { BotEvent, ToolCtx } from "./tools.js";
import {
  attachmentToBlocks,
  validateAttachmentBatch,
  ExtractError,
  type IncomingAttachment,
  type ContentBlock,
} from "./extract.js";
import * as store from "./db.js";
import { applyProposal, describeAppliedProposal, ProposalConflict } from "./proposals.js";
import { AppError, appMutation, appQuery } from "./appClient.js";
import { classifyChatFailure, signChatFailure } from "./failureReporting.js";
import { log, toSafeString } from "./redact.js";
import { serializeEvent } from "./wire.js";

type ProfileCompletionSettings = {
  lawyerName?: unknown;
  firmName?: unknown;
  firmAddress?: unknown;
  firmPhone?: unknown;
  firmEmail?: unknown;
};

function profileString(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

/**
 * The assistant may request a low-friction completion form, but it never writes
 * profile data itself. This event is calculated from the authenticated user's
 * canonical settings response and rendered by the browser, which uses the
 * existing owner-scoped settings.update mutation for the explicit save.
 */
export function profileCompletionEvent(
  settings: ProfileCompletionSettings | null | undefined,
  user: { name?: string | null; email?: string | null },
): Extract<BotEvent, { type: "profile_completion" }> | null {
  const lawyerName = profileString(settings?.lawyerName);
  const firmName = profileString(settings?.firmName);
  const firmEmail = profileString(settings?.firmEmail);
  const missingFields = [
    !lawyerName && "lawyerName",
    !firmName && "firmName",
    !firmEmail && "firmEmail",
  ].filter(Boolean) as Array<"lawyerName" | "firmName" | "firmEmail">;
  if (!missingFields.length) return null;

  return {
    type: "profile_completion",
    profile: {
      lawyerName: lawyerName || profileString(user.name),
      firmName,
      firmAddress: profileString(settings?.firmAddress),
      firmPhone: profileString(settings?.firmPhone),
      firmEmail: firmEmail || profileString(user.email),
    },
    // Firm name remains the established onboarding requirement. A user who has
    // already completed onboarding can still be offered this card when the
    // canonical lawyer name or firm email was never recorded, rather than being
    // asked to duplicate data that their signed-in identity already supplies.
    missingFields,
  };
}

async function emitProfileCompletionIfNeeded(ctx: ToolCtx, user: { name?: string | null; email?: string | null }): Promise<void> {
  try {
    const settings = await appQuery(ctx.session, "settings.get") as ProfileCompletionSettings;
    const event = profileCompletionEvent(settings, user);
    if (event) ctx.emit(event);
  } catch (error) {
    // Profile completion should never make a normal assistant turn unavailable.
    // The main application remains authoritative for profile settings and will
    // still surface onboarding/settings outside chat if the bridge is unavailable.
    if (!ctx.signal.aborted) log.warn("profile completion check unavailable", toSafeString(error));
  }
}

validateEnv();
store.pruneExpiredData();
const retentionSweep = setInterval(() => {
  try { store.pruneExpiredData(); } catch (error) { log.error("retention sweep failed", error); }
}, 6 * 60 * 60 * 1000);
retentionSweep.unref();

export const app = express();
app.disable("x-powered-by");

// ── CORS: exact-origin allowlist + credentials (never wildcard) ──────────────
// When embedded in the main app (CHATBOT_EMBEDDED=1), skip the chatbot's own
// CORS middleware — the parent Express app already handles CORS for all routes.
if (!process.env.CHATBOT_EMBEDDED) {
  app.use((req: Request, res: Response, next: NextFunction) => {
    const origin = req.headers.origin;
    if (origin && isAllowedOrigin(origin)) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Vary", "Origin");
      res.setHeader("Access-Control-Allow-Credentials", "true");
      res.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type, X-App-Origin");
      res.setHeader("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
      res.setHeader("Access-Control-Expose-Headers", "X-Rotated-Session");
    }
    if (req.method === "OPTIONS") {
      res.status(204).end();
      return;
    }
    next();
  });
}

// Edge controls run before authentication and, critically, before JSON parsing.
app.use((req, res, next) => {
  const requestId = randomUUID();
  (req as Request & { requestId: string }).requestId = requestId;
  res.setHeader("X-Request-ID", requestId);
  next();
});
export const CHATBOT_API_RATE_MAX = 120;
export const CHATBOT_CHAT_RATE_MAX = 20;
// SEC-2 — the two populations get SEPARATE budgets, because they can only be
// keyed by different things. `trust proxy` stays OFF on purpose (X-Forwarded-For
// is spoofable unless pinned to the exact hop count), so `req.ip` is the proxy
// hop and any IP key is one bucket for the whole deployment; the earlier design
// keyed everything through a synchronous identity peek, which was necessarily
// COLD before requireUser and dropped real users into that one shared bucket on
// their first request. Now:
//
//   1. an edge limiter runs BEFORE auth (and before express.json), keyed by IP
//      in a per-credential key space. It SKIPS both sessions cached after
//      auth.me and valid embedded sessions whose JWT signature the parent app
//      verified into res.locals — so forged traffic cannot consume even a new
//      embedded user's cold-session budget;
//   2. the real limits run AFTER requireUser, keyed by the authenticated user
//      id, which is known synchronously there — no IP fallback anywhere.
//
// The edge max gates only unauthenticated and not-yet-verified requests. In
// embedded operation a valid signed app session skips it even on the first
// request. Standalone mode is loopback-only and holds no app verification key;
// its first request remains cold. 120/min bounds auth.me amplification from
// junk tokens without exposing the deployed multi-user path to that bucket.
// Validation is ON except `xForwardedForHeader`, which fires on every proxied
// request precisely because we do not trust-proxy — that mismatch is deliberate.
export const CHATBOT_EDGE_RATE_MAX = 120;
const limiterOpts = {
  windowMs: 60_000,
  standardHeaders: true,
  legacyHeaders: false,
  validate: { xForwardedForHeader: false },
} as const;
app.use("/api", rateLimit({
  ...limiterOpts,
  keyGenerator: edgeRateLimitKey,
  // /health skips requireUser, so it never reaches the per-user limiter and must
  // stay on the edge limiter even for an established session — otherwise it is
  // the one route covered by no limiter at all.
  skip: (req: Request, res: Response) => req.path !== "/health" && hasVerifiedRateLimitIdentity(req, res),
  max: process.env.VITEST ? 10_000 : CHATBOT_EDGE_RATE_MAX,
}));

const MAX_JSON_BYTES = 28 * 1024 * 1024;
app.use("/api", (req, res, next) => {
  if (req.path === "/health") return next();
  return void requireUser(req, res, next);
});
// Per-user limits, mounted after requireUser so the key is the verified user id
// and still before express.json so an over-limit user never gets a 28 MB body
// parsed. /api/health is the one route that skips requireUser; it has no
// identity to key on and is covered by the edge limiter above.
const userLimiterOpts = {
  ...limiterOpts,
  keyGenerator: (req: Request) => `user:${(req as AuthedRequest).authed.user.id}`,
  skip: (req: Request) => !(req as Partial<AuthedRequest>).authed,
} as const;
app.use("/api", rateLimit({ ...userLimiterOpts, max: process.env.VITEST ? 10_000 : CHATBOT_API_RATE_MAX }));
app.use("/api/chat", rateLimit({ ...userLimiterOpts, max: process.env.VITEST ? 10_000 : CHATBOT_CHAT_RATE_MAX }));
app.use("/api", (req, res, next) => {
  const contentLength = Number(req.headers["content-length"] || 0);
  if (Number.isFinite(contentLength) && contentLength > MAX_JSON_BYTES) {
    res.status(413).json({ error: "payload_too_large" });
    return;
  }
  next();
});
app.use("/api", express.json({ limit: MAX_JSON_BYTES, type: "application/json" }));

// ── Auth middleware ──────────────────────────────────────────────────────────
type AuthedRequest = Request & { authed: AuthedContext; assistantResponseStyle: AssistantResponseStyle };

type AssistantSettings = {
  aiProcessorApprovedAt?: number | null;
  showChatbot?: boolean;
  assistantResponseStyle?: unknown;
};

function normalizeResponseStyle(value: unknown): AssistantResponseStyle {
  return value === "concise" || value === "detailed" || value === "balanced" ? value : "balanced";
}

async function getAssistantAccess(session: AuthedContext["session"]): Promise<{ approved: boolean; responseStyle: AssistantResponseStyle }> {
  const settings = (await appQuery(session, "settings.get")) as AssistantSettings;
  return {
    approved: settings.showChatbot !== false &&
      typeof settings.aiProcessorApprovedAt === "number" &&
      Number.isFinite(settings.aiProcessorApprovedAt) &&
      settings.aiProcessorApprovedAt > 0,
    responseStyle: normalizeResponseStyle(settings.assistantResponseStyle),
  };
}

async function requireUser(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    // BROWSER-ORIGIN GATE (ChatGPT finding 1) — this MUST run BEFORE authenticate().
    // authenticate() calls the app's auth.me under the victim's ride-along cookie,
    // and the app may ROTATE the session and return `X-Rotated-Session` (a fresh
    // full-lifetime JWT); `relay` would set that on OUR response header. The parent
    // CORS reflects a broad allowlist (`*.manus.*`, `*.run.app`) with credentials
    // AND exposes X-Rotated-Session, so relaying it to a disallowed cross-origin
    // caller leaks the rotated token → account takeover, even though the body is
    // 403'd (red-team HIGH). Rejecting cross-origin FIRST means no auth.me call, no
    // rotation, and no header for a disallowed origin. The parent CORS allowlist is
    // never the chatbot's trust boundary; the chatbot enforces its OWN same-origin/
    // exact check (isAllowedBrowserOrigin) on EVERY authenticated route. A cross-
    // origin browser request always carries an Origin header (same-origin GET /
    // server-to-server omit it; the cookie is SameSite=None so it rides along).
    const browserOrigin = req.headers.origin;
    if (typeof browserOrigin === "string" && !isAllowedBrowserOrigin(browserOrigin, req.headers.host, req.protocol)) {
      res.status(403).json({ error: "forbidden_origin" });
      return;
    }
    // Mutations additionally require a matching X-App-Origin (defense in depth):
    // the claimed app origin must itself be an allowed browser origin AND — when
    // the browser sent an Origin — equal it. A mutation that omits X-App-Origin is
    // rejected here even though it passed the gate above.
    if (req.method !== "GET") {
      const claimed = req.headers["x-app-origin"];
      const norm = (o: string) => o.replace(/\/+$/, "");
      if (
        typeof claimed !== "string" ||
        !isAllowedBrowserOrigin(claimed, req.headers.host, req.protocol) ||
        (typeof browserOrigin === "string" && norm(browserOrigin) !== norm(claimed))
      ) {
        res.status(403).json({ error: "forbidden_origin" });
        return;
      }
    }
    // Origin proven allowed — only now validate the session. Rotation here sets
    // X-Rotated-Session, which is safe to expose to an ALLOWED (same-origin) caller.
    const relay = (raw: string) => {
      if (!res.headersSent) res.setHeader("X-Rotated-Session", raw);
    };
    const authed = await authenticate(req, relay);
    if (!authed) {
      res.status(401).json({ error: "auth_expired" });
      return;
    }
    const assistantAccess = await getAssistantAccess(authed.session);
    if (!assistantAccess.approved) {
      res.status(403).json({ error: "assistant_processing_approval_required" });
      return;
    }
    (req as AuthedRequest).authed = authed;
    (req as AuthedRequest).assistantResponseStyle = assistantAccess.responseStyle;
    authed.session.onRotate = relay;
    next();
  } catch (err) {
    // Distinguish an app outage (infra) from an invalid token: an unreachable
    // app must degrade the widget to "offline" (render nothing), not
    // "session expired". authenticate() only throws on infra failure.
    if (err instanceof AppError) {
      res.status(503).json({ error: "app_unreachable" });
      return;
    }
    next(err);
  }
}

// ── Health + session ─────────────────────────────────────────────────────────
app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});

app.get("/api/session", (req, res) => {
  const { user } = (req as AuthedRequest).authed;
  res.json({ ok: true, name: user.name ?? "" });
});

// ── Conversations ────────────────────────────────────────────────────────────
app.get("/api/conversations", (req, res) => {
  const { user } = (req as AuthedRequest).authed;
  res.json(store.listConversations(user.id));
});

app.get("/api/conversations/latest", (req, res) => {
  const { user } = (req as AuthedRequest).authed;
  const scope = typeof req.query.scope === "string" ? req.query.scope : "global";
  const conversation = store.latestConversation(user.id, scope);
  if (!conversation) {
    res.json({ conversation: null, messages: [] });
    return;
  }
  res.json({
    conversation,
    messages: store.listMessages(user.id, conversation.id).map((m) => ({
      id: m.id,
      role: m.role,
      ...JSON.parse(m.content),
    })),
  });
});

// Load one conversation by id (History switch — registered AFTER /latest so
// "latest" is never captured as an :id).
app.get("/api/conversations/:id", (req, res) => {
  const { user } = (req as unknown as AuthedRequest).authed;
  const conversation = store.getConversation(user.id, req.params.id);
  if (!conversation) {
    res.status(404).json({ error: "not_found" });
    return;
  }
  res.json({
    conversation,
    messages: store.listMessages(user.id, conversation.id).map((m) => ({
      id: m.id,
      role: m.role,
      ...JSON.parse(m.content),
    })),
  });
});

app.post("/api/conversations", (req, res) => {
  const { user } = (req as AuthedRequest).authed;
  const scope = typeof req.body?.scope === "string" ? req.body.scope.slice(0, 64) : "global";
  res.json(store.createConversation(user.id, scope));
});

app.delete("/api/conversations/:id", (req, res) => {
  const { user } = (req as unknown as AuthedRequest).authed;
  const ok = store.deleteConversation(user.id, req.params.id);
  res.status(ok ? 200 : 404).json({ ok });
});

// Clear ALL conversations for the authenticated user.
app.delete("/api/conversations", (req, res) => {
  const { user } = (req as AuthedRequest).authed;
  const count = store.deleteAllConversations(user.id);
  res.json({ ok: true, deleted: count });
});

// Export a conversation as a Markdown transcript.
app.get("/api/conversations/:id/export", (req, res) => {
  const { user } = (req as unknown as AuthedRequest).authed;
  const conversation = store.getConversation(user.id, req.params.id);
  if (!conversation) {
    res.status(404).json({ error: "not_found" });
    return;
  }
  const messages = store.listMessages(user.id, conversation.id);
  const lines: string[] = [
    `# Chat Export — ${conversation.title || "Untitled"}`,
    ``,
    `**Scope:** ${conversation.scope}`,
    `**Date:** ${new Date(conversation.created_at).toISOString().slice(0, 10)}`,
    ``,
    `---`,
    ``,
  ];
  for (const m of messages) {
    const parsed = JSON.parse(m.content) as { text: string };
    const label = m.role === "user" ? "**You**" : "**Assistant**";
    lines.push(`${label}:`);
    lines.push(``);
    lines.push(parsed.text);
    lines.push(``);
    lines.push(`---`);
    lines.push(``);
  }
  res.setHeader("Content-Type", "text/markdown; charset=utf-8");
  res.setHeader(
    "Content-Disposition",
    `attachment; filename="chat-export-${conversation.id.slice(0, 8)}.md"`,
  );
  res.send(lines.join("\n"));
});

// ── Chat (NDJSON stream) ─────────────────────────────────────────────────────
// Per-user concurrency cap: the bot shares the app's per-IP rate bucket with
// the user's own browser (security C-14/C-24).
const activeStreams = new Map<number, number>();
let globalActiveStreams = 0;
const MAX_GLOBAL_STREAMS = 16;
const TURN_DEADLINE_MS = 90_000;
const attachmentSchema = z.object({
  name: z.string().min(1).max(255),
  mime: z.string().min(1).max(128),
  dataBase64: z.string().min(4).max(4 * Math.ceil((15 * 1024 * 1024) / 3)),
}).strict();
const chatBodySchema = z.object({
  content: z.string().max(20_000).default(""),
  // An opaque browser-generated key makes a safe retry resume the same user
  // turn instead of appending a duplicate message to the legal-file transcript.
  requestId: z.string().min(8).max(128).optional(),
  attachments: z.array(attachmentSchema).max(8).default([]),
  context: z.object({
    path: z.string().max(500).optional(),
    estateId: z.string().max(64).nullable().optional(),
    tab: z.string().max(64).nullable().optional(),
  }).strict().optional(),
  conversationId: z.string().max(64).optional(),
}).strict();

app.post("/api/chat", async (req, res) => {
  const authedRequest = req as AuthedRequest;
  const { user, session } = authedRequest.authed;
  const parsedBody = chatBodySchema.safeParse(req.body ?? {});
  if (!parsedBody.success) {
    res.status(400).json({ error: "invalid_request" });
    return;
  }
  const body = parsedBody.data;

  // RESERVE the concurrency slot SYNCHRONOUSLY with the check (finding B2). The
  // reservation used to happen after the async attachment extraction below, so
  // several uploads could all pass `running >= 2` before any incremented — a
  // TOCTOU that let a user exceed the cap. Reserve now; release() on EVERY exit
  // path (single-threaded, so check+increment is atomic).
  const running = activeStreams.get(user.id) ?? 0;
  if (running >= 2 || globalActiveStreams >= MAX_GLOBAL_STREAMS) {
    res.status(429).json({ error: "too_many_streams" });
    return;
  }
  activeStreams.set(user.id, running + 1);
  globalActiveStreams++;
  const turnAbort = new AbortController();
  const signal = turnAbort.signal;
  let deadlineExpired = false;
  const turnDeadline = setTimeout(() => {
    deadlineExpired = true;
    turnAbort.abort();
  }, TURN_DEADLINE_MS);
  turnDeadline.unref();
  session.signal = signal;
  let slotReleased = false;
  const releaseSlot = (): void => {
    if (slotReleased) return;
    slotReleased = true;
    clearTimeout(turnDeadline);
    const n = activeStreams.get(user.id) ?? 1;
    activeStreams.set(user.id, Math.max(0, n - 1));
    globalActiveStreams = Math.max(0, globalActiveStreams - 1);
  };

  // Register disconnect/Stop detection EARLY (finding B1/C3): a client that
  // disconnects during attachment extraction or DB setup below must still set
  // `aborted`, so the turn breaks immediately instead of running to completion.
  // res 'close' with the response not yet ended is the real disconnect signal
  // (req 'close' fires when the request BODY finishes — express.json already
  // consumed it — which would abort every turn immediately).
  res.on("close", () => {
    if (!res.writableEnded) turnAbort.abort();
  });

  const content = body.content;
  const attachments: IncomingAttachment[] = body.attachments;
  const pageContext: PageContext | undefined = body.context;

  if (!content.trim() && attachments.length === 0) {
    releaseSlot();
    res.status(400).json({ error: "empty_message" });
    return;
  }

  // Resolve/validate attachments BEFORE opening the stream so caps fail as JSON.
  let attachmentBlocks: ContentBlock[] = [];
  try {
    validateAttachmentBatch(attachments);
    for (const att of attachments) {
      attachmentBlocks.push(...(await attachmentToBlocks(att, signal)));
    }
  } catch (err) {
    releaseSlot();
    if (deadlineExpired) {
      res.status(504).json({ error: "turn_timeout" });
      return;
    }
    if (err instanceof ExtractError) {
      res.status(413).json({ error: "attachments", message: err.message });
      return;
    }
    // A corrupt file (e.g. mammoth on a malformed .docx) must NOT rethrow: an
    // async reject in an Express 4 handler is an unhandled rejection that kills
    // the process. Fail this one request instead.
    log.error("attachment parse failed:", err);
    res.status(422).json({
      error: "attachment_unreadable",
      message: "One of the files couldn't be read. Try a different file.",
    });
    return;
  }

  // Conversation + history setup touches SQLite (can throw SQLITE_BUSY under
  // WAL, disk errors) and sits OUTSIDE the streaming try/finally below. Guard it
  // (finding C1): an unguarded throw here would leak the reserved slot forever
  // (permanent 429 for this user) AND bubble as a process-killing unhandled
  // rejection — the same class the attachment/claim handlers already guard.
  let conversation: store.ConversationRow;
  let history: Array<{ role: "user" | "assistant"; text: string }>;
  let replayAssistant: store.MessageRow | null = null;
  try {
    const requestScope = pageContext?.estateId ? `estate:${pageContext.estateId}` : "global";
    const existing =
      typeof body.conversationId === "string"
        ? store.getConversation(user.id, body.conversationId)
        : undefined;
    // SCOPE GUARD (ChatGPT #2, server-side), narrowed 2026-08-03 per Nick: a
    // conversation now follows the user across the app, so estate↔global
    // navigation appends to the SAME conversation and the thread survives tab
    // switches. The one case that still forks is an estate-scoped conversation
    // receiving a turn from a DIFFERENT estate's page — appending there would
    // file estate B's tool results into estate A's conversation, which is the
    // contamination this guard exists to prevent. (Enforced server-side
    // regardless of a stale/forged conversationId; the client mirrors it.)
    const conflictingEstates =
      existing !== undefined &&
      existing.scope.startsWith("estate:") &&
      requestScope.startsWith("estate:") &&
      existing.scope !== requestScope;
    conversation =
      existing && !conflictingEstates ? existing : store.createConversation(user.id, requestScope);
    const storedMessages = store.listMessages(user.id, conversation.id);
    const existingIndex = body.requestId
      ? storedMessages.findIndex((message) => {
          if (message.role !== "user") return false;
          try {
            return (JSON.parse(message.content) as store.StoredMessageContent).requestId === body.requestId;
          } catch {
            return false;
          }
        })
      : -1;

    if (existingIndex >= 0) {
      const existing = storedMessages[existingIndex]!;
      const existingContent = JSON.parse(existing.content) as store.StoredMessageContent;
      // A request id is an idempotency key, never a client authority to substitute
      // a different message into an existing conversation.
      if (existingContent.text !== content) {
        releaseSlot();
        res.status(409).json({ error: "request_id_conflict" });
        return;
      }
      const next = storedMessages[existingIndex + 1];
      if (next?.role === "assistant") replayAssistant = next;
      // runChat appends `userText` itself, so omit the persisted retry turn from
      // history when a prior attempt ended before a saved assistant reply.
      history = storedMessages
        .slice(0, existingIndex)
        .map((message) => ({ role: message.role, text: (JSON.parse(message.content) as { text: string }).text }));
    } else {
      history = storedMessages
        .map((message) => ({ role: message.role, text: (JSON.parse(message.content) as { text: string }).text }));
      store.appendMessage(conversation.id, "user", {
        text: content,
        requestId: body.requestId,
        attachments: attachments.map((a) => ({
          name: a.name.slice(0, 120),
          mime: a.mime,
          size: Math.floor((a.dataBase64.length * 3) / 4),
        })),
      });
    }
    store.touchConversation(user.id, conversation.id, content.slice(0, 60) || "File drop");
  } catch (err) {
    releaseSlot();
    log.error("chat setup failed:", err);
    res.status(500).json({ error: "internal" });
    return;
  }

  const emit = (event: BotEvent): void => {
    if (signal.aborted) return;
    res.write(serializeEvent(event) + "\n");
  };
  // Streaming route: rotation must ride the stream (headers are already sent).
  session.onRotate = (raw) => emit({ type: "session_rotated", value: raw });

  const ctx: ToolCtx = {
    session,
    userId: user.id,
    conversationId: conversation.id,
    emit,
    docMap: new Map(),
    trace: [],
    signal,
    currentEstateId: pageContext?.estateId ?? undefined,
    knownEstateIds: new Set(pageContext?.estateId ? [pageContext.estateId] : []),
  };

  // Opening the NDJSON stream is INSIDE the try whose finally releases the slot,
  // so even a flushHeaders throw on a dead socket cannot leak the reservation.
  try {
    res.status(200);
    res.setHeader("Content-Type", "application/x-ndjson; charset=utf-8");
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("X-Accel-Buffering", "no");
    res.flushHeaders();

    // Tell the client its conversation id up front (Kimi #6): if the stream dies
    // mid-turn (before `done`), the widget has already adopted the id, so the
    // next send continues this conversation instead of forking a new one.
    emit({ type: "conversation", conversationId: conversation.id });

    // Resolve profile completeness only from the signed-in user's canonical
    // settings record. This is intentionally separate from model output: the
    // client renders a form and performs the explicit protected mutation.
    await emitProfileCompletionIfNeeded(ctx, user);

    // A response may have been persisted just before a proxy or mobile network
    // dropped its terminal event. Replay that recorded reply exactly rather than
    // calling the model again or creating a duplicate turn.
    if (replayAssistant) {
      const replay = JSON.parse(replayAssistant.content) as store.StoredMessageContent;
      if (replay.text) emit({ type: "text_delta", text: replay.text });
      emit({ type: "done", conversationId: conversation.id, messageId: replayAssistant.id });
      return;
    }

    const assistantText = await runChat({
      ctx,
      history,
      userText: content,
      attachmentBlocks,
      pageContext,
      userProfile: { name: user.name, email: user.email },
      responseStyle: authedRequest.assistantResponseStyle,
      signal,
    });
    // Finding #8: the user may have DELETED this conversation mid-stream (the
    // client aborts on delete, but the current turn still finishes here). Do NOT
    // re-insert the assistant turn into a now-deleted conversation — that would
    // leave an unreachable, undeletable estate-PII row (a retention violation).
    // The finally still releases the slot and ends the response.
    if (!store.getConversation(user.id, conversation.id)) return;
    const saved = store.appendMessage(conversation.id, "assistant", {
      text: assistantText,
      toolTrace: ctx.trace,
    });
    store.touchConversation(user.id, conversation.id);
    emit({ type: "done", conversationId: conversation.id, messageId: saved.id });
  } catch (err) {
    // Stop/disconnect intentionally aborts the upstream fetch and emits nothing.
    // Any real Forge/tool failure emits an error event and, critically, does not
    // append a fake assistant message or a `done` event to conversation history.
    if (deadlineExpired) {
      const occurredAt = Date.now();
      const proof = signChatFailure({ operation: "chat_turn", errorCode: "turn_timeout", occurredAt });
      if (proof) void appMutation(session, "failureReports.recordChatbot", { operation: "chat_turn", errorCode: "turn_timeout", occurredAt, proof }).catch((reportError) => log.warn("chat failure report not recorded:", reportError));
      emit({ type: "error", message: "The assistant turn timed out. Please try again or use a narrower request.", retryable: true, retryAfterMs: 750 });
    } else if (!signal.aborted) {
      log.error("chat turn failed:", err);
      const occurredAt = Date.now();
      const errorCode = classifyChatFailure(err);
      const proof = signChatFailure({ operation: "chat_turn", errorCode, occurredAt });
      if (proof) void appMutation(session, "failureReports.recordChatbot", { operation: "chat_turn", errorCode, occurredAt, proof }).catch((reportError) => log.warn("chat failure report not recorded:", reportError));
      emit({ type: "error", message: "The assistant could not complete this request. Retrying once is safe.", retryable: true, retryAfterMs: 500 });
    }
  } finally {
    releaseSlot();
    res.end();
  }
});

// ── Proposals: user-clicked Apply / Dismiss (never model tools) ──────────────

// Pending proposals for re-hydration after reload/navigation (finding #4).
app.get("/api/proposals", (req, res) => {
  const { user } = (req as AuthedRequest).authed;
  const estateId = typeof req.query.estateId === "string" ? req.query.estateId : undefined;
  res.json(
    store.listPendingProposals(user.id, estateId).map((p) => ({
      proposalId: p.id,
      estateId: p.estate_id,
      kind: p.kind,
      diff: JSON.parse(p.diff),
      status: "pending" as const,
    })),
  );
});

app.post("/api/proposals/:id/apply", async (req, res, next) => {
  const { user, session } = (req as unknown as AuthedRequest).authed;
  const proposal = store.getProposal(user.id, req.params.id);
  if (!proposal) {
    res.status(404).json({ error: "not_found" });
    return;
  }
  // Atomic claim (finding #2): exactly one caller flips pending->applying; a
  // concurrent click, retry, or lost-response replay gets false and stops here,
  // so the app write runs at most once. Replaces the racy check-then-act that
  // let two requests both pass a `status === 'pending'` read across the await.
  // Guarded on its own: a claim-time throw (SQLITE_BUSY under WAL, disk error)
  // must return 500 — NOT bubble as an unhandled rejection that kills the
  // process (this handler is async; see the attachment note above). The row is
  // untouched on a throw (still pending), so the user can retry.
  let claimed: boolean;
  try {
    claimed = store.claimProposal(user.id, proposal.id);
  } catch (err) {
    log.error("proposal claim failed:", err);
    res.status(500).json({ error: "claim_failed", message: "Couldn't start applying — please try again." });
    return;
  }
  if (!claimed) {
    const fresh = store.getProposal(user.id, proposal.id);
    res.status(409).json({ error: "not_pending", status: fresh?.status ?? "gone" });
    return;
  }
  try {
    const { invalidate } = await applyProposal(user.id, session, proposal);
    store.resolveProposal(user.id, proposal.id, "applied");
    // Close the loop for the ASSISTANT and the transcript. Nothing else tells
    // this service the user clicked Apply, so the next turn's history would not
    // contain it and the model answers "I did not apply any changes" to someone
    // who just did. The same string goes back to the widget so the chat shows it
    // immediately rather than only after a reload.
    const applied = describeAppliedProposal(proposal);
    if (proposal.conversation_id) {
      try {
        store.appendMessage(proposal.conversation_id, "assistant", { text: applied });
      } catch (err) {
        // The write already succeeded and the user confirmed it — never fail the
        // response over a transcript note.
        log.error("apply note failed:", err);
      }
    }
    res.json({ ok: true, invalidate, applied });
  } catch (err) {
    if (err instanceof ProposalConflict) {
      // The estate changed since propose time (finding #3) — do NOT overwrite.
      const message = `The estate changed since this was proposed (${err.fields.join(", ")}). Ask the assistant to re-read the estate and propose again.`;
      store.resolveProposal(user.id, proposal.id, "failed", message);
      store.auditEvent("bot_write_conflict", user.id, proposal.estate_id, {
        proposalId: proposal.id,
        kind: proposal.kind,
        fields: err.fields,
      });
      res.status(409).json({ error: "conflict", message });
      return;
    }
    if (err instanceof AppError) {
      store.resolveProposal(user.id, proposal.id, "failed", err.message);
      store.auditEvent("bot_write_failed", user.id, proposal.estate_id, {
        proposalId: proposal.id,
        kind: proposal.kind,
        code: err.code,
      });
      res.status(502).json({ error: "apply_failed", code: err.code, message: err.message });
      return;
    }
    // Unknown error after a successful claim — mark failed so the row is not
    // stranded in 'applying', then defer to the error handler.
    store.resolveProposal(user.id, proposal.id, "failed", "internal error during apply");
    next(err);
  }
});

app.post("/api/proposals/:id/dismiss", (req, res) => {
  const { user } = (req as unknown as AuthedRequest).authed;
  const proposal = store.getProposal(user.id, req.params.id);
  if (!proposal) {
    res.status(404).json({ error: "not_found" });
    return;
  }
  // CAS (ChatGPT #8): only a still-pending proposal is dismissed. If it was
  // already claimed for Apply / applied / failed, return 409 so the client does
  // NOT show a false "Rejected".
  if (!store.dismissProposal(user.id, proposal.id)) {
    const fresh = store.getProposal(user.id, proposal.id);
    res.status(409).json({ error: "not_pending", status: fresh?.status ?? "gone" });
    return;
  }
  store.auditEvent("bot_write_rejected", user.id, proposal.estate_id, {
    proposalId: proposal.id,
    kind: proposal.kind,
  });
  res.json({ ok: true });
});

// ── Feedback ─────────────────────────────────────────────────────────────────
app.post("/api/feedback", (req: Request, res: Response) => {
  const { user } = (req as AuthedRequest).authed;
  const { messageId, conversationId, rating, comment } = req.body ?? {};
  if (!messageId || !conversationId || !rating) {
    res.status(400).json({ error: "missing_fields" });
    return;
  }
  if (rating !== "up" && rating !== "down") {
    res.status(400).json({ error: "invalid_rating" });
    return;
  }
  const safeComment = typeof comment === "string" ? comment.slice(0, 500) : "";
  try {
    store.upsertFeedback(user.id, messageId, conversationId, rating, safeComment);
    res.json({ ok: true });
  } catch (err: unknown) {
    if (err instanceof Error && err.message === "forbidden") {
      res.status(403).json({ error: "forbidden" });
      return;
    }
    throw err;
  }
});

app.delete("/api/feedback/:messageId", (req: Request, res: Response) => {
  const { user } = (req as AuthedRequest).authed;
  const { messageId } = req.params;
  store.removeFeedback(user.id, messageId);
  res.json({ ok: true });
});

app.get("/api/feedback/:conversationId", (req: Request, res: Response) => {
  const { user } = (req as AuthedRequest).authed;
  const { conversationId } = req.params;
  const feedback = store.listFeedback(user.id, conversationId);
  res.json({ feedback });
});

// ── Redacting error handler ──────────────────────────────────────────────────
app.use((err: unknown, req: Request, res: Response, _next: NextFunction) => {
  const requestId = (req as Request & { requestId?: string }).requestId || "unknown";
  log.error("unhandled request", { requestId, error: toSafeString(err) });
  if (res.headersSent) {
    res.end();
    return;
  }
  // body-parser rejects an over-limit body before our attachment caps run —
  // give the same friendly size guidance the caps do.
  if ((err as { type?: string })?.type === "entity.too.large") {
    res.status(413).json({
      error: "attachments",
      message: "The upload is too large. Send fewer or smaller files per message.",
    });
    return;
  }
  res.status(500).json({ error: "internal", requestId });
});

// Don't bind a port when imported by the test runner or embedded in the main
// server — route tests start the exported `app` on an ephemeral port themselves,
// and the main server mounts it as sub-router at /chatbot.
if (!process.env.VITEST && !process.env.CHATBOT_EMBEDDED) {
  app.listen(ENV.port, ENV.host, () => {
    log.info(`chatbot service listening on http://${ENV.host}:${ENV.port} (model: ${ENV.model})`);
    log.info(`app base: ${ENV.appBaseUrl}`);
  });
}
