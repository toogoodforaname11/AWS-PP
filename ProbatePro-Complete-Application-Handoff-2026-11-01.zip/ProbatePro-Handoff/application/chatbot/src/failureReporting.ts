import { createHmac } from "node:crypto";

export type ChatFailureCode = "turn_timeout" | "provider_failure" | "app_bridge_failure" | "unexpected_failure";

export function classifyChatFailure(error: unknown): ChatFailureCode {
  const name = error instanceof Error ? error.name.toLowerCase() : "";
  if (name.includes("forge") || name.includes("provider")) return "provider_failure";
  if (name.includes("app") || name.includes("gateway")) return "app_bridge_failure";
  return "unexpected_failure";
}

export function signChatFailure(input: { operation: "chat_turn"; errorCode: ChatFailureCode; occurredAt: number }): string | null {
  const encoded = process.env.PROBATE_FIELD_ENCRYPTION_KEY;
  if (!encoded) return null;
  const key = Buffer.from(encoded, "base64");
  if (key.byteLength !== 32) return null;
  return createHmac("sha256", key)
    .update(`probatepro-chat-failure-v1|${input.operation}|${input.errorCode}|${input.occurredAt}`)
    .digest("base64url");
}
