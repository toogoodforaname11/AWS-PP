/**
 * Per-request authentication for the bot service.
 *
 * The bot holds NO JWT_SECRET by design — the app is the verification oracle.
 * The widget forwards the user's app session JWT (Authorization: Bearer, or the
 * app_session_id cookie riding along on same-host requests); we validate it by
 * calling the app's `auth.me` under that token and cache the resulting identity
 * for 5 minutes keyed by sha256(token). Client-supplied user IDs are never
 * trusted anywhere in this service.
 */
import crypto from "node:crypto";
import type { Request, Response } from "express";
import { ipKeyGenerator } from "express-rate-limit";
import { ENV } from "./env.js";
import { appQuery, type AppSession } from "./appClient.js";

export type AppUser = {
  id: number;
  name: string | null;
  email: string | null;
  role?: string;
};

export type AuthedContext = {
  user: AppUser;
  session: AppSession;
};

const COOKIE_NAME = "app_session_id";

// Must match server/chatbot.ts. Kept local so this isolated package never
// imports the app tree; a root regression test pins the bridge contract.
export const EMBEDDED_CHATBOT_VERIFIED_SESSION_LOCAL = "probateproChatbotVerifiedSession";

export function extractToken(req: Request): string | null {
  const auth = req.headers.authorization;
  if (typeof auth === "string" && auth.startsWith("Bearer ")) {
    const token = auth.slice(7).trim();
    if (token) return token;
  }
  // Cookie ride-along: RFC 6265 cookies are host-scoped (ports ignored), so the
  // app's localhost cookie reaches this service in dev with credentials:"include".
  const cookieHeader = req.headers.cookie;
  if (typeof cookieHeader === "string") {
    for (const part of cookieHeader.split(";")) {
      const trimmed = part.trim();
      if (trimmed.startsWith(`${COOKIE_NAME}=`)) {
        const token = trimmed.slice(COOKIE_NAME.length + 1);
        if (token) return decodeURIComponent(token);
      }
    }
  }
  return null;
}

/**
 * The app base URL the bot forwards the user's JWT to.
 *
 * SECURITY (finding #1): this is the operator-configured `APP_BASE_URL` ONLY —
 * NEVER a caller-supplied value. A previous version let a validated X-App-Origin
 * become the destination; because the default origin allowlist matched every
 * localhost port, a malicious local page could set `X-App-Origin:
 * http://127.0.0.1:9999` and the bot would ship the user's Bearer JWT there
 * during the auth.me probe (cookies are host-scoped, so the cookie rode along).
 * The credential destination and the CORS/CSRF origin check are now fully
 * decoupled: X-App-Origin governs "which browser origin may call me", never
 * "where the user's credential goes".
 */
export function resolveAppBase(_req: Request): string {
  return ENV.appBaseUrl;
}

// Identity cache: sha256(token) -> user, 5-minute TTL, single-flighted.
// `user` is the LAST VERIFIED identity for this token, filled in once the
// promise settles, so synchronous callers (hasVerifiedIdentity) can peek
// without awaiting. It is deliberately CARRIED FORWARD onto the replacement
// entry when the TTL lapses and re-verification starts: `at` is the
// re-verification clock, not an identity expiry, so an actively-used session
// keeps a warm peek across the round trip instead of briefly (and then, every
// 5 minutes, repeatedly) looking unauthenticated to the edge limiter. The
// re-verification itself is unchanged — auth.me still runs on every lapse, and
// a token that fails is deleted outright, so the peek goes cold with it.
type CacheEntry = { promise: Promise<AppUser | null>; at: number; user?: AppUser | null };
const cache = new Map<string, CacheEntry>();
const TTL_MS = 5 * 60 * 1000;

function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

/**
 * Returns the authed context, or null when the token is genuinely invalid.
 * THROWS (AppError) when the app itself is unreachable — the caller maps that
 * to 503 so the widget degrades to "offline" rather than "session expired".
 */
export async function authenticate(
  req: Request,
  onRotate?: (rawHeaderValue: string) => void,
): Promise<AuthedContext | null> {
  const token = extractToken(req);
  if (!token) return null;

  const session: AppSession = { token, baseUrl: resolveAppBase(req), onRotate };
  const key = hashToken(token);
  const now = Date.now();

  let entry = cache.get(key);
  if (!entry || now - entry.at > TTL_MS) {
    const lastVerified = entry?.user;
    entry = {
      at: now,
      user: lastVerified,
      // auth.me is public and returns ctx.user (null on a bad/expired token).
      // appQuery THROWS on infra failure (network/5xx) — we let that reject so
      // it is never cached as "no user" and surfaces as an outage, not a logout.
      promise: (async () => {
        const user = (await appQuery(session, "auth.me")) as AppUser | null;
        return user && typeof user.id === "number" ? user : null;
      })(),
    };
    cache.set(key, entry);
    if (cache.size > 500) {
      for (const [k, v] of cache) if (now - v.at > TTL_MS) cache.delete(k);
    }
  }

  let user: AppUser | null;
  try {
    user = await entry.promise;
    entry.user = user;
  } catch (err) {
    cache.delete(key); // infra failure — don't cache it; propagate as outage
    throw err;
  }
  if (!user) {
    cache.delete(key); // a dead token stays dead — don't cache the failure
    return null;
  }
  return { user, session };
}

/**
 * SEC-2: synchronous peek — does this request carry a token the app has
 * ALREADY verified? Only a token that actually passed auth.me is ever in the
 * cache, so a forged/rotating token can never answer true. Established sessions
 * use this to SKIP the pre-auth edge limiter entirely; their real limits are
 * enforced per user id after requireUser, where the identity is known for
 * certain. That split is what stops unauthenticated traffic from consuming an
 * authenticated user's budget.
 *
 * Deliberately NOT gated on TTL_MS. TTL_MS is the re-authorization interval:
 * `at` is refreshed only inside authenticate(), which runs AFTER this limiter.
 * Gating the peek on it put every established session back through the shared
 * pre-auth bucket once per TTL — and a 429 there skips authenticate(), so `at`
 * never refreshes and a sustained token-bearing flood locks every user out
 * permanently. This peek only ever selects a rate-limit bucket, never an
 * authorization outcome: authenticate() still re-verifies on its own TTL, and a
 * token that fails re-verification is deleted from the cache (:130, :134), so a
 * revoked token loses the skip on its very next request.
 */
export function hasVerifiedIdentity(req: Request): boolean {
  const token = extractToken(req);
  if (!token) return false;
  const entry = cache.get(hashToken(token));
  return !!entry && !!entry.user;
}

/**
 * Rate-limit identity may come from either the chatbot's completed auth.me
 * cache or the parent app's local JWT-signature verification. The latter fixes
 * the first request of a valid embedded session: it cannot be starved by a
 * rotating-forgery flood in the shared `cold:` bucket. It is only a limiter
 * hint; requireUser still performs the authoritative app-backed authentication.
 */
export function hasVerifiedRateLimitIdentity(req: Request, res: Response): boolean {
  const embeddedSubject = res.locals?.[EMBEDDED_CHATBOT_VERIFIED_SESSION_LOCAL];
  return (typeof embeddedSubject === "string" && embeddedSubject.length > 0) || hasVerifiedIdentity(req);
}

/**
 * SEC-2: bucket key for the PRE-AUTH edge limiter. Behind the platform proxy
 * with no `trust proxy` (deliberate — X-Forwarded-For is spoofable unless
 * pinned to the exact hop count), `req.ip` is the proxy hop, so this is one
 * bucket per key space for the whole deployment. It is therefore split into
 * SEPARATE key spaces by credential presence: a tokenless flood — the cheapest
 * attack, since the limiter runs before express.json so neither a valid body
 * nor a token is needed — fills `anon:` and can no longer 429 the first,
 * still-cold standalone request, which lands in `cold:`. In the shipped
 * embedded mode, the parent app locally verifies a valid signed JWT into
 * res.locals and that request skips this limiter before the cache is warm.
 *
 * Deliberately NOT keyed by the token: rotating forged tokens would mint fresh
 * buckets and bypass the limiter entirely.
 */
export function edgeRateLimitKey(req: Request): string {
  const ip = ipKeyGenerator(req.ip ?? "");
  return extractToken(req) ? `cold:${ip}` : `anon:${ip}`;
}
