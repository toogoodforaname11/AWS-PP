import { parentPort, workerData } from "node:worker_threads";
import mammoth from "mammoth";
import pdfParse from "pdf-parse/lib/pdf-parse.js";

type Job = { kind: "pdf" | "docx"; bytes: ArrayBuffer };

async function main(job: Job): Promise<string> {
  const buffer = Buffer.from(job.bytes);
  if (job.kind === "pdf") return (await pdfParse(buffer)).text;
  return (await mammoth.extractRawText({ buffer })).value;
}

main(workerData as Job).then(
  (text) => parentPort?.postMessage({ ok: true, text }),
  () => parentPort?.postMessage({ ok: false }),
);

