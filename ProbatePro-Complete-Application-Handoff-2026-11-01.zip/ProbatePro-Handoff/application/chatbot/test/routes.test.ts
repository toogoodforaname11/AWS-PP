/**
 * Route-wiring coverage (Kimi #9) — the Express layer had ZERO tests. Starts the
 * real `app` on an ephemeral port; the bot's own outbound `auth.me` call is
 * mocked (bot -> app), while the test drives real HTTP at the bot. Covers auth
 * 401, the CSRF 403 on a mutation without X-App-Origin, and the
 * /conversations/latest-vs-/:id route ordering.
 */
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import superjson from "superjson";
import type { Server } from "node:http";

let server: Server;
let base: string;
const realFetch = globalThis.fetch;
let forgeMode: "failure" | "stream" | null = null;
let assistantApproved = true;
let canonicalFirmName = "";
let canonicalLawyerName = "";
let canonicalFirmEmail = "";
let lastForgeRequest: Record<string, unknown> | null = null;

function forgeResponse(): Response {
  if (forgeMode === "failure") return new Response(JSON.stringify({ error: "boom" }), { status: 500 });
  const body = [
    `data: ${JSON.stringify({ choices: [{ delta: { content: "First " } }] })}\n\n`,
    `data: ${JSON.stringify({ choices: [{ delta: { content: "second." }, finish_reason: "stop" }] })}\n\n`,
    "data: [DONE]\n\n",
  ].join("");
  return new Response(body, { status: 200, headers: { "content-type": "text/event-stream" } });
}

const authMe = () =>
  ({
    status: 200,
    ok: true,
    headers: { get: () => null },
    text: async () =>
      JSON.stringify({ result: { data: superjson.serialize({ id: 1, name: "Test", email: "test@probate-pro.com" }) } }),
  }) as any;

const approvedSettings = () =>
  ({
    status: 200,
    ok: true,
    headers: { get: () => null },
    text: async () => JSON.stringify({ result: { data: superjson.serialize({ aiProcessorApprovedAt: assistantApproved ? Date.now() : 0, showChatbot: assistantApproved, lawyerName: canonicalLawyerName, firmName: canonicalFirmName, firmAddress: "", firmPhone: "", firmEmail: canonicalFirmEmail }) } }),
  }) as any;

beforeAll(async () => {
  process.env.BUILT_IN_FORGE_API_KEY = "test-forge-key";
  process.env.BUILT_IN_FORGE_API_URL = "https://forge.test";
  process.env.APP_BASE_URL = "http://app.test";
  process.env.CHATBOT_DB_PATH = "./data/route-test.db";
  // Route the bot's outbound auth.me (bot -> app) to a mock; everything else
  // (the test's own requests to the bot) uses the real fetch.
  vi.stubGlobal("fetch", (url: any, init?: any) =>
    String(url).includes("app.test")
      ? Promise.resolve(String(url).includes("settings.get") ? approvedSettings() : authMe())
      : String(url).includes("forge.test") && forgeMode
        ? (lastForgeRequest = JSON.parse(String(init?.body ?? "{}")), Promise.resolve(forgeResponse()))
        : realFetch(url, init),
  );
  const mod = await import("../src/index.js");
  server = await new Promise<Server>((res) => {
    const s = mod.app.listen(0, "127.0.0.1", () => res(s));
  });
  const addr = server.address();
  base = `http://127.0.0.1:${typeof addr === "object" && addr ? addr.port : 0}`;
});

afterAll(() => {
  vi.unstubAllGlobals();
  server?.close();
});

beforeEach(() => {
  assistantApproved = true;
  canonicalFirmName = "";
  canonicalLawyerName = "";
  canonicalFirmEmail = "";
  lastForgeRequest = null;
});

const AUTH = { authorization: "Bearer valid.jwt.token" };

describe("bot HTTP routes", () => {
  it("GET /api/health -> 200 (no auth)", async () => {
    const r = await realFetch(`${base}/api/health`);
    expect(r.status).toBe(200);
    expect(await r.json()).toEqual({ ok: true });
  });

  it("GET /api/session without a token -> 401", async () => {
    const r = await realFetch(`${base}/api/session`);
    expect(r.status).toBe(401);
  });

  it("GET /api/session with a valid token but no recorded approval -> 403", async () => {
    assistantApproved = false;
    const r = await realFetch(`${base}/api/session`, { headers: AUTH });
    expect(r.status).toBe(403);
    expect(await r.json()).toMatchObject({ error: "assistant_processing_approval_required" });
  });

  it("GET /api/session with a valid token -> 200", async () => {
    const r = await realFetch(`${base}/api/session`, { headers: AUTH });
    expect(r.status).toBe(200);
    expect((await r.json()).name).toBe("Test");
  });

  it("POST apply without X-App-Origin -> 403 (CSRF guard)", async () => {
    const r = await realFetch(`${base}/api/proposals/x/apply`, {
      method: "POST",
      headers: { ...AUTH, "content-type": "application/json" },
      body: "{}",
    });
    expect(r.status).toBe(403);
  });

  it("route ordering: /conversations/latest is not captured by /:id", async () => {
    const latest = await realFetch(`${base}/api/conversations/latest?scope=global`, { headers: AUTH });
    expect(latest.status).toBe(200);
    expect(await latest.json()).toHaveProperty("messages");
    // A real (uuid-shaped) id that doesn't exist for this user -> 404 (proves /:id works too).
    const byId = await realFetch(`${base}/api/conversations/no-such-id`, { headers: AUTH });
    expect(byId.status).toBe(404);
  });

  it("authenticates before attempting to parse an untrusted JSON body", async () => {
    const r = await realFetch(`${base}/api/chat`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-app-origin": "https://probate-pro.com" },
      body: "{ malformed JSON that must not be parsed first",
    });
    expect(r.status).toBe(401);
    expect(r.headers.get("x-request-id")).toMatch(/^[0-9a-f-]{36}$/i);
  });

  it("emits an error but does not persist a fabricated assistant turn when Forge fails", async () => {
    forgeMode = "failure";
    try {
      const response = await realFetch(`${base}/api/chat`, {
        method: "POST",
        headers: {
          ...AUTH,
          "content-type": "application/json",
          "x-app-origin": "https://probate-pro.com",
        },
        body: JSON.stringify({ content: "trigger a backend failure", context: { path: "/" } }),
      });
      expect(response.status).toBe(200);
      const events = (await response.text())
        .trim()
        .split("\n")
        .filter(Boolean)
        .map((line) => JSON.parse(line));
      expect(events.some((event) => event.type === "error")).toBe(true);
      expect(events.some((event) => event.type === "done")).toBe(false);

      const conversationId = events.find((event) => event.type === "conversation")?.conversationId;
      expect(conversationId).toBeTruthy();
      const stored = await realFetch(`${base}/api/conversations/${conversationId}`, { headers: AUTH });
      expect(stored.status).toBe(200);
      const payload = await stored.json();
      expect(payload.messages.map((message: { role: string }) => message.role)).toEqual(["user"]);
    } finally {
      forgeMode = null;
    }
  });

  it("streams Forge deltas through NDJSON and persists only the completed assistant turn", async () => {
    forgeMode = "stream";
    try {
      const response = await realFetch(`${base}/api/chat`, {
        method: "POST",
        headers: {
          ...AUTH,
          "content-type": "application/json",
          "x-app-origin": "https://probate-pro.com",
        },
        body: JSON.stringify({ content: "stream a response", context: { path: "/" } }),
      });
      const events = (await response.text()).trim().split("\n").filter(Boolean).map((line) => JSON.parse(line));
      expect(events.filter((event) => event.type === "text_delta").map((event) => event.text))
        .toEqual(["First ", "second."]);
      expect(events.some((event) => event.type === "done")).toBe(true);

      const conversationId = events.find((event) => event.type === "conversation")?.conversationId;
      const stored = await realFetch(`${base}/api/conversations/${conversationId}`, { headers: AUTH });
      const payload = await stored.json();
      expect(payload.messages.map((message: { role: string; text: string }) => [message.role, message.text]))
        .toEqual([["user", "stream a response"], ["assistant", "First second."]]);
    } finally {
      forgeMode = null;
    }
  });

  it("emits a profile-completion event only when the authenticated user's canonical firm profile is incomplete", async () => {
    forgeMode = "stream";
    const post = async (content: string) => {
      const response = await realFetch(`${base}/api/chat`, {
        method: "POST",
        headers: { ...AUTH, "content-type": "application/json", "x-app-origin": "https://probate-pro.com" },
        body: JSON.stringify({ content, context: { path: "/" } }),
      });
      return (await response.text()).trim().split("\n").filter(Boolean).map((line) => JSON.parse(line));
    };
    try {
      const missingEvents = await post("profile needs completion");
      expect(missingEvents.find((event) => event.type === "profile_completion")).toMatchObject({
        missingFields: ["lawyerName", "firmName", "firmEmail"],
        profile: { lawyerName: "Test", firmName: "", firmEmail: "test@probate-pro.com" },
      });

      canonicalFirmName = "Example Law LLP";
      const partialEvents = await post("profile still needs saved professional details");
      expect(partialEvents.find((event) => event.type === "profile_completion")).toMatchObject({
        missingFields: ["lawyerName", "firmEmail"],
        profile: { lawyerName: "Test", firmName: "Example Law LLP", firmEmail: "test@probate-pro.com" },
      });

      canonicalLawyerName = "Test";
      canonicalFirmEmail = "test@probate-pro.com";
      const completeEvents = await post("profile is complete");
      expect(completeEvents.some((event) => event.type === "profile_completion")).toBe(false);
      // The check takes no model-controlled identity or write input; it only
      // reads settings.get through the signed-in user's own forwarded session.
      expect(completeEvents.some((event) => event.type === "done")).toBe(true);
    } finally {
      forgeMode = null;
    }
  });

  it("passes the authenticated user profile to the assistant model during a normal chat session", async () => {
    forgeMode = "stream";
    try {
      const response = await realFetch(`${base}/api/chat`, {
        method: "POST",
        headers: {
          ...AUTH,
          "content-type": "application/json",
          "x-app-origin": "https://probate-pro.com",
        },
        body: JSON.stringify({ content: "Who am I signed in as?", context: { path: "/" } }),
      });
      expect(response.status).toBe(200);
      await response.text();
      const messages = lastForgeRequest?.messages as Array<{ role?: string; content?: unknown }>;
      const system = String(messages.find((message) => message.role === "system")?.content ?? "");
      expect(system).toContain("name: Test");
      expect(system).toContain("email: test@probate-pro.com");
      expect(system).toContain("verified identity attributes");
    } finally {
      forgeMode = null;
    }
  });

  it("reuses a retry request id without duplicating the user turn after a failed response", async () => {
    const post = (body: unknown) =>
      realFetch(`${base}/api/chat`, {
        method: "POST",
        headers: { ...AUTH, "content-type": "application/json", "x-app-origin": "https://probate-pro.com" },
        body: JSON.stringify(body),
      });
    const body = {
      requestId: "retry-turn-0001",
      content: "resume the interrupted turn",
      context: { path: "/" },
    };
    forgeMode = "failure";
    try {
      const failedEvents = (await (await post(body)).text())
        .trim()
        .split("\n")
        .filter(Boolean)
        .map((line) => JSON.parse(line));
      const conversationId = failedEvents.find((event) => event.type === "conversation")?.conversationId as string;
      expect(conversationId).toBeTruthy();
      expect(failedEvents.some((event) => event.type === "done")).toBe(false);

      forgeMode = "stream";
      const retriedEvents = (await (await post({ ...body, conversationId })).text())
        .trim()
        .split("\n")
        .filter(Boolean)
        .map((line) => JSON.parse(line));
      expect(retriedEvents.some((event) => event.type === "done")).toBe(true);

      const stored = await realFetch(`${base}/api/conversations/${conversationId}`, { headers: AUTH });
      const payload = await stored.json();
      expect(payload.messages.map((message: { role: string; text: string }) => [message.role, message.text]))
        .toEqual([["user", "resume the interrupted turn"], ["assistant", "First second."]]);
    } finally {
      forgeMode = null;
    }
  });

  it("keeps one conversation across pages, forking only between different estates", async () => {
    // Nick 2026-08-03: the chat must survive tab/page switches. The scope guard
    // was narrowed to fork ONLY when an estate conversation gets a turn from a
    // DIFFERENT estate's page — the contamination case it exists to prevent.
    forgeMode = "stream";
    try {
      const post = (body: unknown) =>
        realFetch(`${base}/api/chat`, {
          method: "POST",
          headers: { ...AUTH, "content-type": "application/json", "x-app-origin": "https://probate-pro.com" },
          body: JSON.stringify(body),
        });
      const idOf = async (r: Response) => {
        const events = (await r.text()).trim().split("\n").filter(Boolean).map((l) => JSON.parse(l));
        return events.find((e) => e.type === "conversation")?.conversationId as string;
      };

      // Born on an estate page…
      const estateConv = await idOf(await post({ content: "about estate 7", context: { path: "/estate/7", estateId: "7" } }));
      // …it follows the user to a global page: same conversation.
      const afterGlobal = await idOf(await post({ conversationId: estateConv, content: "follow-up from deadlines", context: { path: "/deadlines" } }));
      expect(afterGlobal).toBe(estateConv);
      // A DIFFERENT estate's page forks: estate 8's turns are never filed into estate 7's conversation.
      const afterOtherEstate = await idOf(await post({ conversationId: estateConv, content: "about estate 8", context: { path: "/estate/8", estateId: "8" } }));
      expect(afterOtherEstate).not.toBe(estateConv);
      // A global conversation also follows the user onto an estate page.
      const globalConv = await idOf(await post({ content: "hello", context: { path: "/" } }));
      const globalOnEstate = await idOf(await post({ conversationId: globalConv, content: "now on estate 7", context: { path: "/estate/7", estateId: "7" } }));
      expect(globalOnEstate).toBe(globalConv);

      // Estate 7's conversation holds exactly its own turns — nothing from estate 8.
      const stored = await realFetch(`${base}/api/conversations/${estateConv}`, { headers: AUTH });
      const payload = await stored.json();
      const userTexts = payload.messages
        .filter((m: { role: string }) => m.role === "user")
        .map((m: { text: string }) => m.text);
      expect(userTexts).toEqual(["about estate 7", "follow-up from deadlines"]);
    } finally {
      forgeMode = null;
    }
  });

  it("exports the current transcript and clears every conversation for the authenticated user", async () => {
    forgeMode = "stream";
    try {
      const createdResponse = await realFetch(`${base}/api/conversations`, {
        method: "POST",
        headers: {
          ...AUTH,
          "content-type": "application/json",
          "x-app-origin": "https://probate-pro.com",
        },
        body: JSON.stringify({ scope: "global" }),
      });
      expect(createdResponse.status).toBe(200);
      const created = await createdResponse.json() as { id: string };

      const chatResponse = await realFetch(`${base}/api/chat`, {
        method: "POST",
        headers: {
          ...AUTH,
          "content-type": "application/json",
          "x-app-origin": "https://probate-pro.com",
        },
        body: JSON.stringify({ conversationId: created.id, content: "export me", context: { path: "/" } }),
      });
      expect((await chatResponse.text())).toContain('"type":"done"');

      const exported = await realFetch(`${base}/api/conversations/${created.id}/export`, { headers: AUTH });
      expect(exported.status).toBe(200);
      expect(exported.headers.get("content-type")).toContain("text/markdown");
      expect(exported.headers.get("content-disposition")).toContain("attachment;");
      const transcript = await exported.text();
      expect(transcript).toContain("**You**:");
      expect(transcript).toContain("export me");
      expect(transcript).toContain("**Assistant**:");
      expect(transcript).toContain("First second.");

      const cleared = await realFetch(`${base}/api/conversations`, {
        method: "DELETE",
        headers: { ...AUTH, "x-app-origin": "https://probate-pro.com" },
      });
      expect(cleared.status).toBe(200);
      expect((await cleared.json()).ok).toBe(true);

      const list = await realFetch(`${base}/api/conversations`, { headers: AUTH });
      expect(await list.json()).toEqual([]);
      const gone = await realFetch(`${base}/api/conversations/${created.id}/export`, { headers: AUTH });
      expect(gone.status).toBe(404);
    } finally {
      forgeMode = null;
    }
  });
});
