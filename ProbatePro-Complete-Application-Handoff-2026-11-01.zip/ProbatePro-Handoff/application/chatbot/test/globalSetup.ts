import fs from "node:fs";
import path from "node:path";

/**
 * Wipe the dedicated test DB (and its WAL sidecars) before the run so each suite
 * starts from an empty, isolated store — never the developer/operator chatbot.db
 * (ChatGPT #10). Paths mirror CHATBOT_DB_PATH set in vitest.config.ts.
 */
export default function setup(): void {
  const base = path.resolve(process.cwd(), process.env.CHATBOT_DB_PATH || "./data/vitest.db");
  for (const f of [base, `${base}-wal`, `${base}-shm`, `${base}-journal`]) {
    try {
      fs.rmSync(f, { force: true });
    } catch {
      /* ignore */
    }
  }
  // routes.test.ts uses its own path; clear it too for a clean start.
  const routeBase = path.resolve(process.cwd(), "./data/route-test.db");
  for (const f of [routeBase, `${routeBase}-wal`, `${routeBase}-shm`]) {
    try {
      fs.rmSync(f, { force: true });
    } catch {
      /* ignore */
    }
  }
}
