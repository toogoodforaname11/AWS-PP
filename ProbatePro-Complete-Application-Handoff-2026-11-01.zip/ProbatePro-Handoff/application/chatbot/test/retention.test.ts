import { describe, expect, it } from "vitest";
import { appendMessage, ageConversationForTest, createConversation, deleteAllConversations, deleteConversation, feedbackRowCountForTest, getConversation, pruneExpiredData, upsertFeedback } from "../src/db.js";

describe("chat retention and deletion", () => {
  it("deleting one conversation also deletes its feedback", () => {
    const userId = 81_001;
    deleteAllConversations(userId);
    const conversation = createConversation(userId, "global");
    const message = appendMessage(conversation.id, "assistant", { text: "hello" });
    upsertFeedback(userId, message.id, conversation.id, "up", "useful");
    expect(feedbackRowCountForTest(userId)).toBe(1);
    expect(deleteConversation(userId, conversation.id)).toBe(true);
    expect(feedbackRowCountForTest(userId)).toBe(0);
  });

  it("the scheduled policy removes chat data after the configured window", () => {
    const userId = 81_002;
    deleteAllConversations(userId);
    const conversation = createConversation(userId, "global");
    const message = appendMessage(conversation.id, "assistant", { text: "aged chat" });
    upsertFeedback(userId, message.id, conversation.id, "down", "old");
    ageConversationForTest(userId, conversation.id, Date.now() - 366 * 24 * 60 * 60 * 1000);
    const result = pruneExpiredData();
    expect(result.conversations).toBeGreaterThanOrEqual(1);
    expect(getConversation(userId, conversation.id)).toBeUndefined();
    expect(feedbackRowCountForTest(userId)).toBe(0);
  });
});
