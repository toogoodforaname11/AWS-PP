/**
 * Store-level coverage for the privacy-critical + ownership guarantees the
 * History UI relies on (Kimi #5 gap): conversation delete CASCADES its
 * proposals (so the user-facing delete really removes estate data), pending
 * proposals list correctly, and every read/delete is user_id-scoped.
 */
import { describe, expect, it } from "vitest";
import {
  appendMessage,
  claimProposal,
  createConversation,
  createProposal,
  deleteAllConversations,
  deleteConversation,
  dismissProposal,
  getConversation,
  getProposal,
  listMessages,
  listConversations,
  listPendingProposals,
  resolveProposal,
} from "../src/db.js";

const A = 90001;
const B = 90002;

describe("deleteConversation cascade (privacy — finding #8/#6c)", () => {
  it("removes the conversation, its messages, AND its proposals", () => {
    const conv = createConversation(A, "estate:e-cascade");
    appendMessage(conv.id, "user", { text: "hi" });
    const prop = createProposal({
      userId: A,
      conversationId: conv.id,
      estateId: "e-cascade",
      kind: "intake",
      payload: { procedure: "estate.update", input: {} },
      diff: { kind: "intake", estateId: "e-cascade", estateName: "E", rows: [] },
    });
    expect(getProposal(A, prop.id)).toBeTruthy();

    expect(deleteConversation(A, conv.id)).toBe(true);

    expect(getConversation(A, conv.id)).toBeUndefined();
    expect(listMessages(A, conv.id)).toEqual([]);
    // The estate-data-bearing proposal row is GONE, not orphaned.
    expect(getProposal(A, prop.id)).toBeUndefined();
  });
});

describe("ownership scoping", () => {
  it("a conversation is invisible and undeletable to another user", () => {
    const conv = createConversation(A, "estate:e-own");
    expect(getConversation(B, conv.id)).toBeUndefined();
    expect(listMessages(B, conv.id)).toEqual([]);
    // B cannot delete A's conversation; it survives for A.
    expect(deleteConversation(B, conv.id)).toBe(false);
    expect(getConversation(A, conv.id)).toBeTruthy();
  });
});

describe("claimProposal CAS (apply idempotency)", () => {
  it("exactly one caller can claim a pending proposal; the rest get false", () => {
    const conv = createConversation(A, "estate:e-claim");
    const prop = createProposal({
      userId: A,
      conversationId: conv.id,
      estateId: "e-claim",
      kind: "intake",
      payload: {},
      diff: {},
    });
    // First claim wins (pending -> applying); a concurrent claim/retry loses.
    expect(claimProposal(A, prop.id)).toBe(true);
    expect(claimProposal(A, prop.id)).toBe(false);
    // Another user cannot claim it either.
    expect(claimProposal(B, prop.id)).toBe(false);
    // It is no longer offered as pending while applying.
    expect(listPendingProposals(A, "e-claim").map((p) => p.id)).not.toContain(prop.id);
    // After resolution the status is terminal.
    resolveProposal(A, prop.id, "applied");
    expect(getProposal(A, prop.id)?.status).toBe("applied");
  });
});

describe("dismissProposal CAS (ChatGPT #8)", () => {
  it("dismisses only a pending proposal; a claimed/applied one returns false", () => {
    const conv = createConversation(A, "estate:e-dismiss");
    const prop = createProposal({
      userId: A,
      conversationId: conv.id,
      estateId: "e-dismiss",
      kind: "intake",
      payload: {},
      diff: {},
    });
    // Pending -> dismissed once; a second Reject (or a Reject after Apply) fails.
    expect(dismissProposal(A, prop.id)).toBe(true);
    expect(dismissProposal(A, prop.id)).toBe(false);
    expect(getProposal(A, prop.id)?.status).toBe("dismissed");

    // A proposal already claimed for Apply cannot be dismissed (would fake "Rejected").
    const p2 = createProposal({
      userId: A,
      conversationId: conv.id,
      estateId: "e-dismiss",
      kind: "intake",
      payload: {},
      diff: {},
    });
    expect(claimProposal(A, p2.id)).toBe(true); // now 'applying'
    expect(dismissProposal(A, p2.id)).toBe(false);
    // Another user can't dismiss it either.
    expect(dismissProposal(B, prop.id)).toBe(false);
  });
});

describe("listPendingProposals (finding #4 rehydration source)", () => {
  it("lists pending proposals for the estate and drops them once resolved", () => {
    const conv = createConversation(A, "estate:e-pending");
    const prop = createProposal({
      userId: A,
      conversationId: conv.id,
      estateId: "e-pending",
      kind: "intake",
      payload: {},
      diff: {},
    });
    expect(listPendingProposals(A, "e-pending").map((p) => p.id)).toContain(prop.id);
    // Another user sees none of it.
    expect(listPendingProposals(B, "e-pending")).toEqual([]);

    resolveProposal(A, prop.id, "applied");
    expect(listPendingProposals(A, "e-pending").map((p) => p.id)).not.toContain(prop.id);
  });
});

describe("deleteAllConversations privacy boundary", () => {
  it("removes all account conversations and proposals, including orphaned rows, without touching another account", () => {
    const aConversation = createConversation(A, "estate:e-clear-a");
    const bConversation = createConversation(B, "estate:e-clear-b");
    appendMessage(aConversation.id, "user", { text: "private A" });
    appendMessage(bConversation.id, "user", { text: "private B" });
    const orphan = createProposal({
      userId: A,
      conversationId: null,
      estateId: "e-clear-a",
      kind: "intake",
      payload: { private: "A" },
      diff: { private: "A" },
    });

    expect(deleteAllConversations(A)).toBeGreaterThan(0);
    expect(listConversations(A)).toEqual([]);
    expect(getProposal(A, orphan.id)).toBeUndefined();
    expect(getConversation(B, bConversation.id)).toBeTruthy();
    expect(listMessages(B, bConversation.id)).toHaveLength(1);

    deleteAllConversations(B);
  });
});
