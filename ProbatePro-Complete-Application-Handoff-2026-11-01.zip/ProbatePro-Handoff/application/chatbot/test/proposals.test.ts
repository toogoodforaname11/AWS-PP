/**
 * Coverage for proposal payload construction + the abort guard (Kimi #5,
 * finding C2). appClient is mocked so the create* functions run against a fake
 * estate; the real bot SQLite store persists the row (verifies payload shape).
 */
import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("../src/appClient.js", async (importActual) => {
  const actual = await importActual<typeof import("../src/appClient.js")>();
  return { ...actual, appQuery: vi.fn(), appMutation: vi.fn() };
});

import { AppError, appMutation, appQuery } from "../src/appClient.js";
import {
  applyProposal,
  describeAppliedProposal,
  ProposalConflict,
  createContactsProposal,
  createContactUpdatesProposal,
  createIntakeProposal,
  createInventoryProposal,
} from "../src/proposals.js";
import type { ProposalRow } from "../src/db.js";

const session = { token: "t", baseUrl: "http://app" } as any;

beforeEach(() => {
  vi.mocked(appQuery).mockReset();
  vi.mocked(appMutation).mockReset();
  vi.mocked(appMutation).mockResolvedValue({} as any);
  // estate.get -> a fake estate; contact.list -> [] (no existing executors).
  vi.mocked(appQuery).mockImplementation(async (_s: any, proc: string) =>
    proc === "contact.list" ? [] : { estateName: "Estate One", deceasedLastName: "Chan", revision: 7 },
  );
});

const proposalRow = (over: Partial<ProposalRow> & Pick<ProposalRow, "kind">): ProposalRow => ({
  id: `p-${Math.round(over.created_at ?? 1)}-${over.kind}`,
  conversation_id: null,
  user_id: 1,
  estate_id: "e1",
  payload: "{}",
  diff: "{}",
  status: "applying",
  error: null,
  created_at: 1,
  resolved_at: null,
  ...over,
});

describe("createIntakeProposal", () => {
  it("builds an estate.update payload from the accepted fields", async () => {
    const { proposal, diff } = await createIntakeProposal({
      userId: 1,
      conversationId: null,
      session,
      estateId: "e1",
      accepted: [{ field: "deceasedFirstName", value: "Mary", source: "will.pdf" }],
    });
    const payload = JSON.parse(proposal!.payload);
    expect(payload).toEqual({
      procedure: "estate.update",
      input: { id: "e1", data: { deceasedFirstName: "Mary" } },
    });
    expect(diff!.rows[0]).toMatchObject({ key: "deceasedFirstName", newValue: "Mary" });
  });

  it("drops fields the estate already holds so the card shows only real changes", async () => {
    // The reported bug: the model re-proposed values it had just read back, so
    // the card rendered "Chan -> Chan" rows and applying it changed nothing.
    // Carrying them also widens detectIntakeDrift's guard over untouched fields.
    vi.mocked(appQuery).mockResolvedValueOnce({
      estateName: "Estate One",
      deceasedLastName: "Chan",
      deceasedFirstName: "Mary",
    });
    const { proposal, diff, unchanged } = await createIntakeProposal({
      userId: 1,
      conversationId: null,
      session,
      estateId: "e1",
      accepted: [
        { field: "deceasedLastName", value: "Chan", source: "p1.pdf" }, // already stored
        { field: "deceasedFirstName", value: "Mary", source: "p1.pdf" }, // already stored
        { field: "deceasedResidenceCity", value: "Victoria", source: "p1.pdf" }, // real change
      ],
    });

    expect(unchanged).toEqual(["deceasedLastName", "deceasedFirstName"]);
    expect(diff!.rows.map((r) => r.key)).toEqual(["deceasedResidenceCity"]);
    // Only the changed field may reach the app — and therefore only it is
    // guarded for drift at apply time.
    expect(JSON.parse(proposal!.payload).input.data).toEqual({ deceasedResidenceCity: "Victoria" });
  });

  it("creates NO proposal when every proposed value already matches the estate", async () => {
    vi.mocked(appQuery).mockResolvedValueOnce({ estateName: "Estate One", deceasedLastName: "Chan" });
    const { proposal, diff, unchanged } = await createIntakeProposal({
      userId: 1,
      conversationId: null,
      session,
      estateId: "e1",
      accepted: [{ field: "deceasedLastName", value: "Chan", source: "p1.pdf" }],
    });

    // An all-no-op card applies cleanly and changes nothing, which is
    // indistinguishable from a broken Apply. Better to create nothing.
    expect(proposal).toBeNull();
    expect(diff).toBeNull();
    expect(unchanged).toEqual(["deceasedLastName"]);
  });

  it("throws (no row written) when the request was aborted before the write", async () => {
    await expect(
      createIntakeProposal({
        userId: 1,
        conversationId: null,
        session,
        estateId: "e1",
        accepted: [{ field: "deceasedFirstName", value: "Mary", source: "will.pdf" }],
        signal: { aborted: true },
      }),
    ).rejects.toThrow(/cancel/i);
  });
});

describe("createContactsProposal", () => {
  it("builds contact.create inputs and discloses the auto executor rank", async () => {
    const { proposal, diff } = await createContactsProposal({
      userId: 1,
      conversationId: null,
      session,
      estateId: "e1",
      accepted: [{ fields: { role: "executor", name: "Alex" }, source: "will.pdf" }],
    });
    const payload = JSON.parse(proposal.payload);
    expect(payload.procedure).toBe("contact.create");
    expect(payload.inputs[0]).toMatchObject({ estateId: "e1", role: "executor", name: "Alex" });
    // The derived executorRank is disclosed on the card but NOT in the write payload.
    expect("executorRank" in payload.inputs[0]).toBe(false);
    const flat = (diff.groups ?? []).flat();
    expect(flat.some((r) => r.key === "executorRank" && /primary/i.test(r.newValue))).toBe(true);
  });
});

describe("createInventoryProposal", () => {
  it("stores integer cents with valueRecorded set", async () => {
    const { proposal } = await createInventoryProposal({
      userId: 1,
      conversationId: null,
      session,
      estateId: "e1",
      accepted: [
        { category: "financial", description: "RBC chequing", valueCents: 1234500, source: "stmt" },
      ],
    });
    const payload = JSON.parse(proposal.payload);
    expect(payload.procedure).toBe("inventory.bulkCreate");
    expect(payload.input.items[0]).toMatchObject({
      category: "financial",
      value: 1234500,
      valueRecorded: 1,
    });
  });
});

describe("applyProposal apply-time paths (Kimi #9)", () => {
  it("intake: throws ProposalConflict when a target field drifted since propose", async () => {
    vi.mocked(appQuery).mockResolvedValueOnce({ deceasedLastName: "Chang" }); // drifted from Chan
    const p = proposalRow({
      kind: "intake",
      payload: JSON.stringify({ input: { id: "e1", data: { deceasedLastName: "Chen" } } }),
      diff: JSON.stringify({
        kind: "intake",
        rows: [{ key: "deceasedLastName", label: "Last name", oldValue: "Chan", newValue: "Chen" }],
      }),
    });
    await expect(applyProposal(1, session, p)).rejects.toBeInstanceOf(ProposalConflict);
    expect(appMutation).not.toHaveBeenCalled(); // never wrote
  });

  it("intake: applies when nothing drifted", async () => {
    vi.mocked(appQuery).mockResolvedValueOnce({ deceasedLastName: "Chan", revision: 7 });
    const p = proposalRow({
      kind: "intake",
      payload: JSON.stringify({ input: { id: "e1", data: { deceasedLastName: "Chen" } } }),
      diff: JSON.stringify({
        kind: "intake",
        rows: [{ key: "deceasedLastName", label: "Last name", oldValue: "Chan", newValue: "Chen" }],
      }),
    });
    await expect(applyProposal(1, session, p)).resolves.toMatchObject({ invalidate: expect.any(Array) });
    expect(appMutation).toHaveBeenCalledWith(session, "estate.update", {
      id: "e1",
      expectedRevision: 7,
      data: { deceasedLastName: "Chen" },
    });
  });

  it("intake: refuses to write when the apply-time estate revision is unavailable", async () => {
    vi.mocked(appQuery).mockResolvedValueOnce({ deceasedLastName: "Chan" });
    const p = proposalRow({
      kind: "intake",
      payload: JSON.stringify({ input: { id: "e1", data: { deceasedLastName: "Chen" } } }),
      diff: JSON.stringify({
        kind: "intake",
        rows: [{ key: "deceasedLastName", label: "Last name", oldValue: "Chan", newValue: "Chen" }],
      }),
    });
    await expect(applyProposal(1, session, p)).rejects.toMatchObject({
      code: "ESTATE_REVISION_UNAVAILABLE",
      httpStatus: 409,
    });
    expect(appMutation).not.toHaveBeenCalled();
  });

  it("contacts: throws ProposalConflict when the executor landscape changed (#4)", async () => {
    // Disclosed at propose: no existing primary. Now a primary executor exists.
    vi.mocked(appQuery).mockResolvedValueOnce([{ role: "executor", executorRank: "primary" }]);
    const p = proposalRow({
      kind: "contacts",
      payload: JSON.stringify({
        inputs: [{ estateId: "e1", role: "executor", name: "Alex" }],
        executorDisclosure: { primaryTakenAtPropose: false, hasExecutorish: true },
      }),
      diff: JSON.stringify({ kind: "contacts", groups: [] }),
    });
    await expect(applyProposal(1, session, p)).rejects.toBeInstanceOf(ProposalConflict);
    expect(appMutation).not.toHaveBeenCalled();
  });

  it("contacts: reports how many landed on a mid-loop failure", async () => {
    vi.mocked(appQuery).mockResolvedValueOnce([]); // no executor drift
    vi.mocked(appMutation)
      .mockResolvedValueOnce({} as any) // 1st contact ok
      .mockRejectedValueOnce(new AppError("boom", "X", 500)); // 2nd fails
    const p = proposalRow({
      kind: "contacts",
      payload: JSON.stringify({
        inputs: [
          { estateId: "e1", role: "beneficiary", name: "A" },
          { estateId: "e1", role: "beneficiary", name: "B" },
        ],
        executorDisclosure: { primaryTakenAtPropose: false, hasExecutorish: false },
      }),
      diff: JSON.stringify({ kind: "contacts", groups: [] }),
    });
    await expect(applyProposal(1, session, p)).rejects.toThrow(/Added 1 of 2/);
  });

  it("inventory: partial-failure message tells the user to verify before retrying (#5)", async () => {
    vi.mocked(appMutation).mockRejectedValueOnce(new AppError("boom", "X", 500));
    const p = proposalRow({
      kind: "inventory",
      payload: JSON.stringify({ input: { estateId: "e1", items: [{}, {}, {}] } }),
      diff: JSON.stringify({ kind: "inventory", groups: [] }),
    });
    await expect(applyProposal(1, session, p)).rejects.toThrow(/may already be saved|Inventory tab/i);
  });
});

describe("describeAppliedProposal", () => {
  // The assistant has no other channel for learning the user clicked Apply:
  // the card's outcome lives in React state and never reaches this service, and
  // no tool reads proposal status. Without this line in the conversation the
  // model answers "No — I did not apply any changes" to a user who just did.
  it("names the fields that landed so the next turn cannot deny the apply", () => {
    const note = describeAppliedProposal(
      proposalRow({
        kind: "intake",
        diff: JSON.stringify({
          kind: "intake",
          rows: [
            { key: "deceasedResidenceCity", label: "Former residence city", oldValue: "", newValue: "Victoria", source: "p1.pdf" },
          ],
        }),
      }),
    );
    expect(note).toContain("Applied");
    expect(note).toContain("Former residence city");
  });

  it("reads labels out of grouped diffs (contacts / inventory)", () => {
    const note = describeAppliedProposal(
      proposalRow({
        kind: "contacts",
        diff: JSON.stringify({
          kind: "contacts",
          groups: [[{ key: "name", label: "Name", oldValue: "", newValue: "Alex", source: "will.pdf" }]],
        }),
      }),
    );
    expect(note).toContain("Name");
  });

  it("still reports the apply when the diff cannot be parsed", () => {
    // That the write HAPPENED matters more than naming the fields — a malformed
    // diff must not silently drop the only record of it.
    const note = describeAppliedProposal(proposalRow({ kind: "intake", diff: "not json" }));
    expect(note).toContain("Applied");
  });
});

describe("contact duplication guard + editing an existing person", () => {
  const withContacts = (contacts: Array<Record<string, unknown>>) =>
    vi.mocked(appQuery).mockImplementation(async (_s: any, proc: string) =>
      proc === "contact.list" ? contacts : { estateName: "Estate One", deceasedLastName: "Chan" },
    );

  it("refuses to re-create a person already on the estate", async () => {
    // The reported damage: asked to change an executor's role, the model had
    // only a create tool and proposed the person again — leaving the file with
    // two Emma Carters and two David Carters, and a consent list naming the
    // same party twice. Roles drive Rule 25 notices, PGT and distribution, so a
    // duplicated party is a legal defect.
    withContacts([{ id: "c1", name: "David Michael Carter", role: "executor" }]);

    const { proposal, diff, duplicates } = await createContactsProposal({
      userId: 1,
      conversationId: null,
      session,
      estateId: "e1",
      accepted: [{ fields: { role: "beneficiary", name: "David  MICHAEL   Carter" }, source: "will.pdf" }],
    });

    // Matched despite different casing and spacing — a create must not slip
    // through on cosmetic differences.
    expect(duplicates).toEqual(["David  MICHAEL   Carter"]);
    expect(proposal).toBeNull();
    expect(diff).toBeNull();
  });

  it("still creates genuinely new people in the same batch", async () => {
    withContacts([{ id: "c1", name: "David Michael Carter", role: "executor" }]);

    const { proposal, diff, duplicates } = await createContactsProposal({
      userId: 1,
      conversationId: null,
      session,
      estateId: "e1",
      accepted: [
        { fields: { role: "beneficiary", name: "David Michael Carter" }, source: "will.pdf" },
        { fields: { role: "beneficiary", name: "Emma Louise Carter" }, source: "will.pdf" },
      ],
    });

    expect(duplicates).toEqual(["David Michael Carter"]);
    expect(JSON.parse(proposal!.payload).inputs).toHaveLength(1);
    expect(diff!.groups).toHaveLength(1);
  });

  it("builds a contact.update payload carrying only the fields that change", async () => {
    withContacts([
      { id: "c1", name: "David Michael Carter", role: "beneficiary", email: "d@x.com", isMinor: 0 },
    ]);

    const { proposal, diff, unchanged } = await createContactUpdatesProposal({
      userId: 1,
      conversationId: null,
      session,
      estateId: "e1",
      accepted: [
        {
          contactId: "c1",
          fields: { role: "executor,applicant", email: "d@x.com" }, // email already correct
          bools: { isMinor: false }, // already false
          source: "user instruction",
        },
      ],
    });

    const payload = JSON.parse(proposal!.payload);
    expect(payload.procedure).toBe("contact.update");
    expect(payload.inputs[0]).toEqual({ id: "c1", estateId: "e1", data: { role: "executor,applicant" } });
    expect(unchanged).toEqual(expect.arrayContaining(["email", "isMinor"]));
    // The card must name WHO is being changed — the user is authorizing an edit
    // to a specific party, not a set of orphan values.
    expect(diff!.groups![0][0]).toMatchObject({ key: "__contact", newValue: "David Michael Carter" });
  });

  it("creates no proposal when the contact already holds every value", async () => {
    withContacts([{ id: "c1", name: "David Michael Carter", role: "executor" }]);
    const { proposal, unchanged } = await createContactUpdatesProposal({
      userId: 1, conversationId: null, session, estateId: "e1",
      accepted: [{ contactId: "c1", fields: { role: "executor" }, source: "user" }],
    });
    expect(proposal).toBeNull();
    expect(unchanged).toEqual(["role"]);
  });

  it("reports a contactId that is not on the estate instead of writing", async () => {
    withContacts([{ id: "c1", name: "David Michael Carter", role: "executor" }]);
    const { proposal, unknownContacts } = await createContactUpdatesProposal({
      userId: 1, conversationId: null, session, estateId: "e1",
      accepted: [{ contactId: "ghost", fields: { role: "executor" }, source: "user" }],
    });
    expect(proposal).toBeNull();
    expect(unknownContacts).toEqual(["ghost"]);
  });

  it("refuses to apply a contact edit when staff changed that field first", async () => {
    // An edit OVERWRITES, so a stale proposal must never clobber a correction
    // someone made in the Contacts tab between propose and Apply.
    vi.mocked(appQuery).mockResolvedValueOnce([
      { id: "c1", name: "David Michael Carter", role: "trustee" }, // was "beneficiary" at propose
    ]);
    const p = proposalRow({
      kind: "contact_updates",
      payload: JSON.stringify({ procedure: "contact.update", inputs: [{ id: "c1", estateId: "e1", data: { role: "executor" } }] }),
      diff: JSON.stringify({
        kind: "contact_updates",
        groups: [[
          { key: "__contact", label: "Editing", oldValue: "", newValue: "David Michael Carter", source: "existing contact" },
          { key: "role", label: "Role", oldValue: "beneficiary", newValue: "executor", source: "user" },
        ]],
      }),
    });
    await expect(applyProposal(1, session, p)).rejects.toBeInstanceOf(ProposalConflict);
    expect(appMutation).not.toHaveBeenCalled();
  });

  it("applies a contact edit through the app's own contact.update", async () => {
    vi.mocked(appQuery).mockResolvedValueOnce([
      { id: "c1", name: "David Michael Carter", role: "beneficiary" },
    ]);
    const p = proposalRow({
      kind: "contact_updates",
      payload: JSON.stringify({ procedure: "contact.update", inputs: [{ id: "c1", estateId: "e1", data: { role: "executor" } }] }),
      diff: JSON.stringify({
        kind: "contact_updates",
        groups: [[
          { key: "__contact", label: "Editing", oldValue: "", newValue: "David Michael Carter", source: "existing contact" },
          { key: "role", label: "Role", oldValue: "beneficiary", newValue: "executor", source: "user" },
        ]],
      }),
    });
    await expect(applyProposal(1, session, p)).resolves.toMatchObject({ invalidate: expect.any(Array) });
    expect(appMutation).toHaveBeenCalledWith(session, "contact.update", {
      id: "c1", estateId: "e1", data: { role: "executor" },
    });
  });

  // LOGIC-007: two contacts sharing a display name (father/son — routine on a
  // probate file). The drift guard used to join diff groups to write inputs BY
  // NAME, so both groups compared against the first "John Smith" — missing real
  // drift on the second one (or false-conflicting). The join is now the shared
  // index (groups[i] ↔ inputs[i], built pairwise at propose time).
  const twoJohnsProposal = () =>
    proposalRow({
      kind: "contact_updates",
      payload: JSON.stringify({
        procedure: "contact.update",
        inputs: [
          { id: "c1", estateId: "e1", data: { role: "executor" } },
          { id: "c2", estateId: "e1", data: { role: "trustee" } },
        ],
      }),
      diff: JSON.stringify({
        kind: "contact_updates",
        groups: [
          [
            { key: "__contact", label: "Editing", oldValue: "", newValue: "John Smith", source: "existing contact" },
            { key: "role", label: "Role", oldValue: "beneficiary", newValue: "executor", source: "user" },
          ],
          [
            { key: "__contact", label: "Editing", oldValue: "", newValue: "John Smith", source: "existing contact" },
            { key: "role", label: "Role", oldValue: "beneficiary", newValue: "trustee", source: "user" },
          ],
        ],
      }),
    });

  it("catches drift on the SECOND of two same-named contacts (LOGIC-007)", async () => {
    // Staff corrected the son (c2) after propose; the father (c1) is untouched.
    // The name join compared c2's group against c1's row (both "John Smith",
    // c1.role still matches the group's oldValue) and applied a stale overwrite.
    vi.mocked(appQuery).mockResolvedValueOnce([
      { id: "c1", name: "John Smith", role: "beneficiary" },
      { id: "c2", name: "John Smith", role: "spouse" }, // drifted since propose
    ]);
    await expect(applyProposal(1, session, twoJohnsProposal())).rejects.toBeInstanceOf(ProposalConflict);
    expect(appMutation).not.toHaveBeenCalled();
  });

  it("applies both same-named contacts to their own rows when nothing drifted", async () => {
    vi.mocked(appQuery).mockResolvedValueOnce([
      { id: "c1", name: "John Smith", role: "beneficiary" },
      { id: "c2", name: "John Smith", role: "beneficiary" },
    ]);
    await expect(applyProposal(1, session, twoJohnsProposal())).resolves.toMatchObject({
      invalidate: expect.any(Array),
    });
    expect(appMutation).toHaveBeenCalledWith(session, "contact.update", { id: "c1", estateId: "e1", data: { role: "executor" } });
    expect(appMutation).toHaveBeenCalledWith(session, "contact.update", { id: "c2", estateId: "e1", data: { role: "trustee" } });
  });
});
