/**
 * SEC-2 — split rate-limit populations (src/index.ts mount order).
 *
 * The chatbot sits in-process behind the platform proxy with no `trust proxy`,
 * so any IP key is ONE bucket for the whole deployment. The fix is not a better
 * key, it is two limiters:
 *   • an edge limiter BEFORE auth — IP-keyed, split into `anon:`/`cold:` key
 *     spaces by credential presence, skipped entirely for sessions the app has
 *     already verified;
 *   • the real per-user limits AFTER auth — keyed by the verified user id.
 * The properties that matter: one user exhausting their bucket leaves others
 * untouched, a forged token can never mint itself a fresh bucket, and an
 * unauthenticated flood cannot 429 an authenticated user — not even on the
 * first, still-cold request of their embedded session. The parent app verifies
 * the signed JWT locally and places the subject in res.locals before this app;
 * standalone loopback mode retains the cold bucket because it holds no app key.
 */
import { afterEach, beforeAll, describe, expect, it, vi } from "vitest";
import type { Server } from "node:http";
import express from "express";
import rateLimit from "express-rate-limit";

vi.mock("../src/appClient.js", async (importActual) => {
  const actual = await importActual<typeof import("../src/appClient.js")>();
  return { ...actual, appQuery: vi.fn(), appMutation: vi.fn() };
});

import { appQuery } from "../src/appClient.js";
import {
  authenticate,
  edgeRateLimitKey,
  EMBEDDED_CHATBOT_VERIFIED_SESSION_LOCAL,
  hasVerifiedIdentity,
  hasVerifiedRateLimitIdentity,
} from "../src/auth.js";

// token -> user id, as the app's auth.me would verify it. Unknown tokens are dead.
const USERS: Record<string, number> = {
  "alice-token": 101,
  "bob-token": 202,
  "carol-token": 303,
  "dave-token": 404,
  "eve-token": 505,
};

let server: Server | undefined;

beforeAll(() => {
  vi.mocked(appQuery).mockImplementation(async (session: any, proc: string) => {
    if (proc === "settings.get") return { aiProcessorApprovedAt: Date.now(), showChatbot: true };
    const id = USERS[session.token];
    return id ? { id, name: `user-${id}`, email: null } : null;
  });
});

afterEach(() => {
  server?.close();
  server = undefined;
  vi.useRealTimers();
});

/**
 * The real mount order from src/index.ts, with a tiny max so exhaustion is
 * testable (index.ts self-caps at 10k under VITEST). Each test gets its own
 * app so the in-memory buckets never bleed across cases.
 */
async function startApp(max = 2): Promise<string> {
  const shared = {
    windowMs: 60_000,
    max,
    standardHeaders: true,
    legacyHeaders: false,
    validate: { xForwardedForHeader: false },
  } as const;
  const app = express();
  // Stand-in for the parent app's local JWT-signature verifier. This header is
  // TEST-ONLY; production writes res.locals directly in server/chatbot.ts.
  app.use((req, res, next) => {
    const trusted = req.headers["x-test-verified-session"];
    if (typeof trusted === "string") {
      res.locals[EMBEDDED_CHATBOT_VERIFIED_SESSION_LOCAL] = trusted;
    }
    next();
  });
  app.use(rateLimit({
    ...shared,
    keyGenerator: edgeRateLimitKey,
    skip: (req, res) => req.path !== "/health" && hasVerifiedRateLimitIdentity(req, res),
  }));
  app.use((req, res, next) => {
    // Stand-in for requireUser: the same authenticate() call, same 401.
    // /health bypasses it in index.ts, so it never reaches the per-user limiter.
    if (req.path === "/health") return next();
    void authenticate(req)
      .then((authed) => {
        if (!authed) return void res.status(401).json({ error: "auth_expired" });
        (req as any).authed = authed;
        next();
      })
      .catch(() => void res.status(503).json({ error: "app_unreachable" }));
  });
  app.use(rateLimit({
    ...shared,
    keyGenerator: (req) => `user:${(req as any).authed.user.id}`,
    skip: (req) => !(req as any).authed,
  }));
  app.get("/ping", (_req, res) => void res.json({ ok: true }));
  app.get("/health", (_req, res) => void res.json({ ok: true }));
  server = await new Promise<Server>((res) => {
    const s = app.listen(0, "127.0.0.1", () => res(s));
  });
  const addr = server.address();
  return `http://127.0.0.1:${typeof addr === "object" && addr ? addr.port : 0}`;
}

const ping = (base: string, token?: string, verifiedSession?: string) =>
  fetch(`${base}/ping`, { headers: {
    ...(token ? { authorization: `Bearer ${token}` } : {}),
    ...(verifiedSession ? { "x-test-verified-session": verifiedSession } : {}),
  } });

describe("edge bucket keying", () => {
  it("splits tokenless from token-bearing traffic and never keys on the token", async () => {
    const anon = edgeRateLimitKey({ headers: {}, ip: "10.0.0.1" } as any);
    expect(anon).toBe("anon:10.0.0.1");
    // Any token — verified, expired or forged — shares the `cold:` bucket, so
    // rotating forged tokens cannot mint fresh buckets and bypass the limiter.
    const forged = edgeRateLimitKey({ headers: { authorization: "Bearer forged" }, ip: "10.0.0.1" } as any);
    expect(forged).toBe("cold:10.0.0.1");
    expect(edgeRateLimitKey({ headers: { authorization: "Bearer other-forged" }, ip: "10.0.0.1" } as any))
      .toBe(forged);
    expect(forged).not.toBe(anon);
    // IPv6-safe (express-rate-limit's ipKeyGenerator, /56 bucketing).
    expect(edgeRateLimitKey({ headers: {}, ip: "2001:db8:85a3::8a2e:370:7334" } as any))
      .toBe("anon:2001:db8:85a3::/56");
  });

  it("reports a verified session as warm and everything else as cold", async () => {
    expect(hasVerifiedIdentity({ headers: { authorization: "Bearer alice-token" } } as any)).toBe(false);
    await authenticate({ headers: { authorization: "Bearer alice-token" } } as any);
    expect(hasVerifiedIdentity({ headers: { authorization: "Bearer alice-token" } } as any)).toBe(true);
    expect(hasVerifiedIdentity({ headers: { authorization: "Bearer forged-token" } } as any)).toBe(false);
    expect(hasVerifiedIdentity({ headers: {} } as any)).toBe(false);
  });

  it("accepts only the parent's non-request res.locals hint for a valid cold embedded session", () => {
    const req = { headers: { authorization: "Bearer carol-token" } } as any;
    expect(hasVerifiedIdentity(req)).toBe(false);
    expect(hasVerifiedRateLimitIdentity(req, { locals: {} } as any)).toBe(false);
    expect(hasVerifiedRateLimitIdentity(req, {
      locals: { [EMBEDDED_CHATBOT_VERIFIED_SESSION_LOCAL]: "carol-open-id" },
    } as any)).toBe(true);
  });

  it("keeps an actively-used session warm across the TTL re-verification", async () => {
    await authenticate({ headers: { authorization: "Bearer bob-token" } } as any);
    vi.useFakeTimers({ toFake: ["Date"] }); // clock only — leave timers/microtasks real
    // Past the 5-minute TTL: authenticate() re-verifies with the app, but the
    // last verified identity is carried onto the new entry, so the synchronous
    // peek never reports a live session as unauthenticated.
    vi.setSystemTime(Date.now() + 6 * 60 * 1000);
    await authenticate({ headers: { authorization: "Bearer bob-token" } } as any);
    expect(hasVerifiedIdentity({ headers: { authorization: "Bearer bob-token" } } as any)).toBe(true);
  });
});

describe("per-user limits", () => {
  it("isolates users: one user exhausting their bucket leaves another unaffected", async () => {
    const base = await startApp();
    expect((await ping(base, "alice-token")).status).toBe(200);
    expect((await ping(base, "alice-token")).status).toBe(200);
    expect((await ping(base, "alice-token")).status).toBe(429); // alice exhausted
    expect((await ping(base, "bob-token")).status).toBe(200); // bob untouched
  });

  it("does not let an unauthenticated flood 429 an authenticated user", async () => {
    const base = await startApp();
    // The cheap attack: junk requests with no token at all (the edge limiter
    // runs before express.json, so no valid body or token is needed).
    expect((await ping(base)).status).toBe(401);
    expect((await ping(base)).status).toBe(401);
    expect((await ping(base)).status).toBe(429); // `anon:` bucket pinned at zero
    // carol has NEVER authenticated on this process — her very first request is
    // cold, exactly the case the old shared bucket 429'd (and, because she never
    // reached requireUser, her per-user bucket was never warmed either).
    expect(hasVerifiedIdentity({ headers: { authorization: "Bearer carol-token" } } as any)).toBe(false);
    expect((await ping(base, "carol-token")).status).toBe(200);
    // …and an established session is skipped at the edge outright.
    expect((await ping(base, "alice-token")).status).toBe(200);
  });

  it("keeps an established session out of a token-bearing flood's bucket, across the TTL boundary", async () => {
    const base = await startApp();
    // dave establishes his session (no HTTP, so the `cold:` bucket is untouched).
    await authenticate({ headers: { authorization: "Bearer dave-token" } } as any);

    vi.useFakeTimers({ toFake: ["Date"] }); // clock only — leave timers/microtasks real
    vi.setSystemTime(Date.now() + 6 * 60 * 1000); // past TTL_MS: dave must re-verify

    // The costlier attack the tokenless test does not cover: attach ANY junk
    // token and the flood lands in `cold:` instead of `anon:`.
    expect((await ping(base, "forged-x")).status).toBe(401);
    expect((await ping(base, "forged-y")).status).toBe(401);
    expect((await ping(base, "forged-z")).status).toBe(429); // `cold:` pinned at zero

    // dave crosses his TTL boundary while `cold:` is exhausted. hasVerifiedIdentity
    // is deliberately not gated on TTL_MS: a 429 here would skip authenticate(),
    // so `at` would never refresh and the flood would lock him out permanently.
    expect((await ping(base, "dave-token")).status).toBe(200);
  });

  it("does not let rotating forged tokens block a valid first embedded request", async () => {
    const base = await startApp();
    expect((await ping(base, "forged-first")).status).toBe(401);
    expect((await ping(base, "forged-second")).status).toBe(401);
    expect((await ping(base, "forged-third")).status).toBe(429);

    // Eve has no chatbot auth cache entry. The parent has independently
    // verified her signed app JWT, so the first request skips `cold:` and then
    // establishes the authoritative per-user identity in requireUser.
    expect(hasVerifiedIdentity({ headers: { authorization: "Bearer eve-token" } } as any)).toBe(false);
    expect((await ping(base, "eve-token", "eve-open-id")).status).toBe(200);
  });

  it("keeps /health on the edge limiter — it is the one route with no per-user limiter", async () => {
    const base = await startApp();
    await authenticate({ headers: { authorization: "Bearer dave-token" } } as any);
    // /health skips requireUser, so req.authed is never set and the per-user
    // limiter skips it. Without the edge limiter it would be covered by nothing.
    const health = () => fetch(`${base}/health`, { headers: { authorization: "Bearer dave-token" } });
    expect((await health()).status).toBe(200);
    expect((await health()).status).toBe(200);
    expect((await health()).status).toBe(429);
  });

  it("pins forged tokens to the shared cold bucket — no bypass by rotating tokens", async () => {
    const base = await startApp();
    expect((await ping(base, "forged-a")).status).toBe(401);
    expect((await ping(base, "forged-b")).status).toBe(401);
    expect((await ping(base, "forged-c")).status).toBe(429);
  });
});
