/**
 * Security coverage for ChatGPT's DO-NOT-SHIP findings.
 *
 * Finding 1 — credentialed cross-origin exposure: the embedded chatbot used to
 *   trust every origin the (broad) parent CORS accepts (`*.manus.*`, `*.run.app`),
 *   so a page on another parent-allowed origin could read a victim's chatbot data
 *   (the session cookie is SameSite=None). We now enforce the chatbot's OWN
 *   same-origin/exact check on EVERY authenticated route.
 * Finding 3 — account isolation was tested only at the SQLite layer with a single
 *   mocked user. We now drive TWO real identities through the HTTP routes.
 * Finding 2 (mitigation) — the in-process embed removed the structural boundary;
 *   we enforce the by-convention boundary with an import/secret guard.
 *
 * Runs EMBEDDED (CHATBOT_EMBEDDED=1) so it exercises the exact deployment path the
 * finding is about. The bot's outbound auth.me is mocked to two users by token.
 *
 * COVERAGE BOUNDARY: cross-user ESTATE reads on the chat-tool path (a foreign
 * pageContext.estateId / document key) are enforced APP-SIDE by assertEstateOwned
 * and covered by the app's own tests; the bot delegates that check to the app and
 * does not re-test it here (it would require mocking the whole app tRPC surface).
 */
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import superjson from "superjson";
import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import type { Server } from "node:http";

let server: Server;
let base: string;
let host: string;
let store: typeof import("../src/db.js");
// Populated in beforeAll via dynamic import — importing env.js statically at the
// top would freeze ENV before beforeAll sets BUILT_IN_FORGE_API_KEY (validateEnv
// would then throw during the index.js import).
let isAllowedBrowserOrigin: (origin?: string, host?: string) => boolean;
const realFetch = globalThis.fetch;

const userFor = (token: string) =>
  token.startsWith("Bob") ? { id: 2, name: "Bob", email: null } : { id: 1, name: "Alice", email: null };

function outboundAuth(init: unknown): string {
  const h = (init as { headers?: unknown } | undefined)?.headers as
    | { get?: (k: string) => string | null; authorization?: string; Authorization?: string }
    | undefined;
  if (!h) return "";
  if (typeof h.get === "function") return h.get("authorization") || h.get("Authorization") || "";
  return h.authorization || h.Authorization || "";
}

function authMe(init: unknown) {
  const token = outboundAuth(init).replace(/^Bearer\s+/i, "").trim();
  const user = userFor(token);
  // Simulate a past-50%-lifetime session: auth.me returns a rotated token. Used to
  // prove a cross-origin request never relays it onto our response header (the
  // X-Rotated-Session exfil that would otherwise be account takeover).
  const rotated = `app_session_id=rotated.${user.id}.jwt`;
  return {
    status: 200,
    ok: true,
    headers: { get: (k: string) => (String(k).toLowerCase() === "x-rotated-session" ? rotated : null) },
    text: async () => JSON.stringify({ result: { data: superjson.serialize(user) } }),
  } as unknown as Response;
}

function approvedSettings() {
  return {
    status: 200,
    ok: true,
    headers: { get: () => null },
    text: async () => JSON.stringify({ result: { data: superjson.serialize({ aiProcessorApprovedAt: Date.now(), showChatbot: true }) } }),
  } as unknown as Response;
}

beforeAll(async () => {
  process.env.CHATBOT_EMBEDDED = "1";
  process.env.BUILT_IN_FORGE_API_KEY = "test-forge-key";
  process.env.BUILT_IN_FORGE_API_URL = "https://forge.test";
  process.env.APP_BASE_URL = "http://app.test";
  process.env.CHATBOT_DB_PATH = "./data/security-test.db";
  // Bot -> app auth.me is mocked (two users by token); everything else is real.
  vi.stubGlobal("fetch", (url: unknown, init?: unknown) =>
    String(url).includes("app.test")
      ? Promise.resolve(String(url).includes("settings.get") ? approvedSettings() : authMe(init))
      : realFetch(url as string, init as RequestInit),
  );
  const mod = await import("../src/index.js");
  store = await import("../src/db.js");
  ({ isAllowedBrowserOrigin } = await import("../src/env.js"));
  server = await new Promise<Server>((res) => {
    const s = mod.app.listen(0, "127.0.0.1", () => res(s));
  });
  const addr = server.address();
  const port = typeof addr === "object" && addr ? addr.port : 0;
  base = `http://127.0.0.1:${port}`;
  host = `127.0.0.1:${port}`;
});

afterAll(() => {
  vi.unstubAllGlobals();
  server?.close();
});

const A = { authorization: "Bearer Alice.jwt" };
const B = { authorization: "Bearer Bob.jwt" };
const JSON_CT = { "content-type": "application/json" };

describe("Finding 1 — credentialed cross-origin is rejected on EVERY route (even embedded)", () => {
  const EVIL = "https://evil.manus.space"; // a parent-CORS-allowed origin that is NOT ours

  it("GET /api/session from a cross-origin page -> 403", async () => {
    const r = await realFetch(`${base}/api/session`, { headers: { ...A, origin: EVIL } });
    expect(r.status).toBe(403);
  });

  it("GET /api/conversations from a cross-origin page -> 403 (GET routes are gated too)", async () => {
    const r = await realFetch(`${base}/api/conversations`, { headers: { ...A, origin: EVIL } });
    expect(r.status).toBe(403);
  });

  it("POST /api/conversations from a cross-origin page -> 403", async () => {
    const r = await realFetch(`${base}/api/conversations`, {
      method: "POST",
      headers: { ...A, origin: EVIL, "x-app-origin": EVIL, ...JSON_CT },
      body: JSON.stringify({ scope: "global" }),
    });
    expect(r.status).toBe(403);
  });

  it("a *.run.app origin is also rejected", async () => {
    const r = await realFetch(`${base}/api/session`, { headers: { ...A, origin: "https://svc.run.app" } });
    expect(r.status).toBe(403);
  });

  it("same-origin (no Origin header) is allowed", async () => {
    const r = await realFetch(`${base}/api/session`, { headers: A });
    expect(r.status).toBe(200);
    expect((await r.json()).name).toBe("Alice");
  });

  it("a matching same-origin Origin (== Host) is allowed", async () => {
    const r = await realFetch(`${base}/api/session`, { headers: { ...A, origin: `http://${host}` } });
    expect(r.status).toBe(200);
  });

  it("health is reachable with any origin (no auth, no data)", async () => {
    const r = await realFetch(`${base}/api/health`, { headers: { origin: EVIL } });
    expect(r.status).toBe(200);
  });

  it("a cross-origin request leaks NO X-Rotated-Session header (rotated-token exfil closed)", async () => {
    // auth.me here returns a rotated token; the origin gate MUST run before
    // authenticate(), so a disallowed origin never triggers auth.me and the rotated
    // JWT is never relayed onto the 403 the attacker's JS could read. On the old
    // ordering (gate after authenticate) this header would be present -> takeover.
    const r = await realFetch(`${base}/api/session`, { headers: { ...A, origin: EVIL } });
    expect(r.status).toBe(403);
    expect(r.headers.get("x-rotated-session")).toBeNull();
  });
});

describe("isAllowedBrowserOrigin — unit (exercises the same-origin==Host branch directly)", () => {
  it("undefined Origin (same-origin GET / server-to-server) is allowed", () => {
    expect(isAllowedBrowserOrigin(undefined)).toBe(true);
  });
  it("localhost / 127.0.0.1 is allowed ONLY when the Host is also local (finding 2)", () => {
    expect(isAllowedBrowserOrigin("http://localhost:3000", "localhost:3000", "http")).toBe(true);
    expect(isAllowedBrowserOrigin("http://127.0.0.1:5173", "127.0.0.1:5173", "http")).toBe(true);
    expect(isAllowedBrowserOrigin("http://localhost:3000", "localhost:5173", "http")).toBe(false);
    expect(isAllowedBrowserOrigin("https://localhost:3000", "localhost:3000", "http")).toBe(false);
    // A malicious local page must NOT be trusted against a production host.
    expect(isAllowedBrowserOrigin("http://localhost:5173", "probate-pro.com")).toBe(false);
    expect(isAllowedBrowserOrigin("http://localhost:3000", undefined)).toBe(false);
  });
  it("same-origin on a NON-localhost host requires HTTPS", () => {
    expect(isAllowedBrowserOrigin("https://app.example.org", "app.example.org")).toBe(true);
    expect(isAllowedBrowserOrigin("http://app.example.org", "app.example.org")).toBe(false);
  });
  it("cross-origin (Origin host != Host, not in exact list) is rejected", () => {
    expect(isAllowedBrowserOrigin("https://evil.manus.space", "app.example.org")).toBe(false);
    expect(isAllowedBrowserOrigin("https://x.run.app", "app.example.org")).toBe(false);
  });
  it("null origin and a look-alike suffix are rejected", () => {
    expect(isAllowedBrowserOrigin("null", "app.example.org")).toBe(false);
    expect(isAllowedBrowserOrigin("https://probate-pro.com.evil.com", "app.example.org")).toBe(false);
    expect(isAllowedBrowserOrigin("https://probate-pro.com///", "probate-pro.com")).toBe(false);
  });
  it("the exact probate-pro.com backstop is allowed even under a host rewrite", () => {
    expect(isAllowedBrowserOrigin("https://probate-pro.com", "internal-host")).toBe(true);
    expect(isAllowedBrowserOrigin("http://probate-pro.com", "internal-host")).toBe(false);
  });
  it("a port mismatch (Origin authority != Host) is rejected", () => {
    expect(isAllowedBrowserOrigin("https://app.example.org:8443", "app.example.org")).toBe(false);
  });
});

describe("Finding 3 — two-user end-to-end isolation through the HTTP routes", () => {
  const ORIGIN = () => ({ origin: `http://${host}`, "x-app-origin": `http://${host}` });
  let convId: string;

  it("user A creates and reads her own conversation", async () => {
    const create = await realFetch(`${base}/api/conversations`, {
      method: "POST",
      headers: { ...A, ...ORIGIN(), ...JSON_CT },
      body: JSON.stringify({ scope: "global" }),
    });
    expect(create.status).toBe(200);
    convId = (await create.json()).id;
    expect(convId).toBeTruthy();
    const read = await realFetch(`${base}/api/conversations/${convId}`, { headers: A });
    expect(read.status).toBe(200);
  });

  it("user B cannot read user A's conversation by id -> 404", async () => {
    const r = await realFetch(`${base}/api/conversations/${convId}`, { headers: B });
    expect(r.status).toBe(404);
  });

  it("user B's conversation list does not include user A's conversation", async () => {
    const r = await realFetch(`${base}/api/conversations`, { headers: B });
    expect(r.status).toBe(200);
    const list = (await r.json()) as Array<{ id: string }>;
    expect(Array.isArray(list)).toBe(true);
    expect(list.find((c) => c.id === convId)).toBeUndefined();
  });

  it("user B cannot export user A's conversation -> 404", async () => {
    const r = await realFetch(`${base}/api/conversations/${convId}/export`, { headers: B });
    expect(r.status).toBe(404);
  });

  it("user B cannot delete user A's conversation, and A's survives", async () => {
    const del = await realFetch(`${base}/api/conversations/${convId}`, {
      method: "DELETE",
      headers: { ...B, ...ORIGIN() },
    });
    expect(del.status).toBe(404);
    const still = await realFetch(`${base}/api/conversations/${convId}`, { headers: A });
    expect(still.status).toBe(200);
  });

  it("user B cannot apply or dismiss a proposal owned by user A -> 404", async () => {
    // Seed a pending proposal for user A (id 1) directly in the store.
    const p = store.createProposal({
      userId: 1,
      conversationId: convId,
      estateId: "estate-A",
      kind: "intake",
      payload: { updates: [] },
      diff: { kind: "intake", estateId: "estate-A", estateName: "A", rows: [] },
    });
    const applyB = await realFetch(`${base}/api/proposals/${p.id}/apply`, {
      method: "POST",
      headers: { ...B, ...ORIGIN(), ...JSON_CT },
      body: "{}",
    });
    expect(applyB.status).toBe(404);
    const dismissB = await realFetch(`${base}/api/proposals/${p.id}/dismiss`, {
      method: "POST",
      headers: { ...B, ...ORIGIN(), ...JSON_CT },
      body: "{}",
    });
    expect(dismissB.status).toBe(404);
    // A's proposal is untouched (still pending).
    expect(store.getProposal(1, p.id)?.status).toBe("pending");
  });
});

describe("Finding 2 (mitigation) — gate-enforced by-convention isolation boundary", () => {
  // The in-process embed (59280b9) removed the structural process boundary, so
  // isolation is now by-convention. This guard is a TRIPWIRE, not a hard boundary
  // (in a shared process an app secret is readable at runtime regardless) — it
  // makes the convention enforceable: a chatbot source that reaches into the app
  // tree, pulls in the app's DB/ORM stack, or reads an app secret fails this gate.
  // NOTE: there is no repo CI (no .github/workflows); this runs via the root
  // `pnpm test:all` (= app vitest + `pnpm --dir chatbot test`) in the gate sequence.
  // Decision (2026-08-01): keep the embed + this tripwire; a separate process with
  // no JWT_SECRET/DB creds is the recommended future *structural* hardening, not a
  // current blocker — the exploitable hole (cross-origin, finding 1) is closed.
  // See chatbot/README.md "Security posture & residuals" and the ADR.
  const srcDir = join(process.cwd(), "src");

  // Recursive (red-team LOW: a future src subdir would otherwise be unscanned).
  const collect = (dir: string): string[] => {
    const out: string[] = [];
    for (const e of readdirSync(dir, { withFileTypes: true })) {
      const p = join(dir, e.name);
      if (e.isDirectory()) out.push(...collect(p));
      else if (e.name.endsWith(".ts")) out.push(p);
    }
    return out;
  };
  const files = collect(srcDir);

  // A relative climb OR an aliased/bare import into the app tree.
  const APP_TREE_IMPORT =
    /(?:from|import\s*\(\s*)["'](?:(?:\.\.\/)+(?:server|shared|client|drizzle)\b|@(?:server|shared|app|client|db|drizzle)\/|(?:server|shared|drizzle)\/)/;
  // Bare modules the bot must NEVER import: the app's data layer + the dead LLM
  // SDKs the raw-fetch Forge client replaced. (Bot deps: express, superjson, zod,
  // mammoth, pdf-parse, node: builtins.)
  const FORBIDDEN_MODULE =
    /from\s+["'](drizzle-orm|mysql2|@planetscale\/database|better-sqlite3|openai|@anthropic-ai\/sdk)\b/;
  // App secrets the bot must never read — dotted OR bracket access. The bot's OWN
  // BUILT_IN_FORGE_API_KEY is legitimately read and is intentionally NOT listed.
  const SECRET_NAMES = "JWT_SECRET|DATABASE_URL|DB_PASSWORD|DB_HOST|DB_USER|TIDB[_A-Z]*|DRIZZLE[_A-Z]*|SESSION_SECRET";
  const APP_SECRET = new RegExp(
    `process\\.env(?:\\.(?:${SECRET_NAMES})\\b|\\s*\\[\\s*["'](?:${SECRET_NAMES})["'])`,
  );

  it("has the full source set to check", () => {
    expect(files.length).toBeGreaterThan(8);
  });

  for (const f of files) {
    it(`${f.slice(srcDir.length + 1)}: no app-tree import, no app DB/ORM module, no app secret`, () => {
      const code = readFileSync(f, "utf-8");
      expect(code).not.toMatch(APP_TREE_IMPORT);
      expect(code).not.toMatch(FORBIDDEN_MODULE);
      expect(code).not.toMatch(APP_SECRET);
    });
  }
});
