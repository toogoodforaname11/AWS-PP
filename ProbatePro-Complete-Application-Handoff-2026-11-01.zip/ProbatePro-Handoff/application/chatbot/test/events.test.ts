/**
 * Regression: the session_rotated event's token must survive the NDJSON sink
 * un-redacted (it IS the fresh token being relayed to the session's owner),
 * while every other event is still scrubbed.
 */
import { describe, expect, it } from "vitest";
import { serializeEvent } from "../src/wire.js";

const JWT = "eyJhbGciOiJIUzI1NiJ9.eyJvcGVuSWQiOiJ4In0.c2lnbmF0dXJl";

describe("serializeEvent redaction policy", () => {
  it("keeps the rotation token intact so the widget stores a valid session", () => {
    const line = serializeEvent({ type: "session_rotated", value: `app_session_id=${JWT}` });
    const parsed = JSON.parse(line);
    expect(parsed.value).toBe(`app_session_id=${JWT}`);
    expect(parsed.value).not.toContain("REDACTED");
  });

  it("still redacts a token that leaks into any OTHER event", () => {
    const line = serializeEvent({ type: "error", message: `boom ${JWT}` });
    const parsed = JSON.parse(line);
    expect(parsed.message).not.toContain(JWT);
    expect(parsed.message).toContain("[REDACTED_JWT]");
  });
});
