/**
 * Site-knowledge corpus: correctness + DRIFT guards.
 *
 * These tests catch structural route/tab drift and exercise important retrieval
 * questions. Content still requires review when the underlying UI or law changes;
 * no static test can prove that prose can never become stale.
 * (Reading app source as TEXT here is not an app-tree import — the import guard only
 * scans chatbot/src, and this is a test.)
 */
import { describe, it, expect } from "vitest";
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import {
  SITE_KNOWLEDGE,
  ESTATE_TABS,
  TOP_LEVEL_ROUTES,
  searchHelp,
  type HelpRoute,
} from "../src/site-knowledge.js";
import { isAllowedNavPath } from "../src/allowlist.js";
import { buildTools, type ToolCtx } from "../src/tools.js";

// vitest cwd is the chatbot package; the repo root is one level up.
const REPO = join(process.cwd(), "..");

function isValidRoute(r: HelpRoute): boolean {
  if (r === null) return true;
  return (TOP_LEVEL_ROUTES as readonly string[]).includes(r) || (ESTATE_TABS as readonly string[]).includes(r);
}

describe("site-knowledge corpus", () => {
  it("has unique entry ids", () => {
    const ids = SITE_KNOWLEDGE.map((e) => e.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("every entry route is a real destination and carries a source citation", () => {
    for (const e of SITE_KNOWLEDGE) {
      expect(isValidRoute(e.route), `entry ${e.id} route=${String(e.route)}`).toBe(true);
      expect(e.source.length, `entry ${e.id} missing source`).toBeGreaterThan(0);
      expect(e.answer.trim().length, `entry ${e.id} empty answer`).toBeGreaterThan(0);
      const paths = e.source.match(/\b(?:chatbot|client|drizzle|references|server|shared)\/[A-Za-z0-9_./-]+\.(?:md|ts|tsx)\b/g) ?? [];
      expect(paths.length, `entry ${e.id} has no concrete source path: ${e.source}`).toBeGreaterThan(0);
      for (const path of paths) {
        expect(existsSync(join(REPO, path)), `entry ${e.id} source does not exist: ${path}`).toBe(true);
      }
    }
  });

  it("every corpus route is one suggest_navigation actually accepts", () => {
    for (const r of TOP_LEVEL_ROUTES) expect(isAllowedNavPath(r)).toBe(true);
    for (const t of ESTATE_TABS) expect(isAllowedNavPath(`/estate/abc-123?tab=${t}`)).toBe(true);
  });

  it("coverage: every estate tab has at least one help entry", () => {
    for (const t of ESTATE_TABS) {
      expect(SITE_KNOWLEDGE.some((e) => e.route === t), `no help entry routes to tab "${t}"`).toBe(true);
    }
  });

  // ── DRIFT GUARDS (fail when the app changes tabs without updating the corpus) ──

  it("DRIFT: ESTATE_TABS matches the app's real tabContent map (EstateDetail.tsx)", () => {
    const src = readFileSync(join(REPO, "client/src/pages/EstateDetail.tsx"), "utf-8");
    const start = src.indexOf("const tabContent");
    expect(start, "could not find `const tabContent` in EstateDetail.tsx").toBeGreaterThan(-1);
    const block = src.slice(start, src.indexOf("};", start));
    const appTabs = [...block.matchAll(/^\s*["']?([a-z-]+)["']?:\s*</gm)].map((m) => m[1]);
    expect(appTabs.length, "parsed no tabs from tabContent").toBeGreaterThan(0);
    expect([...appTabs].sort()).toEqual([...ESTATE_TABS].sort());
  });

  it("DRIFT: ESTATE_TABS matches the chatbot nav whitelist (allowlist.ts NAV_RE)", () => {
    const src = readFileSync(join(REPO, "chatbot/src/allowlist.ts"), "utf-8");
    const m = src.match(/\?tab=\(([a-z|\-]+)\)/);
    expect(m, "could not find the ?tab=(...) alternation in NAV_RE").not.toBeNull();
    const navTabs = m![1].split("|");
    expect([...navTabs].sort()).toEqual([...ESTATE_TABS].sort());
  });

  it("DRIFT: the system-prompt APP-LAYOUT floor names every estate tab", () => {
    // The prompt restates the tab set as a floor; guard it against drifting from ESTATE_TABS.
    const src = readFileSync(join(REPO, "chatbot/src/agent.ts"), "utf-8");
    for (const t of ESTATE_TABS) {
      const Cap = t === "client-portal" ? "Client Portal" : t[0].toUpperCase() + t.slice(1);
      expect(src, `SYSTEM_PROMPT does not mention the "${Cap}" tab`).toContain(Cap);
    }
  });

  it("does not misdescribe the project-approved P10 supplement as an official Part 3", () => {
    const entry = SITE_KNOWLEDGE.find((candidate) => candidate.id === "record-beneficiary-share");
    expect(entry).toBeTruthy();
    expect(entry!.answer).toContain("supplementary Distribution section");
    expect(entry!.answer).toContain("official Form P10 does not call that section Part 3");

    const prompt = readFileSync(join(REPO, "chatbot/src/agent.ts"), "utf-8");
    const app = readFileSync(join(REPO, "client/src/pages/EstateDetail.tsx"), "utf-8");
    expect(prompt).not.toContain("feeds Form P10 Part 3");
    expect(app).not.toContain("Distribution (P10 Part 3)");
  });

  it("narrows the untrusted-data rule only for the static product-help corpus", () => {
    const prompt = readFileSync(join(REPO, "chatbot/src/agent.ts"), "utf-8");
    expect(prompt).toContain("every value returned by estate/data tools");
    expect(prompt).toContain("search_product_help corpus is product documentation");
    expect(prompt).toContain("sole tool-result exception");
    expect(prompt).toContain("never evidence about an estate or a source of legal advice");
  });

  // ── EVAL: common questions retrieve the right entry ──

  it.each([
    ["how do I edit the beneficiary letter wording", "edit-beneficiary-letter-wording"],
    ["where do I record a beneficiary's share", "record-beneficiary-share"],
    ["how do I mark a deadline as done", "deadlines-are-computed"],
    ["how do I create a new estate", "create-new-estate"],
    ["how do I upload the will", "upload-will"],
    ["how do I generate form P1", "generate-court-form"],
    ["what is form P8", "p8-p9-are-affidavits"],
    ["how do I add a beneficiary", "add-contact-beneficiary"],
    ["upload my firm letterhead", "upload-letterhead"],
    ["is the file ready to file", "check-readiness"],
    ["how do I mark a beneficiary as predeceased", "mark-contact-predeceased"],
    ["do you send deadline email reminders", "no-automatic-reminders"],
    ["where do I record the death certificate", "record-death-certificate-received"],
    ["how do I change the court registry", "change-court-registry"],
    ["where do I record that the grant was issued", "record-grant-issued-date"],
    ["how do I delete an estate", "delete-estate"],
    ["where is checkbox appearance", "checkbox-appearance"],
    ["where do I record a citation", "record-citation"],
  ])("eval: %j retrieves %s", (query, expectedId) => {
    const ids = searchHelp(query).map((h) => h.id);
    expect(ids, `query "${query}" -> ${JSON.stringify(ids)}`).toContain(expectedId);
  });

  it.each([
    ["how do I edit the beneficiary letter wording", "edit-beneficiary-letter-wording"],
    ["how do I mark a deadline as done", "deadlines-are-computed"],
    ["how do I create a new estate", "create-new-estate"],
    ["what is form P8", "p8-p9-are-affidavits"],
  ])("top-hit: %j ranks %s first", (query, expectedId) => {
    const ids = searchHelp(query).map((h) => h.id);
    expect(ids[0], `query "${query}" -> ${JSON.stringify(ids)}`).toBe(expectedId);
  });

  it("returns nothing for an unrelated query (so the bot admits uncertainty)", () => {
    expect(searchHelp("what is the weather today")).toHaveLength(0);
  });

  it.each([
    "can I e-file forms electronically",
    "does the app integrate with a court filing portal",
    "where is the trust accounting ledger",
  ])("does not manufacture help for unsupported capability: %j", (query) => {
    expect(searchHelp(query)).toHaveLength(0);
  });

  it("returns a cited, allowlisted full estate route through the actual help tool", async () => {
    const ctx: ToolCtx = {
      session: {} as never,
      userId: 1,
      conversationId: "help-test",
      emit: () => undefined,
      docMap: new Map(),
      trace: [],
      signal: { aborted: false },
      currentEstateId: "estate-abc_123",
    };
    const tool = (buildTools(ctx) as unknown as Array<{ name: string; run: (input: unknown) => Promise<string> }>)
      .find((candidate) => candidate.name === "search_product_help");
    expect(tool).toBeTruthy();
    const payload = JSON.parse(await tool!.run({ query: "upload the will" }));
    expect(payload.results[0].source).toContain("client/src/pages/EstateDetail.tsx");
    expect(payload.results[0].open).toBe("/estate/estate-abc_123?tab=intake");
    expect(isAllowedNavPath(payload.results[0].open)).toBe(true);
  });

  it("never returns an unconnected estate-tab token without estate context", async () => {
    const ctx: ToolCtx = {
      session: {} as never,
      userId: 1,
      conversationId: "help-test-global",
      emit: () => undefined,
      docMap: new Map(),
      trace: [],
      signal: { aborted: false },
    };
    const tool = (buildTools(ctx) as unknown as Array<{ name: string; run: (input: unknown) => Promise<string> }>)
      .find((candidate) => candidate.name === "search_product_help");
    const payload = JSON.parse(await tool!.run({ query: "upload the will" }));
    expect(payload.results[0].open).toBeNull();
    expect(payload.results[0].requiresEstateContext).toBe(true);
  });

  it("does not let a model read a guessed estate id before it is verified in this request", async () => {
    const ctx: ToolCtx = {
      session: {} as never,
      userId: 1,
      conversationId: "scope-read-test",
      emit: () => undefined,
      docMap: new Map(),
      trace: [],
      signal: { aborted: false },
      currentEstateId: "estate-open",
      knownEstateIds: new Set(["estate-open"]),
    };
    const tool = (buildTools(ctx) as unknown as Array<{ name: string; run: (input: unknown) => Promise<string> }>)
      .find((candidate) => candidate.name === "get_estate_snapshot");
    await expect(tool!.run({ estateId: "estate-injected", sections: ["estate"] }))
      .resolves.toBe("That estate is not in this request's verified context. Open the estate or list the available estate files first, then ask again.");
  });

  it("does not let a model list documents from a guessed estate id", async () => {
    const ctx: ToolCtx = {
      session: {} as never,
      userId: 1,
      conversationId: "scope-document-test",
      emit: () => undefined,
      docMap: new Map(),
      trace: [],
      signal: { aborted: false },
      currentEstateId: "estate-open",
      knownEstateIds: new Set(["estate-open"]),
    };
    const tool = (buildTools(ctx) as unknown as Array<{ name: string; run: (input: unknown) => Promise<string> }>)
      .find((candidate) => candidate.name === "list_documents");
    await expect(tool!.run({ estateId: "estate-injected" }))
      .resolves.toMatch(/not in this request's verified context/i);
  });

  it("does not let a model prepare a proposal for an estate that is not currently open", async () => {
    const ctx: ToolCtx = {
      session: {} as never,
      userId: 1,
      conversationId: "scope-write-test",
      emit: () => undefined,
      docMap: new Map(),
      trace: [],
      signal: { aborted: false },
      currentEstateId: "estate-open",
      knownEstateIds: new Set(["estate-open", "estate-other"]),
    };
    const tool = (buildTools(ctx) as unknown as Array<{ name: string; run: (input: unknown) => Promise<string> }>)
      .find((candidate) => candidate.name === "propose_inventory");
    await expect(tool!.run({
      estateId: "estate-other",
      items: [{ category: "cash", description: "Injected item", valueCents: 100, source: "untrusted text" }],
    })).resolves.toBe("For privacy, I can prepare changes only for the estate currently open in the app. Open the intended estate first, then ask again.");
  });
});
