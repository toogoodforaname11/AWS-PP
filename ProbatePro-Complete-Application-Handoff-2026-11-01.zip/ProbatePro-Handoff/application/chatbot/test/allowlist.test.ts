/**
 * The security-load-bearing checks: field allowlists, the deny-by-default
 * procedure registry, redaction, navigation whitelist, and the superjson wire
 * shape. These are the pieces where a silent regression turns into an LLM
 * writing arbitrary sworn-document columns.
 */
import { describe, expect, it } from "vitest";
import superjson from "superjson";
import {
  ALLOWED_PROCEDURES,
  CONTACT_FIELD_ALLOWLIST,
  INTAKE_FIELD_ALLOWLIST,
  KNOWN_CONTACT_ROLES,
  isAllowedNavPath,
  isKnownContactRole,
  isValidYmd,
} from "../src/allowlist.js";
import {
  detectIntakeDrift,
  validateContacts,
  validateIntakeUpdates,
  validateInventory,
} from "../src/proposals.js";
import { redact, registerSecret } from "../src/redact.js";
import { TOOL_NAMES, compactRecord } from "../src/tools.js";
import { sanitizeAttachmentSmoke } from "./helpers.js";

describe("intake field allowlist (C-16)", () => {
  it("accepts a plausible extraction set", () => {
    const { accepted, rejected } = validateIntakeUpdates([
      { field: "deceasedFirstName", value: "Mary", source: "will.pdf p.1" },
      { field: "dateOfDeath", value: "2026-01-15", source: "death certificate" },
      { field: "addressCity", value: "Victoria", source: "will.pdf p.1" },
    ]);
    expect(rejected).toEqual([]);
    expect(accepted).toHaveLength(3);
  });

  it("rejects system/workflow/derived columns — the forbidden classes", () => {
    const forbidden = [
      "id",
      "createdByUserId",
      "fileNumber",
      "status",
      "fileType",
      "grantType",
      "hasWill",
      "partialIntestacy",
      "testatePortionCents",
      "testatePortionRecorded",
      "willStorageKey",
      "willFilePath",
      "codicilFiles",
      "domicileCity", // oath city ONLY (Nick ruling 2026-07-26, RULES.md Rule 12)
      "juratCity",
      "oathType",
      "spouseStatus",
      "createdAt",
    ];
    const { accepted, rejected } = validateIntakeUpdates(
      forbidden.map((field) => ({ field, value: "x", source: "attack" })),
    );
    expect(accepted).toEqual([]);
    expect(rejected).toHaveLength(forbidden.length);
  });

  it("requires provenance on every field (C-17)", () => {
    const { accepted, rejected } = validateIntakeUpdates([
      { field: "deceasedLastName", value: "Chan", source: "" },
    ]);
    expect(accepted).toEqual([]);
    expect(rejected[0].reason).toContain("source");
  });

  it("validates date shape and yes/no enums", () => {
    const { rejected } = validateIntakeUpdates([
      { field: "dateOfBirth", value: "Jan 5, 1950", source: "doc" },
      { field: "hasOtherNames", value: "maybe", source: "doc" },
    ]);
    expect(rejected).toHaveLength(2);
  });

  it("rejects impossible-but-well-formed dates (finding #6)", () => {
    // Right shape, wrong calendar — the old regex accepted these and let them
    // flow toward sworn forms and deadlines.
    const { accepted, rejected } = validateIntakeUpdates([
      { field: "dateOfDeath", value: "2026-02-31", source: "doc" },
      { field: "dateOfBirth", value: "2026-99-99", source: "doc" },
      { field: "willDate", value: "2026-00-10", source: "doc" },
    ]);
    expect(accepted).toEqual([]);
    expect(rejected).toHaveLength(3);
    // Round-trip validator agrees with shared/date-utils.parseYmd's semantics.
    expect(isValidYmd("2026-02-28")).toBe(true);
    expect(isValidYmd("2024-02-29")).toBe(true); // leap year
    expect(isValidYmd("2026-02-29")).toBe(false); // not a leap year
    expect(isValidYmd("2026-13-01")).toBe(false);
  });

  it("SNAPSHOT: the allowlist itself — additions must be deliberate", () => {
    expect(Object.keys(INTAKE_FIELD_ALLOWLIST).sort()).toEqual(
      [
        "addressCity",
        "addressCountry",
        "addressPostalCode",
        "addressProvince",
        "addressStreet",
        "addressUnit",
        "akaFirstName",
        "akaLastName",
        "akaMiddleName",
        "courtFileNumber",
        "dateOfBirth",
        "dateOfDeath",
        "deceasedAddress",
        "deceasedAliases",
        "deceasedFirstName",
        "deceasedGender",
        "deceasedLastName",
        "deceasedMiddleNames",
        "deceasedOccupation",
        "deceasedPostOfficeBox",
        "deceasedResidenceCity",
        "deceasedSecondMiddleName",
        "estateName",
        "hasOtherNames",
        "maritalStatus",
        "placeOfBirth",
        "registry",
        "willDate",
      ].sort(),
    );
  });
});

describe("intake stale-write guard (finding #3)", () => {
  const rows = [
    { key: "deceasedLastName", label: "Deceased's last name", oldValue: "Chan", newValue: "Chen", source: "will.pdf" },
    { key: "dateOfDeath", label: "Date of death", oldValue: "", newValue: "2026-01-15", source: "death cert" },
  ];

  it("no drift when current values still match the propose-time snapshot", () => {
    const current = { deceasedLastName: "Chan", dateOfDeath: "" };
    expect(detectIntakeDrift(rows, current)).toEqual([]);
  });

  it("flags a field a staff member changed since the proposal was built", () => {
    // Someone set the last name to "Chang" after the proposal captured "Chan".
    const current = { deceasedLastName: "Chang", dateOfDeath: "" };
    expect(detectIntakeDrift(rows, current)).toEqual(["Deceased's last name"]);
  });

  it("treats a now-populated previously-empty field as drift (no silent clobber)", () => {
    const current = { deceasedLastName: "Chan", dateOfDeath: "2026-01-01" };
    expect(detectIntakeDrift(rows, current)).toEqual(["Date of death"]);
  });
});

describe("contact allowlist (silent-drop parity, C-18)", () => {
  it("rejects keys not on the app's create whitelist instead of silently dropping", () => {
    const { accepted, rejected } = validateContacts([
      { fields: { role: "executor", executorRank: "primary" }, source: "will.pdf" },
    ]);
    expect(accepted).toEqual([]);
    expect(rejected[0].field).toContain("executorRank");
  });

  it("requires a role", () => {
    const { rejected } = validateContacts([{ fields: { name: "Bob" }, source: "will" }]);
    expect(rejected[0].reason).toContain("role");
  });

  it("rejects a model-invented role the app would silently ignore (finding #3)", () => {
    const { accepted, rejected } = validateContacts([
      { fields: { role: "heir", name: "Sam" }, source: "will" },
      { fields: { role: "next_of_kin", name: "Pat" }, source: "will" },
    ]);
    expect(accepted).toEqual([]);
    expect(rejected).toHaveLength(2);
    expect(rejected[0].reason).toContain("unknown role");
  });

  it("accepts recognized roles, case-insensitively, incl. comma-combined", () => {
    const { accepted, rejected } = validateContacts([
      { fields: { role: "executor", name: "A" }, source: "will" },
      { fields: { role: "Beneficiary", name: "B" }, source: "will" },
      { fields: { role: "executor,beneficiary", name: "C" }, source: "will" },
      // Previously over-rejected — these ARE user-assignable / app-recognized.
      { fields: { role: "administrator", name: "D" }, source: "will" },
      { fields: { role: "guardian", name: "E" }, source: "will" },
      { fields: { role: "citor", name: "F" }, source: "will" },
    ]);
    expect(rejected).toEqual([]);
    expect(accepted).toHaveLength(6);
    // A single bad token in a comma list still fails.
    expect(isKnownContactRole("executor,made_up")).toBe(false);
    expect(isKnownContactRole("")).toBe(false);
    expect(isKnownContactRole("heir")).toBe(false); // canonical is "beneficiary"
    expect(KNOWN_CONTACT_ROLES.has("intestate_successor")).toBe(true);
    // Phantom role — badge-only, no legal-pipeline consumer (ChatGPT #5).
    expect(isKnownContactRole("intestate_successor_candidate")).toBe(false);
  });

  it("every allowed contact field is on the app's contact.create whitelist", () => {
    // Verified against server/routers.ts:1659-1811 — a field here that the
    // server drops would "apply" without writing (sworn-record correctness).
    const serverWhitelist = new Set([
      "role", "name", "address", "addressForService", "residentialAddress", "postalAddress",
      "faxNumber", "email", "phone", "cityCountry", "relationship", "deliveryMethod",
      "deliveryDate", "executorStatus", "isMinor", "isMentallyIncapable", "isPredeceased",
      "recipientType", "renunciationReason", "appointedTrustee", "addressFormatOverride",
      "guardianName", "minorDeliveryBranch", "occupation", "firmName", "hasCommittee",
      "committeeType", "committeeName", "committeeAddress", "committeeJurisdiction",
      "executorRank", "executorRankNumber", "applicantKind", "serviceFax", "claimAmountCents",
      "residenceStreet", "residenceCity", "residenceProvince", "residenceCountry",
      "nameAsInWill", "orgSignatoryName", "orgSignatoryTitle", "parentContactId", "side",
      "spousalShareBps", "priorityConsent", "priorityConsentDocumentKey",
      "priorityConsentInquiryDetails", "share", "shareType", "estimatedValue",
      "estimatedValueRecorded", "relationshipTerminated", "isCommonDescendant",
      "commonDescendantStatus", "relationshipDurationMonths", "pgtInfoReviewed",
    ]);
    for (const key of Object.keys(CONTACT_FIELD_ALLOWLIST)) {
      expect(serverWhitelist.has(key), `bot field "${key}" missing server-side`).toBe(true);
    }
  });
});

describe("inventory validation", () => {
  it("enforces category/location enums and integer cents", () => {
    const { accepted, rejected } = validateInventory([
      { category: "financial", description: "RBC chequing", valueCents: 1234500, source: "stmt" },
      { category: "crypto", description: "x", valueCents: 1, source: "s" },
      { category: "tangible", description: "car", valueCents: 99.5, source: "s" },
      { category: "tangible", description: "boat", valueCents: -1, source: "s" },
    ]);
    expect(accepted).toHaveLength(1);
    expect(rejected).toHaveLength(3);
  });
});

describe("procedure registry (deny-by-default, C-7)", () => {
  it("SNAPSHOT: the full callable surface — previewFile/docgen/delete are absent", () => {
    expect([...ALLOWED_PROCEDURES].sort()).toEqual(
      [
        "activity.list",
        "auth.me",
        "contact.create",
        "contact.list",
        // Added deliberately: without an EDIT path the assistant "corrected" a
        // person by creating a second copy, duplicating a party on a probate file.
        // Reachable only through a contact_updates proposal the user must Apply.
        "contact.update",
        "deadline.list",
        "distribution.compute",
        "document.list",
        "estate.get",
        "estate.list",
        "estate.update",
        // Content-free operational signal signed by the embedded route; never
        // selected by the model and rejected by the app without a fresh HMAC.
        "failureReports.recordChatbot",
        "inventory.bulkCreate",
        "inventory.list",
        "inventory.totals",
        "readiness.check",
        "readiness.timeline",
        "requiredDoc.list",
        "settings.get",
      ].sort(),
    );
    expect(ALLOWED_PROCEDURES.has("estate.previewFile")).toBe(false);
    expect(ALLOWED_PROCEDURES.has("document.generate")).toBe(false);
    expect(ALLOWED_PROCEDURES.has("estate.delete")).toBe(false);
    expect(ALLOWED_PROCEDURES.has("settings.get")).toBe(true);
  });

  it("SNAPSHOT: the tool registry", () => {
    expect([...TOOL_NAMES].sort()).toEqual(
      [
        "compute_distribution",
        "get_deadlines",
        "get_estate_snapshot",
        "get_readiness",
        "list_activity",
        "list_documents",
        "list_estates",
        "list_required_documents",
        "propose_contact_updates",
        "propose_contacts",
        "propose_intake_updates",
        "propose_inventory",
        "read_document",
        "search_product_help",
        "suggest_navigation",
      ].sort(),
    );
  });
});

describe("snapshot compaction never leaks storage keys (finding A / C-8)", () => {
  it("strips name-matched locators, *DocumentKey, and embedded-locator JSON", () => {
    const out = compactRecord({
      deceasedFirstName: "Mary",
      willStorageKey: "wills/estate-1_will.pdf", // name matches regex
      willFileName: "will.pdf",
      wesaS58OrderFilePath: "orders/x.pdf", // name matches regex
      priorityConsentDocumentKey: "consents/estate-1_consent.pdf", // bare key, *DocumentKey
      // Name ends in "Files" — slips the regex — but the VALUE embeds keys:
      codicilFiles: JSON.stringify([
        { storageKey: "codicils/estate-1_codicil_1.pdf", fileName: "c.pdf", mimeType: "application/pdf" },
      ]),
    });
    expect(out.deceasedFirstName).toBe("Mary");
    expect(out).not.toHaveProperty("willStorageKey");
    expect(out).not.toHaveProperty("willFileName");
    expect(out).not.toHaveProperty("wesaS58OrderFilePath");
    expect(out).not.toHaveProperty("priorityConsentDocumentKey");
    expect(out).not.toHaveProperty("codicilFiles");
    // Nothing that survived contains a storage-key token or path.
    expect(JSON.stringify(out)).not.toMatch(/storageKey|codicils\/|consents\//);
  });

  it("backstop drops any unforeseen value that embeds a locator token", () => {
    const out = compactRecord({
      note: "normal note",
      mysteryBlob: '{"storageKey":"secret/key.pdf"}', // unknown future column
    });
    expect(out.note).toBe("normal note");
    expect(out).not.toHaveProperty("mysteryBlob");
  });
});

describe("navigation whitelist (C-12)", () => {
  it("allows app routes and rejects everything else", () => {
    expect(isAllowedNavPath("/")).toBe(true);
    expect(isAllowedNavPath("/deadlines")).toBe(true);
    expect(isAllowedNavPath("/estate/abc123?tab=inventory")).toBe(true);
    expect(isAllowedNavPath("/estate/abc123")).toBe(true);
    expect(isAllowedNavPath("https://evil.example")).toBe(false);
    expect(isAllowedNavPath("/estate/abc?tab=evil")).toBe(false);
    expect(isAllowedNavPath("/portal")).toBe(false);
    expect(isAllowedNavPath("//evil.example")).toBe(false);
  });
});

describe("redaction (C-3)", () => {
  it("scrubs JWTs, provider keys, auth headers, and session pairs", () => {
    const dirty = [
      "token eyJhbGciOiJIUzI1NiJ9.eyJvcGVuSWQiOiJ4In0.c2lnbmF0dXJlLXNpZ25hdHVyZQ",
      'authorization: "Bearer abc123"',
      "sk-ant-api03-verysecretkey123",
      "forge_key_thisisalsoverysecret123",
      "Cookie: app_session_id=sometokenvalue; other=1",
    ].join("\n");
    const clean = redact(dirty);
    expect(clean).not.toContain("eyJhbGciOiJIUzI1NiJ9");
    expect(clean).not.toContain("verysecretkey");
    expect(clean).not.toContain("thisisalsoverysecret");
    expect(clean).not.toContain("abc123");
    expect(clean).not.toContain("sometokenvalue");
    expect(clean).toContain("[REDACTED_JWT]");
    expect(clean).toContain("[REDACTED_KEY]");
  });

  it("scrubs a registered literal secret whose format the sk-/forge- patterns miss", () => {
    // Manus may issue the Forge key as a bare hex/UUID token matching no pattern;
    // registering its literal value guarantees it is still stripped from sinks
    // (e.g. a Forge error body that reflects the Authorization header).
    const oddKey = "9f2c1a7b4e6d40f8b3e2c5a1d7f09b6e";
    registerSecret(oddKey);
    // Neutral context (no "authorization="/"sk-"/"forge-") so ONLY the value-based
    // path can catch it — proves literal-secret scrubbing on its own.
    const clean = redact(`Forge upstream reflected the raw token ${oddKey} in its error body`);
    expect(clean).not.toContain(oddKey);
    expect(clean).toContain("[REDACTED_KEY]");
  });
});

describe("superjson wire shape", () => {
  it("serializes plain input the way the app's tRPC transformer expects", () => {
    const wire = superjson.serialize({ id: "abc" });
    expect(JSON.parse(JSON.stringify(wire))).toEqual({ json: { id: "abc" } });
  });
  it("round-trips a result envelope", () => {
    const payload = superjson.serialize({ ok: true, when: new Date("2026-01-01T00:00:00Z") });
    const back = superjson.deserialize(JSON.parse(JSON.stringify(payload))) as any;
    expect(back.ok).toBe(true);
    expect(back.when).toBeInstanceOf(Date);
  });
});

describe("attachment sanitation", () => {
  it("wraps untrusted content and strips embedded delimiters", () => {
    sanitizeAttachmentSmoke();
  });
});
