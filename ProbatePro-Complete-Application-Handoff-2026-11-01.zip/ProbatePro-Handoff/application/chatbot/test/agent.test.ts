/**
 * Offline coverage for the raw-fetch Forge tool loop (runChat). Mocks global
 * fetch so no network or LLM is touched. It proves the loop (a) builds
 * JSON-Schema tool specs for EVERY tool without throwing — the regression that
 * took down production when zodFunction was used under Zod v4 — (b) dispatches a
 * tool call, validates its args, runs it, feeds the result back, and returns the
 * model's final text, (c) requests and incrementally parses SSE streaming while
 * sending NO `max_tokens`, (d) coerces JSON fallback array-form content, and
 * (e) rejects backend failures/aborts so the route cannot persist fake success.
 */
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { afterEach, describe, expect, it, vi } from "vitest";
import { FORGE_TIMEOUT_MS, runChat } from "../src/agent.js";
import type { BotEvent, ToolCtx } from "../src/tools.js";

/** Tests run with cwd = chatbot/, matching site-knowledge.test.ts. */
const REPO = join(process.cwd(), "..");

function makeCtx(events: BotEvent[], signal: AbortSignal): ToolCtx {
  return {
    session: {} as never,
    userId: 1,
    conversationId: "c1",
    emit: (e) => events.push(e),
    docMap: new Map(),
    trace: [],
    signal,
  };
}

function jsonResponse(obj: unknown, status = 200): Response {
  return new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json" } });
}

function sseResponse(payloads: unknown[]): Response {
  const encoded = new TextEncoder().encode(
    payloads.map((payload) => `data: ${JSON.stringify(payload)}\n\n`).join("") + "data: [DONE]\n\n",
  );
  // Split at awkward offsets so the parser proves it handles partial lines and
  // partial JSON values rather than relying on one network chunk per event.
  const cuts = [17, 43, 89, encoded.length];
  let start = 0;
  const body = new ReadableStream<Uint8Array>({
    start(controller) {
      for (const end of cuts) {
        if (end > start) controller.enqueue(encoded.slice(start, Math.min(end, encoded.length)));
        start = end;
        if (start >= encoded.length) break;
      }
      controller.close();
    },
  });
  return new Response(body, { status: 200, headers: { "content-type": "text/event-stream" } });
}

type ReqBody = {
  max_tokens?: unknown;
  stream?: boolean;
  tools?: Array<{ function: { parameters: unknown } }>;
  messages: Array<{ role: string; tool_call_id?: string; content?: unknown }>;
};

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
});

describe("runChat — raw Forge tool loop", () => {
  it("builds tool specs for every tool, dispatches a tool call, returns final text, sends no max_tokens", async () => {
    let call = 0;
    let firstBody: ReqBody | null = null;
    let secondBody: ReqBody | null = null;
    vi.stubGlobal(
      "fetch",
      vi.fn(async (url: unknown, init: { body: string }) => {
        const u = String(url);
        if (!u.includes("/chat/completions")) throw new Error("unexpected fetch: " + u);
        call++;
        if (call === 1) {
          firstBody = JSON.parse(init.body);
          return sseResponse([
            {
              choices: [{ delta: { tool_calls: [{ index: 0, id: "call_1", type: "function", function: { name: "suggest_navigation", arguments: '{"path":"/dead' } }] } }],
            },
            {
              choices: [{ delta: { tool_calls: [{ index: 0, function: { arguments: 'lines","label":"Open deadlines"}' } }] }, finish_reason: "tool_calls" }],
            },
          ]);
        }
        secondBody = JSON.parse(init.body);
        return sseResponse([
          { choices: [{ delta: { content: "Here are " } }] },
          { choices: [{ delta: { content: "your deadlines." }, finish_reason: "stop" }] },
        ]);
      }),
    );

    const events: BotEvent[] = [];
    const controller = new AbortController();
    const ctx = makeCtx(events, controller.signal);
    const out = await runChat({
      ctx,
      history: [],
      userText: "open deadlines",
      attachmentBlocks: [],
      pageContext: { path: "/", estateId: null, tab: null },
      signal: controller.signal,
    });

    expect(call).toBe(2);
    expect(out).toBe("Here are your deadlines.");
    expect(events).toContainEqual({ type: "navigate", path: "/deadlines", label: "Open deadlines" });
    const streamedText = events
      .filter((e): e is Extract<BotEvent, { type: "text_delta" }> => e.type === "text_delta")
      .map((e) => e.text);
    expect(streamedText).toEqual(["Here are ", "your deadlines."]);
    expect(streamedText.join("")).toBe("Here are your deadlines.");

    // NO max_tokens on any request (gpt-5 rejects it; the proven Forge call omits it).
    expect(firstBody!.max_tokens).toBeUndefined();
    expect(secondBody!.max_tokens).toBeUndefined();
    expect(firstBody!.stream).toBe(true);
    expect(secondBody!.stream).toBe(true);

    // 2nd request carried the assistant tool-call turn + the matching tool result.
    const roles = secondBody!.messages.map((m) => m.role);
    expect(roles).toContain("assistant");
    expect(roles).toContain("tool");
    expect(secondBody!.messages.find((m) => m.role === "tool")!.tool_call_id).toBe("call_1");

    // Regression guard: every advertised tool has a JSON-Schema parameters object
    // (the old openai/zodFunction path threw here under Zod v4).
    expect(firstBody!.tools!.length).toBeGreaterThanOrEqual(13);
    for (const t of firstBody!.tools!) expect(typeof t.function.parameters).toBe("object");
  });

  it("adds the persisted detailed response-style preference to the Forge system instruction", async () => {
    let body: ReqBody | null = null;
    vi.stubGlobal("fetch", vi.fn(async (_url: unknown, init: { body: string }) => {
      body = JSON.parse(init.body);
      return sseResponse([{ choices: [{ delta: { content: "Ready." }, finish_reason: "stop" }] }]);
    }));

    const controller = new AbortController();
    await expect(runChat({
      ctx: makeCtx([], controller.signal),
      history: [],
      userText: "status",
      attachmentBlocks: [],
      pageContext: { path: "/", estateId: null, tab: null },
      responseStyle: "detailed",
      signal: controller.signal,
    })).resolves.toBe("Ready.");

    const system = body!.messages.find((message) => message.role === "system")!.content;
    expect(system).toContain("USER RESPONSE PREFERENCE");
    expect(system).toContain("additional practical context");
    expect(system).toContain("legal-advice limits");
  });

  it("passes the authenticated signed-in profile to the model as trusted session context", async () => {
    let body: ReqBody | null = null;
    vi.stubGlobal("fetch", vi.fn(async (_url: unknown, init: { body: string }) => {
      body = JSON.parse(init.body);
      return sseResponse([{ choices: [{ delta: { content: "Hello Alex." }, finish_reason: "stop" }] }]);
    }));

    const controller = new AbortController();
    await expect(runChat({
      ctx: makeCtx([], controller.signal),
      history: [],
      userText: "Who am I signed in as?",
      attachmentBlocks: [],
      pageContext: { path: "/", estateId: null, tab: null },
      userProfile: { name: "Alex Chen", email: "alex@example.test" },
      signal: controller.signal,
    })).resolves.toBe("Hello Alex.");

    const system = String(body!.messages.find((message) => message.role === "system")!.content);
    expect(system).toContain("SIGNED-IN USER PROFILE");
    expect(system).toContain("name: Alex Chen");
    expect(system).toContain("email: alex@example.test");
    expect(system).toContain("not instructions");
  });

  it("coerces array-form assistant content (Forge may return content parts, not a string)", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () =>
        jsonResponse({
          choices: [
            {
              message: {
                role: "assistant",
                content: [
                  { type: "text", text: "The estate " },
                  { type: "text", text: "has 3 beneficiaries." },
                ],
              },
              finish_reason: "stop",
            },
          ],
        }),
      ),
    );
    const events: BotEvent[] = [];
    const controller = new AbortController();
    const ctx = makeCtx(events, controller.signal);
    const out = await runChat({
      ctx,
      history: [],
      userText: "summarize",
      attachmentBlocks: [],
      pageContext: undefined,
      signal: controller.signal,
    });
    expect(out).toBe("The estate has 3 beneficiaries.");
    expect(events.some((e) => e.type === "text_delta" && e.text === "The estate has 3 beneficiaries.")).toBe(true);
  });

  it("rejects a Forge error without emitting a fake assistant text delta", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => jsonResponse({ error: "boom" }, 500)));
    const events: BotEvent[] = [];
    const controller = new AbortController();
    const ctx = makeCtx(events, controller.signal);
    await expect(runChat({
      ctx,
      history: [],
      userText: "hi",
      attachmentBlocks: [],
      pageContext: undefined,
      signal: controller.signal,
    })).rejects.toThrow("Forge 500");
    expect(events.some((e) => e.type === "text_delta")).toBe(false);
  });

  it("retries one transient Forge HTTP failure before streaming a response", async () => {
    vi.useFakeTimers();
    const fetchMock = vi.fn()
      .mockResolvedValueOnce(jsonResponse({ error: "temporary" }, 503))
      .mockResolvedValueOnce(jsonResponse({
        choices: [{ message: { role: "assistant", content: "Recovered response." } }],
      }));
    vi.stubGlobal("fetch", fetchMock);
    const events: BotEvent[] = [];
    const controller = new AbortController();
    const ctx = makeCtx(events, controller.signal);
    const pending = runChat({
      ctx,
      history: [],
      userText: "recover",
      attachmentBlocks: [],
      pageContext: undefined,
      signal: controller.signal,
    });

    await vi.advanceTimersByTimeAsync(300);
    await expect(pending).resolves.toBe("Recovered response.");
    expect(fetchMock).toHaveBeenCalledTimes(2);
    expect(events).toContainEqual({ type: "text_delta", text: "Recovered response." });
  });

  it("rejects a truncated SSE response instead of persisting partial text as success", async () => {
    const encoded = new TextEncoder().encode(
      `data: ${JSON.stringify({ choices: [{ delta: { content: "partial" } }] })}\n\n`,
    );
    vi.stubGlobal("fetch", vi.fn(async () => new Response(
      new ReadableStream<Uint8Array>({
        start(controller) {
          controller.enqueue(encoded);
          controller.close();
        },
      }),
      { status: 200, headers: { "content-type": "text/event-stream" } },
    )));
    const events: BotEvent[] = [];
    const controller = new AbortController();
    const ctx = makeCtx(events, controller.signal);

    await expect(runChat({
      ctx,
      history: [],
      userText: "hi",
      attachmentBlocks: [],
      pageContext: undefined,
      signal: controller.signal,
    })).rejects.toThrow("Forge stream ended before a terminal event");
    expect(events).toContainEqual({ type: "text_delta", text: "partial" });
  });

  it("does not call Forge once the turn is aborted", async () => {
    const fetchMock = vi.fn(async () => jsonResponse({ choices: [{ message: { role: "assistant", content: "hi" } }] }));
    vi.stubGlobal("fetch", fetchMock);
    const events: BotEvent[] = [];
    const controller = new AbortController();
    const ctx = makeCtx(events, controller.signal);
    controller.abort();
    await expect(runChat({ ctx, history: [], userText: "x", attachmentBlocks: [], pageContext: undefined, signal: controller.signal }))
      .rejects.toMatchObject({ name: "AbortError" });
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("aborts an in-flight Forge fetch when the client stops", async () => {
    const controller = new AbortController();
    vi.stubGlobal(
      "fetch",
      vi.fn((_url: unknown, init: RequestInit) => new Promise<Response>((_resolve, reject) => {
        init.signal?.addEventListener("abort", () => reject(new DOMException("aborted", "AbortError")), { once: true });
      })),
    );
    const events: BotEvent[] = [];
    const ctx = makeCtx(events, controller.signal);
    const pending = runChat({ ctx, history: [], userText: "x", attachmentBlocks: [], pageContext: undefined, signal: controller.signal });
    controller.abort();
    await expect(pending).rejects.toMatchObject({ name: "AbortError" });
  });

  it("times out a hung Forge fetch instead of holding the concurrency slot forever", async () => {
    vi.useFakeTimers();
    const controller = new AbortController();
    vi.stubGlobal(
      "fetch",
      vi.fn((_url: unknown, init: RequestInit) => new Promise<Response>((_resolve, reject) => {
        init.signal?.addEventListener("abort", () => reject(new DOMException("aborted", "AbortError")), { once: true });
      })),
    );
    const events: BotEvent[] = [];
    const ctx = makeCtx(events, controller.signal);
    const pending = runChat({ ctx, history: [], userText: "x", attachmentBlocks: [], pageContext: undefined, signal: controller.signal });
    const rejected = expect(pending).rejects.toThrow("Forge request timed out");
    await vi.advanceTimersByTimeAsync(FORGE_TIMEOUT_MS);
    await rejected;
  });

  it("throws (never fakes success) when the tool loop never reaches a final answer", async () => {
    // Model asks for a tool on EVERY turn and never stops → the loop must hit the
    // iteration cap and throw, not silently return an empty/degraded turn.
    const fetchMock = vi.fn(async (url: unknown) => {
      if (!String(url).includes("/chat/completions")) throw new Error("unexpected fetch");
      return sseResponse([
        {
          choices: [{
            delta: { tool_calls: [{ index: 0, id: "call_loop", type: "function", function: { name: "suggest_navigation", arguments: '{"path":"/deadlines","label":"Open deadlines"}' } }] },
            finish_reason: "tool_calls",
          }],
        },
      ]);
    });
    vi.stubGlobal("fetch", fetchMock);
    const events: BotEvent[] = [];
    const controller = new AbortController();
    const ctx = makeCtx(events, controller.signal);

    await expect(runChat({
      ctx, history: [], userText: "loop forever", attachmentBlocks: [],
      pageContext: undefined, signal: controller.signal,
    })).rejects.toThrow(/tool budget exceeded 8/);
    expect(fetchMock).toHaveBeenCalledTimes(9);
  });

  it("rejects an oversized parallel tool batch before executing any call", async () => {
    const toolCalls = Array.from({ length: 5 }, (_, index) => ({
      id: `call_${index}`,
      type: "function",
      function: { name: "suggest_navigation", arguments: '{"path":"/deadlines","label":"Open"}' },
    }));
    vi.stubGlobal("fetch", vi.fn(async () => jsonResponse({ choices: [{ message: { role: "assistant", content: "", tool_calls: toolCalls } }] })));
    const events: BotEvent[] = [];
    const controller = new AbortController();
    await expect(runChat({
      ctx: makeCtx(events, controller.signal), history: [], userText: "do many things", attachmentBlocks: [],
      pageContext: undefined, signal: controller.signal,
    })).rejects.toThrow(/maximum is 4/);
    expect(events.some((event) => event.type === "navigate" || event.type === "tool_start")).toBe(false);
  });

  it("throws (never fakes success) when the model finishes with an empty final response", async () => {
    // No tool calls (loop completes) but the assistant text is whitespace-only →
    // must throw rather than persist an empty assistant turn as a success.
    vi.stubGlobal("fetch", vi.fn(async () => jsonResponse({
      choices: [{ message: { role: "assistant", content: "   \n  " }, finish_reason: "stop" }],
    })));
    const events: BotEvent[] = [];
    const controller = new AbortController();
    const ctx = makeCtx(events, controller.signal);

    await expect(runChat({
      ctx, history: [], userText: "hi", attachmentBlocks: [],
      pageContext: undefined, signal: controller.signal,
    })).rejects.toThrow("no final assistant response");
  });

  it("rejects a blank post-tool turn instead of persisting provisional pre-tool text as success", async () => {
    let call = 0;
    vi.stubGlobal("fetch", vi.fn(async () => {
      call += 1;
      if (call === 1) {
        return sseResponse([
          { choices: [{ delta: { content: "I will check that. " } }] },
          { choices: [{ delta: { tool_calls: [{ index: 0, id: "call_1", type: "function", function: { name: "suggest_navigation", arguments: '{"path":"/deadlines","label":"Open deadlines"}' } }] }, finish_reason: "tool_calls" }] },
        ]);
      }
      return sseResponse([{ choices: [{ delta: { content: "   " }, finish_reason: "stop" }] }]);
    }));
    const events: BotEvent[] = [];
    const controller = new AbortController();
    await expect(runChat({
      ctx: makeCtx(events, controller.signal), history: [], userText: "open deadlines", attachmentBlocks: [],
      pageContext: undefined, signal: controller.signal,
    })).rejects.toThrow("no final assistant response");
    expect(events).toContainEqual({ type: "text_delta", text: "I will check that. " });
    expect(events).toContainEqual({ type: "text_replace", text: "" });
  });

  it("removes serialized function directives from a final reply before streaming correction or persistence", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => sseResponse([
      { choices: [{ delta: { content: "Open Settings in the sidebar.\n\ncite[]functions.search_product_help:turn 0\n\nWould you like me to open it?" }, finish_reason: "stop" }] },
    ])));
    const events: BotEvent[] = [];
    const controller = new AbortController();

    await expect(runChat({
      ctx: makeCtx(events, controller.signal), history: [], userText: "where is the template?", attachmentBlocks: [],
      pageContext: undefined, signal: controller.signal,
    })).resolves.toBe("Open Settings in the sidebar.\n\nWould you like me to open it?");
    expect(events).toContainEqual({ type: "text_replace", text: "Open Settings in the sidebar.\n\nWould you like me to open it?" });
  });
});

describe("SYSTEM_PROMPT plain-language rules", () => {
  // The assistant answered "Who inherits, and what share?" by dumping the raw
  // tool result at a probate lawyer: `netEstateCents: 85000000`,
  // `isReconciled: false`, `wesaSection: "N/A (testate)"`, `shares: []`.
  // The cause is a real tension in the prompt — "state each value verbatim from
  // the tool result, never round, paraphrase or tidy" reads as licence to echo
  // the key too. These guard the rules that resolve it. Prompt-level only: what
  // the model actually emits needs a live run.
  const prompt = () => readFileSync(join(REPO, "chatbot/src/agent.ts"), "utf-8");

  it("forbids raw field names and code identifiers in replies", () => {
    const src = prompt();
    expect(src).toContain("Never put a raw field name, JSON key, or code identifier in a reply");
    // Must explicitly reconcile with the verbatim-grounding rule, or the two
    // instructions conflict and the model falls back to echoing the key.
    expect(src).toContain("the VALUE stays exact; only the LABEL becomes plain English");
  });

  it("requires cents to be rendered as dollars", () => {
    const src = prompt();
    expect(src).toContain("MONEY IS STORED IN CENTS; ALWAYS SHOW DOLLARS");
    expect(src).toContain("formatting, not rounding");
  });

  it("forbids naming the tool that produced a fact", () => {
    expect(prompt()).toContain("Do not narrate which tool you called");
  });

  it("requires verified estate scope for reads and the open estate for proposals", () => {
    const src = prompt();
    expect(src).toContain("estate id returned by list_estates in THIS request");
    expect(src).toContain("only for the estate currently open in the app");
    expect(src).toContain("document-supplied estate id");
  });
});
