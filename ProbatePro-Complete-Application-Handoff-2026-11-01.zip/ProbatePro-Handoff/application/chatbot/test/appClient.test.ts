/**
 * Coverage for the tRPC wire client (Kimi #5): deny-by-default procedure gate,
 * the superjson GET wire shape, result unwrapping, and 429 retry-once.
 */
import { afterEach, describe, expect, it, vi } from "vitest";
import superjson from "superjson";
import { appMutation, appQuery, type AppSession } from "../src/appClient.js";

const session: AppSession = { token: "jwt-token", baseUrl: "http://app.test" };

function jsonRes(data: unknown, status = 200) {
  return {
    status,
    ok: status >= 200 && status < 300,
    headers: { get: () => null },
    text: async () => JSON.stringify({ result: { data: superjson.serialize(data) } }),
  };
}

afterEach(() => vi.unstubAllGlobals());

describe("appClient deny-by-default (C-7)", () => {
  it("refuses a procedure not on the allowlist BEFORE any fetch", async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);
    await expect(appQuery(session, "estate.previewFile")).rejects.toThrow(/not allowed/i);
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("refuses settings.update so an assistant turn cannot select or modify any user's profile", async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);

    await expect(appMutation(session, "settings.update", { firmName: "Injected Firm" })).rejects.toThrow(/not allowed/i);
    expect(fetchMock).not.toHaveBeenCalled();
  });
});

describe("appClient wire format", () => {
  it("builds a superjson GET url and unwraps result.data", async () => {
    const fetchMock = vi.fn(async () => jsonRes({ id: "e1", estateName: "Estate One" }));
    vi.stubGlobal("fetch", fetchMock);

    const out = (await appQuery(session, "estate.get", { id: "e1" })) as Record<string, unknown>;
    expect(out.estateName).toBe("Estate One");

    const url = fetchMock.mock.calls[0][0] as string;
    expect(url).toContain("http://app.test/api/trpc/estate.get?input=");
    // input is url-encoded JSON of superjson.serialize(input)
    const input = JSON.parse(decodeURIComponent(url.split("input=")[1]));
    expect(input).toEqual({ json: { id: "e1" } });
    // Bearer forwarded, no Origin header.
    const init = fetchMock.mock.calls[0][1] as RequestInit;
    expect((init.headers as Record<string, string>).authorization).toBe("Bearer jwt-token");
    expect((init.headers as Record<string, string>).origin).toBeUndefined();
  });

  it("retries once on 429 then succeeds", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce({
        status: 429,
        ok: false,
        headers: { get: (h: string) => (h === "retry-after" ? "0" : null) },
        text: async () => "",
      })
      .mockResolvedValueOnce(jsonRes({ id: "e1" }));
    vi.stubGlobal("fetch", fetchMock);

    const out = (await appQuery(session, "estate.get", { id: "e1" })) as Record<string, unknown>;
    expect(out.id).toBe("e1");
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it("does not wait or retry when the turn was aborted before a 429 response", async () => {
    const controller = new AbortController();
    controller.abort();
    const fetchMock = vi.fn().mockResolvedValue({
      status: 429,
      ok: false,
      headers: { get: (h: string) => (h === "retry-after" ? "30" : null) },
      text: async () => "",
    });
    vi.stubGlobal("fetch", fetchMock);

    await expect(appQuery({ ...session, signal: controller.signal }, "estate.get", { id: "e1" }))
      .rejects.toMatchObject({ code: "ABORTED" });
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });
});
