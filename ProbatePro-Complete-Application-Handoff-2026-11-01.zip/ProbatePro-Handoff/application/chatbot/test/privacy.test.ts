import { describe, expect, it } from "vitest";
import { projectContactSnapshot, projectEstateSnapshot, projectInventorySnapshot } from "../src/tools.js";

describe("Forge data minimization", () => {
  it("permanently excludes identity, account, ownership, and storage secrets", () => {
    const estate = projectEstateSnapshot({ estateName: "Smith Estate", deceasedFirstName: "Jane", deceasedSIN: "123456789", deceasedTIN: "T0001", createdByUserId: 7, willStorageKey: "secret/key", accessToken: "secret" });
    expect(estate).toEqual({ estateName: "Smith Estate", deceasedFirstName: "Jane" });
    // contactId is EXPOSED by design (2026-08-03): it is the handle
    // propose_contact_updates requires, it grants nothing by itself (every
    // write is authorized server-side under the user's own JWT at Apply time),
    // and without it the edit-a-contact flow dead-ends. Storage locators and
    // unlisted columns stay stripped.
    const contact = projectContactSnapshot({ id: "contact-7", name: "Alex", role: "executor", priorityConsentDocumentKey: "secret/key" });
    expect(contact).toEqual({ contactId: "contact-7", Name: "Alex", Roles: "executor" });
    const item = projectInventorySnapshot({ id: "item-secret", category: "financial", description: "Savings account", value: 10_000, accountNumber: "999999", accountHolder: "Jane Smith", bankAddress: "1 Bank St", estateId: "estate-secret" });
    expect(item).toEqual({ category: "financial", description: "Savings account", value: 10_000 });
  });

  it("speaks the contact snapshot in plain English, not column names", () => {
    // Whatever keys this projection emits are what the model parrots into
    // user-facing prose — "isMinor: 0" reached Nick's screen twice. Labels are
    // human; clear flags and unrecorded defaults are dropped; money renders as
    // dollars; role tokens stay canonical so they round-trip into
    // propose_contact_updates validation.
    const contact = projectContactSnapshot({
      id: 12,
      name: "Susan Marie Hughes-Bennett",
      role: "beneficiary,executor,applicant",
      relationship: "child",
      residentialAddress: "88 Beach Drive, Victoria, BC V8T 2K9",
      isMinor: 0,
      isMentallyIncapable: 0,
      isPredeceased: 1,
      executorStatus: "applying",
      executorRank: "primary",
      executorRankNumber: 0,
      applicantKind: "individual",
      estimatedValue: 0,
      estimatedValueRecorded: 0,
    });
    expect(contact).toEqual({
      contactId: "12",
      Name: "Susan Marie Hughes-Bennett",
      Roles: "beneficiary, executor, applicant",
      "Relationship to the deceased": "child",
      "Residential address": "88 Beach Drive, Victoria, BC V8T 2K9",
      Predeceased: "yes",
      "Executor status": "applying",
      "Executor rank": "primary",
      "Applicant type": "individual",
    });
    // A recorded value renders as dollars, including a genuine $0.
    expect(projectContactSnapshot({ id: 1, name: "A", estimatedValue: 123456, estimatedValueRecorded: 1 })["Estimated value"]).toBe("$1,234.56");
    expect(projectContactSnapshot({ id: 1, name: "A", estimatedValue: 0, estimatedValueRecorded: 1 })["Estimated value"]).toBe("$0.00");
  });
});
