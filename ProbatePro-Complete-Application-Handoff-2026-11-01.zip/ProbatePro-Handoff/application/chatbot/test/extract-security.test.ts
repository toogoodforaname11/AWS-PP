import { describe, expect, it } from "vitest";
import JSZip from "jszip";
import { ExtractError, inspectDocxArchive, validateAttachmentBatch } from "../src/extract.js";

describe("attachment extraction boundaries", () => {
  it("rejects malformed base64 before allocating parser work", () => {
    expect(() => validateAttachmentBatch([{ name: "will.pdf", mime: "application/pdf", dataBase64: "%%%%" }])).toThrow(ExtractError);
  });

  it("accepts a small canonical DOCX package", async () => {
    const zip = new JSZip();
    zip.file("[Content_Types].xml", "<Types/>");
    zip.file("word/document.xml", "<w:document/>");
    const buffer = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
    expect(() => inspectDocxArchive(buffer)).not.toThrow();
  });

  it("rejects malformed and high-ratio DOCX archives before Mammoth", async () => {
    expect(() => inspectDocxArchive(Buffer.from("PK malformed", "ascii"))).toThrow(/malformed/i);
    const zip = new JSZip();
    zip.file("[Content_Types].xml", "<Types/>");
    zip.file("word/document.xml", "<w:document/>");
    zip.file("word/media/bomb.bin", Buffer.alloc(2 * 1024 * 1024, 0x41));
    const bomb = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE", compressionOptions: { level: 9 } });
    expect(() => inspectDocxArchive(bomb)).toThrow(/compression ratio/i);
  });
});
