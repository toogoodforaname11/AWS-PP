import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { forgeConfigError, isAllowedBrowserOrigin, validateEnv } from "../src/env.js";

describe("Forge environment contract", () => {
  it("requires the key and URL together", () => {
    expect(forgeConfigError({ forgeApiKey: "", forgeApiUrl: "https://forge.test" })).toContain("BUILT_IN_FORGE_API_KEY");
    expect(forgeConfigError({ forgeApiKey: "key", forgeApiUrl: "" })).toContain("BUILT_IN_FORGE_API_URL");
    expect(forgeConfigError({ forgeApiKey: "key", forgeApiUrl: "https://forge.test" })).toBeNull();
  });

  it("rejects invalid or insecure non-local Forge URLs", () => {
    expect(forgeConfigError({ forgeApiKey: "key", forgeApiUrl: "not-a-url" })).toContain("valid URL");
    expect(forgeConfigError({ forgeApiKey: "key", forgeApiUrl: "http://forge.example" })).toContain("HTTPS");
    expect(forgeConfigError({ forgeApiKey: "key", forgeApiUrl: "http://localhost:9999" })).toBeNull();
    // Credentials / query / fragment must be rejected — they must never reach the
    // request-URL builder (where the key is appended as a search param).
    expect(forgeConfigError({ forgeApiKey: "key", forgeApiUrl: "https://user:pass@forge.test" })).toContain("credentials");
    expect(forgeConfigError({ forgeApiKey: "key", forgeApiUrl: "https://forge.test/?x=1" })).toContain("query");
    expect(forgeConfigError({ forgeApiKey: "key", forgeApiUrl: "https://forge.test/#frag" })).toContain("fragment");
  });

  it("throws for invalid startup config instead of terminating an embedded parent process", () => {
    expect(() => validateEnv({ forgeApiKey: "", forgeApiUrl: "https://forge.test" }))
      .toThrow("Chatbot configuration invalid: BUILT_IN_FORGE_API_KEY is required");
  });

  it("requires exact scheme, host, and port for loopback credentialed origins", () => {
    expect(isAllowedBrowserOrigin("https://localhost:5173", "localhost:3000", "https")).toBe(false);
    expect(isAllowedBrowserOrigin("http://localhost:3000", "localhost:3000", "https")).toBe(false);
    expect(isAllowedBrowserOrigin("https://localhost:3000", "localhost:3000", "https")).toBe(true);
  });

  it("ships a copyable example with the settings the runtime actually consumes", () => {
    const example = readFileSync(join(process.cwd(), ".env.example"), "utf8");
    expect(example).toMatch(/^BUILT_IN_FORGE_API_KEY=\s*$/m);
    expect(example).toContain("BUILT_IN_FORGE_API_URL=https://");
    expect(example).toContain("CHATBOT_MODEL=gpt-5-mini");
    expect(example).not.toContain("ANTHROPIC_API_KEY");
    expect(example).not.toContain("claude-");
  });

  it("keeps embedded runtime dependencies aligned and removes the unused provider SDKs", () => {
    const root = JSON.parse(readFileSync(join(process.cwd(), "..", "package.json"), "utf8"));
    const bot = JSON.parse(readFileSync(join(process.cwd(), "package.json"), "utf8"));
    expect(root.dependencies["@anthropic-ai/sdk"]).toBeUndefined();
    expect(root.dependencies.openai).toBeUndefined();
    expect(bot.dependencies["@anthropic-ai/sdk"]).toBeUndefined();
    expect(bot.dependencies.openai).toBeUndefined();
    expect(bot.dependencies.superjson).toBe(root.dependencies.superjson);
  });
});
