import { defineConfig } from "vitest/config";

// Scoped HARD to this package — without this, vitest walks up and finds the
// app's root config, running the entire app suite from here.
export default defineConfig({
  test: {
    include: ["test/**/*.test.ts"],
    environment: "node",
    // Serialize files: several suites share a node:sqlite DB, and the boot-time
    // schema migration is a read-decide-write that isn't safe under concurrent
    // workers. Sequential files remove the contention deterministically
    // (busy_timeout is the belt; this is the braces). The suite is tiny/fast.
    fileParallelism: false,
    // ISOLATE the DB (ChatGPT #10): point every suite at a DEDICATED test DB, so
    // tests never read/pollute or boot-sweep the developer/operator chatbot.db.
    // Applied to process.env before any test file (and thus src/db.ts) imports.
    env: { CHATBOT_DB_PATH: "./data/vitest.db", AI_PROCESSOR_APPROVED: "true" },
    globalSetup: ["./test/globalSetup.ts"],
  },
});
